/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 19-05-2023	|	V1_0_0		| F5A01 - BRAKING SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF3B02_H
#define IRF3B02_H
#include "InterfaceRule.h"

class IRF3B02 : private InterfaceRule
{
public:
	// CTOR
	//IRF5A01();


	// METHODS
	int IRF3B02_002(ruleResult& final_res);
	int IRF3B02_004(ruleResult& final_res);
};
/*------------------- function prototypes for IRF3B02_002 rule -------------------*/
ProError F3B02_visit(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError F3B02_descget(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError Platform_Dropdown_action_IRF3B02_002(char* dialog, char* component);
void f3B02_getReqValsFrom2DCsvData(char* csvFileName, int fuelIdx, int reqValIdx, string fuelcap, vector<string>& reqValsFromCsv);
ProError Dropdown_action_IRF3B02_002(char* dialog, char* component);
ProError rule_action();

/*------------------- function prototypes for IRF3B02_002 rule -------------------*/

#endif