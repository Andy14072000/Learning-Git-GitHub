(Dialog dlg_IR_F5A24_006
    (Components
        (SubLayout Content)
        (Separator CommitSeparator)
        (PushButton rule_ok_pb)
        (PushButton rule_cancel_pb)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (rule_ok_pb.Label "OK")
        (rule_ok_pb.TopOffset 5)
        (rule_ok_pb.BottomOffset 10)
        (rule_ok_pb.LeftOffset 40)
        (rule_ok_pb.RightOffset 0)
        (rule_ok_pb.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:TopOffset")
        (rule_cancel_pb.Label "Cancel")
        (rule_cancel_pb.TopOffset 5)
        (rule_cancel_pb.BottomOffset 10)
        (rule_cancel_pb.LeftOffset 8)
        (rule_cancel_pb.RightOffset 10)
        (rule_cancel_pb.ResourceHints "Template:OKCancelDialog.CommitCancel" "UserOverrideAttrs:TopOffset")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "rule_ok_pb")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.AttachLeft True)
        (.Label "IR-F5A24-006")
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                Content CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    rule_ok_pb
                    (Pos 1 3)
                    rule_cancel_pb
                )
            )
        )
    )
)
(Layout Content
    (Components
        (SubLayout Layout1)
        (SubLayout Layout2)
        (Label lbl_2)
    )
    (Resources
        (lbl_2.Label "Click OK to verify if the model has Equalizer Mechanism")
        (lbl_2.AttachLeft True)
        (lbl_2.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_2.TopOffset 5)
        (lbl_2.BottomOffset 5)
        (lbl_2.LeftOffset 5)
        (lbl_2.RightOffset 5)
        (lbl_2.Alignment 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 5)
        (.BottomOffset 5)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content" "UserOverrideAttrs:TopOffset,BottomOffset")
        (.AttachBottom True)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 0 1 0)
                (Cols 0)
                Layout1 Layout2
                (Pos 4 1)
                lbl_2
            )
        )
    )
)
(Layout Layout1
    (Components
        (Label lbl_1)
    )
    (Resources
        (lbl_1.Label "Equalizer mechanism to be provided in order to equalize the 
pull of both rear-brake cables.")
        (lbl_1.AttachLeft True)
        (lbl_1.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_1.TopOffset 5)
        (lbl_1.BottomOffset 5)
        (lbl_1.LeftOffset 5)
        (lbl_1.RightOffset 5)
        (lbl_1.Alignment 0)
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset")
        (.TopOffset 9)
        (.BottomOffset 3)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                lbl_1
            )
        )
    )
)
(Layout Layout2
    (Components
        (PushButton pb_img)
    )
    (Resources
        (pb_img.Bitmap "D:\IRCApplications\DPDSCreoIRC_230724\text\usascii\resource\IR_F5A24_006\IR_F5A11_006.png")
        (pb_img.Columns 2)
        (pb_img.ButtonStyle 2)
        (pb_img.AttachLeft True)
        (pb_img.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (pb_img.TopOffset 5)
        (pb_img.BottomOffset 5)
        (pb_img.LeftOffset 5)
        (pb_img.RightOffset 5)
        (pb_img.Accelerator "Ctrl+S")
        (pb_img.KeyboardInput 0)
        (.ResourceHints "UserOverrideAttrs:AttachLeft,AttachRight,AttachTop,AttachBottom")
        (.TopOffset 3)
        (.BottomOffset 6)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                pb_img
            )
        )
    )
)
