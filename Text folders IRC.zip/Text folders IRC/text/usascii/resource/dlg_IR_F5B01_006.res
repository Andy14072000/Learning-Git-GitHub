(Dialog dlg_IR_F5B01_006
    (Components
        (SubLayout Content)
        (Separator CommitSeparator)
        (PushButton CommitOK)
        (PushButton CommitCancel)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (CommitOK.Label "OK")
        (CommitOK.TopOffset 10)
        (CommitOK.BottomOffset 10)
        (CommitOK.LeftOffset 40)
        (CommitOK.RightOffset 0)
        (CommitOK.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:Label")
        (CommitCancel.Label "Cancel")
        (CommitCancel.TopOffset 10)
        (CommitCancel.BottomOffset 10)
        (CommitCancel.LeftOffset 8)
        (CommitCancel.RightOffset 10)
        (CommitCancel.ResourceHints "Template:OKCancelDialog.CommitCancel")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "CommitOK")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.Label "IR-F5B01-006")
        (.AttachLeft True)
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                Content CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    CommitOK
                    (Pos 1 3)
                    CommitCancel
                )
            )
        )
    )
)
(Layout Content
    (Components
        (SubLayout description_layout)
        (SubLayout main_layout)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 16)
        (.BottomOffset 16)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content")
        (.AttachBottom True)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 0)
                description_layout main_layout
            )
        )
    )
)
(Layout description_layout
    (Components
        (Label desc_lbl)
    )
    (Resources
        (desc_lbl.Label "Lateral clearance between grown tire & component immediately
nearest to grown tire (usually U-bolt of Suspension) should be 
minimum 40**mm.")
        (desc_lbl.AttachLeft True)
        (desc_lbl.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (desc_lbl.TopOffset 3)
        (desc_lbl.BottomOffset 1)
        (desc_lbl.LeftOffset 2)
        (desc_lbl.RightOffset 2)
        (desc_lbl.Alignment 0)
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,LeftOffset,RightOffset")
        (.TopOffset 10)
        (.BottomOffset 3)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                desc_lbl
            )
        )
    )
)
(Layout main_layout
    (Components
        (SubLayout selection_layout)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 2)
        (.BottomOffset 0)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                selection_layout
            )
        )
    )
)
(Layout selection_layout
    (Components
        (PushButton rule_img)
        (Label Label3)
        (Label Label2)
        (PushButton Select1)
    )
    (Resources
        (rule_img.Bitmap "IR_F5B01_006/IR_F5B01_006.png")
        (rule_img.Columns 2)
        (rule_img.ButtonStyle 2)
        (rule_img.AttachLeft True)
        (rule_img.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (rule_img.TopOffset 5)
        (rule_img.BottomOffset 5)
        (rule_img.LeftOffset 2)
        (rule_img.RightOffset 2)
        (Label3.Label "Click on Ok to verify the rule.")
        (Label3.AttachLeft True)
        (Label3.TopOffset 1)
        (Label3.BottomOffset 0)
        (Label3.LeftOffset 0)
        (Label3.RightOffset 0)
        (Label2.Label "Click to select surfaces for measuring the clearance")
        (Label2.AttachLeft True)
        (Label2.TopOffset 0)
        (Label2.BottomOffset 3)
        (Label2.LeftOffset 0)
        (Label2.RightOffset 4)
        (Select1.Label "Select")
        (Select1.TopOffset 0)
        (Select1.BottomOffset 3)
        (Select1.LeftOffset 40)
        (Select1.RightOffset 0)
        (Select1.ResourceHints "UserOverrideAttrs:LeftOffset,AttachLeft,AttachRight")
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 0)
        (.BottomOffset 5)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.Layout
            (Grid
                (Rows 0 0 0)
                (Cols 0)
                (Grid
                    (Rows 0)
                    (Cols 0 0)
                    Label2 Select1
                )
                rule_img Label3
            )
        )
    )
)
