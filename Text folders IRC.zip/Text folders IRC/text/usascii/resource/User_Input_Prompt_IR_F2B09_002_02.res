(Dialog User_Input_Prompt_IR_F2B09_002_02
    (Components
        (SubLayout main_layout)
        (Separator CommitSeparator)
        (PushButton CommitOK1)
        (PushButton CommitCancel1)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (CommitOK1.Label "OK")
        (CommitOK1.TopOffset 10)
        (CommitOK1.BottomOffset 10)
        (CommitOK1.LeftOffset 40)
        (CommitOK1.RightOffset 0)
        (CommitOK1.ResourceHints "Template:OKCancelDialog.CommitOK")
        (CommitCancel1.Label "Cancel")
        (CommitCancel1.TopOffset 10)
        (CommitCancel1.BottomOffset 10)
        (CommitCancel1.LeftOffset 8)
        (CommitCancel1.RightOffset 10)
        (CommitCancel1.ResourceHints "Template:OKCancelDialog.CommitCancel")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "CommitOK1")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.Label "Confirmation Needed")
        (.AttachLeft True)
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                main_layout CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    CommitOK1
                    (Pos 1 3)
                    CommitCancel1
                )
            )
        )
    )
)
(Layout main_layout
    (Components
        (SubLayout Layout1)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 10)
        (.BottomOffset 10)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content" "UserOverrideAttrs:TopOffset,BottomOffset")
        (.AttachBottom True)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                Layout1
            )
        )
    )
)
(Layout Layout1
    (Components
        (Label Label1)
        (SubLayout Layout3)
    )
    (Resources
        (Label1.Label "Computed distance = 0mm ,
Kindly confirm that protection is present on the point.")
        (Label1.AttachLeft True)
        (Label1.Alignment 0)
        (Label1.TopOffset 10)
        (Label1.BottomOffset 5)
        (Label1.LeftOffset 7)
        (Label1.RightOffset 7)
        (Label1.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset")
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 0)
                Label1 Layout3
            )
        )
    )
)
(Layout Layout3
    (Components
        (RadioGroup Options2)
    )
    (Resources
        (Options2.AttachRight False)
        (Options2.AttachTop False)
        (Options2.AttachBottom False)
        (Options2.Names "Select" "Yes" "No")
        (Options2.Labels "Select" "Yes" "No")
        (Options2.ResourceHints "UserOverrideAttrs:LeftOffset,RightOffset,ButtonStyle")
        (Options2.TopOffset 0)
        (Options2.BottomOffset 0)
        (Options2.LeftOffset 4)
        (Options2.RightOffset 12)
        (Options2.FontStyle 10)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset")
        (.TopOffset 10)
        (.BottomOffset 10)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                Options2
            )
        )
    )
)
