(Dialog dlg_IR_f2b01_001
    (Components
        (SubLayout Content)
        (Separator CommitSeparator)
        (PushButton pb_run)
        (PushButton CommitCancel)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (pb_run.Label "Run")
        (pb_run.TopOffset 5)
        (pb_run.BottomOffset 10)
        (pb_run.LeftOffset 40)
        (pb_run.RightOffset 0)
        (pb_run.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:Label,TopOffset")
        (pb_run.Sensitive False)
        (CommitCancel.Label "Cancel")
        (CommitCancel.TopOffset 5)
        (CommitCancel.BottomOffset 10)
        (CommitCancel.LeftOffset 8)
        (CommitCancel.RightOffset 10)
        (CommitCancel.ResourceHints "Template:OKCancelDialog.CommitCancel" "UserOverrideAttrs:TopOffset")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "pb_run")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.AttachLeft True)
        (.Label "IR-F2B01-001")
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                Content CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    pb_run
                    (Pos 1 3)
                    CommitCancel
                )
            )
        )
    )
)
(Layout Content
    (Components
        (SubLayout Layout2)
        (SubLayout Layout1)
        (SubLayout Layout3)
        (SubLayout Layout4)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 16)
        (.BottomOffset 16)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content" "UserOverrideAttrs:TopOffset,BottomOffset")
        (.AttachBottom True)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 0 0 0)
                (Cols 0)
                Layout2 Layout1 Layout3 Layout4
            )
        )
    )
)
(Layout Layout2
    (Components
        (Label lbl_1)
    )
    (Resources
        (lbl_1.Label "Ensure clearance between Steering column 
assy/ rubber bellow & Brake pedal >50mm.")
        (lbl_1.AttachLeft True)
        (lbl_1.ResourceHints "UserOverrideAttrs:AttachLeft,TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_1.TopOffset 3)
        (lbl_1.BottomOffset 1)
        (lbl_1.LeftOffset 2)
        (lbl_1.RightOffset 2)
        (lbl_1.Alignment 0)
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,LeftOffset,RightOffset")
        (.TopOffset 10)
        (.BottomOffset 3)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                lbl_1
            )
        )
    )
)
(Layout Layout1
    (Components
        (PushButton pb_img)
    )
    (Resources
        (pb_img.Bitmap "IR_F2B01_001/IR-F2B01-001")
        (pb_img.Columns 2)
        (pb_img.ButtonStyle 2)
        (pb_img.AttachLeft True)
        (pb_img.ResourceHints "UserOverrideAttrs:AttachLeft,TopOffset,BottomOffset,LeftOffset,RightOffset")
        (pb_img.TopOffset 5)
        (pb_img.BottomOffset 5)
        (pb_img.LeftOffset 2)
        (pb_img.RightOffset 2)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 2)
        (.BottomOffset 0)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                pb_img
            )
        )
    )
)
(Layout Layout3
    (Components
        (Label select_info_lbl)
        (PushButton pb_select)
    )
    (Resources
        (select_info_lbl.Label "Click \"select\"
1. First select part
2. Then select the surface
")
        (select_info_lbl.AttachLeft True)
        (select_info_lbl.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (select_info_lbl.TopOffset 5)
        (select_info_lbl.BottomOffset 5)
        (select_info_lbl.LeftOffset 2)
        (select_info_lbl.RightOffset 2)
        (select_info_lbl.Alignment 0)
        (pb_select.Label "Select")
        (pb_select.AttachLeft True)
        (pb_select.TopOffset 5)
        (pb_select.BottomOffset 5)
        (pb_select.LeftOffset 5)
        (pb_select.RightOffset 5)
        (pb_select.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 3)
        (.BottomOffset 2)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0 0)
                select_info_lbl pb_select
            )
        )
    )
)
(Layout Layout4
    (Components
        (Label lbl_2)
    )
    (Resources
        (lbl_2.Label "Click Run to proceed.")
        (lbl_2.AttachLeft True)
        (lbl_2.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_2.TopOffset 5)
        (lbl_2.BottomOffset 5)
        (lbl_2.LeftOffset 2)
        (lbl_2.RightOffset 2)
        (lbl_2.Alignment 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 1)
        (.BottomOffset 3)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                lbl_2
            )
        )
    )
)
