﻿(Dialog dlg_IR_F2C01_017
    (Components
        (SubLayout Content)
        (Separator CommitSeparator)
        (PushButton CommitOK)
        (PushButton CommitCancel)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (CommitOK.Label "OK")
        (CommitOK.TopOffset 10)
        (CommitOK.BottomOffset 10)
        (CommitOK.LeftOffset 40)
        (CommitOK.RightOffset 0)
        (CommitOK.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:Label")
        (CommitOK.Sensitive False)
        (CommitCancel.Label "Cancel")
        (CommitCancel.TopOffset 10)
        (CommitCancel.BottomOffset 10)
        (CommitCancel.LeftOffset 8)
        (CommitCancel.RightOffset 10)
        (CommitCancel.ResourceHints "Template:OKCancelDialog.CommitCancel")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "CommitOK")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.Label "IR_F2C01_017")
        (.AttachLeft True)
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                Content CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    CommitOK
                    (Pos 1 3)
                    CommitCancel
                )
            )
        )
    )
)
(Layout Content
    (Components
        (SubLayout description_layout)
        (SubLayout main_layout)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 16)
        (.BottomOffset 16)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content")
        (.AttachBottom True)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 0)
                description_layout main_layout
            )
        )
    )
)
(Layout description_layout
    (Components
        (Label desc_lbl)
    )
    (Resources
        (desc_lbl.Label "Target RA inclination to be with in ± 1 deg of GB inclination. 
Else, decision based on Performance evaluation 
")
        (desc_lbl.AttachLeft True)
        (desc_lbl.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (desc_lbl.TopOffset 3)
        (desc_lbl.BottomOffset 1)
        (desc_lbl.LeftOffset 2)
        (desc_lbl.RightOffset 2)
        (desc_lbl.Alignment 0)
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,LeftOffset,RightOffset")
        (.TopOffset 10)
        (.BottomOffset 3)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                desc_lbl
            )
        )
    )
)
(Layout main_layout
    (Components
        (SubLayout selection_layout)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 2)
        (.BottomOffset 0)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                selection_layout
            )
        )
    )
)
(Layout selection_layout
    (Components
        (PushButton rule_img)
        (Label select_info_lbl)
        (PushButton select_pb)
    )
    (Resources
        (rule_img.Bitmap "IR_F2C01_017\IR_F2C01_017.png")
        (rule_img.Columns 2)
        (rule_img.ButtonStyle 2)
        (rule_img.AttachLeft True)
        (rule_img.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (rule_img.TopOffset 5)
        (rule_img.BottomOffset 5)
        (rule_img.LeftOffset 2)
        (rule_img.RightOffset 2)
        (select_info_lbl.Label "Click to select the Axis as shown above.")
        (select_info_lbl.AttachLeft True)
        (select_info_lbl.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (select_info_lbl.TopOffset 5)
        (select_info_lbl.BottomOffset 5)
        (select_info_lbl.LeftOffset 2)
        (select_info_lbl.RightOffset 2)
        (select_pb.Label "Select")
        (select_pb.AttachLeft True)
        (select_pb.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (select_pb.TopOffset 5)
        (select_pb.BottomOffset 5)
        (select_pb.LeftOffset 5)
        (select_pb.RightOffset 5)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 0)
        (.BottomOffset 5)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 0)
                rule_img
                (Grid
                    (Rows 0)
                    (Cols 0 0)
                    select_info_lbl select_pb
                )
            )
        )
    )
)
