(Dialog User_Input_Prompt_IR_F2B09_002
    (Components
        (SubLayout main_Layout)
        (Separator CommitSeparator)
        (PushButton CommitOK)
        (PushButton CommitCancel)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (CommitOK.Label "OK")
        (CommitOK.TopOffset 10)
        (CommitOK.BottomOffset 10)
        (CommitOK.LeftOffset 40)
        (CommitOK.RightOffset 0)
        (CommitOK.ResourceHints "Template:OKCancelDialog.CommitOK")
        (CommitCancel.Label "Cancel")
        (CommitCancel.TopOffset 10)
        (CommitCancel.BottomOffset 10)
        (CommitCancel.LeftOffset 8)
        (CommitCancel.RightOffset 10)
        (CommitCancel.ResourceHints "Template:OKCancelDialog.CommitCancel")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "CommitOK")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.Label "Confirmation Needed")
        (.AttachLeft True)
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                main_Layout CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    CommitOK
                    (Pos 1 3)
                    CommitCancel
                )
            )
        )
    )
)
(Layout main_Layout
    (Components
        (SubLayout Layout1)
        (SubLayout Layout2)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 10)
        (.BottomOffset 10)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content" "UserOverrideAttrs:TopOffset,BottomOffset")
        (.AttachBottom True)
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 1)
                Layout1 Layout2
            )
        )
    )
)
(Layout Layout1
    (Components
        (Label Label1)
        (SubLayout Layout3)
    )
    (Resources
        (Label1.Label "Computed distance < 10mm,
Kindly confirm that on either side of the point,
within 40mm the Clamps/Brackets are present")
        (Label1.AttachLeft True)
        (Label1.Alignment 0)
        (Label1.TopOffset 10)
        (Label1.BottomOffset 5)
        (Label1.LeftOffset 7)
        (Label1.RightOffset 7)
        (Label1.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset")
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 0)
        (.BottomOffset 10)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 0)
                Label1 Layout3
            )
        )
    )
)
(Layout Layout3
    (Components
        (RadioGroup Options)
    )
    (Resources
        (Options.AttachRight False)
        (Options.AttachTop False)
        (Options.AttachBottom False)
        (Options.Names "Select" "Yes" "No")
        (Options.Labels "Select" "Yes" "No")
        (Options.ResourceHints "UserOverrideAttrs:LeftOffset,RightOffset,ButtonStyle")
        (Options.TopOffset 0)
        (Options.BottomOffset 0)
        (Options.LeftOffset 4)
        (Options.RightOffset 12)
        (Options.FontStyle 10)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset")
        (.TopOffset 10)
        (.BottomOffset 10)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                Options
            )
        )
    )
)
(Layout Layout2
    (Components
        (SubLayout Layout4)
        (SubLayout Layout4_copy)
    )
    (Resources
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.ResourceHints "UserOverrideAttrs:TopOffset")
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 1)
                Layout4 Layout4_copy
            )
        )
    )
)
(Layout Layout4
    (Components
        (Label Label2)
        (InputPanel InputPanel1)
    )
    (Resources
        (Label2.Label "Kindly enter the 1st bracket/clamp no.")
        (Label2.AttachLeft True)
        (Label2.TopOffset 0)
        (Label2.BottomOffset 2)
        (Label2.LeftOffset 0)
        (Label2.RightOffset 0)
        (InputPanel1.MaxLen 100)
        (InputPanel1.TopOffset 5)
        (InputPanel1.BottomOffset 0)
        (InputPanel1.LeftOffset 0)
        (InputPanel1.RightOffset 0)
        (InputPanel1.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset")
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset")
        (.TopOffset 10)
        (.BottomOffset 2)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 1)
                Label2 InputPanel1
            )
        )
    )
)
(Layout Layout4_copy
    (Components
        (Label Label3)
        (InputPanel InputPanel2)
    )
    (Resources
        (Label3.Label "Kindly enter the 2nd bracket/clamp no..")
        (Label3.AttachLeft True)
        (Label3.TopOffset 0)
        (Label3.BottomOffset 2)
        (Label3.LeftOffset 0)
        (Label3.RightOffset 0)
        (InputPanel2.MaxLen 100)
        (InputPanel2.TopOffset 5)
        (InputPanel2.BottomOffset 0)
        (InputPanel2.LeftOffset 0)
        (InputPanel2.RightOffset 0)
        (InputPanel2.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset")
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset")
        (.TopOffset 10)
        (.BottomOffset 6)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 1)
                Label3 InputPanel2
            )
        )
    )
)
