(Dialog dlg_IR_F5A10_007
    (Components
        (SubLayout Content)
        (Separator CommitSeparator)
        (PushButton CommitOK)
        (PushButton CommitClose)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (CommitOK.Label "OK")
        (CommitOK.TopOffset 7)
        (CommitOK.BottomOffset 5)
        (CommitOK.LeftOffset 40)
        (CommitOK.RightOffset 0)
        (CommitOK.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:TopOffset,BottomOffset")
        (CommitOK.Sensitive False)
        (CommitClose.Label "Close")
        (CommitClose.TopOffset 7)
        (CommitClose.BottomOffset 5)
        (CommitClose.LeftOffset 8)
        (CommitClose.RightOffset 10)
        (CommitClose.ResourceHints "Template:OKCancelDialog.CommitCancel" "UserOverrideAttrs:Label,TopOffset,BottomOffset")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "CommitOK")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.Label "IR-F5A10-007")
        (.AttachLeft True)
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                Content CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    CommitOK
                    (Pos 1 3)
                    CommitClose
                )
            )
        )
    )
)
(Layout Content
    (Components
        (Label Label1)
        (SubLayout Layout1)
    )
    (Resources
        (Label1.Label "Clearance between electronic valve and mounting bracket should be 
more than 5mm")
        (Label1.AttachLeft True)
        (Label1.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (Label1.TopOffset 5)
        (Label1.BottomOffset 5)
        (Label1.LeftOffset 5)
        (Label1.RightOffset 5)
        (Label1.Alignment 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 5)
        (.BottomOffset 5)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.ResourceHints "Template:OKCancelDialog.Content" "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.AttachBottom True)
        (.Focus "CommitOK")
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 1 0)
                (Cols 0)
                Label1
                (Pos 3 1)
                Layout1
            )
        )
    )
)
(Layout Layout1
    (Components
        (SubLayout layout1)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 6)
        (.BottomOffset 6)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                layout1
            )
        )
    )
)
(Layout layout1
    (Components
        (PushButton pb_image1)
        (SubLayout Layout2)
    )
    (Resources
        (pb_image1.Bitmap "IR_F5A10_007\IR_F5A10_007.jpg")
        (pb_image1.ButtonStyle 2)
        (pb_image1.AttachLeft True)
        (pb_image1.BackgroundColor 1)
        (pb_image1.TopOffset 0)
        (pb_image1.BottomOffset 3)
        (pb_image1.LeftOffset 0)
        (pb_image1.RightOffset 0)
        (.Columns 7)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 5)
        (.BottomOffset 5)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 0)
                pb_image1 Layout2
            )
        )
    )
)
(Layout Layout2
    (Components
        (Label Label3_copy)
        (PushButton pb_select)
    )
    (Resources
        (Label3_copy.Label "Select above surfaces to compute X and Y")
        (Label3_copy.AttachLeft True)
        (Label3_copy.TopOffset 0)
        (Label3_copy.BottomOffset 0)
        (Label3_copy.LeftOffset 0)
        (Label3_copy.RightOffset 4)
        (pb_select.Label "Select")
        (pb_select.AttachLeft True)
        (pb_select.TopOffset 0)
        (pb_select.BottomOffset 0)
        (pb_select.LeftOffset 3)
        (pb_select.RightOffset 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 3)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0 0)
                Label3_copy pb_select
            )
        )
    )
)
