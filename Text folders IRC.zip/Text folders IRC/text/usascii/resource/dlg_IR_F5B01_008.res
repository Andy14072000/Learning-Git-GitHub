(Dialog dlg_IR_F5B01_008
    (Components
        (SubLayout main_layout)
        (Separator CommitSeparator)
        (PushButton rule_ok_pb)
        (PushButton rule_cancel_pb)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (rule_ok_pb.Label "OK")
        (rule_ok_pb.TopOffset 10)
        (rule_ok_pb.BottomOffset 10)
        (rule_ok_pb.LeftOffset 40)
        (rule_ok_pb.RightOffset 0)
        (rule_ok_pb.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:Label,TopOffset")
        (rule_ok_pb.Sensitive False)
        (rule_cancel_pb.Label "Cancel")
        (rule_cancel_pb.TopOffset 10)
        (rule_cancel_pb.BottomOffset 10)
        (rule_cancel_pb.LeftOffset 8)
        (rule_cancel_pb.RightOffset 10)
        (rule_cancel_pb.ResourceHints "Template:OKCancelDialog.CommitCancel" "UserOverrideAttrs:TopOffset")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "rule_ok_pb")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.AttachLeft True)
        (.Label "IR-F5B01-008")
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                main_layout CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    rule_ok_pb
                    (Pos 1 3)
                    rule_cancel_pb
                )
            )
        )
    )
)
(Layout main_layout
    (Components
        (SubLayout Layout1)
        (SubLayout Layout2)
        (SubLayout Layout3)
        (SubLayout Layout4)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 16)
        (.BottomOffset 16)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content" "UserOverrideAttrs:TopOffset,BottomOffset")
        (.AttachBottom True)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 0 0 1 0)
                (Cols 0)
                Layout1 Layout2 Layout3
                (Pos 5 1)
                Layout4
            )
        )
    )
)
(Layout Layout1
    (Components
        (Label lbl_1)
    )
    (Resources
        (lbl_1.Label " Clearance between wheel rim with valve and brake drum or 
 disc should be minimum 3mm.
")
        (lbl_1.AttachLeft True)
        (lbl_1.ResourceHints "UserOverrideAttrs:AttachLeft,TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_1.TopOffset 5)
        (lbl_1.BottomOffset 5)
        (lbl_1.LeftOffset 5)
        (lbl_1.RightOffset 5)
        (lbl_1.Alignment 0)
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,LeftOffset,RightOffset")
        (.TopOffset 10)
        (.BottomOffset 3)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Label "Description")
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                lbl_1
            )
        )
    )
)
(Layout Layout2
    (Components
        (SubLayout Layout5)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 10)
        (.BottomOffset 5)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.ResourceHints "UserOverrideAttrs:AttachLeft,AttachRight,TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                Layout5
            )
        )
    )
)
(Layout Layout5
    (Components
        (PushButton pb_img)
    )
    (Resources
        (pb_img.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset,AttachLeft")
        (pb_img.TopOffset 10)
        (pb_img.BottomOffset 5)
        (pb_img.LeftOffset 5)
        (pb_img.RightOffset 5)
        (pb_img.Bitmap "IR-F5B01-008/blank.png")
        (pb_img.ButtonStyle 2)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 6)
        (.BottomOffset 6)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                pb_img
            )
        )
    )
)
(Layout Layout3
    (Components
        (Label lbl_2)
        (PushButton pb_select)
    )
    (Resources
        (lbl_2.Label "Please click to select the surfaces or components as shown 
in the image.")
        (lbl_2.AttachLeft True)
        (lbl_2.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_2.TopOffset 5)
        (lbl_2.BottomOffset 5)
        (lbl_2.LeftOffset 5)
        (lbl_2.RightOffset 5)
        (lbl_2.Alignment 0)
        (pb_select.Label "Select")
        (pb_select.AttachLeft True)
        (pb_select.TopOffset 7)
        (pb_select.BottomOffset 5)
        (pb_select.LeftOffset 5)
        (pb_select.RightOffset 5)
        (pb_select.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 10)
        (.BottomOffset 5)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Decorated 1)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 0)
                lbl_2 pb_select
            )
        )
    )
)
(Layout Layout4
    (Components
        (Label lbl_3)
    )
    (Resources
        (lbl_3.Label "Click OK to validate.")
        (lbl_3.AttachLeft True)
        (lbl_3.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_3.TopOffset 5)
        (lbl_3.BottomOffset 5)
        (lbl_3.LeftOffset 2)
        (lbl_3.RightOffset 2)
        (lbl_3.Alignment 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 3)
        (.BottomOffset 3)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                lbl_3
            )
        )
    )
)
