(Dialog dlg_IR_F4A02_001
    (Components
        (SubLayout Content)
        (Separator CommitSeparator)
        (PushButton rule_ok_pb)
        (PushButton rule_cancel_pb)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (rule_ok_pb.Label "OK")
        (rule_ok_pb.TopOffset 10)
        (rule_ok_pb.BottomOffset 10)
        (rule_ok_pb.LeftOffset 40)
        (rule_ok_pb.RightOffset 0)
        (rule_ok_pb.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:Label")
        (rule_cancel_pb.Label "Cancel")
        (rule_cancel_pb.TopOffset 10)
        (rule_cancel_pb.BottomOffset 10)
        (rule_cancel_pb.LeftOffset 8)
        (rule_cancel_pb.RightOffset 10)
        (rule_cancel_pb.ResourceHints "Template:OKCancelDialog.CommitCancel")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "rule_ok_pb")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.Label "IR-F4A02-001")
        (.AttachLeft True)
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                Content CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    rule_ok_pb
                    (Pos 1 3)
                    rule_cancel_pb
                )
            )
        )
    )
)
(Layout Content
    (Components
        (SubLayout description_layout)
        (SubLayout main_layout)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 16)
        (.BottomOffset 16)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content")
        (.AttachBottom True)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 1)
                (Cols 1)
                description_layout main_layout
            )
        )
    )
)
(Layout description_layout
    (Components
        (Label desc_lbl)
    )
    (Resources
        (desc_lbl.Label "Standard leaf spring type across platform based on application.
E.g. parabolic, semielliptical etc.")
        (desc_lbl.AttachLeft True)
        (desc_lbl.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (desc_lbl.TopOffset 3)
        (desc_lbl.BottomOffset 1)
        (desc_lbl.LeftOffset 2)
        (desc_lbl.RightOffset 2)
        (desc_lbl.Alignment 0)
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,LeftOffset,RightOffset")
        (.TopOffset 10)
        (.BottomOffset 3)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                desc_lbl
            )
        )
    )
)
(Layout main_layout
    (Components
        (SubLayout selection_layout)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 2)
        (.BottomOffset 0)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 1)
                (Cols 1)
                selection_layout
            )
        )
    )
)
(Layout selection_layout
    (Components
        (Label sel_option_menu_lbl)
        (OptionMenu spring_type_option_menu)
        (PushButton suspension_img)
    )
    (Resources
        (sel_option_menu_lbl.Label "Select the Leaf spring type")
        (sel_option_menu_lbl.AttachLeft True)
        (sel_option_menu_lbl.TopOffset 5)
        (sel_option_menu_lbl.BottomOffset 5)
        (sel_option_menu_lbl.LeftOffset 2)
        (sel_option_menu_lbl.RightOffset 2)
        (sel_option_menu_lbl.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (spring_type_option_menu.Columns 8)
        (spring_type_option_menu.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset,AttachRight")
        (spring_type_option_menu.TopOffset 5)
        (spring_type_option_menu.BottomOffset 5)
        (spring_type_option_menu.LeftOffset 5)
        (spring_type_option_menu.RightOffset 5)
        (spring_type_option_menu.AttachRight False)
        (suspension_img.Columns 2)
        (suspension_img.AttachLeft True)
        (suspension_img.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (suspension_img.TopOffset 5)
        (suspension_img.BottomOffset 5)
        (suspension_img.LeftOffset 2)
        (suspension_img.RightOffset 2)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 0)
        (.BottomOffset 5)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.Layout
            (Grid
                (Rows 0 1 0)
                (Cols 1)
                (Grid
                    (Rows 0)
                    (Cols 0 1)
                    sel_option_menu_lbl spring_type_option_menu
                )
                (Pos 3 1)
                suspension_img
            )
        )
    )
)
