(Dialog dlg_IR_F5A24_006
    (Components
        (SubLayout Content)
        (Separator CommitSeparator)
        (PushButton rule_ok_pb)
        (PushButton rule_cancel_pb)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (rule_ok_pb.Label "OK")
        (rule_ok_pb.TopOffset 5)
        (rule_ok_pb.BottomOffset 10)
        (rule_ok_pb.LeftOffset 40)
        (rule_ok_pb.RightOffset 0)
        (rule_ok_pb.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:Label,TopOffset")
        (rule_ok_pb.Sensitive False)
        (rule_cancel_pb.Label "Cancel")
        (rule_cancel_pb.TopOffset 5)
        (rule_cancel_pb.BottomOffset 10)
        (rule_cancel_pb.LeftOffset 8)
        (rule_cancel_pb.RightOffset 10)
        (rule_cancel_pb.ResourceHints "Template:OKCancelDialog.CommitCancel" "UserOverrideAttrs:TopOffset")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "rule_ok_pb")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.AttachLeft True)
        (.Label "IR-F5A24-006")
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                Content CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    rule_ok_pb
                    (Pos 1 3)
                    rule_cancel_pb
                )
            )
        )
    )
)
(Layout Content
    (Components
        (SubLayout Layout2)
        (SubLayout Layout1)
        (SubLayout Layout3)
        (SubLayout Layout4)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 16)
        (.BottomOffset 16)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content" "UserOverrideAttrs:TopOffset,BottomOffset")
        (.AttachBottom True)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 0 0 0)
                (Cols 0)
                Layout2 Layout1 Layout3 Layout4
            )
        )
    )
)
(Layout Layout2
    (Components
        (Label lbl_1)
    )
    (Resources
        (lbl_1.Label "Equalizer mechanism to be provided in order to equalize the pull of both
rear-brake cables.
")
        (lbl_1.AttachLeft True)
        (lbl_1.ResourceHints "UserOverrideAttrs:AttachLeft,TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_1.TopOffset 3)
        (lbl_1.BottomOffset 1)
        (lbl_1.LeftOffset 2)
        (lbl_1.RightOffset 2)
        (lbl_1.Alignment 0)
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,LeftOffset,RightOffset")
        (.TopOffset 10)
        (.BottomOffset 3)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                lbl_1
            )
        )
    )
)
(Layout Layout1
    (Components
        (PushButton pb_img)
    )
    (Resources
        (pb_img.Bitmap "IR_F5A24_006/IR_F5A24_006.png")
        (pb_img.Columns 2)
        (pb_img.ButtonStyle 2)
        (pb_img.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset,AttachLeft,AttachRight")
        (pb_img.TopOffset 5)
        (pb_img.BottomOffset 5)
        (pb_img.LeftOffset 2)
        (pb_img.RightOffset 2)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 2)
        (.BottomOffset 0)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                pb_img
            )
        )
    )
)
(Layout Layout3
    (Components
        (Label select_info_lbl)
        (PushButton pb_select)
    )
    (Resources
        (select_info_lbl.Label "Click to select 'Planes'
")
        (select_info_lbl.AttachLeft True)
        (select_info_lbl.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (select_info_lbl.TopOffset 5)
        (select_info_lbl.BottomOffset 5)
        (select_info_lbl.LeftOffset 2)
        (select_info_lbl.RightOffset 2)
        (pb_select.Label "Select")
        (pb_select.AttachLeft True)
        (pb_select.TopOffset 5)
        (pb_select.BottomOffset 5)
        (pb_select.LeftOffset 5)
        (pb_select.RightOffset 5)
        (pb_select.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 3)
        (.BottomOffset 2)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0 0)
                select_info_lbl pb_select
            )
        )
    )
)
(Layout Layout4
    (Components
        (Label lbl_2)
    )
    (Resources
        (lbl_2.Label "Click OK to validate.")
        (lbl_2.AttachLeft True)
        (lbl_2.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_2.TopOffset 5)
        (lbl_2.BottomOffset 5)
        (lbl_2.LeftOffset 2)
        (lbl_2.RightOffset 2)
        (lbl_2.Alignment 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 1)
        (.BottomOffset 3)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                lbl_2
            )
        )
    )
)
