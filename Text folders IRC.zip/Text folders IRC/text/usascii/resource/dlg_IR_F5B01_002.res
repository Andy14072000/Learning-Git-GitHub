(Dialog dlg_IR_F5B01_002
    (Components
        (SubLayout Content)
        (Separator CommitSeparator)
        (PushButton rule_ok_pb)
        (PushButton rule_cancel_pb)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (rule_ok_pb.Label "OK")
        (rule_ok_pb.TopOffset 10)
        (rule_ok_pb.BottomOffset 10)
        (rule_ok_pb.LeftOffset 40)
        (rule_ok_pb.RightOffset 0)
        (rule_ok_pb.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:Label")
        (rule_cancel_pb.Label "Cancel")
        (rule_cancel_pb.TopOffset 10)
        (rule_cancel_pb.BottomOffset 10)
        (rule_cancel_pb.LeftOffset 8)
        (rule_cancel_pb.RightOffset 10)
        (rule_cancel_pb.ResourceHints "Template:OKCancelDialog.CommitCancel")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "rule_ok_pb")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.Label "IR-F5B01-002")
        (.AttachLeft True)
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                Content CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    rule_ok_pb
                    (Pos 1 3)
                    rule_cancel_pb
                )
            )
        )
    )
)
(Layout Content
    (Components
        (SubLayout description_layout)
        (SubLayout main_layout)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 16)
        (.BottomOffset 16)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content")
        (.AttachBottom True)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 0)
                description_layout main_layout
            )
        )
    )
)
(Layout description_layout
    (Components
        (Label desc_lbl)
    )
    (Resources
        (desc_lbl.Label "Clearance between grown tire/wheel rim and brake chamber should be 
minimum 20**mm")
        (desc_lbl.AttachLeft True)
        (desc_lbl.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (desc_lbl.TopOffset 3)
        (desc_lbl.BottomOffset 1)
        (desc_lbl.LeftOffset 2)
        (desc_lbl.RightOffset 2)
        (desc_lbl.Alignment 0)
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,LeftOffset,RightOffset")
        (.TopOffset 10)
        (.BottomOffset 3)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                desc_lbl
            )
        )
    )
)
(Layout main_layout
    (Components
        (SubLayout selection_layout)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 2)
        (.BottomOffset 0)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                selection_layout
            )
        )
    )
)
(Layout selection_layout
    (Components
        (PushButton rule_img)
        (Label Label1)
    )
    (Resources
        (rule_img.Bitmap "IR_F5B01_002/IR_F5B01_002.png")
        (rule_img.Columns 2)
        (rule_img.ButtonStyle 2)
        (rule_img.AttachLeft True)
        (rule_img.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (rule_img.TopOffset 5)
        (rule_img.BottomOffset 5)
        (rule_img.LeftOffset 2)
        (rule_img.RightOffset 2)
        (Label1.Label "Click OK to measure the clearance.")
        (Label1.AttachLeft True)
        (Label1.TopOffset 1)
        (Label1.BottomOffset 0)
        (Label1.LeftOffset 0)
        (Label1.RightOffset 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 0)
        (.BottomOffset 5)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 0)
                rule_img Label1
            )
        )
    )
)
