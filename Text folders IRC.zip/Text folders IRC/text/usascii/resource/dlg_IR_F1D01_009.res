(Dialog dlg_IR_F1D01_009
    (Components
        (SubLayout Content)
        (Separator Separator1)
        (SubLayout Layout3)
    )
    (Resources
        (.ResourceHints "Version:Creo4")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.Label "IR-F1D01-009")
        (.StartLocation 4)
        (.MinimizeButton True)
        (.Focus "Ok_pb")
        (.MaximizeButton True)
        (.DefaultButton "Ok_pb")
        (.Layout
            (Grid
                (Rows 0 1 0 0)
                (Cols 1)
                Content
                (Pos 4 1)
                (Grid
                    (Rows 0 1)
                    (Cols 1)
                    Separator1 Layout3
                )
            )
        )
    )
)
(Layout Content
    (Components
        (SubLayout Description_Layout)
        (SubLayout Layout1)
    )
    (Resources
        (.TopOffset 10)
        (.BottomOffset 10)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content")
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 0)
                Description_Layout Layout1
            )
        )
    )
)
(Layout Description_Layout
    (Components
        (Label lbl_1)
    )
    (Resources
        (lbl_1.Label "Minimum one clamp to be provided in distance of 2m to hold the hydraulic pipe")
        (lbl_1.AttachLeft True)
        (lbl_1.TopOffset 3)
        (lbl_1.BottomOffset 3)
        (lbl_1.LeftOffset 2)
        (lbl_1.RightOffset 2)
        (lbl_1.Alignment 0)
        (lbl_1.Bitmap "UI ToolBar right image")
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 10)
        (.BottomOffset 10)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.Label "Description")
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                lbl_1
            )
        )
    )
)
(Layout Layout1
    (Components
        (SubLayout Table_Layout)
        (Label Label1)
    )
    (Resources
        (Label1.Bitmap "UI ToolBar right image")
        (Label1.Label "List of clamps identified in the current assembly.")
        (Label1.AttachLeft True)
        (Label1.TopOffset 10)
        (Label1.BottomOffset 3)
        (Label1.LeftOffset 5)
        (Label1.RightOffset 5)
        (.TopOffset 0)
        (.BottomOffset 10)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 1)
                (Cols 1)
                Label1
                (Grid
                    (Rows 1)
                    (Cols 1)
                    Table_Layout
                )
            )
        )
    )
)
(Layout Table_Layout
    (Components)
    (Resources
        (.AttachLeft True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 10)
        (.BottomOffset 5)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Rows 18)
        (.Columns 42)
        (.AttachRight True)
        (.Layout
            (Grid
                (Rows 1)
                (Cols 1)
            )
        )
    )
)
(Layout Layout3
    (Components
        (PushButton Ok_pb)
        (PushButton Cancel_pb)
    )
    (Resources
        (Ok_pb.Label "OK")
        (Ok_pb.TopOffset 5)
        (Ok_pb.BottomOffset 5)
        (Ok_pb.LeftOffset 5)
        (Ok_pb.RightOffset 5)
        (Ok_pb.AttachRight True)
        (Ok_pb.BackgroundColor 12)
        (Cancel_pb.Label "Cancel")
        (Cancel_pb.AttachRight True)
        (Cancel_pb.TopOffset 5)
        (Cancel_pb.BottomOffset 5)
        (Cancel_pb.LeftOffset 0)
        (Cancel_pb.RightOffset 5)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 5)
        (.BottomOffset 0)
        (.LeftOffset 5)
        (.RightOffset 0)
        (.Layout
            (Grid
                (Rows 1)
                (Cols 1 0 0)
                Ok_pb
                (Pos 1 3)
                Cancel_pb
            )
        )
    )
)
