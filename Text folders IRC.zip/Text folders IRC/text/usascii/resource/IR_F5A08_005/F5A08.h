/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	|	V1_0_0		| F5A08 - BRAKING SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF5A08_H
#define IRF5A08_H

#include "InterfaceRule.h"

class IRF5A08 : private InterfaceRule
{
public:
	// CTOR
	IRF5A08() = default;

	// METHODS
	int IRF5A08_005(ruleResult& final_res);
};

ProError ruleDlgOKactionf5a08005(char* dialog, char* component, ProAppData data);
int createDatumPointsF5A08005(Pro3dPnt pnt_arr[2], char* csysName);
ProError deleteDatumPointF5A08005(char* dtmpoint_name);
string doubleToStringf5a08005(double value);
void Clear_Memory_F5A08005();
#endif