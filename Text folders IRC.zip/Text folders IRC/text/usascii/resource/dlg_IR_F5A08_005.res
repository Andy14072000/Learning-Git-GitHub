(Dialog dlg_IR_F5A08_005
    (Components
        (SubLayout Content)
        (Separator CommitSeparator)
        (PushButton rule_ok_pb)
        (PushButton rule_cancel_pb)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (rule_ok_pb.Label "OK")
        (rule_ok_pb.TopOffset 5)
        (rule_ok_pb.BottomOffset 10)
        (rule_ok_pb.LeftOffset 40)
        (rule_ok_pb.RightOffset 0)
        (rule_ok_pb.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:Label,TopOffset")
        (rule_cancel_pb.Label "Cancel")
        (rule_cancel_pb.TopOffset 5)
        (rule_cancel_pb.BottomOffset 10)
        (rule_cancel_pb.LeftOffset 8)
        (rule_cancel_pb.RightOffset 10)
        (rule_cancel_pb.ResourceHints "Template:OKCancelDialog.CommitCancel" "UserOverrideAttrs:TopOffset")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "rule_ok_pb")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.AttachLeft True)
        (.Label "IR-F5A08-005")
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                Content CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    rule_ok_pb
                    (Pos 1 3)
                    rule_cancel_pb
                )
            )
        )
    )
)
(Layout Content
    (Components
        (Label lbl_1)
        (SubLayout Layout1)
        (Label lbl_2)
    )
    (Resources
        (lbl_1.Label "Clearance between Brake valve and Steering system.")
        (lbl_1.AttachLeft True)
        (lbl_1.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_1.TopOffset 5)
        (lbl_1.BottomOffset 5)
        (lbl_1.LeftOffset 5)
        (lbl_1.RightOffset 5)
        (lbl_1.Alignment 0)
        (lbl_2.Label "Please note that this may take a moment to compute distances between the components.

Click OK to proceed.")
        (lbl_2.AttachLeft True)
        (lbl_2.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_2.TopOffset 5)
        (lbl_2.BottomOffset 5)
        (lbl_2.LeftOffset 5)
        (lbl_2.RightOffset 5)
        (lbl_2.Alignment 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 5)
        (.BottomOffset 5)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content" "UserOverrideAttrs:TopOffset,BottomOffset")
        (.AttachBottom True)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 1 0 0)
                (Cols 0)
                lbl_1
                (Pos 3 1)
                Layout1
                (Pos 4 1)
                lbl_2
            )
        )
    )
)
(Layout Layout1
    (Components
        (PushButton pb_img)
    )
    (Resources
        (pb_img.Bitmap "IR_F5A08_005/IR_F5A08_005.png")
        (pb_img.Columns 2)
        (pb_img.ButtonStyle 2)
        (pb_img.AttachLeft True)
        (pb_img.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset")
        (pb_img.TopOffset 5)
        (pb_img.BottomOffset 5)
        (pb_img.LeftOffset 5)
        (pb_img.RightOffset 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 6)
        (.BottomOffset 2)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                pb_img
            )
        )
    )
)
