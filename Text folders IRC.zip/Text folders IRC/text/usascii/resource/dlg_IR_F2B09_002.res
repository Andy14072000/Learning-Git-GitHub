(Dialog dlg_IR_F2B09_002
    (Components
        (SubLayout Content)
        (Separator CommitSeparator)
        (PushButton rule_ok_pb)
        (PushButton rule_cancel_pb)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (rule_ok_pb.Label "OK")
        (rule_ok_pb.TopOffset 10)
        (rule_ok_pb.BottomOffset 10)
        (rule_ok_pb.LeftOffset 40)
        (rule_ok_pb.RightOffset 0)
        (rule_ok_pb.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:Label,TopOffset")
        (rule_ok_pb.Sensitive False)
        (rule_cancel_pb.Label "Cancel")
        (rule_cancel_pb.TopOffset 10)
        (rule_cancel_pb.BottomOffset 10)
        (rule_cancel_pb.LeftOffset 8)
        (rule_cancel_pb.RightOffset 10)
        (rule_cancel_pb.ResourceHints "Template:OKCancelDialog.CommitCancel" "UserOverrideAttrs:TopOffset")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "rule_ok_pb")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.AttachLeft True)
        (.Label "IR-F2B09-002")
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                Content CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    rule_ok_pb
                    (Pos 1 3)
                    rule_cancel_pb
                )
            )
        )
    )
)
(Layout Content
    (Components
        (SubLayout Layout2)
        (SubLayout Layout1)
        (SubLayout Layout3_copy)
        (SubLayout Layout4)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 16)
        (.BottomOffset 16)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content" "UserOverrideAttrs:TopOffset,BottomOffset")
        (.AttachBottom True)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 0 1 0 0)
                (Cols 0)
                Layout2 Layout1
                (Pos 4 1)
                Layout3_copy
                (Pos 5 1)
                Layout4
            )
        )
    )
)
(Layout Layout2
    (Components
        (Label lbl_1)
    )
    (Resources
        (lbl_1.Label "Ensure clearance between Steering piping+ Rubber hose & Frame >10mm
in nominal conditions. Reduction to 5mm with positive clamping. Contact 
is allowed if pipe protection is provided
")
        (lbl_1.AttachLeft True)
        (lbl_1.ResourceHints "UserOverrideAttrs:AttachLeft,TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_1.TopOffset 5)
        (lbl_1.BottomOffset 5)
        (lbl_1.LeftOffset 5)
        (lbl_1.RightOffset 5)
        (lbl_1.Alignment 0)
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,LeftOffset,RightOffset")
        (.TopOffset 7)
        (.BottomOffset 3)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Label "Description")
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                lbl_1
            )
        )
    )
)
(Layout Layout1
    (Components
        (SubLayout Layout5)
        (SubLayout Layout3)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 10)
        (.BottomOffset 5)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.ResourceHints "UserOverrideAttrs:AttachLeft,AttachRight,TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.Layout
            (Grid
                (Rows 0 0)
                (Cols 0)
                Layout5 Layout3
            )
        )
    )
)
(Layout Layout5
    (Components
        (PushButton pb_img)
    )
    (Resources
        (pb_img.Bitmap "IR-F2B09-002\IR-F2B09-002.png")
        (pb_img.ButtonStyle 2)
        (pb_img.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset,AttachLeft")
        (pb_img.TopOffset 0)
        (pb_img.BottomOffset 0)
        (pb_img.LeftOffset 0)
        (pb_img.RightOffset 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 3)
        (.BottomOffset 2)
        (.LeftOffset 2)
        (.RightOffset 2)
        (.Alignment 2)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                pb_img
            )
        )
    )
)
(Layout Layout3
    (Components
        (Label Label1)
    )
    (Resources
        (Label1.Label "Note: The image is just for reference, It might differ in your case.")
        (Label1.AttachLeft True)
        (Label1.ResourceHints "UserOverrideAttrs:TopOffset")
        (Label1.TopOffset 5)
        (Label1.BottomOffset 0)
        (Label1.LeftOffset 0)
        (Label1.RightOffset 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 3)
        (.BottomOffset 3)
        (.LeftOffset 3)
        (.RightOffset 3)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                Label1
            )
        )
    )
)
(Layout Layout3_copy
    (Components
        (Label select_info_lbl_copy)
        (PushButton Measure)
    )
    (Resources
        (select_info_lbl_copy.AttachLeft True)
        (select_info_lbl_copy.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (select_info_lbl_copy.TopOffset 5)
        (select_info_lbl_copy.BottomOffset 5)
        (select_info_lbl_copy.LeftOffset 5)
        (select_info_lbl_copy.RightOffset 5)
        (select_info_lbl_copy.Alignment 0)
        (select_info_lbl_copy.Label "Click on Measure")
        (Measure.Label "Measure")
        (Measure.AttachLeft True)
        (Measure.TopOffset 10)
        (Measure.BottomOffset 5)
        (Measure.LeftOffset 5)
        (Measure.RightOffset 5)
        (Measure.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 10)
        (.BottomOffset 5)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Decorated 1)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0 0)
                select_info_lbl_copy Measure
            )
        )
    )
)
(Layout Layout4
    (Components
        (Label lbl_2)
    )
    (Resources
        (lbl_2.Label "Click OK to validate.")
        (lbl_2.AttachLeft True)
        (lbl_2.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (lbl_2.TopOffset 5)
        (lbl_2.BottomOffset 5)
        (lbl_2.LeftOffset 2)
        (lbl_2.RightOffset 2)
        (lbl_2.Alignment 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 1)
        (.BottomOffset 3)
        (.LeftOffset 7)
        (.RightOffset 7)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                lbl_2
            )
        )
    )
)
