(Dialog dlg_IR_F3B04_001
    (Components
        (SubLayout Content)
        (Separator CommitSeparator)
        (PushButton CommitOK)
        (PushButton rule_cancel_pb)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (CommitOK.Label "OK")
        (CommitOK.TopOffset 10)
        (CommitOK.BottomOffset 10)
        (CommitOK.LeftOffset 40)
        (CommitOK.RightOffset 0)
        (CommitOK.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:Label")
        (rule_cancel_pb.Label "Cancel")
        (rule_cancel_pb.TopOffset 10)
        (rule_cancel_pb.BottomOffset 10)
        (rule_cancel_pb.LeftOffset 8)
        (rule_cancel_pb.RightOffset 10)
        (rule_cancel_pb.ResourceHints "Template:OKCancelDialog.CommitCancel")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "CommitOK")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.Label "IR-F3B04-001")
        (.AttachLeft True)
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                Content CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    CommitOK
                    (Pos 1 3)
                    rule_cancel_pb
                )
            )
        )
    )
)
(Layout Content
    (Components
        (SubLayout description_layout)
        (SubLayout main_layout)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 16)
        (.BottomOffset 16)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content")
        (.AttachBottom True)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 1)
                (Cols 1)
                description_layout main_layout
            )
        )
    )
)
(Layout description_layout
    (Components
        (Label desc_lbl)
    )
    (Resources
        (desc_lbl.Label "Use of Gasket based on the emmission regulatory requirement.
")
        (desc_lbl.AttachLeft True)
        (desc_lbl.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (desc_lbl.TopOffset 3)
        (desc_lbl.BottomOffset 1)
        (desc_lbl.LeftOffset 2)
        (desc_lbl.RightOffset 2)
        (desc_lbl.Alignment 0)
        (desc_lbl.Bitmap "UI small info image")
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,LeftOffset,RightOffset")
        (.TopOffset 10)
        (.BottomOffset 3)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                desc_lbl
            )
        )
    )
)
(Layout main_layout
    (Components
        (PushButton pb_image)
        (SubLayout selection_layout)
        (Label Label2)
    )
    (Resources
        (pb_image.Bitmap "IR_F3B04_001\IR_F3B04_001.png")
        (pb_image.ButtonStyle 2)
        (pb_image.AttachLeft True)
        (pb_image.TopOffset 0)
        (pb_image.BottomOffset 3)
        (pb_image.LeftOffset 0)
        (pb_image.RightOffset 0)
        (Label2.Label "Click OK to check if Gaskets are used based on emmision regulatory requirement.")
        (Label2.AttachLeft True)
        (Label2.TopOffset 3)
        (Label2.BottomOffset 0)
        (Label2.LeftOffset 0)
        (Label2.RightOffset 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 2)
        (.BottomOffset 0)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0 0 1 0)
                (Cols 1)
                pb_image selection_layout
                (Pos 4 1)
                (Grid
                    (Rows 0)
                    (Cols 0)
                    Label2
                )
            )
        )
    )
)
(Layout selection_layout
    (Components
        (Label Label1)
        (OptionMenu emission_norm_dd)
    )
    (Resources
        (Label1.Label "Select Emission Norm ")
        (Label1.AttachLeft True)
        (Label1.TopOffset 0)
        (Label1.BottomOffset 0)
        (Label1.LeftOffset 0)
        (Label1.RightOffset 4)
        (emission_norm_dd.TopOffset 0)
        (emission_norm_dd.BottomOffset 0)
        (emission_norm_dd.LeftOffset 3)
        (emission_norm_dd.RightOffset 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 0)
        (.BottomOffset 5)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 1)
                (Grid
                    (Rows 0)
                    (Cols 0 1)
                    Label1 emission_norm_dd
                )
            )
        )
    )
)
