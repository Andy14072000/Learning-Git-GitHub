(Dialog Clamp_Selection_tble_f1c02_006
    (Components
        (Separator Separator1)
        (SubLayout Layout3)
        (SubLayout Table_Layout)
    )
    (Resources
        (.ResourceHints "Version:Creo4")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.Label "Clamps and Brackets Identified in the Assembly")
        (.StartLocation 6)
        (.MinimizeButton True)
        (.Focus "Ok_pb")
        (.MaximizeButton True)
        (.DefaultButton "Ok_pb")
        (.Layout
            (Grid
                (Rows 1 0)
                (Cols 1)
                (Grid
                    (Rows 1)
                    (Cols 1)
                    Table_Layout
                )
                (Grid
                    (Rows 0 1)
                    (Cols 1)
                    Separator1 Layout3
                )
            )
        )
    )
)
(Layout Layout3
    (Components
        (PushButton Ok_pb)
        (PushButton Cancel_pb)
    )
    (Resources
        (Ok_pb.Label "OK")
        (Ok_pb.TopOffset 5)
        (Ok_pb.BottomOffset 5)
        (Ok_pb.LeftOffset 5)
        (Ok_pb.RightOffset 5)
        (Ok_pb.AttachRight True)
        (Ok_pb.BackgroundColor 12)
        (Cancel_pb.Label "Cancel")
        (Cancel_pb.AttachRight True)
        (Cancel_pb.TopOffset 5)
        (Cancel_pb.BottomOffset 5)
        (Cancel_pb.LeftOffset 0)
        (Cancel_pb.RightOffset 5)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 5)
        (.BottomOffset 0)
        (.LeftOffset 5)
        (.RightOffset 0)
        (.Layout
            (Grid
                (Rows 1)
                (Cols 1 0 0)
                Ok_pb
                (Pos 1 3)
                Cancel_pb
            )
        )
    )
)
(Layout Table_Layout
    (Components)
    (Resources
        (.AttachLeft True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 5)
        (.BottomOffset 5)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Rows 20)
        (.Columns 54)
        (.AttachRight True)
        (.Layout
            (Grid
                (Rows 1)
                (Cols 1)
            )
        )
    )
)
