(Dialog dlg_IR_A1A01_007
    (Components
        (SubLayout Content)
        (Separator CommitSeparator)
        (PushButton rule_run_pb)
        (PushButton rule_cancel_pb)
    )
    (Resources
        (CommitSeparator.ResourceHints "Template:OKCancelDialog.CommitSeparator")
        (rule_run_pb.Label "RUN")
        (rule_run_pb.TopOffset 10)
        (rule_run_pb.BottomOffset 10)
        (rule_run_pb.LeftOffset 40)
        (rule_run_pb.RightOffset 0)
        (rule_run_pb.ResourceHints "Template:OKCancelDialog.CommitOK" "UserOverrideAttrs:Label,TopOffset")
        (rule_cancel_pb.Label "Cancel")
        (rule_cancel_pb.TopOffset 10)
        (rule_cancel_pb.BottomOffset 10)
        (rule_cancel_pb.LeftOffset 8)
        (rule_cancel_pb.RightOffset 10)
        (rule_cancel_pb.ResourceHints "Template:OKCancelDialog.CommitCancel" "UserOverrideAttrs:TopOffset")
        (.TopOffset 0)
        (.BottomOffset 0)
        (.LeftOffset 0)
        (.RightOffset 0)
        (.DefaultButton "rule_run_pb")
        (.ResourceHints "Template:OKCancelDialog" "Guidelines:Creo4-Dialog" "GuidelinesVersion:2" "Version:Creo4" "@Subgrid0x2.Template:OKCancelDialog.CommitBar")
        (.Accelerator "Esc")
        (.AttachLeft True)
        (.Label "IR-A1A01-007")
        (.Layout
            (Grid
                (Rows 1 0 0)
                (Cols 1)
                Content CommitSeparator
                (Grid
                    (Rows 1)
                    (Cols 1 0 0)
                    (Pos 1 2)
                    rule_run_pb
                    (Pos 1 3)
                    rule_cancel_pb
                )
            )
        )
    )
)
(Layout Content
    (Components
        (SubLayout Desc_Layout)
        (SubLayout pb_Layout)
    )
    (Resources
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.TopOffset 10)
        (.BottomOffset 10)
        (.LeftOffset 10)
        (.RightOffset 10)
        (.ResourceHints "Template:OKCancelDialog.Content" "UserOverrideAttrs:TopOffset,BottomOffset")
        (.AttachBottom True)
        (.Decorated 1)
        (.Layout
            (Grid
                (Rows 0 1)
                (Cols 0)
                Desc_Layout pb_Layout
            )
        )
    )
)
(Layout Desc_Layout
    (Components
        (Label Description)
    )
    (Resources
        (Description.Label "Platform wise common sub frame start point.")
        (Description.AttachLeft True)
        (Description.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (Description.TopOffset 5)
        (Description.BottomOffset 5)
        (Description.LeftOffset 5)
        (Description.RightOffset 5)
        (Description.Alignment 0)
        (Description.Bitmap "UI ToolBar right image")
        (.Label "Rule Description")
        (.Decorated 1)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 10)
        (.BottomOffset 5)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                Description
            )
        )
    )
)
(Layout pb_Layout
    (Components
        (PushButton pb_img)
        (SubLayout OK_Label_Layout)
    )
    (Resources
        (pb_img.Bitmap "IR_A1A01_007/IR_A1A01_007.png")
        (pb_img.Columns 2)
        (pb_img.ButtonStyle 2)
        (pb_img.AttachLeft True)
        (pb_img.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (pb_img.TopOffset 10)
        (pb_img.BottomOffset 5)
        (pb_img.LeftOffset 7)
        (pb_img.RightOffset 7)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.TopOffset 5)
        (.BottomOffset 5)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Decorated 1)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.Layout
            (Grid
                (Rows 0 1 0)
                (Cols 0)
                pb_img
                (Pos 3 1)
                OK_Label_Layout
            )
        )
    )
)
(Layout OK_Label_Layout
    (Components
        (Label OK_Label)
    )
    (Resources
        (OK_Label.Label "Click 'RUN' to measure the distance from FACL to the SUBFRAME ASSY..")
        (OK_Label.AttachLeft True)
        (OK_Label.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (OK_Label.TopOffset 0)
        (OK_Label.BottomOffset 0)
        (OK_Label.LeftOffset 0)
        (OK_Label.RightOffset 0)
        (OK_Label.Alignment 0)
        (.AttachLeft True)
        (.AttachRight True)
        (.AttachTop True)
        (.AttachBottom True)
        (.ResourceHints "UserOverrideAttrs:TopOffset,BottomOffset,LeftOffset,RightOffset")
        (.TopOffset 5)
        (.BottomOffset 5)
        (.LeftOffset 5)
        (.RightOffset 5)
        (.Layout
            (Grid
                (Rows 0)
                (Cols 0)
                OK_Label
            )
        )
    )
)
