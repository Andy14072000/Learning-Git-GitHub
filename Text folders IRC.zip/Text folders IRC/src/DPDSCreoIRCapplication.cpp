/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-12-2021	| V1_0_0		| MAIN .CPP FILE
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

#include "DPDSCreoIRCapplication.h"
#include "AppFrontEnd.h"
//#include<DPDSCreoAppTracker.h>

// INITIALIZED WITH extern KEYWORD IN Main header
LogFile mainLog;
ProError status;
Utils _utils;
const char *PROE_TML_STD_PATH =  getenv("PROE_TML_STD_PATH");

FILE *fp1 = NULL;
extern "C" int user_initialize()
{
	ProError status;
	uiCmdCmdId cmd_id;
	fp1 = fopen("c:\\tmp\\DPDSCreoIRC.log", "w");
	fflush(fp1);

	status = ProCmdActionAdd ("DPDS_IRC_APP", (uiCmdCmdActFn)callApplication, uiProeImmediate, TestAccessDefault, PRO_B_TRUE, PRO_B_TRUE, &cmd_id);
	fprintf (fp1,"ProCmdActionAdd = %d \n", status);
	fflush(fp1);

	//---------------------------- Icon Setting ----------------------------//
	status = ProCmdIconSet(cmd_id, "irc.png");
	fprintf (fp1,"ProCmdIconSet = %d \n", status);
	fflush(fp1);

	status = ProCmdDesignate(cmd_id, "InterfaceRulesCheck label", "InterfaceRulesCheck help", "InterfaceRulesCheck desc", L"uiMsg.txt");
	fprintf (fp1,"ProCmdDesignate = %d \n", status);
	fflush(fp1);

	status = Map_Log_Server(fp1);

	if(status !=0) return 0;

	fclose(fp1);
	return 0;
}

int callApplication()
{
	fprintf (fp1,"---------- callApplication ----------\n");
	fflush(fp1);

	// CREATE THE MAIN LOG FILE 
	mainLog.Start("C:\\tmp\\DPDSCreoIRCApp.log");
	// CREATE THE RULE LOG FILE 
	ruleLog.Start("C:\\tmp\\DPDSCreoIRCrules.log");


	bool IsOk = GetTrackingInfo(enm_App_DPDSIRCApp, enm_subApp_Interface_Rule_Check, enm_Appstatus_Clicked);
	if (!IsOk)
	{
		status = NotifyUserForTracking();
		return status;
	}

	AppFrontEnd _appFrontEnd;
	_appFrontEnd.initialize();

	IsOk = GetTrackingInfo(enm_App_DPDSIRCApp, enm_subApp_Interface_Rule_Check, enm_Appstatus_Executed);
	if (!IsOk)
	{
		status = NotifyUserForTracking();
		return status;
	}

	return 0;
}

static uiCmdAccessState TestAccessDefault(uiCmdAccessMode access_mode)
{
	return (ACCESS_AVAILABLE);
}

extern "C" int user_terminate()
{

	return 0;
}

static void executeCommandSilently(const std::string& command) {

	STARTUPINFO				si;
	PROCESS_INFORMATION		pi;

	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	si.dwFlags = STARTF_USESHOWWINDOW;
	si.wShowWindow = SW_HIDE; // Hide the window

	ZeroMemory(&pi, sizeof(pi));

	// Start the child process
	if (!CreateProcess(nullptr, const_cast<char*>(command.c_str()), nullptr, nullptr, FALSE, 0, nullptr, nullptr, &si, &pi)) {

	}
	else {

		// Wait until child process exits.
		WaitForSingleObject(pi.hProcess, INFINITE);

		// Close process and thread handles.
		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);

	}

}

ProError Map_Log_Server(FILE* fp) {

	ProError status;

	fprintf(fp, "Inside : Map_Log_Server\n");
	fflush(fp);

	std::string networkPath = "\\\\172.22.99.22\\startparttemplate";
	std::string username = "ptcuser";
	std::string password = "ptcuser123";

	std::string netCommand = "net use " + networkPath + " " + password + " /user:" + username;

	fprintf(fp, " netCommand = %s \n", netCommand.c_str());
	fflush(fp);

	executeCommandSilently(netCommand);

	return PRO_TK_NO_ERROR;

}

#pragma warning(pop)