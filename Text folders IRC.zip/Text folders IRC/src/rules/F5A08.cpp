﻿/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	|	V1_0_0		| F5A08 - BRAKING SYSTEM RULES
==================================================================================================================*/
#include "F5A08.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5A08005		| Pallavi Garodi	| MF5A08; MF2B01	| Clearance of brake valve & steering system to be defined.
===================================================================================================================*/
#define DLG_IRF5A08_005 "dlg_IR_F5A08_005"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"
#define PB_RCLOSE		"CommitClose"



double standard_clearance_F5A08005 = 50.00;
double measured_clearance_F5A08005;
//double toleranceF5A10001 = 0.001;
vector<int>ID_mapf5a08005;
string remF5A08005 = "";
int tarrayf5a08005[100] = { 0 }; // Initialize all elements to 0 (or any default value)
vector<Model_Tree_Information> treeInformationVectorf5a08005;
vector<Model_Tree_Information> selection_items_F5A08005;

int IRF5A08::IRF5A08_005(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF5A10::IRF5A08_005   ==========================");

    deleteDatumPoint("datum_PNT1");
    deleteDatumPoint("datum_PNT2");
    Clear_Memory_F5A08005();

    //remF5A10001.append("Distance measured from Electronic Brake Valve to propeller shaft is: \n\n");

    status = ProUIDialogCreate(DLG_IRF5A08_005, DLG_IRF5A08_005);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF5A08_005, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A08_005, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A08_005, PB_ROK, (ProUIAction)ruleDlgOKactionf5a08005, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF5A08_005, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF5A08_005);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;


    //selection_items_F5A10001[2].dist_chk = FALSE;

    /*for (int i = 1; i < selection_items_F5A10001.size(); i++)
    {
        ruleLog.Write("Name: " + selection_items_F5A10001[i].name + " Description: " + selection_items_F5A10001[i].description + " Distance " + to_string(selection_items_F5A10001[i].distance) + "mm [" + to_string(selection_items_F5A10001[i].dist_chk) + "] ID Path:");
        for (int id : selection_items_F5A10001[i].ID_path)
        {
            ruleLog.Write(to_string(id));
        }
    }*/

    isRightValue = FALSE;
    if (measured_clearance_F5A08005 >= standard_clearance_F5A08005)
    {
        isRightValue = TRUE;
    }


    remF5A08005.append("Measured distance between " + selection_items_F5A08005[0].name + ".asm [" + selection_items_F5A08005[0].description + "] \n");
    remF5A08005.append("and " + selection_items_F5A08005[1].name + ".asm [" + selection_items_F5A08005[1].description + "] is " + doubleToString(measured_clearance_F5A08005) + "mm.\n\n");

    /*
    * selection_items_F5A10001[0].name
    * selection_items_F5A10001[0].description
    * selection_items_F5A10001[1].name
    * selection_items_F5A10001[1].description
    measured_clearance_F5A10001

    */
    remF5A08005.append("Acceptance criteria: Clearance of brake valve & steering system >= 50.00mm");

    final_res.remark = remF5A08005;

    // DECLARE RESULT
    if (isRightValue)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    return 0;
}

ProError UserAsmCompFilterf5a08005(ProFeature* feature, ProAppData app_data)
{
    ProError status;
    ProFeattype ftype;

    status = ProFeatureTypeGet(feature, &ftype);

    if (ftype == PRO_FEAT_COMPONENT)
        return(PRO_TK_NO_ERROR);
    return(PRO_TK_CONTINUE);
}

ProError user_actionf5a08005(ProFeature* feature, ProError status, ProAppData appdata)
{
    FILE* fp;
    int level;
    ProMdl mdl27;
    char name27[PRO_MDLNAME_SIZE];
    char type[PRO_MDLEXTENSION_SIZE];
    UserAppdata* appd, appd1;
    ProMdlName modelName;
    ProMdlExtension modelExtension;
    ProAsmcomppath comppath;
    ProModelitem modelItem;
    char existingPval[PRO_NAME_SIZE]{};

    //ProModelitem p_item27;
    ProIdTable table;
    //table[0] = -1;
    //int ID;

    appd = (UserAppdata*)appdata;
    fp = appd->fp;
    level = appd->level;

    status = ProAsmcompMdlGet(feature, &mdl27);
    status = ProMdlMdlnameGet(mdl27, modelName);
    status = ProMdlExtensionGet(mdl27, modelExtension);

    ProWstringToString(name27, modelName);
    ProWstringToString(type, modelExtension);

    //if (strncmp(type, "ASM", 3) == 0 || strncmp(type, "PRT", 3))
    //{
    ID_mapf5a08005.push_back(feature->id);
    //component_path.push_back(ID_mapf2c01004);

    appd1.fp = appd->fp;
    appd1.level = appd->level + 1;

    //numberofasm++;

    status = ProMdlToModelitem(mdl27, &modelItem);
    ruleLog.Write("ProMdlToModelitem: " + to_string(status));
    ProParameter pDesc;
    ProParamvalue pvDesc;
    ProName pDescName = L"DESCRIPTION";
    status = ProParameterInit(&modelItem, pDescName, &pDesc);
    ruleLog.Write("ProParameterInit: " + to_string(status));

    if (status == PRO_TK_NO_ERROR)
    {
        status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
        ProWstringToString(existingPval, pvDesc.value.s_val);
        Model_Tree_Information tree1;
        tree1.name = string(name27);
        tree1.extension = string(type);
        tree1.ID = feature->id;
        tree1.description = existingPval;
        tree1.ID_path = ID_mapf5a08005;
        tree1.ID_table_size = ID_mapf5a08005.size();

        treeInformationVectorf5a08005.push_back(tree1);
        ruleLog.Write("Name of assembly = " + string(name27) + " , ID = " + to_string(feature->id) + " , Description = " + existingPval);
        for (int id : tree1.ID_path)
        {
            ruleLog.Write(to_string(id) + " ");
        }
    }

    status = ProSolidFeatVisit((ProSolid)mdl27, user_actionf5a08005, UserAsmCompFilterf5a08005, &appd1);
    ID_mapf5a08005.pop_back();
    //}
    return(PRO_TK_CONTINUE);
}

ProError ruleDlgOKactionf5a08005(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgOKaction -----------------------------");

    char name[PRO_MDLNAME_SIZE];
    char type[PRO_MDLEXTENSION_SIZE];
    ProError status;
    UserAppdata appdata;
    FILE* fp{};
    ProMdl p_asm;
    ProMdl reqMdlsair1hs, mdl;
    ProMdlName modelName;
    ProMdlExtension modelExtension;
    //double distance;
    int count = -1;
    Pro3dPnt pnt_arr[2];
    //int ex, tail, sil;
    InterfaceRule     _irule;
    int				  rule_sts;

    status = ProMdlCurrentGet(&p_asm);
    status = ProMdlMdlnameGet(p_asm, modelName);
    ProWstringToString(name, modelName);
    status = ProMdlExtensionGet(p_asm, modelExtension);
    ProWstringToString(type, modelExtension);

    appdata.fp = fp;
    appdata.level = 1;

    status = ProSolidFeatVisit((ProSolid)p_asm, user_actionf5a08005, UserAsmCompFilterf5a08005, &appdata);


    for (int i = 0; i < treeInformationVectorf5a08005.size(); i++)
    {
        if (treeInformationVectorf5a08005[i].name.find("F5A08") != std::string::npos)
        {
            selection_items_F5A08005.push_back(treeInformationVectorf5a08005[i]);
        }
    }

    for (int i = 0; i < treeInformationVectorf5a08005.size(); i++)
    {
        if (treeInformationVectorf5a08005[i].name.find("F2B01") != std::string::npos)
        {
            selection_items_F5A08005.push_back(treeInformationVectorf5a08005[i]);
        }
    }
    for (int i = 0; i < selection_items_F5A08005.size(); i++)
    {
        ruleLog.Write("Sub-Module: " + selection_items_F5A08005[i].sub_mod_name + "Name: " + selection_items_F5A08005[i].name + " ID: " + to_string(selection_items_F5A08005[i].ID) + " Description: " + selection_items_F5A08005[i].description + " ID Path:");
        for (int id : selection_items_F5A08005[i].ID_path)
        {
            ruleLog.Write(to_string(id));
        }
    }

    //Set Selections
    for (int i = 0; i < selection_items_F5A08005.size(); i++)
    {
        ProIdTable id_table{};
        ProMdl reqMdlsair;
        ProName compair;
        ProModelitem featureair;
        // Create a character array with a size one larger than the string to accommodate the null terminator
        char charArray[100];

        // Copy the contents of the std::string to the character array
        strcpy(charArray, selection_items_F5A08005[i].name.c_str());
        ProStringToWstring(compair, charArray);

        status = ProMdlnameInit(compair, PRO_MDLFILE_ASSEMBLY, &reqMdlsair);
        ruleLog.Write("ProMdlnameInit status = " + to_string(status));

        status = ProMdlToModelitem(reqMdlsair, &featureair);
        ruleLog.Write("ProMdlToModelitem status = " + to_string(status));

        vector temp = selection_items_F5A08005[i].ID_path;
        int vectorSize = selection_items_F5A08005[i].ID_path.size();
        //tbl1_sizef5a27006 = vectorSize;

        for (int j = 0; j < vectorSize; ++j)
        {
            tarrayf5a08005[j] = temp[j];
        }

        // Print the elements in the array
        //std::cout << "Array elements:";

        for (int j = 0; j < vectorSize; ++j)
        {
            id_table[j] = tarrayf5a08005[j];
        }

        ProAsmcomppath pathair;
        ProSelection sel;
        status = ProAsmcomppathInit((ProSolid)curMdl, id_table, vectorSize, &pathair);
        ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));

        status = ProSelectionAlloc(&pathair, &featureair, &sel);
        ruleLog.Write("ProSelectionAlloc status = " + to_string(status));

        selection_items_F5A08005[i].sela = sel;
        /*status = ProSelectionHighlight(selection_items_F5A10001[i].sela, PRO_COLOR_HIGHLITE);
        ruleLog.Write("ProSelectionHighlight status = " + to_string(status));*/
    }

    double distance;
    /*  ProBoolean is_interference_found;
      status = ProFitClearanceCompute(selection_items_F5A08005[0].sela, PRO_FIT_INCLUDE_NONE, selection_items_F5A08005[1].sela, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, selection_items_F5A08005[1].sela, PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
      ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));
      measured_clearance_F5A08005 = distance;
      createDatumPointsF5A08005(pnt_arr, "CSYS_ASM_DEF");*/

    rule_sts = _irule.measureDistanceBetweenSurfaces(selection_items_F5A08005[0].sela, selection_items_F5A08005[1].sela, distance);
    ruleLog.Write("measureDistanceBetweenSurfaces = " + to_string(rule_sts));
    measured_clearance_F5A08005 = distance;

    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return PRO_TK_NO_ERROR;
}

int createDatumPointsF5A08005(Pro3dPnt pnt_arr[2], char* csysName)
{

    ruleLog.Write("=================> InterfaceRule::createDatumPoints <=================");
    ProElement  elem_tree, elem_ftype, elem_feature_name,
        pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
        pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
        pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
    ProReference REPDEP_ref1;
    wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wide_string[PRO_NAME_SIZE], wide_string_2[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE];
    //CSYS_ASM_DEF
    ProModelitem refCsysitem;
    ProSelection refCsysSel, reqMdlSel;
    ProFeatureCreateOptions* opts = 0;
    ProFeature pnt_feat;
    ProErrorlist errors;
    //converting negative values to positive
    double d1 = -pnt_arr[0][2];
    double d2 = -pnt_arr[1][2];
    char cDatumPointName[PRO_NAME_SIZE] = "Dist_highlght_pnt";

    ProStringToWstring(wCsysName, csysName);
    status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
    status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);


    //Create Element Tree
    status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
    ruleLog.Write("Tree root status = " + to_string(status));

    // TREE ALLOCATION
    status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
    ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
    ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
    ruleLog.Write("type status = " + to_string(status));

    //feature name
    status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
    status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, cDatumPointName));
    status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
    ruleLog.Write("feature name = " + to_string(status));

    //PRO_E_DPOINT_TYPE
    status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
    status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
    ruleLog.Write("type status = " + to_string(status));

    //Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);

    //ref
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
    status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
    status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);

    //
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);

    //Populating array element
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);

    //Point1
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);

    //Point1 Name
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
    ProStringToWstring(wide_string, "datum_PNT1");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);

    //PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);

    //PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);

    //PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);

    //Point2
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);

    //Point2 Name
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
    ProStringToWstring(wide_string_2, "datum_PNT2");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);

    ////PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);

    ////PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);

    ////PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);

    /* =============================================================== *\
    Create Model Selection Object
    \* =============================================================== */

    status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
    ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
    status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

    opts[0] = PRO_FEAT_CR_NO_OPTS;

    // Create Points
    status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
    ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

    status = ProArrayFree((ProArray*)&opts);
    status = ProElementFree(&elem_tree);
    status = ProSelectionFree(&reqMdlSel);

    ProSelection pnt_Sel;
    status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
    status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_ERROR);
    //PRO_COLOR_SELECTED for green highlight
    return 0;
}

void Clear_Memory_F5A08005()
{
    treeInformationVectorf5a08005.clear();
    selection_items_F5A08005.clear();
    ID_mapf5a08005.clear();
    remF5A08005.clear();
}

/*================================================================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	                                        | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5A08007		| Prajakta Bhelawe	| MF5A08; MF1E01; MD1A05; MD1A06; MF5A20; MF5A21; MF1E04	| Type of Brake Booster to be selection based on system requirement.
==================================================================================================================================================================*/
#define DLG_F5A08_007   "dlg_IR_F5A08_007"
#define rule_cancel_pb  "rule_cancel_pb"
#define rule_ok_pb      "rule_ok_pb"
#define OptionMenu1	    "OptionMenu1"
#define OptionMenu2	    "OptionMenu2"


int							n_selSF5A08;
char**						selValue2F5A08, **selValueF5A08, **boosterNamesF5A08;
boolean						isDescMatchF5A08;
wchar_t**					boosterLabelsF5A08;
vector<string>				boosterTypeF5A08,tonnageF5A08{ "Select", "0-7T", "7.5T-55T", "10.5T-55T" };
vector<PartnameDescriptionPair> reqComp;
string boosterType1;


int IRF5A08::IRF5A08_007(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5A08::IRF5A08_007   ==========================");

	final_res.result = "FAIL";
	reqComp.clear();
	//final_res.result.clear();
	final_res.remark.clear();

	string				rem_message;
	char** tonnageNames;
	wchar_t** tonnageLabels;

	//rem_message.clear();

	// find the sub-module info
	for (int i = 0; i < subModulesList.size(); ++i) {
		if (subModulesList[i].name.find("F5A08") != string::npos) {
			status = ProSolidFeatVisit((ProSolid)curMdl, searchInDescF5A08, compsFilter, (ProAppData)&reqComp);
			ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
		}
	}

	for (int i = 0; i < reqComp.size(); i++)
	{
		ruleLog.Write("item.description : " + string(reqComp.at(i).description));
		ruleLog.Write("item.Name : " + string(reqComp.at(i).part_name));
	}

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_F5A08_007, DLG_F5A08_007);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_F5A08_007, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F5A08_007, rule_cancel_pb, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F5A08_007, rule_ok_pb, (ProUIAction)ruleDlgOKaction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIOptionmenuSelectActionSet(DLG_F5A08_007, OptionMenu1, (ProUIAction)optionMenu1DropDownActionF5A08, NULL);
	status = ProUIOptionmenuSelectActionSet(DLG_F5A08_007, OptionMenu2, (ProUIAction)optionMenu2DropDownActionF5A08, NULL);
	ruleLog.Write("ProUIOptionmenuSelectActionSet: " + to_string(status));

	status = ProArrayAlloc(tonnageF5A08.size(), sizeof(char*), 50, (ProArray*)&tonnageNames);
	ruleLog.Write("ProArrayAlloc1: " + to_string(status));
	status = ProArrayAlloc(tonnageF5A08.size(), sizeof(wchar_t*), 50, (ProArray*)&tonnageLabels);
	ruleLog.Write("ProArrayAlloc2: " + to_string(status));

	for (int i = 0; i < tonnageF5A08.size(); ++i)
	{
		tonnageNames[i] = (char*)calloc(50, sizeof(char));
		ProTKSprintf(tonnageNames[i], "%s", tonnageF5A08[i]);
		ruleLog.Write("size = " + to_string(tonnageF5A08.size()));
		ruleLog.Write("i = " + to_string(i));
		ruleLog.Write("tonnage = " + tonnageF5A08[i]);
		ruleLog.Write("tonnageNames SET: ");

		tonnageLabels[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
		ProStringToWstring(tonnageLabels[i], tonnageNames[i]);
		ruleLog.Write("tonnageLabels SET: ");
	}

	status = ProUIOptionmenuNamesSet(DLG_F5A08_007, OptionMenu1, int(tonnageF5A08.size()), tonnageNames);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(DLG_F5A08_007, OptionMenu1, int(tonnageF5A08.size()), tonnageLabels);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

	status = ProArrayFree((ProArray*)&tonnageNames);
	ruleLog.Write("ProArrayFree N" + to_string(status));
	status = ProArrayFree((ProArray*)&tonnageLabels);
	ruleLog.Write("ProArrayFree L" + to_string(status));

	status = ProUIDialogActivate(DLG_F5A08_007, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_F5A08_007);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogShow: " + to_string(status));

	// check for user quits in close_action
	if (isUserQuits)
		return -1;

	//DECLARE RESULT
	if (isDescMatchF5A08 == true)
	{
		final_res.result = "PASS";
		rem_message += "Selected tonnage capacity:- " + string(selValueF5A08[0]);
		rem_message += " \nSelected Booster Type: ";
		rem_message += string(boosterType1);
		rem_message += "\n";
		/*if (selValueF5A08[0] == "0-7T") {
			rem_message += " (Hydraulic Brake)";
		}
		else
			rem_message += " (Air Brake)";*/

			//rem_message += "\nSelected Booster type:- " + string(selValue2F5A08[0]);


		rem_message += "\nBooster type present in assembly: ";
		rem_message += "\n";
		for (int i = 0; i < reqComp.size(); i++)
		{
			rem_message += to_string(i + 1) + ")" + string(reqComp.at(i).description) + " (" + string(reqComp.at(i).part_name) + ".PRT), ";

		}


	}

	else if (isDescMatchF5A08 == false)
	{
		final_res.result = "FAIL";
		rem_message += "Selected tonnage capacity:- " + string(selValueF5A08[0]);
		rem_message += " \nSelected Booster Type: ";
		rem_message += string(selValue2F5A08[0]);
		/*if (selValueF5A08[0] == "0-7T" || selValueF5A08[0] == "7.5T-55T") {
			rem_message += " (Hydraulic Brake)";
		}
		else
			rem_message += " (Air Brake)";*/

			//rem_message += "\nSelected Booster type:- " + string(selValue2F5A08[0]);
		rem_message += "\n";
		rem_message += "\nBooster type present in assembly: ";
		rem_message += "\n";
		for (int i = 0; i < reqComp.size(); i++)
		{
			rem_message += to_string(i + 1) + ")" + string(reqComp.at(i).description) + " (" + string(reqComp.at(i).part_name) + ".PRT), ";

		}
		/*rem_message += " \nAcceptance Criteria: " + string(selValue2F5A08[0]);*/

	}
	final_res.remark = rem_message;

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	reqComp.clear();
	rem_message.clear();

	return 0;
}

ProError optionMenu1DropDownActionF5A08(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- optionMenu1DropDownAction -----------------------------");

	string* reqData = (string*)data;
	//char           sel_PB[PRO_NAME_SIZE];


	status = ProUIOptionmenuSelectednamesGet(dialog, OptionMenu1, &n_selSF5A08, &selValueF5A08);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValueF5A08[0]));

	if (string(selValueF5A08[0]) == tonnageF5A08[1]) {
		boosterTypeF5A08 = { "VACUUM BOOSTER" };
		status = ProUIPushbuttonEnable(DLG_F5A08_007, OptionMenu2);
	}
	else if (string(selValueF5A08[0]) == tonnageF5A08[2]) {
		boosterTypeF5A08 = { "VACUUM BOOSTER", "UNI BOOSTER", "DBV" };
		status = ProUIPushbuttonEnable(DLG_F5A08_007, OptionMenu2);
	}
	else if (string(selValueF5A08[0]) == tonnageF5A08[3]) {
		boosterTypeF5A08 = { "DBV" };
		status = ProUIPushbuttonEnable(DLG_F5A08_007, OptionMenu2);
	}

	else if (string(selValueF5A08[0]) == tonnageF5A08[0]) {
		status = ProUIPushbuttonDisable(DLG_F5A08_007, OptionMenu2);
	}

	status = ProArrayAlloc(boosterTypeF5A08.size(), sizeof(char*), 150, (ProArray*)&boosterNamesF5A08);
	ruleLog.Write("ProArrayAlloc3: " + to_string(status));
	status = ProArrayAlloc(boosterTypeF5A08.size(), sizeof(wchar_t*), 150, (ProArray*)&boosterLabelsF5A08);
	ruleLog.Write("ProArrayAlloc4: " + to_string(status));

	for (int i = 0; i < boosterTypeF5A08.size(); ++i) {
		boosterNamesF5A08[i] = (char*)calloc(50, sizeof(char));
		ProTKSprintf(boosterNamesF5A08[i], "%s", boosterTypeF5A08[i]);

		boosterLabelsF5A08[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
		ProStringToWstring(boosterLabelsF5A08[i], boosterNamesF5A08[i]);
	}

	status = ProUIOptionmenuNamesSet(DLG_F5A08_007, OptionMenu2, int(boosterTypeF5A08.size()), boosterNamesF5A08);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(DLG_F5A08_007, OptionMenu2, int(boosterTypeF5A08.size()), boosterLabelsF5A08);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

	//status = ProUIPushbuttonEnable(DLG_F1E01_001, OptionMenu2);
	status = ProArrayFree((ProArray*)&boosterNamesF5A08);
	ruleLog.Write("ProArrayFree N" + to_string(status));
	status = ProArrayFree((ProArray*)&boosterLabelsF5A08);
	ruleLog.Write("ProArrayFree L" + to_string(status));

	return status;
}

ProError optionMenu2DropDownActionF5A08(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- optionMenu2DropDownAction -----------------------------");

	isDescMatchF5A08 = false;

	//status = ProUIOptionmenuSelectednamesSet(dialog, OptionMenu2, 1, charArray);

	status = ProUIOptionmenuSelectednamesGet(dialog, OptionMenu2, &n_selSF5A08, &selValue2F5A08);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue2F5A08[0]));

	status = ProUIPushbuttonEnable(DLG_F5A08_007, rule_ok_pb);

	string name = selValue2F5A08[0];

	if (name == "DBV")
	{
		string newArray[1] = { name };
		ruleLog.Write("Value in array = " + string(newArray[0]));

		newArray[0] = "DUAL BRAKE VALVE";
		boosterType1 = "DUAL BRAKE VALVE";
		ruleLog.Write("New Value in array = " + string(newArray[0]));

		for (int i = 0; i < reqComp.size(); i++)
		{
			if (string(reqComp.at(i).description) == newArray[0])
			{
				isDescMatchF5A08 = true;
			}
		}
	}

	if (name == "UNIBOOSTER")
	{
		string newArray[1] = { name };
		ruleLog.Write("Value in array = " + string(newArray[0]));

		newArray[0] = "UNIBOOSTER";
		boosterType1 = "UNIBOOSTER";
		ruleLog.Write("New Value in array = " + string(newArray[0]));

		for (int i = 0; i < reqComp.size(); i++)
		{
			if (string(reqComp.at(i).description) == newArray[0])
			{
				isDescMatchF5A08 = true;
			}
		}

	}

	if (name == "VACUUM BOOSTER")
	{
		string newArray[1] = { name };
		ruleLog.Write("Value in array = " + string(newArray[0]));

		newArray[0] = "VACUUM BOOSTER";
		boosterType1 = "VACUUM BOOSTER";
		ruleLog.Write("New Value in array = " + string(newArray[0]));

		for (int i = 0; i < reqComp.size(); i++)
		{
			if (string(reqComp.at(i).description) == newArray[0])
			{
				isDescMatchF5A08 = true;
			}
		}

	}

	for (int i = 0; i < reqComp.size(); i++)
	{
		if (string(reqComp.at(i).description) == name)
		{
			isDescMatchF5A08 = true;
		}
	}

	return status;
}

ProError searchInDescF5A08(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("----------------------------- getParameterDescAndPartname -----------------------------");

	vector<PartnameDescriptionPair>* prtname_desc_list = (vector<PartnameDescriptionPair>*)app_data;

	ProMdlType                subModuleMdlType;
	ProModelitem              modelItem;
	wchar_t                   wFeatName[PRO_NAME_SIZE];
	char                      cFeatName[PRO_NAME_SIZE];
	ProMdl                    reqMdl;
	char                      existingPval[PRO_NAME_SIZE]{};
	PartnameDescriptionPair   compd{};
	string                    description;

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	//ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
	status = ProMdlMdlnameGet(reqMdl, wFeatName);
	//ruleLog.Write("ProMdlMdlnameGet : " + to_string(status));
	status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
	//ruleLog.Write("ProMdlTypeGet : " + to_string(status));
	ProWstringToString(cFeatName, wFeatName);

	strcpy(compd.part_name, cFeatName);

	if (subModuleMdlType == PRO_MDL_ASSEMBLY)
	{
		//ruleLog.Write("Assembly Name: ");
		//ruleLog.Write(cFeatName);
		ProSolidFeatVisit((ProSolid)reqMdl, searchInDescF5A08, compsFilter, (ProAppData)app_data);
	}

	else if (subModuleMdlType == PRO_MDL_PART)
	{
		status = ProMdlToModelitem(reqMdl, &modelItem);
		//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		ProParameter pDesc;
		ProParamvalue pvDesc;
		ProName pDescName = L"DESCRIPTION";

		status = ProParameterInit(&modelItem, pDescName, &pDesc);
		//ruleLog.Write("ProParameterInit: " + to_string(status));

		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ProWstringToString(existingPval, pvDesc.value.s_val);
			description.append(existingPval);
			//ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);

			//Keywords for search in Description
			const regex a("(DUAL BRAKE VALVE)");
			const regex b("(VACUUM BOOSTER)");
			const regex c("(UNIBOOSTER)");

			//Patterns for Booster Type
			regex stringRegex("([A-Z]+ [A-Z]+ [A-Z]+)");
			regex stringRegex2("([A-Z]+ [A-Z]+)");

			smatch                    matchFound;
			string                    boosterType;
			string::const_iterator searchStart(description.cbegin());

			if ((regex_search(description, matchFound, a)) || (regex_search(description, matchFound, b)) || (regex_search(description, matchFound, c)))
			{
				if (regex_search(description, matchFound, stringRegex)) {
					boosterType = matchFound.str();
				}
				else (regex_search(description, matchFound, stringRegex2)); {
					boosterType = matchFound.str();
				}
				const char* charBoosterType = boosterType.c_str();
				strcpy(compd.description, charBoosterType);
				ruleLog.Write("compd.description: " + string(compd.description));
				ruleLog.Write("compd.part_name: " + string(compd.part_name));
				prtname_desc_list->push_back(compd);
			}
		}
	}
	return status;
}
#pragma pop