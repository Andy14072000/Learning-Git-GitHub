/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-03-2023	|	V1_0_0		| F2B06 - STEERING SYSTEM RULES
==================================================================================================================*/
#include "F2B06.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2B06003		| PRAJAKTA BHELAWE			| MF2B06;			| Ensure Pitman arm clearance in extreme travel with front mounted exhaust system > 20mm
===================================================================================================================*/
#define DLG_F2B06_003 "dlg_IR_F2B06_003"
#define PR_CANCEL        "CommitCancel" 
#define CommitOK         "CommitOK"
#define select_pb        "select_pb"

string steeringSysName;
vector<string> exhaustName;
ProSelection   selSteeringSys;
ProSelection selExhaust;
vector<ProSelection> selExhaustVector;

int IRF2B06::IRF2B06_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2B06::IRF2B06_003   ==========================");

	string remarkPt;
	double clearancePass = 0, clearanceFail = 0;

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_F2B06_003, DLG_F2B06_003);
	status = ProUIDialogAboveactivewindowSet(DLG_F2B06_003, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_F2B06_003, PR_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F2B06_003, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIPushbuttonDisable(DLG_F2B06_003, PB_RUN);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_F2B06_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_F2B06_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	ComponentData req_sub[10]{};
	string req_SubMod[6] = { "F2B06","F3B06","F3B05","F3B01","F3B03","F3B11" };

	for (int i = 0; i < subModulesList.size(); ++i)
	{
		for (int j = 0; j < 2; ++j)
		{
			if (subModulesList[j].name.find(req_SubMod[j]) != string::npos)
			{
				strcpy(req_sub[j].name, subModulesList[j].name.c_str());
				ruleLog.Write("req_sub[j].name = " + string(req_sub[i].name));
				break;
			}
		}
	}

	double clearance;
	ProBoolean is_interference_found = PRO_B_FALSE;
	Pro3dPnt coord[2];

	status = ProSolidFeatVisit((ProSolid)curMdl, user_action_F2B06_003, compsFilter, (ProAppData)&presentSubmodule);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

	remarkPt += "Clearance between Pitman arm and front mounted exhaust system ";

	ruleLog.Write("selExhaust.size() = " + to_string(selExhaustVector.size()));

	deleteDatumPoint("datum_PNT1");

	double minClearance = 0.0;
	int minClearanceIndex = -1;
	int minExhaustIndex = -1;
	int minSteeringSysIndex = -1;
	bool isFirst = true;

	for (int i = 0; i < selExhaustVector.size(); i++) {

		double calculatedClearance = 0.0;
		status = ProFitClearanceCompute(selExhaustVector[i], PRO_FIT_INCLUDE_NONE, selSteeringSys, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &calculatedClearance, NULL, &is_interference_found, coord);
		ruleLog.Write("clearance1 = " + to_string(calculatedClearance));

		string strClearanceF2C01 = to_string(calculatedClearance);
		string result;
		size_t dotPos = strClearanceF2C01.find('.');

		if (dotPos != std::string::npos) {
			if (dotPos + 3 <= strClearanceF2C01.size()) {
				result = strClearanceF2C01.substr(0, dotPos + 3);
			}
			else {
				result = strClearanceF2C01.substr(0, dotPos + 1);
			}
		}
		else {
			result = strClearanceF2C01;
		}

		// Update remarkPt with the clearance details
		remarkPt += "\n" + to_string(i + 1) + ". " + steeringSysName + " and ";
		remarkPt += exhaustName[i] + " = ";
		remarkPt += result + "mm.";

		if (isFirst) {
			minClearance = calculatedClearance;
			minClearanceIndex = i;
			minExhaustIndex = i;
			minSteeringSysIndex = 0;
			isFirst = false;
		}
		else {
			if (calculatedClearance < minClearance) {
				minClearance = calculatedClearance;
				minClearanceIndex = i;
				minExhaustIndex = i;
				minSteeringSysIndex = 0;
			}
		}

		if (calculatedClearance > 20)
			clearancePass++;
		else
			clearanceFail++;
	}

	if (minClearanceIndex != -1 && minExhaustIndex != -1 && minSteeringSysIndex != -1) {
		double distance = 0.0;
		status = ProFitClearanceCompute(selExhaustVector[minExhaustIndex], PRO_FIT_INCLUDE_NONE, selSteeringSys, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance, NULL, &is_interference_found, coord);
		ruleLog.Write("clearance1 = " + to_string(distance));

		if (status == PRO_TK_NO_ERROR) {
			createDatumPoints(coord, "CSYS_ASM_DEF", "Dist_highlght_pnt");
			ruleLog.Write("Smallest clearance is " + to_string(minClearance) + "mm between selections at index " + to_string(minExhaustIndex + 1) + " and " + to_string(minSteeringSysIndex + 1) + " with distance " + to_string(distance));
		}
	}


	//for (int i = 0; i < selExhaustVector.size(); i++)
	//{

	//	status = ProFitClearanceCompute(selExhaustVector[i], PRO_FIT_INCLUDE_NONE, selSteeringSys, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearance, NULL, &is_interference_found, coord);
	//	ruleLog.Write("clearance1 = " + to_string(clearance));

	//	createDatumPoints(coord, "CSYS_ASM_DEF", "Dist_highlght_pnt");

	//	string strClearanceF2C01;
	//	strClearanceF2C01 = to_string(clearance);

	//	string result;
	//	size_t dotPos = strClearanceF2C01.find('.');

	//	if (dotPos != std::string::npos) {
	//		// Check if there are at least two characters after the decimal point
	//		if (dotPos + 3 <= strClearanceF2C01.size()) {
	//			result = strClearanceF2C01.substr(0, dotPos + 3);  // Include the dot and two characters after
	//		}
	//		else {
	//			// Less than two characters after the decimal point
	//			result = strClearanceF2C01.substr(0, dotPos + 1);  // Include only up to the decimal point
	//		}
	//	}
	//	else {
	//		// No decimal point found
	//		result = strClearanceF2C01;
	//	}

	//	remarkPt += "\n" + to_string(i + 1) + ". " + steeringSysName + " and ";
	//	remarkPt += exhaustName[i] + " = ";
	//	remarkPt += result + "mm.";


	//	if (clearance > 20)
	//		clearancePass++;
	//	else
	//		clearanceFail++;
	//}


	ruleLog.Write("check 1");

	remarkPt += "\n\nAcceptance Criteria: Pitman arm clearance in extreme travel with front mounted exhaust system > 20.00mm";
	ruleLog.Write(remarkPt);
	ruleLog.Write("check 2");

	if (clearanceFail == 0)
	{
		ruleLog.Write("check 3");
		final_res.result = "PASS";
	}
	else
	{
		ruleLog.Write("check 4");
		final_res.result = "FAIL";
	}

	final_res.remark = remarkPt;
	ruleLog.Write("check 5");

	exhaustName.clear();
	selExhaustVector.clear();
	remarkPt.clear();
	steeringSysName.clear();
	ruleLog.Write("check 6");

	return 0;
}

ProError user_action_F2B06_003(ProFeature* p_feature, ProError status, ProAppData appdata)
{
	ruleLog.Write("----------------------------- user_action_F2B06_003 -----------------------------");

	vector<PartnameDescriptionPair>* prtname_desc_list = (vector<PartnameDescriptionPair>*)appdata;

	ProMdlType subModuleMdlType;
	ProModelitem modelItem;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ProMdl reqMdl;
	PartnameDescriptionPair compd{};

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
	status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
	ruleLog.Write("ProMdlTypeGet: " + to_string(status));
	status = ProMdlMdlnameGet(reqMdl, wFeatName);
	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(cFeatName, wFeatName);
	ruleLog.Write("cFeatName = " + string(cFeatName));
	string cFeatNameStr = cFeatName;

	status = ProMdlToModelitem(reqMdl, &modelItem);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	string tokenF2B06 = "F2B06";
	vector<string> tokenExhaust = { "F3B06","F3B05","F3B01","F3B03", "F3B11" };

	ProIdTable memb_id_tab;
	memb_id_tab[0] = p_feature->id;
	ProAsmcomppath p_comp_path;

	if (strlen(cFeatName) == 14 && cFeatNameStr.find(tokenF2B06) != string::npos)
	{
		strcpy(compd.part_name, cFeatName);
		ruleLog.Write("compd.part_name: " + string(compd.part_name));

		steeringSysName = cFeatName;

		ProMdl curMdl;
		status = ProMdlCurrentGet(&curMdl);
		ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

		status = ProAsmcomppathInit((ProSolid)curMdl, memb_id_tab, 1, &p_comp_path);
		ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

		status = ProSelectionAlloc(&p_comp_path, &modelItem, &selSteeringSys);
		ruleLog.Write("ProSelectionAlloc: " + to_string(status));
	}

	if (strlen(cFeatName) == 14 && ((cFeatNameStr.find(tokenExhaust[0]) != string::npos || cFeatNameStr.find(tokenExhaust[1]) != string::npos || cFeatNameStr.find(tokenExhaust[2]) != string::npos || cFeatNameStr.find(tokenExhaust[3]) != string::npos || cFeatNameStr.find(tokenExhaust[4]) != string::npos || cFeatNameStr.find(tokenExhaust[5]) != string::npos)))
	{
		strcpy(compd.part_name, cFeatName);
		ruleLog.Write("compd.part_name: " + string(compd.part_name));

		exhaustName.push_back(cFeatName);
		ruleLog.Write("check 1");

		ProMdl curMdl;
		status = ProMdlCurrentGet(&curMdl);

		status = ProAsmcomppathInit((ProSolid)curMdl, memb_id_tab, 1, &p_comp_path);
		ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

		status = ProSelectionAlloc(&p_comp_path, &modelItem, &selExhaust);
		ruleLog.Write("ProSelectionAlloc: " + to_string(status));

		selExhaustVector.push_back(selExhaust);
	}
	//prtname_desc_list->push_back(compd);
	return PRO_TK_NO_ERROR;
}
