/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 07-07-2023	|	V1_0_0		| F3B03 - EXHAUST SYSTEM RULES
==================================================================================================================*/
#include "F3B03.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF3B03002		| Pallavi Garodi	| MF3B03			|  Differential Pressure sensor mounting bracket in CNG Exhaust system to be packaged between Inlet & outlet flanges of GPF
===================================================================================================================*/
#define DLG_F3B03_002   "dlg_IR_F3B03_002"
#define PB_RCANCEL      "rule_cancel_pb"
#define PB_ROK          "rule_ok_pb"
#define PB_RSELECT      "PB_RSELECT"
#define CSYS            "CSYS"
#define _Platform	    "_Platform"

bool				RightValue = NULL;
string				str;
char				cParentMdlName[PRO_NAME_SIZE], existingPval[PRO_NAME_SIZE]{};
double				cadValue;
ProSelection*		DPS_Selection = nullptr, DPSCSYS = nullptr;
double				surface_Distance1, surface_Distance2, surface_Distance3, CSYSDistance;
vector<double>		t1, t3;
vector<string>		dpsPosition;
vector<int>			Id;
vector<string>		Des, _Name;


int IRF3B03::IRF3B03_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF3B03::IRF3B03_002   ==========================");

	InterfaceRule     _irule;
	string            description;
	double            distance;

	final_res.remark.clear();

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_F3B03_002, DLG_F3B03_002);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_F3B03_002, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F3B03_002, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F3B03_002, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F3B03_002, PB_RSELECT, (ProUIAction)select_surface_IRF3B03002, (ProAppData)&isUserQuits);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogHide: " + to_string(status));
	status = ProUIDialogActivate(DLG_F3B03_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	status = ProUIDialogDestroy(DLG_F3B03_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits) {
		return -1;
	}
	//ruleLog.Write("Result");
	ruleLog.Write(_Name[0]);
	ruleLog.Write(to_string(Id[0]));
	//ruleLog.Write(Des[0]);
	ruleLog.Write(_Name[1]);
	ruleLog.Write(to_string(Id[1]));
	//ruleLog.Write(Des[0]);

	// DECLARE RESULT
	string rem_message;
	rem_message += "Position of DPS Sensor is " + (dpsPosition[0]) + "mm and " + (dpsPosition[1]) + "mm from Inlet & outlet flanges of GPF.\n";

	if (RightValue == true) {
		final_res.result = "PASS";
		rem_message += "DPS Sensor is mounted preferable at the center of GPF, as per acceptance criteria.\n ";
	}
	else {
		final_res.result = "FAIL";
		rem_message += "DPS Sensor position is not as per acceptance criteria.\n ";
	}

	rem_message += "\nReferances selected:- " + string(_Name[0]) + ".prt (Feat Id:" + to_string(Id[0]) + ")," + string(_Name[1]) + ".prt (Feat Id:" + to_string(Id[1]) + "),\n                      " + string(_Name[2]) + ".prt (Feat Id:" + to_string(Id[2]) + ")\n\n";
	//rem_message += "Selection 2  = " + string(_Name[1]) + ".prt (Feat Id:" + to_string(Id[1]) + ")\n";
	//rem_message += "Selection 3  = " + string(_Name[2]) + ".prt (Feat Id:" + to_string(Id[2]) + ")\n\n";

	rem_message += "\nAcceptance Criteria: DPS Sensor position preferable at the center of GPF, ";
	rem_message += "\n                     In case of DMU constraint +/-75mm tolerance is acceptable.";
	final_res.remark = rem_message;

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);


	t1.clear();
	t3.clear();
	dpsPosition.clear();
	Id.clear();
	Des.clear();
	_Name.clear();
	//reqValsFromCsv_F3B03.clear();
	////_reqValsFromCsv.clear();
	return 0;
}

ProError select_surface_IRF3B03002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_surface_IRF3B03002 -----------------------------");

	InterfaceRule _irule;
	int sels;
	double D;
	bool* quitAction = (bool*)data;
	int rule_sts;
	ProAsmcomppath	  DPS_comp_path;
	ProAsmcomppath    path;
	ProMdl	          parent_mdl;
	wchar_t           wParentMdlName[PRO_NAME_SIZE];
	ProModelitem      modelItem;
	ProParameter      pDesc;
	ProParamvalue     pvDesc;
	ProName pDescName = L"DESCRIPTION";
	int              curWinId;
	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);
	ProAnnotationElem annotelem;
	ProAnnotationElem annotelem1;
	char				t[20];
	t1.clear();
	t3.clear();
	dpsPosition.clear();

	status = ProSelect((char*)"surface,edge", 3, NULL, NULL, NULL, NULL, &DPS_Selection, &sels);
	ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(sels));

	if (status == PRO_TK_USER_ABORT) {
		/*if (quitAction != NULL)
			*quitAction = true;*/
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide inputs again!. Refer help document for details.");
		status = ProUIDialogShow(dialog);
		status = ProUIPushbuttonDisable(DLG_F3B03_002, PB_ROK);
		return status;
	}

	if ((sels < 2) || (status != PRO_TK_NO_ERROR)) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide 2 surface selection. Refer help document for details.");
		/*if (quitAction != NULL)
			*quitAction = true;*/
		status = ProUIDialogShow(dialog);
		status = ProUIPushbuttonDisable(DLG_F3B03_002, PB_ROK);
		return status;
	}
	for (int i = 0; i < 3; ++i) {
		status = ProSelectionAsmcomppathGet(DPS_Selection[i], &DPS_comp_path);
		ruleLog.Write("ProSelectionAsmcomppathGet = " + to_string(status));

		status = ProAsmcomppathMdlGet(&DPS_comp_path, &parent_mdl);
		ruleLog.Write("ProAsmcomppathMdlGet = " + to_string(status));

		status = ProMdlMdlnameGet(parent_mdl, wParentMdlName);
		ProWstringToString(cParentMdlName, wParentMdlName);
		ruleLog.Write("cParentMdlName = " + (string)cParentMdlName);
		_Name.push_back(cParentMdlName);

		/*status = ProMdlToModelitem(parent_mdl, &modelItem);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&modelItem, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit: " + to_string(status));

		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ProWstringToString(existingPval, pvDesc.value.s_val);
			ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);
			Des.push_back(existingPval);
		}*/

		status = ProSelectionModelitemGet(DPS_Selection[i], &annotelem);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status) + "\tSurface Id: " + to_string(annotelem.id));
		Id.push_back(annotelem.id);

	}

	status = _irule.measureDistanceBetweenSurfaces(DPS_Selection[0], DPS_Selection[1], surface_Distance1);
	status = _irule.measureDistanceBetweenSurfaces(DPS_Selection[0], DPS_Selection[2], surface_Distance2);
	status = _irule.measureDistanceBetweenSurfaces(DPS_Selection[1], DPS_Selection[2], surface_Distance3);
	t1.push_back(surface_Distance1);
	t1.push_back(surface_Distance2);
	t1.push_back(surface_Distance3);

	// Find the greatest and smallest values
	double smallest = *std::min_element(t1.begin(), t1.end());
	double greatest = *std::max_element(t1.begin(), t1.end());

	cadValue = greatest / 2;
	ruleLog.Write("cadValue: " + to_string(cadValue));

	double lowerLimit = smallest - 75;
	double higherLimit = smallest + 75;

	if (cadValue >= lowerLimit && cadValue <= higherLimit)
	{
		ruleLog.Write("Rule Pass");
		RightValue = true;
	}
	else {
		RightValue = false;
	}
	for (double val : t1) {
		if (val != greatest) {
			ruleLog.Write(to_string(val));
			t3.push_back(val);
		}
	}
	for (int i = 0; i < t3.size(); ++i) {
		// Remove trailing zeros from the second decimal place
		sprintf(t, "%.2f", t3.at(i));
		int length = strlen(t);
		while (length > 0 && t[length + 1] == '0') {
			t[length + 1] = '\0';
			length--;
		}
		ruleLog.Write(t);
		dpsPosition.push_back(t);
	}
	status = ProUIPushbuttonDisable(DLG_F3B03_002, _Platform);
	status = ProUIDialogShow(dialog);
	status = ProUIPushbuttonEnable(DLG_F3B03_002, PB_ROK);

	return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES				| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF3B03005		| Atharva Patil		| MF3B03;MF3B05;MF3B06			| A minimum ground clearance value to be maintained while
																	  mounting EGP Assembly on vehicle.
===================================================================================================================*/
#define DLG_F3B03_005		"dlg_IR_F3B03_005"
#define PB_RCANCEL			"Commit_Cancel"
#define PB_ROK				"Commit_Ok"
#define PB_SELECT_TYRE      "pb_select_tyre"
#define Label_tyre			"Lable_sel_tyre"
#define PB_SELECT_FRAME     "pb_select_frame"
#define Label_frame			"Lable_sel_frame"
#define Label_plat			"Label_plat"
#define platform			"platform"
#define Label_subPlat		"Label_subPlat"
#define vehicalType			"vehicalType"
#define Label_SLR			"Label_SLR"
#define InputPanel_SLR		"InputPanel_SLR"
//#define Label_RG			"Label_RG"
//#define RadioGroup			"RadioGroup"
//#define Label_STR			"Label_STR"
//#define InputPanel_STR		"InputPanel_STR"

vector<vector<string>>dbList2D_EGP;
string PlatFVal_EGP, subPlatFVal_EGP;
vector<string>reqValsFromCsv_EGP;
double stdGrndCleVal_EGP{};

int IRF3B03::IRF3B03_005(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF3B03::IRF3B03_005   ==========================");
	string tyreSurfInfo{}, suspTravMsg{};
	vector<selectionInfo>tyreSurfSels(2);
	//vector<selectionInfo>longMembSels(1);
	vector<double>slrValVec;
	vector<double>susTravelValVec;
	tyreSurfInfo.erase();
	suspTravMsg.erase();
	slrValVec.clear();
	susTravelValVec.clear();
	//bool isUnladen = NULL;
	double offsetValue{};

	string				reqCompSubMod[3] = { "F3B03","F3B05","F3B06" };
	string target;
	//Search in the main assembly if submodule, that is to be selected Programmatically, is available
	vector<ComponentData>_reqComps(sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]));
	ruleLog.Write("_reqComps size: " + to_string(_reqComps.size()));

	for (int i = 0; i < _reqComps.size(); ++i)
	{
		target = reqCompSubMod[i];
		ruleLog.Write("target comp: " + target);
		for (int j = 0; j < subModulesList.size(); ++j)
		{
			ruleLog.Write("submodule name being visited: " + subModulesList[j].name);
			if (subModulesList[j].name.find(target) != string::npos)
			{
				ruleLog.Write("match found for: " + subModulesList[j].name);
				strcpy(_reqComps[i].name, subModulesList[j].name.c_str());
			}
		}
	}

	for (int i = 0; i < _reqComps.size(); i++)
	{
		ruleLog.Write("_reqComps[" + to_string(i) + "].name: " + string(_reqComps[i].name));
	}
	/*for (int i = 0; i < subModulesList.size(); ++i)
	{
		ruleLog.Write("submodule name being visited: " + subModulesList[i].name);
		if (subModulesList[i].name.find("F3B05") != string::npos)
		{
			ruleLog.Write("match found for: " + subModulesList[i].name);
			strcpy(_reqComps[0].name, subModulesList[i].name.c_str());
			break;
		}
	}*/

	//Visiting the model tree for getting feature id of F3B01 SM which will be used to select it
	status = ProSolidFeatVisit((ProSolid)curMdl, (ProFeatureVisitAction)getReqComponentsIdVec, compsFilter, &_reqComps);
	ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
	for (int i = 0; i < _reqComps.size(); i++)
	{
		ruleLog.Write("_reqComps[" + to_string(i) + "].name: " + string(_reqComps[i].name));
		ruleLog.Write("_reqComps[" + to_string(i) + "].id: " + to_string(_reqComps[i].id));
	}


	vector<string> platformValFrmCSV, subPlatform, platformVal;
	dbList2D_EGP = getData2D("IRF3B03005.csv");
	ruleLog.Write("dbList2D.size():" + to_string(dbList2D_EGP.size()));

	for (int i = 1; i < dbList2D_EGP.size(); ++i)	// i = 1 for skipping the headers
	{
		string tok2;
		std::istringstream ss2(dbList2D_EGP[i][0]);
		while (std::getline(ss2, tok2, ';'))
		{
			trimString(tok2);
			ruleLog.Write("Platform: " + tok2);
			//storing list of Platforms from db
			if (find(platformValFrmCSV.begin(), platformValFrmCSV.end(), tok2) == platformValFrmCSV.end()) {
				platformValFrmCSV.push_back(tok2);
			}
		}
	}

	//Delete the features created in previous run
	status = deleteDatumPoint("PROJ_PNT_R");
	ruleLog.Write("deleteDatumPoint PROJ_PNT_R: " + to_string(status));
	status = deleteDatumPoint("PROJ_PNT_F");
	ruleLog.Write("deleteDatumPoint PROJ_PNT_F: " + to_string(status));
	status = deleteDatumPoint("PROJ_PNT_M");
	ruleLog.Write("deleteDatumPoint PROJ_PNT_M: " + to_string(status));
	status = deleteDatumPoint("MY_PNT1");
	ruleLog.Write("deleteDatumPoint MY_PNT1: " + to_string(status));
	status = deleteDatumPoint("MY_PNT2");
	ruleLog.Write("deleteDatumPoint MY_PNT2: " + to_string(status));
	rule_sts = deleteDatumPlane("SIDE_PLANE2");
	ruleLog.Write("deleteDatumPlane SIDE_PLANE2: " + to_string(status));
	rule_sts = deleteDatumPlane("GROUND_PLANE");
	ruleLog.Write("deleteDatumPlane GROUND_PLANE: " + to_string(status));
	status = deleteDatumPoint("F_GND_PNT_OPP");
	ruleLog.Write("deleteDatumPoint F_GND_PNT_OPP: " + to_string(status));
	rule_sts = deleteDatumPlane("SIDE_PLANE1");
	ruleLog.Write("deleteDatumPlane SIDE_PLANE1: " + to_string(status));
	status = deleteDatumPoint("F_GND_PNT");
	ruleLog.Write("deleteDatumPoint F_GND_PNT: " + to_string(status));
	status = deleteDatumPoint("R_GND_PNT");
	ruleLog.Write("deleteDatumPoint R_GND_PNT: " + to_string(status));
	status = deleteDatumPoint("F_CENT_PNT");
	ruleLog.Write("deleteDatumPoint F_CENT_PNT: " + to_string(status));
	status = deleteDatumPoint("R_CENT_PNT");
	ruleLog.Write("deleteDatumPoint R_CENT_PNT: " + to_string(status));
	status = deleteDatumPoint("F_CENT_PNT_OPP");
	ruleLog.Write("deleteDatumPoint R_CENT_PNT: " + to_string(status));
	rule_sts = deleteDatumPlane("CENTRE_PLANE");
	ruleLog.Write("deleteDatumPlane CENTRE_PLANE: " + to_string(status));

	//Create UI dialog
	status = ProUIDialogCreate(DLG_F3B03_005, DLG_F3B03_005);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_F3B03_005, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F3B03_005, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F3B03_005, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_F3B03_005, PB_SELECT_TYRE, (ProUIAction)refSurfSelections, &tyreSurfSels);
	//status = ProUIPushbuttonActivateActionSet(DLG_F3B06_003, PB_SELECT_FRAME, (ProUIAction)refSurfSelections, &longMembSels);
	status = ProUIOptionmenuInputActionSet(DLG_F3B03_005, InputPanel_SLR, (ProUIAction)inputValue, &slrValVec);
	//status = ProUIOptionmenuInputActionSet(DLG_F3B03_005, InputPanel_STR, (ProUIAction)inputValue, &susTravelValVec);
	/*status = ProUIRadiogroupSelectActionSet(DLG_F3B03_005, RadioGroup, (ProUIAction)radioGrpSelectAction, &isUnladen);
	ruleLog.Write("ProUIRadiogroupSelectActionSet status: " + to_string(status));*/
	status = ProUIOptionmenuSelectActionSet(DLG_F3B03_005, platform, (ProUIAction)platformList_EGP, NULL);
	status = ProUIOptionmenuSelectActionSet(DLG_F3B03_005, vehicalType, (ProUIAction)subplatformList_EGP, NULL);

	platformValFrmCSV.insert(platformValFrmCSV.begin(), "Select");
	//Set platform values in platform drop down
	option_menu_EGP(platformValFrmCSV, platform);

	status = ProUIPushbuttonDisable(DLG_F3B03_005, PB_ROK);
	ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));

	status = ProUIOptionmenuDisable(DLG_F3B03_005, platform);
	status = ProUIOptionmenuDisable(DLG_F3B03_005, vehicalType);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogHide: " + to_string(status));

	/*status = ProUILabelHide(DLG_F3B03_005, Label_STR);
	ruleLog.Write("ProUILabelHide: " + to_string(status));
	status = ProUIInputpanelHide(DLG_F3B03_005, InputPanel_STR);
	ruleLog.Write("ProUIInputpanelHide: " + to_string(status));*/

	//Radio button, selected for first button (default)
	//int radioGrpNames[2];
	//char** buttonNames;

	//status = ProUIRadiogroupSelectednamesGet(DLG_F3B03_005, RadioGroup, radioGrpNames, &buttonNames);
	//ruleLog.Write("ProUIRadiogroupSelectednamesGet status main: " + to_string(status));
	//ruleLog.Write("selected button name: " + (string)buttonNames[0]);

	//if (buttonNames[0] == "rb1")       //If user does not select any then default radio button will be first button, 
	//									//and action related to that will be performed on clicking Ok								
	//{
	//	isUnladen = false;
	//}


	status = ProUIDialogActivate(DLG_F3B03_005, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_F3B03_005);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}
	if (slrValVec.size() == 0)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention", "SLR value are not entered,\nClick OK to return.");
		status = ProUIDialogDestroy(DLG_F3B03_005);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		tyreSurfSels.clear();
		//longMembSels.clear();
		slrValVec.clear();

		return -1;
	}

	//Plane Creation 
	edgeSel edgeSelection1{}, edgeSelection2{};
	ProSelection fCentPntSel{}, rCentPntSel{}, csysSel{};
	/*---------------------Create F_CENT_PNT and R_CENT_PNT----------------------
	F_CENT_PNT = Front centre point at the centre of front tyre
	R_CENT_PNT = Rear centre point at the centre of rear tyre
	The points will be created at the centre of biggest edge of tyre surfaces*/

	rule_sts = findTheBiggestArcEdge(tyreSurfSels[0], &edgeSelection1);
	ruleLog.Write("findTheBiggestArcEdge 1: " + to_string(rule_sts));
	status = ProSelectionHighlight(edgeSelection1.sel, PRO_COLOR_HIGHLITE);
	ruleLog.Write("ProSelectionHighlight 1 status: " + to_string(status));
	rule_sts = createDatumPointAtCenterOfEdge(edgeSelection1.sel, "F_CENT_PNT");
	ruleLog.Write("createDatumPointAtCenterOfEdge 1: " + to_string(rule_sts));

	rule_sts = findTheBiggestArcEdge(tyreSurfSels[1], &edgeSelection2);
	ruleLog.Write("findTheBiggestArcEdge 2: " + to_string(rule_sts));
	status = ProSelectionHighlight(edgeSelection2.sel, PRO_COLOR_HIGHLITE);
	ruleLog.Write("ProSelectionHighlight 2 status: " + to_string(status));
	rule_sts = createDatumPointAtCenterOfEdge(edgeSelection2.sel, "R_CENT_PNT");
	ruleLog.Write("createDatumPointAtCenterOfEdge 2: " + to_string(rule_sts));

	/*-----------Get the selection objects of F_CENT_PNT and R_CENT_PNT and CSYS
	It will be used as references to create ground points----------------------*/
	rule_sts = selectionAllocByName("F_CENT_PNT", PRO_POINT, &fCentPntSel);
	ruleLog.Write("selectionAllocByName F_CENT_PNT: " + to_string(rule_sts));
	rule_sts = selectionAllocByName("R_CENT_PNT", PRO_POINT, &rCentPntSel);
	ruleLog.Write("selectionAllocByName R_CENT_PNT: " + to_string(rule_sts));
	rule_sts = selectionAllocByName("CSYS_ASM_DEF", PRO_CSYS, &csysSel);
	ruleLog.Write("selectionAllocByName R_CENT_PNT: " + to_string(rule_sts));

	/*=============== Create a projection plane on opposite side of the vehicle to create a cetre point on that
	side as well
	centre plane will be created as a plane passing through 3 points ===============*/

	//get the selection alloc of a plane passing through vehicle centre (ASM_XZ plane)
	ProSelection asmXZSel;
	rule_sts = selectionAllocByName("ASM_XZ", PRO_SURFACE, &asmXZSel);
	ruleLog.Write("selectionAllocByName ASM_XZ: " + to_string(rule_sts));
	double oppSidePlaneOffsVal = -1200;  //Using general value for commonising the offs distance for all the CAD models 
	rule_sts = createOffsetPlaneWithReference(asmXZSel, oppSidePlaneOffsVal, "SIDE_PLANE1");
	ruleLog.Write("createOffsetPlaneWithReferenceG status: " + to_string(rule_sts));

	//get the selection object of side plane
	ProSelection sidePlane1Sel{};
	rule_sts = selectionAllocByName("SIDE_PLANE1", PRO_SURFACE, &sidePlane1Sel);
	ruleLog.Write("selectionAllocByName PROJ_PLANE: " + to_string(rule_sts));

	rule_sts = projectDatumPointOnPlane(fCentPntSel, sidePlane1Sel, "F_CENT_PNT_OPP");
	ruleLog.Write("projectDatumPointOnPlane1: " + to_string(rule_sts));

	//get the selection object of F_GND_PNT_OPP
	ProSelection fCentPntOpp{};
	rule_sts = selectionAllocByName("F_CENT_PNT_OPP", PRO_POINT, &fCentPntOpp);
	ruleLog.Write("selectionAllocByName PROJ_PLANE: " + to_string(rule_sts));

	//Create a ground plane Normal to Long member surface and passing thr G_PNT_F and G_PNT_R 
	rule_sts = threePointPlaneCreate(fCentPntSel, fCentPntOpp, rCentPntSel, "CENTRE_PLANE");
	ruleLog.Write("threePointPlaneCreate status: " + to_string(rule_sts));

	ProSelection centrePlaneSel{};
	rule_sts = selectionAllocByName("CENTRE_PLANE", PRO_SURFACE, &centrePlaneSel);
	ruleLog.Write("selectionAllocByName CENTRE_PLANE: " + to_string(rule_sts));
	
	
	////Writing the remark for laden/ unladen condition along with manipulating the offset value for creating ground plane
	//ruleLog.Write("Boolean for laden/Unladen? : " + to_string(isUnladen));
	//suspTravMsg += "\nUser response for Laden/Unladen? - ";
	//if (isUnladen == false)
	//{
	//	ruleLog.Write("entered the laden loop");
	//	suspTravMsg += "Laden";
	//	
	//}
	//else if (isUnladen == true)
	//{
	//	ruleLog.Write("entered the Unladen loop");
	//	string susTravelStr;
	//	susTravelStr = to_string(abs(susTravelValVec[susTravelValVec.size() - 1]));
	//	susTravelStr.erase(susTravelStr.find_last_not_of('0') + 3);          //Removing trailing zeroes to keep only 2 zeroes post decimal point
	//	suspTravMsg += "Unladen";
	//	suspTravMsg += "\nSuspension travel enterd by user: " + susTravelStr + " mm.";
	//	offsetValue = abs(slrValVec[slrValVec.size() - 1]) - abs(susTravelValVec[susTravelValVec.size() - 1]);
	//}
	
	offsetValue = abs(slrValVec[slrValVec.size() - 1]);
	ruleLog.Write("offsetValue: " + to_string(offsetValue));

	//Create a Ground plane paralle to centre plane at an offset distance offsetValue
	ruleLog.Write("slrValVec[slrValVec.size() - 1]: " + to_string(slrValVec[slrValVec.size() - 1]));
	rule_sts = createOffsetPlaneWithReference(centrePlaneSel, offsetValue, "GROUND_PLANE");
	ruleLog.Write("createOffsetPlaneWithReferenceG status: " + to_string(rule_sts));

	ProSelection groundPlaneSel{};
	rule_sts = selectionAllocByName("GROUND_PLANE", PRO_SURFACE, &groundPlaneSel);
	ruleLog.Write("selectionAllocByName GROUND_PLANE: " + to_string(rule_sts));

	//Measure distance between component and ground plane (groundClearance)
	double distance;
	Pro3dPnt pntArr[2];
	vector<clearanceData>cleaData;
	clearanceData obj;
	for (int i = 0; i < _reqComps.size(); i++)
	{
		rule_sts = measureDistanceBetweenPlaneAndComp(groundPlaneSel, _reqComps[i], distance, pntArr);
		ruleLog.Write("measureDistanceBetweenPlaneAndCompG status: " + to_string(rule_sts));
		obj.clearance = distance;
		ruleLog.Write("distance copied");
		obj.pntArr[0][0] = pntArr[0][0];
		obj.pntArr[0][1] = pntArr[0][1];
		obj.pntArr[0][2] = pntArr[0][2];
		obj.pntArr[1][0] = pntArr[1][0];
		obj.pntArr[1][1] = pntArr[1][1];
		obj.pntArr[1][2] = pntArr[1][2];
		ruleLog.Write("coordinates copied");
		strcpy(obj.nameOfSel2, _reqComps[i].name);
		ruleLog.Write("name copied");
		obj.id2 = _reqComps[i].id;
		ruleLog.Write("id copied");
		cleaData.push_back(obj);

	}
	sort(cleaData.begin(), cleaData.end(), [](const clearanceData& a, const clearanceData& b) {
		return a.clearance < b.clearance;
		});
	/*===================== create points for highlighting the distance =====================
	  NOTE :- coords (pntArr) returned by API ProSelectionWithOptionsDistanceEval===========*/
	rule_sts = createCsysOffsDatumPoint(csysSel, cleaData[0].pntArr, "GROUND_CLEARANCE_PNT");
	ruleLog.Write("createCsysOffsDatumPoint status: " + to_string(rule_sts));
	double groundClearance = cleaData[0].clearance;

	ruleLog.Write("check1");
	//Rule Validation and Results 
	if (groundClearance >= stdGrndCleVal_EGP)
	{
		final_res.result = "PASS";
	}
	else
		final_res.result = "FAIL";
	ruleLog.Write("check2");
	/*========================== remarks ==============================*/
	//remark message for tyre surface details
	tyreSurfInfo += "\n\nReferences selected from tyre - \n";
	for (int i = 0; i < tyreSurfSels.size(); i++)
	{
		tyreSurfInfo += to_string(i + 1) + ")surf ID- " + to_string(tyreSurfSels[i].id) + "(Owner: " + tyreSurfSels[i].name + ".PRT\tDesc: " + tyreSurfSels[i].descrp + ")\n";
	}
	ruleLog.Write("check3");
	string userSelsRec, slrValStr;
	slrValStr = to_string(abs(slrValVec[slrValVec.size() - 1]));
	slrValStr.erase(slrValStr.find_last_not_of('0') + 3);          //Removing trailing zeroes to keep only 2 zeroes post decimal point
	ruleLog.Write("check4");
	//remarkMsg for SLR value and platform selected by user
	userSelsRec += "\nSelected Platform: " + PlatFVal_EGP + "\t" + subPlatFVal_EGP + "\n";
	userSelsRec += "SLR value provided: " + slrValStr + " mm.";
	sprintf(remark, "Ground Clearance of Exhaust system: %0.2lf mm\nAcceptance Criteria: min %0.2lf mm\n", round(groundClearance), stdGrndCleVal_EGP);

	ruleLog.Write("check5");
	//Remark message for ground clearance of submodules
	string depSmGrndClea, temp;
	depSmGrndClea += "Ground Clearance of: \n";
	for (int i = 0; i < cleaData.size(); i++)
	{
		ruleLog.Write("Running for: " + to_string(i + 1) + "th time");
		depSmGrndClea += cleaData[i].nameOfSel2;
		depSmGrndClea += ": ";
		temp = to_string(round(abs(cleaData[i].clearance)));
		ruleLog.Write("check imp: " + temp);
		temp.erase(temp.find_last_not_of('0') + 3);
		ruleLog.Write("check vvvimp");
		depSmGrndClea += temp + " mm.\n";
		temp.erase();
	}
	final_res.remark = remark + depSmGrndClea + userSelsRec + suspTravMsg + tyreSurfInfo;
	//destroy the UI dialog for smooth transition 
	status = ProUIDialogDestroy(DLG_F3B03_005);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	tyreSurfSels.clear();
	//longMembSels.clear();

	cleaData.clear();
	return 0;
}

ProError platformList_EGP(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- platformList -----------------------------");
	status = ProUIPushbuttonDisable(dialog, PB_ROK);
	status = ProUIOptionmenuDisable(dialog, vehicalType);
	string* _data = (string*)data;
	int n_sel;
	char** selValue;
	InterfaceRule iRule;

	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("Platform = " + string(selValue[0]));
	string storePlatVal = string(selValue[0]);

	vector<string> SelPlatform;

	//Assign to global
	PlatFVal_EGP = storePlatVal;

	if ((storePlatVal == "ILCV") || (storePlatVal == "BUS") || (storePlatVal == "MHCV"))
	{
		ruleLog.Write("inside if condition");
		status = ProUIOptionmenuHide(dialog, vehicalType);
		status = ProUILabelHide(dialog, Label_subPlat);
		ruleLog.Write("ProUIOptionmenuDisable status: " + to_string(status));
		getGroundClearanceValsFromCsv_EGP("IRF3B01004.csv", 0, 2, storePlatVal, reqValsFromCsv_EGP);
		for (auto values : reqValsFromCsv_EGP) {
			ruleLog.Write("Distances = " + values);
			stdGrndCleVal_EGP = stod(values);
		}
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
		iRule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention!!", "Please Click on 'Ok' button to display the results.");
		subPlatFVal_EGP.erase();
	}
	else
	{
		ruleLog.Write("inside else condition");
		status = ProUIOptionmenuShow(dialog, vehicalType);
		status = ProUILabelShow(dialog, Label_subPlat);
		status = ProUIPushbuttonEnable(dialog, vehicalType);
		getPlatval_EGP(dbList2D_EGP, storePlatVal, SelPlatform);
		//ProUIPushbuttonDisable(DLG_F3A01_003, PB_ROK);

		for (auto str : SelPlatform) {
			ruleLog.Write("SelPlatform = " + str);
		}

		option_menu_EGP(SelPlatform, vehicalType);

	}

	if (storePlatVal == "Select")
	{
		ProUIPushbuttonDisable(dialog, PB_ROK);
		ProUIOptionmenuDisable(dialog, vehicalType);
	}

	return PRO_TK_NO_ERROR;
}

ProError subplatformList_EGP(char* dialog, char* component, ProAppData data) {

	ruleLog.Write("----------------------------- subplatformList -----------------------------");
	status = ProUIPushbuttonDisable(dialog, PB_ROK);
	//vector<string> reqValsFromCsv;
	InterfaceRule irc;
	string* reqData = (string*)data;
	int n_sel;
	char** selValue;
	boolean isUserQuits = false;
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("Sub Platform = " + string(selValue[0]));
	string str = string(selValue[0]);

	//Assign to global
	subPlatFVal_EGP += "(" + (string)selValue[0] + ")";

	getGroundClearanceValsFromCsv_EGP("IRF3B01004.csv", 1, 2, str, reqValsFromCsv_EGP);
	for (auto values : reqValsFromCsv_EGP) {
		ruleLog.Write("Distances = " + values);
		stdGrndCleVal_EGP = stod(values);
	}
	//reqValsFromCsv = reqValsFromCsv;
	ruleLog.Write(" Size = " + to_string(reqValsFromCsv_EGP.size()));

	status = ProUIPushbuttonEnable(dialog, PB_ROK);
	return PRO_TK_NO_ERROR;
}

void getPlatval_EGP(vector<vector<string>> dbList2D_EP_F3A01, string platformName, vector<string>& values) {

	ruleLog.Write("----------------------------- getengineCapdatafromcsv -----------------------------");

	for (int i = 1; i < dbList2D_EP_F3A01.size(); ++i) {
		while (dbList2D_EP_F3A01[i][0].compare(platformName) == 0) {
			string str = dbList2D_EP_F3A01[i][1];
			if (find(values.begin(), values.end(), str) == values.end()) {
				values.push_back(str);
			}
			break;
		}
	}
	ruleLog.Write("platform.size:" + to_string(values.size()));
}

void option_menu_EGP(vector<string> option_menulist, char* optionmenu) {

	ruleLog.Write("----------------------------- option_menu -----------------------------");

	char** loadCapListNames;
	wchar_t** loadCapListLabels;
	status = ProArrayAlloc(option_menulist.size(), sizeof(char*), 50, (ProArray*)&loadCapListNames);
	status = ProArrayAlloc(option_menulist.size(), sizeof(wchar_t*), 50, (ProArray*)&loadCapListLabels);

	for (int i = 0; i < option_menulist.size(); ++i)
	{
		loadCapListNames[i] = (char*)calloc(50, sizeof(char));
		ProTKSprintf(loadCapListNames[i], "%s", option_menulist[i]);

		loadCapListLabels[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
		ProStringToWstring(loadCapListLabels[i], loadCapListNames[i]);
	}
	status = ProUIOptionmenuNamesSet(DLG_F3B03_005, optionmenu, int(option_menulist.size()), loadCapListNames);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(DLG_F3B03_005, optionmenu, int(option_menulist.size()), loadCapListLabels);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

	status = ProArrayFree((ProArray*)&loadCapListNames);
	status = ProArrayFree((ProArray*)&loadCapListLabels);
}

void getGroundClearanceValsFromCsv_EGP(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv) {
	mainLog.Write("================= getGroundClearanceValsFromCsv ==================");

	InterfaceRule iRule;
	vector<vector<string>> csvData2D = iRule.getData2D(csvFilename);
	for (int i = 1; i < csvData2D.size(); i++) {
		if (csvData2D[i][partNoIdx].compare(partNo) == 0) {
			string tok1;
			std::istringstream ss1(csvData2D[i][reqValIdx]);
			while (std::getline(ss1, tok1, ';')) {
				reqValsFromCsv.push_back(tok1);
			}
			break;
		}

	}
	csvData2D.clear();
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES			| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F3B03-006	| ATHARVA PATIL 	| MF3B03;					| Verification of Ramp over and Departure angle for
																  EGP - Exhaust System as per design rule guidelines
===================================================================================================================*/
#define DLG_F3B03_006		"dlg_IR_F3B03_006"
#define PB_RCANCEL			"Commit_Cancel"
#define PB_ROK				"Commit_Ok"
#define PB_SELECT_TYRE      "pb_select_tyre"
#define Label_tyre			"Lable_sel_tyre"
#define PB_SELECT_FRAME     "pb_select_frame"
#define Label_frame			"Lable_sel_frame"
#define Label_SLRf			"Label_SLRf"
#define Label_SLRr			"Label_SLRr"
#define InputPanel_Rrf		"InputPanel_Rrf"
#define InputPanel_Rrr		"InputPanel_Rrr"
//#define Label_RG			"Label_RG"
//#define RadioGroup		"RadioGroup"
//#define Label_STR			"Label_STR"
//#define InputPanel_STR	"InputPanel_STR"


int IRF3B03::IRF3B03_006(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF3B03::IRF3B03_006   ==========================");
	string tyreSurfInfo{}, frameSurfInfo{}, suspTravMsg{};
	vector<selectionInfo>tyreSurfSels(2);
	vector<selectionInfo>longMembSels(1);
	vector<double>frontSLRVec, rearSLRVec;
	//vector<double>susTravelValVec;
	//susTravelValVec.clear();
	//bool isUnladen = NULL;
	double offsetValueFrnt{}, offsetValueRear{};

	tyreSurfInfo.erase();
	frameSurfInfo.erase();
	frontSLRVec.clear();
	rearSLRVec.clear();


	//Search in the main assembly if submodule, that is to be selected Programmatically, is available
	ComponentData _reqComps[1];
	for (int i = 0; i < subModulesList.size(); ++i)
	{
		ruleLog.Write("submodule name being visited: " + subModulesList[i].name);
		if (subModulesList[i].name.find("F3B03") != string::npos)
		{
			ruleLog.Write("match found for: " + subModulesList[i].name);
			strcpy(_reqComps[0].name, subModulesList[i].name.c_str());
			break;
		}
	}

	//Visiting the model tree for getting feature id of F3B01 SM which will be used to select it
	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps);
	ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
	ruleLog.Write("Name of the submodule = " + string(_reqComps[0].name));
	ruleLog.Write("Feat id of the submodule = " + to_string(_reqComps[0].id));

	//Delete the features created in previous run
	status = deleteDatumPoint("PROJ_PNT_R");
	ruleLog.Write("deleteDatumPoint PROJ_PNT_R: " + to_string(status));
	status = deleteDatumPoint("PROJ_PNT_F");
	ruleLog.Write("deleteDatumPoint PROJ_PNT_F: " + to_string(status));
	status = deleteDatumPoint("PROJ_PNT_M");
	ruleLog.Write("deleteDatumPoint PROJ_PNT_M: " + to_string(status));
	status = deleteDatumPoint("MY_PNT1");
	ruleLog.Write("deleteDatumPoint MY_PNT1: " + to_string(status));
	status = deleteDatumPoint("MY_PNT2");
	ruleLog.Write("deleteDatumPoint MY_PNT2: " + to_string(status));
	rule_sts = deleteDatumPlane("SIDE_PLANE2");
	ruleLog.Write("deleteDatumPlane SIDE_PLANE2: " + to_string(status));
	rule_sts = deleteDatumPlane("GROUND_PLANE");
	ruleLog.Write("deleteDatumPlane GROUND_PLANE: " + to_string(status));
	status = deleteDatumPoint("F_GND_PNT_OPP");
	ruleLog.Write("deleteDatumPoint F_GND_PNT_OPP: " + to_string(status));
	rule_sts = deleteDatumPlane("SIDE_PLANE1");
	ruleLog.Write("deleteDatumPlane SIDE_PLANE1: " + to_string(status));
	status = deleteDatumPoint("F_GND_PNT");
	ruleLog.Write("deleteDatumPoint F_GND_PNT: " + to_string(status));
	status = deleteDatumPoint("R_GND_PNT");
	ruleLog.Write("deleteDatumPoint R_GND_PNT: " + to_string(status));
	status = deleteDatumPoint("F_CENT_PNT");
	ruleLog.Write("deleteDatumPoint F_CENT_PNT: " + to_string(status));
	status = deleteDatumPoint("R_CENT_PNT");
	ruleLog.Write("deleteDatumPoint R_CENT_PNT: " + to_string(status));
	status = deleteDatumPoint("F_CENT_PNT_OPP");
	ruleLog.Write("deleteDatumPoint F_CENT_PNT_OPP: " + to_string(status));
	rule_sts = deleteDatumPlane("CENTRE_PLANE");
	ruleLog.Write("deleteDatumPlane CENTRE_PLANE: " + to_string(status));

	//Create UI dialog
	status = ProUIDialogCreate(DLG_F3B03_006, DLG_F3B03_006);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_F3B03_006, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F3B03_006, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F3B03_006, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_F3B03_006, PB_SELECT_TYRE, (ProUIAction)refSurfSelections, &tyreSurfSels);
	status = ProUIPushbuttonActivateActionSet(DLG_F3B03_006, PB_SELECT_FRAME, (ProUIAction)refSurfSelections, &longMembSels);
	status = ProUIOptionmenuInputActionSet(DLG_F3B03_006, InputPanel_Rrf, (ProUIAction)inputValue, &frontSLRVec);
	status = ProUIOptionmenuInputActionSet(DLG_F3B03_006, InputPanel_Rrr, (ProUIAction)inputValue, &rearSLRVec);
	//status = ProUIOptionmenuInputActionSet(DLG_F3B03_006, InputPanel_STR, (ProUIAction)inputValue, &susTravelValVec);
	//status = ProUIRadiogroupSelectActionSet(DLG_F3B03_006, RadioGroup, (ProUIAction)radioGrpSelectAction, &isUnladen);
	ruleLog.Write("ProUIRadiogroupSelectActionSet status: " + to_string(status));
	status = ProUIPushbuttonDisable(DLG_F3B03_006, PB_ROK);
	ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));
	status = ProUIInputpanelDisable(DLG_F3B03_006, InputPanel_Rrf);
	status = ProUIInputpanelDisable(DLG_F3B03_006, InputPanel_Rrr);
	status = ProUIPushbuttonDisable(DLG_F3B03_006, PB_SELECT_FRAME);


	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogHide: " + to_string(status));
	/*status = ProUILabelHide(DLG_F3B03_006, Label_STR);
	ruleLog.Write("ProUILabelHide: " + to_string(status));
	status = ProUIInputpanelHide(DLG_F3B03_006, InputPanel_STR);
	ruleLog.Write("ProUIInputpanelHide: " + to_string(status));*/

	//Provision of radio buttons for laden/unladen condition

	//Radio button, selected for first button (default)
	//int radioGrpNames[2];
	//char** buttonNames;
	//status = ProUIRadiogroupSelectednamesGet(DLG_F3B03_006, RadioGroup, radioGrpNames, &buttonNames);
	//ruleLog.Write("ProUIRadiogroupSelectednamesGet status main: " + to_string(status));
	//ruleLog.Write("selected button name: " + (string)buttonNames[0]);
	//if (buttonNames[0] == "rb1")       //If user does not select any then default radio button will be first button, 
	//									//and action related to that will be performed on clicking Ok								
	//{
	//	isUnladen = false;
	//}


	status = ProUIDialogActivate(DLG_F3B03_006, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_F3B03_006);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}
	if (frontSLRVec.size() == 0 || rearSLRVec.size() == 0)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention", "SLR values are not entered,\nClick OK to return.");
		status = ProUIDialogDestroy(DLG_F3B03_006);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		tyreSurfSels.clear();
		longMembSels.clear();
		frontSLRVec.clear();
		rearSLRVec.clear();
		return -1;

	}

	ProSelection fCentPntSel{}, rCentPntSel{}, csysSel{}, gPntF{}, gPntR{};
	double rollRadFront[3], rollRadRear[3];       // This is rolling radius of front and rear tyre
	rollRadRear[0] = 0;
	rollRadRear[1] = 0;
	rollRadFront[0] = 0;
	rollRadFront[1] = 0;

	//provision for considering suspension travel based on laden and unladen (expand the commented lines for clarity)

	/*//Writing the remark for laden/ unladen condition along with manipulating the offset value for creating ground plane

	ruleLog.Write("Boolean for laden/Unladen? : " + to_string(isUnladen));
	suspTravMsg += "\nUser response for Laden/Unladen? - ";

	if (isUnladen == false)
	{
		ruleLog.Write("entered the laden loop");
		suspTravMsg += "Laden";*/
	offsetValueFrnt = (frontSLRVec[frontSLRVec.size() - 1]);
	offsetValueRear = (rearSLRVec[rearSLRVec.size() - 1]);

	rollRadRear[2] = offsetValueRear;
	rollRadFront[2] = offsetValueFrnt;
	/*}
	else if (isUnladen == true)
	{
		ruleLog.Write("entered the Unladen loop");
		string susTravelStr;
		susTravelStr = to_string(abs(susTravelValVec[susTravelValVec.size() - 1]));
		susTravelStr.erase(susTravelStr.find_last_not_of('0') + 3);          //Removing trailing zeroes to keep only 2 zeroes post decimal point

		suspTravMsg += "Unladen";
		suspTravMsg += "\nSuspension travel enterd by user: " + susTravelStr + " mm.";

		offsetValueFrnt = abs(frontSLRVec[frontSLRVec.size() - 1]) - abs(susTravelValVec[susTravelValVec.size() - 1]);
		offsetValueRear = abs(rearSLRVec[rearSLRVec.size() - 1]) - abs(susTravelValVec[susTravelValVec.size() - 1]);

		rollRadRear[2] = offsetValueRear;
		rollRadFront[2] = offsetValueFrnt;
	}*/


	//Plane Creation 
	edgeSel edgeSelection1{}, edgeSelection2{};

	/*---------------------Create F_CENT_PNT and R_CENT_PNT----------------------
	F_CENT_PNT = Front centre point at the centre of front tyre
	R_CENT_PNT = Rear centre point at the centre of rear tyre
	The points will be created at the centre of biggest edge of tyre surfaces*/

	rule_sts = findTheBiggestArcEdge(tyreSurfSels[0], &edgeSelection1);
	ruleLog.Write("findTheBiggestArcEdge 1: " + to_string(rule_sts));
	status = ProSelectionHighlight(edgeSelection1.sel, PRO_COLOR_HIGHLITE);
	ruleLog.Write("ProSelectionHighlight 1 status: " + to_string(status));
	rule_sts = createDatumPointAtCenterOfEdge(edgeSelection1.sel, "F_CENT_PNT");
	ruleLog.Write("createDatumPointAtCenterOfEdge 1: " + to_string(rule_sts));

	rule_sts = findTheBiggestArcEdge(tyreSurfSels[1], &edgeSelection2);
	ruleLog.Write("findTheBiggestArcEdge 2: " + to_string(rule_sts));
	status = ProSelectionHighlight(edgeSelection2.sel, PRO_COLOR_HIGHLITE);
	ruleLog.Write("ProSelectionHighlight 2 status: " + to_string(status));
	rule_sts = createDatumPointAtCenterOfEdge(edgeSelection2.sel, "R_CENT_PNT");
	ruleLog.Write("createDatumPointAtCenterOfEdge 2: " + to_string(rule_sts));

	/*-----------Get the selection objects of F_CENT_PNT and R_CENT_PNT and CSYS
	It will be used as references to create ground points----------------------*/
	rule_sts = selectionAllocByName("F_CENT_PNT", PRO_POINT, &fCentPntSel);
	ruleLog.Write("selectionAllocByName F_CENT_PNT: " + to_string(rule_sts));
	rule_sts = selectionAllocByName("R_CENT_PNT", PRO_POINT, &rCentPntSel);
	ruleLog.Write("selectionAllocByName R_CENT_PNT: " + to_string(rule_sts));
	rule_sts = selectionAllocByName("CSYS_ASM_DEF", PRO_CSYS, &csysSel);
	ruleLog.Write("selectionAllocByName csys: " + to_string(rule_sts));

	//create front ground point taking SLRf value

	rule_sts = createGenDPntAtOffsDist(fCentPntSel, csysSel, rollRadFront, "F_GND_PNT");
	ruleLog.Write("createGenDPntAtOffsDist F_GND_PNT: " + to_string(rule_sts));
	//Get the F_GND_PNT selection object
	rule_sts = selectionAllocByName("F_GND_PNT", PRO_POINT, &gPntF);
	ruleLog.Write("selectionAllocByName F_GND_PNT: " + to_string(rule_sts));

	//create rear ground point taking SLRr value
	rule_sts = createGenDPntAtOffsDist(rCentPntSel, csysSel, rollRadRear, "R_GND_PNT");
	ruleLog.Write("createGenDPntAtOffsDist R_GND_PNT: " + to_string(rule_sts));
	//Get the R_GND_PNT selection object
	rule_sts = selectionAllocByName("R_GND_PNT", PRO_POINT, &gPntR);
	ruleLog.Write("selectionAllocByName R_GND_PNT: " + to_string(rule_sts));

	/*=============== Create a projection plane on opposite side of the vehicle to create a ground point on that
	side as well
	Ground plane will be created as a plane passing through 3 points ===============*/

	//get the selection alloc of a plane passing through vehicle centre (ASM_XZ plane)
	ProSelection asmXZSel;
	rule_sts = selectionAllocByName("ASM_XZ", PRO_SURFACE, &asmXZSel);
	ruleLog.Write("selectionAllocByName ASM_XZ: " + to_string(rule_sts));
	double oppSidePlaneOffsVal = -900;  //Using general value for commonising the offs distance for all the CAD models 
	rule_sts = createOffsetPlaneWithReference(asmXZSel, oppSidePlaneOffsVal, "SIDE_PLANE1");
	ruleLog.Write("createOffsetPlaneWithReferenceG status: " + to_string(rule_sts));

	//get the selection object of side plane
	ProSelection sidePlane1Sel{};
	rule_sts = selectionAllocByName("SIDE_PLANE1", PRO_SURFACE, &sidePlane1Sel);
	ruleLog.Write("selectionAllocByName SIDE_PLANE1: " + to_string(rule_sts));

	rule_sts = projectDatumPointOnPlane(gPntF, sidePlane1Sel, "F_GND_PNT_OPP");
	ruleLog.Write("projectDatumPointOnPlane1: " + to_string(rule_sts));

	//get the selection object of F_GND_PNT_OPP
	ProSelection fGndPntOpp{};
	rule_sts = selectionAllocByName("F_GND_PNT_OPP", PRO_POINT, &fGndPntOpp);
	ruleLog.Write("selectionAllocByName F_GND_PNT_OPP: " + to_string(rule_sts));

	//Create a ground plane Normal to Long member surface and passing thr G_PNT_F and G_PNT_R 
	rule_sts = threePointPlaneCreate(gPntF, fGndPntOpp, gPntR, "GROUND_PLANE");
	ruleLog.Write("threePointPlaneCreate status: " + to_string(rule_sts));

	//Create a side plane for projecting all the points on a same line
	double sidePlaneOffsVal = 1200;  //Using general value for commonising the offs distance for all the CAD models 
	rule_sts = createOffsetPlaneWithReference(asmXZSel, sidePlaneOffsVal, "SIDE_PLANE2");
	ruleLog.Write("createOffsetPlaneWithReferenceG status: " + to_string(rule_sts));
	//get the selection object of side plane
	ProSelection projPlaneSel{};
	rule_sts = selectionAllocByName("SIDE_PLANE2", PRO_SURFACE, &projPlaneSel);
	ruleLog.Write("selectionAllocByName SIDE_PLANE2: " + to_string(rule_sts));

	//measure distance between rear plane and rear centre point
	double rearEndDist;
	status = measureDistanceBetweenSurfacesWithOptions(longMembSels[0].selection, PRO_B_TRUE, rCentPntSel, PRO_B_TRUE, rearEndDist);
	ruleLog.Write("measureDistanceBetweenSurfacesWithOptions status: " + to_string(status));

	//Get selection object of ground plane
	ProSelection grndPlaneSel{};
	rule_sts = selectionAllocByName("GROUND_PLANE", PRO_SURFACE, &grndPlaneSel);
	ruleLog.Write("selectionAllocByName ground plane: " + to_string(rule_sts));

	//Measure distance between component and ground plane (groundClearance)
	double groundClearance;
	Pro3dPnt pntArr[2];
	rule_sts = measureDistanceBetweenPlaneAndComp(grndPlaneSel, _reqComps[0], groundClearance, pntArr);
	ruleLog.Write("measureDistanceBetweenPlaneAndCompG status: " + to_string(rule_sts));

	/*===================== create points for highlighting the distance =====================
	  NOTE :- coords (pntArr) returned by API ProSelectionWithOptionsDistanceEval===========*/
	rule_sts = createCsysOffsDatumPoint(csysSel, pntArr, "DISTANCE_HIGHLIGHT_PNT");
	ruleLog.Write("createCsysOffsDatumPoint status: " + to_string(rule_sts));

	/*=================get the selection object of middle point===================
	NOTE -: It will be used to create a point projected on PROJ_PLANE ===========*/
	ProSelection middlePntSel{};
	rule_sts = selectionAllocByName("MY_PNT2", PRO_POINT, &middlePntSel);
	ruleLog.Write("selectionAllocByName middle proj point: " + to_string(rule_sts));
	//Project middle point on side PROJ_PLANE
	rule_sts = projectDatumPointOnPlane(middlePntSel, projPlaneSel, "PROJ_PNT_M");
	ruleLog.Write("projectDatumPointOnPlane1: " + to_string(rule_sts));
	//Get selection object of PROJ_PNT_M
	ProSelection middleProjPntSel{};
	rule_sts = selectionAllocByName("PROJ_PNT_M", PRO_POINT, &middleProjPntSel);
	ruleLog.Write("selectionAllocByName PROJ_PNT_M: " + to_string(rule_sts));

	//project front ground point on a side plane
	rule_sts = projectDatumPointOnPlane(gPntF, projPlaneSel, "PROJ_PNT_F");
	ruleLog.Write("projectDatumPointOnPlane1: " + to_string(rule_sts));
	//Get selection object of PROJ_PNT_F
	ProSelection frontProjPntSel{};
	rule_sts = selectionAllocByName("PROJ_PNT_F", PRO_POINT, &frontProjPntSel);
	ruleLog.Write("selectionAllocByName PROJ_PNT_F: " + to_string(rule_sts));

	//project rear ground point on a side plane
	rule_sts = projectDatumPointOnPlane(gPntR, projPlaneSel, "PROJ_PNT_R");
	ruleLog.Write("projectDatumPointOnPlane2: " + to_string(rule_sts));
	//Get selection object of PROJ_PNT_R
	ProSelection rearProjPntSel{};
	rule_sts = selectionAllocByName("PROJ_PNT_R", PRO_POINT, &rearProjPntSel);
	ruleLog.Write("selectionAllocByName PROJ_PNT_R: " + to_string(rule_sts));

	//measure distance between front project point to middle project point
	double frontPntDist;
	status = measureDistanceBetweenSurfacesWithOptions(frontProjPntSel, PRO_B_TRUE, middleProjPntSel, PRO_B_TRUE, frontPntDist);
	ruleLog.Write("measureDistanceBetweenSurfacesWithOptions status: " + to_string(status) +
		"\ndistance between front and middle point: " + to_string(frontPntDist));

	//measure distance between rear project point to middle project point
	double rearPntDist;
	status = measureDistanceBetweenSurfacesWithOptions(rearProjPntSel, PRO_B_TRUE, middleProjPntSel, PRO_B_TRUE, rearPntDist);
	ruleLog.Write("measureDistanceBetweenSurfacesWithOptions status: " + to_string(status) +
		"\ndistance between rear and middle point: " + to_string(rearPntDist));

	//measure height of frame from ground plane
	double frameHeight;
	status = measureDistanceBetweenSurfacesWithOptions(longMembSels[0].selection, PRO_B_FALSE, grndPlaneSel, PRO_B_FALSE, frameHeight);
	ruleLog.Write("measureDistanceBetweenSurfacesWithOptions status: " + to_string(status) +
		"\nheight of frame from ground plane: " + to_string(frameHeight));

	//calculate departure angle
	double depAngleMeas;
	depAngleMeas = depatureAngleCalc(rearEndDist, frameHeight, abs(rollRadRear[2]));
	ruleLog.Write("depatureAngle status: " + to_string(status) +
		"\nDeparture angle calculated: " + to_string(depAngleMeas));

	//calculate Ramp Over angle
	double rampOvAngMeas;
	rampOvAngMeas = rampOverAngleCalc(frontPntDist, groundClearance, abs(offsetValueFrnt), abs(rollRadRear[2]), rearPntDist);
	ruleLog.Write("rampOverAngle status: " + to_string(status) +
		"\Ramp over angle calculated: " + to_string(rampOvAngMeas));

	//Rule Validation and Results 
	double stdDeprtureAng = 10, stdRampOvAngl = 15;
	if ((depAngleMeas >= stdDeprtureAng) && (rampOvAngMeas >= stdRampOvAngl))
	{
		final_res.result = "PASS";
	}
	else
		final_res.result = "FAIL";

	/*================================= remarks ========================================*/
	//remark message for tyre surface details
	tyreSurfInfo += "\nReferences selected from tyre - \n";
	for (int i = 0; i < tyreSurfSels.size(); i++)
	{
		tyreSurfInfo += to_string(i + 1) + ")surf ID- " + to_string(tyreSurfSels[i].id) + "(Owner: " + tyreSurfSels[i].name + ".PRT\tDesc: " + tyreSurfSels[i].descrp + ")\n";
	}

	//remark message for tyre surface details
	frameSurfInfo += "\nReferences selected from rearmost component - \n";
	for (int i = 0; i < longMembSels.size(); i++)
	{
		frameSurfInfo += to_string(i + 1) + ")Edge ID- " + to_string(longMembSels[i].id) + " (Owner: " + longMembSels[i].name + ".PRT\tDesc: " + longMembSels[i].descrp + ")\n";
	}

	//Remark message for rolling radii provided by user
	string rollingRadMsg, rollRadFrnStr, rollRadRearStr;
	rollRadFrnStr = to_string(abs(frontSLRVec[frontSLRVec.size() - 1]));
	rollRadFrnStr.erase(rollRadFrnStr.find_last_not_of('0') + 3);      //for keeping only 2 zeroes post descimal
	rollRadRearStr = to_string(abs(rearSLRVec[rearSLRVec.size() - 1]));
	rollRadRearStr.erase(rollRadRearStr.find_last_not_of('0') + 3);
	rollingRadMsg += "\nRolling radius values provided by user -\nFront tyre(Rrf): " + rollRadFrnStr + " mm.\t\tRear tyre(Rrr): " + rollRadRearStr + " mm.\n";
	sprintf(remark, "Measured Values - \t\t\t Departure Angle: %0.2lf deg\t || RampOver Angle: %0.2lf deg\nAcceptance Criteria - Departure angle: min.10 deg\t||\tRamp Over angle: min.15 deg (As per IS:12218)\n", depAngleMeas, rampOvAngMeas);
	final_res.remark = remark + rollingRadMsg + suspTravMsg + tyreSurfInfo + frameSurfInfo;

	//destroy the UI dialog for smooth transition 
	status = ProUIDialogDestroy(DLG_F3B03_006);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	tyreSurfSels.clear();
	longMembSels.clear();

	ruleLog.Write("rearEndDist: " + to_string(rearEndDist) + "\nframeHeight: " + to_string(frameHeight) + "\nRolling Radius rear: " + to_string(abs(rollRadRear[2])));
	ruleLog.Write("frontPntDist: " + to_string(frontPntDist) + "\ngroundClearance: " + to_string(groundClearance) + "\nRolling Radius front: " + to_string(abs(rollRadFront[2])) + "\nrearPntDist: " + to_string(rearPntDist));


	return 0;
}