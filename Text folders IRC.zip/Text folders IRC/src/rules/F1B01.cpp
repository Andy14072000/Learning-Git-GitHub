﻿/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 18-04-2023	| V1_0_0		| F1B01 - FIFTH WHEEL COUPLING RULES
==================================================================================================================*/

#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#include "F1B01.h"

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF1B01001		| Aniket Satpute	| MF1B01			| The coupling should be chosen wrt load requirements of the vehicle
===================================================================================================================*/
// UI DEFINITIONS
#define DLG_IRF1B01_001				"dlg_IR_F1B01_001"
#define OM_LOAD_CAPACITY			"load_capacity_option_menu"
#define PB_CANCEL					"CommitCancel"
#define PB_OK						"CommitOK"
#define PB_IMG						"rule_image"

int IRF1B01::IRF1B01_001(ruleResult &final_res)
{
	ruleLog.Write("==========================   IRF1B01::IRF1B01_001   ==========================");
	vector<IntAndStringlistMap> CouplingsList;
	int loadCapacity{};
	vector<ComponentData> compAsmNameList;
	SubModuleInfo _reqSMinfo;
	char cReqMdlPath[PRO_PATH_SIZE];
	ProPath wReqMdlPath;
	ProMdl reqMdl;
	ProModelitem reqMdlitem;
	ProParameter pLoadCapacity;
	ProParamvalue pvLoadCapacity;
	ProUnititem puLoadCapacity;
	ProName pLoadCapacityName =  L"LOAD_CAPACITY";

	for (int i = 0; i < subModulesList.size(); ++i){
		if(subModulesList[i].name.find("F1B01") != std::string::npos){
			_reqSMinfo = subModulesList[i];
			break;
		}
	}
	sprintf(cReqMdlPath, "%s%s.asm", cCurMdlPath, _reqSMinfo.name.c_str());
	ruleLog.Write("cReqMdlPath: "+string(cReqMdlPath));
	ProStringToWstring(wReqMdlPath, cReqMdlPath);
	status = ProMdlnameRetrieve(wReqMdlPath, PRO_MDLFILE_ASSEMBLY, &reqMdl);
	ruleLog.Write("ProMdlnameRetrieve: "+to_string(status));
	if(status != PRO_TK_NO_ERROR)
		return -1;

	// EXTRACT THE COMP NAMES
	status = ProSolidFeatVisit((ProSolid)reqMdl, getVisitedCompAsmNamesAction, compsFilter, (ProAppData)&compAsmNameList);
	ruleLog.Write("compAsmNameList.size(): " + to_string(compAsmNameList.size()));

	// EXTRACT THE LOAD CAPACITY FROM PARAMETER
	status = ProMdlToModelitem(reqMdl, &reqMdlitem);

	status = ProParameterInit(&reqMdlitem, pLoadCapacityName, &pLoadCapacity);
	ruleLog.Write("ProParameterInit: " + to_string(status));

	// create parameter if not found
	if(status == PRO_TK_E_NOT_FOUND)
	{
		int _val;
		status = ProParamvalueSet(&pvLoadCapacity, &_val, PRO_PARAM_INTEGER);
		ruleLog.Write("ProParamvalueSet: " + to_string(status));
		status = ProParameterWithUnitsCreate(&reqMdlitem, pLoadCapacityName, &pvLoadCapacity, NULL, &pLoadCapacity);
		ruleLog.Write("ProParameterWithUnitsCreate: " + to_string(status));
	}

	status = ProParameterValueWithUnitsGet(&pLoadCapacity, &pvLoadCapacity, &puLoadCapacity);
	ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status)+"\texisting loadCapacity: " + to_string(pvLoadCapacity.value.i_val));

	vector<vector<string>> dbList2D = getData2D("IRF1B01001.csv");
	ruleLog.Write("dbList2D.size(): "+ to_string(dbList2D.size()));

	for(int i = 1; i< dbList2D.size(); ++i)	// i = 1 for skipping the headers
	{
		string tok1;
		std::istringstream ss1(dbList2D[i][0]);
		while (std::getline(ss1, tok1, ';')) 
		{
			IntAndStringlistMap _temp;
			//ruleLog.Write("tok1: "+trimString(tok1));
			// load capacity
			_temp.intval = stoi(tok1);		

			// assigned part numbers
			std::istringstream ss2(dbList2D[i][1]);
			string tok2;
			while (std::getline(ss2, tok2, ';')){
				//ruleLog.Write("tok2: "+trimString(tok2));
				_temp.strList.push_back(tok2);
			}
			CouplingsList.push_back(_temp);
		}
	}
	/*bool isLoadCapacityFound = false;
	for(auto item : CouplingsList){
		if(item.loadCapacity == loadCapacity)
			isLoadCapacityFound = true;
	}*/

	// GET USER INPUT FOR LOAD CAPACITY
	status = ProUIDialogCreate(DLG_IRF1B01_001, DLG_IRF1B01_001);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF1B01_001, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF1B01_001, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF1B01_001, PB_OK, (ProUIAction)ruleDlgOKaction, NULL);
	string optionMenuActionData[2] = { PB_IMG,"IR_F1B01_001"};
	status = ProUIOptionmenuSelectActionSet(DLG_IRF1B01_001, OM_LOAD_CAPACITY, (ProUIAction)optionMenuImageChangeAction, (ProAppData)&optionMenuActionData);
	
	char **loadCapListNames;
	wchar_t **loadCapListLabels;
	status = ProArrayAlloc(CouplingsList.size(), sizeof(char *), 1, (ProArray *)&loadCapListNames);
	status = ProArrayAlloc(CouplingsList.size(), sizeof(wchar_t *), 1, (ProArray *)&loadCapListLabels);

	for (int i=0; i<CouplingsList.size(); ++i)
	{
		loadCapListNames[i] = (char *)calloc(5, sizeof(char));
		ProTKSprintf(loadCapListNames[i], "%d", CouplingsList[i].intval);

		loadCapListLabels[i] = (wchar_t *)calloc(5, sizeof(wchar_t));
		ProStringToWstring(loadCapListLabels[i], loadCapListNames[i]);
	}
	status = ProUIOptionmenuNamesSet (DLG_IRF1B01_001, OM_LOAD_CAPACITY, int(CouplingsList.size()), loadCapListNames);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet (DLG_IRF1B01_001, OM_LOAD_CAPACITY, int(CouplingsList.size()), loadCapListLabels);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

	status = ProUIPushbuttonBitmapSet(DLG_IRF1B01_001, PB_IMG, "IR_F1B01_001/30.png");	// default image
	ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));

	status = ProArrayFree((ProArray*)&loadCapListNames);
	status = ProArrayFree((ProArray*)&loadCapListLabels);

	status = ProUIDialogActivate(DLG_IRF1B01_001, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	// check for user quits in close_action
	if(isUserQuits){
		status = ProUIDialogDestroy(DLG_IRF1B01_001);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		return -1;
	}

	int n_sel;
	char **selCapacity;
	status = ProUIOptionmenuSelectednamesGet(DLG_IRF1B01_001, OM_LOAD_CAPACITY, &n_sel, &selCapacity);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	loadCapacity = stoi(selCapacity[0]);
	ruleLog.Write("Selected Capacity = " + to_string(loadCapacity));

	// MODIFY THE PARAMETER
	status = ProParameterInit(&reqMdlitem, L"LOAD_CAPACITY", &pLoadCapacity);
	ruleLog.Write("ProParameterInit: " + to_string(status));
	status = ProParamvalueSet(&pvLoadCapacity, &loadCapacity, PRO_PARAM_INTEGER);
	ruleLog.Write("ProParamvalueSet: " + to_string(status));
	status = ProParameterValueWithUnitsSet(&pLoadCapacity, &pvLoadCapacity, &puLoadCapacity);
	ruleLog.Write("ProParameterValueWithUnitsSet: " + to_string(status));

	string coupling_name;
	bool couplingFound = false;

	for(auto item : CouplingsList)
	{
		if(item.intval == loadCapacity)
		{
			ruleLog.Write("Std. Couplings:");
			for (auto comp_name : item.strList)
			{
				ruleLog.Write("\t"+comp_name);
	
				// remarks (acceptance criteria)
				acceptance_criteria.append(comp_name + ".asm, ");
	
				// check if the coupling is present in the model or not.
				for (int i = 0; i< compAsmNameList.size(); ++i){
					string currentPartNameCAD = compAsmNameList[i].name;
					ruleLog.Write("Found Couplings: " +string(currentPartNameCAD.c_str()));
					if(strcmp(currentPartNameCAD.c_str(), comp_name.c_str()) == 0){
						couplingFound = true;
						coupling_name += comp_name + ".asm";
						break;
					}
					
				}
			}
			break;
		}
	}

	// DECLARE RESULT
	if(!couplingFound){
		final_res.result = "FAIL";
		sprintf(remark, "The Std. Couplings are not present; Acceptance criteria: %s", acceptance_criteria.c_str());
	}
	else{
		final_res.result = "PASS";
		sprintf(remark, "Found Coupling no. = %s ; Acceptance criteria: %s", coupling_name.c_str(), acceptance_criteria.c_str());
	}
	final_res.remark = string(remark);

	ruleLog.Write("status: "+string(final_res.result));
	ruleLog.Write("remark: "+string(final_res.remark));

	status = ProUIDialogDestroy(DLG_IRF1B01_001);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

	return 0;
	
}
#pragma pop
