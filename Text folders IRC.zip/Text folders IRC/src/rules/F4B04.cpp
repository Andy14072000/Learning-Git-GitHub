#include "F4B04.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES | DESCRIPTION
------------------------------------------------------------------------------------------------------------------
IR-F4B04-002	| MATHANPRASATH A	| MF4B04	| Standard Shock Absorber Interface configuration to Frame and Axle Attachment across platform as per Application
===================================================================================================================*/
#define dlg_IR_F4B04_002     "dlg_IR_F4B04_002" 
#define PB_SELECT		     "select_pb"
#define PB_SELECT_2		     "select_pb_2"
#define PB_CANCEL		     "CommitCancel" 
#define PB_OK			     "CommitOK"

vector<double>dia_frame;
vector<double> dia_axle;
string remarkF4B04;
vector<string> name_asmAxle; 
vector<string> name_asmFrame;

boolean frameEndMatchBool1_F4B04 = FALSE;
boolean axleEndMatchBool1_F4B04 = FALSE;

int IRF4B04::IRF4B04_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF4B04::IRF4B04_002   ==========================");
	dia_frame.clear();
	dia_axle.clear();

	boolean frameEndMatchBool = FALSE;
	boolean	axleEndMatchBool = FALSE;
	frameEndMatchBool = FALSE;
	axleEndMatchBool = FALSE;

	vector<string> resultFrameEnd;
	vector<string> resultAxleEnd;

	for (int i = 0; i < subModulesList.size(); ++i) {
		if (subModulesList[i].name.find("F4B04") != string::npos) {
			_reqSMinfo = subModulesList[i];
			break;
		}
	}

	project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
	ruleLog.Write("Project Code: " + to_string(project_code));

	vector<string> reqValsFromCsv1, reqValsFromCsv2;
	getReqValsFrom2DCsvData("IRF4B04002.csv", 2, 3, project_code, reqValsFromCsv1);
	getReqValsFrom2DCsvData("IRF4B04002.csv", 2, 4, project_code, reqValsFromCsv2);

	if (reqValsFromCsv1.size() == 0 && reqValsFromCsv2.size() == 0)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Project Code not found. \nPlease update the CSV.");
		return 0;
	}

	isUserQuits = false;
	status = ProUIDialogCreate(dlg_IR_F4B04_002, dlg_IR_F4B04_002);
	status = ProUIDialogAboveactivewindowSet(dlg_IR_F4B04_002, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(dlg_IR_F4B04_002, PB_SELECT, (ProUIAction)select_action_IRF4B04_002, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(dlg_IR_F4B04_002, PB_SELECT_2, (ProUIAction)select_action_IRF4B04_002_2, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(dlg_IR_F4B04_002, PB_OK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(dlg_IR_F4B04_002, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(dlg_IR_F4B04_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(dlg_IR_F4B04_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	ruleLog.Write("dia_frame_F4A04: " + to_string(dia_frame.size()));
	ruleLog.Write("dia_axle_F4A04: " + to_string(dia_axle.size()));

	for (int i = 0; i < reqValsFromCsv1.size(); ++i)
	{
		for (int j = 0; j < dia_frame.size(); ++j)
		{
			ruleLog.Write("reqValsFromCsv1 = " + reqValsFromCsv1[i]);
			ruleLog.Write("Dia of the frame boult :" + to_string(dia_frame.at(j)));

			if (stod(reqValsFromCsv1[i]) == dia_frame[j])
			{
				//frontEndMatch.push_back(dia_frame[j]);
				ruleLog.Write("inside = " + (reqValsFromCsv1[i]));
				ruleLog.Write("inside = " + to_string(dia_frame[j]));
				frameEndMatchBool = TRUE;
				ruleLog.Write("frontEndMatchBool = " + to_string(frameEndMatchBool));
				break;

			}
		}
	}

	for (int i = 0; i < reqValsFromCsv2.size(); ++i)
	{
		for (int j = 0; j < dia_axle.size(); ++j)
		{
			ruleLog.Write("reqValsFromCsv2 = " + reqValsFromCsv2[i]);
			ruleLog.Write("Dia of the axle boult :" + to_string(dia_axle.at(j)));

			if (stod(reqValsFromCsv2[i]) == dia_axle[j])
			{
				//axleEndMatch.push_back(dia_axle[j]);

				ruleLog.Write("inside = " + (reqValsFromCsv2[i]));
				ruleLog.Write("inside = " + to_string(dia_axle[j]));

				axleEndMatchBool = TRUE;
				ruleLog.Write("axleEndMatchBool = " + to_string(axleEndMatchBool));
				break;

			}
		}
	}
	ruleLog.Write("frameEndMatchBool1 = " + to_string(frameEndMatchBool));
	ruleLog.Write("axleEndMatchBool1 = " + to_string(axleEndMatchBool));

	///////////////
	remarkF4B04 += "Frame end :";
	remarkF4B04 += "\n1) Bolt size for " + name_asmFrame[0] + ".PRT = " + to_string(dia_frame[0]) + "mm";
	remarkF4B04 += "\n2) Bolt size for " + name_asmFrame[1] + ".PRT = " + to_string(dia_frame[1]) + "mm";
	remarkF4B04 += "\nFor Axle end :";
	remarkF4B04 += "\n1) Bolt size for " + name_asmAxle[0] + ".PRT = " + to_string(dia_axle[0]) + "mm";
	remarkF4B04 += "\n2) Bolt size for " + name_asmAxle[1] + ".PRT = " + to_string(dia_axle[1]) + "mm";
	//////////

	remarkF4B04 += "\n\nAcceptance Crietria: \nFor frame end(in mm) : ";
	for (int i = 0; i < reqValsFromCsv1.size(); i++)
	{
		remarkF4B04 += reqValsFromCsv1[i] + ".00, ";
	}
	remarkF4B04 += "\nAxle end(in mm) : ";
	for (int i = 0; i < reqValsFromCsv2.size(); i++)
	{
		remarkF4B04 += reqValsFromCsv2[i] + ".00, ";
	}

	if (axleEndMatchBool == TRUE && frameEndMatchBool == TRUE && frameEndMatchBool1_F4B04 == TRUE && axleEndMatchBool1_F4B04 == TRUE)
	{
		ruleLog.Write("PASS");
		final_res.result = "PASS";
		final_res.remark = remarkF4B04;
	}

	else
	{
		ruleLog.Write("FAIL");
		final_res.result = "FAIL";
		final_res.remark = remarkF4B04;
	}

	remarkF4B04.clear();
	dia_axle.clear();
	dia_frame.clear();
	name_asmAxle.clear();
	name_asmFrame.clear();
	frameEndMatchBool = FALSE;;
	axleEndMatchBool = FALSE;

	return 0;
}

ProError select_action_IRF4B04_002(char* dialog, char* component, ProAppData data)
{
	int num_sel;
	ProSelection* sel_frame;
	double dia_frame_1, dia_frame_2;
	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &sel_frame, &num_sel);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)
	{
		status = ProUIPushbuttonEnable(dialog, PB_SELECT_2);
		status = ProGeomitemDiameterEval(sel_frame[0], &dia_frame_1);
		ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status));

		status = ProGeomitemDiameterEval(sel_frame[1], &dia_frame_2);
		ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status));

		for (int i = 0; i < num_sel; i++)
		{

			ProModelitem part_model_item;
			ProName name;
			char str_name[PRO_NAME_SIZE];
			ProModelitem parent_model_item;
			ProParameter pDesc;
			ProParamvalue pvDesc;
			ProName pDescName = L"DESCRIPTION";
			string                  description;
			char existingPval[PRO_LINE_SIZE]{};

			status = ProSelectionModelitemGet(sel_frame[i], &part_model_item);
			ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

			status = ProMdlMdlnameGet(part_model_item.owner, name);
			ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

			ProWstringToString(str_name, name);
			ruleLog.Write("str_name = " + string(str_name));

			status = ProMdlToModelitem(part_model_item.owner, &parent_model_item);
			ruleLog.Write("ProMdlToModelitem: " + to_string(status));

			status = ProParameterInit(&parent_model_item, pDescName, &pDesc);
			ruleLog.Write("ProParameterInit status = " + to_string(status));
			if (status != PRO_TK_E_NOT_FOUND)
			{
				status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
				ruleLog.Write("ProParameterValueWithUnitsGet status = " + to_string(status));
				ProWstringToString(existingPval, pvDesc.value.s_val);
			}
			name_asmFrame.push_back(str_name);
		}

		ruleLog.Write(to_string(dia_frame_1));
		ruleLog.Write(to_string(dia_frame_2));

		dia_frame.push_back(dia_frame_1);
		dia_frame.push_back(dia_frame_2);

		if (dia_frame_1 == dia_frame_2)
		{
			frameEndMatchBool1_F4B04 = TRUE;
		}
		else
		{
			remarkF4B04 += "Bolt diameters for front end does not match\n";
		}
	}

	return status;
}

ProError select_action_IRF4B04_002_2(char* dialog, char* component, ProAppData data)
{
	double dia_axle_1, dia_axle_2;
	int num_sel;
	ProSelection* sel_axle;

	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &sel_axle, &num_sel);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)

	{
		status = ProUIPushbuttonEnable(dialog, PB_OK);
		status = ProGeomitemDiameterEval(sel_axle[0], &dia_axle_1);
		ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status));

		status = ProGeomitemDiameterEval(sel_axle[1], &dia_axle_2);
		ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status));

		for (int i = 0; i < num_sel; i++)
		{

			ProModelitem part_model_item;
			ProName name;
			char str_name[PRO_NAME_SIZE];
			ProModelitem parent_model_item;
			ProParameter pDesc;
			ProParamvalue pvDesc;
			ProName pDescName = L"DESCRIPTION";
			string                  description;
			char existingPval[PRO_LINE_SIZE]{};

			status = ProSelectionModelitemGet(sel_axle[i], &part_model_item);
			ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

			status = ProMdlMdlnameGet(part_model_item.owner, name);
			ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

			ProWstringToString(str_name, name);
			ruleLog.Write("str_name = " + string(str_name));

			status = ProMdlToModelitem(part_model_item.owner, &parent_model_item);
			ruleLog.Write("ProMdlToModelitem: " + to_string(status));

			status = ProParameterInit(&parent_model_item, pDescName, &pDesc);
			ruleLog.Write("ProParameterInit status = " + to_string(status));
			if (status != PRO_TK_E_NOT_FOUND)
			{
				status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
				ruleLog.Write("ProParameterValueWithUnitsGet status = " + to_string(status));
				ProWstringToString(existingPval, pvDesc.value.s_val);
			}
			name_asmAxle.push_back(str_name);

		}

		ruleLog.Write(to_string(dia_axle_1));
		ruleLog.Write(to_string(dia_axle_2));

		dia_axle.push_back(dia_axle_1);
		dia_axle.push_back(dia_axle_2);

		if (dia_axle_1 == dia_axle_2)
		{
			axleEndMatchBool1_F4B04 = TRUE;
		}
		else
		{
			remarkF4B04 += "Bolt diameters for rear end does not match\n";
		}

	}

	return status;
}
//
///*==================================================================================================================
//RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
//-------------------------------------------------------------------------------------------------------------------
//IR-F4B04-003	| Surendra Sarode	|  MF4B04	|
//===================================================================================================================*/
//#define DLG_IRF4B04_003 "dlg_IR_F4B04_003"
//#define PB_RSELECT      "pb_select"
//#define PB_RCANCEL       "CommitCancel"
//#define PB_OK           "pb_ok"
//#define spring_type "spring_type"
//#define PB_IMG1 "rule_img1"
//
//string type_Selected003 = "";
//ProSelection* surf_Sel_F4B04;
//bool isdistancematch3 = false;
//vector<double> reqvalfromcsvdouble3;
//double distance003;
//string rem_mes_003 = "";
//
//struct surfDataF4B04 {
//    string part_name;
//    int id;
//};
//
//int IRF4B04::IRF4B04_003(ruleResult& final_res)
//{
//    ruleLog.Write("==========================   IRF4B04::IRF4B04_003   ==========================");
//
//    /* your code goes here */
//    status = ProWindowRepaint(PRO_VALUE_UNUSED);
//    distance003 = 0;
//    reqvalfromcsvdouble3.clear();
//
//    type_Selected003 = "";
//    rem_mes_003 = "";
//    isdistancematch3 = false;
//    //ComponentData _reqComps[1]{};
//
//    //string reqCompSubMod[] = { "F4A02" };
//
//    //for (int i = 0; i < subModulesList.size(); ++i)
//    //	for (int j = 0; j < 1; ++j)
//    //		if (subModulesList[j].name.find(reqCompSubMod[j]) != string::npos)
//    //			strcpy(_reqComps[j].name, subModulesList[j].name.c_str());
//
//    //project_code = stoi(string(_reqComps[0].name).substr(0, 4));
//    //ruleLog.Write("Project Code:" + to_string(project_code));
//
//    //vector<string> reqvalfromcsv;
//    //getReqValsFrom2DCsvData("IRF4A02005.csv", 2, 3, project_code,reqvalfromcsv);
//    //
//    //if (reqvalfromcsv.size() == 0) {
//    //	UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", "The Project code is not available in the database.");
//    //	return 0;
//    //}
//
// //   for (auto val : reqvalfromcsv) {
// //       ruleLog.Write("val:" + val);
// //   }
//
//    isUserQuits = false;
//    status = ProUIDialogCreate(DLG_IRF4B04_003, DLG_IRF4B04_003);
//    ruleLog.Write("ProUIDialogCreate" + to_string(status));
//    status = ProUIDialogAboveactivewindowSet(DLG_IRF4B04_003, PRO_B_FALSE);
//    ruleLog.Write("ProUIDialogAboveactivewindowSet" + to_string(status));
//    status = ProUIPushbuttonActivateActionSet(DLG_IRF4B04_003, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
//    ruleLog.Write("ProUIPushbuttonActivateActionSet" + to_string(status));
//    status = ProUIPushbuttonActivateActionSet(DLG_IRF4B04_003, PB_OK, (ProUIAction)run_action_IRF4B04003, NULL);
//    ruleLog.Write("ProUIPushbuttonActivateActionSet" + to_string(status));
//    status = ProUIPushbuttonActivateActionSet(DLG_IRF4B04_003, PB_RSELECT, (ProUIAction)select_action_IRF4B04003, NULL);
//    ruleLog.Write("ProUIPushbuttonActivateActionSet" + to_string(status));
//    status = ProUIDialogHide(DLG_IRC_MAIN);
//    ruleLog.Write("ProUIDialogHide: " + to_string(status));
//    status = ProUIPushbuttonDisable(DLG_IRF4B04_003, PB_RSELECT);
//    ruleLog.Write("ProUIPushbuttonDisable" + to_string(status));
//    status = ProUIPushbuttonDisable(DLG_IRF4B04_003, PB_OK);
//    ruleLog.Write("ProUIPushbuttonDisable" + to_string(status));
//
//    string optionMenuActionData[2] = { PB_IMG1,"IR_F4B04_003" };
//    status = ProUIOptionmenuSelectActionSet(DLG_IRF4B04_003, spring_type, (ProUIAction)optionMenuImageChangeAction_F4B04003, (ProAppData)&optionMenuActionData);
//
//    // Create a drop down selection menu
//    char** type_of_susp_names;
//    wchar_t** type_of_susp_labels;
//    vector<string> type_of_susp_vec;
//    type_of_susp_vec = { "Select","Leaf","Coil", "Air", "Pneumatic" };
//
//    status = ProArrayAlloc(type_of_susp_vec.size(), sizeof(char*), 1, (ProArray*)&type_of_susp_names);
//    //ruleLog.Write("ProArrayAlloc names " + to_string(status));
//    status = ProArrayAlloc(type_of_susp_vec.size(), sizeof(wchar_t*), 1, (ProArray*)&type_of_susp_labels);
//    //ruleLog.Write("ProArrayAlloc lables" + to_string(status));
//
//    for (int i = 0; i < type_of_susp_vec.size(); ++i)
//    {
//        type_of_susp_names[i] = (char*)calloc(10, sizeof(char));
//        ProTKSprintf(type_of_susp_names[i], "%s", type_of_susp_vec[i]);
//
//        type_of_susp_labels[i] = (wchar_t*)calloc(10, sizeof(wchar_t));
//        ProStringToWstring(type_of_susp_labels[i], type_of_susp_names[i]);
//    }
//
//    status = ProUIOptionmenuNamesSet(DLG_IRF4B04_003, spring_type, int(type_of_susp_vec.size()), type_of_susp_names);
//    ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
//    status = ProUIOptionmenuLabelsSet(DLG_IRF4B04_003, spring_type, int(type_of_susp_vec.size()), type_of_susp_labels);
//    ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));
//    status = ProUIPushbuttonBitmapSet(DLG_IRF4B04_003, PB_IMG1, "IR_F4B04_003/Select.png");    // default image
//   //ruleLog.Write("ProUIPushbuttonBitmapSet rule: " + to_string(status));
//
//    status = ProUIDialogActivate(DLG_IRF4B04_003, &dlg_sts);
//    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
//    ruleLog.Write("dlg_sts: " + to_string(dlg_sts));
//    status = ProArrayFree((ProArray*)&type_of_susp_names);
//    ruleLog.Write("ProArrayFree: " + to_string(status));
//    status = ProArrayFree((ProArray*)&type_of_susp_labels);
//    ruleLog.Write("ProArrayFree: " + to_string(status));
//
//
//    // check for user quits in close_action
//    if (isUserQuits) {
//        status = ProUIDialogDestroy(DLG_IRF4B04_003);
//        ruleLog.Write("ProUIDialogDestroy close action: " + to_string(status));
//        status = ProUIDialogShow(DLG_IRC_MAIN);
//        return -1;
//    }
//
//    //Close after rule run
//    status = ProUIDialogDestroy(DLG_IRF4B04_003);
//    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
//    status = ProUIDialogShow(DLG_IRC_MAIN);
//
//    if (isdistancematch3) {
//        final_res.result = "PASS";
//        final_res.remark = rem_mes_003;
//    }
//    else {
//        final_res.result = "FAIL";
//        final_res.remark = rem_mes_003;
//    }
//
//    ruleLog.Write("status: " + final_res.result);
//    ruleLog.Write("remark: " + final_res.remark);
//
//    reqvalfromcsvdouble3.clear();
//
//    return 0;
//}
//ProError select_action_IRF4B04003(char* dialog, char* component, ProAppData data)
//{
//    ruleLog.Write("--------------------------  select_action_IRF2D01_002  --------------------------");
//
//    int n_sels;
//
//    status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surf_Sel_F4B04, &n_sels);
//    ruleLog.Write("ProSelect: " + to_string(status));
//
//    if (status == PRO_TK_USER_ABORT) {
//        status = ProUIPushbuttonDisable(DLG_IRF4B04_003, PB_OK);
//        return status;
//    }
//    if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
//        _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
//        status = ProUIPushbuttonDisable(DLG_IRF4B04_003, PB_OK);
//        return status;
//    }
//
//
//    if (n_sels > 0 && n_sels == 2) {
//        status = ProUIPushbuttonEnable(DLG_IRF4B04_003, PB_OK);
//        return status;
//    }
//
//    return status;
//}
//ProError optionMenuImageChangeAction_F4B04003(char* dialog, char* component, ProAppData data)
//{
//    ruleLog.Write("----------------------------- optionMenuImageChangeActionF4A02005 -----------------------------");
//
//    status = ProUIPushbuttonDisable(DLG_IRF4B04_003, PB_OK);
//    ruleLog.Write("ProUIPushbuttonDisable " + to_string(status));
//
//    char** selValue;
//    string* reqData = (string*)data;
//    int n_sel;
//    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
//    ruleLog.Write("ProUIOptionmenuSelectednamesGet cb fn: " + to_string(status));
//    ruleLog.Write("selValue1 = " + string(selValue[0]));
//    type_Selected003.erase();
//    type_Selected003.append(selValue[0]);
//    ruleLog.Write("Type of suspension selected = " + type_Selected003);
//
//    char imgName[PRO_NAME_SIZE], cPbName[PRO_NAME_SIZE];
//    ProTKSprintf(imgName, "%s/%s.png", reqData[1], selValue[0]);
//    ruleLog.Write("imgName = " + string(imgName));
//
//    strcpy(cPbName, reqData[0].c_str());
//    ruleLog.Write("cPbName = " + string(cPbName));
//    status = ProUIPushbuttonBitmapSet(dialog, cPbName, imgName);
//    ruleLog.Write("ProUIPushbuttonBitmapSet cb fn: " + to_string(status));
//
//
//    if (strcmp(selValue[0], "Select"))
//    {
//        ProUIPushbuttonDisable(DLG_IRF4B04_003, PB_RSELECT);
//        ProUIPushbuttonDisable(DLG_IRF4B04_003, PB_OK);
//    }
//
//    if (strcmp(selValue[0], "Air") == 0 || strcmp(selValue[0], "Pneumatic") == 0 || strcmp(selValue[0], "Coil") == 0)
//    {
//        ruleLog.Write("----------------------------- (AIR/HYDROPNEUMATIC/COIL)-----------------------------");
//        ProUIMessageButton* button;
//        ProUIMessageButton user_choice;
//        ProArrayAlloc(1, sizeof(ProUIMessageButton), 1, (ProArray*)&button);
//        button[0] = PRO_UI_MESSAGE_OK;
//
//        status = ProUIPushbuttonDisable(DLG_IRF4B04_003, PB_RSELECT);
//        ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));
//        status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Attention!!",
//            L"The rule is not applicable for this type of suspension", button, PRO_UI_MESSAGE_OK, &user_choice);
//        ruleLog.Write("ProUIMessageDialogDisplay status: " + to_string(status));
//        if (user_choice == PRO_UI_MESSAGE_OK)
//        {
//            status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Attention!!",
//                L"Please Click on 'OK' to execute the rule", button, PRO_UI_MESSAGE_OK, &user_choice);
//            status = ProUIPushbuttonEnable(DLG_IRF4B04_003, PB_OK);
//        }
//    }
//    else
//    {
//        ruleLog.Write("Else condition");
//        status = ProUIPushbuttonEnable(DLG_IRF4B04_003, PB_RSELECT);
//        ruleLog.Write("ProUIPushbuttonEnable status: " + to_string(status));
//    }
//
//    ProStringarrayFree(selValue, n_sel);
//    return status;
//}
//ProError run_action_IRF4B04003(char* dialog, char* component, ProAppData data)
//{
//    surfDataF4B04 surfdata;
//    vector<surfDataF4B04> part_data;
//    ProCharPath remark{};
//    InterfaceRule irc;
//    Utils utl;
//    if (type_Selected003 == "Leaf")
//    {
//        ComponentData _reqComps[1]{};
//        string reqCompSubMod[] = { "F4B02" };
//
//        ruleLog.Write("subModulesList.size():" + to_string(subModulesList.size()));
//
//        for (int i = 0; i < subModulesList.size(); ++i) {
//            for (int j = 0; j < subModulesList.size(); ++j) {
//                if (subModulesList[j].name.find(reqCompSubMod[j]) != string::npos)
//                    strcpy(_reqComps[j].name, subModulesList[j].name.c_str());
//            }
//        }
//
//        int project_code = stoi(string(_reqComps[0].name).substr(0, 4));
//        ruleLog.Write("Project Code:" + to_string(project_code));
//
//        vector<string> reqvalfromcsv;
//        utl.getReqValsFrom2DCsvData("IRF4B04003.csv", 2, 3, project_code, reqvalfromcsv);
//
//        if (reqvalfromcsv.size() == 0) {
//            utl.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", "The Project code is not available in the database.");
//            status = ProUIPushbuttonDisable(DLG_IRF4B04_003, PB_OK);
//            return status;
//        }
//
//        for (auto val : reqvalfromcsv) {
//            ruleLog.Write("val:" + val);
//        }
//
//        for (int i = 0; i < reqvalfromcsv.size(); ++i) {
//            reqvalfromcsvdouble3.push_back(stod(reqvalfromcsv.at(i)));
//        }
//
//
//        status = irc.measureDistanceBetweenSurfaces(surf_Sel_F4B04[0], surf_Sel_F4B04[1], distance003);
//        ruleLog.Write("measureDistanceBetweenSurfaces: " + to_string(status));
//        if (status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT) {
//            _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selected surfaces.");
//            return status;
//        }
//
//
//        for (int i = 0; i < reqvalfromcsvdouble3.size(); ++i) {
//            if (utl.compareFloat(distance003, reqvalfromcsvdouble3.at(i))) {
//                isdistancematch3 = true;
//                break;
//            }
//        }
//
//        //Get the id of selected surfaces
//        for (int i = 0; i < 2; ++i) {
//            ProMdlName		wname;
//            char            cname[PRO_MDLNAME_SIZE];
//            ProFeature feature;
//
//            status = ProSelectionModelitemGet(surf_Sel_F4B04[i], &feature);
//            status = ProMdlMdlnameGet(feature.owner, wname);
//            ProWstringToString(cname, wname);
//
//            surfdata.part_name = cname;
//            surfdata.id = feature.id;
//            part_data.push_back(surfdata);
//            ruleLog.Write("surfdata.id: " + to_string(surfdata.id));
//        }
//
//        sort(reqvalfromcsvdouble3.begin(), reqvalfromcsvdouble3.end());
//
//        sprintf(remark, " \nMeasured Spring track : %.2lfmm", distance003);
//        rem_mes_003 += remark;
//
//        rem_mes_003 += "\n\nFollowing are the applicable spring track values: ";
//
//
//        if (reqvalfromcsvdouble3.size() > 4) {
//            for (int i = 0; i < 4; ++i)
//            {
//                sprintf(remark, "%.2lfmm, ", reqvalfromcsvdouble3[i]);
//                rem_mes_003 += remark;
//            }
//            rem_mes_003 += " \n";
//            for (int i = 4; i < reqvalfromcsvdouble3.size(); ++i)
//            {
//                sprintf(remark, "%.2lfmm, ", reqvalfromcsvdouble3[i]);
//                rem_mes_003 += remark;
//            }
//        }
//        else
//        {
//            for (int i = 0; i < reqvalfromcsvdouble3.size(); i++)
//            {
//                sprintf(remark, "%.2lfmm, ", reqvalfromcsvdouble3[i]);
//                rem_mes_003 += remark;
//            }
//        }
//
//
//        rem_mes_003 += "\n\nUsed reference part: " + part_data[0].part_name + ".PRT" + " (Surf ID:" + to_string(part_data[0].id) + ")";
//        rem_mes_003 += "\nUsed reference part: " + part_data[1].part_name + ".PRT" + " (Surf ID:" + to_string(part_data[1].id) + ")";
//    }
//
//
//    if (type_Selected003 == "Air" || type_Selected003 == "Pneumatic" || type_Selected003 == "Coil")
//    {
//        rem_mes_003 += "The Rule is not applicable for this type of suspension.\nHence Passed.";
//        rem_mes_003 += "\nType of Suspension Selected: " + type_Selected003;
//        isdistancematch3 = true;
//    }
//
//    part_data.clear();
//
//    ruleLog.Write("=========run action end=========");
//    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
//}
#pragma pop