/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 29-06-2023	| V1_0_0		| F5A01 - BRAKING SYSTEM RULES
==================================================================================================================*/
#include "F5A01.h"

#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES                 | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F5A01-001	| Surendra Sarode	| MF5A01; MF5A02; MF1A01; MF2A01    |  Clearance between frame and foundation brake module should be 50 mm minimum.
===================================================================================================================*/

#define DLG_IRF5A01_001  "dlg_IR_F5A01_001"
#define PB_RSELECT       "rule_select_pb"
#define PB_RCANCEL      "CommitCancel"
#define PB_ROK			"pb_ok"


ProSelection* surface_Sel;
double output_clearance_val[2];
ComponentData	reqComps_f5a01_001[4]{};
//MF1A01-frame assm
//MF5A01- foundn break - Forwardword
//MF5A02- foundn break-rearword
int IRF5A01::IRF5A01_001(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF5A01::IRF5A01_001   ==========================");

    double MinValue = 50.0;

    string reqCompSubModAuto[4] = { "F1A01","F5A01","F5A02", "F2A01" };
    for (int i = 0; i < subModulesList.size(); ++i) {
        for (int j = 0; j < sizeof(reqCompSubModAuto) / sizeof(reqCompSubModAuto[0]); ++j) {
            if (subModulesList[i].name.find(reqCompSubModAuto[j]) != string::npos) {
                strcpy(reqComps_f5a01_001[j].name, subModulesList[i].name.c_str());
            }
        }
    }
    status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&reqComps_f5a01_001);
    for (auto elem : reqComps_f5a01_001) {
        ruleLog.Write("reqComps_f5a07_002[].name = " + string(elem.name));
        ruleLog.Write("reqComps_f5a07_002[].id = " + to_string(elem.id));
    }

    isUserQuits = false;

    status = ProUIDialogCreate(DLG_IRF5A01_001, DLG_IRF5A01_001);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF5A01_001, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A01_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A01_001, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF5A01_001, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF5A01_001);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    //_utils.UserDisplayPopupMessage_OK_CANCEL(PROUIMESSAGE_INFO, "Message Window", "Measuring the distance... Please wait for around 60 min !");

    ProUIMessageButton* buttons;
    ProUIMessageButton user_choice;
    ProArrayAlloc(2, sizeof(ProUIMessageButton), 1, (ProArray*)&buttons);
    buttons[0] = PRO_UI_MESSAGE_OK;
    buttons[1] = PRO_UI_MESSAGE_CANCEL;

    wchar_t wTitle[PRO_NAME_SIZE], wMsg[PRO_PATH_SIZE];
    char cTitle[PRO_NAME_SIZE] = "Message Window";
    char cMsg[PRO_PATH_SIZE] = "Please avoid closing the application as the clearance measurement may take a little longer.\nYou will be notified once the rule execution is complete.\n\nClick OK to continue... ";
    ProStringToWstring(wTitle, cTitle);
    ProStringToWstring(wMsg, cMsg);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogHide(DLG_IRF5A01_001);

    status = ProUIMessageDialogDisplay(PROUIMESSAGE_INFO, wTitle, wMsg, buttons, buttons[0], &user_choice);
    mainLog.Write("ProUIMessageDialogDisplay: " + to_string(status));

    status = ProUIDialogActivate(DLG_IRF5A01_001, &dlg_sts);
    status = ProUIDialogDestroy(DLG_IRF5A01_001);
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (user_choice == PRO_UI_MESSAGE_CANCEL) return -1;
    ProArrayFree((ProArray*)&buttons);

    // Clearance between components (automatic)
    rule_sts = measureDistanceBetweenComponents(reqComps_f5a01_001[0], reqComps_f5a01_001[1], output_clearance_val[0]); // F5A01
    rule_sts = measureDistanceBetweenComponents(reqComps_f5a01_001[0], reqComps_f5a01_001[2], output_clearance_val[1]); // F5A02

    // rounding the values to one decimal place
    for (int i = 0; i < sizeof(output_clearance_val) / sizeof(output_clearance_val[0]); ++i)
        output_clearance_val[i] = round(output_clearance_val[i] * 10) / 10;

    //DECLARE RESULT
    sprintf(remark, "Clearance between %s.asm and,\n%s.asm : %0.1fmm, \n%s.asm : %0.1fmm,\n\nAcceptance criteria: Clearance between frame and foundation brake module should be 50 mm minimum.", string(reqComps_f5a01_001[0].name), string(reqComps_f5a01_001[1].name), output_clearance_val[0], string(reqComps_f5a01_001[2].name), output_clearance_val[1]);
    final_res.remark = string(remark);

    ruleLog.Write("First Measured Value: " + to_string(output_clearance_val[0]));
    ruleLog.Write("Second Measured Value: " + to_string(output_clearance_val[1]));

    if (output_clearance_val[0] >= MinValue && output_clearance_val[0] >= MinValue)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    return 0;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5A01_004     | Prajakta Bhelawe	| MF5A01; MF5B01;	| Clearance between valve tube & brake drum of foundation brake module should be 5 mm minimum.
===================================================================================================================*/
#define DLG_IRF5A01_004 "dlg_IR_F5A01_004"
#define PB_RCANCEL      "CommitCancel"
#define PB_RSELECT		"pb_select"
#define PB_ROK			"pb_ok"
#define PB_IMG			"pb_img"

struct PartNames1
{
    char part_name[PRO_NAME_SIZE];
    char description[PRO_PATH_SIZE];
};

vector<string> targetStr_valveTube = { "TUBE", "TUBE ASSY", "TUBE ASSY WITH VALVE", "TUBE ASSY,CENTRALLY MTD TUBE VALVE", "TUBE TYPE TYRE,TR13", "TUBE TYPE TYRE,TR15", "TUBE WITH VALVE", "TUBE WITH VALVE & CAP", "TUBE - OFFER DRG", "VALVE", "VALVE ASSY", "VALVE ASSY,TUBELESS TYRE" };

ProMdl MdlF5A01;
int models_cnt1_F5A01;
int	owner_feat_id1_F5A01;
Asm_model1_F5A01 models_004[1000];
Asm_model1_F5A01 Assy_models_004[1000];
int level1_F5A01;
int	Assy_models_cnt1_F5A01;
int model_count1_F5A01;
vector<feat_id_data1_F5A01> feat_id_data_arr_004;

ProSelection		p_selection_ValveTube;
ProSelection		p_selection_DrakeDrum;

pathVariables_F5A01 pathVar;
vector<ProSelection> p_sel;
string PartName_BrakeDrum{};
string PartName_ValveTube{};
string exsitingPvalspacesRemF5A01;

int IRF5A01::IRF5A01_004(ruleResult& final_prores)
{
    ruleLog.Write("==========================   IRF5A01::IRF5A01_004   ==========================");

    deleteDatumPoint("datum_PNT1");
    deleteDatumPoint("datum_PNT2");

    vector<PartNames1> reqComps1;
    double std_clearance_F5A01 = 5.00;
    isUserQuits = false;
    double clearanceVal_F5A01 = 0;
    Assy_models_cnt1_F5A01 = 0;
    vector<double> clearanceValVector;
    double minElement = 0;
    ProBoolean interf;
    Pro3dPnt coord[2];

    status = ProUIDialogCreate(DLG_IRF5A01_004, DLG_IRF5A01_004);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));
    status = ProUIDialogAboveactivewindowSet(DLG_IRF5A01_004, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A01_004, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A01_004, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF5A01_004, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF5A01_004);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    status = ProMdlCurrentGet(&MdlF5A01);
    ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));

    curMdl = MdlF5A01;
    level1_F5A01 = 1;
    models_cnt1_F5A01 = 1;
    models_004[0].Model = MdlF5A01;
    models_004[0].Model_feat_id = 0;

begin:
    for (int a = 0; a < models_cnt1_F5A01; a++)
    {
        owner_feat_id1_F5A01 = models_004[a].Model_feat_id;
        status = ProSolidFeatVisit((ProSolid)models_004[a].Model, (ProFeatureVisitAction)user_action_F5A01, compsFilter, (ProAppData)&reqComps1);
        ruleLog.Write("ProSolidFeatVisit status = " + to_string(status));
    }

    if (Assy_models_cnt1_F5A01 > 0) {
        ++level1_F5A01;

        for (int b = 0; b < Assy_models_cnt1_F5A01; ++b)
        {
            models_004[b].Model = Assy_models_004[b].Model;
            models_004[b].Model_feat_id = Assy_models_004[b].Model_feat_id;
        }
        models_cnt1_F5A01 = Assy_models_cnt1_F5A01;
        Assy_models_cnt1_F5A01 = 0;
        goto begin;
    }

    ruleLog.Write("model_count in asssmbly = " + to_string(model_count1_F5A01));

    for (int i = 0; i < p_sel.size(); i++)
    {
        status = ProFitClearanceCompute(p_sel[i], PRO_FIT_INCLUDE_NONE, p_selection_ValveTube, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearanceVal_F5A01, NULL, &interf, coord);
        ruleLog.Write("ProFitClearanceCompute = " + to_string(status) + "\ndistance = " + to_string(clearanceVal_F5A01));

        clearanceValVector.push_back(clearanceVal_F5A01);
    }

    //to get the minimum clearance
    minElement = *min_element(clearanceValVector.begin(), clearanceValVector.end());
    ruleLog.Write("Minimum Element = " + to_string(minElement));

    if (status != PRO_TK_NO_ERROR) {
        UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selected parts.");
        return -1;
    }

    sprintf(remark, " Clearance between %s.PRT and %s.PRT = %.2fmm; Acceptance criteria >=5.00mm.", PartName_BrakeDrum, PartName_ValveTube, minElement);
    ruleLog.Write("remark = " + string(remark));
    final_prores.remark = string(remark);

    if (minElement >= std_clearance_F5A01) {
        final_prores.result = "PASS";
        createDatumPoints(coord, "CSYS_ASM_DEF", "Dist_highlght_pnt");
        status = ProSelectionHighlight(p_selection_ValveTube, PRO_COLOR_SELECTED);
        ruleLog.Write("ProSelectionHighlight: " + to_string(status));

        status = ProSelectionHighlight(p_selection_DrakeDrum, PRO_COLOR_SELECTED);
        ruleLog.Write("ProSelectionHighlight: " + to_string(status));
    }
    else
    {
        final_prores.result = "FAIL";
        status = ProSelectionHighlight(p_selection_ValveTube, PRO_COLOR_SS_FAILED_ITEMS);
        ruleLog.Write("ProSelectionHighlight: " + to_string(status));

        status = ProSelectionHighlight(p_selection_DrakeDrum, PRO_COLOR_SS_FAILED_ITEMS);
        ruleLog.Write("ProSelectionHighlight: " + to_string(status));
    }

    final_prores.remark = string(remark);

    ruleLog.Write("status: " + final_prores.result);
    ruleLog.Write("remark: " + final_prores.remark);

    reqComps1.clear();
    clearanceValVector.clear();
    feat_id_data_arr_004.clear();
    p_sel.clear();
    PartName_ValveTube.clear();
    PartName_BrakeDrum.clear();
    exsitingPvalspacesRemF5A01.clear();

    return 0;
}

ProError user_action_F5A01(ProFeature* p_feature, ProError status, ProAppData appdata)
{
    vector<PartNames1>* prtname_list = (vector<PartNames1>*)appdata;

    char existingPval[PRO_LINE_SIZE]{};
    ProMdlfileType			comp_type;
    ProFamilyMdlName		comp_name;
    char					part_no[PRO_PATH_SIZE];
    ProMdl					model;
    ProFeattype				ftype;

    status = ProFeatureTypeGet(p_feature, &ftype);
    ruleLog.Write("ProFeatureTypeGet status = " + to_string(status));
    ruleLog.Write(to_string(ftype));

    if (ftype == PRO_FEAT_COMPONENT)
    {
        ProMdlType				type;

        ruleLog.Write(" Component Level = " + to_string(level1_F5A01));
        status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
        ruleLog.Write("ProAsmcompMdlMdlnameGet status = " + to_string(status));

        ProWstringToString(part_no, comp_name);
        ruleLog.Write("ProMdlName = " + string(part_no));

        ++model_count1_F5A01;

        status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
        ruleLog.Write("ProAsmcompMdlGet status  =  " + to_string(status));
        status = ProMdlTypeGet(model, &type);
        ruleLog.Write("ProMdlTypeGet status  =  " + to_string(status));

        ProBoolean is_hidden;

        status = ProModelitemIsHidden((ProModelitem*)p_feature, &is_hidden);
        ruleLog.Write("ProModelitemIsHidden: " + to_string(status));

        string is_hiddenStr = to_string(is_hidden);
        ruleLog.Write("Is Hidden = " + is_hiddenStr);

        if (is_hiddenStr == "0")
        {
            feat_id_data1_F5A01  _feat_id_data;
            if (level1_F5A01 == 1) {

                _feat_id_data.feat_ids[0] = p_feature->id;
                _feat_id_data.level = level1_F5A01;

                feat_id_data_arr_004.push_back(_feat_id_data);
            }
            else {
                for (int j = 0; j < feat_id_data_arr_004.size(); ++j) {

                    if (feat_id_data_arr_004[j].feat_ids[level1_F5A01 - 2] == owner_feat_id1_F5A01) {

                        feat_id_data1_F5A01	owner_feat_id_data = feat_id_data_arr_004[j];

                        for (int i = 0; i < level1_F5A01 - 1; ++i) {
                            _feat_id_data.feat_ids[i] = owner_feat_id_data.feat_ids[i];
                        }
                        _feat_id_data.feat_ids[level1_F5A01 - 1] = p_feature->id;
                        _feat_id_data.level = level1_F5A01;
                        break;
                    }
                }
                feat_id_data_arr_004.push_back(_feat_id_data);
            }

            wchar_t wFeatName[PRO_NAME_SIZE];
            char cFeatName[PRO_NAME_SIZE];
            ProModelitem modelItem;
            ProParameter pDesc;
            ProParamvalue pvDesc;
            ProName pDescName = L"DESCRIPTION";
            string                  description;

            status = ProMdlMdlnameGet(model, wFeatName);

            ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
            ProWstringToString(cFeatName, wFeatName);

            status = ProMdlToModelitem(model, &modelItem);
            ruleLog.Write("ProMdlToModelitem: " + to_string(status));

            status = ProParameterInit(&modelItem, pDescName, &pDesc);
            ruleLog.Write("ProParameterInit: " + to_string(status));

            if (status != PRO_TK_E_NOT_FOUND)
            {
                status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
                ruleLog.Write("ProParameterValueWithUnitsGet : " + to_string(status));

                ProWstringToString(existingPval, pvDesc.value.s_val);

                ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval + "Feature ID = " + to_string(p_feature->id));
                exsitingPvalspacesRemF5A01 = remSpacesAtBothEnds_F5A01(existingPval);
            }

            description.append(exsitingPvalspacesRemF5A01);
            ruleLog.Write(description);
            const regex p("(BRAKE DRUM)");

            if ((regex_search(description, p) != 0))
            {
                ruleLog.Write("------------------------inside brakedrum if------------------------");
                ProIdTable			comp_id_table{};
                int table_num;
                ProAsmcomppath		p_comp_path;

                table_num = level1_F5A01;

                ruleLog.Write("table_num =  " + to_string(table_num));
                pathVar.table_num_Vector.push_back(table_num);

                for (int m = 0; m < level1_F5A01; ++m) {
                    comp_id_table[m] = _feat_id_data.feat_ids[m];
                    ruleLog.Write("comp_id_table[] =  " + to_string(m) + "  " + to_string(comp_id_table[m]));
                }

                ProMdl curMdl;
                status = ProMdlCurrentGet(&curMdl);

                status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
                ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

                status = ProSelectionAlloc(&p_comp_path, &modelItem, &p_selection_DrakeDrum);
                ruleLog.Write("ProSelectionAlloc: " + to_string(status));
                ruleLog.Write("Part Name = " + string(cFeatName));
                PartName_BrakeDrum = cFeatName;
                p_sel.push_back(p_selection_DrakeDrum);
            }

            ruleLog.Write("targetStr_valveTube size = " + to_string(targetStr_valveTube.size()));
            for (int i = 0; i < targetStr_valveTube.size(); i++)
            {
                ruleLog.Write("------------------------inside targetStr_valveTube FOR------------------------");

                ruleLog.Write("targetStr_valveTube = " + targetStr_valveTube[i]);
                ruleLog.Write("existingPval = " + string(existingPval));

                string existingPvalStr = existingPval;
                existingPvalStr.erase(existingPvalStr.find_last_not_of(" \n\r\t") + 1); // Trim right
                existingPvalStr.erase(0, existingPvalStr.find_first_not_of(" \n\r\t")); // Trim left

                if (targetStr_valveTube[i] == (existingPvalStr))
                {
                    ruleLog.Write("------------------------inside targetStr_valveTube if------------------------");
                    int feature_ID = p_feature->id;
                    ruleLog.Write("Feature ID = " + to_string(feature_ID) + "Description = +" + existingPval);

                    ProIdTable			comp_id_table;
                    int table_num;
                    ProAsmcomppath		p_comp_path;
                    table_num = level1_F5A01;

                    ruleLog.Write("table_num =  " + to_string(table_num));

                    for (int m = 0; m < level1_F5A01; ++m) {
                        comp_id_table[m] = _feat_id_data.feat_ids[m];
                        ruleLog.Write("comp_id_table[] =  " + to_string(m) + "  " + to_string(comp_id_table[m]));
                    }
                    ProMdl curMdl;
                    status = ProMdlCurrentGet(&curMdl);

                    status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
                    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

                    status = ProSelectionAlloc(&p_comp_path, &modelItem, &p_selection_ValveTube);
                    ruleLog.Write("ProSelectionAlloc: " + to_string(status));
                    ruleLog.Write("Part Name = " + string(cFeatName));
                    PartName_ValveTube = cFeatName;
                }
            }

            if (type == PRO_MDL_ASSEMBLY)
            {
                Assy_models_004[Assy_models_cnt1_F5A01].Model = model;
                Assy_models_004[Assy_models_cnt1_F5A01].Model_feat_id = p_feature->id;
                Assy_models_cnt1_F5A01 += 1;
            }
        }
    }

    return PRO_TK_NO_ERROR;
}

string remSpacesAtBothEnds_F5A01(const string& str) {
    mainLog.Write("================= Utils::remSpacesAtBothEnds ==================");
    string strVal = str;
    if (str.empty())
        strVal;
    size_t start = strVal.find_first_not_of(" \t\n");
    if (start != string::npos) {
        strVal = strVal.substr(start);
    }
    size_t end = strVal.find_last_not_of(" \t\n");
    if (end != string::npos) {
        strVal = strVal.substr(0, end + 1);
    }
    return strVal;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	                                | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F5A01-007    | Himanshu Pachpute	| MF5A01; MF5A02; MF5A03; MF5A04; MF5A05; MF5A06	| Brake drum diameter to be fixed as per tonnage range.
===================================================================================================================*/

#define DLG_IRF5A01_007 "dlg_IR_F5A01_007" 
#define LOAD_CAPACITY	"tonnage"
#define PB_RSELECT		"select_pb"
#define PB_CANCEL		"CommitCancel" 
#define PB_OK			"CommitOK"

string          tonnes;
ProSelection* surf_selection;
int             n_sels;

int IRF5A01::IRF5A01_007(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF5A01::IRF5A01_007   ==========================");

    vector<BrakeDrumTonnage> TonnageDiaList;
    bool rightvalue = false;

    vector<vector<string>> F5A01007 = getData2D("IRF5A01007.csv");
    ruleLog.Write("F5A01007.size(): " + to_string(F5A01007.size()));

    for (int i = 1; i < F5A01007.size(); ++i)
    {
        BrakeDrumTonnage temp;
        temp.CapacityTon = F5A01007[i][1];
        ruleLog.Write("CapacityTon: " + F5A01007[i][1]);

        temp.Diainmm = stoi(F5A01007[i][2]);
        ruleLog.Write("Diainmm: " + F5A01007[i][2]);

        TonnageDiaList.push_back(temp);
    }

    status = ProUIDialogCreate(DLG_IRF5A01_007, DLG_IRF5A01_007);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF5A01_007, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A01_007, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    //status = ProUIDialogCloseActionSet(DLG_IRF5A01_007, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A01_007, PB_OK, (ProUIAction)ruleDlgOKaction, NULL);
    status = ProUIOptionmenuSelectActionSet(DLG_IRF5A01_007, LOAD_CAPACITY, (ProUIAction)Dropdown_action_IRF5A01007, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A01_007, PB_RSELECT, (ProUIAction)select_action_IRF5A01007, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIPushbuttonDisable(DLG_IRF5A01_007, PB_OK);
    status = ProUIPushbuttonDisable(DLG_IRF5A01_007, PB_RSELECT);

    char** Tonnage_names;
    wchar_t** Tonnage_labels;

    status = ProArrayAlloc(TonnageDiaList.size(), sizeof(char*), 1, (ProArray*)&Tonnage_names);
    ruleLog.Write("ProArrayAlloc: " + to_string(status));

    status = ProArrayAlloc(TonnageDiaList.size(), sizeof(wchar_t*), 1, (ProArray*)&Tonnage_labels);
    ruleLog.Write("ProArrayAlloc: " + to_string(status));

    for (int i = 0; i < TonnageDiaList.size(); ++i)
    {
        Tonnage_names[i] = (char*)calloc(50, sizeof(char));
        strcpy(Tonnage_names[i], TonnageDiaList[i].CapacityTon.c_str());

        Tonnage_labels[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
        ProStringToWstring(Tonnage_labels[i], Tonnage_names[i]);
    }

    status = ProUIOptionmenuNamesSet(DLG_IRF5A01_007, LOAD_CAPACITY, int(TonnageDiaList.size()), Tonnage_names);
    ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));

    status = ProUIOptionmenuLabelsSet(DLG_IRF5A01_007, LOAD_CAPACITY, int(TonnageDiaList.size()), Tonnage_labels);
    ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

    status = ProArrayFree((ProArray*)&Tonnage_names);
    ruleLog.Write("ProArrayFree: " + to_string(status));

    status = ProArrayFree((ProArray*)&Tonnage_labels);
    ruleLog.Write("ProArrayFree: " + to_string(status));

    if (isUserQuits) {
        status = ProUIDialogDestroy(DLG_IRF5A01_007);
        ruleLog.Write("ProUIDialogDestroy close action: " + to_string(status));

        status = ProUIDialogShow(DLG_IRC_MAIN);
        ruleLog.Write("ProUIDialogShow: " + to_string(status));
        return -1;
    }

    status = ProUIDialogActivate(DLG_IRF5A01_007, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));

    status = ProUIDialogDestroy(DLG_IRF5A01_007);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

    status = ProUIDialogShow(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogShow: " + to_string(status));

    int foundvalue{};
    for (const BrakeDrumTonnage& Ton : TonnageDiaList) {
        if (Ton.CapacityTon == tonnes) {
            ruleLog.Write("Ton.Diainmm: " + to_string(Ton.Diainmm));
            foundvalue = Ton.Diainmm;
        }
    }

    vector<int> dias{};
    string measured_vals = "Selected Tonnnage Range:" + tonnes + "\nNo. of Selections: " + to_string(n_sels) + "\n\nMeasured values\n";
    for (int i = 0; i < n_sels; i++)
    {
        ProGeomitem feature;
        status = ProSelectionModelitemGet(surf_selection[i], &feature);
        ruleLog.Write("ProUIDialogHide: " + to_string(status));

        int ID1 = feature.id;

        ProMdl surf_item_owner;
        status = ProModelitemMdlGet(&feature, &surf_item_owner);
        ruleLog.Write("ProModelitemMdlGet: " + to_string(status));

        ProModelitem p_modelitem;
        status = ProMdlToModelitem(surf_item_owner, &p_modelitem);
        ruleLog.Write("ProMdlToModelitem: " + to_string(status));

        int ID2 = p_modelitem.id;

        ProAsmcomppath asm_comp_path;
        status = ProSelectionAsmcomppathGet(surf_selection[i], &asm_comp_path);
        ruleLog.Write("ProSelectionAsmcomppathGet: " + to_string(status));

        int lastCompID = -1;
        for (int k = 0; k < asm_comp_path.table_num; ++k) {
            ruleLog.Write("comp_id_table[" + to_string(k) + "]: " + to_string(asm_comp_path.comp_id_table[k]));
            lastCompID = asm_comp_path.comp_id_table[k];
        }

        ruleLog.Write("lastCompID: " + to_string(lastCompID));

        ProSelection p_selection{};
        status = ProSelectionAlloc(&asm_comp_path, &p_modelitem, &p_selection);
        ruleLog.Write("ProSelectionAlloc: " + to_string(status));

        ProMdlName wname;
        status = ProMdlMdlnameGet(surf_item_owner, wname);;
        ruleLog.Write("ProModelitemMdlGet: " + to_string(status));

        char model_name[PRO_MDLNAME_SIZE];
        ProWstringToString(model_name, wname);
        ruleLog.Write("ProWstringToString: " + string(model_name));

        double Dia{};
        status = ProGeomitemDiameterEval(surf_selection[i], &Dia);
        ruleLog.Write("ProGeomitemDiameterEval = " + to_string(status) + "\t" + "Diameters: " + to_string(Dia));

        
        string formattedValue = doubleToString(Dia);
        ruleLog.Write("formattedNumber: " + formattedValue);
        dias.push_back(round(Dia));

        measured_vals += "\t" + string(model_name) + " (" + to_string(lastCompID) + ")" + ": " + formattedValue + "mm\n";

        if (dias[i] != foundvalue)
        {
            status = ProSelectionHighlight(p_selection, PRO_COLOR_SS_FAILED_ITEMS);
            ruleLog.Write("ProSelectionHighlight: " + to_string(status));
        }
    }

    measured_vals += "\nAcceptance criteria according to Tonnage Range: " + to_string(foundvalue) + "mm";

    ruleLog.Write("dias.size(): " + to_string(dias.size()));

    for (int l = 0; l < dias.size(); l++) {
        if (dias[l] != foundvalue) {
            rightvalue = true;
            break;
        }
    }

    if (!isUserQuits)
        final_res.remark = measured_vals;

    if (rightvalue == false && !isUserQuits)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    TonnageDiaList.clear();
    dias.clear();

    return 0;
}

ProError Dropdown_action_IRF5A01007(char* dialog, char* component) {

    ruleLog.Write("----------------------------- Dropdown_action_IRF5A01007 -----------------------------");

    int n_sel;
    char** selValue;

    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
    ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
    ruleLog.Write("selValue = " + string(selValue[0]));

    tonnes = selValue[0];
    status = ProUIPushbuttonEnable(DLG_IRF5A01_007, PB_RSELECT);
    ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));

    return status;
}

ProError select_action_IRF5A01007(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- select_action_IRF5A01007 -----------------------------");

    surf_selection = nullptr;

    int curWinId;
    status = ProWindowCurrentGet(&curWinId);
    ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

    status = ProWindowRepaint(curWinId);
    ruleLog.Write("ProWindowRepaint: " + to_string(status));

    status = ProUIDialogHide(DLG_IRF5A01_007);
    ruleLog.Write("ProUIDialogHide: " + to_string(status));

    status = ProSelect((char*)"surface", -1, NULL, NULL, NULL, NULL, &surf_selection, &n_sels);
    ruleLog.Write("Proselect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sels));

    if (status == PRO_TK_USER_ABORT) {

        status = ProUIDialogShow(DLG_IRF5A01_007);
        ruleLog.Write("ProUIDialogShow: " + to_string(status));

        status = ProUIPushbuttonDisable(DLG_IRF5A01_007, PB_OK);
        ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));
        return status;
    }

    status = ProUIDialogShow(DLG_IRF5A01_007);
    ruleLog.Write("ProUIDialogShow: " + to_string(status));

    if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
        InterfaceRule _irule;
        _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
        status = ProUIPushbuttonDisable(DLG_IRF5A01_007, PB_OK);
        ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));
        return status;
    }

    status = ProUIPushbuttonEnable(DLG_IRF5A01_007, PB_OK);
    ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));

    status = ProUIPushbuttonDisable(DLG_IRF5A01_007, LOAD_CAPACITY);
    ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));

    return status;
}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES                     	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F5A01-005 	| Himanshu Pachpute	| MF5A01; MF5A02; MF5A04; MF5A05; MF2C01    | Clearance between propeller shaft module and foundation brake module should be 50 mm min.
===================================================================================================================*/

//Changed to IR-F5A04-001
//int IRF5A01::IRF5A01_005(ruleResult &final_res)
//{
//    ruleLog.Write("==========================   IRF5A01::IRF5A01_005   ==========================");
//
//    /* your code goes here */
//
//    return 0;
//}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES                     	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F5A01-006	| MATHANPRASATH A	| MF5A01; MF5A02; MF5A04; MF5A05; MH2D01    | Clearance between axle housing module and foundation brake module should be 50 mm minimum..
===================================================================================================================*/

#define dlg_IR_F5A01_006     "dlg_IR_F5A01_006" 
#define PB_CANCEL		     "CommitCancel" 
#define PB_OK			     "CommitOK"

int    f5A01_ModelsCount09{}, f5A01_AsmModelCount09{}, f5A01_NoOfAsmFixed09{},
       f5A01_MdlCount09{},f5A01_OwnerFeatID09{},f5A01_Levels09{},a, tarrayf5a27006[100] = { 0 }; // Initialize all elements to 0 (or any default value);
vector<string>                  slack_adjuster, slack_adjust_desc, Carrier_head, status_F5A01_006;
vector<ProModelitem>            carriel_sel, slack_sel;
ProModelitem                    modelItem1;
ProSelection                    prt_sel, sel_Slack, sel_Carrier;
ProAsmcomppath                  asm_path;
vector<SelectionStruct>         carrier_SelectionInfo{}, slack_SelectionInfo{};
f5A01_AsmModelStr               AsmCModel[1000]{}, CModel[1000]{};
vector<FeatureIDdataStr>        FeatIDDataArr{};
ComponentData                   _reqCompsf5a27[2]{};
vector<int>                     ID_mapf5a27006;                         
double                          standardf5a27006 = 80.00, computedf5a27006;
string                          remf5a27006 = "", remark_msg_f5A01_006;
vector<ProSelection>            sel1f5A01006, sel2f5A01006, Sel_Cover_f5A01006, slack_selection, Carrier_selection;
vector<remark_info>             remark_vec, remark_cover;
vector<Model_Tree_Information>  treeInformationVectorf5a27, Selection_item1f5A01, Selection_item2f5A01, Selection_item3f5A01, Selection_itemCover;
vector< remark_info>            remark_final, Axle_Cover_final;

int IRF5A01::IRF5A01_006(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF5A01::IRF5A01_006  ==========================");
    //Clearing the vectors and string to avoid duplicate result.
    remark_msg_f5A01_006.clear();
    vector<PartnameDescriptionPair>Part_Desc;
    treeInformationVectorf5a27.clear();
    Selection_item1f5A01.clear();
    Selection_item2f5A01.clear();
    ID_mapf5a27006.clear();
    sel1f5A01006.clear();
    sel2f5A01006.clear();
    Part_Desc.clear();
    remark_vec.clear();
    remark_final.clear();
    Model_Tree_Information dis;

    //UI calls
    isUserQuits = false;
    status = ProUIDialogCreate(dlg_IR_F5A01_006, dlg_IR_F5A01_006);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));
    status = ProUIDialogAboveactivewindowSet(dlg_IR_F5A01_006, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(dlg_IR_F5A01_006, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(dlg_IR_F5A01_006, PB_OK, (ProUIAction)ruleDlgOKaction, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(dlg_IR_F5A01_006, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(dlg_IR_F5A01_006);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);
    if (isUserQuits)
        return -1;

    ProSelection* sel_part;
    int sel_num;

    ProBoolean  interf;
    double      distance, dist;
    Pro3dPnt    coord[2];
    ProModelitem part1, part2;
    ProMdl prt_mdl1, prt_mdl2;
    // level = 1;
    ID_mapf5a27006.clear();
    char name[PRO_MDLNAME_SIZE];
    char type[PRO_MDLEXTENSION_SIZE];
    ProError status;
    UserAppdata appdata;
    FILE* fp{};
    ProMdl p_asm;
    ProMdl reqMdlsair1hs, mdl;
    ProMdlName modelName;
    ProMdlExtension modelExtension;
    //double distance;
    int count = -1;
    Pro3dPnt pnt_arr[2];

    //int ex, tail, sil;
    boolean standard = true;
    ComponentData req_sub[10]{};
    string req_SubMod[10] = { "F5A01","F5A02","F5A03","F5A04","F5A05","F5A06","H2D01","H2D02" ,"H2B01" ,"H3A16" };

    for (int i = 0; i < 10; ++i)
    {

        for (int j = 0; j < subModulesList.size(); ++j)
        {
            ruleLog.Write(subModulesList[j].name);
            ruleLog.Write(req_SubMod[i]);
            if (subModulesList[j].name.find(req_SubMod[i]) != string::npos)
            {
                ruleLog.Write("1 :" + subModulesList[j].name + "2:" + req_SubMod[i]);
                strcpy(req_sub[i].name, subModulesList[j].name.c_str());
                break;
            }
        }
    }




    status = ProMdlCurrentGet(&p_asm);
    status = ProMdlMdlnameGet(p_asm, modelName);
    ProWstringToString(name, modelName);
    status = ProMdlExtensionGet(p_asm, modelExtension);
    ProWstringToString(type, modelExtension);


    appdata.fp = fp;
    appdata.level = 1;
    // visiting the modeltree
    status = ProSolidFeatVisit((ProSolid)p_asm, user_actionf5A01006, compsFilter, (ProAppData)&req_sub);
    ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
    /* for (int i = 0; i < treeInformationVectorf5a27.size(); i++)
     {
         ruleLog.Write("Sub-Module: " + treeInformationVectorf5a27[i].sub_mod_name + "Name: " + treeInformationVectorf5a27[i].name + " ID: " + to_string(treeInformationVectorf5a27[i].ID) + " Description: " + treeInformationVectorf5a27[i].description + " ID Path:");
         for (int id : treeInformationVectorf5a27[i].ID_path)
         {
             ruleLog.Write(to_string(id));
         }

     }*/

     //Separating the required parts to different vectors.
    ruleLog.Write("----------CarrierF5A01-----");
    for (int i = 0; i < treeInformationVectorf5a27.size(); i++)
    {
        if ((treeInformationVectorf5a27[i].description.find("COVER REAR") != std::string::npos) || (treeInformationVectorf5a27[i].description.find("REAR COVER") != std::string::npos))
        {
            string barel, standard;
            barel.erase();
            standard.append(treeInformationVectorf5a27[i].name);
            barel = standard.substr(8, 2);
            if (barel == "82")
            {
                Model_Tree_Information treeCover;
                //tree2.sub_mod_name = "F3B06 (Tail)";
                treeCover.name = string(treeInformationVectorf5a27[i].name);
                //tree2.extension = string(treeInformationVectorf5a27[i].extension);
                treeCover.ID = treeInformationVectorf5a27[i].ID;
                treeCover.description = treeInformationVectorf5a27[i].description;
                treeCover.ID_path = treeInformationVectorf5a27[i].ID_path;
                Selection_itemCover.push_back(treeCover);
            }

        }
        if ((treeInformationVectorf5a27[i].description.find("CARRIER HOUSING") != std::string::npos))
        {
            Model_Tree_Information tree2;
            //tree2.sub_mod_name = "F3B06 (Tail)";
            tree2.name = string(treeInformationVectorf5a27[i].name);
            //tree2.extension = string(treeInformationVectorf5a27[i].extension);
            tree2.ID = treeInformationVectorf5a27[i].ID;
            tree2.description = treeInformationVectorf5a27[i].description;
            tree2.ID_path = treeInformationVectorf5a27[i].ID_path;

            Selection_item1f5A01.push_back(tree2);
        }

        ruleLog.Write("----------SlackF5A01-----");
        if ((treeInformationVectorf5a27[i].description.find("AUTO SLACK ADJUSTER") != std::string::npos)
            || (treeInformationVectorf5a27[i].description.find("DRUM BRAKE ASSY") != std::string::npos))
        {
            string barrel, stand;
            stand.erase();
            stand.append(treeInformationVectorf5a27[i].name);
            barrel = stand.substr(8, 2);
            if (barrel == "01")
            {
                Model_Tree_Information tree2;
                //tree2.sub_mod_name = "F3B06 (Tail)";
                tree2.name = string(treeInformationVectorf5a27[i].name);
                //tree2.extension = string(treeInformationVectorf5a27[i].extension);
                tree2.ID = treeInformationVectorf5a27[i].ID;
                tree2.description = treeInformationVectorf5a27[i].description;
                tree2.ID_path = treeInformationVectorf5a27[i].ID_path;
                Selection_item2f5A01.push_back(tree2);
            }


        }

    }


    //Print the selection vector1 parts info
    ruleLog.Write("-----------Item1F5A01-----");
    ruleLog.Write("size1 =" + to_string(Selection_item1f5A01.size()));
    for (int i = 0; i < Selection_item1f5A01.size(); i++)
    {
        ruleLog.Write("Name: " + Selection_item1f5A01[i].name + " ID: " + to_string(Selection_item1f5A01[i].ID) + " Description: " + Selection_item1f5A01[i].description + " ID Path:");
        for (int id : Selection_item1f5A01[i].ID_path)
        {
            ruleLog.Write(to_string(id));
        }
    }

    //Print the selection vector2 parts info
    ruleLog.Write("-----------Item2F5A01-----");
    ruleLog.Write("size1 =" + to_string(Selection_item2f5A01.size()));
    for (int i = 0; i < Selection_item2f5A01.size(); i++)
    {
        ruleLog.Write("Name: " + Selection_item2f5A01[i].name + " ID: " + to_string(Selection_item2f5A01[i].ID) + " Description: " + Selection_item2f5A01[i].description + " ID Path:");
        for (int id : Selection_item2f5A01[i].ID_path)
        {
            ruleLog.Write(to_string(id));
        }
    }

    //Print the selection vector3 parts info
    ruleLog.Write("-----------Item3F5A01-----");
    ruleLog.Write("size1 =" + to_string(Selection_itemCover.size()));
    for (int i = 0; i < Selection_itemCover.size(); i++)
    {
        ruleLog.Write("Name: " + Selection_itemCover[i].name + " ID: " + to_string(Selection_itemCover[i].ID) + " Description: " + Selection_itemCover[i].description + " ID Path:");
        for (int id : Selection_itemCover[i].ID_path)
        {
            ruleLog.Write(to_string(id));
        }
    }

    //Assigning the selectionhandle to each parts in the vector1
    ruleLog.Write("-------------1stVector_SelectionInfo-------------");
    for (int i = 0; i < Selection_item1f5A01.size(); i++)
    {
        /*if (i == reference_idx)
        {
            continue;
        }*/
        ProIdTable id_table{};
        ProMdl reqMdlsair;
        ProName compair;
        ProModelitem featureair;
        // Create a character array with a size one larger than the string to accommodate the null terminator
        char charArray[100];

        // Copy the contents of the std::string to the character array
        strcpy(charArray, Selection_item1f5A01[i].name.c_str());
        ProStringToWstring(compair, charArray);

        /*if (Selection_itemsf5a27[i].extension.find("ASM") != std::string::npos)
        {
            status = ProMdlnameInit(compair, PRO_MDLFILE_ASSEMBLY, &reqMdlsair);
            ruleLog.Write("ProMdlnameInit status = " + to_string(status));
        }*/
        status = ProMdlCurrentGet(&reqMdlsair);
        ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));

        status = ProMdlnameInit(compair, PRO_MDLFILE_PART, &reqMdlsair);
        ruleLog.Write("ProMdlnameInit status = " + to_string(status));
        ruleLog.Write("Name: " + Selection_item1f5A01[i].name);
        status = ProMdlToModelitem(reqMdlsair, &featureair);
        ruleLog.Write("ProMdlToModelitem status = " + to_string(status));

        vector temp = Selection_item1f5A01[i].ID_path;
        int vectorSize = Selection_item1f5A01[i].ID_path.size();
        //tbl1_sizef5a27006 = vectorSize;

        for (int j = 0; j < vectorSize; ++j)
        {
            tarrayf5a27006[j] = temp[j];
        }

        // Print the elements in the array
        //std::cout << "Array elements:";

        for (int j = 0; j < vectorSize; ++j)
        {
            id_table[j] = tarrayf5a27006[j];
        }

        int id_1;
        for (int id : id_table)
        {
            ruleLog.Write(to_string(id));
            id_1 = id;

        }
        ProModelitem item;
        status = ProModelitemInit(reqMdlsair, id_1, PRO_PART, &item);
        ruleLog.Write("ProModelitemInit status = " + to_string(status));
        ProAsmcomppath pathair;
        ProSelection sel;
        ProMdl asm_mdl;
        ProMdlName asm_mdl_name;
        ProModelitem asm_mdl_item;

        char name[PRO_NAME_SIZE] = "";
        status = ProAsmcomppathInit((ProSolid)curMdl, id_table, vectorSize, &pathair);
        ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));

        status = ProAsmcomppathMdlGet(&pathair, &asm_mdl);
        ruleLog.Write("ProAsmcomppathMdlGet status = " + to_string(status));
        if (status != PRO_TK_NO_ERROR)
        {
            status = ProSelectionAlloc(&pathair, &featureair, &sel);
            ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
        }
        else
        {
            status = ProMdlMdlnameGet(asm_mdl, asm_mdl_name);
            ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));
            ProWstringToString(name, asm_mdl_name);
            ruleLog.Write("AsmCOMPname =" + string(name));
            status = ProMdlToModelitem(asm_mdl, &asm_mdl_item);
            ruleLog.Write("ProMdlToModelitem status = " + to_string(status));
            status = ProSelectionAlloc(&pathair, &asm_mdl_item, &sel);
            ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
        }



        sel1f5A01006.push_back(sel);
        /*status = ProSelectionHighlight(selaf1c02_004[i], PRO_COLOR_HIGHLITE);
        ruleLog.Write("ProSelectionHighlight status = " + to_string(status));*/

    }


    //Assigning the selectionhandle to each parts in the vector2
    ruleLog.Write("-------------2ndVector_SelectionInfo-------------");
    for (int i = 0; i < Selection_item2f5A01.size(); i++)
    {
        /*if (i == reference_idx)
        {
            continue;
        }*/
        ProIdTable id_table{};
        ProMdl reqMdlsair;
        ProName compair;
        ProModelitem featureair;
        // Create a character array with a size one larger than the string to accommodate the null terminator
        char charArray[100];

        // Copy the contents of the std::string to the character array
        strcpy(charArray, Selection_item2f5A01[i].name.c_str());
        ProStringToWstring(compair, charArray);

        /*if (Selection_itemsf5a27[i].extension.find("ASM") != std::string::npos)
        {
            status = ProMdlnameInit(compair, PRO_MDLFILE_ASSEMBLY, &reqMdlsair);
            ruleLog.Write("ProMdlnameInit status = " + to_string(status));
        }*/

        status = ProMdlnameInit(compair, PRO_MDLFILE_PART, &reqMdlsair);
        ruleLog.Write("ProMdlnameInit status = " + to_string(status));


        status = ProMdlToModelitem(reqMdlsair, &featureair);
        ruleLog.Write("ProMdlToModelitem status = " + to_string(status));

        vector temp = Selection_item2f5A01[i].ID_path;
        int vectorSize = Selection_item2f5A01[i].ID_path.size();
        //tbl1_sizef5a27006 = vectorSize;

        for (int j = 0; j < vectorSize; ++j)
        {
            tarrayf5a27006[j] = temp[j];
        }

        // Print the elements in the array
        //std::cout << "Array elements:";

        for (int j = 0; j < vectorSize; ++j)
        {
            id_table[j] = tarrayf5a27006[j];
        }

        ProAsmcomppath pathair;
        ProSelection sel;
        ProMdl asm_mdl;
        ProMdlName asm_mdl_name;
        ProModelitem asm_mdl_item;
        char name[PRO_NAME_SIZE] = "";
        status = ProAsmcomppathInit((ProSolid)curMdl, id_table, vectorSize, &pathair);
        ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));

        status = ProAsmcomppathMdlGet(&pathair, &asm_mdl);
        ruleLog.Write("ProAsmcomppathMdlGet status = " + to_string(status));

        if (status != PRO_TK_NO_ERROR)
        {
            status = ProSelectionAlloc(&pathair, &featureair, &sel);
            ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
        }
        else
        {
            status = ProMdlMdlnameGet(asm_mdl, asm_mdl_name);
            ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));
            ProWstringToString(name, asm_mdl_name);
            ruleLog.Write("AsmCOMPname =" + string(name));
            status = ProMdlToModelitem(asm_mdl, &asm_mdl_item);
            ruleLog.Write("ProMdlToModelitem status = " + to_string(status));
            status = ProSelectionAlloc(&pathair, &asm_mdl_item, &sel);
            ruleLog.Write("ProSelectionAlloc status = " + to_string(status));

        }
        sel2f5A01006.push_back(sel);

        /*status = ProSelectionHighlight(selaf1c02_004[i], PRO_COLOR_HIGHLITE);
        ruleLog.Write("ProSelectionHighlight status = " + to_string(status));*/

    }


    //Assigning the selectionhandle to each parts in the vector3
    ruleLog.Write("-------------CoverPart_SelectionInfo-------------");
    for (int i = 0; i < Selection_itemCover.size(); i++)
    {

        ProIdTable id_table{};
        ProMdl reqMdlsair;
        ProName compair;
        ProModelitem featureair;
        // Create a character array with a size one larger than the string to accommodate the null terminator
        char charArray[100];

        // Copy the contents of the std::string to the character array
        strcpy(charArray, Selection_itemCover[i].name.c_str());
        ProStringToWstring(compair, charArray);

        /*if (Selection_itemsf5a27[i].extension.find("ASM") != std::string::npos)
        {
            status = ProMdlnameInit(compair, PRO_MDLFILE_ASSEMBLY, &reqMdlsair);
            ruleLog.Write("ProMdlnameInit status = " + to_string(status));
        }*/
        status = ProMdlCurrentGet(&reqMdlsair);
        ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));

        status = ProMdlnameInit(compair, PRO_MDLFILE_PART, &reqMdlsair);
        ruleLog.Write("ProMdlnameInit status = " + to_string(status));
        ruleLog.Write("Name: " + Selection_itemCover[i].name);
        status = ProMdlToModelitem(reqMdlsair, &featureair);
        ruleLog.Write("ProMdlToModelitem status = " + to_string(status));

        vector temp = Selection_itemCover[i].ID_path;
        int vectorSize = Selection_itemCover[i].ID_path.size();
        //tbl1_sizef5a27006 = vectorSize;

        for (int j = 0; j < vectorSize; ++j)
        {
            tarrayf5a27006[j] = temp[j];
        }

        // Print the elements in the array
        //std::cout << "Array elements:";

        for (int j = 0; j < vectorSize; ++j)
        {
            id_table[j] = tarrayf5a27006[j];
        }

        int id_1;
        for (int id : id_table)
        {
            ruleLog.Write(to_string(id));
            id_1 = id;

        }
        ProModelitem item;
        status = ProModelitemInit(reqMdlsair, id_1, PRO_PART, &item);
        ruleLog.Write("ProModelitemInit status = " + to_string(status));
        ProAsmcomppath pathair;
        ProSelection sel;
        ProMdl asm_mdl;
        ProMdlName asm_mdl_name;
        ProModelitem asm_mdl_item;

        char name[PRO_NAME_SIZE] = "";
        status = ProAsmcomppathInit((ProSolid)curMdl, id_table, vectorSize, &pathair);
        ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));

        status = ProAsmcomppathMdlGet(&pathair, &asm_mdl);
        ruleLog.Write("ProAsmcomppathMdlGet status = " + to_string(status));
        if (status != PRO_TK_NO_ERROR)
        {
            status = ProSelectionAlloc(&pathair, &featureair, &sel);
            ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
        }
        else
        {
            status = ProMdlMdlnameGet(asm_mdl, asm_mdl_name);
            ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));
            ProWstringToString(name, asm_mdl_name);
            ruleLog.Write("AsmCOMPname =" + string(name));
            status = ProMdlToModelitem(asm_mdl, &asm_mdl_item);
            ruleLog.Write("ProMdlToModelitem status = " + to_string(status));
            status = ProSelectionAlloc(&pathair, &asm_mdl_item, &sel);
            ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
        }



        Sel_Cover_f5A01006.push_back(sel);
        status = ProSelectionHighlight(Sel_Cover_f5A01006[i], PRO_COLOR_HIGHLITE);
        ruleLog.Write("ProSelectionHighlight status = " + to_string(status));


    }

    string ss, ss1, ss2;
    string sp, sp2;
    string name_check1;
    string name_check2;
    string remark_msg1, remark_msg2;
    string ASA_loop, ASA_info;
    vector<string>closest_remark;
    remark_info remark_item;

    string sts;
    string check;

    //Information window and measuring the distance btwn Vec1 and Vec2
    remark_msg_f5A01_006 += "Measured value :";
    remark_msg_f5A01_006 += "clearance between\n";
    for (int c = 0; c < sel1f5A01006.size(); ++c)
    {
        check += "\n" + Selection_item1f5A01[c].name + ".PRT" + "-" + (Selection_item1f5A01[c].description) + " (" + to_string(Selection_item1f5A01[c].ID) + ") ";
        // name_check1 = Selection_item1f5A01[c].name + "." + Selection_item1f5A01[c].extension;
        ruleLog.Write("1 ");
        strcpy(remark_item.name_1, Selection_item1f5A01[c].name.c_str());
        strcat(remark_item.name_1, ".PRT");
        remark_item.desc_1 = Selection_item1f5A01[c].description;
        remark_item.re_id1 = Selection_item1f5A01[c].ID;
        remark_item.sel_1 = sel1f5A01006.at(c);
        // strcat(remark_item.name_1, Selection_item1f5A01[c].extension.c_str());
        for (int sl = 0; sl < sel2f5A01006.size(); sl++)
        {
            strcpy(remark_item.name_2, Selection_item2f5A01[sl].name.c_str());
            strcat(remark_item.name_2, ".PRT");
            remark_item.desc_2 = Selection_item2f5A01[sl].description;
            remark_item.re_id2 = Selection_item2f5A01[sl].ID;
            remark_item.sel_2 = sel2f5A01006.at(sl);
            ruleLog.Write("2");
            ProBoolean is_interference;
            Pro3dPnt pnt_[2];
            Pro2dPnt param1, param2;
            Pro3dPnt pnt1, pnt2;
            status = ProSelectionWithOptionsDistanceEval(sel1f5A01006.at(c), PRO_B_TRUE, sel2f5A01006.at(sl), PRO_B_TRUE, param1, param2, pnt1, pnt2, &distance);
            ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status));

            dis.distances = distance;
            string act_dis;
            act_dis = to_string(round(distance));
            act_dis.erase(act_dis.find_last_not_of('0') + 3);

            if (distance < 25)
            {
                sts = "FAIL";
                check += "&" + Selection_item2f5A01[sl].name + ".PRT" + "-" + (Selection_item2f5A01[sl].description) + " (" + to_string(Selection_item2f5A01[sl].ID) + ") " + " = " + act_dis + " (" + sts + " )\n";

                status = ProSelectionHighlight(sel1f5A01006.at(c), PRO_COLOR_HIGHLITE);
                ruleLog.Write("ProSelectionHighlight1: " + to_string(status));
                status = ProSelectionHighlight(sel2f5A01006.at(sl), PRO_COLOR_HIGHLITE);
                ruleLog.Write("ProSelectionHighlight2: " + to_string(status));
            }
            else
            {
                sts = "PASS";
                ruleLog.Write("-------------------------------------------------------------------------");
                ruleLog.Write("\n" + Selection_item1f5A01[c].name + ".PRT" + "-" + (Selection_item1f5A01[c].description) + " (" + to_string(Selection_item1f5A01[c].ID) + ") ");
                ruleLog.Write("&" + Selection_item2f5A01[sl].name + ".PRT" + "-" + (Selection_item2f5A01[sl].description) + " (" + to_string(Selection_item2f5A01[sl].ID) + ") " + " = " + act_dis + " (" + sts + " )\n");
                //ruleLog.Write("distance "+ to_string(d) +" :" + to_string(distances[d])); 
                check += "&" + Selection_item2f5A01[sl].name + ".PRT" + " (" + to_string(Selection_item2f5A01[sl].ID) + ") " + " = " + act_dis + " (" + sts + " )\n";
            }

            remark_item.dis_info = distance;
            remark_item.actual_clearance = act_dis;
            remark_item.status = sts;
            status_F5A01_006.push_back(sts);
            remark_vec.push_back(remark_item);
        }
        //sorting
        sort(remark_vec.begin(), remark_vec.end(), [](const remark_info& a, const remark_info& b)
            {
                return a.dis_info > b.dis_info;
            });
        //same distance value elements
        string copy_dis;
        for (int d = 0; d < remark_vec.size(); ++d)
        {
            copy_dis = remark_vec[d].actual_clearance;
        }
        for (auto rem_info : remark_vec)
        {

            ruleLog.Write("Remark vector name_1                 :" + string(rem_info.name_1));
            ruleLog.Write("Remark Vector Description_1          :" + string(rem_info.desc_1));
            ruleLog.Write("Remark vector id_1                   :" + to_string(rem_info.re_id1));
            ruleLog.Write("Remark vector name_2                 :" + string(rem_info.name_2));
            ruleLog.Write("Remark Vector Description_2          :" + string(rem_info.desc_2));
            ruleLog.Write("Remark vector id_2                   :" + to_string(rem_info.re_id2));
            ruleLog.Write("Remark vector actual _clearance      :" + string(rem_info.actual_clearance));
            ruleLog.Write("Remark vector distance               :" + to_string(rem_info.dis_info));

            if (copy_dis == rem_info.actual_clearance)
            {
                remark_final.push_back(rem_info);
            }
        }

        //storing the same distances parts
        double final_vec_size{};
        if (remark_final.size() > 1)
        {
            final_vec_size = remark_final.size();
        }
        ruleLog.Write("size of final vec : " + to_string(final_vec_size));



        status = ProSelectionHighlight(remark_final[c].sel_1, PRO_COLOR_SELECTED);
        ruleLog.Write("ProSelectionHighlight1: " + to_string(status));

        for (int m = 0; m < final_vec_size; m++)
        {

            status = ProSelectionHighlight(remark_final[m].sel_2, PRO_COLOR_SELECTED);
            ruleLog.Write("ProSelectionHighlight2: " + to_string(status));
            remark_msg_f5A01_006 += remark_final[m].name_1 + string("-") + (remark_final[m].desc_1) + "(" + to_string(remark_final[m].re_id1) + ")";
            remark_msg_f5A01_006 += "& " + string(remark_final[m].name_2) + string("-") + (remark_final[m].desc_2) + "(" + to_string(remark_final[m].re_id2) + ")" + " = " + remark_final[m].actual_clearance + " mm\n";
        }

        remark_msg_f5A01_006 += "\n";
        remark_vec.clear();
        remark_final.clear();
    }

    //Rear Axle Cover and ASA & Drum Brake parts Distance measurement
    string R_cover;
    remark_info rem_cover;
    R_cover += "Rear Axle Cover and Brake Drum/ Auto Slack Adjuster:clearance between\n";

    //Rear axle cover parts vector 
    for (int d = 0; d < Sel_Cover_f5A01006.size(); ++d)
    {
        strcpy(rem_cover.name_1, Selection_itemCover[d].name.c_str());
        strcat(rem_cover.name_1, ".PRT");
        rem_cover.desc_1 = Selection_itemCover[d].description;
        rem_cover.re_id1 = Selection_itemCover[d].ID;
        rem_cover.sel_1 = Sel_Cover_f5A01006.at(d);
        //ASA & Drum Brake parts Vector
        for (int sl = 0; sl < sel2f5A01006.size(); sl++)
        {
            strcpy(rem_cover.name_2, Selection_item2f5A01[sl].name.c_str());
            strcat(rem_cover.name_2, ".PRT");
            rem_cover.desc_2 = Selection_item2f5A01[sl].description;
            rem_cover.re_id2 = Selection_item2f5A01[sl].ID;
            rem_cover.sel_2 = sel2f5A01006.at(sl);
            ruleLog.Write("2");
            ProBoolean is_interference;
            Pro3dPnt pnt_[2];
            Pro2dPnt param1, param2;
            Pro3dPnt pnt1, pnt2;
            status = ProSelectionWithOptionsDistanceEval(Sel_Cover_f5A01006.at(d), PRO_B_TRUE, sel2f5A01006.at(sl), PRO_B_TRUE, param1, param2, pnt1, pnt2, &distance);
            ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status));
            dis.distances = distance;
            string act_dis;
            act_dis = to_string(round(distance));
            act_dis.erase(act_dis.find_last_not_of('0') + 3);

            if (distance < 25)
            {
                sts = "FAIL";
            }
            else
            {
                sts = "PASS";
            }

            rem_cover.dis_info = distance;
            rem_cover.actual_clearance = act_dis;
            rem_cover.status = sts;
            status_F5A01_006.push_back(sts);
            remark_cover.push_back(rem_cover);
        }

        //sorting rear cover & ASA Distance vector
        sort(remark_cover.begin(), remark_cover.end(), [](const remark_info& a, const remark_info& b)
            {
                return a.dis_info > b.dis_info;
            });
        //same distance value elements
        string copy_dis;
        for (int d = 0; d < remark_cover.size(); ++d)
        {
            copy_dis = remark_cover[d].actual_clearance;
        }
        for (auto rem_info : remark_cover)
        {

            ruleLog.Write("Axle Cover name_1                 :" + string(rem_info.name_1));
            ruleLog.Write("Axle Cover Description_1          :" + string(rem_info.desc_1));
            ruleLog.Write("Axle Cover id_1                   :" + to_string(rem_info.re_id1));
            ruleLog.Write("Axle Cover name_2                 :" + string(rem_info.name_2));
            ruleLog.Write("Axle Cover Description_2          :" + string(rem_info.desc_2));
            ruleLog.Write("Axle Cover id_2                   :" + to_string(rem_info.re_id2));
            ruleLog.Write("Axle Cover actual _clearance      :" + string(rem_info.actual_clearance));
            ruleLog.Write("Axle Cover distance               :" + to_string(rem_info.dis_info));

            if (copy_dis == rem_info.actual_clearance)
            {
                Axle_Cover_final.push_back(rem_info);
            }
        }
        ruleLog.Write("size of remark_final vec : " + to_string(Axle_Cover_final.size()));
        //storing the same distances parts
        double final_cover_size{};
        if (Axle_Cover_final.size() > 0)
        {
            final_cover_size = Axle_Cover_final.size();
        }
        ruleLog.Write("size of final vec : " + to_string(final_cover_size));

        for (int m = 0; m < final_cover_size; m++)
        {
            R_cover += Axle_Cover_final[m].name_1 + string("-") + (Axle_Cover_final[m].desc_1) + "(" + to_string(Axle_Cover_final[m].re_id1) + ")";
            R_cover += "& " + string(Axle_Cover_final[m].name_2) + string("-") + (Axle_Cover_final[m].desc_2) + "(" + to_string(Axle_Cover_final[m].re_id2) + ")" + " = " + Axle_Cover_final[m].actual_clearance + " mm\n";
        }

        R_cover += "\n";
        remark_cover.clear();
        Axle_Cover_final.clear();
    }
    R_cover += "Acceptance Criteria: Clearance between axle housing module and foundation brake module should be 25 mm minimum. ";
    for (int r = 0; r < status_F5A01_006.size(); ++r)
    {
        if (status_F5A01_006[r] == "FAIL")
        {
            final_res.result = "FAIL";
            break;
        }

        else
        {
            final_res.result = "PASS";

        }
    }
    final_res.remark = string(remark_msg_f5A01_006) + R_cover;

    ruleLog.Write(check);

    ruleLog.Write("\n\n" + remark_msg_f5A01_006 + R_cover);

    return 0;
}

ProError user_actionf5A01006(ProFeature* feature, ProError status, ProAppData appdata)
{
    FILE* fp;
    int level;
    ProMdl mdl27;
    char name27[PRO_MDLNAME_SIZE];
    char type[PRO_MDLEXTENSION_SIZE];
    UserAppdata* appd, appd1;
    ProMdlName modelName;
    ProMdlExtension modelExtension;
    ProAsmcomppath comppath;
    ProModelitem modelItem;
    char existingPval[PRO_NAME_SIZE]{};

    //ProModelitem p_item27;
    ProIdTable table;
    //table[0] = -1;
    //int ID;

    appd = (UserAppdata*)appdata;
    fp = appd->fp;
    level = appd->level;

    status = ProAsmcompMdlGet(feature, &mdl27);
    status = ProMdlMdlnameGet(mdl27, modelName);
    status = ProMdlExtensionGet(mdl27, modelExtension);

    ProWstringToString(name27, modelName);
    ProWstringToString(type, modelExtension);


    //if (strncmp(type, "ASM", 3) == 0 || strncmp(type, "PRT", 3))
    //{
    ID_mapf5a27006.push_back(feature->id);
    //component_path.push_back(ID_mapf2c01004);

    appd1.fp = appd->fp;
    appd1.level = appd->level + 1;

    //numberofasm++;

    ProMdlType subModuleMdlType;

    status = ProMdlTypeGet(mdl27, &subModuleMdlType);
    ruleLog.Write("ProMdlTypeGet status: " + to_string(status));
    if (subModuleMdlType == PRO_MDL_PART)
    {
        status = ProMdlToModelitem(mdl27, &modelItem);
        ruleLog.Write("ProMdlToModelitem: " + to_string(status));
        ProParameter pDesc;
        ProParamvalue pvDesc;
        ProName pDescName = L"DESCRIPTION";
        status = ProParameterInit(&modelItem, pDescName, &pDesc);
        ruleLog.Write("ProParameterInit: " + to_string(status));

        if (status == PRO_TK_NO_ERROR)
        {
            status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
            ProWstringToString(existingPval, pvDesc.value.s_val);

            ruleLog.Write("component Name :" + string(name27) + "." + string(type));
            ruleLog.Write("component Description :" + string(existingPval));
            if
                ((string(existingPval).find("CARRIER HOUSING") != std::string::npos)
                    || ((string(existingPval).find("AUTO SLACK ADJUSTER") != std::string::npos))
                    || ((string(existingPval).find("DRUM BRAKE ASSY") != std::string::npos))
                    || ((string(existingPval).find("COVER") != std::string::npos)))
            {
                Model_Tree_Information tree1;
                tree1.name = string(name27);
                //tree1.extension = string(type);
                tree1.ID = feature->id;
                tree1.description = existingPval;
                tree1.ID_path = ID_mapf5a27006;
                tree1.ID_table_size = ID_mapf5a27006.size();

                treeInformationVectorf5a27.push_back(tree1);
                ruleLog.Write("----------------------- Description Filter-------------------");
                ruleLog.Write("Name of assembly = " + string(name27) + " , ID = " + to_string(feature->id) + " , Description = " + existingPval);
                for (int id : tree1.ID_path)
                {
                    ruleLog.Write(to_string(id) + " ");
                }
                ruleLog.Write("----------------------- Description Filter End-------------------");
            }

            /**/
        }

    }


    status = ProSolidFeatVisit((ProSolid)mdl27, user_actionf5A01006, compsFilter, &appd1);
    ID_mapf5a27006.pop_back();
    //}
    return(PRO_TK_CONTINUE);
}

ProError F5A01_Typeget(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    ProMdlType subModuleMdlType;
    ProModelitem modelItem;
    ProMdl reqMdl;
    wchar_t wFeatName[PRO_NAME_SIZE];
    char cFeatName[PRO_NAME_SIZE];
    PartnameDescriptionPair compd;
    string asmname_substr;
    string asm_name;
    char existingPval[PRO_PATH_SIZE];

    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
    //ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
    status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
    //ruleLog.Write("ProMdlTypeGet: " + to_string(status));
    status = ProMdlMdlnameGet(reqMdl, wFeatName);
    //ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
    ProWstringToString(cFeatName, wFeatName);

    if (subModuleMdlType == PRO_MDL_ASSEMBLY)
    {
        ruleLog.Write("Assembly Name: ");
        ruleLog.Write(cFeatName);
        strcpy(compd.part_name, cFeatName);
        asm_name.erase();
        asm_name.append(compd.part_name);
        asmname_substr = asm_name.substr(4, 5);
        /*if (asmname_substr == "F4A01")
        {
            ruleLog.Write("-----------------------------F4A01_ getParameterDescAndPartname -----------------------------");
            ProSolidFeatVisit((ProSolid)reqMdl, getParameterDescAndPartname, compsFilter, (ProAppData)app_data);
        }*/

        if (asmname_substr == "H2D01")
        {
            ProSolidFeatVisit((ProSolid)reqMdl, F5A01_descget, compsFilter, (ProAppData)app_data);
        }
        // status = ProSolidFeatVisit((ProSolid)CModel[a].Model, (ProFeatureVisitAction)NameAndIdVisitAction, compsFilter, NULL);
    }
    return PRO_TK_NO_ERROR;
}

ProError F5A01_descget(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    vector<PartnameDescriptionPairM>* prtname_list = (vector<PartnameDescriptionPairM>*)app_data;
    ProMdlType subModuleMdlType;

    wchar_t wFeatName[PRO_NAME_SIZE];
    char cFeatName[PRO_NAME_SIZE];
    ProMdl reqMdl;
    char existingPval[PRO_PATH_SIZE];
    PartnameDescriptionPairM compd;
    string asm_name, asmname_substr;
    ProFeature asm_feat;
    ProAsmcomppath asm_path;
    bool Carrier_asm;
    ProBoolean res;

    /*status = ProGeomitemFeatureGet((ProGeomitem*)reqMdl, &asm_feat);
    ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id1 = " + to_string(asm_feat.id));
    */
    status = ProAsmcomppathInit(ProSolid(curMdl), &p_feature->id, 1, &asm_path);
    ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));

    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
    //  ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));

    status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
    // ruleLog.Write("ProMdlTypeGet: " + to_string(status));
    status = ProMdlMdlnameGet(reqMdl, wFeatName);
    //  ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
    ProWstringToString(cFeatName, wFeatName);
    status = ProMdlToModelitem(reqMdl, &modelItem1);
    ruleLog.Write("ProMdlToModelitem: " + to_string(status));
    ProBoolean is_visible;
    status = ProFeatureVisibilityGet(p_feature, &is_visible);
    if (is_visible == PRO_B_TRUE)
    {
        ProParameter pDesc;
        ProParamvalue pvDesc;
        ProName pDescName = L"DESCRIPTION";
        ProName pMatName = L"MATERIAL";
        status = ProParameterInit(&modelItem1, pDescName, &pDesc);
        ruleLog.Write("ProParameterInit: " + to_string(status));
        if (status == 0)
        {
            if (subModuleMdlType == PRO_MDL_ASSEMBLY)
            {
                /* ruleLog.Write("Assembly Name: ");
                 ruleLog.Write(cFeatName);*/
                status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
                ProWstringToString(existingPval, pvDesc.value.s_val);
                ruleLog.Write("ProParameterValueWithUnitsGet =" + to_string(status) + "\nAsm_Description: " + existingPval);
                ProSolidFeatVisit((ProSolid)reqMdl, F5A01_descget, compsFilter, (ProAppData)app_data);
            }

            //  const regex a("(CARRIER HOUSING)");
            if (subModuleMdlType == PRO_MDL_PART)
            {

                status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
                ProWstringToString(existingPval, pvDesc.value.s_val);
                ruleLog.Write("ProParameterValueWithUnitsGet =" + to_string(status));
                // const regex Slack("(SLACK ADJUSTER)");//ASSY
                const regex Carrier("(CARRIER HOUSING)");



                //if ((regex_search(existingPval, Slack) != 0))
                //{
                //    string barrel, stand;
                //    stand.erase();
                //    stand.append(cFeatName);
                //    barrel = stand.substr(8, 2);
                //    if (barrel == "01")
                //    {
                //        ruleLog.Write("Part Name: " + (string)cFeatName);
                //        slack_adjuster.push_back(cFeatName);
                //        ruleLog.Write("\nPart_Description: " + (string)existingPval);
                //        slack_adjust_desc.push_back(existingPval);
                //        slack_sel.push_back(modelItem);
                //        /*status = ProSelectionAlloc(NULL, &modelItem, &sel_Slack);
                //        ruleLog.Write("ProSelectionAlloc =" + to_string(status));
                //        status = ProSelectionHighlight(sel_Slack, PRO_COLOR_LETTER);
                //        ruleLog.Write("slack_adjuster ProSelectionHighlight =" + to_string(status));*/
                //    }
                //
               // }
                if ((regex_search(existingPval, Carrier) != 0))
                {
                    ProSelection sel2;
                    status = ProSelectionAlloc(NULL, &modelItem1, &sel2);
                    sel1f5A01006.push_back(sel2);
                    ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
                    ruleLog.Write("Part Name: " + (string)cFeatName);
                    Carrier_head.push_back(cFeatName);
                    carriel_sel.push_back(modelItem1);

                    /**/
                }


                /*if ((regex_search(existingPval, a) != 0))
                {
                    int id1, id2;

                    ProFeature part_feat1, axis_feat2;
                    ruleLog.Write("Part Name: ");
                    ruleLog.Write(cFeatName);
                    status = ProSelectionAlloc(NULL, &modelItem, &prt_sel);
                    ruleLog.Write("ProSelectionAlloc =" + to_string(status));

                    status = ProSelectionHighlight(prt_sel, PRO_COLOR_HIGHLITE);
                    ruleLog.Write("ProSelectionHighlight =" + to_string(status));
                    Carrier_asm = true;
                }*/

            }
        }

    }






    return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES                     	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F5A01-011	| Ved Aiyar         | MF5A01                                    | Mounting hole PCD for brake drum should be defined as per tonnage range
===================================================================================================================*/


#define DLG_IRF5A01_011 "dlg_IR_F5A01_011"
#define PB_SELECT       "select_pb"
#define PB_ROK			"CommitOK"
#define LOAD_CAPACITY   "select_option_menu_Load"
#define CATEGORY        "select_option_menu_category"
#define PB_RCANCEL      "CommitCancel"

struct BrakeDrumTonnageF5A01011
{
    string Platform;
    string CapacityTon;
    string Diainmm;
};



ProMdl Brakedrum;
vector<surfaceData>surfaceCollect;
vector<int> ID_MAP;
int tarrayf5a01[100] = { 0 }; // Initialize all elements to 0 (or any default value)
//vector<ProSelection*> selaf5a01;
ProSelection min_diam_sel;
ProSelection* sel_alloc1;
int sel_num = 0;
vector<double> hole_diam;
UserAppdata* appd2;
ProFeature* f_type;
int bd_check = 0;
ProSelection sel_alloc2;
//vector<ProSelection> surf_list;
vector<int>idTable;
vector<double> big_diam;
vector <double> PCD_Dis;
double PCD1;
string platformF5A01;
vector<string> optionMenuSpringTypes;
vector<string> Platforms;
std::vector<std::string> ILCVCapacityTon;
std::vector<std::string> MHCVCapacityTon;
vector<BrakeDrumTonnageF5A01011> TonnageDiaList;
vector<double> AcceptedStandardValues;
string standardf5a01;
string standardf5a01_cat;
string remf5a01;
string remark_f5a01;

Asm_model					models[1000];
int							models_cntF5A01011;
Asm_model					Assy_models[1000];
int							Assy_models_cntF5A01011;
int							num_of_assy_fixedF5A01011 = 0;
int							model_countF5A01011;
vector<feat_id_data>		feat_id_data_arr;
int							levelF5A01011;
int							owner_feat_idF5A01011;
ProMdl						curr_model;
int sel_F5A01_011;
string info_f5A01_011;

int IRF5A01::IRF5A01_011(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF5A01::IRF5A01_011   ==========================");
    Platforms.clear();
    TonnageDiaList.clear();
    ILCVCapacityTon.clear();
    MHCVCapacityTon.clear();
    info_f5A01_011.clear();
    remark_f5a01.clear();
    PCD_Dis.clear();

    SubModuleInfo _reqSMinfo;
    int n_sels;
    ProModelitem mode_dem;
    ProName MI_name;


    for (int i = 0; i < subModulesList.size(); ++i)
    {
        if (subModulesList[i].name.find("F5A01") != string::npos)
        {
            _reqSMinfo = subModulesList[i];
            break;
        }
    }

    project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
    ruleLog.Write("Sub-module Name: " + _reqSMinfo.name);
    ruleLog.Write("Project Code: " + to_string(project_code));

    InterfaceRule itr;
    bool rightvalue = false;

    vector<vector<string>> F5A01011 = itr.getData2D("IRF5A01011.csv");
    //ruleLog.Write("F5A01007.size(): " + to_string(F5A01011.size()));

    for (int i = 0; i < F5A01011.size(); ++i)
    {
        BrakeDrumTonnageF5A01011 temp;
        temp.Platform = F5A01011[i][0];
        temp.CapacityTon = F5A01011[i][1];
        temp.Diainmm = F5A01011[i][2];

        //ruleLog.Write(F5A01011[i][0] + "     " + F5A01011[i][1] + "     " + F5A01011[i][2]);

        TonnageDiaList.push_back(temp);
    }

    for (const auto& item : TonnageDiaList)
    {
        std::string combined = item.CapacityTon;
        optionMenuSpringTypes.push_back(combined);
    }

    Platforms.push_back("SELECT PLATFORM");
    Platforms.push_back("ILCV");
    Platforms.push_back("MHCV");

    // Insert "SELECT TONNAGE" as the first element of each vector
    ILCVCapacityTon.push_back("SELECT TONNAGE");
    MHCVCapacityTon.push_back("SELECT TONNAGE");

    // Populate the vectors based on Platform
    for (const auto& tonnage : TonnageDiaList) {
        if (tonnage.Platform.find("ILCV") != std::string::npos) {
            // If Platform contains "ILCV", add CapacityTon to ILCVCapacityTon vector
            ILCVCapacityTon.push_back(tonnage.CapacityTon);
        }
        else if (tonnage.Platform.find("MHCV") != std::string::npos) {
            // If Platform contains "MHCV", add CapacityTon to MHVCCapacityTon vector
            MHCVCapacityTon.push_back(tonnage.CapacityTon);
        }
    }



    status = ProUIDialogCreate(DLG_IRF5A01_011, DLG_IRF5A01_011);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF5A01_011, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A01_011, PB_RCANCEL, (ProUIAction)ruleDlgCloseActionf5a01011, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A01_011, PB_ROK, (ProUIAction)ruleDlgOKactionf5a01011, NULL);
    status = ProUIOptionmenuSelectActionSet(DLG_IRF5A01_011, CATEGORY, (ProUIAction)optionMenuImageChangeActionf5A01_category, NULL);
    status = ProUIOptionmenuSelectActionSet(DLG_IRF5A01_011, LOAD_CAPACITY, (ProUIAction)optionMenuImageChangeActionf5A01_load, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A01_011, PB_SELECT, (ProUIAction)select_action_IRF5A01_011, (ProAppData)&isUserQuits);

    status = ProUIPushbuttonDisable(DLG_IRF5A01_011, PB_ROK);
    status = ProUIOptionmenuDisable(DLG_IRF5A01_011, LOAD_CAPACITY);

    //if (standardf5a01 == "Tonnage Range")
    //{
    //    ruleLog.Write("TONNAGE RANGE SELECTED");
    //    itr.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning ", "Please Select a tonnage range");
    //    goto start; // Jump back to the 'start' label        
    //}


    option_menuF5a01(DLG_IRF5A01_011, Platforms, CATEGORY);
    optionMenuSpringTypes.clear();

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF5A01_011, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF5A01_011);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);



    if (isUserQuits)
        return -1;




    // Iterate over each element of the vector
    for (const auto& entry : TonnageDiaList)
    {
        // Check if standardf5a01 is present in CapacityTon
        if (entry.CapacityTon == standardf5a01)
        {
            // Split Diainmm by semicolon delimiter
            std::stringstream ss(entry.Diainmm);
            std::string token;
            while (std::getline(ss, token, ';'))
            {
                // Convert token to double and push into AcceptedStandardValues
                AcceptedStandardValues.push_back(std::stod(token));
            }
            break; // Exit loop since match is found
        }
    }

    // Print AcceptedStandardValues
    for (double value : AcceptedStandardValues)
    {
        ruleLog.Write("Standard Values = " + to_string(value));
        //std::cout << value << " ";
    }

    bool found = false;

    /* for (int i = 0; i < AcceptedStandardValues.size(); i++)
     {
         if (compareFloat(AcceptedStandardValues[i], PCD_Dis[i]))
         {
             isRightValue = TRUE;
             break;
         }
         else
         {
             isRightValue = FALSE;
         }
     }*/

    string status;
    vector<string>st;
    for (int i = 0; i < PCD_Dis.size(); ++i)
    {
        for (int j = 0; j < AcceptedStandardValues.size(); j++)
        {
            ruleLog.Write("Comparing Value : " + to_string(AcceptedStandardValues[j]));
            ruleLog.Write("Compared Value : " + to_string(PCD_Dis[i]));
            if (compareFloat(AcceptedStandardValues[j], PCD_Dis[i]))
            {

                status = "PASS";
                st.push_back(status);
                break;
            }
            else
            {
                status = "FAIL";
                st.push_back(status);
            }
        }
    }

    bool NoRightValue{};
    for (auto res : st)
    {
        if (res.find("FAIL") == 0)
        {
            NoRightValue = TRUE;
        }
    }

    // String to store the result
    std::string result;

    // Iterate over each element of the vector
    for (size_t i = 0; i < AcceptedStandardValues.size(); ++i) {
        // Convert value to string and append "mm"
        std::stringstream ss;
        ss << AcceptedStandardValues[i] << ".00 mm";
        result += ss.str(); // Append to result string

        // Add comma if not the last element
        if (i != AcceptedStandardValues.size() - 1) {
            result += ", "; // Add comma and space
        }
    }

    remf5a01 = "\nAcceptance criteria for " + standardf5a01_cat + " " + standardf5a01 + " is " + result + ".";
    remark_f5a01 += remf5a01;
    final_res.remark = remark_f5a01 + info_f5A01_011;

    //isRightValue = FALSE;
    // DECLARE RESULT
    if (NoRightValue)
        final_res.result = "FAIL";
    else
        final_res.result = "PASS";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    hole_diam.clear();
    surfaceCollect.clear();
    ID_MAP.clear();
    idTable.clear();
    big_diam.clear();
    AcceptedStandardValues.clear();
    remf5a01.clear();
    remark_f5a01.clear();
    optionMenuSpringTypes.clear();
    TonnageDiaList.clear();



    return 0;
}

ProError select_action_IRF5A01_011(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- select_action_IRF5A01_011 -----------------------------");

    status = ProSelect((char*)"edge", -1, NULL, NULL, NULL, NULL, &sel_alloc1, &sel_F5A01_011);
    ruleLog.Write("ProSelect: " + to_string(status));
    InterfaceRule _irule_f5a01;
    if (status == PRO_TK_USER_ABORT || sel_F5A01_011 < 2)
    {
        _irule_f5a01.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
        status = ProUIPushbuttonDisable(dialog, PB_ROK);
        ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
        return status;
    }

    if (status == 0)
    {
        status = ProUIPushbuttonEnable(dialog, PB_ROK);
    }
    return status;
}

ProError ruleDlgOKactionf5a01011(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgOKaction -----------------------------");

    ruleLog.Write("Number of Selections :" + to_string(sel_F5A01_011));

    double param_1, param_2;
    double pnt_1, pnt_2;
    ProModelitem mdlitem_1, mdlitem_2;
    ProMdl mdl_1, mdl_2;
    wchar_t model_1, model_2;
    char namesel_1[PRO_NAME_SIZE];
    char namesel_2[PRO_NAME_SIZE];
    // char* namesel_1{}, namesel_2{};

    info_f5A01_011 += "\nSelection Info:";
    int n = 0;
    for (int i = 0; i < sel_F5A01_011; i += 2)
    {
        int l = n + 1;
        status = ProSelectionModelitemGet(sel_alloc1[i], &mdlitem_1);
        ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

        status = ProModelitemMdlGet(&mdlitem_1, &mdl_1);
        ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

        status = ProMdlMdlnameGet(mdl_1, &model_1);
        ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

        ProWstringToString(namesel_1, &model_1);
        remf5a01 += "Pitch Circle Diameter of the " + string(namesel_1) + ".PRT is ";

        info_f5A01_011 += "\nPart Name:" + string(namesel_1) + ",Surace Id :" + to_string(mdlitem_1.id);
        string s();

        if (i + 1 < sel_F5A01_011)
        {
            int k = l + 1;
            status = ProSelectionModelitemGet(sel_alloc1[i + 1], &mdlitem_2);
            ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

            status = ProModelitemMdlGet(&mdlitem_2, &mdl_2);
            ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

            status = ProMdlMdlnameGet(mdl_2, &model_2);
            ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

            ProWstringToString(namesel_2, &model_2);
            ruleLog.Write("Number of time =" + to_string(i));
            //  int j = i + 1;
              //measure the distance between sel[i] and sel[i+1]
            status = ProSelectionWithOptionsDistanceEval(sel_alloc1[i], PRO_B_TRUE, sel_alloc1[i + 1], PRO_B_TRUE, &param_1, &param_2, &pnt_1, &pnt_2, &PCD1);
            ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
            double O_PCD = PCD1 * 2;
            string pcdBS;
            pcdBS = to_string(round(O_PCD));
            pcdBS.erase(pcdBS.find_last_not_of('0') + 3, string::npos);

            ruleLog.Write("Distance = " + pcdBS + "mm");
            remf5a01 += pcdBS + " mm\n";
            PCD_Dis.push_back(O_PCD);

            info_f5A01_011 += "\nPart Name:" + string(namesel_2) + ",Edge Id :" + to_string(mdlitem_2.id);
        }


    }
    //for (int i = 0; i < num_sel.size(); ++i) 
    //{
    //    int j = i + 1;
    //    status = ProSelectionWithOptionsDistanceEval(sel_alloc1[i], PRO_B_TRUE, sel_alloc1[j], PRO_B_TRUE, &param_1, &param_2, &pnt_1, &pnt_2, &PCD);
    //    ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
    //   // PCD = PCD * 2;
    //    ruleLog.Write("Distance = " + doubleToStringf5a01(PCD) + "mm");
    //}
    ProMdl p_asm;
    //    UserAppdata appdata;
    //    FILE* fp;
    //
    //    status = ProMdlCurrentGet(&p_asm);
    //    ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));
    //    appdata.fp = fp;
    //    appdata.level = 1;
    //
    //
    //    status = ProSolidFeatVisit((ProSolid)p_asm, user_actionf5a01, UserAsmCompFilterf5a01, &appdata);
    //
    //
    //    //Visit the features of opened submodule
    //    //FILE* fp{};
    //    levelF5A01011 = 1;
    //
    //    num_of_assy_fixedF5A01011 = 0;
    //
    //    models[0].Model = curMdl;
    //    models[0].Model_feat_id = 0;
    //    models_cntF5A01011 = 1;
    //    Assy_models_cntF5A01011 = 0;
    //
    //begin:
    //
    //    for (int a = 0; a < models_cntF5A01011; ++a)
    //    {
    //        owner_feat_idF5A01011 = models[a].Model_feat_id;
    //        status = ProSolidFeatVisit((ProSolid)models[a].Model, (ProFeatureVisitAction)visitActionf5a01_1, compsFilter, fp);
    //        ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
    //    }
    //
    //    if (Assy_models_cntF5A01011 > 0)
    //    {
    //        ++levelF5A01011;
    //        for (int b = 0; b < Assy_models_cntF5A01011; ++b)
    //        {
    //            models[b].Model = Assy_models[b].Model;
    //            models[b].Model_feat_id = Assy_models[b].Model_feat_id;
    //        }
    //        models_cntF5A01011 = Assy_models_cntF5A01011;
    //        Assy_models_cntF5A01011 = 0;
    //        goto begin;
    //    }

        //auto maxElement = std::max_element(big_diam.begin(), big_diam.end());
        //std::string maxString = std::to_string(*maxElement);

        //ruleLog.Write("Maximum Diameter = " + maxString);
        //ruleLog.Write("Minimum Diameter = " + to_string(hole_diam[0]));

        //sel_num = 0;

       /* double diameterp;
        status = ProGeomitemDiameterEval(sel_alloc1, &diameterp);
        ruleLog.Write("ProGeomitemDiameterEval status = " + to_string(status));
        ruleLog.Write("Diameter Test Print = " + to_string(diameterp));

        double diameterp1;
        status = ProGeomitemDiameterEval(sel_alloc2, &diameterp1);
        ruleLog.Write("ProGeomitemDiameterEval status = " + to_string(status));
        ruleLog.Write("Diameter Test Print = " + to_string(diameterp1));

        status = ProSelectionHighlight(sel_alloc1 , PRO_COLOR_HIGHLITE);
        ruleLog.Write("ProSelectionHighlight status = " + to_string(status));
        status = ProSelectionHighlight(sel_alloc2, PRO_COLOR_HIGHLITE);
        ruleLog.Write("ProSelectionHighlight status = " + to_string(status));

        double param_1, param_2;
        double pnt_1, pnt_2;

        status = ProSelectionWithOptionsDistanceEval(sel_alloc1, PRO_B_TRUE, sel_alloc2, PRO_B_TRUE, &param_1, &param_2, &pnt_1, &pnt_2, &PCD);
        ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
        PCD = PCD * 2;
        ruleLog.Write("Distance = " + doubleToStringf5a01(PCD) + "mm");*/


    ruleLog.Write(remf5a01);
    remark_f5a01 += remf5a01;


    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return PRO_TK_NO_ERROR;
}

ProError user_actionf5a01(ProFeature* feature, ProError status, ProAppData appdata)
{
    FILE* fp;
    int l, level;
    ProMdl mdl;
    char name[PRO_MDLNAME_SIZE];
    char type[PRO_MDLEXTENSION_SIZE];
    wchar_t wname[PRO_NAME_SIZE];
    UserAppdata* appd, appd1;
    ProMdlName modelName;
    ProMdlExtension modelExtension;
    ProMdlType subModuleMdlType;
    ProModelitem subMdlModelItem;
    ProParameter            pDesc;
    ProParamvalue           pvDesc;
    ProName                 pDescName = L"DESCRIPTION";
    char                    descriptionVal[PRO_NAME_SIZE];
    wchar_t					wFeatName[PRO_NAME_SIZE];
    char					cFeatname[PRO_NAME_SIZE];
    const regex				cfpattern("BRAKE DRUM");
    string					description;
    smatch					matchFound1, matchFound2, matchFound3;
    char existingPval[PRO_NAME_SIZE]{};




    appd = (UserAppdata*)appdata;
    fp = appd->fp;
    level = appd->level;

    //if (bd_check == 0)
    //{
    status = ProAsmcompMdlGet(feature, &mdl);
    ruleLog.Write("ProAsmcompMdlGet status = " + to_string(status));

    status = ProMdlMdlnameGet(mdl, modelName);
    ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));
    status = ProMdlExtensionGet(mdl, modelExtension);
    ruleLog.Write("ProMdlExtensionGet status = " + to_string(status));
    ProWstringToString(name, modelName);
    ProWstringToString(type, modelExtension);
    string sname(name);
    string stype(type);


    status = ProMdlTypeGet(mdl, &subModuleMdlType);
    ruleLog.Write("ProMdlTypeGet status = " + to_string(status));

    ID_MAP.push_back(feature->id);

    if (subModuleMdlType == PRO_MDL_PART)
    {
        status = ProMdlToModelitem(mdl, &subMdlModelItem);
        //ruleLog.Write("ProMdlToModelitem: " + to_string(status));
        ProParameter pDesc;
        ProParamvalue pvDesc;
        ProName pDescName = L"DESCRIPTION";
        status = ProParameterInit(&subMdlModelItem, pDescName, &pDesc);
        //ruleLog.Write("ProParameterInit: " + to_string(status));

        if (status == PRO_TK_NO_ERROR)
        {
            status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
            ProWstringToString(existingPval, pvDesc.value.s_val);
            //ruleLog.Write("Name of assembly = " + string(name27) + " , ID = " + to_string(feature->id) + " , Description = " + existingPval);

            const char* substringToFind = "BRAKE DRUM";
            // Use the strstr function to check if the substring exists
            const char* found = strstr(existingPval, substringToFind);
            if (found != nullptr)
            {
                //bd_check = 1;

                ruleLog.Write("FFFFFFFFFFFOOOOOOOOOUUUUUUUUUUUNNNNNNNNNNNNDDDDDDDDDDDD");

                Brakedrum = mdl;
                appd2 = &appd1;



            }
            else
            {
                //bd_check = 0;
            }
        }

    }

    //if (strncmp(type, "ASM", 3) == 0)
    //{
    appd1.fp = appd->fp;
    appd1.level = appd->level + 1;
    status = ProSolidFeatVisit((ProSolid)mdl, user_actionf5a01, UserAsmCompFilterf5a01, &appd1);
    ID_MAP.pop_back();
    //}

    if (feature != NULL)
    {
        return(PRO_TK_NO_ERROR);
    }
    //}



    return(PRO_TK_CONTINUE);

}

ProError ruleDlgCloseActionf5a01011(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgCloseAction -----------------------------");

    if (data != NULL) {
        bool* quitAction = (bool*)data;
        *quitAction = true;
    }

    hole_diam.clear();
    surfaceCollect.clear();
    ID_MAP.clear();
    idTable.clear();
    big_diam.clear();
    AcceptedStandardValues.clear();
    remf5a01.clear();
    optionMenuSpringTypes.clear();

    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return status;
}

ProError UserAsmCompFilterf5a01(ProFeature* feature, ProAppData app_data)
{
    ProError status;
    ProFeattype ftype;
    ProName feature_type_name;
    wchar_t f_name;
    char name[100];
    ProMdlName ownwer_name;
    char c_owner_name[100];
    ProModelitem MI;
    char existingp_val[100];

    status = ProFeatureTypeGet(feature, &ftype);

    if (ftype == PRO_FEAT_HOLE)
    {
        ID_MAP.push_back(feature->id);

        ruleLog.Write("ProFeatureTypeGet : " + to_string(ftype));
        status = ProFeatureTypenameGet(feature, feature_type_name);
        ruleLog.Write("ProFeatureTypenameGet status: " + to_string(status));

        status = ProMdlMdlnameGet(feature->owner, ownwer_name);
        ruleLog.Write("ProMdlMdlnameGet status: " + to_string(status));

        ProWstringToString(c_owner_name, ownwer_name);
        string own(c_owner_name);

        status = ProMdlToModelitem(feature->owner, &MI);
        ruleLog.Write("ProMdlToModelitem: " + to_string(status));
        ProParameter pDesc;
        ProParamvalue pvDesc;
        ProName pDescName = L"DESCRIPTION";
        status = ProParameterInit(&MI, pDescName, &pDesc);

        if (status == PRO_TK_NO_ERROR)
        {
            status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
            ProWstringToString(existingp_val, pvDesc.value.s_val);
            //ruleLog.Write("Name of assembly = " + string(name27) + " , ID = " + to_string(feature->id) + " , Description = " + existingPval);

            const char* substringToFind = "BRAKE DRUM";
            // Use the strstr function to check if the substring exists
            const char* found = strstr(existingp_val, substringToFind);
            if (found != nullptr)
            {

                ProFeatureGeomitemVisit(feature, PRO_SURFACE, (ProGeomitemAction)Geom_visit_action, NULL, NULL);



                /*if (status == PRO_TK_NO_ERROR)
                {

                }*/

                //ProWstringToString(name, feature_type_name);
                //string nameString(name);
                //ruleLog.Write("Feature type name :                                  " + nameString + " Feature ID : " + to_string(feature->id) + " Feature Ownwer = " + own);
                //
                //int vectorSize = ID_MAP.size();

                //for (int i = 0; i < vectorSize; ++i)
                //{
                //    tarrayf5a01[i] = ID_MAP[i];
                //}

                //for (int i = 0; i < ID_MAP.size(); ++i)
                //{
                //    ruleLog.Write(to_string(tarrayf5a01[i]) + "+++++++++++++++");
                //}

                //ProAsmcomppath pathair1;
                ////ProIdTable idtblair1 = { _reqCompsf5a27->id };
                //status = ProAsmcomppathInit((ProSolid)curMdl, tarrayf5a01, vectorSize , &pathair1);
                //ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));

                //status = ProSelectionAlloc(&pathair1, &MI, sel_hole);
                //ruleLog.Write("ProSelectionAlloc status = " + to_string(status));

            }
        }

        /* status = ProModelitemNameGet(feature , &f_name);
         ruleLog.Write("ProModelitemNameGet status: " + to_string(status));

         status = ProFeatureSelectionGet(feature , sel_hole);
         ruleLog.Write("ProFeatureSelectionGet status: " + to_string(status));

         status = ProSelectionHighlight(sel_hole[0] , PRO_COLOR_HIGHLITE);
         ruleLog.Write("ProSelectionHighlight status: " + to_string(status));*/




        ID_MAP.pop_back();

        return(PRO_TK_CONTINUE);

    }
    else if (ftype == PRO_FEAT_COMPONENT)
    {
        //bd_check = 0;
        return(PRO_TK_NO_ERROR);
    }



    return(PRO_TK_CONTINUE);
}

ProError Geom_visit_action(ProGeomitem geom, ProError status, ProAppData app_data)
{
    ProSurface surface;
    double diam;
    ProModelitem MIG;
    int min;
    ProSrftype sur_type;

    ID_MAP.push_back(geom.id);
    for (int i = 0; i < ID_MAP.size(); ++i)
    {
        ruleLog.Write(to_string(ID_MAP[i]) + "+++++++++++++++");
    }

    status = ProGeomitemToSurface(&geom, &surface);
    ruleLog.Write("ProGeomitemToSurface status: " + to_string(status));

    status = ProSurfaceTypeGet(surface, &sur_type);
    ruleLog.Write("ProSurfaceTypeGet status: " + to_string(status) + " Sur Type = " + to_string(sur_type));

    ProError status1 = ProSurfaceDiameterEval(surface, NULL, &diam);
    ruleLog.Write("ProSurfaceDiameterEval status: " + to_string(status));


    if (status1 == PRO_TK_NO_ERROR && (std::round(diam * 100) / 100) != 0.00)
    {
        ruleLog.Write("Check");

        // Check if the vector is empty
        if (hole_diam.empty() == false)
        {
            // Find the smallest element in the vector using a for loop
            double minElement = hole_diam[0]; // Assume the first element as the minimum
            for (size_t i = 1; i < hole_diam.size(); ++i)
            {
                if (hole_diam[i] < minElement)
                {
                    minElement = hole_diam[i];
                }
            }

            ruleLog.Write("Smallest dia : " + to_string(minElement));

            if ((std::round(diam * 100) / 100) < (std::round(minElement * 100) / 100))
            {
                status = ProModelitemInit(geom.owner, geom.id, geom.type, &MIG);
                ruleLog.Write("ProModelitemInit status: " + to_string(status));

                // status = ProSelectionAlloc(NULL, &MIG, &sel_alloc1);
                ruleLog.Write("ProSelectionAlloc status: " + to_string(status) + " Selection Index = " + to_string(sel_num));
                sel_num++;
            }

            ruleLog.Write("                                     Geom ID: " + to_string(geom.id));

        }
        hole_diam.push_back(diam);
    }



    ID_MAP.pop_back();

    //ruleLog.Write("Diameter : " + to_string(diam));   

    return PRO_TK_NO_ERROR;
}

ProError Geom_filter_action(ProFeature feature, ProAppData app_data)
{

    return PRO_TK_NO_ERROR;
}

ProMdl flangeMdl1;
ProError visitActionf5a01_1(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    ruleLog.Write("====== visitActionH2D01 =====");
    ProMdlfileType			comp_type;
    ProFamilyMdlName		comp_name;
    char					part_no[PRO_PATH_SIZE];
    ProAsmcompconstraint* constr_array;
    ProMdl					model;
    ProFeattype				ftype;
    ProAsmcompconstraint	constraint;
    ProAsmcompconstraint* constraints;
    ProPatternStatus 		p_pattern_status;
    ProFeatStatus 			p_status;
    FILE* fp = (FILE*)app_data;



    status = ProFeatureTypeGet(p_feature, &ftype);
    ruleLog.Write("ProFeatureTypeGet status: " + to_string(status));

    if (ftype == PRO_FEAT_COMPONENT)
    {
        ruleLog.Write("Component Level = " + to_string(levelF5A01011));
        status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
        ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));
        ProWstringToString(part_no, comp_name);
        ruleLog.Write("Part name: " + (string)part_no);
        ++model_countF5A01011;

        feat_id_data  _feat_id_data;

        if (levelF5A01011 == 1) {
            ruleLog.Write("inside if loop level ==1 ");
            _feat_id_data.feat_ids[0] = p_feature->id;
            _feat_id_data.level = levelF5A01011;

            feat_id_data_arr.push_back(_feat_id_data);

        }
        else
        {
            for (int j = 0; j < feat_id_data_arr.size(); ++j)
            {
                if (feat_id_data_arr[j].feat_ids[levelF5A01011 - 2] == owner_feat_idF5A01011)
                {
                    feat_id_data owner_feat_id_data = feat_id_data_arr[j];
                    for (int i = 0; i < levelF5A01011 - 1; ++i)
                    {
                        _feat_id_data.feat_ids[i] = owner_feat_id_data.feat_ids[i];
                    }

                    _feat_id_data.feat_ids[levelF5A01011 - 1] = p_feature->id;
                    _feat_id_data.level = levelF5A01011;

                    break;
                }

            }

            feat_id_data_arr.push_back(_feat_id_data);
        }

        ProMdlType				subModuleMdlType;
        ProModelitem			subMdlModelItem;
        ProParameter            pDesc;
        ProParamvalue           pvDesc;
        ProName                 pDescName = L"DESCRIPTION";
        char                    descriptionVal[PRO_NAME_SIZE];
        wchar_t					wFeatName[PRO_NAME_SIZE];
        char					cFeatname[PRO_NAME_SIZE];
        const regex				cfpattern("BRAKE DRUM");
        smatch					matchFound1, matchFound2, matchFound3;
        string					description;
        ProFeature				featHandle;



        status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
        ruleLog.Write("ProAsmcompMdlGet status: " + to_string(status));
        flangeMdl1 = model;
        //referenceObject1.parentMdl = model;
        status = ProMdlTypeGet(model, &subModuleMdlType);
        ruleLog.Write("ProMdlTypeGet status: " + to_string(status));
        if (subModuleMdlType == PRO_MDL_PART)
        {
            status = ProMdlToModelitem(model, &subMdlModelItem);
            ruleLog.Write("ProMdlToModelitem VAS: " + to_string(status));
            status = ProParameterInit(&subMdlModelItem, pDescName, &pDesc);
            ruleLog.Write("ProParameterInit VAS: " + to_string(status));
            if (status != PRO_TK_E_NOT_FOUND)
            {
                status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
                ruleLog.Write("ProParameterValueWithUnitsGet VAS: " + to_string(status));
                ruleLog.Write("Check for regex statement");
                if (regex_search(description, matchFound1, cfpattern) == 0)
                {
                    ruleLog.Write("Size of IdTable found flange: " + to_string(idTable.size()));
                    ruleLog.Write("Check for inside regex search");

                    vector<surfaceData>cylSurfaces;
                    status = ProSolidSurfaceVisit((ProSolid)flangeMdl1, (ProSurfaceVisitAction)surfVisitAction1, NULL, &cylSurfaces);
                    ruleLog.Write("ProSolidSurfaceVisit VAS: " + to_string(status));

                }
            }
        }

        if (subModuleMdlType == PRO_MDL_ASSEMBLY)
        {
            Assy_models[Assy_models_cntF5A01011].Model = model;
            Assy_models[Assy_models_cntF5A01011].Model_feat_id = p_feature->id;
            Assy_models_cntF5A01011 += 1;
        }
    }

    return PRO_TK_NO_ERROR;
}

ProError surfVisitAction1(ProSurface surface, ProError status, vector<surfaceData>* cylSurfaces)
{
    ProSrftype surfType;
    surfaceData surfObject;
    int id;
    ProModelitem modelIt;
    ProGeomitem GI;


    status = ProSurfaceTypeGet(surface, &surfType);
    ruleLog.Write("ProSurfaceTypeGet status: " + to_string(status) + "\nSurface type is: " + to_string(surfType));
    if (status == PRO_TK_NO_ERROR)
    {
        if (surfType == PRO_SRF_CYL)
        {
            surfObject.surface = surface;
            ruleLog.Write("Before push back");
            surfaceCollect.push_back(surfObject);

            ruleLog.Write("After push back");
            double diameter;
            status = ProSurfaceDiameterEval(surface, NULL, &diameter);

            if (big_diam.empty() == FALSE)
            {
                // Find the maximum value in the vector using a for loop
                double maxElement = big_diam[0]; // Assume the first element as the maximum
                for (size_t i = 1; i < big_diam.size(); ++i)
                {
                    if (big_diam[i] > maxElement) {
                        maxElement = big_diam[i];
                    }
                }
                ruleLog.Write("Maximum Dia = " + to_string(maxElement));

                if (diameter > maxElement)
                {
                    status = ProSurfaceToGeomitem((ProSolid)flangeMdl1, surface, &GI);
                    ruleLog.Write("ProSurfaceToGeomitem status: " + to_string(status));

                    status = ProModelitemInit(GI.owner, GI.id, GI.type, &modelIt);
                    ruleLog.Write("ProModelitemInit status: " + to_string(status));

                    status = ProSelectionAlloc(NULL, &modelIt, &sel_alloc2);
                    ruleLog.Write("ProSelectionAlloc status: " + to_string(status) + " Selection Index = " + to_string(sel_num));
                    sel_num++;


                    /*status = ProModelitemInit();
                    ruleLog.Write("ProModelitemInit status: " + to_string(status));

                    status = ProSelectionAlloc(NULL, &MIG, &sel_alloc1);
                    ruleLog.Write("ProSelectionAlloc status: " + to_string(status) + " Selection Index = " + to_string(sel_num));
                    sel_num++;*/
                }
            }


            big_diam.push_back(diameter);


            //ruleLog.Write("ProSurfaceDiameterEval status: " + to_string(status) + "\nDiameter: " + to_string(diameter));
            //surfObject.diameter = diameter;
            //status = ProSurfaceIdGet(surface, &id);
            //ruleLog.Write("ProSurfaceIdGet status: " + to_string(status) + "\n identifier: " + to_string(id));
            ////surfObject.id = id;
            //status = ProModelitemInit(flangeMdl, id, PRO_SURFACE, &modelIt);
            //ruleLog.Write("ProModelitemInit status: " + to_string(status));
            //surfObject.modelItem = modelIt;
            //cylSurfaces->push_back(surfObject);

        }
    }
    return PRO_TK_NO_ERROR;
}

void option_menuF5a01(char* dialog, vector<string> option_menulist, char* optionmenu)
{

    ruleLog.Write("----------------------------- option_menu -----------------------------");
    //long memore = LONG_MAX;
    char** loadCapListNames;
    wchar_t** loadCapListLabels;
    status = ProArrayAlloc(option_menulist.size(), sizeof(char*), (50), (ProArray*)&loadCapListNames);
    status = ProArrayAlloc(option_menulist.size(), sizeof(wchar_t*), (50), (ProArray*)&loadCapListLabels);

    for (int i = 0; i < option_menulist.size(); ++i)
    {
        loadCapListNames[i] = (char*)calloc((50), sizeof(char));
        ProTKSprintf(loadCapListNames[i], "%s", option_menulist[i]);

        loadCapListLabels[i] = (wchar_t*)calloc((50), sizeof(wchar_t));
        ProStringToWstring(loadCapListLabels[i], loadCapListNames[i]);
    }
    status = ProUIOptionmenuNamesSet(dialog, optionmenu, int(option_menulist.size()), loadCapListNames);
    ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
    status = ProUIOptionmenuLabelsSet(dialog, optionmenu, int(option_menulist.size()), loadCapListLabels);
    ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

    optionMenuSpringTypes.clear();

    status = ProArrayFree((ProArray*)&loadCapListNames);
    status = ProArrayFree((ProArray*)&loadCapListLabels);
}

ProError optionMenuImageChangeActionf5A01_load(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- optionMenuImageChangeActionf4a02 -----------------------------");

    string* reqData = (string*)data;
    int n_sel;
    char** selValue;
    string blank = "Select";
    InterfaceRule itr;
    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
    ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
    ruleLog.Write("selValue = " + string(selValue[0]));
    standardf5a01 = string(selValue[0]);
    if (standardf5a01 == "SELECT TONNAGE")
    {
        status = ProUIPushbuttonDisable(DLG_IRF5A01_011, PB_ROK);
    }
    return PRO_TK_NO_ERROR;
}

ProError optionMenuImageChangeActionf5A01_category(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- optionMenuImageChangeActionf4a02 -----------------------------");

    string* reqData = (string*)data;
    int n_sel;
    char** selValue;
    string blank = "Select";
    InterfaceRule itr;
    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
    ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
    ruleLog.Write("selValue = " + string(selValue[0]));
    standardf5a01_cat = string(selValue[0]);
    if (standardf5a01_cat == "SELECT PLATFORM")
    {
        status = ProUIPushbuttonDisable(DLG_IRF5A01_011, PB_ROK);
        status = ProUIOptionmenuDisable(DLG_IRF5A01_011, LOAD_CAPACITY);
    }
    else
    {
        status = ProUIOptionmenuEnable(DLG_IRF5A01_011, LOAD_CAPACITY);
        // Check if "ILCV" is found
        if (standardf5a01_cat.find("ILCV") != std::string::npos)
        {
            // Do something if "ILCV" is found
            option_menuF5a01(DLG_IRF5A01_011, ILCVCapacityTon, LOAD_CAPACITY);
        }
        else
        {
            option_menuF5a01(DLG_IRF5A01_011, MHCVCapacityTon, LOAD_CAPACITY);
        }
    }
    return PRO_TK_NO_ERROR;
}

#pragma pop