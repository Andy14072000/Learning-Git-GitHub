/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
Pallavi Garodi	| 14-06-2024	|	V1_0_0		| F4A05 - FRONT SUSPENSION RULES
==================================================================================================================*/
#include "F4A05.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F4A05-002	| Vinay Neel    	| MF4A05        	| Standard ARB attachment across platform based on mounting bolt size for Front suspension.
===================================================================================================================*/

#define DLG_IRF4A05_002 "dlg_IR_F4A05_002"
#define PB_RSELECT1		"pb_select1"
#define PB_RCANCEL       "CommitCancel"
#define PB_RUN           "pb_run"
struct CompData_F4A02005 {
	ProSelection    ProSelection;
	char            Name[PRO_PATH_SIZE];
	int             ID;
};

vector<CompData_F4A02005> CompData_F4A02005_vector1, CompData_F4A02005_vector2;
int IRF4A05::IRF4A05_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF4A05::IRF4A05_002   ==========================");

	/* your code goes here */
	ComponentData _reqComps[1]{};
	CompData_F4A02005_vector1.clear(); CompData_F4A02005_vector2.clear();
	bool condcheck = false;
	bool condcheck1 = false;
	string remarkstring;
	double Computed_dia1{}, Computed_dia2{};
	string reqCompSubMod[] = { "F4A05" };

	for (int i = 0; i < subModulesList.size(); ++i)
		for (int j = 0; j < 1; ++j)
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
				strcpy(_reqComps[j].name, subModulesList[j].name.c_str());

	int project_code = stoi(string(_reqComps[0].name).substr(0, 4));
	ruleLog.Write("Project Code:" + to_string(project_code));


	string acceptance_Frame{}, acceptance_Axle{};
	vector<string> reqvalfromcsv_frontEnd, reqvalfromcsv_axleEnd;
	getReqValsFrom2DCsvData("IRF4A05002.csv", 2, 3, project_code, reqvalfromcsv_frontEnd);
	getReqValsFrom2DCsvData("IRF4A05002.csv", 2, 4, project_code, reqvalfromcsv_axleEnd);

	if (reqvalfromcsv_frontEnd.size() == 0 && reqvalfromcsv_axleEnd.size() == 0) {
		UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "ERROR", "The Project code is not available in the database.");
		return 0;
	}

	for (size_t i = 0; i < reqvalfromcsv_frontEnd.size(); i++) {
		ruleLog.Write("reqvalfromcsv_frontEnd: " + reqvalfromcsv_frontEnd[i]);
		if (i != (reqvalfromcsv_frontEnd.size() - 1)) {
			acceptance_Frame += reqvalfromcsv_frontEnd[i] + ", ";
		}
		else {
			acceptance_Frame += reqvalfromcsv_frontEnd[i] + ".";
		}
	}

	for (size_t i = 0; i < reqvalfromcsv_axleEnd.size(); i++) {
		ruleLog.Write("reqvalfromcsv_axleEnd: " + reqvalfromcsv_axleEnd[i]);
		if (i != (reqvalfromcsv_axleEnd.size() - 1)) {
			acceptance_Axle += reqvalfromcsv_axleEnd[i] + ", ";
		}
		else {
			acceptance_Axle += reqvalfromcsv_axleEnd[i] + ".";
		}
	}


	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF4A05_002, DLG_IRF4A05_002);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF4A05_002, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A05_002, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A05_002, PB_RUN, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A05_002, PB_RSELECT1, (ProUIAction)select_action1_IRF4A05002, NULL);


	status = ProUIPushbuttonDisable(DLG_IRF4A05_002, PB_RUN);
	//status = ProUIPushbuttonDisable(DLG_IRF4A05_002, PB_RSELECT2);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF4A05_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF4A05_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);


	if (isUserQuits)
		return -1;

	ruleLog.Write("CompData_F4A02005_vector1.size(): " + to_string(CompData_F4A02005_vector1.size()));
	string rstring1 = "Computed diameter of Frame End Bolts\n";
	for (int i = 0; i < CompData_F4A02005_vector1.size(); i++) {
		status = ProGeomitemDiameterEval(CompData_F4A02005_vector1[i].ProSelection, &Computed_dia1);
		ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status) + "\tComputed_dia: " + to_string(Computed_dia1));
		ostringstream stream1{};
		stream1 << fixed << setprecision(2) << Computed_dia1;
		string formattedStandardValue = stream1.str();
		rstring1 += "\t\t\t\t\t" + string(CompData_F4A02005_vector1[i].Name) + ".PRT " + "(Surf. Id: " + to_string(CompData_F4A02005_vector1[i].ID) + "): " + formattedStandardValue + " mm.\n";
		for (int j = 0; j < reqvalfromcsv_frontEnd.size(); j++) {
			if (Computed_dia1 == stod(reqvalfromcsv_frontEnd[j])) {
				ruleLog.Write("Computed Diameter: " + to_string(Computed_dia1) + " matches Standard Diameter: " + reqvalfromcsv_frontEnd[j]);
				condcheck = false;
				break;
			}
			else {
				ruleLog.Write("Computed Diameter: " + to_string(Computed_dia1) + " does not match Standard Diameter: " + reqvalfromcsv_frontEnd[j]);
				condcheck = true;
			}
		}
	}

	ruleLog.Write("CompData_F4A02005_vector2.size(): " + to_string(CompData_F4A02005_vector2.size()));
	string rstring2 = "Computed diameter of Axle End Bolts\n";
	for (int i = 0; i < CompData_F4A02005_vector2.size(); i++) {
		status = ProGeomitemDiameterEval(CompData_F4A02005_vector2[i].ProSelection, &Computed_dia2);
		ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status) + "\tComputed_dia: " + to_string(Computed_dia2));
		ostringstream stream2{};
		stream2 << fixed << setprecision(2) << Computed_dia2;
		string formattedStandardValue1 = stream2.str();
		rstring2 += "\t\t\t\t\t" + string(CompData_F4A02005_vector2[i].Name) + ".PRT " + "(Surf. Id: " + to_string(CompData_F4A02005_vector2[i].ID) + "): " + formattedStandardValue1 + " mm.\n";
		for (int j = 0; j < reqvalfromcsv_axleEnd.size(); j++) {
			if (Computed_dia2 == stod(reqvalfromcsv_axleEnd[j])) {
				ruleLog.Write("Computed Diameter: " + to_string(Computed_dia2) + " matches Standard Diameter: " + reqvalfromcsv_axleEnd[j]);
				condcheck1 = false;
				break;
			}
			else {
				ruleLog.Write("Computed Diameter: " + to_string(Computed_dia2) + " does not match Standard Diameter: " + reqvalfromcsv_axleEnd[j]);
				condcheck1 = true;
			}
		}
	}

	remarkstring = rstring1 + rstring2 + "\nAcceptance Criteria for Frame End Bolts diameter (in mm): " + acceptance_Frame + "\nAcceptance Criteria for Axle End Bolts diameter (in mm): " + acceptance_Axle;

	final_res.remark = remarkstring;

	if (condcheck1 == false && condcheck == false)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	CompData_F4A02005_vector1.clear();
	CompData_F4A02005_vector2.clear();
	remarkstring.clear();
	acceptance_Frame.clear();
	acceptance_Axle.clear();
	rstring1.clear();
	rstring2.clear();
	return 0;
}
ProError select_action1_IRF4A05002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action1_IRF4A05002 -----------------------------");

	int curWinId;
	ProSelection* surf_part_Sels1 = nullptr;
	ProSelection* surf_part_Sels2 = nullptr;
	int n_sel1, n_sel2;
	InterfaceRule irule;

	status = ProWindowCurrentGet(&curWinId);
	status = ProWindowRepaint(curWinId);
	status = ProUIDialogHide(dialog);

	auto handleSelection = [&](const char* prompt, ProSelection*& selections, int& n_selections, std::vector<CompData_F4A02005>& compDataVector) -> bool {
		InterfaceRule forPrompt;
		forPrompt.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, prompt, "Please select the surfaces.");

		status = ProSelect("surface", 2, nullptr, nullptr, nullptr, nullptr, &selections, &n_selections);
		ruleLog.Write("Proselect: " + std::to_string(status) + "\tNo. of Selections: " + std::to_string(n_selections));

		if (n_selections < 2 || status != PRO_TK_NO_ERROR) {
			irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs in the Selection!. Refer help document for details.");
			status = ProUIDialogShow(dialog);
			return false;
		}

		for (size_t i = 0; i < n_selections; ++i) {
			ProModelitem mdl_item{}, mdl_item_desc{};
			wchar_t w_name[PRO_PATH_SIZE];
			ProParameter param_desc;
			ProParamvalue param_value;
			int lastCompID = -1;
			ProAsmcomppath asm_comp_path;

			status = ProSelectionModelitemGet(selections[i], &mdl_item);
			status = ProMdlMdlnameGet(mdl_item.owner, w_name);
			status = ProMdlToModelitem(mdl_item.owner, &mdl_item_desc);
			status = ProParameterInit(&mdl_item_desc, L"DESCRIPTION", &param_desc);
			status = ProParameterValueWithUnitsGet(&param_desc, &param_value, NULL);

			CompData_F4A02005 comp_data{};
			status = ProSelectionCopy(selections[i], &comp_data.ProSelection);
			status = ProSelectionAsmcomppathGet(selections[i], &asm_comp_path);

			for (int k = 0; k < asm_comp_path.table_num; ++k) {
				lastCompID = asm_comp_path.comp_id_table[k];
			}

			comp_data.ID = mdl_item.id;
			ProWstringToString(comp_data.Name, w_name);

			//status = ProSelectionModelitemGet(prt_selF2B01002[0], &modelitem[0]);
			//status = ProModelitemMdlGet(&modelitem[0], &Mdl[0]);
			//status = ProMdlMdlnameGet(Mdl[0], wname1);
			//ProWstringToString(cname1, wname1);
			//strcpy(seldata.name, cname1);
			//seldata.id = modelitem[0].id;
		//	ProWstringToString(comp_data.Description, param_value.value.s_val);
			compDataVector.push_back(comp_data);

			ruleLog.Write("Name: " + std::string(comp_data.Name) + "\tFeat_ID: " + std::to_string(comp_data.ID));
		}
		return true;
	};

	if (!handleSelection("For Frame End Bolt Selection!", surf_part_Sels1, n_sel1, CompData_F4A02005_vector1)) {
		return PRO_TK_NO_ERROR;
	}

	if (!handleSelection("For Axle End Bolt Selection!", surf_part_Sels2, n_sel2, CompData_F4A02005_vector2)) {
		return PRO_TK_NO_ERROR;
	}

	status = ProUIPushbuttonEnable(dialog, PB_RUN);
	status = ProUIPushbuttonDisable(dialog, PB_RSELECT1);
	status = ProUIDialogShow(dialog);
	return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES											| DESCRIPTION
------------------------------------------------------------------------------------------------------------------
IR-F4A05-003	|Pallavi Garodi	     | F4A05  	|Standard antiroll bar and its attachment across platform based on application
===================================================================================================================*/
#define DLG_IRF4A05_003    "dlg_IR_F4A05_003"
#define CommitOK            "CommitOK"
#define CommitCancel		"CommitCancel"
#define PB_SELECT           "select_pb"

ProSelection* Sel;
double dia;
int num_sel, k;
char              parentName[PRO_NAME_SIZE];
char              Decsription[PRO_NAME_SIZE]{};
vector<vector<string>> dbList2D_F4A05;
boolean _isProjectCodeFound = false;

int IRF4A05::IRF4A05_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF4B05::IRF4A05_003   ==========================");

	_isProjectCodeFound = false;
	ProCharPath rmrk1{};
	boolean found;
	string ARB_1, ARB_2;
	InterfaceRule     _irule;
	vector<string> projectCodes;
	string        rem_message;

	// get the submodule name from list
	for (int i = 0; i < subModulesList.size(); ++i)
	{
		if (subModulesList[i].name.find("F4A05") != string::npos)
		{
			_reqSMinfo = subModulesList[i];
			break;
		}
	}

	//get the project code of opened submodule
	project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
	ruleLog.Write("project code: " + to_string(project_code));
	
	//Fetch the data from CSV 
	//vector<string> reqValsFromCsv;
	vector<string> dia_1;
	vector<string>dia_2;
	
	//dia1
	getReqValsFrom2DCsvData("IRF4A05003.csv", 2, 3, project_code, dia_1);
	ruleLog.Write("getReqValsFrom2DCsvData1: " + to_string(status));
	ruleLog.Write("Size of vector1 is :" + to_string(dia_1.size()));
	if ((dia_1.size()) == 0) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Input Not Found", "Project Code is not present in CSV please update the data base.");
		return status;
	}

	//Printing the fetched data of 1st dia
	for (int i = 0; i < dia_1.size(); ++i)
	{
		double stand;
		ruleLog.Write(dia_1.at(i));
		ARB_1 = dia_1.at(i);
		ruleLog.Write("Expec Dia1 :" + ARB_1);
	}

	//dia2
	getReqValsFrom2DCsvData("IRF4A05003.csv", 2, 4, project_code, dia_2);
	ruleLog.Write("getReqValsFrom2DCsvData2: " + to_string(status));
	ruleLog.Write("Size of vector2 is :" + to_string(dia_2.size()));
	if ((dia_2.size()) == 0) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Input Not Found", "Project Code is not present in CSV please update the data base.");
		return status;
	}

	//Printing the fetched data of 1st dia
	for (int i = 0; i < dia_2.size(); ++i)
	{
		double stand;
		ruleLog.Write(dia_2.at(i));
		ARB_2 = dia_2.at(i);
		ruleLog.Write("Expec Dia2 :" + ARB_2);
	}

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF4A05_003, DLG_IRF4A05_003);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF4A05_003, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A05_003, PB_SELECT, (ProUIAction)select_action_IRF4A05_003, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A05_003, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A05_003, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF4A05_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF4A05_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits) {
		return -1;
	}

	status = ProGeomitemDiameterEval(Sel[0], &dia);
	ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status) + "\nDiameter :" + to_string(dia));
	string target = to_string(dia);
	ruleLog.Write("Dia :" + target);

	char		  removeZero[20];
	// rounding the values to two decimal place
	dia = round(dia * 100) / 100;

	// Remove trailing zeros from the second decimal place
	sprintf(removeZero, "%.2f", dia);
	int length = strlen(removeZero);
	while (length > 0 && removeZero[length - 1] == '0') {
		removeZero[length - 1] = '\0';
		length--;
	}
	ruleLog.Write(removeZero);

	if ((target >= ARB_1) && (target <= ARB_2))
	{
		isRightValue = true;
		final_res.result = "PASS";
	}
	else{
		final_res.result = "FAIL";
	}

	rem_message += "Measured value :";
	rem_message += "\nDiameter of the anti roll bar is " /*+ removeZero + "00mm."*/;
	sprintf(remark, " %.2lfmm", dia);
	rem_message += remark; 
	rem_message += "\n\nAcceptance criteria :";
	rem_message += "\nDiameter of the Standard Anti Roll Bar should be within " + ARB_1 + ".00mm to " + ARB_2 + ".00mm.";
	final_res.remark = rem_message;
	rem_message += "\n\nSelected Refrences :\n";
	rem_message += "Part Number - " + (string)parentName + "[" + Decsription + "]";
	final_res.remark = rem_message;

	//status = ProUIDialogShow(DLG_IRC_MAIN);

	/*if (isUserQuits)
		return -1;*/

	return 0;
}

ProError select_action_IRF4A05_003(char* dialog, char* component, ProAppData data)
{
	int            curWinId;
	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);

	status = ProSelect((char*)"surface", 1, NULL, NULL, NULL, NULL, &Sel, &num_sel);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (num_sel < 1 || status != 0) {
		status = ProUIPushbuttonDisable(DLG_IRF4A05_003, CommitOK);
		status = ProUIDialogShow(DLG_IRF4A05_003);
		return status;
	}

	ProAsmcomppath	  part_asmcomp_path;
	ProMdl	          parent_mdl;
	wchar_t           wParentMdlName[PRO_NAME_SIZE];
	ProModelitem      modelItem;
	ProParameter      pDesc;
	ProParamvalue     pvDesc;
	ProName pDescName = L"DESCRIPTION";
	ProAnnotationElem  annotelem;
	string             description;

	status = ProSelectionAsmcomppathGet(Sel[0], &part_asmcomp_path);
	ruleLog.Write("ProSelectionAsmcomppathGet = " + to_string(status));

	// to find the parent component
	//part_asmcomp_path.comp_id_table[part_asmcomp_path.table_num - 1] = -1;
	//part_asmcomp_path.table_num = part_asmcomp_path.table_num - 1;

	status = ProAsmcomppathMdlGet(&part_asmcomp_path, &parent_mdl);
	ruleLog.Write("ProAsmcomppathMdlGet = " + to_string(status));

	status = ProMdlMdlnameGet(parent_mdl, wParentMdlName);
	ProWstringToString(parentName, wParentMdlName);
	ruleLog.Write("cParentMdlName = " + (string)parentName);

	status = ProMdlToModelitem(parent_mdl, &modelItem);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	status = ProParameterInit(&modelItem, pDescName, &pDesc);
	ruleLog.Write("ProParameterInit: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)
	{
		status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
		ProWstringToString(Decsription, pvDesc.value.s_val);
		ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + Decsription);
		//description.append(Decsription);
	}

	status = ProUIPushbuttonEnable(DLG_IRF4A05_003, CommitOK);
	return PRO_TK_NO_ERROR;
}