/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 10-03-2024	|	V1_0_0		| H1A15 - ENGINE ASSY
==================================================================================================================*/
#include "H1A15.h"
#include "Utils.h"
#include <iomanip> //for setW()
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-H1A15-001	| MATHANPRASATH A	| MH1A15; MH1A08	| Standardization for gap between the Air Intake System Reducer hose and Exhaust Manifold.
===================================================================================================================*/
#define DLG_IRH1A15_011	"dlg_IR_H1A15_001" 
#define PB_RSELECT		"select_pb"
#define PB_RCLOSE		"CommitCancel"
#define PB_OK           "CommitOK"

//Parameters
#define H1A15_Param	    "dlg_H1A15_001_Parameters"
#define PB_RCANCEL		"Commit_Cancel"
#define PB_ROK			"Commit_Ok"

#define Label_PF        "Label_PF"
#define Label_VT        "Label_VT"
#define Label_PERF      "Label_PERF"
#define Label_Emission  "Label_Emission"
#define Label_Tc_Na     "Label_Tc_Na"
#define Lable_Torque    "Torque"
#define Lable_Power     "Power"
#define Label_Fuel      "Label_Fuel"
#define Label_Vol       "Label_Vol"
#define Label_ACR       "Label_ACR"
#define Label_Alt       "Label_Alt"
#define Label_CS        "Label_CS"


#define PF_Menu	         "PF_Menu"
#define VT_Menu	         "VT_Menu"
#define PERF_Menu	     "PERF_Menu"
#define EMI_Menu	     "EMI_Menu"
#define TC_Menu	         "TC_Menu"
#define Torque_Menu1     "Torq_Menu1"
#define Power_Menu1	     "Power_Menu1"
#define FT_Menu1	     "FT_Menu"
#define Vol_Menu	     "Vol_Menu"
#define ACR_Menu	     "ACR_Menu"
#define InputPanel_11	 "InputPanel_Alt"
#define InputPanel_12	 "InputPanel_CS"
#define DC1	             "DC1"
#define DC2	             "DC2"
#define DC3	             "DC3"
#define DC4	             "DC4"
#define DC5	             "DC5"
#define DC6	             "DC6"
#define Power_Menu2	     "Power_Menu2"
#define Torque_Menu2     "Torque_Menu2"
#define InputPanel_16	 "InputPanel_TurboCharge"
#define InputPanel_17	 "InputPanel_EST"
#define HFM_Menu	     "HFM_Menu"
#define ACD_Menu	     "ACD_Menu"
#define InputPanel_20	 "InputPanel_Service"
#define InputPanel_21	 "InputPanel_NVH"
#define InputPanel_22	 "InputPanel_Weight"
#define InputPanel_23	 "InputPanel_Cost"
#define InputPanel_24	 "InputPanel_WWH"
#define InputPanel_25	 "InputPanel_SH"
#define InputPanel_26	 "InputPanel_Owner"



vector<string>Param_input;
vector<string>Param_Value;
vector<string>Selected_Param;
vector<vector<string>>dbList2D_Param;
vector<string>Param_csv;
vector<string>Param_Value_csv;

string Param_remark;

struct Model_Tree_InformationIRH1A15_001
{
	string sub_mod_name;
	string name;
	string extension;
	int ID;
	string description;
	vector<int> ID_path;
	int ID_table_size;
};


ComponentData _reqCompsH1A15[2]{};
vector<int>ID_mapIRH1A15_001;
vector<Model_Tree_InformationIRH1A15_001> treeInformationVectorIRH1A15_001;
vector<Model_Tree_InformationIRH1A15_001> Selection_itemsIRH1A15_001;
ProSelection* SelsIRH1A15_001_1;
ProSelection SelsIRH1A15_001_2;
int tarrayIRH1A15_001[100] = { 0 }; // Initialize all elements to 0 (or any default value)
double Standard_dist_H1A15 = 25.00;
double computed_dist_H1A15;
string hose_name;
string mfold_name;
string remh1a15001;
string IRC_modules;
char** sel_Value_H1A15;

//vectors of option Menu:
vector<string>PF_menu; vector<string>VT_menu; vector<string>PERF_menu; vector<string>EMI_menu;vector<string>TC_menu; vector<string>Torque_menu1; vector<string>Power_menu1; vector<string>FT_menu1;
vector<string>Vol_menu; vector<string>ACR_menu; vector<string>Power_menu2; vector<string>Torque_menu2;
vector<string>HFM_menu; vector<string>ACD_menu;


//Vectors for Lable_text
vector<string>Vehicle_Engine;
vector<string>Engine_AIS;
vector<string>Vehicle_AIS;
vector<string>Duty_Cycle;
ostringstream table;
ProModelitem annotelem_1, annotelem_2;
int IRH1A15::IRH1A15_001(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRH2D01::IRH2D01_001   ==========================");
	status = ProWindowRepaint(PRO_VALUE_UNUSED);

	//Clearing all the vectors and strings for multiple run
	Param_Value.clear();
	Param_csv.clear();
	Selected_Param.clear();
	
	Selection_itemsIRH1A15_001.clear();
	treeInformationVectorIRH1A15_001.clear();
	remh1a15001.clear();
	ID_mapIRH1A15_001.clear();
	IRC_modules.clear();
	dbList2D_Param.clear();
	final_res.remark.clear();

	string comp_names[2];
	double clearance_vals;
	string Val = "value";
	Selected_Param.push_back(Val);
	isRightValue = FALSE;
	string reqCompSubMod[2] = { "H1A15", "H1A08" };
	isUserQuits = false;
	table.str("");
	
	//Load the standard parameters from csv:
	dbList2D_Param = getData2D("IRH1A15001_Param.csv");
	ruleLog.Write("dbList2D.size():" + to_string(dbList2D_Param.size()));

	for (int i = 0; i < dbList2D_Param.size(); ++i)
	{
		string tok1;
		std::istringstream ss1(dbList2D_Param[i][0]);

		while (std::getline(ss1, tok1, ';'))
		{
			trimString(tok1);
			Param_csv.push_back(tok1);
		}
	}	

	for (auto value : Param_csv)
	{
		ruleLog.Write("Parameter_CSV :" + value);
	}
	
	
	for (int i = 0; i < subModulesList.size(); ++i)
	{
		for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j)
		{
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
			{
				strcpy(_reqCompsH1A15[j].name, subModulesList[i].name.c_str());
				comp_names[j] = subModulesList[i].name;
			}
		}
	}

	IRC_modules += "Interfacing Modules: \n"+ comp_names[0]+", "+comp_names[1]+"\n";

	//Function for Parameter verfication.
	int status_1 = Parameter_Verfication();
	ruleLog.Write("Parameter_Verfication:" + to_string(status_1));

	if(status_1 != 0)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_INFO,"WARNING","Parameter Verfication is necessary before Cad Verfication.");
		return -1;
	}

	//UI for Cad Verification
	status = ProUIDialogCreate(DLG_IRH1A15_011, DLG_IRH1A15_011);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRH1A15_011, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRH1A15_011, PB_RCLOSE, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRH1A15_011, PB_RSELECT, (ProUIAction)select_action_IRH1A15_001, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRH1A15_011, PB_OK, (ProUIAction)ruleDlgOKactionH1A15, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUIDialogActivate(DLG_IRH1A15_011, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRH1A15_011);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;


	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqCompsH1A15);

	for (auto elem : _reqCompsH1A15)
	{
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}



	if (computed_dist_H1A15 >= Standard_dist_H1A15)
	{
		isRightValue = TRUE;
	}
	else
	{
		isRightValue = FALSE;
	}

	remh1a15001 = "\nDistance from " + hose_name + ".prt("+ to_string( annotelem_1.id)+") to " + mfold_name + ".prt(" + to_string(annotelem_2.id)+ ") = " + doubleToStringH1A15(computed_dist_H1A15) + "mm";
	remh1a15001.append("\nAcceptance criteria:\n Distance between Reducer Hose and Exhaust Manifold should be >=25.00mm");
	remh1a15001 += "\n--------------------------------------------------------------";
	final_res.remark = IRC_modules + remh1a15001 + "\n" + table.str();
	// DECLARE RESULT
	if (isRightValue)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	Selection_itemsIRH1A15_001.clear();
	treeInformationVectorIRH1A15_001.clear();
	remh1a15001.clear();
	ID_mapIRH1A15_001.clear();
	IRC_modules.clear();
	table.clear();

	dbList2D_Param.clear();
	return 0;

}

int Parameter_Verfication() 
{
	// Specify the file path where the CSV will be created
	string file_Path = "C:\\tmp\\temp.csv";
	bool isUserQuits = false;
	int dlg_sts{};

	// UI for Parameters Verfication
	status = ProUIDialogCreate(H1A15_Param, H1A15_Param);
	//ruleLog.Write("ProUIDialogCreate_param status = " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(H1A15_Param, PRO_B_FALSE);
	//ruleLog.Write("ProUIDialogAboveactivewindowSet_param status = " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(H1A15_Param, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(H1A15_Param, PB_ROK, (ProUIAction)ruleDlgOKaction_H1A15_001, NULL);
	//ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	
	
	PF_menu = { "Select","Zip", "Ace", "Intra", "Winger", "Yodha", "LCV", "ICV", "SFC", "MHCV truck" };
	status = Optionmenu_Create(PF_menu, PF_Menu);
	VT_menu = { "Select","Tilt Cabin", "Fixed Cabin", "Truck", "Tipper", "Teactor Trailor" };
	status = Optionmenu_Create(VT_menu, VT_Menu);
	PERF_menu = { "Select","4T", "7T", "9T", "10T", "12T","15T","16T","19T","25T","28T","30T","35T","42T","49T","55T" };
	status = Optionmenu_Create(PERF_menu, PERF_Menu);
	EMI_menu = { "Select","BS1", "BS2", "BS3", "BS4", "BS6 Phase-1", "BS6 Phase-2" };
	status = Optionmenu_Create(EMI_menu, EMI_Menu);
	/*TC_menu = { "Select","Turbocharged","Naturally Aspirated" };
	status = Optionmenu_Create(TC_menu, TC_Menu);*/
	Torque_menu1 = { "Select","285", "300", "390", "405", "420","450","590","850","950","1100" };
	status = Optionmenu_Create(Torque_menu1, Torque_Menu1);
	Power_menu1 = { "Select","85", "100", "125", "130", "155", "180","189","200","223","250","300" };
	status = Optionmenu_Create(Power_menu1, Power_Menu1);
	FT_menu1 = { "Select","Diesel", "CNG", "H2 ICE" };
	status = Optionmenu_Create(FT_menu1, FT_Menu1);
	Vol_menu = { "Select","12", "24" };
	status = Optionmenu_Create(Vol_menu, Vol_Menu);
	ACR_menu = { "Select","YES", "NO" };
	status = Optionmenu_Create(ACR_menu, ACR_Menu);
	/*status = Optionmenu_Create(Power_menu1, Power_Menu2);
	status = Optionmenu_Create(Torque_menu1, Torque_Menu2);*/
	HFM_menu = { "Select","Required", "Not Required" };
	status = Optionmenu_Create(HFM_menu, HFM_Menu);
	ACD_menu = { "Select","Required", "Not Required" };
	status = Optionmenu_Create(ACD_menu, ACD_Menu);


	//Input Panel enable for all the Parameters Verification
	//Vehicle --> Engine
	string PF{};
	status = ProUIOptionmenuSelectActionSet(H1A15_Param, PF_Menu, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);
	status = ProUIOptionmenuSelectActionSet(H1A15_Param, VT_Menu, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);
	status = ProUIOptionmenuSelectActionSet(H1A15_Param, PERF_Menu, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);
	status = ProUIOptionmenuSelectActionSet(H1A15_Param, EMI_Menu, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);
	//status = ProUIOptionmenuSelectActionSet(H1A15_Param, TC_Menu, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);
	status = ProUIOptionmenuSelectActionSet(H1A15_Param, Torque_Menu1, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);
	status = ProUIOptionmenuSelectActionSet(H1A15_Param, Power_Menu1, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);
	status = ProUIOptionmenuSelectActionSet(H1A15_Param, FT_Menu1, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);
	status = ProUIOptionmenuSelectActionSet(H1A15_Param, Vol_Menu, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);
	status = ProUIOptionmenuSelectActionSet(H1A15_Param, ACR_Menu, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);
	status = ProUIInputpanelEnable(H1A15_Param, InputPanel_11);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, InputPanel_11, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, InputPanel_12);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, InputPanel_12, (ProUIAction)inputValue_Param, &Param_input);

	//Duty Cycle
	status = ProUIInputpanelEnable(H1A15_Param, DC1);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, DC1, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, DC2);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, DC2, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, DC3);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, DC3, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, DC4);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, DC4, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, DC5);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, DC5, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, DC6);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, DC6, (ProUIAction)inputValue_Param, &Param_input);


	// Engine --> AIS
	/*status = ProUIOptionmenuSelectActionSet(H1A15_Param, Power_Menu2, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);
	status = ProUIOptionmenuSelectActionSet(H1A15_Param, Torque_Menu2, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);*/
	status = ProUIInputpanelEnable(H1A15_Param, InputPanel_16);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, InputPanel_16, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, InputPanel_17);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, InputPanel_17, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIOptionmenuSelectActionSet(H1A15_Param, HFM_Menu, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);
	status = ProUIOptionmenuSelectActionSet(H1A15_Param, ACD_Menu, (ProUIAction)Dropdown_action_IRH1A15_001, NULL);

	//Vehicle --> AIS
	status = ProUIInputpanelEnable(H1A15_Param, InputPanel_20);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, InputPanel_20, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, InputPanel_21);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, InputPanel_21, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, InputPanel_22);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, InputPanel_22, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, InputPanel_23);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, InputPanel_23, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, InputPanel_24);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, InputPanel_24, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, InputPanel_25);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, InputPanel_25, (ProUIAction)inputValue_Param, &Param_input);
	status = ProUIInputpanelEnable(H1A15_Param, InputPanel_26);
	status = ProUIOptionmenuInputActionSet(H1A15_Param, InputPanel_26, (ProUIAction)inputValue_Param, &Param_input);


	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(H1A15_Param, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(H1A15_Param);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

	if (isUserQuits)
	{
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	for (auto value : Selected_Param)
	{
		ruleLog.Write(" Parameter_Userinput :" + value);
	}

	//Param_remark += "/nParameters:";
	//Param_remark += "vechicle --> Engine";
	//for (int i = 0; i < 12; ++i) 
	//{

	//}

	// Create the CSV file and insert the vector data
	create_table( Param_csv, Selected_Param);

	return 0;
}

int create_table(vector<string>value1, vector<string>value2)
{
	ruleLog.Write("----------------------create_table-------------------------------");
	
	size_t max_left_width{};
	for (auto& item : value1) 
	{
		ruleLog.Write("1");
		if (item.length() > max_left_width) 
		{
			ruleLog.Write("2");
			max_left_width = item.length();
		}
	}

	int columnwidth =50;

	for (size_t i = 0; i < 1; ++i)
	{
		table <<left <<setw(max_left_width)<< value1[i] << "|" << left<< setw(columnwidth) << value2[i] << "\n--------------------------------------------------------------\n";
	}

	for (size_t i = 1; i < 13; ++i)
	{
		table << left << setw(max_left_width) << value1[i] << "|" << left << setw(columnwidth) << value2[i] << "\n";
	}
	for (size_t i = 19; i < 29; ++i)
	{
		table << left << setw(max_left_width) << value1[i] << "|" << left << setw(columnwidth) << value2[i] << "\n";
	}
	for (size_t i = 29; i < 30; ++i)
	{
		table << left << setw(max_left_width) << value1[i] << "|" << left << setw(columnwidth) << value2[i] << "\n--------------------------------------------------------------\n";
	}
	for (size_t i = 13; i < 17; ++i)
	{
		table << left << setw(max_left_width) << value1[i] << "|" << left << setw(columnwidth) << value2[i] << "\n";
	}
	for (size_t i = 17; i < 18; ++i)
	{
		table << left << setw(max_left_width) << value1[i] << "|" << left << setw(columnwidth) << value2[i] << "\n--------------------------------------------------------------\n";
	}
	for (size_t i = 18; i < 19; ++i)
	{
		table << left << setw(max_left_width) << value1[i] << "|" << left << setw(columnwidth) << value2[i] << "\n--------------------------------------------------------------\n";
	}

	ruleLog.Write(table.str());
	return 0;
}

void Create_CSV_H1A15_001(const string& file_Path, const vector<string>& vector1_name, const vector<string>& vector2_name)
{
		if (ifstream(file_Path))
		{
			remove(file_Path.c_str());
			ruleLog.Write("Existing file deleted at" + file_Path);
		}

		// Open a new file stream
		ofstream file(file_Path);
		if (!file.is_open()) 
		{
			ruleLog.Write("Error: Could not open file at" + file_Path);
			return;
		}

		// Write data to the CSV file
		size_t maxRows = max(vector1_name.size(), vector2_name.size());
		for (size_t i = 0; i < maxRows; ++i)
		{
			string value1 = i < vector1_name.size() ? vector1_name[i] : "";
			string value2 = i < vector2_name.size() ? vector2_name[i] : "";
			file << value1 << "," << value2 << endl;
		}

		file.close();
		ruleLog.Write("CSV file created and written successfully at "+ file_Path);
	
}

ProError Optionmenu_Create(vector<string>value,char *optionmenu)
{
	char** CapNames;
	wchar_t** CapLabels;
	vector<string> cap_fuel;

	ruleLog.Write("----------------------Optionmenu_Create-------------------------------");
	status = ProArrayAlloc(value.size(), sizeof(char*), 50, (ProArray*)&CapNames);
	status = ProArrayAlloc(value.size(), sizeof(wchar_t*), 50, (ProArray*)&CapLabels);

	for (int i = 0; i < value.size(); ++i)
	{
		CapNames[i] = (char*)calloc(50, sizeof(char));
		ProTKSprintf(CapNames[i], "%s", value[i]);

		CapLabels[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
		ProStringToWstring(CapLabels[i], CapNames[i]);
	}
	status = ProUIOptionmenuNamesSet(H1A15_Param, optionmenu, int(value.size()), CapNames);
	//ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(H1A15_Param, optionmenu, int(value.size()), CapLabels);
	//ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));
	return status;
}

ProError Dropdown_action_IRH1A15_001(char* dialog, char* component)
{
	ruleLog.Write("================= Dropdown_action_IRH1A15_001 ==================");
	return status;
}

ProError ruleDlgOKaction_H1A15_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgOKaction_H1A15_001 -----------------------------");

	wchar_t* wparamValue[PRO_NAME_SIZE];
	char cparamVal[PRO_NAME_SIZE];

	//Getting the Parameters input by user and push it back to a string vector:
	int n_sel;

	status = ProUIOptionmenuSelectednamesGet(dialog, PF_Menu, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIOptionmenuSelectednamesGet(dialog,VT_Menu , &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIOptionmenuSelectednamesGet(dialog, PERF_Menu, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIOptionmenuSelectednamesGet(dialog, EMI_Menu, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIOptionmenuSelectednamesGet(dialog, TC_Menu, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIOptionmenuSelectednamesGet(dialog, Torque_Menu1, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIOptionmenuSelectednamesGet(dialog, Power_Menu1, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIOptionmenuSelectednamesGet(dialog, FT_Menu1, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIOptionmenuSelectednamesGet(dialog, Vol_Menu, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIOptionmenuSelectednamesGet(dialog, ACR_Menu, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIInputpanelValueGet(dialog, InputPanel_11, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, InputPanel_12, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, DC1, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, DC2, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, DC3, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, DC4, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, DC5, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, DC6, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	/*status = ProUIOptionmenuSelectednamesGet(dialog, Power_Menu2, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIOptionmenuSelectednamesGet(dialog, Torque_Menu2, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));*/

	status = ProUIInputpanelValueGet(dialog, InputPanel_16, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, InputPanel_17, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIOptionmenuSelectednamesGet(dialog, HFM_Menu, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIOptionmenuSelectednamesGet(dialog, ACD_Menu, &n_sel, &sel_Value_H1A15);
	Selected_Param.push_back(string(sel_Value_H1A15[0]));

	status = ProUIInputpanelValueGet(dialog, InputPanel_20, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, InputPanel_21, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, InputPanel_22, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, InputPanel_23, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, InputPanel_24, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, InputPanel_25, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	status = ProUIInputpanelValueGet(dialog, InputPanel_26, wparamValue);
	ProWstringToString(cparamVal, *wparamValue);
	Selected_Param.push_back(cparamVal);

	

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);

	return PRO_TK_NO_ERROR;
}

ProError inputValue_Param(char* dialog, char* component, vector<string>* offsetValVec)
{
	ruleLog.Write("----------------------------- inputValue_parameter_value -----------------------------");
	wchar_t* wparamValue[PRO_NAME_SIZE];
	char cparamVal[PRO_NAME_SIZE];

	status = ProUIInputpanelValueGet(dialog,component, wparamValue);
	//ruleLog.Write("ProUIInputpanelValueGet: " + to_string(status));

	ProWstringToString(cparamVal,*wparamValue);
	//ruleLog.Write("Parameter value :" + string(cparamVal));


	return PRO_TK_NO_ERROR;
}


ProError select_action_IRH1A15_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRH1A15_001  --------------------------");
	int n_sels;
	wchar_t wIpVal[50];
	InterfaceRule iRule;
	
	char nameofsel_1[PRO_NAME_SIZE];
	char nameofsel_2[PRO_NAME_SIZE];
	ProMdl mdl_1,mdl_2;
	wchar_t model_1,model_2;

	//get the Info of selection_1
	status = ProSelect((char*)"part", 2, NULL, NULL, NULL, NULL, &SelsIRH1A15_001_1, &n_sels);
	ruleLog.Write("ProSelect status = " + to_string(status));
	if (n_sels ==2) 
	{
		status = ProUIPushbuttonEnable(DLG_IRH1A15_011, PB_OK);
		ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));

		status = ProSelectionModelitemGet(SelsIRH1A15_001_1[0], &annotelem_1);
		ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

		status = ProModelitemMdlGet(&annotelem_1, &mdl_1);
		ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

		status = ProMdlMdlnameGet(mdl_1, &model_1);
		ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

		ProWstringToString(nameofsel_1, &model_1);
		string s1(nameofsel_1);

		//store it in a string for result 
		hose_name = nameofsel_1;

		//get the Info of selection_2
		status = ProSelectionModelitemGet(SelsIRH1A15_001_1[1], &annotelem_2);
		ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

		status = ProModelitemMdlGet(&annotelem_2, &mdl_2);
		ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

		status = ProMdlMdlnameGet(mdl_2, &model_2);
		ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

		ProWstringToString(nameofsel_2, &model_2);
		//store it in a string for result 
		string s2(nameofsel_2);
		mfold_name = nameofsel_2;

	}
	if (status == PRO_TK_USER_ABORT || n_sels < 2)
	{
		iRule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}
	
	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	
	return status;
}

ProError ruleDlgOKactionH1A15(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgOKaction -----------------------------");

	//Measure the clearance between selected parts:
	double distance;
	ProBoolean is_interference_found;
	Pro3dPnt pnt_arr[2];
	double param_1, param_2;
	double pnt_1, pnt_2;
	//status = ProFitClearanceCompute(SelsIRH1A15_001_1[0], PRO_FIT_INCLUDE_NONE, SelsIRH1A15_001_1[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, SelsIRH1A15_001_1[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	//ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));	//status = ProFitClearanceCompute(sela2, PRO_FIT_INCLUDE_NONE, sela1, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, sela1, PRO_B_FALSE, &distance, NULL, &interf, coord);
	//
	status = ProSelectionWithOptionsDistanceEval(SelsIRH1A15_001_1[0], PRO_B_TRUE, SelsIRH1A15_001_1[1], PRO_B_TRUE, &param_1, &param_2, &pnt_1, &pnt_2, &distance);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status)+"\nDistance" + to_string(distance));
    

	//computedf5a27006 = distance;
	computed_dist_H1A15 = distance;

	status = ProSelectionHighlight(SelsIRH1A15_001_1[0], PRO_COLOR_SELECTED);
	status = ProSelectionHighlight(SelsIRH1A15_001_1[1], PRO_COLOR_SELECTED);

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return PRO_TK_NO_ERROR;
}

std::string trimH1A15(const std::string& strH1A15)
{
	// Find the first character that is not a space
	std::size_t start = strH1A15.find_first_not_of(" \t\n\r");

	// Find the last character that is not a space
	std::size_t end = strH1A15.find_last_not_of(" \t\n\r");

	// If both start and end are valid positions
	if (start != std::string::npos && end != std::string::npos) {
		// Extract the substring without leading and trailing spaces
		return strH1A15.substr(start, end - start + 1);
	}
	else {
		// If no non-space characters found, return an empty string
		return "";
	}
}

string doubleToStringH1A15(double value)
{
	std::stringstream stream;
	stream << std::fixed << std::setprecision(2) << value;
	return stream.str();
}





/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR_H1A15_006	| MATHANPRASATH A	| MH1A14, MH1A01	| For HCV Application-For the open blade fan , Radial Clearance between Fan blade Tip & Shroud should be minimum 18 mm.
===================================================================================================================*/
//#define dlg_IR_H1A15_006     "dlg_IR_H1A15_006" 
//#define FUEL_CAPACITY	     "select_option_menu"
//#define PLATFRM_LIST         "platform_option_menu"
//#define PB_CANCEL		     "CommitCancel" 
//#define PB_OK			     "CommitOK"
//#define PB_SELECT            "select_pb"
//ProSelection* sel_surf;
//int numsurf_sels;
//int IRH1A15::IRH1A15_006(ruleResult& final_res)
//{
//	ruleLog.Write("==========================   IRH1A15::IRH1A15_006   ==========================");
//	
//	double fan_dis,dia1,dia2;
//	ProCharPath surf_Parents_info{};
//	isUserQuits = false;
//	status = ProUIDialogCreate(dlg_IR_H1A15_006, dlg_IR_H1A15_006);
//	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
//	status = ProUIDialogAboveactivewindowSet(dlg_IR_H1A15_006, PRO_B_FALSE);
//	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
//	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A15_006, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
//	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
//	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A15_006, PB_OK, (ProUIAction)ruleDlgOKaction, NULL);
//	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
//	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A15_006, PB_SELECT, (ProUIAction)select_action_IRH1A15_006, (ProAppData)&isUserQuits);
//	ruleLog.Write("fuel_cap_ProUIOptionmenuSelectActionSet: " + to_string(status));
//	
//
//	status = ProUIDialogHide(DLG_IRC_MAIN);
//	status = ProUIDialogActivate(dlg_IR_H1A15_006, &dlg_sts);
//	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
//	status = ProUIDialogDestroy(dlg_IR_H1A15_006);
//	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
//	status = ProUIDialogShow(DLG_IRC_MAIN);
//	
//	if (isUserQuits)
//		return -1;
//	ProModelitem surf_1,surf_2;
//	ProFeature surf_feat1, surf_feat2;
//	ProMdl sur_mdl1, sur_mdl2;
//	wchar_t wsurmdlName1[PRO_NAME_SIZE];
//	char csurmdlName1[PRO_NAME_SIZE];
//	wchar_t wsurmdlName2[PRO_NAME_SIZE];
//	char csurmdlName2[PRO_NAME_SIZE];
//	status = ProSelectionModelitemGet(sel_surf[0], &surf_1);
//	status = ProSelectionModelitemGet(sel_surf[1], &surf_2);
//
//	status = ProGeomitemFeatureGet((ProGeomitem*)&surf_1, &surf_feat1);
//	ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id1 = " + to_string(surf_feat1.id));
//
//	status = ProGeomitemFeatureGet((ProGeomitem*)&surf_2, &surf_feat2);
//	ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id2 = " + to_string(surf_feat2.id));
//
//
//	status = ProModelitemMdlGet(&surf_1, &sur_mdl1);
//	status = ProModelitemMdlGet(&surf_2, &sur_mdl2);
//
//	status = ProMdlMdlnameGet(sur_mdl1, wsurmdlName1);
//	ProWstringToString(csurmdlName1, wsurmdlName1);
//	ruleLog.Write("Axis model Name :" + string(csurmdlName1));
//	status = ProMdlMdlnameGet(sur_mdl2, wsurmdlName2);
//	ProWstringToString(csurmdlName2, wsurmdlName2);
//	ruleLog.Write("Axis model Name :" + string(csurmdlName2));
//
//	status = ProGeomitemDiameterEval(sel_surf[0], &dia1);
//	ruleLog.Write("measureDistanceBetweenSurfaces status= " + to_string(status) + "\nFan Blade distance " + to_string(dia1));
//	status = ProGeomitemDiameterEval(sel_surf[1], &dia2);
//	ruleLog.Write("measureDistanceBetweenSurfaces status= " + to_string(status) + "\nFan Blade distance " + to_string(dia2));
//	/*status = measureDistanceBetweenSurfaces(sel_surf[0], sel_surf[1],fan_dis);
//	ruleLog.Write("measureDistanceBetweenSurfaces status= " + to_string(status) + "\nFan Blade distance " + to_string(fan_dis));*/
//	double act_dia1 = dia1 / 2.0;
//	ruleLog.Write("actual dia1 =" + to_string(act_dia1));
//	double act_dia2 = dia2 / 2.0;
//	ruleLog.Write("actual dia2 =" + to_string(act_dia2));
//	double act_dia = act_dia1 - act_dia2;
//	ruleLog.Write("actual dia =" + to_string(act_dia));
//
//	if (act_dia < 0)
//	{
//		act_dia = std::abs(act_dia);
//
//	}
//	
//
//	if (act_dia >= 18)
//	{
//		final_res.result = "PASS";
//		ruleLog.Write("actual dia =" + to_string(act_dia));
//		sprintf(remark, "Measured Value: Distance between fan blade tip and Shroud is %0.2lf mm.\nAcceptance Criteria : Radial Clearance between Fan blade Tip & Shroud should be minimum 18 mm.",act_dia);
//		sprintf(surf_Parents_info, "\nReferences:\nSurface_id 1: %d, Partnumber: %s.\nSurface_id 2: %d, Partnumber: %s.", surf_feat1.id, csurmdlName1, surf_feat2.id, csurmdlName2);
//		final_res.remark = string(remark) + surf_Parents_info;
//	}
//	else
//	{
//		final_res.result = "FAIL";
//		ruleLog.Write("actual dia =" + to_string(act_dia));
//		sprintf(remark, "Measured Value: Distance between fan blade tip and Shroud is %0.2lf mm.\nAcceptance Criteria : Radial Clearance between Fan blade Tip & Shroud should be minimum 18 mm.", act_dia);
//		sprintf(surf_Parents_info, "\nReferences:\nSurface_id 1: %d, Partnumber: %s.\nSurface_id 2: %d, Partnumber: %s.", surf_feat1.id, csurmdlName1, surf_feat2.id, csurmdlName2);
//		final_res.remark = string(remark) + surf_Parents_info;
//	}
//		
//	/* your code goes here */
//
//	return 0;
//}
//
//ProError select_action_IRH1A15_006(char* dialog, char* component, ProAppData data) 
//{
//	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &sel_surf, &numsurf_sels);
//	ruleLog.Write("Proselect status= " + to_string(status) + "\nNo.of Selection " + to_string(numsurf_sels));
//
//	if (status == PRO_TK_NO_ERROR) 
//	{
//		status = ProUIPushbuttonEnable(dlg_IR_H1A15_006, PB_OK);
//		ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));
//	}
//	return status;
//}