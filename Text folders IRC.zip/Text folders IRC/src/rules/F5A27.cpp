/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	|	V1_0_0		| F5A27 - BRAKING SYSTEM RULES
==================================================================================================================*/
#include "F5A27.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5A27_003		| Atharva Patil		| MF5A27			| Vacuum tank length to be design according to the required capacity.
===================================================================================================================*/

#define DLG_IRF5A27_003				"dlg_IR_F5A27_003"
#define Label1						"Label1"
#define Label2						"Label2"
#define PB_CANCEL					"CommitCancel"
#define PB_OK						"CommitOK"
#define PB_IMG						"rule_img"
#define tonnage_cap					"tonnage_cap"

vector<string>						tonCapacityList, partNumbers, tankCapacity;
string								partName, remarkMsgt, shellName, capRmkMsg;


struct tankInfo
{
	int projCode;
	string tonCap;
	double tankCap;
	string prtName;
};

tankInfo tankShell;
vector<tankInfo> tankVector;
int IRF5A27::IRF5A27_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5A27::IRF5A27_003   ==========================");
	ruleLog.Write("Vacuum tank length to be design according to the required capacity.");
	remarkMsgt.erase();
	string optionMenuActionData[2] = { PB_IMG,"IR_F5A27_003" };
	const regex tonCapPattn("\\d+(\\.\\d+)?[T]");
	smatch found;
	//Get the Project code
	for (int i = 0; i < subModulesList.size(); ++i)
	{
		if (subModulesList[i].name.find("F5A27") != string::npos)
		{
			_reqSMinfo = subModulesList[i];
			break;
		}
	}
	project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
	ruleLog.Write("Project Code: " + to_string(project_code));

	//Get the tonnage capacity associated with the project code
	tonCapacityList.clear();
	getReqValsFrom2DCsvData("IRF5A27003.csv", 1, 2, project_code, tonCapacityList);
	ruleLog.Write(to_string(tonCapacityList.size()));

	//Get the tank capacity values
	tankCapacity.clear();
	getReqValsFrom2DCsvData("IRF5A27003.csv", 1, 3, project_code, tankCapacity);
	ruleLog.Write(to_string(tankCapacity.size()));

	//Get the part numbers
	partNumbers.clear();
	getReqValsFrom2DCsvData("IRF5A27003.csv", 1, 4, project_code, partNumbers);
	ruleLog.Write(to_string(partNumbers.size()));

	//Writing the values from vectors to an object of type struct 
	for (int i = 0; i < tonCapacityList.size(); i++)
	{
		tankShell.projCode = project_code;
		ruleLog.Write("PC");
		tankShell.tankCap = stod(tankCapacity.at(i));
		ruleLog.Write(to_string(tankShell.tankCap));
		tankShell.prtName = partNumbers.at(i);
		ruleLog.Write(tankShell.prtName);
		tankShell.tonCap = tonCapacityList.at(i);
		ruleLog.Write("Ton capacity is: " + tankShell.tonCap);
		/*if (regex_search(tonCapacityList.at(i), found, tonCapPattn))
		{
			ruleLog.Write("Match found");
			tankShell.tonCap = stod(found[0].str());
			ruleLog.Write(to_string(tankShell.tonCap));
		}
		else
		{
			ruleLog.Write("No match found for " + tonCapacityList.at(i));
		}*/

		tankVector.push_back(tankShell);
		ruleLog.Write("Vec pb actn");
	}

	//Create a UI and set actions for push Buttons
	status = ProUIDialogCreate(DLG_IRF5A27_003, DLG_IRF5A27_003);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRF5A27_003, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A27_003, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A27_003, PB_OK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogHide main: " + to_string(status));
	status = ProUIPushbuttonHide(DLG_IRF5A27_003, PB_IMG);
	ruleLog.Write("ProUIPushbuttonHide img: " + to_string(status));
	status = ProUIPushbuttonDisable(DLG_IRF5A27_003, PB_OK);
	ruleLog.Write("ProUIPushbuttonDisable ok: " + to_string(status));
	//status = ProUILabelHide(DLG_IRF5A27_003, Label2);


	//Create a drop down menu in case of multiple options for the same PC
	char** tonnageCapacityNames;
	wchar_t** tonnageCapacityLables;
	if (tonCapacityList.size() > 1)
	{

		status = ProUIPushbuttonBitmapSet(DLG_IRF5A27_003, PB_IMG, "IR_F5A27_003/Select.png"); //Default image
		status = ProUIPushbuttonShow(DLG_IRF5A27_003, PB_IMG);
		ruleLog.Write("=========== Multiple Ton capacity ========");

		status = ProArrayAlloc(tonCapacityList.size(), sizeof(char*), 1, (ProArray*)&tonnageCapacityNames);
		ruleLog.Write("ProArrayAlloc names " + to_string(status));
		status = ProArrayAlloc(tonCapacityList.size(), sizeof(wchar_t*), 1, (ProArray*)&tonnageCapacityLables);
		ruleLog.Write("ProArrayAlloc lables" + to_string(status));

		for (int i = 0; i < tonCapacityList.size(); i++)
		{
			ruleLog.Write("=========== Inside for loop for naming and labeling ========");
			tonnageCapacityNames[i] = (char*)calloc(5, sizeof(char));
			ProTKSprintf(tonnageCapacityNames[i], "%s", tonCapacityList[i]);

			tonnageCapacityLables[i] = (wchar_t*)calloc(5, sizeof(wchar_t));
			ProStringToWstring(tonnageCapacityLables[i], tonnageCapacityNames[i]);
		}

		status = ProUIOptionmenuNamesSet(DLG_IRF5A27_003, tonnage_cap, int(tonCapacityList.size()), tonnageCapacityNames);
		ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));

		status = ProUIOptionmenuLabelsSet(DLG_IRF5A27_003, tonnage_cap, int(tonCapacityList.size()), tonnageCapacityLables);
		ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));
		status = ProArrayFree((ProArray*)&tonnageCapacityNames);
		ruleLog.Write("ProArrayFree: " + to_string(status));
		status = ProArrayFree((ProArray*)&tonnageCapacityLables);
		ruleLog.Write("ProArrayFree: " + to_string(status));
		status = ProUIOptionmenuSelectActionSet(DLG_IRF5A27_003, tonnage_cap, (ProUIAction)optionMenuImageChangeAction_F5A27_003,
			(ProAppData)&optionMenuActionData);
		ruleLog.Write("ProUIOptionmenuSelectActionSet :  " + to_string(status));
	}
	else
	{
		ruleLog.Write("=========== No Ton cap category ========");

		//Hide UI things
		status = ProUILabelHide(DLG_IRF5A27_003, Label1);
		ruleLog.Write("ProUILabelHide:  " + to_string(status));
		status = ProUIOptionmenuHide(DLG_IRF5A27_003, tonnage_cap);
		ruleLog.Write("ProUIOptionmenuHide:  " + to_string(status));
		capRmkMsg = tankCapacity.at(0).erase(tankCapacity.at(0).find_last_not_of('0') + 1, string::npos);;
		//Get the part number associated with it
		char imgName[PRO_NAME_SIZE];
		ProTKSprintf(imgName, "%s/%s.png", "IR_F5A27_003", partNumbers.at(0));
		ruleLog.Write("Image name is: " + (string)imgName);
		ruleLog.Write("=========== image name copied ========");
		partName = partNumbers.at(0);
		partName.append(".ASM");
		ruleLog.Write("partName is : " + partName);

		status = ProUIPushbuttonBitmapSet(DLG_IRF5A27_003, PB_IMG, imgName);
		ruleLog.Write("ProUIPushbuttonBitmapSet else: " + to_string(status));
		status = ProUIPushbuttonShow(DLG_IRF5A27_003, PB_IMG);
		ruleLog.Write("ProUIPushbuttonShow : " + to_string(status));
		status = ProUILabelShow(DLG_IRF5A27_003, Label2);
		status = ProUIPushbuttonEnable(DLG_IRF5A27_003, PB_OK);
		ruleLog.Write("ProUIPushbuttonEnable ok: " + to_string(status));
	}
	status = ProUIDialogActivate(DLG_IRF5A27_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate multi ton: " + to_string(status));

	if (isUserQuits) {
		status = ProUIDialogDestroy(DLG_IRF5A27_003);
		ruleLog.Write("ProUIDialogDestroy close action: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	//Get the part number used for the tank shell
	const regex descpattn("(VACUUM TANK ASSY)");
	vector<PartnameDescriptionPair> nameDescList;


	status = ProSolidFeatVisit((ProSolid)curMdl, (ProFeatureVisitAction)getVisitedCompAsmNamesAndDescriptionTank, compsFilter, &nameDescList);
	ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));

	ruleLog.Write("=============Inside for loop for vector iteration=========");
	ruleLog.Write("Description values are");
	for (int i = 0; i < nameDescList.size(); i++)
	{
		if (regex_search(nameDescList.at(i).description, descpattn))
		{
			shellName.append(nameDescList.at(i).part_name);
			shellName.append(".ASM");
			ruleLog.Write("Shell name is: " + shellName);
			break;
		}
	}

	//Close after rule run
	status = ProUIDialogDestroy(DLG_IRF5A27_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	//Write the remarks

	remarkMsgt += "Tank shell used: " + shellName;
	remarkMsgt += "\nAcceptance criteria : Capacity: " + capRmkMsg + "L,Part Name: " + partName;

	final_res.remark = remarkMsgt;

	//Declare Results
	ruleLog.Write("Shell name before results:  " + shellName + "part Name : " + partName);
	if (shellName == partName)
	{
		final_res.result = "PASS";
	}
	else
		final_res.result = "FAIL";
	shellName.erase();
	return 0;
}

ProError getVisitedCompAsmNamesAndDescriptionTank(ProFeature* p_feature, ProError status, vector<PartnameDescriptionPair>* compList)
{
	ProMdl					reqMdl;
	wchar_t					wMdlName[PRO_NAME_SIZE];
	char					cMdlName[PRO_NAME_SIZE];
	PartnameDescriptionPair	comp;
	ProModelitem			modelItem;
	ProParameter            pDesc;
	ProParamvalue           pvDesc;
	ProName                 pDescName = L"DESCRIPTION";
	char                    existingPval[PRO_NAME_SIZE];
	ProMdlType				mdlType;

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	ruleLog.Write("ProAsmcompMdlGet status: " + to_string(status));
	if (status == PRO_TK_NO_ERROR)
	{
		status = ProMdlMdlnameGet(reqMdl, wMdlName);
		ruleLog.Write("ProMdlMdlnameGet status: " + to_string(status));
		ProWstringToString(cMdlName, wMdlName);
		strcpy(comp.part_name, cMdlName);
		ruleLog.Write("Comp name is: " + (string)comp.part_name);

		status = ProMdlToModelitem(reqMdl, &modelItem);
		ruleLog.Write("ProMdlToModelitem status: " + to_string(status));
		status = ProParameterInit(&modelItem, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit status: " + to_string(status));
		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ruleLog.Write("ProParameterValueWithUnitsGet status: " + to_string(status));
			ProWstringToString(existingPval, pvDesc.value.s_val);
			strcpy(comp.description, existingPval);
			ruleLog.Write("comp.description is: " + (string)comp.description);

		}
		status = ProMdlTypeGet(reqMdl, &mdlType);
		ruleLog.Write("ProMdlTypeGet status: " + to_string(status));
		comp.mdlType = mdlType;
		compList->push_back(comp);
		if (mdlType == PRO_MDL_ASSEMBLY)
		{
			status = ProSolidFeatVisit((ProSolid)reqMdl, (ProFeatureVisitAction)getVisitedCompAsmNamesAndDescriptionTank, compsFilter, compList);
		}

	}

	return PRO_TK_NO_ERROR;
}

//Image change action
ProError optionMenuImageChangeAction_F5A27_003(char* dialog, char* component, ProAppData data)
{
	InterfaceRule _irule;
	ruleLog.Write("----------------------------- optionMenuImageChangeAction -----------------------------");
	string* reqData = (string*)data;
	int n_sel;
	string target;
	char** selValue;

	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet cb fn: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue[0]));

	char imgName[PRO_NAME_SIZE], cPbName[PRO_NAME_SIZE];

	target = selValue[0];
	ruleLog.Write("Target is: " + target);
	partName.clear();
	strcpy(cPbName, reqData[0].c_str());
	for (int j = 0; j < tankVector.size(); j++)
	{
		ruleLog.Write("Elements:" + tankVector.at(j).prtName);
		if (target == tankVector.at(j).tonCap)
		{
			ruleLog.Write("target matched with " + tankVector.at(j).tonCap);
			string t = to_string(tankVector.at(j).tankCap);
			capRmkMsg = t.erase(t.find_last_not_of('0') + 1, string::npos);

			partName = tankVector.at(j).prtName;
			ProTKSprintf(imgName, "%s/%s.png", "IR_F5A27_003", tankVector.at(j).prtName);
			ruleLog.Write("Image name is: " + (string)imgName);
			status = ProUIPushbuttonBitmapSet(dialog, cPbName, imgName);
			ruleLog.Write("ProUIPushbuttonBitmapSet multi ton: " + to_string(status));
			/*status = ProUIPushbuttonShow(dialog, cPbName);
			ruleLog.Write("ProUIPushbuttonShow : " + to_string(status));*/
			status = ProUILabelShow(dialog, Label2);
			break;
		}
	}

	//Get the part number associated with it
	//for (int i = 1; i < csvData2D.size(); ++i)	// i = 1 for skipping the headers
	//{
	//	ruleLog.Write("=============Inside for loop for fetching the value from IRF5A27003_1.csv=========");
	//	if (stoi(csvData2D[i][1]) == stoi(selValue[0]))
	//	{
	//		string tok1;
	//		istringstream ss1(csvData2D[i][2]);
	//		while (getline(ss1, tok1, ';')) {
	//			/*reqValsFromCsv.push_back(tok1);*/
	//			partName = tok1;
	//			ruleLog.Write("Part name for selected capacity is:" + partName);
	//		}
	//		break;
	//	}
	//}
	//csvData2D.clear();

	partName.append(".ASM");
	ruleLog.Write("Part name is" + partName);
	status = ProUIPushbuttonEnable(DLG_IRF5A27_003, PB_OK);
	ruleLog.Write("ProUIPushbuttonEnable ok multi ton: " + to_string(status));
	return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5A27004		| Mathanprasath A	| MF5A27			| Vacuum tank mounting bracket holes and pitch (vertical & horizontal) to be defined.
===================================================================================================================*/
#define DLG_IRF5A27_004		"dlg_IR_F5A27_004" 
#define OM_NO_OF_HOLES		"no_of_holes_om" 
#define PB_CANCEL			"CommitCancel" 
#define PB_SELECT			"pb_select" 
#define PB_OK				"CommitOK"
#define PB_IMG				"pb_img"

ProSelection* vt_holes_sels;
int n_vt_holes_sels;
vector<double> vt_holes_diameters, vt_holes_pitches;
bool vt_invalid_sel;
char** sel_Value;

int no_of_holes = 4;
string info_f5A27_004;
int IRF5A27::IRF5A27_004(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5A27::IRF5A27_004   ==========================");
	//int no_of_holes;
	info_f5A27_004.clear();
	vt_invalid_sel = false;
	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF5A27_004, DLG_IRF5A27_004);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF5A27_004, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A27_004, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);

	string optionMenuActionData[2] = { PB_IMG, "IR_F5A27_004" };
	status = ProUIOptionmenuSelectActionSet(DLG_IRF5A27_004, OM_NO_OF_HOLES, (ProUIAction)f5a27_004_optionMenuImageChangeAction, (ProAppData)&optionMenuActionData);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A27_004, PB_SELECT, (ProUIAction)select_action_IRF5A27004, (ProAppData)&no_of_holes);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A27_004, PB_OK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIPushbuttonBitmapSet(DLG_IRF5A27_004, PB_IMG, "IR_F5A27_004/4.png");	//default image for 4 holes

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF5A27_004, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF5A27_004);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if ((isUserQuits) || (vt_invalid_sel))	// check for user quits in close_action
		return -1;

	double param1, param2, param3, param4;
	double pnt1, pnt2, pnt3, pnt4;




	// 4 HOLES SELECTION
	if (no_of_holes == 4)
	{
		// measure the pitch values
		for (int i = 0; i < 3; ++i)
		{
			for (int j = i + 1; j < 4; ++j)
			{
				double dist;
				status = ProSelectionWithOptionsDistanceEval(vt_holes_sels[i], PRO_B_TRUE, vt_holes_sels[j], PRO_B_TRUE, &param1, &param2, &pnt1, &pnt2, &dist);
				vt_holes_pitches.push_back(dist);
			}
		}
		// sort to push the diagnols to the end
		sortVector(vt_holes_pitches);
		for (int i = 0; i <= 5; i++)
			ruleLog.Write("Pitch = " + to_string(vt_holes_pitches[i]));

		if (!_utils.compareFloat(vt_holes_pitches[4], vt_holes_pitches[5]))	// comparing the diagnols for validating if vt_holes_pitches are similar
		{
			string warning_msg = "The Horizontal and Vertical vt_holes_pitches of selected fasteners are unequal. The Pitch values are " + to_string(int(vt_holes_pitches[0])) + "mm and " + to_string(int(vt_holes_pitches[1])) + "mm.";
			UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Pitch mismatch!", warning_msg);
			vt_holes_pitches.clear();
			vt_holes_diameters.clear();
			return -1;
		}
		vt_holes_pitches.erase(vt_holes_pitches.end() - 2, vt_holes_pitches.end());	// remove the 2 diagnol values at end of the vector
	}

	string measured_vt_holes_pitches;
	vt_holes_pitches.erase(std::unique(vt_holes_pitches.begin(), vt_holes_pitches.end()), vt_holes_pitches.end());
	for (auto pitch : vt_holes_pitches)
		measured_vt_holes_pitches.append(to_string(int(pitch)) + "mm, ");

	/*int check = 0;
	for (int i = 0; i < 4; i++)
	{
	if (_utils.compareFloat(vt_holes_diameters[0], vt_holes_diameters[i]) == 0)
	{
	check++;
	ProSelectionHighlight(vt_holes_sels[i], PRO_COLOR_WARNING);
	}
	}

	if (check > 0)
	{
	ruleLog.Write("Diameter of Holes are not equal");
	}
	else
	{
	ruleLog.Write("Diameter of holes are equal");
	}

	double diagonal1, diagonal2;
	diagonal1 = sqrt(pow(distance[0], 2) + pow(distance[2], 2));
	diagonal2 = sqrt(pow(distance[1], 2) + pow(distance[3], 2));
	ruleLog.Write("diagonal1 = "+to_string(diagonal1));
	ruleLog.Write("diagonal2 = "+to_string(diagonal2));*/

	// 3 HOLES SELECTION
	if (no_of_holes == 3)
	{
		// measure the pitch values
		for (int i = 1; i < n_vt_holes_sels; ++i)
		{
			double dist;
			status = ProSelectionWithOptionsDistanceEval(vt_holes_sels[0], PRO_B_TRUE, vt_holes_sels[i], PRO_B_TRUE, &param1, &param2, &pnt1, &pnt2, &dist);
			vt_holes_pitches.push_back(dist);
		}
		// sort to push the diagnols to the end
		sortVector(vt_holes_pitches);
		for (int i = 0; i < vt_holes_pitches.size(); i++)
			ruleLog.Write("Pitch = " + to_string(vt_holes_pitches[i]));

		double vertical_dist = sqrt(pow(vt_holes_pitches[1], 2) - pow(vt_holes_pitches[0] / 2, 2));	// pythagoras theorum
		ruleLog.Write("vertical_dist = " + to_string(vertical_dist));

		vt_holes_pitches.pop_back(); // remove the diagnol pitch value
		vt_holes_pitches.push_back(vertical_dist);	// add the vertical pitch value
	}

	csvData2D = getData2D("IRF5A27004.csv");
	for (int i = 1; i < csvData2D.size(); ++i)	// i = 1 for skipping the headers
	{
		string NoOfHoles, HoleDia, xVal, yVal;
		/*std::istringstream ss1(csvData2D[i][0]);
		while (std::getline(ss1, NoOfHoles, ','))
		{
			ruleLog.Write("NoOfHoles "+NoOfHoles);
		}*/

		acceptance_criteria.append("[" + csvData2D[i][1] + ", " + csvData2D[i][2] + "x" + csvData2D[i][3] + "], ");

		std::istringstream ss2(csvData2D[i][1]);
		while (std::getline(ss2, HoleDia, ',')) {
			ruleLog.Write("HoleDia " + HoleDia);
			if (int(vt_holes_diameters[0]) == stoi(HoleDia.substr(1)))
			{
				std::istringstream ss3(csvData2D[i][2]);
				while (std::getline(ss3, xVal, ','))
				{
					for (int j = 0; j < vt_holes_pitches.size(); ++j)
					{
						if (int(vt_holes_pitches[j]) == stoi(xVal))
						{
							ruleLog.Write("i: " + to_string(i) + "\txVal :" + xVal);
							std::istringstream ss4(csvData2D[i][3]);
							while (std::getline(ss4, yVal, ',')) {
								for (int k = 0; k < vt_holes_pitches.size(); ++k)
								{
									if (int(vt_holes_pitches[k]) == stoi(yVal))
									{
										ruleLog.Write("yVal " + yVal);
										isRightValue = true;
									}
								}
							}
						}

					}
				}
			}
		}
		//ruleLog.Write("xxxxxxxx For loop ends");
	}

	ruleLog.Write("Acceptance Criteria: " + acceptance_criteria);

	if (isRightValue)
	{
		final_res.result = "PASS";
		sprintf(remark, "The diameter %dmm and pitch values %s are according to standards; Acceptance criteria: %s", int(vt_holes_diameters[0]), measured_vt_holes_pitches.c_str(), acceptance_criteria.c_str());
	}
	else
	{
		final_res.result = "FAIL";
		sprintf(remark, "The diameter %dmm and pitch values %s are not according to standards; Acceptance criteria: %s", int(vt_holes_diameters[0]), measured_vt_holes_pitches.c_str(), acceptance_criteria.c_str());
	}
	final_res.remark = remark + info_f5A27_004;

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	csvData2D.clear();
	vt_holes_diameters.clear();
	vt_holes_pitches.clear();

	return 0;
}

ProError select_action_IRF5A27004(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRF5A27004  --------------------------");
	int* no_of_holes = (int*)data;
	int cur_win_id;
	

	/*if (reinterpret_cast<int>(selValue[0]) == 4)
	{
		no_of_holes = 4;
		ruleLog.Write("No of Holes:" + no_of_holes);
	}
	else
	{
		 no_of_holes = 3;
		 ruleLog.Write("No of Holes:"+ no_of_holes);
	}*/

	status = ProSelect("surface", *no_of_holes, NULL, NULL, NULL, NULL, &vt_holes_sels, &n_vt_holes_sels);
	ruleLog.Write("ProSelect = " + to_string(status));
	ProWindowCurrentGet(&cur_win_id);
	ProWindowRepaint(cur_win_id);
	InterfaceRule _inrule;

	if (status == PRO_TK_USER_ABORT)
	{
		//_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_OK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}
	else if (n_vt_holes_sels < *no_of_holes || status != PRO_TK_NO_ERROR)
	{
		_inrule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_OK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}

	/*if (status != PRO_TK_NO_ERROR || n_vt_holes_sels < *no_of_holes) {
		vt_invalid_sel = true;
		return status;
	}*/

	// validate for curved surface and fetch the vt_holes_diameters
	for (int i = 0; i < n_vt_holes_sels; i++)
	{
		double _dia;
		status = ProGeomitemDiameterEval(vt_holes_sels[i], &_dia);
		ruleLog.Write("ProGeomitemDiameterEval = " + to_string(status) + "\tDiameter = " + to_string(_dia));
		if (status != PRO_TK_NO_ERROR || _dia <= 0) {
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please select proper fastener surfaces.");
			vt_holes_diameters.clear();
			vt_invalid_sel = true;
			return status;
		}
		vt_holes_diameters.push_back(_dia);
	}

	for (int i = 1; i < vt_holes_diameters.size(); i++) {
		if (!_utils.compareFloat(vt_holes_diameters[0], vt_holes_diameters[i])) {
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "vt_holes_diameters mismatch!", "The diamters of selected fasteners are unequal.");
			vt_holes_diameters.clear();
			vt_invalid_sel = true;
			return status;
		}
	}


	ProModelitem mdlitem_1, mdlitem_2;
	ProMdl mdl_1, mdl_2;
	wchar_t model_1, model_2;
	char namesel_1[PRO_NAME_SIZE];
	//char namesel_2[PRO_NAME_SIZE];
	info_f5A27_004.clear();
	info_f5A27_004 += "\nSelection Info:";

	for (int i = 0; i < n_vt_holes_sels; ++i)
	{
		status = ProSelectionModelitemGet(vt_holes_sels[i], &mdlitem_1);
		ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

		/*status = ProModelitemMdlGet(&mdlitem_1, &mdl_1);
		ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));*/

		status = ProMdlMdlnameGet(mdlitem_1.owner, &model_1);
		ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

		ProWstringToString(namesel_1, &model_1);
		info_f5A27_004 += "\nPart Name:" + string(namesel_1) + ",Surace Id :" + to_string(mdlitem_1.id);
	}
	status = ProUIPushbuttonEnable(dialog, PB_OK);

	return PRO_TK_NO_ERROR;
}

ProError f5a27_004_optionMenuImageChangeAction(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- optionMenuImageChangeAction -----------------------------");

	string* reqData = (string*)data;
	int noOfsel;

	status = ProUIOptionmenuSelectednamesGet(dialog, component, &noOfsel, &sel_Value);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("selValue = " + string(sel_Value[0]));
	no_of_holes = stoi(sel_Value[0]);

	char imgName[PRO_NAME_SIZE], cPbName[PRO_NAME_SIZE];
	ProTKSprintf(imgName, "%s/%s.png", reqData[1], sel_Value[0]);
	strcpy(cPbName, reqData[0].c_str());
	status = ProUIPushbuttonBitmapSet(dialog, cPbName, imgName);
	ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));

	return PRO_TK_NO_ERROR;
}



/*==================================================================================================================
RULE ID			| DEVELOPER			    | DEPENDENT MODULES	        | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5A27_005		| Vinay Neel			| MF5A27; MF1A01; MF2C01 	| Clearance between vacuum tank with nearby static & dynamic aggregates
===================================================================================================================*/

#define DLG_IRF5A27_005 "dlg_IR_F5A27_005"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"
#define PB1_RSELECT      "rule_select1_pb"
#define PB2_RSELECT      "rule_select2_pb"

ProSelection* selF5A27005;
vector<string> selection_partsF5A27005;
int n_selF5A27005;
ProSelection* vac_tank_F5A27;
string final_res005 = "";
string tankName;
vector<ProSelection> vac_tank_sel;
ProMdl reqMdlF5A27;
int dtmptcount005 = 1;

int IRF5A27::IRF5A27_005(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5A27::IRF5A27_005   ==========================");

	/* your code goes here */

	final_res005 = "";
	ComponentData _reqComps[3]{};
	string reqCompSubMod[3] = { "F5A27","F1A01", "F2C01" };
	double clearance_value, std_clearance = 20.0;
	vector<double> clearance_values;

	status = ProWindowRepaint(PRO_VALUE_UNUSED);


	for (int i = 0; i < subModulesList.size(); ++i)
		for (int j = 0; j < 3; ++j)
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
				strcpy(_reqComps[j].name, subModulesList[i].name.c_str());

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps);
	ruleLog.Write("ProSolidFeatVisit1: " + to_string(status));

	for (auto elem : _reqComps) {
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}

	ProName comp1_name;
	vector<ComponentData> _reqCompsVtank;
	//  ProModelitem feature;
	ProStringToWstring(comp1_name, _reqComps[0].name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdlF5A27);
	ruleLog.Write("ProMdlnameInitF2b01: " + to_string(status));

	//F5A27 as a main assembly (it will travers only in F5A27)
	status = ProSolidFeatVisit((ProSolid)reqMdlF5A27, getVisitedCompAsmNamesAction_F5A27005, compsFilter, (ProAppData)&_reqCompsVtank);
	ruleLog.Write("ProSolidFeatVisit reqMdlF5A27: " + to_string(status));
	ruleLog.Write("vac_tank_sel.size(): " + to_string(vac_tank_sel.size()));

	if (_reqCompsVtank.size() != 0) {
		for (auto elem : _reqCompsVtank) {
			ruleLog.Write("_reqCompsVtank[0].name = " + string(elem.name));
			ruleLog.Write("_reqCompsVtank[0].id = " + to_string(elem.id));
		}

	}


	isUserQuits = false;

	status = ProUIDialogCreate(DLG_IRF5A27_005, DLG_IRF5A27_005);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRF5A27_005, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A27_005, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A27_005, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A27_005, PB1_RSELECT, (ProUIAction)select_action1_IR5A27005, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A27_005, PB2_RSELECT, (ProUIAction)select_action2_IR5A27005, NULL);

	status = ProUIPushbuttonDisable(DLG_IRF5A27_005, PB_ROK);

	if (vac_tank_sel.size() != 0) {
		ruleLog.Write("Inside if");
		ProUIMessageButton btn_choice = UserDisplayPopupMessage_OK_CANCEL(PROUIMESSAGE_INFO, "Info", "The Vacuum tank assy has been automatically selected.\nPlease select the nearby static parts.\n\nClick on OK to proceed");
		if (btn_choice == PRO_UI_MESSAGE_CANCEL) {
			tankName.clear();
			vac_tank_sel.clear();

			return -1;
		}
		status = ProUIPushbuttonDisable(DLG_IRF5A27_005, PB1_RSELECT);
		status = ProUIPushbuttonEnable(DLG_IRF5A27_005, PB2_RSELECT);
	}
	else {
		ruleLog.Write("Inside else");
		ProUIMessageButton btn_choice = UserDisplayPopupMessage_OK_CANCEL(PROUIMESSAGE_INFO, "Info", "The Vacuum tank assy is not found.\nPlease select the Vacuum Tank assy and nearby static parts.\n\nClick on OK to proceed");
		if (btn_choice == PRO_UI_MESSAGE_CANCEL) {
			return -1;
		}
		status = ProUIPushbuttonDisable(DLG_IRF5A27_005, PB2_RSELECT);
	}

	deleteDatumPoint("datum_PNT1");
	deleteDatumPoint("datum_PNT2");


	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF5A27_005, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF5A27_005);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);


	if (isUserQuits)
		return -1;


	//measuring the clearance between the Vaccum tank and propeller shaft
	Pro3dPnt pnt1_arr[2];
	//status = ProSelectionHighlight(vac_tank_sel[0], PRO_COLOR_ERROR);

	measureDistanceBetweenASMandComponentIR5A27005(vac_tank_sel[0], _reqComps[2], clearance_value, pnt1_arr);
	createDatumPointsIR5A27005(pnt1_arr, "CSYS_ASM_DEF");
	ruleLog.Write("clearance_value = " + to_string(clearance_value));
	clearance_value = round(clearance_value * 100) / 100;

	//measuring the clearance between the Vaccum tank and user selected parts
	for (int i = 0; i < n_selF5A27005; ++i)
	{
		double val;
		ProBoolean interf;
		Pro3dPnt pnt2_arr[2];
		status = ProFitClearanceCompute(vac_tank_sel[0], PRO_FIT_INCLUDE_NONE, selF5A27005[i], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &val, NULL, &interf, pnt2_arr);
		ruleLog.Write("ProFitClearanceCompute = " + to_string(status) + "\ndistance = " + to_string(val));
		//createDatumPointsIR5A27005(pnt2_arr, "CSYS_ASM_DEF");
		val = round(val * 100) / 100;
		clearance_values.push_back(val);
	}


	for (int i = 0; i < n_selF5A27005; ++i) {
		clearance_values[i] = round(clearance_values[i] * 100) / 100;
	}

	isRightValue = true;
	for (auto vals : clearance_values) {
		if (vals < std_clearance) {
			isRightValue = false;
			break;
		}
	}

	//Highlighting the selected parts where the clearance is <20mm

	if (isRightValue == false)
	{
		for (int i = 0; i < n_selF5A27005; ++i) {
			if (clearance_values[i] < std_clearance)
			{
				ProSelectionHighlight(selF5A27005[i], PRO_COLOR_ERROR);
			}
		}
		ProSelectionHighlight(vac_tank_sel[0], PRO_COLOR_ERROR);
	}

	if (clearance_value >= 50 && isRightValue)
	{
		final_res.result = "PASS";
	}
	else
		final_res.result = "FAIL";

	status = ProSelectionHighlight(vac_tank_sel[0], PRO_COLOR_ERROR);

	// DECLARE RESULT
	final_res005 += "Result:\nMeasured Values:";
	final_res005 += "\n\nClearance between " + tankName + " (Vaccum Tank) and " + "\n " + string(_reqComps[2].name) + ".ASM (Propeller shaft)";

	sprintf(remark, ": %.2lfmm;Acceptance criteria for dynamic parts(i.e. Propeller shaft) : >= 50.00mm", clearance_value);
	final_res005 += remark;

	final_res005 += "\n\nClearance between " + tankName + " (Vaccum Tank) and \n below user selected static parts";
	for (int i = 0; i < n_selF5A27005; ++i) {
		sprintf(remark, "\n -%s: %.2lfmm", selection_partsF5A27005[i].c_str(), clearance_values[i]);
		final_res005 += remark;
	}
	final_res005 += "\nAcceptance criteria for nearby static parts: >= 20.00mm";

	//	final_res005 += "\nUsed refrence part: " + string(cname) + ".PRT (ID:" + to_string(feature.id) + ")";

	final_res.remark = final_res005;


	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	n_selF5A27005 = 0;
	tankName.clear();
	final_res005.clear();
	selection_partsF5A27005.clear();
	vac_tank_sel.clear();
	dtmptcount005 = 1;
	return 0;
}
ProError select_action1_IR5A27005(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action1_IR5A27005  --------------------------");


	int n_sels;
	ProSelection sel_copy;
	status = ProSelect((char*)"prt_or_asm", 1, NULL, NULL, NULL, NULL, &vac_tank_F5A27, &n_sels);
	ruleLog.Write("ProSelect1: " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_IRF5A27_005, PB2_RSELECT);
		return status;
	}

	if (n_sels < 1 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(DLG_IRF5A27_005, PB2_RSELECT);
		return status;
	}

	//Get the id and name of vaccum tank
	ProMdlName		wname;
	char            cname[PRO_MDLNAME_SIZE];
	ProFeature feature;
	ProMdl subModuleMdl;
	ProMdlType subModuleMdlType;

	status = ProSelectionModelitemGet(vac_tank_F5A27[0], &feature);
	ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));
	status = ProMdlMdlnameGet(feature.owner, wname);
	status = ProModelitemMdlGet(&feature, &subModuleMdl);
	status = ProMdlTypeGet(subModuleMdl, &subModuleMdlType);
	ruleLog.Write("ProMdlTypeGet status = " + to_string(status));

	ProWstringToString(cname, wname);
	tankName = cname;

	if (subModuleMdlType == PRO_MDL_ASSEMBLY)
		tankName.append(".ASM");
	else
		tankName.append(".PRT");

	ruleLog.Write("part_name: " + string(cname));
	ruleLog.Write("id: " + to_string(feature.id));

	status = ProSelectionCopy(vac_tank_F5A27[0], &sel_copy);
	if (n_sels > 0 && n_sels == 1) {
		vac_tank_sel.push_back(sel_copy);
		status = ProUIPushbuttonEnable(DLG_IRF5A27_005, PB2_RSELECT);
		return status;
	}

	return status;
}
ProError select_action2_IR5A27005(char* dialog, char* component, ProAppData data)
{

	ruleLog.Write("--------------------------  select_action2_IR5A27005  --------------------------");

	status = ProUIDialogHide(dialog);
	ruleLog.Write("ProUIDialogHide status = " + to_string(status));

	ProModelitem annotelem;
	char nameofsel[PRO_NAME_SIZE];
	wchar_t model;
	int curWinId;


	status = ProSelect((char*)"prt_or_asm", -1, NULL, NULL, NULL, NULL, &selF5A27005, &n_selF5A27005);
	ruleLog.Write("Proselect status = " + to_string(status));
	ruleLog.Write("Number of selections = " + to_string(n_selF5A27005));

	status = ProWindowCurrentGet(&curWinId);
	ruleLog.Write("ProWindowCurrentGet status = " + to_string(status));

	status = ProWindowRepaint(curWinId);
	ruleLog.Write("ProWindowRepaint status = " + to_string(status));

	status = ProUIDialogShow(dialog);
	ruleLog.Write("ProUIDialogShow status = " + to_string(status));

	for (int i = 0; i < n_selF5A27005; ++i)
	{
		ProMdl mdl;
		ProMdlType subModuleMdlType;

		status = ProSelectionModelitemGet(selF5A27005[i], &annotelem);
		ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

		status = ProModelitemMdlGet(&annotelem, &mdl);
		ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

		status = ProMdlMdlnameGet(mdl, &model);
		ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

		//status = ProMdlTypeGet(mdl, &subModuleMdlType);
		//ruleLog.Write("ProMdlTypeGet status = " + to_string(status));

		ProWstringToString(nameofsel, &model);
		std::string models(nameofsel);

		/*	if (subModuleMdlType == PRO_MDL_ASSEMBLY)
				models.append(".ASM");
			else
				models.append(".PRT");
		*/
		models.append(".PRT");
		selection_partsF5A27005.push_back(models);
	}


	status = ProUIPushbuttonEnable(dialog, PB_ROK);

	return status;
}
int measureDistanceBetweenASMandComponentIR5A27005(ProSelection& asm_sel, ComponentData reqComp2, double& distance, Pro3dPnt(&pnt_arr)[2])
{
	ruleLog.Write("=================> measureDistanceBetweenASMandComponentIR5A27005 <=================");

	ProSelection sels[2];
	ProIdTable idtbl2 = { reqComp2.id };		// component id of the component 2 to be selected

	ProName comp1_name, comp2_name;
	ProModelitem feature[2];
	ProMdl reqMdls[2];

	ProStringToWstring(comp2_name, reqComp2.name);
	status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[1], &feature[1]);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProAsmcomppath path[2];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl2, 1, &path[1]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	ProBoolean is_interference_found;
	//Pro3dPnt pnt_arr[2];
	status = ProFitClearanceCompute(asm_sel, PRO_FIT_INCLUDE_NONE, sels[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, asm_sel, PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));

	return 0;
}
ProError getVisitedCompAsmNamesAction_F5A27005(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("----------------------------- getVisitedCompAsmNamesAction_FFA27005 -----------------------------");

	vector<ComponentData>* namesList = (vector<ComponentData>*)app_data;
	//required sub-module under the parent sub-module
	ProMdl reqMdl;
	ProMdlType subModuleMdlType;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ComponentData cd;
	ProModelitem modelItem;
	ProAsmcomppath		p_comp_path;
	char existingPval[PRO_NAME_SIZE]{};

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
	status = ProMdlMdlnameGet(reqMdl, wFeatName);
	ProWstringToString(cFeatName, wFeatName);

	status = ProMdlToModelitem(reqMdl, &modelItem);

	ProParameter pDesc;
	ProParamvalue pvDesc;
	ProName pDescName = L"DESCRIPTION";

	status = ProParameterInit(&modelItem, pDescName, &pDesc);
	ruleLog.Write("ProParameterInit: " + to_string(status));


	if (subModuleMdlType == PRO_MDL_ASSEMBLY && status == PRO_TK_NO_ERROR) {

		status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
		ProWstringToString(existingPval, pvDesc.value.s_val);

		const regex p("(VACUUM TANK ASSY)");

		if (regex_search(existingPval, p) != 0)
		{

			ProSelection p_selection_vtank;

			strcpy(cd.name, cFeatName);
			cd.id = p_feature->id;
			namesList->push_back(cd);
			ruleLog.Write("cFeatName: " + string(cFeatName));

			ProIdTable	comp_id_table = { cd.id };
			ruleLog.Write("comp_id_table[0] =  " + to_string(comp_id_table[0]));

			//reqMdlF5A27 as a parent sub-module
			status = ProAsmcomppathInit((ProSolid)reqMdlF5A27, comp_id_table, 1, &p_comp_path);
			ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

			status = ProSelectionAlloc(&p_comp_path, &modelItem, &p_selection_vtank);
			ruleLog.Write("ProSelectionAlloc: " + to_string(status));

			if (status == PRO_TK_NO_ERROR) {
				tankName = cFeatName;
				tankName.append(".ASM");
				vac_tank_sel.push_back(p_selection_vtank);
			}

		}
	}
	ProSolidFeatVisit((ProSolid)reqMdl, getVisitedCompAsmNamesAction_F5A27005, compsFilter, (ProAppData)namesList);


	return PRO_TK_NO_ERROR;
}
int createDatumPointsIR5A27005(Pro3dPnt pnt_arr[2], char* csysName) {

	ruleLog.Write("=================> createDatumPointsIR5A27005 <=================");
	ProElement	elem_tree, elem_ftype, elem_feature_name,
		pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
		pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
		pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
	ProReference REPDEP_ref1;
	wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wide_string[PRO_NAME_SIZE], wide_string_2[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE];
	//CSYS_ASM_DEF
	ProModelitem refCsysitem;
	ProSelection refCsysSel, reqMdlSel;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pnt_feat;
	ProErrorlist errors;
	//converting negative values to positive
	double d1 = -pnt_arr[0][2];
	double d2 = -pnt_arr[1][2];
	string PointName = "Dist_highlght_pnt" + to_string(dtmptcount005);
	char cDatumPointName[PRO_NAME_SIZE];
	strcpy(cDatumPointName, PointName.c_str());

	ProStringToWstring(wCsysName, csysName);
	status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
	status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);


	//Create Element Tree
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	//feature name
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, cDatumPointName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
	ruleLog.Write("feature name = " + to_string(status));

	//PRO_E_DPOINT_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
	ruleLog.Write("type status = " + to_string(status));

	//Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);

	//ref
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
	status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
	status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);

	//
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);

	//Populating array element
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);

	//Point1
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);

	//Point1 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
	ProStringToWstring(wide_string, "datum_PNT1");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);

	//Point2
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);

	//Point2 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
	ProStringToWstring(wide_string_2, "datum_PNT2");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);

	/* =============================================================== *\
	Create Model Selection Object
	\* =============================================================== */

	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Points
	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	status = ProElementFree(&elem_tree);
	status = ProSelectionFree(&reqMdlSel);

	ProSelection pnt_Sel;
	status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
	status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_SS_FAILED_ITEMS);
	//PRO_COLOR_SELECTED for green highlight
	++dtmptcount005;
	return 0;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5A27_006		| Ved Aiyar			| MF5A27; MA1B01; 	| Clearance of vacuum tank with load body to be maintained at least as 80 mm. (**Depending up project requirement dimensional requirement can be compromised but complete components level and vehicle level validation to be done to ensure robustness)
===================================================================================================================*/
#define DLG_IRF5A27_006	"dlg_IR_F5A27_006" 
#define PB_RSELECT		"select_pb"
#define PB_ROK			"CommitOK"
#define PB_RCLOSE		"CommitCancel"

//typedef struct user_appdataf5a27006
//{
//	FILE* fp;
//	int level;
//} UserAppdata;
//
//struct Model_Tree_InformationF5A27
//{
//	string sub_mod_name;
//	string name;
//	string extension;
//	int ID;
//	string description;
//	vector<int> ID_path;
//	int ID_table_size;
//};


ProSelection* sel_brac;
string sel_inf;
string bracket_name;

int IRF5A27::IRF5A27_006(ruleResult& final_res)
{
	vector<int>ID_mapf5a27006;


	string remf5a27006 = "";
	vector<ProSelection> selaf5a27006;
	vector<Model_Tree_Information> treeInformationVectorf5a27;
	vector<Model_Tree_Information> Selection_itemsf5a27;

	string reqCompSubMod[1] = {"A1B01"};
	string comp_names[1];
	double clearance_vals;
	isUserQuits = false;
	ComponentData _reqCompsf5a27[1]{};
	int tarrayf5a27006[100] = { 0 }; // Initialize all elements to 0 (or any default value)
	double standardf5a27006 = 80.00;
	double computedf5a27006;
	deleteDatumPointf5a27("datum_PNT1");
	deleteDatumPointf5a27("datum_PNT2");
	remf5a27006.append("Distance measured from ");

	for (int i = 0; i < subModulesList.size(); ++i)
	{
		for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j)
		{
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
			{
				strcpy(_reqCompsf5a27[j].name, subModulesList[i].name.c_str());
				comp_names[j] = subModulesList[i].name;
				//ruleLog.Write(comp_names[j]+"---------------------------------------");
			}
		}
	}

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqCompsf5a27);


	for (auto elem : _reqCompsf5a27)
	{
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}

	status = ProUIDialogCreate(DLG_IRF5A27_006, DLG_IRF5A27_006);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF5A27_006, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A27_006, PB_RCLOSE, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A27_006, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A27_006, PB_RSELECT, (ProUIAction)select_action_IRF5A27_006, NULL);
	status = ProUIPushbuttonDisable(DLG_IRF5A27_006, PB_ROK);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF5A27_006, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF5A27_006);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	double dis;
	int status = measureDistanceBetweenSurfaceAndComp(_reqCompsf5a27[0], sel_brac[0], dis);
	ruleLog.Write("measureDistanceBetweenSurfaceAndComp: " + to_string(status));

	string act_clrnce;
	act_clrnce = to_string(round(dis));
	act_clrnce.erase(act_clrnce.find_last_not_of('0') + 3);

	isRightValue = false;
	string r_msg = "";
	r_msg += "Measured Value:\nClearance between load body (" + string(_reqCompsf5a27[0].name) + ".ASM)" + " and Vaccum tank is " + act_clrnce + "mm.\n";
	r_msg += "\nAcceptance Criteria: Clearance of vacuum tank with load body to be maintained at least as 80 mm.\nSelection Reference:\n1.";
	

	if (dis < standardf5a27006)
	{
		isRightValue = FALSE;
	}
	else
	{
		isRightValue = TRUE;
	}


	//// Iterate through the vector
	//for (const auto& item : Selection_itemsf5a27) {
	//	// Check if the description contains the substring "SHELL"
	//	if (item.name.find("A1B01") != std::string::npos) {
	//		// If found, print the corresponding name
	//		remf5a27006.append(item.name + ".asm is " + doubleToStringf5a27(computedf5a27006) + "mm.\nAcceptance criteria >=80.00mm");
	//	}
	//}

	final_res.remark = r_msg + sel_inf;
	// DECLARE RESULT
	if (isRightValue)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	remf5a27006.clear();
	Selection_itemsf5a27.clear();
	treeInformationVectorf5a27.clear();
	r_msg.clear();
	sel_inf.clear();
	bracket_name.clear();
	return 0;

}

ProError f5a27ruleDlgOKaction(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgOKaction -----------------------------");
	vector<int>ID_mapf5a27006;


	string remf5a27006 = "";
	vector<ProSelection> selaf5a27006;
	vector<Model_Tree_Information> treeInformationVectorf5a27;
	vector<Model_Tree_Information> Selection_itemsf5a27;

	int tarrayf5a27006[100] = { 0 };
	char name[PRO_MDLNAME_SIZE];
	char type[PRO_MDLEXTENSION_SIZE];
	ProError status;
	UserAppdata appdata;
	FILE* fp{};
	ProMdl p_asm;
	ProMdl reqMdlsair1hs, mdl;
	ProMdlName modelName;
	ProMdlExtension modelExtension;
	//double distance;
	int count = -1;
	Pro3dPnt pnt_arr[2];
	//int ex, tail, sil;


	status = ProMdlCurrentGet(&p_asm);
	status = ProMdlMdlnameGet(p_asm, modelName);
	ProWstringToString(name, modelName);
	status = ProMdlExtensionGet(p_asm, modelExtension);
	ProWstringToString(type, modelExtension);

	appdata.fp = fp;
	appdata.level = 1;

	status = ProSolidFeatVisit((ProSolid)p_asm, user_actionf5a27006, UserAsmCompFilterf5a27, &appdata);

	/*for (int i = 0; i < treeInformationVectorf5a27.size(); i++)
	{
		ruleLog.Write("Sub-Module: " + treeInformationVectorf5a27[i].sub_mod_name + "Name: " + treeInformationVectorf5a27[i].name + " ID: " + to_string(treeInformationVectorf5a27[i].ID) + " Description: " + treeInformationVectorf5a27[i].description + " ID Path:");
		for (int id : treeInformationVectorf5a27[i].ID_path)
		{
			ruleLog.Write(to_string(id));
		}

	}*/

	for (int i = 0; i < treeInformationVectorf5a27.size(); i++)
	{
		if (treeInformationVectorf5a27[i].name.find("A1B01") != std::string::npos)
		{
			Model_Tree_Information tree2;
			//tree2.sub_mod_name = "F3B06 (Tail)";
			tree2.name = string(treeInformationVectorf5a27[i].name);
			tree2.extension = string(treeInformationVectorf5a27[i].extension);
			tree2.ID = treeInformationVectorf5a27[i].ID;
			tree2.description = treeInformationVectorf5a27[i].description;
			tree2.ID_path = treeInformationVectorf5a27[i].ID_path;

			Selection_itemsf5a27.push_back(tree2);
		}

	}

	for (int i = 0; i < Selection_itemsf5a27.size(); i++)
	{
		ruleLog.Write("Name: " + Selection_itemsf5a27[i].name + " Extension: " + Selection_itemsf5a27[i].extension + " ID: " + to_string(Selection_itemsf5a27[i].ID) + " Description: " + Selection_itemsf5a27[i].description + " ID Path:");
		for (int id : Selection_itemsf5a27[i].ID_path)
		{
			ruleLog.Write(to_string(id));
		}
	}

	for (int i = 0; i < Selection_itemsf5a27.size(); i++)
	{
		/*if (i == reference_idx)
		{
			continue;
		}*/
		ProIdTable id_table{};
		ProMdl reqMdlsair;
		ProName compair;
		ProModelitem featureair;
		// Create a character array with a size one larger than the string to accommodate the null terminator
		char charArray[100];

		// Copy the contents of the std::string to the character array
		strcpy(charArray, Selection_itemsf5a27[i].name.c_str());
		ProStringToWstring(compair, charArray);

		if (Selection_itemsf5a27[i].extension.find("ASM") != std::string::npos)
		{
			status = ProMdlnameInit(compair, PRO_MDLFILE_ASSEMBLY, &reqMdlsair);
			ruleLog.Write("ProMdlnameInit status = " + to_string(status));
		}
		else if (Selection_itemsf5a27[i].extension.find("PRT") != std::string::npos)
		{
			status = ProMdlnameInit(compair, PRO_MDLFILE_PART, &reqMdlsair);
			ruleLog.Write("ProMdlnameInit status = " + to_string(status));
		}

		status = ProMdlToModelitem(reqMdlsair, &featureair);
		ruleLog.Write("ProMdlToModelitem status = " + to_string(status));

		vector temp = Selection_itemsf5a27[i].ID_path;
		int vectorSize = Selection_itemsf5a27[i].ID_path.size();
		//tbl1_sizef5a27006 = vectorSize;

		for (int j = 0; j < vectorSize; ++j)
		{
			tarrayf5a27006[j] = temp[j];
		}

		// Print the elements in the array
		//std::cout << "Array elements:";

		for (int j = 0; j < vectorSize; ++j)
		{
			id_table[j] = tarrayf5a27006[j];
		}

		ProAsmcomppath pathair;
		ProSelection sel;
		status = ProAsmcomppathInit((ProSolid)curMdl, id_table, vectorSize, &pathair);
		ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));

		status = ProSelectionAlloc(&pathair, &featureair, &sel);
		ruleLog.Write("ProSelectionAlloc status = " + to_string(status));

		selaf5a27006.push_back(sel);
		/*status = ProSelectionHighlight(selaf1c02_004[i], PRO_COLOR_HIGHLITE);
		ruleLog.Write("ProSelectionHighlight status = " + to_string(status));*/

	}

	/*ProBoolean  interf;
	Pro3dPnt coord[2];
	double param[2];
	double pnt[2];*/
	double distance;
	//int count1 =0 ;
	double standardf5a27006 = 80.00;
	double computedf5a27006;
	ProBoolean is_interference_found;
	//Pro3dPnt pnt_arr[2];
	status = ProFitClearanceCompute(selaf5a27006[0], PRO_FIT_INCLUDE_NONE, selaf5a27006[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, selaf5a27006[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));	//status = ProFitClearanceCompute(sela2, PRO_FIT_INCLUDE_NONE, sela1, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, sela1, PRO_B_FALSE, &distance, NULL, &interf, coord);
	computedf5a27006 = distance;

	createDatumPointsF5A27(pnt_arr, "CSYS_ASM_DEF");

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);

	return PRO_TK_NO_ERROR;
}

ProError user_actionf5a27006(ProFeature* feature, ProError status, ProAppData appdata)
{
	ruleLog.Write("----------------------------- user_actionf5a27006 -----------------------------");
	FILE* fp;
	int level;
	ProMdl mdl27;
	char name27[PRO_MDLNAME_SIZE];
	char type[PRO_MDLEXTENSION_SIZE];
	UserAppdata* appd, appd1;
	ProMdlName modelName;
	ProMdlExtension modelExtension;
	ProAsmcomppath comppath;
	ProModelitem modelItem;
	char existingPval[PRO_NAME_SIZE]{};

	vector<int>ID_mapf5a27006;


	string remf5a27006 = "";
	vector<ProSelection> selaf5a27006;
	vector<Model_Tree_Information> treeInformationVectorf5a27;
	vector<Model_Tree_Information> Selection_itemsf5a27;


	//ProModelitem p_item27;
	ProIdTable table;
	//table[0] = -1;
	//int ID;

	appd = (UserAppdata*)appdata;
	fp = appd->fp;
	level = appd->level;

	status = ProAsmcompMdlGet(feature, &mdl27);
	status = ProMdlMdlnameGet(mdl27, modelName);
	status = ProMdlExtensionGet(mdl27, modelExtension);

	ProWstringToString(name27, modelName);
	ProWstringToString(type, modelExtension);

	//if (strncmp(type, "ASM", 3) == 0 || strncmp(type, "PRT", 3))
	//{
	ID_mapf5a27006.push_back(feature->id);
	//component_path.push_back(ID_mapf2c01004);

	appd1.fp = appd->fp;
	appd1.level = appd->level + 1;

	//numberofasm++;

	status = ProMdlToModelitem(mdl27, &modelItem);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));
	ProParameter pDesc;
	ProParamvalue pvDesc;
	ProName pDescName = L"DESCRIPTION";
	status = ProParameterInit(&modelItem, pDescName, &pDesc);
	ruleLog.Write("ProParameterInit: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)
	{
		status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
		ProWstringToString(existingPval, pvDesc.value.s_val);
		Model_Tree_Information tree1;
		tree1.name = string(name27);
		tree1.extension = string(type);
		tree1.ID = feature->id;
		tree1.description = existingPval;
		tree1.ID_path = ID_mapf5a27006;
		tree1.ID_table_size = ID_mapf5a27006.size();

		treeInformationVectorf5a27.push_back(tree1);
		/*ruleLog.Write("Name of assembly = " + string(name27) + " , ID = " + to_string(feature->id) + " , Description = " + existingPval);
		for (int id : tree1.ID_path)
		{
			ruleLog.Write(to_string(id) + " ");
		}*/
	}

	status = ProSolidFeatVisit((ProSolid)mdl27, user_actionf5a27006, UserAsmCompFilterf5a27, &appd1);
	ID_mapf5a27006.pop_back();
	//}
	return(PRO_TK_CONTINUE);
}

ProError UserAsmCompFilterf5a27(ProFeature* feature, ProAppData app_data)
{
	ProError status;
	ProFeattype ftype;

	status = ProFeatureTypeGet(feature, &ftype);

	if (ftype == PRO_FEAT_COMPONENT)
		return(PRO_TK_NO_ERROR);
	return(PRO_TK_CONTINUE);
}

int createDatumPointsF5A27(Pro3dPnt pnt_arr[2], char* csysName)
{

	ruleLog.Write("=================> InterfaceRule::createDatumPoints <=================");
	ProElement  elem_tree, elem_ftype, elem_feature_name,
		pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
		pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
		pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
	ProReference REPDEP_ref1;
	wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wide_string[PRO_NAME_SIZE], wide_string_2[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE];
	//CSYS_ASM_DEF
	ProModelitem refCsysitem;
	ProSelection refCsysSel, reqMdlSel;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pnt_feat;
	ProErrorlist errors;
	//converting negative values to positive
	double d1 = -pnt_arr[0][2];
	double d2 = -pnt_arr[1][2];
	char cDatumPointName[PRO_NAME_SIZE] = "Dist_highlght_pnt";

	ProStringToWstring(wCsysName, csysName);
	status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
	status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);


	//Create Element Tree
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	//feature name
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, cDatumPointName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
	ruleLog.Write("feature name = " + to_string(status));

	//PRO_E_DPOINT_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
	ruleLog.Write("type status = " + to_string(status));

	//Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);

	//ref
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
	status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
	status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);

	//
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);

	//Populating array element
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);

	//Point1
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);

	//Point1 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
	ProStringToWstring(wide_string, "datum_PNT1");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);

	//Point2
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);

	//Point2 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
	ProStringToWstring(wide_string_2, "datum_PNT2");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);

	/* =============================================================== *\
	Create Model Selection Object
	\* =============================================================== */

	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Points
	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	status = ProElementFree(&elem_tree);
	status = ProSelectionFree(&reqMdlSel);

	ProSelection pnt_Sel;
	status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
	status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_ERROR);
	//PRO_COLOR_SELECTED for green highlight
	return 0;
}

ProError deleteDatumPointf5a27(char* dtmpoint_name)
{
	ruleLog.Write("=================> InterfaceRule::deleteDatumPoints <=================");
	ProError status;
	int* feat_ids = NULL;
	ProMdl mdl;
	ProModelitem mdl_item;
	ProFeature feat;
	ProFeatureDeleteOptions* delete_opts = 0;
	ProIdTable idtbl1;
	ProAsmcomppath path;
	wchar_t wdatum_pt[PRO_NAME_SIZE];

	status = ProMdlCurrentGet(&mdl);
	ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));

	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path);
	ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));


	ProStringToWstring(wdatum_pt, dtmpoint_name);
	status = ProModelitemByNameInit(mdl, PRO_POINT, wdatum_pt, &mdl_item);
	ruleLog.Write("ProModelitemByNameInit status = " + to_string(status));

	/*status = ProSelectionAlloc(&path, &mdl_item, &selections[0]);
	ruleLog.Write("ProSelectionAlloc 1 status = " + to_string(status));*/

	/*ProStringToWstring(name2, "datum_PNT2");
	status = ProModelitemByNameInit(mdl, PRO_POINT, name2, &mdl_item);
	ruleLog.Write("ProModelitemByNameInit 2 status = " + to_string(status));
	*/

	if (status == PRO_TK_NO_ERROR) {
		/*status = ProSelectionAlloc(&path, &mdl_item, &selections[1]);
		ruleLog.Write("ProSelectionAlloc 2 status = " + to_string(status));*/

		/*status = ProSelectionModelitemGet(selections[i], &mdl_item);
		ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));*/

		status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
		ruleLog.Write("ProArrayAlloc status = " + to_string(status));

		status = ProGeomitemFeatureGet((ProGeomitem*)&mdl_item, &feat);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status));
		feat_ids[0] = feat.id;

		status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
		delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;
		status = ProFeatureWithoptionsDelete((ProSolid)mdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
		ruleLog.Write("ProFeatureWithoptionsDelete status = " + to_string(status));

		status = ProArrayFree((ProArray*)&delete_opts);
		status = ProArrayFree((ProArray*)&feat_ids);


	}
	return PRO_TK_NO_ERROR;
}

ProError select_action_IRF5A27_006(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRF5A10_007  --------------------------");
	vector<int>ID_mapf5a27006;


	string remf5a27006 = "";
	vector<ProSelection> selaf5a27006;
	vector<Model_Tree_Information> treeInformationVectorf5a27;
	vector<Model_Tree_Information> Selection_itemsf5a27;

	int n_sels;
	wchar_t wIpVal[50];
	InterfaceRule iRule;
	ProModelitem annotelem;
	char nameofsel[PRO_NAME_SIZE];
	ProMdl mdl;
	wchar_t model;
	

	status = ProSelect((char*)"surface", 1, NULL, NULL, NULL, NULL, &sel_brac, &n_sels);
	ruleLog.Write("ProSelect status = " + to_string(status));

	InterfaceRule Int_rule;
	if (status == PRO_TK_USER_ABORT)
	{
		//_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}
	else if (n_sels < 1 || status != PRO_TK_NO_ERROR)
	{
		Int_rule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}


	selaf5a27006.push_back(sel_brac[0]);

	ProMdlName		wname;
	char            cname[PRO_MDLNAME_SIZE];
	ProFeature feature;

	status = ProSelectionModelitemGet(sel_brac[0], &feature);
	status = ProMdlMdlnameGet(feature.owner, wname);
	ProWstringToString(cname, wname);
	ruleLog.Write("part_names: " + to_string(feature.id));
	remf5a27006.append(string(cname) + ".prt[Surface ID: " + to_string(feature.id) + "] " + "to ");
	ruleLog.Write("Selection Surf Id = " + to_string(feature.id));

	sel_inf += string(cname) + ".prt[Surface ID: " + to_string(feature.id) + "] ";

	status = ProUIPushbuttonEnable(DLG_IRF5A27_006, PB_ROK);
	return status;
}

//int measureDistanceBetweenComponentsF5A27(Model_Tree_InformationF5A27 reqComp1, Model_Tree_InformationF5A27 reqComp2, double& distance, Pro3dPnt(&pnt_arr)[2])
//{
//	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenComponents <=================");
//
//	ProSelection sels[2];
//	ProIdTable idtbl1 = reqComp1.ID_path;      // component id of the component 1 to be selected
//	ProIdTable idtbl2 = reqComp2.ID_path;      // component id of the component 2 to be selected
//
//	ProName comp1_name, comp2_name;
//	ProModelitem feature[2];
//	ProMdl reqMdls[2];
//
//	ProStringToWstring(comp1_name, reqComp1.name);
//	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
//	ruleLog.Write("ProMdlnameInit: " + to_string(status));
//	status = ProMdlToModelitem(reqMdls[0], &feature[0]);
//
//	ProStringToWstring(comp2_name, reqComp2.name);
//	status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
//	status = ProMdlToModelitem(reqMdls[1], &feature[1]);
//
//	ProAsmcomppath path[2];
//	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
//	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
//	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl2, 1, &path[1]);
//	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
//
//	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
//	ruleLog.Write("ProSelectionAlloc: " + to_string(status));
//	status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
//	ruleLog.Write("ProSelectionAlloc: " + to_string(status));
//
//	ProBoolean is_interference_found;
//	//Pro3dPnt pnt_arr[2];
//	status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_NONE, sels[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, sels[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
//	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));
//
//	return 0;
//}
#pragma pop