/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 07-07-2023	|	V1_0_0		| F3B02 - EXHAUST SYSTEM RULES
==================================================================================================================*/
#include "F3B02.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*= ================================================================================================================ =
RULE ID     | DEVELOPER         | DEPENDENT MODULES | DESCRIPTION
------------------------------------------------------------------------------------------------------------------ -
IRF3B02002  | MATHANPRASATH A   |                   | Define Urea Tank capacity & design across platforms based on similar Engine Capacity, Fuel economy, urea filling interval.
================================================================================================================== = */
#define DLG_IR_F3B02_002     "dlg_IR_f3b02_002" 
#define FUEL_CAPACITY	     "select_option_menu"
#define PLATFRM_LIST         "platform_option_menu"
#define PB_CANCEL		     "CommitCancel" 
#define PB_OK			     "CommitOK"

struct Urea_tank
{
    string comp_name;
    string type;
    string visit;
};

Urea_tank type_part, type_asm;
string fuel_capacity, urea_cap;
vector<Urea_tank>Visited_part_name;
vector <string>Fuel_cap_Csv, Urea_cap_Csv, Urea_Part_Csv, platform_sel, found_partname;

char** selValue;
string ;

int IRF3B02::IRF3B02_002(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF3B02::IRF3B02_002   ==========================");
   // int i = 0;
    fuel_capacity ="";
   // part_num_found = false;
    final_res.result.clear();
    final_res.remark.clear();
    Visited_part_name.clear();
    Fuel_cap_Csv.clear();
    Urea_cap_Csv.clear();
    Urea_Part_Csv.clear();
    found_partname.clear();
    string part_name ="";
    string res_part = "";
    string ureapart_remark = "";
    vector<Urea_tank> UreatankList;
    bool loop = true;
    boolean part_num_found = false;
    vector <string>Urea_Part_Csv_cpy;
    vector <string>platform_Csv;
    vector<string>cap_list;
    vector<string>platform_list;
    vector<IntAndStringlistMap>projectcodelist;
    Visited_part_name.clear();
	SubModuleInfo _reqSMinfo;
	vector<PartnameDescriptionPair> name_desc_list;
    name_desc_list.clear();
   
    string urea_cap_found;
    
   
    char** selValue;

    status = ProSolidFeatVisit((ProSolid)curMdl, F3B02_visit, compsFilter, (ProAppData)&name_desc_list);
    ruleLog.Write("prosolidfeatvisit status :" + to_string(status));

    for (int i = 0; i < Visited_part_name.size(); i++)
    {
        ruleLog.Write("Name: " + Visited_part_name[i].comp_name+Visited_part_name[i].type );
    }
  
    isUserQuits = false;
    status = ProUIDialogCreate(DLG_IR_F3B02_002, DLG_IR_F3B02_002);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));
    status = ProUIDialogAboveactivewindowSet(DLG_IR_F3B02_002, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_IR_F3B02_002, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_IR_F3B02_002, PB_OK, (ProUIAction)ruleDlgOKaction, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIOptionmenuSelectActionSet(DLG_IR_F3B02_002, FUEL_CAPACITY, (ProUIAction)Dropdown_action_IRF3B02_002, NULL);
    ruleLog.Write("fuel_cap_ProUIOptionmenuSelectActionSet: " + to_string(status));


    char** CapNames;
    wchar_t** CapLabels;
    vector<string> cap_fuel;
    cap_fuel = { "Select","30L", "35L", "60L", "90L", "120L", "160L", "192L", "200L", "250L","260L", "280L", "300L", "350L", "365L", "400L"};

    status = ProArrayAlloc(cap_fuel.size(), sizeof(char*), 50, (ProArray*)&CapNames);
    status = ProArrayAlloc(cap_fuel.size(), sizeof(wchar_t*), 50, (ProArray*)&CapLabels);

    for (int i = 0; i < cap_fuel.size(); ++i)
    {
        CapNames[i] = (char*)calloc(50, sizeof(char));
        ProTKSprintf(CapNames[i], "%s", cap_fuel[i]);

        CapLabels[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
        ProStringToWstring(CapLabels[i], CapNames[i]);
    }
    status = ProUIOptionmenuNamesSet(DLG_IR_F3B02_002, FUEL_CAPACITY, int(cap_fuel.size()), CapNames);
    ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
    status = ProUIOptionmenuLabelsSet(DLG_IR_F3B02_002, FUEL_CAPACITY, int(cap_fuel.size()), CapLabels);
    ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

    status = ProArrayFree((ProArray*)&CapNames);
    //ruleLog.Write("ProArrayFree N" + to_string(status));
    status = ProArrayFree((ProArray*)&CapLabels);
    //ruleLog.Write("ProArrayFree L" + to_string(status));

    
    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IR_F3B02_002, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
   
    f3B02_getReqValsFrom2DCsvData("IRF3B02_002.csv", 0, 1, fuel_capacity, Urea_Part_Csv);
    ruleLog.Write("f3B02_getReqValsFrom2DCsvData-----check 1");
    f3B02_getReqValsFrom2DCsvData("IRF3B02_002.csv", 0, 2, fuel_capacity, Urea_cap_Csv);
    ruleLog.Write("f3B02_getReqValsFrom2DCsvData-----check 2");

    for (string ureapart : Urea_Part_Csv)
    {
        ruleLog.Write("ureaPart_csvfile :" + ureapart);
    }
    for (string ureacap : Urea_cap_Csv)
    {
        ruleLog.Write("ureacap_csvfile :" + ureacap);
    }

    // check for user quits in close_action
    if (isUserQuits) 
    {
        status = ProUIDialogDestroy(DLG_IR_F3B02_002);
        ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
        status = ProUIDialogShow(DLG_IRC_MAIN);
        return -1;
    }
    
    if (isUserQuits)
        return -1;
    
    
    int new_line = 0;
    for (string ureapart : Urea_Part_Csv)
    {
    ruleLog.Write("partname_csvfile :" + ureapart);
    ureapart_remark += ureapart + ",";
    new_line++;
        if (new_line == 7)
        {
            new_line = 0;
            ureapart_remark += "\n";
        }
    }
   
    const regex compNamePattern("\\b[0-9A-Za-z]+\\.\\w+\\b");
    smatch matchFound;
   
    for (int i = 0; i < Visited_part_name.size(); ++i)
    {
        if (loop == false)
        {
            break;
        }

        for (int j = 0; j < Urea_Part_Csv.size(); j++)
        {

            urea_cap = Urea_cap_Csv.at(j);
            ruleLog.Write("------Comparing the values ---------");
            ruleLog.Write("comparing value :" + Visited_part_name[i].comp_name);
            ruleLog.Write("Urea capacity   :" + urea_cap);
            ruleLog.Write("compared with   :" + Urea_Part_Csv.at(j));
         
            if(Urea_Part_Csv.at(j).compare(Visited_part_name[i].comp_name)==0)
            {
                ruleLog.Write("Part:" + Visited_part_name[i].comp_name+ Visited_part_name[i].type);
                found_partname.push_back(Visited_part_name[i].comp_name + Visited_part_name[i].type);
                ruleLog.Write("Found Partname =" + found_partname.at(0));
                ruleLog.Write("urea_capacity:" + urea_cap);
                part_num_found = true;
                loop = false;
                Visited_part_name.clear();
                Fuel_cap_Csv.clear();
                Urea_cap_Csv.clear();
                Urea_Part_Csv.clear();
                if (loop == false)
                {
                    break;
                }
            }
        }
    }
    ProCharPath re_mark{};
    string remarkMsg;
    vector<vector<string>> dbList2D = getData2D("IRF3B02_002.csv");
    int i{};
    int f = 0;
    // start:
    if (part_num_found == true)
    {
        string res_part = found_partname.at(0);
        final_res.result = "PASS";
        ruleLog.Write("expec :" + res_part);
        ruleLog.Write("ureapart_remark :" + ureapart_remark);
        sprintf(remark, "Result Value: Selected Fueltank Capacity is %s and found Ureatank %s Capacity is %s.\nAcceptance Criteria : Any of the Ureatank from the below list has to be used for the selected Fuel Tank: \n%s", fuel_capacity.c_str(), res_part.c_str(), urea_cap.c_str(),ureapart_remark.c_str());
        final_res.remark = remark;
        ruleLog.Write("Remarks :"+ final_res.remark);
        ruleLog.Write("Urea Tank Capacity :" + urea_cap);
    }
    else
    {
        final_res.result = "FAIL";
        sprintf(remark, "Result Value:Selected Fueltank Capacity is %s and the Standard Ureatank not found.\nAcceptance Criteria : Any of the Ureatank parts from the below list has to be used for the selected Fuel Tank: \n%s", fuel_capacity.c_str(),ureapart_remark.c_str());
        final_res.remark = remark;
    }
       

    ruleLog.Write("6");
    status = ProUIDialogDestroy(DLG_IR_F3B02_002);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    Visited_part_name.clear();
    Fuel_cap_Csv.clear();
    Urea_cap_Csv.clear();
    Urea_Part_Csv.clear();
    found_partname.clear();
    
    
    return 0;
    
}

void f3B02_getReqValsFrom2DCsvData(char* csvFileName, int fuelIdx, int reqValIdx, string fuelcap , vector<string>& reqValsFromCsv)
{
    Utils object;
    mainLog.Write("================= Utils::getReqValsFrom2DCsvData ==================");
    reqValsFromCsv.clear();
    vector<vector<string>> csvData2D = object.getData2D(csvFileName);
    ruleLog.Write("csv----");
    for (int i = 1; i < csvData2D.size(); ++i)	// i = 1 for skipping the headers
    {
        ruleLog.Write("csv 1");
        if ((csvData2D[i][fuelIdx]) == fuelcap)
        {
            ruleLog.Write("csv 2");
            string tok1;
            std::istringstream ss1(csvData2D[i][reqValIdx]);
            while (std::getline(ss1, tok1, ';')) {
                reqValsFromCsv.push_back(tok1);
            }
            //break;
        }
    }
    csvData2D.clear();
}

ProError Dropdown_action_IRF3B02_002(char* dialog, char* component)
{
    ruleLog.Write("================= Dropdown_action_IRF3B02_002 ==================");
    int n_sel;
    vector<ProSelection>sel_value;
    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
    ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
    
  //  sel_value.push_back(selValue[0]);
   
    string sel = "Select";
    if ((string(selValue[0])).compare(sel) == 0)
    {
        status = ProUIPushbuttonDisable(DLG_IR_F3B02_002, PB_OK);
        ruleLog.Write("Blank selected");
    }
   
    else
    {
        status = ProUIPushbuttonEnable(DLG_IR_F3B02_002, PB_OK);
        ruleLog.Write("ProUIPushbuttonEnable selected");
        fuel_capacity = selValue[0];
    }
    ruleLog.Write("selValue = " + string(selValue[0]));
    fuel_capacity = selValue[0];
    return status;
}

ProError Platform_Dropdown_action_IRF3B02_002(char* dialog, char* component)
{
    int n_sel;
    char** selValue;
   
    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
    ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
    ruleLog.Write("selValue = " + string(selValue[0]));

    platform_sel.push_back(selValue[0]);
    ruleLog.Write("selected_pltfrm :"+ platform_sel.at(0));

    return status;
}

ProError F3B02_visit(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    ProMdlType subModuleMdlType;
    ProModelitem modelItem;
    ProMdl reqMdl;
    wchar_t wFeatName[PRO_NAME_SIZE];
    char cFeatName[PRO_NAME_SIZE];
    PartnameDescriptionPair compd;
    string asmname_substr;
    string asm_name;
    char existingPval[PRO_PATH_SIZE];

    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
    //ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
    status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
    //ruleLog.Write("ProMdlTypeGet: " + to_string(status));
    status = ProMdlMdlnameGet(reqMdl, wFeatName);
    //ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
    ProWstringToString(cFeatName, wFeatName);

    if (subModuleMdlType == PRO_MDL_ASSEMBLY)
    {
        ruleLog.Write("Assembly Name: " +(string)cFeatName);
        strcpy(compd.part_name, cFeatName);
        asm_name.erase();
        asm_name.append(compd.part_name);
        asmname_substr = asm_name.substr(4, 5);
        Urea_tank type_asm;
        type_asm.comp_name = ((string)cFeatName);
        type_asm.type = ".ASM";
        Visited_part_name.push_back(type_asm);
        ProSolidFeatVisit((ProSolid)reqMdl, F3B02_descget, compsFilter, (ProAppData)app_data);
        
    }


	return PRO_TK_NO_ERROR;
}

ProError F3B02_descget(ProFeature* p_feature, ProError status, ProAppData app_data) 
{
    vector<PartnameDescriptionPair>* prtname_list = (vector<PartnameDescriptionPair>*)app_data;
    ProMdlType subModuleMdlType;
    ProModelitem modelItem;
    wchar_t wFeatName[PRO_NAME_SIZE];
    char cFeatName[PRO_NAME_SIZE], existingPval[PRO_PATH_SIZE];
    ProMdl reqMdl;
   
    PartnameDescriptionPair compd;
    string asm_name, asmname_substr;
    ProFeature asm_feat;
    ProAsmcomppath asm_path;
    bool Carrier_asm;
    /*status = ProGeomitemFeatureGet((ProGeomitem*)reqMdl, &asm_feat);
    ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id1 = " + to_string(asm_feat.id));

    status = ProAsmcomppathInit(ProSolid(reqMdl),&asm_feat.id, 1,&asm_path);
    ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));*/

    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
    //  ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
    status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
    // ruleLog.Write("ProMdlTypeGet: " + to_string(status));
    status = ProMdlMdlnameGet(reqMdl, wFeatName);
    //  ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
    ProWstringToString(cFeatName, wFeatName);
    status = ProMdlToModelitem(reqMdl, &modelItem);
    ruleLog.Write("ProMdlToModelitem: " + to_string(status));
    ProParameter pDesc;
    ProParamvalue pvDesc;
    ProName pDescName = L"DESCRIPTION", pMatName = L"MATERIAL";
    
    status = ProParameterInit(&modelItem, pDescName, &pDesc);
    ruleLog.Write("ProParameterInit: " + to_string(status));
    if (status == 0)
    {
        if (subModuleMdlType == PRO_MDL_ASSEMBLY)
        {
           /* ruleLog.Write("Assembly Name: ");
            ruleLog.Write(cFeatName);*/
            Urea_tank type_asm;
            type_asm.comp_name = ((string)cFeatName);
            type_asm.type = ".ASM";
            Visited_part_name.push_back(type_asm);
            status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
            ProWstringToString(existingPval, pvDesc.value.s_val);
            ruleLog.Write("ProParameterValueWithUnitsGet =" + to_string(status) + "\nAsm_Description: " + existingPval);
            
        }

        if (subModuleMdlType == PRO_MDL_PART)
        {
            
            status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
            ProWstringToString(existingPval, pvDesc.value.s_val);
            
            type_part.comp_name = ((string)cFeatName);
            type_part.type = ".PRT";
            Visited_part_name.push_back(type_part);
                /*ruleLog.Write("Part Name       : " + string(cFeatName));
                ruleLog.Write("Part_Description: " + string(existingPval));*/
            
        }
        ProSolidFeatVisit((ProSolid)reqMdl, F3B02_descget, compsFilter, (ProAppData)app_data);
    }
    return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES					| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F3B02-003	| Prajakta Bhelawe	| MF3B02; MF1A01                 	| Commonise Position of Urea tank from FACL for different wheel base across platform with sufficient filling access.
===================================================================================================================*/
#define DLG_IRF3B02_003 "dlg_IR_F3B02_003"
#define PB_RCANCEL      "rule_cancel_pb"
#define PB_ROK			"rule_ok_pb"
#define PB_IMG			"pb_image"
#define PB_RBUTTON      "pb_rbutton"


boolean ruleSts;

int IRF3B02::IRF3B02_003(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF3B02::IRF3B02_003   ==========================");

    int	n_names;
    char** r_names;

    char R2[PRO_NAME_SIZE] = "r2";
    char* ptrR2 = R2;
    ruleSts = TRUE;

    status = ProUIDialogCreate(DLG_IRF3B02_003, DLG_IRF3B02_003);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));
    status = ProUIDialogAboveactivewindowSet(DLG_IRF3B02_003, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_IRF3B02_003, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIRadiogroupSelectActionSet(DLG_IRF3B02_003, PB_RBUTTON, (ProUIAction)rg_select_action_IRF3B02_003, NULL);

    /*status = ProUICheckbuttonActivateActionSet(DLG_IRF3B02_003, PB_CHECKBT,(ProUIAction)verify_cb_action_F3B02, NULL);
    ruleLog.Write("ProUICheckbuttonGetState: " + to_string(status));*/
    status = ProUIPushbuttonActivateActionSet(DLG_IRF3B02_003, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));


    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF3B02_003, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF3B02_003);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    if (ruleSts)
    {
        final_res.result = "PASS";
        final_res.remark = "Sufficient filling access for Urea Tank ";
    }

    else
    {
        final_res.result = "FAIL";
        final_res.remark = "Insufficient filling access for Urea Tank ";
    }


    return 0;
}

ProError rg_select_action_IRF3B02_003(char* dialog, char* component, ProAppData data)
{

    ruleLog.Write("----------------------------- rg_select_action_IRF1D02_001 -----------------------------");

    int	n_names;
    char** r_names;

    status = ProUIRadiogroupSelectednamesGet(DLG_IRF3B02_003, PB_RBUTTON, &n_names, &r_names);
    ruleLog.Write("ProUIRadiogroupSelectednamesGet: " + to_string(status));
    ruleLog.Write("r_names = " + string(r_names[0]));

    if (strcmp(r_names[0], "R1") == 0) {

        ruleSts = TRUE;
        char R2[PRO_NAME_SIZE] = "r2";
        char* ptrR2 = R2;
        status = ProUIRadiogroupSelectednamesSet(DLG_IRF3B02_003, PB_RBUTTON, 1, &ptrR2);
        ruleLog.Write("true");

    }

    if (strcmp(r_names[0], "R2") == 0)
    {
        ruleLog.Write("false");
        ruleSts = FALSE;
    }
    return status;

}

/*= ================================================================================================================ =
RULE ID         | DEVELOPER         | DEPENDENT MODULES | DESCRIPTION
------------------------------------------------------------------------------------------------------------------ -
IRF3B02004      | MATHANPRASATH A   | MF3B02;           |A minimum ground clearance to be maintained while mounting urea tank assembly on vehicle.
================================================================================================================== = */


#define DLG_F3B02_004		"dlg_IR_F3B02_004"
#define PB_RCANCEL			"Commit_Cancel"
#define PB_ROK				"Commit_Ok"
#define PB_SELECT_TYRE      "pb_select_tyre"
#define Label_tyre			"Lable_sel_tyre"
#define PB_SELECT_FRAME     "pb_select_frame"
#define Label_frame			"Lable_sel_frame"
#define Label_SLRf			"Label_SLRf"
#define Label_SLRr			"Label_SLRr"
#define InputPanel_Rrf		"InputPanel_Rrf"
#define InputPanel_Rrr		"InputPanel_Rrr"
#define Label_plat			"Label_plat"
#define platform			"platform"
#define Label_subPlat		"Label_subPlat"
#define vehicalType			"vehicalType"
#define Label_STR			"Label_STR"
#define InputPanel_STR		"InputPanel_STR"


vector<vector<string>>dbList2D_Ur;
string PlatFVal_Ur, subPlatFVal_Ur;
vector<string>reqValsFromCsv_Ur;
double stdGrndCleVal_Ur{};

int IRF3B02::IRF3B02_004(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF3B01::IRF3B01_005   ==========================");

    string tyreSurfInfo{}, frameSurfInfo{}, suspTravMsg{};
    vector<selectionInfo>tyreSurfSels(2);
    vector<selectionInfo>longMembSels(1);
    vector<double>frontSLRVec, rearSLRVec;
    //vector<double>susTravelValVec;
    //susTravelValVec.clear();
    //bool isUnladen = NULL;
    double offsetValueFrnt{}, offsetValueRear{};

    tyreSurfInfo.erase();
    frameSurfInfo.erase();
    frontSLRVec.clear();
    rearSLRVec.clear();


    //Search in the main assembly if submodule, that is to be selected Programmatically, is available
    ComponentData _reqComps[1];
    for (int i = 0; i < subModulesList.size(); ++i)
    {
        ruleLog.Write("submodule name being visited: " + subModulesList[i].name);
        if (subModulesList[i].name.find("F3B02") != string::npos)
        {
            ruleLog.Write("match found for: " + subModulesList[i].name);
            strcpy(_reqComps[0].name, subModulesList[i].name.c_str());
            break;
        }
    }

    //Visiting the model tree for getting feature id of F3B01 SM which will be used to select it
    status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps);
    ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
    ruleLog.Write("Name of the submodule = " + string(_reqComps[0].name));
    ruleLog.Write("Feat id of the submodule = " + to_string(_reqComps[0].id));


    vector<string> platformValFrmCSV, subPlatform, platformVal;
    dbList2D_Ur = getData2D("IRF3B02004.csv");
    ruleLog.Write("dbList2D.size():" + to_string(dbList2D_Ur.size()));

    for (int i = 1; i < dbList2D_Ur.size(); ++i)	// i = 1 for skipping the headers
    {
        string tok2;
        std::istringstream ss2(dbList2D_Ur[i][0]);
        while (std::getline(ss2, tok2, ';'))
        {
            trimString(tok2);
            ruleLog.Write("Platform: " + tok2);
            //storing list of Platforms from db
            if (find(platformValFrmCSV.begin(), platformValFrmCSV.end(), tok2) == platformValFrmCSV.end()) {
                platformValFrmCSV.push_back(tok2);
            }
        }
    }


    //Delete the features created in previous run
    status = deleteDatumPoint("PROJ_PNT_R");
    ruleLog.Write("deleteDatumPoint PROJ_PNT_R: " + to_string(status));
    status = deleteDatumPoint("PROJ_PNT_F");
    ruleLog.Write("deleteDatumPoint PROJ_PNT_F: " + to_string(status));
    status = deleteDatumPoint("PROJ_PNT_M");
    ruleLog.Write("deleteDatumPoint PROJ_PNT_M: " + to_string(status));
    status = deleteDatumPoint("MY_PNT1");
    ruleLog.Write("deleteDatumPoint MY_PNT1: " + to_string(status));
    status = deleteDatumPoint("MY_PNT2");
    ruleLog.Write("deleteDatumPoint MY_PNT2: " + to_string(status));
    rule_sts = deleteDatumPlane("SIDE_PLANE2");
    ruleLog.Write("deleteDatumPlane SIDE_PLANE2: " + to_string(status));
    rule_sts = deleteDatumPlane("GROUND_PLANE");
    ruleLog.Write("deleteDatumPlane GROUND_PLANE: " + to_string(status));
    status = deleteDatumPoint("F_GND_PNT_OPP");
    ruleLog.Write("deleteDatumPoint F_GND_PNT_OPP: " + to_string(status));
    rule_sts = deleteDatumPlane("SIDE_PLANE1");
    ruleLog.Write("deleteDatumPlane SIDE_PLANE1: " + to_string(status));
    status = deleteDatumPoint("F_GND_PNT");
    ruleLog.Write("deleteDatumPoint F_GND_PNT: " + to_string(status));
    status = deleteDatumPoint("R_GND_PNT");
    ruleLog.Write("deleteDatumPoint R_GND_PNT: " + to_string(status));
    status = deleteDatumPoint("F_CENT_PNT");
    ruleLog.Write("deleteDatumPoint F_CENT_PNT: " + to_string(status));
    status = deleteDatumPoint("R_CENT_PNT");
    ruleLog.Write("deleteDatumPoint R_CENT_PNT: " + to_string(status));
    status = deleteDatumPoint("F_CENT_PNT_OPP");
    ruleLog.Write("deleteDatumPoint F_CENT_PNT_OPP: " + to_string(status));
    rule_sts = deleteDatumPlane("CENTRE_PLANE");
    ruleLog.Write("deleteDatumPlane CENTRE_PLANE: " + to_string(status));

    //Create UI dialog
    status = ProUIDialogCreate(DLG_F3B02_004, DLG_F3B02_004);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));
    status = ProUIDialogAboveactivewindowSet(DLG_F3B02_004, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_F3B02_004, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_F3B02_004, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIPushbuttonActivateActionSet(DLG_F3B02_004, PB_SELECT_TYRE, (ProUIAction)refSurfSelections, &tyreSurfSels);

    status = ProUIOptionmenuSelectActionSet(DLG_F3B02_004, platform, (ProUIAction)platformList_Ur, NULL);
    status = ProUIOptionmenuSelectActionSet(DLG_F3B02_004, vehicalType, (ProUIAction)subplatformList_Ur, NULL);

    platformValFrmCSV.insert(platformValFrmCSV.begin(), "Select");
    //Set platform values in platform drop down
    option_menu_Ur(platformValFrmCSV, platform);

    status = ProUIPushbuttonDisable(DLG_F3B02_004, PB_ROK);
    ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));

    status = ProUIOptionmenuInputActionSet(DLG_F3B02_004, InputPanel_Rrf, (ProUIAction)inputValue, &frontSLRVec);
    status = ProUIOptionmenuInputActionSet(DLG_F3B02_004, InputPanel_Rrr, (ProUIAction)inputValue, &rearSLRVec);
    //status = ProUIOptionmenuInputActionSet(DLG_F3B03_006, InputPanel_STR, (ProUIAction)inputValue, &susTravelValVec);
    //status = ProUIRadiogroupSelectActionSet(DLG_F3B03_006, RadioGroup, (ProUIAction)radioGrpSelectAction, &isUnladen);
    ruleLog.Write("ProUIRadiogroupSelectActionSet status: " + to_string(status));
    status = ProUIPushbuttonDisable(DLG_F3B02_004, PB_ROK);
    ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));

    status = ProUIDialogHide(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogHide: " + to_string(status));
    //status = ProUILabelHide(DLG_F3B02_004, Label_STR);
    //ruleLog.Write("ProUILabelHide: " + to_string(status));
    //status = ProUIInputpanelHide(DLG_F3B02_004, InputPanel_STR);
    //ruleLog.Write("ProUIInputpanelHide: " + to_string(status));

    //Provision of radio buttons for laden/unladen condition

    //Radio button, selected for first button (default)
    //int radioGrpNames[2];
    //char** buttonNames;
    //status = ProUIRadiogroupSelectednamesGet(DLG_F3B03_006, RadioGroup, radioGrpNames, &buttonNames);
    //ruleLog.Write("ProUIRadiogroupSelectednamesGet status main: " + to_string(status));
    //ruleLog.Write("selected button name: " + (string)buttonNames[0]);
    //if (buttonNames[0] == "rb1")       //If user does not select any then default radio button will be first button, 
    //									//and action related to that will be performed on clicking Ok								
    //{
    //	isUnladen = false;
    //}


    status = ProUIDialogActivate(DLG_F3B02_004, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));

    if (isUserQuits)
    {
        status = ProUIDialogDestroy(DLG_F3B02_004);
        ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
        status = ProUIDialogShow(DLG_IRC_MAIN);
        return -1;
    }
    if (frontSLRVec.size() == 0 || rearSLRVec.size() == 0)
    {
        UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention", "SLR values are not entered,\nClick OK to return.");
        status = ProUIDialogDestroy(DLG_F3B02_004);
        ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
        status = ProUIDialogShow(DLG_IRC_MAIN);
        tyreSurfSels.clear();
        longMembSels.clear();
        frontSLRVec.clear();
        rearSLRVec.clear();
        return -1;

    }

    ProSelection fCentPntSel{}, rCentPntSel{}, csysSel{}, gPntF{}, gPntR{};
    double rollRadFront[3], rollRadRear[3];       // This is rolling radius of front and rear tyre
    rollRadRear[0] = 0;
    rollRadRear[1] = 0;
    rollRadFront[0] = 0;
    rollRadFront[1] = 0;

    //provision for considering suspension travel based on laden and unladen (expand the commented lines for clarity)

    /*//Writing the remark for laden/ unladen condition along with manipulating the offset value for creating ground plane

    ruleLog.Write("Boolean for laden/Unladen? : " + to_string(isUnladen));
    suspTravMsg += "\nUser response for Laden/Unladen? - ";

    if (isUnladen == false)
    {
        ruleLog.Write("entered the laden loop");
        suspTravMsg += "Laden";*/
    offsetValueFrnt = (frontSLRVec[frontSLRVec.size() - 1]);
    offsetValueRear = (rearSLRVec[rearSLRVec.size() - 1]);

    ruleLog.Write("off value front:" + to_string(offsetValueFrnt));
    ruleLog.Write("off value Rear :" + to_string(offsetValueRear));

    rollRadRear[2] = offsetValueRear;
    rollRadFront[2] = offsetValueFrnt;
    /*}
    else if (isUnladen == true)
    {
        ruleLog.Write("entered the Unladen loop");
        string susTravelStr;
        susTravelStr = to_string(abs(susTravelValVec[susTravelValVec.size() - 1]));
        susTravelStr.erase(susTravelStr.find_last_not_of('0') + 3);          //Removing trailing zeroes to keep only 2 zeroes post decimal point

        suspTravMsg += "Unladen";
        suspTravMsg += "\nSuspension travel enterd by user: " + susTravelStr + " mm.";

        offsetValueFrnt = abs(frontSLRVec[frontSLRVec.size() - 1]) - abs(susTravelValVec[susTravelValVec.size() - 1]);
        offsetValueRear = abs(rearSLRVec[rearSLRVec.size() - 1]) - abs(susTravelValVec[susTravelValVec.size() - 1]);

        rollRadRear[2] = offsetValueRear;
        rollRadFront[2] = offsetValueFrnt;
    }*/


    //Plane Creation 
    edgeSel edgeSelection1{}, edgeSelection2{};

    /*---------------------Create F_CENT_PNT and R_CENT_PNT----------------------
    F_CENT_PNT = Front centre point at the centre of front tyre
    R_CENT_PNT = Rear centre point at the centre of rear tyre
    The points will be created at the centre of biggest edge of tyre surfaces*/

    rule_sts = findTheBiggestArcEdge(tyreSurfSels[0], &edgeSelection1);
    ruleLog.Write("findTheBiggestArcEdge 1: " + to_string(rule_sts));
    status = ProSelectionHighlight(edgeSelection1.sel, PRO_COLOR_HIGHLITE);
    ruleLog.Write("ProSelectionHighlight 1 status: " + to_string(status));
    rule_sts = createDatumPointAtCenterOfEdge(edgeSelection1.sel, "F_CENT_PNT");
    ruleLog.Write("createDatumPointAtCenterOfEdge 1: " + to_string(rule_sts));

    rule_sts = findTheBiggestArcEdge(tyreSurfSels[1], &edgeSelection2);
    ruleLog.Write("findTheBiggestArcEdge 2: " + to_string(rule_sts));
    status = ProSelectionHighlight(edgeSelection2.sel, PRO_COLOR_HIGHLITE);
    ruleLog.Write("ProSelectionHighlight 2 status: " + to_string(status));
    rule_sts = createDatumPointAtCenterOfEdge(edgeSelection2.sel, "R_CENT_PNT");
    ruleLog.Write("createDatumPointAtCenterOfEdge 2: " + to_string(rule_sts));

    /*-----------Get the selection objects of F_CENT_PNT and R_CENT_PNT and CSYS
    It will be used as references to create ground points----------------------*/
    rule_sts = selectionAllocByName("F_CENT_PNT", PRO_POINT, &fCentPntSel);
    ruleLog.Write("selectionAllocByName F_CENT_PNT: " + to_string(rule_sts));
    rule_sts = selectionAllocByName("R_CENT_PNT", PRO_POINT, &rCentPntSel);
    ruleLog.Write("selectionAllocByName R_CENT_PNT: " + to_string(rule_sts));
    rule_sts = selectionAllocByName("CSYS_ASM_DEF", PRO_CSYS, &csysSel);
    ruleLog.Write("selectionAllocByName csys: " + to_string(rule_sts));

    //create front ground point taking SLRf value
    rule_sts = createGenDPntAtOffsDist(fCentPntSel, csysSel, rollRadFront, "F_GND_PNT");
    ruleLog.Write("createGenDPntAtOffsDist F_GND_PNT: " + to_string(rule_sts));
    //Get the F_GND_PNT selection object
    rule_sts = selectionAllocByName("F_GND_PNT", PRO_POINT, &gPntF);
    ruleLog.Write("selectionAllocByName F_GND_PNT: " + to_string(rule_sts));

    //create rear ground point taking SLRr value
    rule_sts = createGenDPntAtOffsDist(rCentPntSel, csysSel, rollRadRear, "R_GND_PNT");
    ruleLog.Write("createGenDPntAtOffsDist R_GND_PNT: " + to_string(rule_sts));
    //Get the R_GND_PNT selection object
    rule_sts = selectionAllocByName("R_GND_PNT", PRO_POINT, &gPntR);
    ruleLog.Write("selectionAllocByName R_GND_PNT: " + to_string(rule_sts));

    /*=============== Create a projection plane on opposite side of the vehicle to create a ground point on that
    side as well
    Ground plane will be created as a plane passing through 3 points ===============*/

    //get the selection alloc of a plane passing through vehicle centre (ASM_XZ plane)
    ProSelection asmXZSel;
    rule_sts = selectionAllocByName("ASM_XZ", PRO_SURFACE, &asmXZSel);
    ruleLog.Write("selectionAllocByName ASM_XZ: " + to_string(rule_sts));
    double oppSidePlaneOffsVal = -900;  //Using general value for commonising the offs distance for all the CAD models 
    rule_sts = createOffsetPlaneWithReference_F3B02_004(asmXZSel, oppSidePlaneOffsVal, "SIDE_PLANE1");
    ruleLog.Write("createOffsetPlaneWithReferenceG status: " + to_string(rule_sts));

    //get the selection object of side plane
    ProSelection sidePlane1Sel{};
    rule_sts = selectionAllocByName("SIDE_PLANE1", PRO_SURFACE, &sidePlane1Sel);
    ruleLog.Write("selectionAllocByName SIDE_PLANE1: " + to_string(rule_sts));

    rule_sts = projectDatumPointOnPlane(gPntF, sidePlane1Sel, "F_GND_PNT_OPP");
    ruleLog.Write("projectDatumPointOnPlane1: " + to_string(rule_sts));

    //get the selection object of F_GND_PNT_OPP
    ProSelection fGndPntOpp{};
    rule_sts = selectionAllocByName("F_GND_PNT_OPP", PRO_POINT, &fGndPntOpp);
    ruleLog.Write("selectionAllocByName F_GND_PNT_OPP: " + to_string(rule_sts));

    //Create a ground plane Normal to Long member surface and passing thr G_PNT_F and G_PNT_R 
    rule_sts = threePointPlaneCreate(gPntF, fGndPntOpp, gPntR, "GROUND_PLANE");
    ruleLog.Write("threePointPlaneCreate status: " + to_string(rule_sts));

    //Create a side plane for projecting all the points on a same line
    double sidePlaneOffsVal = 1200;  //Using general value for commonising the offs distance for all the CAD models 
    rule_sts = createOffsetPlaneWithReference_F3B02_004(asmXZSel, sidePlaneOffsVal, "SIDE_PLANE2");
    ruleLog.Write("createOffsetPlaneWithReferenceG status: " + to_string(rule_sts));
    //get the selection object of side plane
    ProSelection projPlaneSel{};
    rule_sts = selectionAllocByName("SIDE_PLANE2", PRO_SURFACE, &projPlaneSel);
    ruleLog.Write("selectionAllocByName SIDE_PLANE2: " + to_string(rule_sts));

    //measure distance between rear plane and rear centre point
    double rearEndDist;
    status = measureDistanceBetweenSurfaces_F3b02(longMembSels[0].selection, PRO_B_TRUE, rCentPntSel, PRO_B_TRUE, rearEndDist);
    ruleLog.Write("measureDistanceBetweenSurfaces status: " + to_string(status));

    //Get selection object of ground plane
    ProSelection grndPlaneSel{};
    rule_sts = selectionAllocByName("GROUND_PLANE", PRO_SURFACE, &grndPlaneSel);
    ruleLog.Write("selectionAllocByName ground plane: " + to_string(rule_sts));

    //Measure distance between component and ground plane (groundClearance)
    double groundClearance;
    Pro3dPnt pntArr[2];
    rule_sts = measureDistanceBetweenPlaneAndComp__F3B02_004(grndPlaneSel, _reqComps[0], groundClearance, pntArr);
    ruleLog.Write("measureDistanceBetweenPlaneAndCompG status: " + to_string(rule_sts));

    /*===================== create points for highlighting the distance =====================
      NOTE :- coords (pntArr) returned by API ProSelectionWithOptionsDistanceEval===========*/
    rule_sts = createCsysOffsDatumPoint(csysSel, pntArr, "DISTANCE_HIGHLIGHT_PNT");
    ruleLog.Write("createCsysOffsDatumPoint status: " + to_string(rule_sts));

    /*=================get the selection object of middle point===================
    NOTE -: It will be used to create a point projected on PROJ_PLANE ===========*/
    ProSelection middlePntSel{};
    rule_sts = selectionAllocByName("MY_PNT2", PRO_POINT, &middlePntSel);
    ruleLog.Write("selectionAllocByName middle proj point: " + to_string(rule_sts));
    //Project middle point on side PROJ_PLANE
    rule_sts = projectDatumPointOnPlane(middlePntSel, projPlaneSel, "PROJ_PNT_M");
    ruleLog.Write("projectDatumPointOnPlane1: " + to_string(rule_sts));
    //Get selection object of PROJ_PNT_M
    ProSelection middleProjPntSel{};
    rule_sts = selectionAllocByName("PROJ_PNT_M", PRO_POINT, &middleProjPntSel);
    ruleLog.Write("selectionAllocByName PROJ_PNT_M: " + to_string(rule_sts));

    //project front ground point on a side plane
    rule_sts = projectDatumPointOnPlane(gPntF, projPlaneSel, "PROJ_PNT_F");
    ruleLog.Write("projectDatumPointOnPlane1: " + to_string(rule_sts));
    //Get selection object of PROJ_PNT_F
    ProSelection frontProjPntSel{};
    rule_sts = selectionAllocByName("PROJ_PNT_F", PRO_POINT, &frontProjPntSel);
    ruleLog.Write("selectionAllocByName PROJ_PNT_F: " + to_string(rule_sts));

    //project rear ground point on a side plane
    rule_sts = projectDatumPointOnPlane(gPntR, projPlaneSel, "PROJ_PNT_R");
    ruleLog.Write("projectDatumPointOnPlane2: " + to_string(rule_sts));
    //Get selection object of PROJ_PNT_R
    ProSelection rearProjPntSel{};
    rule_sts = selectionAllocByName("PROJ_PNT_R", PRO_POINT, &rearProjPntSel);
    ruleLog.Write("selectionAllocByName PROJ_PNT_R: " + to_string(rule_sts));

    //measure distance between front project point to middle project point
    double frontPntDist;
    status = measureDistanceBetweenSurfaces_F3b02(frontProjPntSel, PRO_B_TRUE, middleProjPntSel, PRO_B_TRUE, frontPntDist);
    ruleLog.Write("measureDistanceBetweenSurfaces status: " + to_string(status) +
        "\ndistance between front and middle point: " + to_string(frontPntDist));

    //measure distance between rear project point to middle project point
    double rearPntDist;
    status = measureDistanceBetweenSurfaces_F3b02(rearProjPntSel, PRO_B_TRUE, middleProjPntSel, PRO_B_TRUE, rearPntDist);
    ruleLog.Write("measureDistanceBetweenSurfaces status: " + to_string(status) +
        "\ndistance between rear and middle point: " + to_string(rearPntDist));

    //measure height of frame from ground plane
    double frameHeight;
    status = measureDistanceBetweenSurfaces_F3b02(longMembSels[0].selection, PRO_B_FALSE, grndPlaneSel, PRO_B_FALSE, frameHeight);
    ruleLog.Write("measureDistanceBetweenSurfaces status: " + to_string(status) +
        "\nheight of frame from ground plane: " + to_string(frameHeight));

    //calculate departure angle
    double depAngleMeas;
    depAngleMeas = depatureAngleCalc(rearEndDist, frameHeight, abs(rollRadRear[2]));
    ruleLog.Write("depatureAngle status: " + to_string(status) +
        "\nDeparture angle calculated: " + to_string(depAngleMeas));

    //calculate Ramp Over angle
    double rampOvAngMeas;
    rampOvAngMeas = rampOverAngleCalc(frontPntDist, groundClearance, abs(offsetValueFrnt), abs(rollRadRear[2]), rearPntDist);
    ruleLog.Write("rampOverAngle status: " + to_string(status) +
        "\Ramp over angle calculated: " + to_string(rampOvAngMeas));

    //Rule Validation and Results 
    double stdDeprtureAng = 10, stdRampOvAngl = 15;
    if ((groundClearance >= stdGrndCleVal_Ur) && (rampOvAngMeas >= stdRampOvAngl))
    {
        final_res.result = "PASS";
    }
    else
        final_res.result = "FAIL";

    /*================================= remarks ========================================*/
    //remark message for tyre surface details
    tyreSurfInfo += "\nReferences selected from tyre - \n";
    for (int i = 0; i < tyreSurfSels.size(); i++)
    {
        tyreSurfInfo += to_string(i + 1) + ")surf ID- " + to_string(tyreSurfSels[i].id) + "(Owner: " + tyreSurfSels[i].name + ".PRT\tDesc: " + tyreSurfSels[i].descrp + ")\n";
    }


    //Remark message for rolling radii provided by user
    string rollingRadMsg, rollRadFrnStr, rollRadRearStr;
    rollRadFrnStr = to_string(abs(frontSLRVec[frontSLRVec.size() - 1]));
    rollRadFrnStr.erase(rollRadFrnStr.find_last_not_of('0') + 3);      //for keeping only 2 zeroes post descimal
    rollRadRearStr = to_string(abs(rearSLRVec[rearSLRVec.size() - 1]));
    rollRadRearStr.erase(rollRadRearStr.find_last_not_of('0') + 3);
    rollingRadMsg += "\nRolling radius values provided by user -\nFront tyre(Rrf): " + rollRadFrnStr + " mm.\t\tRear tyre(Rrr): " + rollRadRearStr + " mm.\n";
    sprintf(remark, "Measured Values - Ground Clearance of Urea Tank: %0.2lf mm || RampOver Angle: %0.2lf deg\nAcceptance Criteria - minimum ground clearance %0.2lf mm to be maintained.||\tRamp Over angle: min.15 deg (IS:12218)\n", groundClearance, rampOvAngMeas, stdGrndCleVal_Ur);
    final_res.remark = remark + rollingRadMsg + suspTravMsg + tyreSurfInfo;

    //destroy the UI dialog for smooth transition 
    status = ProUIDialogDestroy(DLG_F3B02_004);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    tyreSurfSels.clear();
    longMembSels.clear();

    ruleLog.Write("rearEndDist: " + to_string(rearEndDist) + "\nframeHeight: " + to_string(frameHeight) + "\nRolling Radius rear: " + to_string(abs(rollRadRear[2])));
    ruleLog.Write("frontPntDist: " + to_string(frontPntDist) + "\ngroundClearance: " + to_string(groundClearance) + "\nRolling Radius front: " + to_string(abs(rollRadFront[2])) + "\nrearPntDist: " + to_string(rearPntDist));


    return 0;
}

ProError measureDistanceBetweenSurfaces_F3b02(ProSelection& sel_surf1, ProBoolean option1, ProSelection& sel_surf2, ProBoolean option2, double& distance_bw_surfs)
{
    ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenSurfaces <=================");

    Pro2dPnt param_surfs1, param_surfs2;
    Pro3dPnt pnt_surfs1, pnt_surfs2;

    status = ProSelectionWithOptionsDistanceEval(sel_surf1, option1, sel_surf2, option2, param_surfs1, param_surfs2, pnt_surfs1, pnt_surfs2, &distance_bw_surfs);
    ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance_bw_surfs: " + to_string(distance_bw_surfs));

    return status;
}

void getGroundClearanceValsFromCsv_Ur(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv) {
    mainLog.Write("================= getGroundClearanceValsFromCsv ==================");

    InterfaceRule iRule;
    vector<vector<string>> csvData2D = iRule.getData2D(csvFilename);
    for (int i = 1; i < csvData2D.size(); i++) {
        if (csvData2D[i][partNoIdx].compare(partNo) == 0) {
            string tok1;
            std::istringstream ss1(csvData2D[i][reqValIdx]);
            while (std::getline(ss1, tok1, ';')) {
                reqValsFromCsv.push_back(tok1);
            }
            break;
        }

    }
    csvData2D.clear();
}

int createOffsetPlaneWithReference_F3B02_004(ProSelection refSelection, double offsetValue, char* outputPlaneName)
{
    /*ProModelitem refPlaneitem;
    ProSelection refPlaneSel;*/
    wchar_t wRefPlaneName[PRO_NAME_SIZE], wOutputPlaneName[PRO_NAME_SIZE];
    ProElement	elem_tree, elem_ftype, elem_consts, elem_prl, elem_const_type1, elem_const_type2, elem_along, elem_offset, elem_offset_ref, elem_feature_name, elem_offset_create;
    ProReference REPDEP_ref1, REPDEP_ref2;
    ProFeatureCreateOptions* opts = 0;
    ProFeature pln_feat;
    ProErrorlist errors;
    ruleLog.Write("Offset value = " + to_string(offsetValue));

    /* =============================================================== *\
    Create Element Tree
    \* =============================================================== */
    status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
    ruleLog.Write("Tree root status = " + to_string(status));

    // TREE ALLOCATION
    status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
    ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM);
    ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
    ruleLog.Write("type status = " + to_string(status));

    // FEATURE NAME
    status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
    status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wOutputPlaneName, outputPlaneName));
    status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);

    // CONSTRAINTS ALLOCATION
    status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINTS, &elem_consts);
    ProElemtreeElementAdd(elem_tree, NULL, elem_consts);
    ruleLog.Write("constraints status = " + to_string(status));

    // Constraint 1
    status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_offset);
    status = ProElemtreeElementAdd(elem_consts, NULL, elem_offset);
    ruleLog.Write("1st constraint status = " + to_string(status));

    status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type1);
    ProElementIntegerSet(elem_const_type1, PRO_DTMPLN_OFFS);
    status = ProElemtreeElementAdd(elem_offset, NULL, elem_const_type1);
    ruleLog.Write("1st constraint type status = " + to_string(status));

    status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_offset_ref);
    status = ProSelectionToReference(refSelection, &REPDEP_ref1);
    ruleLog.Write("ProSelectionToReference = " + to_string(status));
    status = ProElementReferenceSet(elem_offset_ref, REPDEP_ref1);
    ruleLog.Write("ProElementReferenceSet = " + to_string(status));
    status = ProElemtreeElementAdd(elem_offset, NULL, elem_offset_ref);
    ruleLog.Write("1st constraint reference status = " + to_string(status));



    /* =============================================================== *\
        Allocate ref offset value element; add under constraint element.
    \* =============================================================== */
    status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF_OFFSET, &elem_offset_create);
    ProElementDecimalsSet(elem_offset_create, 4);
    ProElementDoubleSet(elem_offset_create, offsetValue);

    status = ProElemtreeElementAdd(elem_offset, NULL, elem_offset_create);


    /*---------------------------------------------------------------*\
    Create the feature in the current model.
    \*---------------------------------------------------------------*/

    ProSelection curMdlSel;
    status = ProSelectionAlloc(NULL, &curMdlitem, &curMdlSel);
    ruleLog.Write("ProSelectionAlloc status featCreate: " + to_string(status));
    status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

    opts[0] = PRO_FEAT_CR_NO_OPTS;

    // Create Plane
    status = ProFeatureWithoptionsCreate(curMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pln_feat, &errors);
    ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

    status = ProArrayFree((ProArray*)&opts);
    ruleLog.Write("ProArrayFree status = " + to_string(status));
    status = ProElementFree(&elem_tree);
    ruleLog.Write("ProElementFree status = " + to_string(status));

    return 0;
}

ProError platformList_Ur(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- platformList -----------------------------");

    status = ProUIPushbuttonDisable(dialog, PB_ROK);
    status = ProUIOptionmenuDisable(dialog, vehicalType);
    string* _data = (string*)data;
    int n_sel;
    char** selValue;

    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
    ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
    ruleLog.Write("Platform = " + string(selValue[0]));
    string storePlatVal = string(selValue[0]);

    vector<string> SelPlatform;

    if (storePlatVal == "Select")
    {
        ProUIPushbuttonDisable(dialog, PB_ROK);
        ProUIPushbuttonDisable(dialog, vehicalType);
    }

    getPlatval_Ur(dbList2D_Ur, storePlatVal, SelPlatform);
    //ProUIPushbuttonDisable(DLG_F3A01_003, PB_ROK);

    for (auto str : SelPlatform) {
        ruleLog.Write("SelPlatform = " + str);
    }

    //Assign to global
    PlatFVal_Ur = storePlatVal;


    option_menu_Ur(SelPlatform, vehicalType);
    status = ProUIPushbuttonEnable(dialog, vehicalType);

    return PRO_TK_NO_ERROR;
}

ProError subplatformList_Ur(char* dialog, char* component, ProAppData data)
{

    ruleLog.Write("----------------------------- subplatformList -----------------------------");
    status = ProUIPushbuttonDisable(dialog, PB_ROK);
    //vector<string> reqValsFromCsv;
    InterfaceRule irc;
    string* reqData = (string*)data;
    int n_sel;
    char** selValue;
    boolean isUserQuits = false;
    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
    ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
    ruleLog.Write("Sub Platform = " + string(selValue[0]));
    string str = string(selValue[0]);

    //Assign to global
    subPlatFVal_Ur = selValue[0];

    getGroundClearanceValsFromCsv_Ur("IRF3B02004.csv", 1, 2, str, reqValsFromCsv_Ur);
    for (auto values : reqValsFromCsv_Ur) {
        ruleLog.Write("Distances = " + values);
        stdGrndCleVal_Ur = stod(values);
    }
    //reqValsFromCsv = reqValsFromCsv;
    ruleLog.Write(" Size = " + to_string(reqValsFromCsv_Ur.size()));

    status = ProUIPushbuttonEnable(dialog, PB_ROK);
    return PRO_TK_NO_ERROR;

}

void getPlatval_Ur(vector<vector<string>> dbList2D_EP_F3A01, string platformName, vector<string>& values)
{

    ruleLog.Write("----------------------------- getengineCapdatafromcsv -----------------------------");

    for (int i = 1; i < dbList2D_EP_F3A01.size(); ++i) {
        while (dbList2D_EP_F3A01[i][0].compare(platformName) == 0) {
            string str = dbList2D_EP_F3A01[i][1];
            if (find(values.begin(), values.end(), str) == values.end()) {
                values.push_back(str);
            }
            break;
        }
    }
    ruleLog.Write("platform.size:" + to_string(values.size()));
}

void option_menu_Ur(vector<string> option_menulist, char* optionmenu)
{

    ruleLog.Write("----------------------------- option_menu -----------------------------");

    char** loadCapListNames;
    wchar_t** loadCapListLabels;
    status = ProArrayAlloc(option_menulist.size(), sizeof(char*), 50, (ProArray*)&loadCapListNames);
    status = ProArrayAlloc(option_menulist.size(), sizeof(wchar_t*), 50, (ProArray*)&loadCapListLabels);

    for (int i = 0; i < option_menulist.size(); ++i)
    {
        loadCapListNames[i] = (char*)calloc(50, sizeof(char));
        ProTKSprintf(loadCapListNames[i], "%s", option_menulist[i]);

        loadCapListLabels[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
        ProStringToWstring(loadCapListLabels[i], loadCapListNames[i]);
    }
    status = ProUIOptionmenuNamesSet(DLG_F3B02_004, optionmenu, int(option_menulist.size()), loadCapListNames);
    ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
    status = ProUIOptionmenuLabelsSet(DLG_F3B02_004, optionmenu, int(option_menulist.size()), loadCapListLabels);
    ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

    status = ProArrayFree((ProArray*)&loadCapListNames);
    status = ProArrayFree((ProArray*)&loadCapListLabels);
}

int measureDistanceBetweenPlaneAndComp__F3B02_004(ProSelection planeSel, ComponentData reqComp1, double& distance, Pro3dPnt pntArr[2])
{
    ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenPlaneAndComp <=================");

    //ProSelection planeSel;
    ProMdl reqMdl;
    char cReqMdlPath[PRO_PATH_SIZE];
    ProPath wReqMdlPath;
    ProModelitem planeMdlitem;
    wchar_t wPlaneName[PRO_NAME_SIZE];
    Utils util;


    ProSelection sels[1];
    ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected

    ProName comp1_name;
    ProModelitem feature[1];
    ProMdl reqMdls[1];

    ProStringToWstring(comp1_name, reqComp1.name);
    status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
    ruleLog.Write("ProMdlnameInit: " + to_string(status));
    status = ProMdlToModelitem(reqMdls[0], &feature[0]);

    ProAsmcomppath path[1];
    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));


    status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    Pro2dPnt param_1, param_2;

    status = ProSelectionWithOptionsDistanceEval(planeSel, PRO_B_FALSE, sels[0], PRO_B_FALSE, param_1, param_2, pntArr[0], pntArr[1], &distance);
    ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(distance));
    if (status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT) {
        util.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selections.");
        return -1;
    }

    ruleLog.Write("Coordinates of point 1: \nX-Coord - " + to_string(pntArr[0][0]) + "\tY-Coord - " +
        to_string(pntArr[0][1]) + "\tZ-Coord - " + to_string(pntArr[0][2]));
    ruleLog.Write("Coordinates of point 2: \nX-Coord - " + to_string(pntArr[1][0]) + "\tY-Coord - " +
        to_string(pntArr[1][1]) + "\tZ-Coord - " + to_string(pntArr[1][2]));

    return 0;
}
