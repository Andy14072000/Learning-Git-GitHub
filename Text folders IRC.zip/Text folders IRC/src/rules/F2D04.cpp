/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 15-04-2024	|	V1_0_0		| F2D04 - LIFT SUSPENSION
==================================================================================================================*/
#include "F2D04.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812

/*==================================================================================================================
RULE ID		    |  DEVELOPER			| DEPENDENT MODULES			| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F2D04-002	|  Himanshu Pachpute	| MF2D04; MF5B01			| Minimum 45 mm clearance to be ensured between Tire and Main Bellow.
===================================================================================================================*/

//#define DLG_IRF2D04_002     "dlg_IRF2D04_002"
//#define PB_RCLOSE           "CommitClose"
//#define PB_ROK              "CommitOK"
//
//struct FeatIDdataStr_IRF2D04_002 { 
//    int level{}; 
//    int feat_ids[10]{}; 
//};
//
//struct AsmModelStr_IRF2D04_002 {
//    ProMdl Model{}; 
//    int Model_feat_id{}; 
//};
//
//struct Comp_Info_IRF2D04_002 {
//    ProSelection p_selection{};
//    char         Description[PRO_PATH_SIZE]{};
//    char         Name[PRO_PATH_SIZE]{};
//    int          FeatId{};
//};
//
//vector<FeatIDdataStr_IRF2D04_002>           FeatIDDataArr_IRF2D04_002{};
//AsmModelStr_IRF2D04_002                     AsmCModel_IRF2D04_002[1000]{};
//AsmModelStr_IRF2D04_002                     CModel_IRF2D04_002[1000]{};
//vector<Comp_Info_IRF2D04_002>               Comp_Info_IRF2D04_002_vec1{};
//vector<Comp_Info_IRF2D04_002>               Comp_Info_IRF2D04_002_vec2{};
//int                                         ModelsCount_IRF2D04_002{}, 
//                                            AsmModelCount_IRF2D04_002{}, 
//                                            MdlCount_IRF2D04_002{}, 
//                                            OwnerFeatID_IRF2D04_002{}, 
//                                            Levels_IRF2D04_002{};
//
//int IRF2D04::IRF2D04_002(ruleResult& final_res)
//{
//    ruleLog.Write("==========================   IRF2D04::IRF2D04_002   ==========================");
//
//    ProMdl          Mdl{};
//    Pro2dPnt        param_1, param_2;
//    Pro3dPnt        pnt_1, pnt_2;
//    double          distance{};
//
//    status = ProMdlCurrentGet(&Mdl);
//
//    curMdl = Mdl;
//    Levels_IRF2D04_002 = 1;
//    CModel_IRF2D04_002[0].Model = Mdl;
//    CModel_IRF2D04_002[0].Model_feat_id = 0;
//    ModelsCount_IRF2D04_002 = 1;
//    AsmModelCount_IRF2D04_002 = 0;
//
//    while (ModelsCount_IRF2D04_002 > 0) {
//        for (int a = 0; a < ModelsCount_IRF2D04_002; ++a) {
//            OwnerFeatID_IRF2D04_002 = CModel_IRF2D04_002[a].Model_feat_id;
//            status = ProSolidFeatVisit((ProSolid)CModel_IRF2D04_002[a].Model, (ProFeatureVisitAction)VisitAction_IRF2D04_002, compsFilter, NULL);
//            ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
//        }
//
//        if (AsmModelCount_IRF2D04_002 > 0) {
//            ++Levels_IRF2D04_002;
//            for (int b = 0; b < AsmModelCount_IRF2D04_002; ++b) {
//                CModel_IRF2D04_002[b].Model = AsmCModel_IRF2D04_002[b].Model;
//                CModel_IRF2D04_002[b].Model_feat_id = AsmCModel_IRF2D04_002[b].Model_feat_id;
//            }
//            ModelsCount_IRF2D04_002 = AsmModelCount_IRF2D04_002;
//            AsmModelCount_IRF2D04_002 = 0;
//        }
//        else
//            ModelsCount_IRF2D04_002 = 0;
//    }
//
//    for (size_t i = 0; i < (Comp_Info_IRF2D04_002_vec1.size() + Comp_Info_IRF2D04_002_vec2.size()); i++) {
//        status = ProSelectionWithOptionsDistanceEval(Comp_Info_IRF2D04_002_vec1[0].p_selection, PRO_B_TRUE, Comp_Info_IRF2D04_002_vec2[i].p_selection, PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance);
//        ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\t Distance: " + to_string(distance));
//        ruleLog.Write("Distance between " + string(Comp_Info_IRF2D04_002_vec1[0].Name) + " " + string(Comp_Info_IRF2D04_002_vec1[0].Description) + " " + to_string(Comp_Info_IRF2D04_002_vec1[0].FeatId) + " & " + 
//            string(Comp_Info_IRF2D04_002_vec2[i].Name) + " " + string(Comp_Info_IRF2D04_002_vec2[i].Description) + " " + to_string(Comp_Info_IRF2D04_002_vec2[i].FeatId) + ": " + to_string(distance));
//    }
//
//    FeatIDDataArr_IRF2D04_002.clear();
//    Comp_Info_IRF2D04_002_vec1.clear();
//    Comp_Info_IRF2D04_002_vec2.clear();
//    memset(&CModel_IRF2D04_002, 0, sizeof(CModel_IRF2D04_002));
//    memset(&AsmCModel_IRF2D04_002, 0, sizeof(AsmCModel_IRF2D04_002));
//    return 0;
//}
//
//ProError VisitAction_IRF2D04_002(ProFeature* p_feature, ProError status, ProAppData app_data)
//{
//    ruleLog.Write("----------------------------- VisitAction_IRF2D04_002 -----------------------------");
//
//    Comp_Info_IRF2D04_002       CompSelection{};
//    char                        part_no[PRO_PATH_SIZE]{};
//    ProMdl                      model{};
//    ProMdlType                  type{};
//    wchar_t                     wFeatName[PRO_NAME_SIZE]{};
//    ProModelitem                modelItem{};
//    ProParameter                pDesc;
//    ProParamvalue               pvDesc;
//    FeatIDdataStr_IRF2D04_002   _FeatIDdata;
//    bool                        compfound{ false };
//    ProMdlfileType              comp_type;
//    ProFamilyMdlName            comp_name;
//
//    ruleLog.Write("Component Level: " + to_string(Levels_IRF2D04_002));
//    status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
//    ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));
//    ProWstringToString(part_no, comp_name);
//    ruleLog.Write("ProMdlName: " + string(part_no));
//
//    ++MdlCount_IRF2D04_002;
//
//    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
//    ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
//
//    status = ProMdlTypeGet(model, &type);
//    ruleLog.Write("ProMdlTypeGet:" + to_string(status));
//
//    status = ProMdlMdlnameGet(model, wFeatName);
//    ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
//    ProWstringToString(CompSelection.Name, wFeatName);
//
//    status = ProMdlToModelitem(model, &modelItem);
//    ruleLog.Write("ProMdlToModelitem: " + to_string(status));
//
//    status = ProParameterInit(&modelItem, L"DESCRIPTION", &pDesc);
//    ruleLog.Write("ProParameterInit: " + to_string(status));
//
//    status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
//    ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));
//
//    ProWstringToString(CompSelection.Description, pvDesc.value.s_val);
//    ruleLog.Write("ProWstringToString: " + string(CompSelection.Description));
//
//    CompSelection.FeatId = p_feature->id;
//
//    if (Levels_IRF2D04_002 == 1) {
//        _FeatIDdata.feat_ids[0] = p_feature->id;
//        _FeatIDdata.level = Levels_IRF2D04_002;
//        FeatIDDataArr_IRF2D04_002.push_back(_FeatIDdata);
//    }
//    else {
//        for (int j = 0; j < FeatIDDataArr_IRF2D04_002.size(); ++j) {
//            if (FeatIDDataArr_IRF2D04_002[j].feat_ids[Levels_IRF2D04_002 - 2] == OwnerFeatID_IRF2D04_002) {
//                FeatIDdataStr_IRF2D04_002	owner_feat_id_data = FeatIDDataArr_IRF2D04_002[j];
//                for (int i = 0; i < Levels_IRF2D04_002 - 1; ++i) {
//                    _FeatIDdata.feat_ids[i] = owner_feat_id_data.feat_ids[i];
//                }
//                _FeatIDdata.feat_ids[Levels_IRF2D04_002 - 1] = p_feature->id;
//                _FeatIDdata.level = Levels_IRF2D04_002;
//                break;
//            }
//        }
//        FeatIDDataArr_IRF2D04_002.push_back(_FeatIDdata);
//    }
//
//    regex   pattern1("F2D04"), pattern2("F5B01");
//    if (Levels_IRF2D04_002 == 1 && (regex_search(CompSelection.Name, pattern1) || regex_search(CompSelection.Name, pattern2))) 
//    {
//        ProMdl curMdl;
//        ProIdTable			comp_id_table;
//        int					table_num;
//        ProAsmcomppath		p_comp_path;
//        ProModelitem		p_modelitem; 
//        
//        ruleLog.Write("========================================================");
//        ruleLog.Write("Level: " + to_string(Levels_IRF2D04_002));
//        ruleLog.Write("Found: Level " + to_string(Levels_IRF2D04_002) + " (" + string(CompSelection.Description) + ") (" + CompSelection.Name + ") " + to_string(CompSelection.FeatId));
//
//        compfound = true;
//        table_num = Levels_IRF2D04_002;
//
//        ruleLog.Write("table_num: " + to_string(table_num));
//
//        for (int m = 0; m < Levels_IRF2D04_002; ++m) {
//            comp_id_table[m] = _FeatIDdata.feat_ids[m];
//            ruleLog.Write("comp_id_table[]: " + to_string(m) + " " + to_string(comp_id_table[m]));
//        }
//
//        status = ProMdlToModelitem(model, &p_modelitem);
//        ruleLog.Write("ProMdlToModelitem: " + to_string(status));
//
//        status = ProMdlCurrentGet(&curMdl);
//        ruleLog.Write("ProMdlCurrentGet: " + to_string(status));
//
//        status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
//        ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
//
//        status = ProSelectionAlloc(&p_comp_path, &p_modelitem, &CompSelection.p_selection);
//        ruleLog.Write("ProSelectionAlloc: " + to_string(status));
//
//        if (regex_search(CompSelection.Name, pattern1))
//            Comp_Info_IRF2D04_002_vec1.push_back(CompSelection);
//        else
//            Comp_Info_IRF2D04_002_vec2.push_back(CompSelection);
//        
//    }
//
//    //if (type == PRO_MDL_ASSEMBLY && compfound == false)
//    //{
//    //    AsmCModel_IRF2D04_002[AsmModelCount_IRF2D04_002].Model = model;
//    //    AsmCModel_IRF2D04_002[AsmModelCount_IRF2D04_002].Model_feat_id = p_feature->id;
//    //    AsmModelCount_IRF2D04_002 += 1;
//    //}
//
//    return PRO_TK_NO_ERROR;
//}
//
////int IRF2D04::IRF2D04_002(ruleResult& final_res) 
////{
////	ruleLog.Write("==========================   IRF2D04::IRF2D04_002   ==========================");
////
////	ProMdl			Mdl;
////	Pro2dPnt        param_1, param_2;
////    Pro3dPnt        pnt_1, pnt_2;
////    double          distance{};
////
////	status = ProMdlCurrentGet(&Mdl);
////	ruleLog.Write("ProMdlCurrentGet: " + to_string(status));
////
////	status = ProSolidFeatVisit((ProSolid)Mdl, (ProFeatureVisitAction)VisitAction_IRF2D04_002, compsFilter, NULL);
////	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
////
////	Comp_Info_IRF2D04_002_vec.insert(Comp_Info_IRF2D04_002_vec.end(), Comp_Info_IRF2D04_002_vec2.begin(), Comp_Info_IRF2D04_002_vec2.end());
////	for (size_t i = 0; i < Comp_Info_IRF2D04_002_vec.size(); i++) {
////	    status = ProSelectionWithOptionsDistanceEval(Comp_Info_IRF2D04_002_vec[i].p_selection, PRO_B_TRUE, Comp_Info_IRF2D04_002_vec[i + 1].p_selection, PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance);
////	    ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\t Distance: " + to_string(distance));
////	}
////
////	Comp_Info_IRF2D04_002_vec.clear();
////	Comp_Info_IRF2D04_002_vec2.clear();
////	return 0;
////}
////
////ProError VisitAction_IRF2D04_002(ProFeature* p_feature, ProError status, ProAppData app_data) 
////{
////	ruleLog.Write("----------------------------- VisitAction_IRF2D04_002 -----------------------------");
////
////	Comp_Info_IRF2D04_002       CompSelection{};
////	char                        part_no[PRO_PATH_SIZE]{};
////	ProMdl                      model{};
////	ProMdlType                  type{};
////	wchar_t                     wFeatName[PRO_NAME_SIZE]{};
////	ProModelitem                modelItem{};
////	ProParameter                pDesc;
////	ProParamvalue               pvDesc;
////	bool                        compfound{ false };
////	ProMdlfileType              comp_type;
////	ProFamilyMdlName            comp_name;
////	
////
////	status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
////	ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));
////	ProWstringToString(part_no, comp_name);
////	ruleLog.Write("ProMdlName: " + string(part_no));
////	
////	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
////	ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
////	
////	status = ProMdlTypeGet(model, &type);
////	ruleLog.Write("ProMdlTypeGet:" + to_string(status));
////	
////	status = ProMdlMdlnameGet(model, wFeatName);
////	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
////	ProWstringToString(CompSelection.Name, wFeatName);
////	
////	status = ProMdlToModelitem(model, &modelItem);
////	ruleLog.Write("ProMdlToModelitem: " + to_string(status));
////	
////	status = ProParameterInit(&modelItem, L"DESCRIPTION", &pDesc);
////	ruleLog.Write("ProParameterInit: " + to_string(status));
////	
////	status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
////	ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));
////	
////	ProWstringToString(CompSelection.Description, pvDesc.value.s_val);
////	ruleLog.Write("ProWstringToString: " + string(CompSelection.Description));
////	
////	CompSelection.FeatId = p_feature->id;
////	ruleLog.Write("CompSelection.FeatId: " + to_string(CompSelection.FeatId));
////
////	regex   pattern1("F2D04"), pattern2("F5B01");
////	if ((regex_search(CompSelection.Name, pattern1) || regex_search(CompSelection.Name, pattern2))) 
////	{
////	    ProMdl curMdl;
////	    ProIdTable			comp_id_table;
////	    int					table_num;
////	    ProAsmcomppath		p_comp_path;
////	    ProModelitem		p_modelitem; 
////	        
////	    ruleLog.Write("Found: (" + string(CompSelection.Description) + ") (" + CompSelection.Name + ") " + to_string(CompSelection.FeatId));
////	
////	    compfound = true;
////	
////	    status = ProMdlToModelitem(model, &p_modelitem);
////	    ruleLog.Write("ProMdlToModelitem: " + to_string(status));
////	
////	    status = ProSelectionAlloc(NULL , &p_modelitem, &CompSelection.p_selection);
////	    ruleLog.Write("ProSelectionAlloc: " + to_string(status));
////	
////	    if (regex_search(CompSelection.Name, pattern1))
////			Comp_Info_IRF2D04_002_vec.push_back(CompSelection);
////	    else
////	        Comp_Info_IRF2D04_002_vec2.push_back(CompSelection);
////	        
////	}
////
////	return PRO_TK_NO_ERROR;
////}
//
//#define DLG_IRF2D04_002		"dlg_IR_F2D04_002"
//#define PB_RSELECT			"PB_Select"
//#define PB_ROK				"CommitOK"
//#define PB_RCANCEL			"CommitClose"
//
//struct ComponentData_IRF2D04_002 {
//    ProSelection    Surf_Sel{};
//	char			name[PRO_PATH_SIZE];
//	char			desc[PRO_PATH_SIZE];
//	int				Mdl_id{};
//	int				Surf_id{};
//};
//
//struct Clearance_Struct_IRF2D04_002 {
//    double          clearance_value{};
//    ProBoolean      interf;
//    Pro3dPnt        coord[2];
//    char			name1[PRO_PATH_SIZE];
//    char			desc1[PRO_PATH_SIZE];
//    int				Mdl_id1{};
//    int				Surf_id1{};
//    char			name2[PRO_PATH_SIZE];
//    char			desc2[PRO_PATH_SIZE];
//    int				Mdl_id2{};
//    int				Surf_id2{};
//};
//			
//vector<ComponentData_IRF2D04_002> ComponentData_IRF2D04_002_array1{};
//vector<ComponentData_IRF2D04_002> ComponentData_IRF2D04_002_array2{};
//
//bool is_alphanumeric_and_space_IRF2D04_002(const string& str) {
//    if (str.empty()) {
//        return false;
//    }
//    for (char c : str) {
//        if (!isalnum(c) && !isspace(c) && c != '-' && c != '.' && c != 'X' && c != ',') {
//            return false;
//        }
//    }
//    return true;
//}
//
//size_t findIndexOfSmallestClearanceValue(const std::vector<Clearance_Struct_IRF2D04_002>& vec) {
//    if (vec.empty()) {
//        throw std::runtime_error("Vector is empty");
//    }
//
//    auto minElementIt = std::min_element(vec.begin(), vec.end(), [](const Clearance_Struct_IRF2D04_002& a, const Clearance_Struct_IRF2D04_002& b) {
//        return a.clearance_value < b.clearance_value;
//        });
//
//    return std::distance(vec.begin(), minElementIt);
//}
//
//int IRF2D04::IRF2D04_002(ruleResult& final_res)
//{
//	ruleLog.Write("==========================   IRF2D04::IRF2D04_002   ==========================");
//
//	isUserQuits = false;
//	
//    vector<Clearance_Struct_IRF2D04_002> clearance_value_vect{};
//	string RemarkString{};
//    int index_val;
//
//    deleteDatumPointCreatedUsingCsys_IR_F2D04_002("datum_PNT1");
//    deleteDatumPointCreatedUsingCsys_IR_F2D04_002("datum_PNT2");
//
//	status = ProUIDialogCreate(DLG_IRF2D04_002, DLG_IRF2D04_002);
//	status = ProUIDialogAboveactivewindowSet(DLG_IRF2D04_002, PRO_B_FALSE);
//	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D04_002, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
//	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D04_002, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
//	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D04_002, PB_RSELECT, (ProUIAction)select_action_IRF2D04_002, NULL);
//	status = ProUIPushbuttonDisable(DLG_IRF2D04_002, PB_ROK);
//
//	status = ProUIDialogHide(DLG_IRC_MAIN);
//	status = ProUIDialogActivate(DLG_IRF2D04_002, &dlg_sts);
//	status = ProUIDialogDestroy(DLG_IRF2D04_002);
//	status = ProUIDialogShow(DLG_IRC_MAIN);
//
//	if (isUserQuits)
//		return -1;
//
//    for (int i = 0; i < ComponentData_IRF2D04_002_array1.size(); i++) {
//        for (int j = 0; j < ComponentData_IRF2D04_002_array2.size(); j++) {
//            Clearance_Struct_IRF2D04_002 clear_obj{};
//	        status = ProFitClearanceCompute(ComponentData_IRF2D04_002_array1[i].Surf_Sel, PRO_FIT_INCLUDE_NONE, ComponentData_IRF2D04_002_array2[j].Surf_Sel, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clear_obj.clearance_value, NULL, &clear_obj.interf, clear_obj.coord);
//	        ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tDistance: " + to_string(clear_obj.clearance_value));
//            clear_obj.Mdl_id1 = ComponentData_IRF2D04_002_array1[i].Mdl_id;
//            clear_obj.Mdl_id2 = ComponentData_IRF2D04_002_array2[j].Mdl_id;
//            clear_obj.Surf_id1 = ComponentData_IRF2D04_002_array1[i].Surf_id;
//            clear_obj.Surf_id2 = ComponentData_IRF2D04_002_array2[j].Surf_id;
//            strcpy(clear_obj.name1, ComponentData_IRF2D04_002_array1[i].name);
//            strcpy(clear_obj.name2, ComponentData_IRF2D04_002_array2[j].name);
//            strcpy(clear_obj.desc1, ComponentData_IRF2D04_002_array1[i].desc);
//            strcpy(clear_obj.desc2, ComponentData_IRF2D04_002_array2[j].desc);
//            clearance_value_vect.push_back(clear_obj);
//        }
//    }
//
//    try {
//        size_t index = findIndexOfSmallestClearanceValue(clearance_value_vect);
//        ruleLog.Write("The index of the smallest clearance value is: " + to_string(index));
//        ruleLog.Write("The smallest clearance value is: " + to_string(clearance_value_vect[index].clearance_value));
//        index_val = index;
//    }
//    catch (const std::runtime_error& e) {
//        std::cerr << e.what() << std::endl;
//    }
//	
//    createDatumPointsusingCSYS_IR_F2D04_002(clearance_value_vect[index_val].coord, "CSYS_ASM_DEF");
//
//	ostringstream stream{};
//	stream << fixed << setprecision(2) << clearance_value_vect[index_val].clearance_value;
//    RemarkString = "Clearance between Tyre and Rubber Bellow is " + stream.str() + "mm" + "\nAcceptance Criteria: Clearance between Tyre and Main Bellow needs to be >= 45mm." 
//        + "\n\nSelected reference surfaces for distance calculation.: \n" 
//        + "\t\t" + string(clearance_value_vect[index_val].name1) + " " + string(clearance_value_vect[index_val].desc1) + " [Model Feat ID: " + to_string(clearance_value_vect[index_val].Mdl_id1) + "] [Surface Feat ID: " + to_string(clearance_value_vect[index_val].Surf_id1) + "]\n"
//        + "\t\t" + string(clearance_value_vect[index_val].name2) + " " + string(clearance_value_vect[index_val].desc2) + " [Model Feat ID: " + to_string(clearance_value_vect[index_val].Mdl_id2) + "] [Surface Feat ID: " + to_string(clearance_value_vect[index_val].Surf_id2) + "]";
//
//	final_res.remark = string(RemarkString);
//
//	if (clearance_value_vect[index_val].clearance_value >= 45)
//		final_res.result = "PASS";
//	else
//		final_res.result = "FAIL";
//
//	ruleLog.Write("status: " + final_res.result);
//	ruleLog.Write("remark: " + final_res.remark);
//
//	RemarkString.clear();
//    clearance_value_vect.clear();
//    ComponentData_IRF2D04_002_array1.clear();
//    ComponentData_IRF2D04_002_array2.clear();
//	return 0;
//}
//
//ProError select_action_IRF2D04_002(char* dialog, char* component, ProAppData data)
//{
//	ruleLog.Write("----------------------------- select_action_IRF2D04_002 -----------------------------");
//
//    status = ProUIDialogHide(DLG_IRF2D04_002);
//
//	int					n_sel1, n_sel2, curWinId;
//	InterfaceRule	    irule1, irule2, irule3, irule4;
//    ProSelection*       surfSels_F2D04_002_1 = nullptr, *surfSels_F2D04_002_2 = nullptr;
//    ComponentData_IRF2D04_002_array1.clear();
//    ComponentData_IRF2D04_002_array2.clear();
//    deleteDatumPointCreatedUsingCsys_IR_F2D04_002("datum_PNT1");
//    deleteDatumPointCreatedUsingCsys_IR_F2D04_002("datum_PNT2");
//
//	status = ProWindowCurrentGet(&curWinId);
//	status = ProWindowRepaint(curWinId);
//
//    irule1.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Tyre Surface Selection!", "Please select the required surfaces from Tyre");
//	status = ProSelect("surface", -1, NULL, NULL, NULL, NULL, &surfSels_F2D04_002_1, &n_sel1);
//	ruleLog.Write("Proselect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel1));
//	if (status == PRO_TK_NO_ERROR && n_sel1 > 0)
//		status = ProUIPushbuttonEnable(dialog, PB_ROK);
//    if (n_sel1 < 1 || status != PRO_TK_NO_ERROR) {
//        irule2.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
//        status = ProUIPushbuttonDisable(dialog, PB_ROK);
//    }
//
//    for (int i = 0; i < n_sel1; i++)
//    {
//        ProModelitem				Selection_model_item, parent_model_item;
//        int                         lastCompID = -1;
//        ProAsmcomppath              asm_comp_path{};
//        ProParameter				pDesc;
//        ProParamvalue				pvDesc;
//        ProName						name;
//        ComponentData_IRF2D04_002	CompData{};
//        char			            desc[PRO_PATH_SIZE];
//        char                        NotFound[30] = { "Description not found." };
//
//        status = ProSelectionCopy(surfSels_F2D04_002_1[i], &CompData.Surf_Sel);
//        ruleLog.Write("ProSelectionCopy: " + to_string(status));
//
//        status = ProSelectionModelitemGet(surfSels_F2D04_002_1[i], &Selection_model_item);
//        ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));
//
//        status = ProMdlMdlnameGet(Selection_model_item.owner, name);
//        ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
//
//        status = ProMdlToModelitem(Selection_model_item.owner, &parent_model_item);
//        ruleLog.Write("ProMdlToModelitem: " + to_string(status));
//
//        status = ProParameterInit(&parent_model_item, L"DESCRIPTION", &pDesc);
//        ruleLog.Write("ProParameterInit: " + to_string(status));
//
//        status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
//        ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));
//
//        status = ProSelectionAsmcomppathGet(surfSels_F2D04_002_1[i], &asm_comp_path);
//        ruleLog.Write("ProSelectionAsmcomppathGet: " + to_string(status));
//        for (int k = 0; k < asm_comp_path.table_num; ++k)
//            lastCompID = asm_comp_path.comp_id_table[k];
//
//        ProWstringToString(CompData.name, name);
//        ProWstringToString(desc, pvDesc.value.s_val);
//        ruleLog.Write("desc: " + string(desc));
//        (is_alphanumeric_and_space_IRF2D04_002(desc) ? strcpy(CompData.desc, desc) : strcpy(CompData.desc, NotFound));
//
//        CompData.Mdl_id = lastCompID;
//        CompData.Surf_id = Selection_model_item.id;
//        ComponentData_IRF2D04_002_array1.push_back(CompData);
//        ruleLog.Write("CompArray_F2D04_002[i].name: " + string(ComponentData_IRF2D04_002_array1[i].name) + "\tCompArray_F2D04_002[i].desc: " + string(ComponentData_IRF2D04_002_array1[i].desc) + "\tCompArray_F2D04_002[i].id: " + to_string(ComponentData_IRF2D04_002_array1[i].Mdl_id) + "\tCompArray_F2D04_002[i].Surf_id: " + to_string(ComponentData_IRF2D04_002_array1[i].Surf_id));
//    }
//
//    irule3.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Rubber Bellow Selection Info", "Please select the required surfaces from Rubber Bellow.");
//    status = ProSelect("surface", -1, NULL, NULL, NULL, NULL, &surfSels_F2D04_002_2, &n_sel2);
//    ruleLog.Write("Proselect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel2));
//    if (status == PRO_TK_NO_ERROR && n_sel2 > 0)
//        status = ProUIPushbuttonEnable(dialog, PB_ROK);
//	if (n_sel2 < 1 || status != PRO_TK_NO_ERROR) {
//        irule4.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
//		status = ProUIPushbuttonDisable(dialog, PB_ROK);
//	}
//
//
//    for (int i = 0; i < n_sel2; i++)
//    {
//        ProModelitem				Selection_model_item1, parent_model_item1;
//        int                         lastCompID1 = -1;
//        ProAsmcomppath              asm_comp_path1{};
//        ProParameter				pDesc1;
//        ProParamvalue				pvDesc1;
//        ProName						name1;
//        ComponentData_IRF2D04_002	CompData1{};
//        char			            desc1[PRO_PATH_SIZE];
//        char                        NotFound1[30] = { "Description not found." };
//
//        status = ProSelectionCopy(surfSels_F2D04_002_2[i], &CompData1.Surf_Sel);
//        ruleLog.Write("ProSelectionCopy: " + to_string(status));
//
//        status = ProSelectionModelitemGet(surfSels_F2D04_002_2[i], &Selection_model_item1);
//        ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));
//
//        status = ProMdlMdlnameGet(Selection_model_item1.owner, name1);
//        ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
//
//        status = ProMdlToModelitem(Selection_model_item1.owner, &parent_model_item1);
//        ruleLog.Write("ProMdlToModelitem: " + to_string(status));
//
//        status = ProParameterInit(&parent_model_item1, L"DESCRIPTION", &pDesc1);
//        ruleLog.Write("ProParameterInit: " + to_string(status));
//
//        status = ProParameterValueWithUnitsGet(&pDesc1, &pvDesc1, NULL);
//        ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));
//
//        status = ProSelectionAsmcomppathGet(surfSels_F2D04_002_2[i], &asm_comp_path1);
//        ruleLog.Write("ProSelectionAsmcomppathGet: " + to_string(status));
//        for (int k = 0; k < asm_comp_path1.table_num; ++k)
//            lastCompID1 = asm_comp_path1.comp_id_table[k];
//
//        ProWstringToString(CompData1.name, name1);
//        ProWstringToString(desc1, pvDesc1.value.s_val);
//        ruleLog.Write("desc: " + string(desc1));
//        (is_alphanumeric_and_space_IRF2D04_002(desc1) ? strcpy(CompData1.desc, desc1) : strcpy(CompData1.desc, NotFound1));
//
//        CompData1.Mdl_id = lastCompID1;
//        CompData1.Surf_id = Selection_model_item1.id;
//        ComponentData_IRF2D04_002_array2.push_back(CompData1);
//        ruleLog.Write("CompArray_F2D04_002[i].name: " + string(ComponentData_IRF2D04_002_array2[i].name) + "\tCompArray_F2D04_002[i].desc: " + string(ComponentData_IRF2D04_002_array2[i].desc) + "\tCompArray_F2D04_002[i].id: " + to_string(ComponentData_IRF2D04_002_array2[i].Mdl_id) + "\tCompArray_F2D04_002[i].Surf_id: " + to_string(ComponentData_IRF2D04_002_array2[i].Surf_id));
//    }
//
//    status = ProUIDialogShow(DLG_IRF2D04_002);
//	return status;
//}
//
//ProError createDatumPointsusingCSYS_IR_F2D04_002(Pro3dPnt pnt_arr[2], char* csysName)
//{
//    ruleLog.Write("----------------------------- createDatumPointsusingCSYS_IR_F2D04_002 -----------------------------");
//
//    wchar_t wCsysName[PRO_PATH_SIZE]{};
//    ProStringToWstring(wCsysName, csysName);
//    ProModelitem refCsysitem{};
//    status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
//    ruleLog.Write("ProModelitemByNameInit: " + to_string(status));
//
//    ProSelection refCsysSel{};
//    status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);
//    ruleLog.Write("ProSelectionAlloc: " + to_string(status));
//
//    ProElement	elem_tree{};
//    status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    ProElement	elem_ftype{};
//    status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
//    ruleLog.Write("ProElementIntegerSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement	elem_feature_name{};
//    status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    wchar_t wDatumPointName[PRO_PATH_SIZE]{};
//    status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, "Dist_highlght_pnt"));
//    ruleLog.Write("ProElementWstringSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement	pro_e_dpoint_type{};
//    status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
//    ruleLog.Write("ProElementIntegerSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement pro_e_dpoint_ofst_csys_type{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
//    ruleLog.Write("ProElementIntegerSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement	pro_e_dpoint_ofst_csys_ref{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    ProReference REPDEP_ref1{};
//    status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
//    ruleLog.Write("ProSelectionToReference: " + to_string(status));
//
//    status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
//    ruleLog.Write("ProElementReferenceSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement	pro_e_dpoint_ofst_csys_with_dims{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
//    ruleLog.Write("ProElementIntegerSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement	pro_e_dpoint_ofst_csys_pnts_array{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement	pro_e_dpoint_ofst_csys_pnt_1{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement	pro_e_dpoint_ofst_csys_pnt_name_1{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    wchar_t wide_string[PRO_NAME_SIZE]{};
//    ProStringToWstring(wide_string, "datum_PNT1");
//    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
//    ruleLog.Write("ProElementWstringSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement	pro_e_dpoint_ofst_csys_dir1_val_1{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
//    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));
//
//    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
//    ruleLog.Write("ProElementDoubleSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement pro_e_dpoint_ofst_csys_dir2_val_1{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
//    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));
//
//    double d1 = -pnt_arr[0][2];
//    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
//    ruleLog.Write("ProElementDoubleSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement	pro_e_dpoint_ofst_csys_dir3_val_1{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
//    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));
//
//    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
//    ruleLog.Write("ProElementDoubleSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement	pro_e_dpoint_ofst_csys_pnt_2{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement pro_e_dpoint_ofst_csys_pnt_name_2{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    wchar_t wide_string_2[PRO_PATH_SIZE]{};
//    ProStringToWstring(wide_string_2, "datum_PNT2");
//    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
//    ruleLog.Write("ProElementWstringSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement	pro_e_dpoint_ofst_csys_dir1_val_2{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
//    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));
//
//    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
//    ruleLog.Write("ProElementDoubleSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement	pro_e_dpoint_ofst_csys_dir2_val_2{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
//    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));
//
//    double d2 = -pnt_arr[1][2];
//    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
//    ruleLog.Write("ProElementDoubleSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProElement pro_e_dpoint_ofst_csys_dir3_val_2{};
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
//    ruleLog.Write("ProElementAlloc: " + to_string(status));
//
//    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
//    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));
//
//    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
//    ruleLog.Write("ProElementDoubleSet: " + to_string(status));
//
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);
//    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));
//
//    ProSelection reqMdlSel{};
//    status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
//    ruleLog.Write("ProSelectionAlloc: " + to_string(status));
//
//    ProFeatureCreateOptions* opts = 0;
//    status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
//    ruleLog.Write("ProArrayAlloc: " + to_string(status));
//
//    ProFeature pnt_feat{};
//    opts[0] = PRO_FEAT_CR_NO_OPTS;
//    ProErrorlist errors{};
//    status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
//    ruleLog.Write("ProFeatureWithoptionsCreate: " + to_string(status));
//
//    status = ProArrayFree((ProArray*)&opts);
//    ruleLog.Write("ProArrayFree: " + to_string(status));
//
//    status = ProElementFree(&elem_tree);
//    ruleLog.Write("ProElementFree: " + to_string(status));
//
//    status = ProSelectionFree(&reqMdlSel);
//    ruleLog.Write("ProSelectionFree: " + to_string(status));
//
//    ProSelection pnt_Sel{};
//    status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
//    ruleLog.Write("ProSelectionAlloc: " + to_string(status));
//
//    status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_SS_FAILED_ITEMS);
//    ruleLog.Write("ProSelectionHighlight: " + to_string(status));
//
//    return PRO_TK_NO_ERROR;
//}
//
//ProError deleteDatumPointCreatedUsingCsys_IR_F2D04_002(char* dtmpoint_name)
//{
//    ruleLog.Write("----------------------------- deleteDatumPointCreatedUsingCsys_IR_F2D04_002 -----------------------------");
//
//    ProIdTable idtbl1{};
//    ProAsmcomppath path{};
//    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path);
//    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
//
//    wchar_t wdatum_pt[PRO_PATH_SIZE]{};
//    ProStringToWstring(wdatum_pt, dtmpoint_name);
//    ProModelitem mdl_item{};
//    status = ProModelitemByNameInit(curMdl, PRO_POINT, wdatum_pt, &mdl_item);
//    ruleLog.Write("ProModelitemByNameInit: " + to_string(status));
//
//    if (status == PRO_TK_NO_ERROR) {
//
//        int* feat_ids = NULL;
//        status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
//        ruleLog.Write("ProArrayAlloc: " + to_string(status));
//
//        ProFeature feat{};
//        status = ProGeomitemFeatureGet((ProGeomitem*)&mdl_item, &feat);
//        ruleLog.Write("ProGeomitemFeatureGet: " + to_string(status));
//        feat_ids[0] = feat.id;
//
//        ProFeatureDeleteOptions* delete_opts = 0;
//        status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
//        ruleLog.Write("ProArrayAlloc: " + to_string(status));
//
//        delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;
//        status = ProFeatureWithoptionsDelete((ProSolid)curMdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
//        ruleLog.Write("ProFeatureWithoptionsDelete: " + to_string(status));
//
//        status = ProArrayFree((ProArray*)&delete_opts);
//        ruleLog.Write("ProArrayFree: " + to_string(status));
//
//        status = ProArrayFree((ProArray*)&feat_ids);
//        ruleLog.Write("ProArrayFree: " + to_string(status));
//    }
//
//    return PRO_TK_NO_ERROR;
//}
#pragma pop

