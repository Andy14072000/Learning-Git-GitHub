/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	|	V1_0_0		| F1E08 - CHASSIS CONTROLS RULES
==================================================================================================================*/
#include "F1E08.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF1E08007		| Atharva Patil		| MF1E08; MF1E01	| Clearance of 50-70mm should be maintained between brake pedal and accelerator pedal assembly
===================================================================================================================*/
#define DLG_IRF1E08_007 "dlg_IR_F1E08_007"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"

//Declare the variables for visiting and creatinng ID table of each comp
Asm_model					models_f1e08[1000];
int							models_cnt_f1e08;
Asm_model					Asm_models_f1e08[1000];
int							Assy_models_cnt_f1e08;
int							num_of_assy_fixed_f1e08 = 0;
int							model_count_f1e08;
vector<feat_id_data>		feat_id_data_arr_f1e08;
int							level_f1e08;
int							owner_feat_id_f1e08;

int IRF1E08::IRF1E08_007(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF1E08::IRF1E08_007   ==========================");

	deleteDatumPoint("datum_PNT1");
	deleteDatumPoint("datum_PNT2");

	//ruleLog.Write("size of reqComps: " + to_string(sizeof(_reqComps)));

	double clearance_value;
	double minClearance = 50.0, maxClearance = 70.0;

	ruleLog.Write(" subModulesList.size : " + to_string(subModulesList.size()));

	string reqCompSubMod[2] = { "F1E01", "F1E08" };
	vector<ComponentIdTableData>		_reqComps(sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]));

	string target{};
	for (int i = 0; i < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++i)
	{
		target = reqCompSubMod[i];
		ruleLog.Write("target comp: " + target);
		for (int j = 0; j < subModulesList.size(); ++j)
		{
			ruleLog.Write("submodule name being visited: " + subModulesList[j].name);
			if (subModulesList[j].name.find(target) != string::npos)
			{
				ruleLog.Write("match found for: " + subModulesList[j].name);
				strcpy(_reqComps[i].name, subModulesList[j].name.c_str());
			}

		}
	}
	/*char cPlaneName;
	status = ProSolidFeatVisit((ProSolid)curMdl, (ProFeatureVisitAction)csysVisitAction, NULL, &cPlaneName);
	ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
	ruleLog.Write("CSYS name: " + cPlaneName);
	return 0;*/

	//Visit the features of opened submodule
	FILE* fp{};
	level_f1e08 = 1;

	num_of_assy_fixed_f1e08 = 0;

	models_f1e08[0].Model = curMdl;
	models_f1e08[0].Model_feat_id = 0;
	models_cnt_f1e08 = 1;
	Assy_models_cnt_f1e08 = 0;

begin:

	for (int a = 0; a < models_cnt_f1e08; ++a)
	{
		owner_feat_id_f1e08 = models_f1e08[a].Model_feat_id;
		status = ProSolidFeatVisit((ProSolid)models_f1e08[a].Model, (ProFeatureVisitAction)visitAction_F1E08, compsFilter, &_reqComps);
		ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
	}

	if (Assy_models_cnt_f1e08 > 0)
	{
		++level_f1e08;
		for (int b = 0; b < Assy_models_cnt_f1e08; ++b)
		{
			models_f1e08[b].Model = Asm_models_f1e08[b].Model;
			models_f1e08[b].Model_feat_id = Asm_models_f1e08[b].Model_feat_id;
		}
		models_cnt_f1e08 = Assy_models_cnt_f1e08;
		Assy_models_cnt_f1e08 = 0;
		goto begin;
	}

	for (auto elem : _reqComps) {
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.compIdTab[elem.tableNum - 1]));
	}

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_IRF1E08_007, DLG_IRF1E08_007);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF1E08_007, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF1E08_007, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF1E08_007, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF1E08_007, &dlg_sts);
	status = ProUIDialogDestroy(DLG_IRF1E08_007);
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Attention!!", "It may take a moment to measure the clearance between two components.");


	/*ProUIMessageButton btn_choice = UserDisplayPopupMessage_OK_CANCEL(PROUIMESSAGE_INFO, "Confirmation", "Click OK to run the rule.\n\nThis may take a moment to compute distances between the components.");
	if(btn_choice == PRO_UI_MESSAGE_CANCEL)
		return -1;*/

		//UserCsysAppData	app_data;

		/*status = ProSolidCsysVisit((ProSolid)curMdl,(ProCsysVisitAction)CsysFindVisitAction,(ProCsysFilterAction)CsysFindFilterAction,(ProAppData)&app_data);*/

	Pro3dPnt pntArr[2];
	rule_sts = measureNearestDistanceBetweenComponents(_reqComps[0], _reqComps[1], clearance_value);

	clearance_value = round(clearance_value * 100) / 100;

	// DECLARE RESULT
	sprintf(remark, "Measured values = %.2lf mm; Acceptance criteria: %.2lf-%.2lf mm.", clearance_value, minClearance, maxClearance);
	final_res.remark = string(remark);

	if (clearance_value >= minClearance && clearance_value <= maxClearance)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	status = ProUIDialogDestroy(DLG_IRF1E08_007);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	return 0;
}

ProError csysVisitAction(ProFeature* p_feature, ProError status, char* cPlaneName[PRO_NAME_SIZE])
{
	ProFeattype feat_type;
	wchar_t wPlaneName[PRO_NAME_SIZE];

	status = ProFeatureTypeGet(p_feature, &feat_type);
	ruleLog.Write("ProFeatureTypeGet status: " + to_string(status));
	ruleLog.Write("ProFeatureType: " + to_string(feat_type));

	if (feat_type == PRO_FEAT_CSYS)
	{
		status = ProModelitemNameGet((ProModelitem*)p_feature, wPlaneName);
		ruleLog.Write("ProModelitemNameGet" + to_string(status));
		ProWstringToString(*cPlaneName, wPlaneName);
		ruleLog.Write("Name of the feature is: " + (string)*cPlaneName);
	}


	return PRO_TK_NO_ERROR;
}

ProError visitAction_F1E08(ProFeature* p_feature, ProError status, vector<ComponentIdTableData>* _reqComps)
{
	ruleLog.Write("====================== visitAction_F1E08 =========================");
	ProMdlfileType			comp_type;
	ProFamilyMdlName		comp_name;
	char					part_no[PRO_PATH_SIZE];
	ProAsmcompconstraint* constr_array;
	ProMdl					model;
	ProFeattype				ftype;
	ProAsmcompconstraint	constraint;
	ProAsmcompconstraint* constraints;
	ProPatternStatus 		p_pattern_status;
	ProFeatStatus 			p_status;




	status = ProFeatureTypeGet(p_feature, &ftype);
	ruleLog.Write("ProFeatureTypeGet status: " + to_string(status));

	if (ftype == PRO_FEAT_COMPONENT)
	{
		ruleLog.Write("Component Level = " + to_string(level_f1e08));
		status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
		ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));
		ProWstringToString(part_no, comp_name);
		ruleLog.Write("Part name: " + (string)part_no);
		++model_count_f1e08;

		feat_id_data  _feat_id_data;

		if (level_f1e08 == 1) {
			ruleLog.Write("inside if loop level_f1e08 ==1 ");
			_feat_id_data.feat_ids[0] = p_feature->id;
			_feat_id_data.level = level_f1e08;

			feat_id_data_arr_f1e08.push_back(_feat_id_data);

		}
		else
		{
			for (int j = 0; j < feat_id_data_arr_f1e08.size(); ++j)
			{
				if (feat_id_data_arr_f1e08[j].feat_ids[level_f1e08 - 2] == owner_feat_id_f1e08)
				{
					feat_id_data owner_feat_id_data = feat_id_data_arr_f1e08[j];
					for (int i = 0; i < level_f1e08 - 1; ++i)
					{
						_feat_id_data.feat_ids[i] = owner_feat_id_data.feat_ids[i];
					}

					_feat_id_data.feat_ids[level_f1e08 - 1] = p_feature->id;
					_feat_id_data.level = level_f1e08;

					break;
				}

			}

			feat_id_data_arr_f1e08.push_back(_feat_id_data);
		}

		ProMdl reqMdl;
		ProMdlType reqMdlType;
		wchar_t wMdlName[PRO_NAME_SIZE];
		char cMdlName[PRO_NAME_SIZE];

		status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
		ruleLog.Write("ProAsmcompMdlGet status: " + to_string(status));

		if (status == PRO_TK_NO_ERROR)
		{
			status = ProMdlNameGet(reqMdl, wMdlName);
			ruleLog.Write("ProMdlNameGet status: " + to_string(status));
			ProWstringToString(cMdlName, wMdlName);
			ruleLog.Write("cMdlName: " + (string)cMdlName);

			ruleLog.Write("reqs_size: " + to_string(_reqComps->size()));
			for (int i = 0; i < _reqComps->size(); ++i)
			{
				/*ruleLog.Write("running for: " + to_string(i) + "th time");*/
				ruleLog.Write("reqs[" + to_string(i) + "].name: " + _reqComps->at(i).name);
				if (strcmp(cMdlName, _reqComps->at(i).name) == 0)
				{
					//Creating ID table for coupling flange
					ProIdTable			comp_id_table;
					int					table_num;
					ProAsmcomppath		p_comp_path;
					table_num = level_f1e08;
					_reqComps->at(i).tableNum = table_num;
					ruleLog.Write("the table num is: " + to_string(table_num));

					for (int m = 0; m < level_f1e08; ++m) {

						_reqComps->at(i).compIdTab[m] = _feat_id_data.feat_ids[m];
						ruleLog.Write("comp_ID-Table " + to_string(m) + ": " + to_string(_reqComps->at(i).compIdTab[m]));
					}
				}
			}
		}


		if (reqMdlType == PRO_MDL_ASSEMBLY)
		{
			Asm_models_f1e08[Assy_models_cnt_f1e08].Model = model;
			Asm_models_f1e08[Assy_models_cnt_f1e08].Model_feat_id = p_feature->id;
			Assy_models_cnt_f1e08 += 1;
		}
	}

	return PRO_TK_NO_ERROR;
}

int measureNearestDistanceBetweenComponents(ComponentIdTableData reqComp1, ComponentIdTableData reqComp2, double& distance)
{
	ruleLog.Write("=================> measureNearestDistanceBetweenComponents <=================");

	ProSelection sels[2];
	InterfaceRule iRule;
	ProName comp1_name, comp2_name;
	ProModelitem feature[2];
	ProMdl reqMdls[2];

	ProStringToWstring(comp1_name, reqComp1.name);
	//ruleLog.Write("comp1_name: " + (string)reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProStringToWstring(comp2_name, reqComp2.name);
	//ruleLog.Write("comp1_name: " + (string)reqComp2.name);
	status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[1], &feature[1]);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProAsmcomppath path[2];
	status = ProAsmcomppathInit((ProSolid)curMdl, reqComp1.compIdTab, reqComp1.tableNum, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
	status = ProAsmcomppathInit((ProSolid)curMdl, reqComp2.compIdTab, reqComp2.tableNum, &path[1]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));
	status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	ProBoolean is_interference_found;
	Pro3dPnt pnt_arr[2];
	Pro2dPnt param_surfs1, param_surfs2;
	//Pro3dPnt pnt_surfs1, pnt_surfs2;
	status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_FROM_QUILTS, sels[1], PRO_FIT_INCLUDE_TO_QUILTS, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));

	iRule.createDatumPoints(pnt_arr, "CSYS_ASM_DEF", "CLEARANCE_HIGHLITE_PNT");
	ruleLog.Write("createDatumPoints status");

	return 0;
}

#pragma pop
