/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-03-2023	|	V1_0_0		| F5B01 - WHEELS AND TYRES RULES
==================================================================================================================*/
#include "F5B01.h"


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5B01001		| MATHANPRASATH A	| MF5B01; MF5A15 	| Clearance between grown front tire/wheel rim and tie rod ball 
														  joint should be minimum 10 **mm in both steering lock positions for all the Platforms.
===================================================================================================================*/

#define DLG_IRF5B01_001		"dlg_IR_F5B01_001"
#define PB_RCANCEL			"CommitCancel"
#define PB_ROK				"CommitOK"
#define PB_RSELECT			"select_pb"

ProSelection*		prt_surf;
string				sel_ref1, sel_ref2;


int IRF5B01::IRF5B01_001(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5B01::IRF5B01_001   ==========================");
	SubModuleInfo _reqSMinfo;
	sel_ref1.clear();
	sel_ref2.clear();
	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF5B01_001, DLG_IRF5B01_001);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF5B01_001, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5B01_001, PB_RSELECT, (ProUIAction)select_IRF5B01_001, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5B01_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5B01_001, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF5B01_001, &dlg_sts);
	status = ProUIDialogDestroy(DLG_IRF5B01_001);
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	// get the submodule name from list
	for (int i = 0; i < subModulesList.size(); ++i)
	{
		if (subModulesList[i].name.find("F5B01") != string::npos)
		{
			_reqSMinfo = subModulesList[i];
			break;
		}
	}

	//get the project code of opened submodule
	project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
	string projectC_str = to_string(project_code);
	ruleLog.Write("project code: " + to_string(project_code));

	vector<vector<string>> dbList2D = getData2D("IRF5B01001.csv");
	vector<string> project_Codes;
	bool isProjectCodeFound = false;
	for (int i = 1; i < dbList2D.size(); ++i)   // i = 1 for skipping the headers
	{
		string tok1, tok2;
		std::istringstream ss1(dbList2D[i][1]);
		while (std::getline(ss1, tok1, ';'))
		{
			ruleLog.Write("project code from CSV:" + tok1);
			//storing list of project codes from db
			project_Codes.push_back(tok1);
		}

	}
	ruleLog.Write("projectCodes.size(): " + to_string(project_Codes.size()));

	//check whether the project code is available or not in db ( Defence vehicle)
	for (int i = 0; i < project_Codes.size(); i++) {
		if ((projectC_str.compare(project_Codes.at(i))) == 0) {
			isProjectCodeFound = true;
			break;
		}
	}
	double clearance_value, std_clearance;
	if (isProjectCodeFound)
	{
		//Defence vehicle 
		std_clearance = 50.0;

	}
	else
	{
		//other platforms
		std_clearance = 10.0;
	}

	Pro2dPnt param_1, param_2;
	Pro3dPnt pnt_1, pnt_2;
	double distance;
	status = ProSelectionWithOptionsDistanceEval(prt_surf[0], PRO_B_TRUE, prt_surf[1], PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(distance));
	string act_clrnce;
	act_clrnce.append(doubleToString(distance));
	string std = doubleToString(std_clearance);
	//double Cr = 10;
	string r_msg;
	r_msg += "Measured Value:\nClearance between tie rod ball joint and wheel rim is ";
	if (distance >= std_clearance)
	{

		r_msg += act_clrnce + " mm.\n";
		r_msg += "Selection Refrence:\n";
		r_msg += "1. " + sel_ref1 + "2. " + sel_ref2;
		final_res.result = "PASS";
		ruleLog.Write("Standard Clearance :" + to_string(std_clearance));
		sprintf(remark, "\nAcceptance criteria:\nThe Standard clearance between tie rod ball joint and wheel rim is 10mm for All Platforms and 50mm for Defence Platform.");
		final_res.remark = r_msg + remark;


	}
	else
	{
		r_msg += act_clrnce + " mm.\n";
		r_msg += sel_ref1;
		r_msg += "1. " + sel_ref1 + "2. " + sel_ref2;
		final_res.result = "FAIL";
		sprintf(remark, "\nAcceptance criteria:\nThe Standard clearance between tie rod ball joint and wheel rim is 10mm for All Platforms and 50mm for Defence Platform.");
		final_res.remark = r_msg + remark;
	}
	return 0;
}

ProError select_IRF5B01_001(char* dialog, char* component, ProAppData data)
{
	int n_prt_surf{};
	char* option = (char*)"part";

	ProModelitem partitem1, surfietm2;
	ProFeature part_featid1, surf_featid2;
	ProMdl part_mdlmdl1, surf_mdlmdl2;
	wchar_t wpartmdlName1[PRO_NAME_SIZE];
	char cpartmdlName1[PRO_NAME_SIZE];
	wchar_t wsurfmdlName2[PRO_NAME_SIZE];
	char csurfmdlName2[PRO_NAME_SIZE];
	int id1, id2;
	ProAsmcomppath part_1{}, part_2{};

	status = ProSelect((char*)"part", 2, NULL, NULL, NULL, NULL, &prt_surf, &n_prt_surf);
	ruleLog.Write("ProSelect :" + to_string(status));

	InterfaceRule _irule;

	if (status == PRO_TK_USER_ABORT)
	{
		//_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}
	else if (n_prt_surf < 2 || status != PRO_TK_NO_ERROR)
	{
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}


	string name1;
	string name2;
	if (status == 0)
	{

		status = ProSelectionAsmcomppathGet(prt_surf[0], &part_1);
		status = ProSelectionAsmcomppathGet(prt_surf[1], &part_2);

		status = ProSelectionModelitemGet(prt_surf[0], &partitem1);
		status = ProSelectionModelitemGet(prt_surf[1], &surfietm2);


		/*status = ProGeomitemFeatureGet(&partitem1, &part_featid1);
		ruleLog.Write("ProGeomitemFeatureGet :" + to_string(status));*/

		for (int i = 0; i < part_1.table_num; ++i)
		{
			ruleLog.Write("Part id1:" + to_string(part_1.comp_id_table[i]));
		}
		ruleLog.Write("Part_1 id:" + to_string(part_1.comp_id_table[part_1.table_num - 1]));
		ruleLog.Write("Part_2 id:" + to_string(part_2.comp_id_table[part_2.table_num - 1]));

		status = ProMdlMdlnameGet(partitem1.owner, wpartmdlName1);
		ProWstringToString(cpartmdlName1, wpartmdlName1);
		name1 = string(cpartmdlName1);
		ruleLog.Write("Part Name_1 :" + string(cpartmdlName1) + ".PRT");
		status = ProMdlMdlnameGet(surfietm2.owner, wsurfmdlName2);
		ProWstringToString(csurfmdlName2, wsurfmdlName2);
		name2 = string(csurfmdlName2);
		ruleLog.Write("Part Name_2 :" + string(csurfmdlName2) + ".PRT");
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	}

	sel_ref1 += name1 + ".PRT" + "(";
	sel_ref1 += to_string(part_1.comp_id_table[part_1.table_num - 1]) + ") ";
	sel_ref2 += name2 + ".PRT" + "(";
	sel_ref2 += to_string(part_2.comp_id_table[part_2.table_num - 1]) + ")\n";
	return PRO_TK_NO_ERROR;
}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5B01002		| VINAY NEEL		| MF5B01; MF5A15 	| Clearance between of grown tire/wheel rim and brake chamber should be minimum 20**mm.
===================================================================================================================*/
#define DLG_IRF5B01_002 "dlg_IR_F5B01_002"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"

int IRF5B01::IRF5B01_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5B01::IRF5B01_002   ==========================");

	ComponentData _reqComps[2]{};
	string reqCompSubMod[2] = { "F5B01","F5A15" };
	double clearance_value, std_clearance;
	Pro3dPnt pnt_arr[2];

	for (int i = 0; i < subModulesList.size(); ++i)
		for (int j = 0; j < 2; ++j)
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
				strcpy(_reqComps[j].name, subModulesList[i].name.c_str());

	project_code = stoi(string(_reqComps[0].name).substr(0, 4));
	string projectC_str = to_string(project_code);

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
	ruleLog.Write("projectC_str = " + projectC_str);

	for (auto elem : _reqComps) {
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}

	bool isProjectCodeFound = false;
	vector<string> project_Codes;
	vector<vector<string>> dbList2D = getData2D("IRF5B01002.csv");

	for (int i = 1; i < dbList2D.size(); ++i)	// i = 1 for skipping the headers
	{
		string tok1, tok2;
		std::istringstream ss1(dbList2D[i][1]);
		while (std::getline(ss1, tok1, ';'))
		{
			ruleLog.Write("project code from CSV:" + tok1);
			//storing list of project codes from db
			project_Codes.push_back(tok1);
		}

	}
	ruleLog.Write("projectCodes.size(): " + to_string(project_Codes.size()));

	//check whether the project code is available or not in db ( Defence vehicle)
	for (int i = 0; i < project_Codes.size(); i++) {
		if ((projectC_str.compare(project_Codes.at(i))) == 0) {
			isProjectCodeFound = true;
			break;
		}
	}

	if (isProjectCodeFound)
	{
		//Defence vehicle 
		std_clearance = 60.0;
	}
	else
	{
		//other platforms
		std_clearance = 20.0;
	}


	isUserQuits = false;

	status = ProUIDialogCreate(DLG_IRF5B01_002, DLG_IRF5B01_002);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF5B01_002, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5B01_002, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5B01_002, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF5B01_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF5B01_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	deleteDatumPoint("datum_PNT1");
	deleteDatumPoint("datum_PNT2");

	if (isUserQuits)
		return -1;

	rule_sts = measureDistanceBetweenComponents(_reqComps[0], _reqComps[1], clearance_value, pnt_arr);
	createDatumPoints(pnt_arr, "CSYS_ASM_DEF", "Dist_highlght_pnt");
	clearance_value = round(clearance_value * 100) / 100;


	// DECLARE RESULT
	sprintf(remark, "Result:\nClearance between %s.ASM (Tyre and Wheel rim) and %s.ASM (Brake chamber) is %.2lf mm;\nAcceptance criteria: \nClearance between grown tyre and brake chamber should be at least 20.00 mm for all platforms and 60.00 mm for defence.", _reqComps[0].name, _reqComps[1].name, clearance_value);
	final_res.remark = string(remark);

	if (clearance_value > std_clearance || clearance_value == std_clearance)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);
	ruleLog.Write("std_clearance: " + to_string(std_clearance));

	return 0;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES					| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5B01006		| ATHARVA PATIL		| MF5B01; MF4A01; MF4A02; MF4A03; 	| Lateral clearance between grown tire and component immediately 
									  MF4B01; MF4B02; MF4B03			  nearest to grown tire (usually U-bolt of Suspension) should be minimum 40**mm.
===================================================================================================================*/

#define DLG_IRF5B01_006 "dlg_IR_F5B01_006"
#define PB_ROK			"CommitOK"
#define PB_RCANCEL		"CommitCancel"
#define PB_Select		"Select1"

vector<clearanceData>		clearanceVec;
int							selectButton = 0;
ProSelection* selectionParts;
vector<ownerInfo>			selInfo;
vector<string>				prtDesc;

int IRF5B01::IRF5B01_006(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5B01::IRF5B01_006   ==========================");

	InterfaceRule		iRule;
	string				rmMsgTyre;

	selectButton = 0;
	rmMsgTyre.erase();
	clearanceVec.clear();
	ProWindowRepaint(PRO_VALUE_UNUSED);
	isUserQuits = false;

	status = ProUIDialogCreate(DLG_IRF5B01_006, DLG_IRF5B01_006);
	ruleLog.Write("ProUIDialogCreate status: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRF5B01_006, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5B01_006, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5B01_006, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5B01_006, PB_Select, (ProUIAction)selectActionF5B01_006, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));

	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogHide status: " + to_string(status));
	status = ProUIPushbuttonDisable(DLG_IRF5B01_006, PB_ROK);
	ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));
	status = ProUIDialogActivate(DLG_IRF5B01_006, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_IRF5B01_006);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);

		return -1;
	}

	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	ruleLog.Write("size of vector: " + to_string(clearanceVec.size()));
	sort(clearanceVec.begin(), clearanceVec.end(), [](const clearanceData& a, const clearanceData& b) {
		return a.clearance < b.clearance;
		});

	ruleLog.Write("sort check");
	rmMsgTyre += "Minimum clearance measured = " + (clearanceVec[0].clea) + " mm.\nAcceptance Criteria: >= 40.00 mm";

	rmMsgTyre += "\n\nReferences selected-\n";



	for (int i = 0; i < clearanceVec.size(); i++)
	{
		rmMsgTyre += to_string(i + 1) + ")" + (string)clearanceVec[i].nameOfSel1 + ".PRT <surf ID: " + to_string(clearanceVec[i].id1) + "> (" + clearanceVec[i].desc1 + ") and "
			+ (string)clearanceVec[i].nameOfSel2 + ".PRT <surf ID: " + to_string(clearanceVec[i].id2) + "> (" + clearanceVec[i].desc2 + ") = " + clearanceVec[i].clea + " mm.\n";

		/*char pointName[PRO_NAME_SIZE] = "CLEARANCE_HIGHLITE_PNT";
		strcat(pointName, to_string(i + 1).c_str());
		createDatumPointsF5B01_006(clearanceVec[i].pntArr, pointName, "CSYS_ASM_DEF");*/
	}


	for (int i = 0; i < clearanceVec.size(); i++)
	{
		if ((round(clearanceVec[i].clearance) < 40.00))
		{
			status = ProSelectionHighlight(clearanceVec[i].sel1, PRO_COLOR_ERROR);
			status = ProSelectionHighlight(clearanceVec[i].sel2, PRO_COLOR_ERROR);
		}
	}

	//Declare results
	for (int i = 0; i < clearanceVec.size(); i++)
	{
		if ((round(clearanceVec[i].clearance) >= 40.00))
		{
			final_res.result = "PASS";
		}
		else
		{
			final_res.result = "FAIL";
			break;
		}
	}



	final_res.remark = rmMsgTyre;


	status = ProUIDialogDestroy(DLG_IRF5B01_006);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);


	return 0;
}

ProError selectActionF5B01_006(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("==========================   selectActionF5B01_006   ==========================");

	InterfaceRule			_irule;
	int						selsCount;
	clearanceData			obj;
	ProModelitem			selItem, partItem;
	wchar_t					wName[PRO_NAME_SIZE];
	char					cDesc[PRO_NAME_SIZE], cName[PRO_NAME_SIZE];
	ProParameter            pDesc;
	ProParamvalue           pvDesc;
	ProName                 pDescName = L"DESCRIPTION";
	string					description;
	const regex				clamp("(U-CLAMP)");
	const regex				bolt("(U-BOLT)");
	const regex				tyre("(TYRE)");
	smatch					found;
	ownerInfo				item;
	string					questionMsg;


	_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Notice", "Select all the pair of U-Bolt/U-Clamp and tyre adjacent to it.");
	status = ProUIDialogHide(dialog);

Begin:
	{
		selInfo.clear();
		status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &selectionParts, &selsCount);
		ruleLog.Write("ProSelect: " + to_string(status));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIPushbuttonDisable(dialog, PB_ROK);
			status = ProUIDialogShow(dialog);
			
			return status;
		}
		if (selsCount < 2 || status != PRO_TK_NO_ERROR) {
			_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			status = ProUIPushbuttonDisable(dialog, PB_ROK);
			ProSelectionFree(selectionParts);
			
			goto Begin;
		}
		selectButton++;
		for (int i = 0; i < selsCount; i++)
		{
			status = ProSelectionModelitemGet(selectionParts[i], &selItem);
			ruleLog.Write("ProSelectionModelitemGet status: " + to_string(status));
			ruleLog.Write("id of selected surface: " + to_string(selItem.id));

			status = ProMdlMdlnameGet(selItem.owner, wName);
			ruleLog.Write("ProMdlMdlnameGet status: " + to_string(status));
			ProWstringToString(cName, wName);

			status = ProMdlToModelitem(selItem.owner, &partItem);
			ruleLog.Write("ProMdlToModelitem status: " + to_string(status));

			status = ProParameterInit(&partItem, pDescName, &pDesc);
			ruleLog.Write("ProParameterInit : " + to_string(status));

			if (status != PRO_TK_E_NOT_FOUND)
			{
				status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
				ruleLog.Write("ProParameterValueWithUnitsGet : " + to_string(status));
				ProWstringToString(cDesc, pvDesc.value.s_val);
				description.append(cDesc);

				if (regex_search(description, found, clamp) || regex_search(description, found, bolt) ||
					regex_search(description, found, tyre))
				{

					ruleLog.Write("desription of selected part: " + description);
					ruleLog.Write("matchFound: " + found.str());
					ruleLog.Write("name of selected part: " + (string)cName);
					prtDesc.push_back(found.str());
					item.id = selItem.id;
					strcpy(item.name, cName);
					selInfo.push_back(item);
					description.erase();
					//idVec.push_back(selItem.id);
				}
				else
				{
					_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Attention!!", "Invalid Selection. Please select surfaces from the TYRE and U-BOLT/ U-BOLT only");
					description.erase();
					selInfo.clear();
					prtDesc.clear();
					
					selectButton--;
					ProSelectionFree(selectionParts);
					selectButton--;
					goto Begin;
				}
			}
		}

		ProBoolean is_interference_found;
		Pro3dPnt pnt_arr[2];
		Pro3dPnt pnt_arr1[2];
		Pro2dPnt param_surfs[2];
		double clearance;
		double pntCreationClearance;

		status = ProSelectionWithOptionsDistanceEval(selectionParts[0], PRO_B_TRUE, selectionParts[1], PRO_B_TRUE, param_surfs[0], param_surfs[1], pnt_arr1[0], pnt_arr1[1], &clearance);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(clearance));
		ruleLog.Write("Coordinates from PSWODE: " + to_string(pnt_arr1[0][0]) + ", " + to_string(pnt_arr1[0][1]) + ", " + to_string(pnt_arr1[0][2]) + ", " + to_string(pnt_arr1[1][0]) + ", " + to_string(pnt_arr1[1][1]) + ", " + to_string(pnt_arr1[1][2]));
		status = ProFitClearanceCompute(selectionParts[0], PRO_FIT_INCLUDE_NONE, selectionParts[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &pntCreationClearance, NULL, &is_interference_found, pnt_arr);
		ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(pntCreationClearance));
		ruleLog.Write("Coordinates from PFCC: " + to_string(pnt_arr[0][0]) + ", " + to_string(pnt_arr[0][1]) + ", " + to_string(pnt_arr[0][2]) + ", " + to_string(pnt_arr[1][0]) + ", " + to_string(pnt_arr[1][1]) + ", " + to_string(pnt_arr[1][2]));

		if (clearance > 0)
		{
			ruleLog.Write("if loop check");
			/*obj.pntArr[0][0] = pnt_arr[0][0];
			obj.pntArr[0][1] = pnt_arr[0][1];
			obj.pntArr[0][2] = pnt_arr[0][2];
			obj.pntArr[1][0] = pnt_arr[1][0];
			obj.pntArr[1][1] = pnt_arr[1][1];
			obj.pntArr[1][2] = pnt_arr[0][2]; */        //Assigned z-Coord of pnt 1 for creating 2nd point at same height in z direction 

			obj.clearance = clearance;
			obj.clea = to_string(round(clearance));
			obj.clea.erase(obj.clea.find_last_not_of('0') + 3);
			ruleLog.Write("clearance check");
			strcpy(obj.nameOfSel1, selInfo[0].name);
			strcpy(obj.nameOfSel2, selInfo[1].name);
			obj.id1 = selInfo[0].id;
			obj.id2 = selInfo[1].id;
			obj.desc1 = prtDesc[0];
			obj.desc2 = prtDesc[1];
			ProSelectionCopy(selectionParts[0], &obj.sel1);
			ProSelectionCopy(selectionParts[1], &obj.sel2);
			ruleLog.Write("selection stored check");


			ruleLog.Write("pushing back for clearance: " + to_string(obj.clearance));
			clearanceVec.push_back(obj);
		}


		ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
		msg_buttons[0] = PRO_UI_MESSAGE_YES;
		msg_buttons[1] = PRO_UI_MESSAGE_NO;


		questionMsg += "You have selected " + to_string(selectButton) + " pair of surfaces\nDo you want to add more pairs?";
		user_choice = _irule.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation!!", questionMsg, msg_buttons);
		ruleLog.Write("UserDisplayPopupMessageUserChoice: " + to_string(user_choice));
	}
	if (user_choice == PRO_UI_MESSAGE_NO)
	{
		ruleLog.Write("inside user_choice == PRO_UI_MESSAGE_NO");
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonEnable status: " + to_string(status));
		status = ProUIDialogShow(dialog);
	}
	else
	{
		ruleLog.Write("inside user_choice == PRO_UI_MESSAGE_YES");
		questionMsg.erase();
		goto Begin;
	}

	selInfo.clear();
	prtDesc.clear();



	return PRO_TK_NO_ERROR;
}


/*==================================================================================================================
RULE ID		|  DEVELOPER			| DEPENDENT MODULES							| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5B01008	|  Himanshu Pachpute	| MF5B01; MF5A01; MF5A02; MF5A04; MF5A05	| Clearance between wheel rim with valve and brake drum/disc should be minimum 10** mm.
===================================================================================================================*/

#define DLG_IRF5B01_008		"dlg_IR_F5B01_008"
#define PB_RSELECT			"pb_select"
#define RULE_IMG			"pb_img"
#define PB_ROK				"rule_ok_pb"
#define PB_RCANCEL			"rule_cancel_pb"

class FeatIDdata01 {
public:
	int level{};
	int feat_ids[10]{};
};

class AsmModel01 {
public:
	ProMdl  Model{};
	int	    Model_feat_id{};
};

struct ThreeDPnt {
	Pro3dPnt pnt_arr1[2]{};
};

vector<compdata_IRF5B01_008>			Vec_Tyres_Rim{};
vector<compdata_IRF5B01_008>			Vec_Selection_Drum{};
vector<compdata_IRF5B01_008>			Vec_Selection_Drum_remark{};
vector<compdata_IRF5B01_008>			Vec_Selection_Disc{};
vector<ThreeDPnt>						ThreeDPnt_Vect{};
vector<FeatIDdata01>					FeatIDDataArr{};
AsmModel01								AsmCModel[1000]{};
AsmModel01								CModel[1000]{};

int ModelsCount01{};
int	AsmModelCount01{};
int	NoOfAsmFixed01{};
int MdlCount01{};
int	OwnerFeatID01{};
int Levels01{};
ProMdl Mdl001{};

vector<string>							reqCompSubMod_IR_F5B01_008{};
bool									Brake_Drum_Found{ false }, Brake_Disc_Found{ false };
vector<Clearances_class_IR_F5B01_008>	Clearance_Value_Vect{};
string									Remark_String_for_IR_F5B01_008 = "";
char									NotFound[PRO_PATH_SIZE] = { "Description not found." };

std::string formatdouble_for_IR_F5B01_008(double value) {
	ostringstream stream;
	stream << fixed << setprecision(2) << value;
	return stream.str();
}

bool is_alphanumeric_and_space_for_IR_F5B01_008(const string& str) {
	for (char c : str) {
		if (!isalnum(c) && !isspace(c) && c != '-' && c != '.' && c != 'X' && c != ',') {
			return false;
		}
	}
	return true;
}

int IRF5B01::IRF5B01_008(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5B01::IRF5B01_008   ==========================");

	isUserQuits = false;
	Brake_Drum_Found = false;
	Brake_Disc_Found = false;

	if (_utils.isSubModulePresent("F5B01") && _utils.isSubModulePresent("F5A01") && _utils.isSubModulePresent("F5A04"))
		reqCompSubMod_IR_F5B01_008.insert(reqCompSubMod_IR_F5B01_008.end(), { "MF5B01", "MF5A01", "MF5A04" });

	if (!_utils.isSubModulePresent("F5B01") || !_utils.isSubModulePresent("F5A01") || !_utils.isSubModulePresent("F5A04"))
		reqCompSubMod_IR_F5B01_008.insert(reqCompSubMod_IR_F5B01_008.end(), { "MF5B01", "MF5A01", "MF5A02", "MF5A03", "MF5A04", "MF5A05", "MF5A06" });

	status = ProUIDialogCreate(DLG_IRF5B01_008, DLG_IRF5B01_008);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));

	status = ProUIDialogAboveactivewindowSet(DLG_IRF5B01_008, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_IRF5B01_008, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_IRF5B01_008, PB_ROK, (ProUIAction)ruleDlgOKaction_for_F5B01_008, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProMdlCurrentGet(&Mdl001);
	ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

	curMdl = Mdl001;
	Levels01 = 1;
	NoOfAsmFixed01 = 0;
	CModel[0].Model = Mdl001;
	CModel[0].Model_feat_id = 0;
	ModelsCount01 = 1;
	AsmModelCount01 = 0;

	while (ModelsCount01 > 0) {
		for (int a = 0; a < ModelsCount01; ++a) {
			OwnerFeatID01 = CModel[a].Model_feat_id;
			status = ProSolidFeatVisit((ProSolid)CModel[a].Model, (ProFeatureVisitAction)PartNameAndIdVisitAction01, compsFilter, NULL);
			//ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
		}

		if (AsmModelCount01 > 0) {
			++Levels01;
			for (int b = 0; b < AsmModelCount01; ++b) {
				CModel[b].Model = AsmCModel[b].Model;
				CModel[b].Model_feat_id = AsmCModel[b].Model_feat_id;
			}
			ModelsCount01 = AsmModelCount01;
			AsmModelCount01 = 0;
		}
		else
			ModelsCount01 = 0;
	}

	if (Brake_Drum_Found == true) {
		char imgName1[PRO_NAME_SIZE];
		strcpy(imgName1, "IR-F5B01-008/Drum_Brake.png");
		status = ProUIPushbuttonBitmapSet(DLG_IRF5B01_008, RULE_IMG, imgName1);
		ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));

		status = ProUIPushbuttonActivateActionSet(DLG_IRF5B01_008, PB_RSELECT, (ProUIAction)select_action_IRF5B01_008_Drum, NULL);
		ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	}
	else if (Brake_Disc_Found == true) {
		char imgName2[PRO_NAME_SIZE];
		strcpy(imgName2, "IR-F5B01-008/Disc_Brake.png");
		status = ProUIPushbuttonBitmapSet(DLG_IRF5B01_008, RULE_IMG, imgName2);
		ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));

		status = ProUIPushbuttonActivateActionSet(DLG_IRF5B01_008, PB_RSELECT, (ProUIAction)select_action_IRF5B01_008_Disc, NULL);
		ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	}

	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogHide: " + to_string(status));

	status = ProUIDialogActivate(DLG_IRF5B01_008, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	status = ProUIDialogDestroy(DLG_IRF5B01_008);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

	status = ProUIDialogShow(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogShow: " + to_string(status));

	if (isUserQuits)
		return -1;

	if (Brake_Disc_Found == true) {
		string Disc_Remark = "";
		if (Vec_Tyres_Rim.size() == Vec_Selection_Disc.size()) {
			Disc_Remark += "Distance between \n";
			for (size_t d = 0; d < Vec_Tyres_Rim.size(); d++) {
				Clearances_class_IR_F5B01_008	Clearance_data{};
				ProBoolean						is_interference_found1;
				ThreeDPnt						pnt_arr1;
				double							clearance_value_for_Disc{};

				status = ProFitClearanceCompute(Vec_Tyres_Rim[d].compsel, PRO_FIT_INCLUDE_NONE, Vec_Selection_Disc[d].compsel, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, Vec_Tyres_Rim[d].compsel, PRO_B_FALSE, &clearance_value_for_Disc, NULL, &is_interference_found1, pnt_arr1.pnt_arr1);
				ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tDistance between " + to_string(Vec_Tyres_Rim[d].ID) + " and " + to_string(Vec_Selection_Disc[d].ID) + ": " + to_string(clearance_value_for_Disc));
				ThreeDPnt_Vect.push_back(pnt_arr1);

				string Double1 = formatdouble_for_IR_F5B01_008(clearance_value_for_Disc);
				Disc_Remark += "\t\t" + string(Vec_Tyres_Rim[d].name) + "." + string(Vec_Tyres_Rim[d].type) + " [" + string(Vec_Tyres_Rim[d].Description) + "] ["
					+ to_string(Vec_Tyres_Rim[d].ID) + "] and \n\t\t\t\t\t\t" + string(Vec_Selection_Disc[d].name) + "." + string(Vec_Selection_Disc[d].type) + " ["
					+ string(Vec_Selection_Disc[d].Description) + "] [" + to_string(Vec_Selection_Disc[d].ID) + "]: " + Double1 + " mm" + "\n\n";

				Clearance_data.clearance = clearance_value_for_Disc;
				Clearance_data.Component_selection = Vec_Selection_Disc[d].compsel;
				Clearance_Value_Vect.push_back(Clearance_data);
			}
			Remark_String_for_IR_F5B01_008 += Disc_Remark;
		}
	}

	for (size_t i = 0; i < Clearance_Value_Vect.size(); i++) {
		if (Clearance_Value_Vect[i].clearance < 3) {

			//status = createDatumPointsusingCSYS_IR_F5B01_008(ThreeDPnt_Vect[i].pnt_arr1, "CSYS_ASM_DEF");
			//ruleLog.Write("createDatumPointsusingCSYS_IR_F5B01_008: " + to_string(status));

			status = ProSelectionHighlight(Clearance_Value_Vect[i].Component_selection, PRO_COLOR_SS_FAILED_ITEMS);
			ruleLog.Write("ProSelectionHighlight: " + to_string(status));
		}
	}

	bool ResCheck = false;
	for (size_t i = 0; i < Clearance_Value_Vect.size(); i++) {
		if (Clearance_Value_Vect[i].clearance < 3) {
			ResCheck = true;
			//status = ProSelectionHighlight(Clearance_Value_Vect[i].Component_selection, PRO_COLOR_SS_FAILED_ITEMS);
			//ruleLog.Write("ProSelectionHighlight: " + to_string(status));
			break;
		}
	}

	Remark_String_for_IR_F5B01_008 += "\nAcceptance criteria : Clearance should be > 3.00mm.";
	final_res.remark = Remark_String_for_IR_F5B01_008;

	if (ResCheck == false)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	FeatIDDataArr.clear();
	Vec_Tyres_Rim.clear();
	Vec_Selection_Drum.clear();
	Vec_Selection_Disc.clear();
	memset(&CModel, 0, sizeof(CModel));
	memset(&AsmCModel, 0, sizeof(AsmCModel));
	reqCompSubMod_IR_F5B01_008.clear();
	Clearance_Value_Vect.clear();
	Brake_Drum_Found = false;
	Brake_Disc_Found = false;

	return 0;
}

ProError PartNameAndIdVisitAction01(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	//ruleLog.Write("----------------------------- PartNameAndIdVisitAction -----------------------------");

	//ruleLog.Write("Component Levels01: " + to_string(Levels01));

	compdata_IRF5B01_008			compdatainfo{};
	ProMdlfileType					comp_type;
	ProFamilyMdlName				comp_name;
	char							part_no[PRO_PATH_SIZE]{};
	ProMdl							model;
	ProMdlExtension					modelExtension{};
	ProMdlType						type;
	wchar_t							wFeatName[PRO_NAME_SIZE]{};
	ProModelitem					modelItem;
	ProName							pDescName = L"DESCRIPTION";
	ProParameter					pDesc;
	ProParamvalue					pvDesc;
	char							Description_temp[PRO_PATH_SIZE]{};
	FeatIDdata01					_FeatIDdata;

	status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
	//ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));
	ProWstringToString(part_no, comp_name);
	//ruleLog.Write("ProMdlName: " + string(part_no));

	++MdlCount01;

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
	//ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));

	status = ProMdlExtensionGet(model, modelExtension);
	//ruleLog.Write("ProMdlExtensionGet: " + to_string(status));
	ProWstringToString(compdatainfo.type, modelExtension);
	//ruleLog.Write("compdatainfo.type: " + string(compdatainfo.type));

	status = ProMdlTypeGet(model, &type);
	//ruleLog.Write("ProMdlTypeGet:" + to_string(status));

	status = ProMdlMdlnameGet(model, wFeatName);
	//ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(compdatainfo.name, wFeatName);

	status = ProMdlToModelitem(model, &modelItem);
	//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	status = ProParameterInit(&modelItem, pDescName, &pDesc);
	//ruleLog.Write("ProParameterInit: " + to_string(status));

	status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
	//ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));
	ProWstringToString(Description_temp, pvDesc.value.s_val);
	(is_alphanumeric_and_space_for_IR_F5B01_008(Description_temp) ? strcpy(compdatainfo.Description, Description_temp) : strcpy(compdatainfo.Description, NotFound));

	compdatainfo.ID = p_feature->id;

	if (Levels01 == 1) {
		_FeatIDdata.feat_ids[0] = p_feature->id;
		_FeatIDdata.level = Levels01;
		FeatIDDataArr.push_back(_FeatIDdata);
	}
	else {
		for (int j = 0; j < FeatIDDataArr.size(); ++j) {
			if (FeatIDDataArr[j].feat_ids[Levels01 - 2] == OwnerFeatID01) {
				FeatIDdata01	owner_feat_id_data = FeatIDDataArr[j];
				for (int i = 0; i < Levels01 - 1; ++i) {
					_FeatIDdata.feat_ids[i] = owner_feat_id_data.feat_ids[i];
				}
				_FeatIDdata.feat_ids[Levels01 - 1] = p_feature->id;
				_FeatIDdata.level = Levels01;
				break;
			}
		}
		FeatIDDataArr.push_back(_FeatIDdata);
	}

	std::string pattern = "F5B01";
	size_t found = string(compdatainfo.name).find(pattern);
	if (found != std::string::npos && Levels01 == 1) {

		ruleLog.Write("Found: Level " + to_string(Levels01) + " (" + string(compdatainfo.Description) + ") (" + compdatainfo.name + ") " + to_string(compdatainfo.ID));

		ProIdTable			comp_id_table;
		int					table_num;
		ProAsmcomppath		p_comp_path;
		ProModelitem		p_modelitem;
		ProMdl				curMdl;
		table_num = Levels01;

		//ruleLog.Write("table_num: " + to_string(table_num));

		for (int m = 0; m < Levels01; ++m) {
			comp_id_table[m] = _FeatIDdata.feat_ids[m];
			//ruleLog.Write("comp_id_table[]: " + to_string(m) + " " + to_string(comp_id_table[m]));
		}

		status = ProMdlToModelitem(model, &p_modelitem);
		//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProMdlCurrentGet(&curMdl);
		//ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

		status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
		//ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

		ProSelection p_selection;
		status = ProSelectionAlloc(&p_comp_path, &p_modelitem, &compdatainfo.compsel);
		//ruleLog.Write("ProSelectionAlloc: " + to_string(status));

		//status = ProModelitemHide(&p_modelitem);
		//ruleLog.Write("ProModelitemHide: " + to_string(status));

		Vec_Tyres_Rim.push_back(compdatainfo);
	}


	string  searchString1 = "DRUM", searchString2 = "DISC";
	regex   pattern1("\\b" + searchString1 + "\\b"), pattern2("\\b" + searchString2 + "\\b");
	if (Brake_Drum_Found == false && regex_search(compdatainfo.Description, pattern1) && (Levels01 == 1 || Levels01 == 2)) {
		Brake_Drum_Found = true;
		ruleLog.Write("Brake_Drum_Found, Level:" + to_string(Levels01));
	}
	else if (Brake_Disc_Found == false && regex_search(compdatainfo.Description, pattern2) && (Levels01 == 1 || Levels01 == 2)) {
		Brake_Disc_Found = true;
		ruleLog.Write("Brake_Disc_Found, Level:" + to_string(Levels01));
	}

	if (type == PRO_MDL_ASSEMBLY && Levels01 < 3)
	{
		AsmCModel[AsmModelCount01].Model = model;
		AsmCModel[AsmModelCount01].Model_feat_id = p_feature->id;
		AsmModelCount01 += 1;
	}

	return PRO_TK_NO_ERROR;
}

ProError select_action_IRF5B01_008_Drum(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF5B01_008_Drum -----------------------------");

	Vec_Selection_Drum.clear();
	Clearance_Value_Vect.clear();
	Remark_String_for_IR_F5B01_008.clear();
	ThreeDPnt_Vect.clear();

	bool			ProSelectCheck{ false };
	int				curWinId{};
	string			Drum_Remark = "";


	status = ProWindowCurrentGet(&curWinId);
	ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

	status = ProWindowRepaint(curWinId);
	ruleLog.Write("ProWindowRepaint: " + to_string(status));

	status = ProUIDialogHide(DLG_IRF5B01_008);
	ruleLog.Write("ProUIDialogHide: " + to_string(status));


	for (size_t d = 0; d < Vec_Tyres_Rim.size(); d++) {
		status = ProSelectionHighlight(Vec_Tyres_Rim[d].compsel, PRO_COLOR_SELECTED);
		ruleLog.Write("ProSelectionHighlight: " + to_string(status));

		int				n_sel{};
		ProSelection* comp_surf_selection_drum = nullptr;
		InterfaceRule	_irule1{};
		InterfaceRule	_irule{};

		status = ProSelect("surface", -1, NULL, NULL, NULL, NULL, &comp_surf_selection_drum, &n_sel);
		ruleLog.Write("ProSelect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel));

		if (n_sel > 0) {
			string Selection_nos = "No. of Selected Surfaces: " + to_string(n_sel) + ", Please click 'OK' to proceed to the next component.";
			_irule1.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Surface Selection Information!", Selection_nos);
		}

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIDialogShow(DLG_IRF5B01_008);
			ruleLog.Write("ProUIDialogShow: " + to_string(status));
			break;
		}
		else if (n_sel < 1) {
			_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			ProSelectCheck = true;
			break;
		}

		status = ProSelectionUnhighlight(Vec_Tyres_Rim[d].compsel);
		ruleLog.Write("ProSelectionUnhighlight: " + to_string(status));

		for (size_t g = 0; g < n_sel; g++) {
			ProModelitem				comp_surf_Modelitem1;
			//ProMdl					owner1{};
			ProModelitem				comp_surf_Modelitem2;
			ProMdlExtension				modelExtension{};
			ProName						pDescName = L"DESCRIPTION";
			ProParameter				pDesc{};
			ProParamvalue				pvDesc{};
			char						Description_temp1[PRO_PATH_SIZE]{};
			wchar_t						MdlName[PRO_PATH_SIZE]{};
			compdata_IRF5B01_008		valuesins1{};



			status = ProSelectionHighlight(comp_surf_selection_drum[g], PRO_COLOR_SELECTED);
			ruleLog.Write("ProSelectionHighlight: " + to_string(status));

			status = ProSelectionModelitemGet(comp_surf_selection_drum[g], &comp_surf_Modelitem1);
			ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

			//status = ProModelitemMdlGet(&comp_surf_Modelitem1, &owner1);
			//ruleLog.Write("ProModelitemMdlGet: " + to_string(status));

			status = ProMdlToModelitem(comp_surf_Modelitem1.owner, &comp_surf_Modelitem2);
			ruleLog.Write("ProModelitemMdlGet: " + to_string(status));

			status = ProMdlExtensionGet(comp_surf_Modelitem1.owner, modelExtension);
			ruleLog.Write("ProMdlExtensionGet: " + to_string(status));
			ProWstringToString(valuesins1.type, modelExtension);
			ruleLog.Write("Type: " + string(valuesins1.type));

			status = ProParameterInit(&comp_surf_Modelitem2, pDescName, &pDesc);
			ruleLog.Write("ProParameterInit: " + to_string(status));

			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));

			ProWstringToString(valuesins1.Description, pvDesc.value.s_val);
			ruleLog.Write("Description: " + string(valuesins1.Description));

			//(is_alphanumeric_and_space_for_IR_F5B01_008(Description_temp1) ? strcpy(valuesins1.Description, Description_temp1) : strcpy(valuesins1.Description, NotFound));
			//ruleLog.Write("Description: " + string(valuesins1.Description));

			status = ProMdlMdlnameGet(comp_surf_Modelitem1.owner, MdlName);
			ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

			status = ProSelectionCopy(comp_surf_selection_drum[g], &valuesins1.compsel);
			ruleLog.Write("ProSelectionCopy: " + to_string(status));

			ProWstringToString(valuesins1.name, MdlName);
			ruleLog.Write("Name: " + string(valuesins1.name));

			valuesins1.Comp_Feat_ID = comp_surf_Modelitem2.id;
			valuesins1.ID = comp_surf_Modelitem1.id;
			ruleLog.Write("Feat ID: " + to_string(valuesins1.ID));
			Vec_Selection_Drum.push_back(valuesins1);

		}
		ruleLog.Write("Vec_Selection_Rim.size(): " + to_string(Vec_Tyres_Rim.size()));
		ruleLog.Write("Vec_Selection_Drum.size(): " + to_string(Vec_Selection_Drum.size()));

		Drum_Remark += "\nDistance between " + string(Vec_Tyres_Rim[d].name) + "." + string(Vec_Tyres_Rim[d].type) + " [" + string(Vec_Tyres_Rim[d].Description) +
			"] [Feature ID: " + to_string(Vec_Tyres_Rim[d].ID) + "] and \n\t\t"/* + string(Vec_Selection_Drum[g].name) + "." + string(Vec_Selection_Drum[g].type) +
			" [" + string(Vec_Selection_Drum[g].Description) + "] \n" + to_string(Vec_Selection_Drum[d].Comp_Feat_ID) + "\n"*/;

		for (size_t o = 0; o < Vec_Selection_Drum.size(); o++) {
			if (o == 0) {
				Drum_Remark += string(Vec_Selection_Drum[o].name) + "." + string(Vec_Selection_Drum[o].type) +
					" [" + string(Vec_Selection_Drum[o].Description) + "] \n" /*+ to_string(Vec_Selection_Drum[o].Comp_Feat_ID) + "\n"*/;
			}
			else
				break;
		}

		for (size_t i = 0; i < Vec_Selection_Drum.size(); i++) {
			Clearances_class_IR_F5B01_008 Clearance_Values_data{};
			ProBoolean is_interference_found1;
			ThreeDPnt pnt_arr2;
			double clearance_value_for_Drum{};

			status = ProFitClearanceCompute(Vec_Tyres_Rim[d].compsel, PRO_FIT_INCLUDE_NONE, Vec_Selection_Drum[i].compsel, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, Vec_Tyres_Rim[d].compsel, PRO_B_FALSE, &clearance_value_for_Drum, NULL, &is_interference_found1, pnt_arr2.pnt_arr1);
			ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tDistance between " + to_string(Vec_Tyres_Rim[d].ID) + " and " + to_string(Vec_Selection_Drum[i].ID) + ": " + to_string(clearance_value_for_Drum));
			ThreeDPnt_Vect.push_back(pnt_arr2);

			string Double = formatdouble_for_IR_F5B01_008(clearance_value_for_Drum);
			Drum_Remark += "\t\t\t\tSurface ID [" + to_string(Vec_Selection_Drum[i].ID) + "]: " + Double + "mm" + "\n";

			Clearance_Values_data.clearance = clearance_value_for_Drum;
			Clearance_Values_data.Component_selection = Vec_Selection_Drum[i].compsel;
			Clearance_Value_Vect.push_back(Clearance_Values_data);
		}
		Vec_Selection_Drum.clear();
	}
	Remark_String_for_IR_F5B01_008 += Drum_Remark;

	if (ProSelectCheck == false) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));
	}

	status = ProUIDialogShow(DLG_IRF5B01_008);
	ruleLog.Write("ProUIDialogShow: " + to_string(status));

	return PRO_TK_NO_ERROR;
}

ProError select_action_IRF5B01_008_Disc(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF5B01_008_Disc -----------------------------");

	Clearance_Value_Vect.clear();
	Remark_String_for_IR_F5B01_008.clear();
	Vec_Selection_Disc.clear();
	ThreeDPnt_Vect.clear();

	bool ProSelectCheck{ false };
	int curWinId{};
	status = ProWindowCurrentGet(&curWinId);
	ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

	status = ProWindowRepaint(curWinId);
	ruleLog.Write("ProWindowRepaint: " + to_string(status));

	status = ProUIDialogHide(DLG_IRF5B01_008);
	ruleLog.Write("ProUIDialogHide: " + to_string(status));

	for (size_t d = 0; d < Vec_Tyres_Rim.size(); d++) {

		compdata_IRF5B01_008	valuesins2;
		char					Description_temp2[PRO_PATH_SIZE]{};

		status = ProSelectionHighlight(Vec_Tyres_Rim[d].compsel, PRO_COLOR_SELECTED);
		ruleLog.Write("ProSelectionHighlight: " + to_string(status));

		int				n_sel{};
		ProSelection* comp_surf_selection_disc = nullptr;
		status = ProSelect("part", 1, NULL, NULL, NULL, NULL, &comp_surf_selection_disc, &n_sel);
		ruleLog.Write("ProSelect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIDialogShow(DLG_IRF5B01_008);
			ruleLog.Write("ProUIDialogShow: " + to_string(status));
			break;
		}
		else if (n_sel < 1) {
			InterfaceRule _irule{};
			_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			ProSelectCheck = true;
			break;
		}

		status = ProSelectionUnhighlight(Vec_Tyres_Rim[d].compsel);
		ruleLog.Write("ProSelectionUnhighlight: " + to_string(status));

		status = ProSelectionHighlight(comp_surf_selection_disc[0], PRO_COLOR_SELECTED);
		ruleLog.Write("ProSelectionHighlight: " + to_string(status));

		status = ProSelectionCopy(comp_surf_selection_disc[0], &valuesins2.compsel);
		ruleLog.Write("ProSelectionCopy: " + to_string(status));

		status = ProSelectionAsmcomppathGet(comp_surf_selection_disc[0], &valuesins2.comp_path);
		ruleLog.Write("ProSelectionCopy: " + to_string(status));

		int temp = valuesins2.comp_path.comp_id_table[valuesins2.comp_path.table_num - 1];
		ruleLog.Write("temp: " + to_string(temp));

		ProModelitem comp_surf_Modelitem3;
		status = ProMdlToModelitem(valuesins2.comp_path.owner, &comp_surf_Modelitem3);
		ruleLog.Write("ProModelitemMdlGet: " + to_string(status));

		ProModelitem comp_part_Modelitem1;
		status = ProSelectionModelitemGet(comp_surf_selection_disc[0], &comp_part_Modelitem1);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

		ProMdlExtension	modelExtension{};
		status = ProMdlExtensionGet(valuesins2.comp_path.owner, modelExtension);
		ruleLog.Write("ProMdlExtensionGet: " + to_string(status));
		ProWstringToString(valuesins2.type, modelExtension);
		ruleLog.Write("type: " + string(valuesins2.type));

		ProName      pDescName = L"DESCRIPTION";
		ProParameter pDesc;
		status = ProParameterInit(&comp_part_Modelitem1, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit: " + to_string(status));

		ProParamvalue pvDesc;
		status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
		ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));
		ProWstringToString(Description_temp2, pvDesc.value.s_val);
		ruleLog.Write("Description_temp2: " + string(Description_temp2));
		(is_alphanumeric_and_space_for_IR_F5B01_008(Description_temp2) ? strcpy(valuesins2.Description, Description_temp2) : strcpy(valuesins2.Description, NotFound));
		ruleLog.Write("Description: " + string(valuesins2.Description));

		wchar_t MdlName[PRO_PATH_SIZE]{};
		status = ProMdlMdlnameGet(comp_part_Modelitem1.owner, MdlName);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

		ProWstringToString(valuesins2.name, MdlName);
		ruleLog.Write("Name: " + string(valuesins2.name));

		valuesins2.ID = temp;
		ruleLog.Write("Feat ID: " + to_string(valuesins2.ID));

		Vec_Selection_Disc.push_back(valuesins2);
	}

	if (ProSelectCheck == false) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));
	}

	status = ProUIDialogShow(DLG_IRF5B01_008);
	ruleLog.Write("ProUIDialogShow: " + to_string(status));

	return PRO_TK_NO_ERROR;
}


ProError ruleDlgOKaction_for_F5B01_008(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgOKaction_for_F5B01_008 -----------------------------");

	int curWinId2{};
	status = ProWindowCurrentGet(&curWinId2);
	ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

	status = ProWindowRepaint(curWinId2);
	ruleLog.Write("ProWindowRepaint: " + to_string(status));

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return PRO_TK_NO_ERROR;
}

