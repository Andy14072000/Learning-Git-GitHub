/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 20-06-2023	|	V1_0_0		| F2B01 - STEERING SYSTEM RULES
==================================================================================================================*/
#include "F2B01.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES			| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2B01_001		| Aniket Satpute	| MF2B01; MF1E01; MF2B03	|  Ensure clearance between Steering column assy/ rubber bellow & Brake pedal >50mm.
===================================================================================================================*/

#define DLG_IRF2B01_001 "dlg_IR_f2b01_001"
#define PB_RSELECT        "pb_select"
#define PB_ROK            "rule_ok_pb"
#define PB_CANCEL        "CommitCancel"

// GLOBAL ENTITIES
double Surfclear;
int IRF2B01::IRF2B01_001(ruleResult& final_res)
{
    ComponentData _reqComps[3]{};
    string reqCompSubMod[3] = { "F2B01", "F1E01" };

    for (int i = 0; i < subModulesList.size(); ++i)
        for (int j = 0; j < 3; ++j)
            if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
                strcpy(_reqComps[j].name, subModulesList[i].name.c_str());

    Surfclear = 0;
    status = ProUIDialogCreate(DLG_IRF2B01_001, DLG_IRF2B01_001);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF2B01_001, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF2B01_001, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF2B01_001, "pb_run", (ProUIAction)ruleDlgOKaction, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF2B01_001, "pb_select", (ProUIAction)select_action_IRF2B01001, NULL);

    status = ProUIPushbuttonDisable(DLG_IRF2B01_001, "pb_run");

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF2B01_001, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF2B01_001);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    sprintf(remark, "Measured value = %dmm; Acceptance criteria: > 50mm.", int(Surfclear));
    final_res.remark = string(remark);

    // DECLARE RESULT
    if (int(Surfclear) > 50)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    return 0;
}

ProError select_action_IRF2B01001(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- select_action_IRF2B01001 -----------------------------");
    InterfaceRule _irule;
    int n_sels, n_sels1;
    int curWinId;
    ProWindowCurrentGet(&curWinId);
    ProWindowRepaint(curWinId);
    ProSelection* surf_sel = nullptr;
    ProSelection* surf_sel1 = nullptr;
    ProSelection Sel1;
    ProSelection Sel2;

    status = ProSelect((char*)"part", 1, NULL, NULL, NULL, NULL, &surf_sel, &n_sels);
    ruleLog.Write("Part Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels));
    ruleLog.Write("check1");

    if (status == PRO_TK_USER_ABORT) {
        status = ProUIPushbuttonDisable(DLG_IRF2B01_001, "pb_run");
        return status;
    }

    if (n_sels < 1 || status != PRO_TK_NO_ERROR) {
        _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
        status = ProUIPushbuttonDisable(DLG_IRF2B01_001, "pb_run");
        return status;
    }

    status = ProSelectionCopy(surf_sel[0], &Sel1);
    ruleLog.Write("ProSelectionCopy: " + to_string(status));

    status = ProSelect((char*)"surface", 1, NULL, NULL, NULL, NULL, &surf_sel1, &n_sels1);
    ruleLog.Write(" Surface Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels1));
    ruleLog.Write("check2");

    if (status == PRO_TK_USER_ABORT) {
        status = ProUIPushbuttonDisable(DLG_IRF2B01_001, "pb_run");
        return status;
    }
    status = ProSelectionCopy(surf_sel1[0], &Sel2);
    ruleLog.Write("ProSelectionCopy: " + to_string(status));

    if (n_sels1 < 1 || status != PRO_TK_NO_ERROR) {
        _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
        status = ProUIPushbuttonDisable(DLG_IRF2B01_001, "pb_run");
        return status;
    }
    status = ProUIPushbuttonEnable(DLG_IRF2B01_001, "pb_run");

    ProBoolean interf;
    Pro3dPnt coord[2];
    status = ProFitClearanceCompute(Sel1, PRO_FIT_INCLUDE_NONE, Sel2, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &Surfclear, NULL, &interf, coord);
    ruleLog.Write("ProFitClearanceCompute " + to_string(status));

    return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES		| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2B01_002		| Vinay Neel    	| MF2B01; MF5A08        |  Ensure clearance between UJ envelope/ EPAS steering column assembly & brake booster >8mm.
===================================================================================================================*/
#define DLG_IRF2B01_002 "dlg_IR_F2B01_002"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"
#define Radio            "RadioGroup1"
#define PB_SELECT        "pb_select"
bool isManual_F2B01002;
ProSelection* prt_selF2B01002;
string remark_mesF2B01002;
struct SelPartDataF2B01002 {
    char name[PRO_NAME_SIZE];
    int id;
};
vector<SelPartDataF2B01002> sel_part_dataF2B01002;
int IRF2B01::IRF2B01_002(ruleResult& final_res) {

    ruleLog.Write("==========================   IRF2B01::IRF2B01_002   ==========================");

    isManual_F2B01002 = false;
    remark_mesF2B01002 = "";
    ComponentData _reqComps[2]{};
    string reqCompSubMod[2] = { "F2B01","F5A08" };
    double clearance_value, std_clearance = 8.0;
    Pro3dPnt pnt_arr[2];

    for (int i = 0; i < subModulesList.size(); ++i)
        for (int j = 0; j < 2; ++j)
            if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
                strcpy(_reqComps[j].name, subModulesList[i].name.c_str());

    status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps);
    ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

    for (auto elem : _reqComps) {
        ruleLog.Write("_reqComps[].name = " + string(elem.name));
        ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
    }

    isUserQuits = false;

    status = ProUIDialogCreate(DLG_IRF2B01_002, DLG_IRF2B01_002);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF2B01_002, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF2B01_002, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF2B01_002, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF2B01_002, PB_SELECT, (ProUIAction)select_action_IRF2B01002, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));

    status = ProUIRadiogroupSelectActionSet(DLG_IRF2B01_002, Radio, (ProUIAction)rg_select_action_IRF2B01002, NULL);
    ruleLog.Write("ProUIRadiogroupSelectActionSet status: " + to_string(status));

    status = ProUIPushbuttonDisable(DLG_IRF2B01_002, PB_SELECT);
    status = ProUIDialogHide(DLG_IRC_MAIN);

    int radioGrpNames[2];
    char** buttonNames;

    //Radio button, selected for first button (default)
    status = ProUIRadiogroupSelectednamesGet(DLG_IRF2B01_002, Radio, radioGrpNames, &buttonNames);
    ruleLog.Write("ProUIRadiogroupSelectednamesGet status main: " + to_string(status));
    ruleLog.Write("selected button name: " + (string)buttonNames[0]);


    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF2B01_002, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF2B01_002);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    deleteDatumPoint("datum_PNT1");
    deleteDatumPoint("datum_PNT2");

    if (isUserQuits)
        return -1;

    //manual selection
    if (isManual_F2B01002 == 1)
    {
        ruleLog.Write("manual selection");
        status = ProUIPushbuttonDisable(DLG_IRF2B01_002, PB_ROK);
        status = ProUIPushbuttonEnable(DLG_IRF2B01_002, PB_SELECT);
        ProBoolean is_interference_found;
        Pro3dPnt coord[2];
        double clearance;
        status = ProFitClearanceCompute(prt_selF2B01002[0], PRO_FIT_INCLUDE_NONE, prt_selF2B01002[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearance, NULL, &is_interference_found, coord);
        ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));
        ruleLog.Write("clearance = " + to_string(clearance));

        remark_mesF2B01002 += "Result: \n\nMinimum clearance between steering column and brake booster found is";
        sprintf(remark, " %.2lf mm.", clearance);
        remark_mesF2B01002 += remark;
        remark_mesF2B01002 += "\n\nAcceptance Criteria : Clearance between UJ envelope / EPAS steering column assembly and brake booster > 8.00 mm.";

        // remark_mesF2B01002 += "\nUsed Reference part : " + string(sel_part_dataF2B01002[0].name) + ".PRT" + " (Id :" + string(to_string(sel_part_dataF2B01002[0].id)) + ")";

        remark_mesF2B01002 += "\nUsed Reference part : " + string(sel_part_dataF2B01002[0].name) + ".PRT";
        remark_mesF2B01002 += "\nUsed Reference part : " + string(sel_part_dataF2B01002[1].name) + ".PRT";

        if (clearance > std_clearance)
        {
            final_res.result = "PASS";
            final_res.remark = remark_mesF2B01002;
        }
        else
        {
            final_res.result = "FAIL";
            final_res.remark = remark_mesF2B01002;
        }

    }
    else
    {
        status = ProUIPushbuttonEnable(DLG_IRF2B01_002, PB_ROK);

        rule_sts = measureDistanceBetweenComponentsF2B01002(_reqComps[0], _reqComps[1], clearance_value, pnt_arr);
        createDatumPoints(pnt_arr, "CSYS_ASM_DEF", "Dist_highlght_pnt");
        clearance_value = round(clearance_value * 100) / 100;


        // DECLARE RESULT
        sprintf(remark, "Result:\nClearance between %s.ASM (steering column) and %s.ASM (brake booster) is %.2lf mm.;\nAcceptance criteria: \nClearance between UJ envelope / EPAS steering column assembly and brake booster > 8.00 mm.", _reqComps[0].name, _reqComps[1].name, clearance_value);
        final_res.remark = string(remark);

        if (clearance_value > std_clearance)
            final_res.result = "PASS";
        else
            final_res.result = "FAIL";
    }
    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    return 0;
}

int measureDistanceBetweenComponentsF2B01002(ComponentData reqComp1, ComponentData reqComp2, double& distance, Pro3dPnt(&pnt_arr)[2])
{
    ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenComponentsF2B01002 <=================");

    ProSelection sels[2];
    ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected
    ProIdTable idtbl2 = { reqComp2.id };		// component id of the component 2 to be selected

    ProName comp1_name, comp2_name;
    ProModelitem feature[2];
    ProMdl reqMdls[2];

    ProStringToWstring(comp1_name, reqComp1.name);
    status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
    ruleLog.Write("ProMdlnameInit: " + to_string(status));
    status = ProMdlToModelitem(reqMdls[0], &feature[0]);

    ProStringToWstring(comp2_name, reqComp2.name);
    status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
    status = ProMdlToModelitem(reqMdls[1], &feature[1]);

    ProAsmcomppath path[2];
    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl2, 1, &path[1]);
    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

    status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));
    status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    ProBoolean is_interference_found;
    //Pro3dPnt pnt_arr[2];
    status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_FROM_QUILTS, sels[1], PRO_FIT_INCLUDE_TO_QUILTS, PRO_FIT_WHOLE_SURFACE, sels[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
    ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));

    return 0;
}

ProError select_action_IRF2B01002(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- select_action_IRF2B01002 -----------------------------");

    //ProModelitem part_model_item;
    //ProName name;
    //char str_name[PRO_NAME_SIZE];
    //ProModelitem parent_model_item;
    //ProParameter pDesc;
    //ProParamvalue pvDesc;
    //ProName pDescName = L"DESCRIPTION";
    //string                  description;
    //char existingPval[PRO_LINE_SIZE]{};

    //InterfaceRule _irule;
    int n_sel;
    bool* quitAction = (bool*)data;

    status = ProSelect((char*)"part", 2, NULL, NULL, NULL, NULL, &prt_selF2B01002, &n_sel);
    ruleLog.Write("ProSelect: " + to_string(status));

    if (status == PRO_TK_USER_ABORT)
    {
        status = ProUIPushbuttonDisable(dialog, PB_ROK);
        if (quitAction != NULL)
            *quitAction = true;
        return status;
    }
    if (n_sel < 2 || status != PRO_TK_NO_ERROR) {
        _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
        if (quitAction != NULL)
            *quitAction = true;
        status = ProUIPushbuttonDisable(dialog, PB_ROK);
        return status;
    }


    if (status == PRO_TK_NO_ERROR && n_sel == 2)
    {
        status = ProUIPushbuttonEnable(dialog, PB_ROK);
    }

    ProMdlName		wname1, wname2;
    char            cname1[PRO_NAME_SIZE], cname2[PRO_NAME_SIZE];
    ProMdl Mdl[2];
    //ProFeature feature[2];
    ProModelitem   modelitem[2];
    SelPartDataF2B01002 seldata{};
    ProAsmcomppath comppath, comp_path;

    status = ProSelectionModelitemGet(prt_selF2B01002[0], &modelitem[0]);
    status = ProModelitemMdlGet(&modelitem[0], &Mdl[0]);
    status = ProMdlMdlnameGet(Mdl[0], wname1);


    ProWstringToString(cname1, wname1);
    strcpy(seldata.name, cname1);
    seldata.id = modelitem[0].id;
    sel_part_dataF2B01002.push_back(seldata);
    ruleLog.Write("model_names1: " + string(cname1));
    ruleLog.Write("Id1: " + to_string(modelitem[0].id));

    status = ProSelectionModelitemGet(prt_selF2B01002[1], &modelitem[1]);
    status = ProModelitemMdlGet(&modelitem[1], &Mdl[1]);
    status = ProMdlMdlnameGet(Mdl[1], wname2);
    ProWstringToString(cname2, wname2);
    strcpy(seldata.name, cname2);
    seldata.id = modelitem[1].id;
    sel_part_dataF2B01002.push_back(seldata);
    ruleLog.Write("model_names2: " + string(cname2));
    ruleLog.Write("Id2: " + to_string(modelitem[1].id));

    return status;
}

ProError rg_select_action_IRF2B01002(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("============== rg_select_action_IRF2B01002 ==============");
    int radioGrpNames[2];
    char** buttonNames;
    char selectedButton[PRO_NAME_SIZE];
    // InterfaceRule iRule;
     //status = ProUIPushbuttonDisable(dialog, PB_OK);
    status = ProUIRadiogroupSelectednamesGet(dialog, component, radioGrpNames, &buttonNames);

    ruleLog.Write("ProUIRadiogroupSelectednamesGet status: " + to_string(status));

    //strcpy(selectedButton, buttonNames[0]);
    ruleLog.Write("selected button name: " + (string)buttonNames[0]);
    if (strcmp(buttonNames[0], "Automatic") == 0)
    {
        isManual_F2B01002 = false;
        ruleLog.Write("IsManual? : " + to_string(isManual_F2B01002));
        status = ProUIPushbuttonDisable(dialog, PB_SELECT);
        status = ProUIPushbuttonEnable(dialog, PB_ROK);
    }
    else
    {
        status = ProUIPushbuttonEnable(dialog, PB_SELECT);
        status = ProUIPushbuttonDisable(dialog, PB_ROK);
        isManual_F2B01002 = true;
        ruleLog.Write("IsManual? : " + to_string(isManual_F2B01002));
    }

    return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES			        | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2B01_003		| Vinay Neel		| MF2B01; MF1C03; MF1C01; MF1C04	|  Ensure clearance between Pneumatic steering column and pneumatic pipe bunch >15mm
===================================================================================================================*/

#define DLG_IRF2B01_003 "dlg_IR_F2B01_003"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"


vector<NumaticPipeData> _numaticComp;
vector<SterClmData> _steerComp;
vector<ProSelection> p_selection_sterClm, p_selection_pNumaticpipe;

string remark_message;
ProMdl reqMdlf2b01;
int dtmptcount = 1;

int IRF2B01::IRF2B01_003(ruleResult& final_res) {
    ruleLog.Write("==========================   IRF2B01::IRF2B01_003   ==========================");
    status = ProWindowRepaint(PRO_VALUE_UNUSED);
    p_selection_sterClm.clear();
    p_selection_pNumaticpipe.clear();
    _numaticComp.clear();
    _steerComp.clear();
    remark_message = "";

    double minClearance = 0;
    ComponentData _reqComps[1]{};
    vector<ComponentData> _reqCompsClm;
    string reqCompSubMod[1] = { "F2B01" };//MF2B01; MF1C03; MF1C01; MF1C04

   // ruleLog.Write("sizeof(p_selection_sterClm: " + to_string(sizeof(p_selection_sterClm)));
   // ruleLog.Write("p_selection_sterClm.size(): " + to_string(p_selection_sterClm.size()));

    vector<double> clearance_values;
    double std_clearance = 15.0;

    for (int i = 0; i < subModulesList.size(); ++i)
        for (int j = 0; j < 1; ++j)
            if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
                strcpy(_reqComps[j].name, subModulesList[i].name.c_str());


    ProName comp1_name;
    //  ProModelitem feature;
    ProStringToWstring(comp1_name, _reqComps[0].name);
    status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdlf2b01);
    ruleLog.Write("ProMdlnameInitF2b01: " + to_string(status));

    //F2B01 as a main assembly (it will travers only in F2B01)
    status = ProSolidFeatVisit((ProSolid)reqMdlf2b01, getVisitedCompAsmNamesAction_F2B01, compsFilter, (ProAppData)&_reqCompsClm);
    ruleLog.Write("ProSolidFeatVisit reqMdlf2b01: " + to_string(status));
    ruleLog.Write("_reqCompsClm.size(): " + to_string(_reqCompsClm.size()));


    if (p_selection_pNumaticpipe.size() == 0) {

        ProUIMessageButton* buttons;
        ProUIMessageButton user_choice;
        ProArrayAlloc(2, sizeof(ProUIMessageButton), 1, (ProArray*)&buttons);
        buttons[0] = PRO_UI_MESSAGE_OK;
        buttons[1] = PRO_UI_MESSAGE_CANCEL;

        wchar_t wTitle[PRO_NAME_SIZE], wMsg[PRO_PATH_SIZE];
        char cTitle[PRO_NAME_SIZE] = "Confirmation";
        char cMsg[PRO_PATH_SIZE];
        string message = "This rule cannot be applied as the Pneumatic pipe bunch is currently unavailable. \n\nKindly verify the CAD data or confirm to proceed with this rule";
        strcpy(cMsg, message.c_str());
        ProStringToWstring(wTitle, cTitle);
        ProStringToWstring(wMsg, cMsg);

        status = ProUIMessageDialogDisplay(PROUIMESSAGE_QUESTION, wTitle, wMsg, buttons, buttons[0], &user_choice);
        mainLog.Write("ProUIMessageDialogDisplay: " + to_string(status));

        sprintf(remark, "This rule is not applicable for %s.ASM.\nHence Passed", _reqComps[0].name);
        if (user_choice == PRO_UI_MESSAGE_OK) {
            final_res.result = "PASS";
            final_res.remark = remark;
            return 0;
        }
        else
            return 0;

    }


    for (auto elem : _reqCompsClm) {
        ruleLog.Write("_reqCompsClm[].name = " + string(elem.name));
        ruleLog.Write("_reqCompsClm[].id = " + to_string(elem.id));
    }

    ruleLog.Write("p_selection_sterClm.size() = " + to_string(p_selection_sterClm.size()));
    ruleLog.Write("p_selection_pipe.size() = " + to_string(p_selection_pNumaticpipe.size()));

    isUserQuits = false;


    status = ProUIDialogCreate(DLG_IRF2B01_003, DLG_IRF2B01_003);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF2B01_003, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF2B01_003, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF2B01_003, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

    for (int i = 0; i < p_selection_pNumaticpipe.size(); ++i) {
        deleteDatumPoint("datum_PNT1");
        deleteDatumPoint("datum_PNT2");
    }

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF2B01_003, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF2B01_003);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;


    for (int i = 0; i < p_selection_pNumaticpipe.size(); i++)
    {
        double val;
        ProBoolean interf;
        Pro3dPnt pnt_arr[2];
        status = ProFitClearanceCompute(p_selection_sterClm[0], PRO_FIT_INCLUDE_NONE, p_selection_pNumaticpipe[i], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &val, NULL, &interf, pnt_arr);
        ruleLog.Write("ProFitClearanceCompute = " + to_string(status) + "\ndistance = " + to_string(val));
        createDatumPointsF2B01005(pnt_arr, "CSYS_ASM_DEF");
        val = round(val * 100) / 100;
        clearance_values.push_back(val);
    }


    for (int i = 0; i < p_selection_pNumaticpipe.size(); i++) {
        clearance_values[i] = round(clearance_values[i] * 100) / 100;
    }

    isRightValue = true;
    for (auto vals : clearance_values) {
        if (vals < std_clearance) {
            isRightValue = false;
            break;
        }
    }

    //Highlighting the Pneumatic pipe parts
    if (isRightValue == true)
    {
        for (int i = 0; i < p_selection_pNumaticpipe.size(); i++) {
            ProSelectionHighlight(p_selection_pNumaticpipe[i], PRO_COLOR_SELECTED);
        }
    }
    else
    {
        for (int i = 0; i < p_selection_pNumaticpipe.size(); i++) {
            if (clearance_values[i] < std_clearance)
            {
                ProSelectionHighlight(p_selection_pNumaticpipe[i], PRO_COLOR_HIGHLITE);
            }
        }
    }


    for (int i = 0; i < p_selection_pNumaticpipe.size(); i++) {
        ruleLog.Write(string(_steerComp[0].name) + " and " + string(_numaticComp[i].name) + " : " + to_string(clearance_values[i]));
    }

    // DECLARE RESULT
    if (isRightValue)
    {
        final_res.result = "PASS";
        remark_message += "Result: \n\nMeasured Values: \nClearance Between " + string(_steerComp[0].name) + ".ASM" + " (Steering Column) and \n following Pneumatic pipe parts";

        for (int i = 0; i < p_selection_pNumaticpipe.size(); i++) {
            sprintf(remark, "\n -%s : %.2lf mm", _numaticComp[i].name, clearance_values[i]);
            remark_message += remark;
        }

        sprintf(remark, " \n\nAcceptance criteria: > %.2lf mm", std_clearance);
        final_res.remark = remark_message + remark;

    }
    else
    {
        final_res.result = "FAIL";
        remark_message += "Result: \n\nMeasured Values: \nClearance Between " + string(_steerComp[0].name) + ".ASM" + " (Steering Column) and following Pneumatic pipe parts";

        for (int i = 0; i < p_selection_pNumaticpipe.size(); i++) {
            sprintf(remark, "\n -%s : %.2lf mm", _numaticComp[i].name, clearance_values[i]);
            remark_message += remark;
        }

        sprintf(remark, " Acceptance criteria: > %.2lf mm", std_clearance);
        final_res.remark = remark_message + remark;

    }

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    //  sprintf(remark, "Measured values :%.2lfmm; Acceptance criteria: >%.2lfmm", minClearance, std_clearance);
    //  final_res.remark = string(remark);

    p_selection_sterClm.clear();
    p_selection_pNumaticpipe.clear();
    _numaticComp.clear();
    _steerComp.clear();
    remark_message.clear();
    dtmptcount = 1;
    return 0;
}

ProError getVisitedCompAsmNamesAction_F2B01(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    ruleLog.Write("----------------------------- getVisitedCompAsmNamesAction_F2B01 -----------------------------");

    vector<ComponentData>* namesList = (vector<ComponentData>*)app_data;
    //required sub-module under the parent sub-module
    ProMdl reqMdl;
    ProMdlType subModuleMdlType;
    wchar_t wFeatName[PRO_NAME_SIZE];
    char cFeatName[PRO_NAME_SIZE];
    ComponentData cd;
    ProModelitem modelItem;
    ProAsmcomppath		p_comp_path;
    NumaticPipeData data2{};
    SterClmData data1{};

    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
    status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
    status = ProMdlMdlnameGet(reqMdl, wFeatName);
    ProWstringToString(cFeatName, wFeatName);

    status = ProMdlToModelitem(reqMdl, &modelItem);

    if (subModuleMdlType == PRO_MDL_ASSEMBLY) {
        if ((string(cFeatName)).substr(4, 4) == "4610")
        {

            ProSelection p_selection_parts;

            strcpy(cd.name, cFeatName);
            cd.id = p_feature->id;
            namesList->push_back(cd);

            ProIdTable	comp_id_table = { cd.id };
            ruleLog.Write("comp_id_table[0] =  " + to_string(comp_id_table[0]));

            //reqMdlf2b01 as a parent sub-module
            status = ProAsmcomppathInit((ProSolid)reqMdlf2b01, comp_id_table, 1, &p_comp_path);
            ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

            status = ProSelectionAlloc(&p_comp_path, &modelItem, &p_selection_parts);
            ruleLog.Write("ProSelectionAlloc1: " + to_string(status));

            if (status == PRO_TK_NO_ERROR) {
                strcpy(data1.name, cFeatName);
                _steerComp.push_back(data1);
                p_selection_sterClm.push_back(p_selection_parts);
            }

        }
        else if ((string(cFeatName)).substr(6, 2) == "80" || (string(cFeatName)).substr(6, 2) == "81")
        {
            ProSelection p_selection_parts;

            strcpy(cd.name, cFeatName);
            cd.id = p_feature->id;
            namesList->push_back(cd);

            ProIdTable	comp_id_table = { cd.id };
            ruleLog.Write("comp_id_table[0] =  " + to_string(comp_id_table[0]));

            status = ProAsmcomppathInit((ProSolid)reqMdlf2b01, comp_id_table, 1, &p_comp_path);
            ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

            status = ProSelectionAlloc(&p_comp_path, &modelItem, &p_selection_parts);
            ruleLog.Write("ProSelectionAlloc2: " + to_string(status));

            if (status == PRO_TK_NO_ERROR) {
                string prtname = string(cFeatName);
                size_t underscorePos = prtname.find('_');
                if (underscorePos != std::string::npos) {
                    // Remove the substring starting from the underscore
                    prtname.erase(underscorePos);
                    ruleLog.Write("prtname: " + prtname);
                    prtname.append(".ASM");
                    strcpy(data2.name, prtname.c_str());
                    _numaticComp.push_back(data2);
                }
                else {
                    string partname = cFeatName;
                    prtname.append(".ASM");
                    strcpy(data2.name, prtname.c_str());
                    ruleLog.Write("cFeatName: " + string(cFeatName));
                    _numaticComp.push_back(data2);
                }
                // strcpy(data2.name, cFeatName);
                // ruleLog.Write("cFeatName: " + string(cFeatName));
                p_selection_pNumaticpipe.push_back(p_selection_parts);
            }
        }
    }
    else if (subModuleMdlType == PRO_MDL_PART) {
        if ((string(cFeatName)).substr(4, 4) == "4610")
        {

            ProSelection p_selection_parts;

            strcpy(cd.name, cFeatName);
            cd.id = p_feature->id;
            namesList->push_back(cd);

            ProIdTable	comp_id_table = { cd.id };
            ruleLog.Write("comp_id_table[0] =  " + to_string(comp_id_table[0]));

            //reqMdlf2b01 as a parent sub-module
            status = ProAsmcomppathInit((ProSolid)reqMdlf2b01, comp_id_table, 1, &p_comp_path);
            ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

            status = ProSelectionAlloc(&p_comp_path, &modelItem, &p_selection_parts);
            ruleLog.Write("ProSelectionAlloc1: " + to_string(status));

            if (status == PRO_TK_NO_ERROR) {
                strcpy(data1.name, cFeatName);
                _steerComp.push_back(data1);
                p_selection_sterClm.push_back(p_selection_parts);
            }

        }
        if ((string(cFeatName)).substr(6, 2) == "80" || (string(cFeatName)).substr(6, 2) == "81") {

            ProSelection p_selection_parts;

            strcpy(cd.name, cFeatName);
            cd.id = p_feature->id;
            namesList->push_back(cd);

            ProIdTable	comp_id_table = { cd.id };
            ruleLog.Write("comp_id_table[0] =  " + to_string(comp_id_table[0]));

            status = ProAsmcomppathInit((ProSolid)reqMdlf2b01, comp_id_table, 1, &p_comp_path);
            ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

            status = ProSelectionAlloc(&p_comp_path, &modelItem, &p_selection_parts);
            ruleLog.Write("ProSelectionAlloc2: " + to_string(status));

            if (status == PRO_TK_NO_ERROR) {
                ruleLog.Write("inside if part");
                string prtname = string(cFeatName);
                size_t underscorePos = prtname.find('_');
                if (underscorePos != std::string::npos) {
                    // Remove the substring starting from the underscore
                    prtname.erase(underscorePos);
                    prtname.append(".PRT");
                    ruleLog.Write("prtname: " + prtname);
                    strcpy(data2.name, prtname.c_str());
                    _numaticComp.push_back(data2);
                }
                else {
                    string prtname = string(cFeatName);
                    prtname.append(".PRT");
                    strcpy(data2.name, prtname.c_str());
                    ruleLog.Write("cFeatName: " + string(cFeatName));
                    _numaticComp.push_back(data2);
                }

                //  strcpy(data2.name, cFeatName);
                p_selection_pNumaticpipe.push_back(p_selection_parts);
            }
        }
    }
    ProSolidFeatVisit((ProSolid)reqMdl, getVisitedCompAsmNamesAction_F2B01, compsFilter, (ProAppData)namesList);


    return PRO_TK_NO_ERROR;
}

int createDatumPointsF2B01005(Pro3dPnt pnt_arr[2], char* csysName) {

    ruleLog.Write("=================> createDatumPointsF2B01005 <=================");
    ProElement	elem_tree, elem_ftype, elem_feature_name,
        pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
        pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
        pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
    ProReference REPDEP_ref1;
    wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wide_string[PRO_NAME_SIZE], wide_string_2[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE];
    //CSYS_ASM_DEF
    ProModelitem refCsysitem;
    ProSelection refCsysSel, reqMdlSel;
    ProFeatureCreateOptions* opts = 0;
    ProFeature pnt_feat;
    ProErrorlist errors;
    //converting negative values to positive
    double d1 = -pnt_arr[0][2];
    double d2 = -pnt_arr[1][2];
    string PointName = "Dist_highlght_pnt" + to_string(dtmptcount);
    char cDatumPointName[PRO_NAME_SIZE];
    strcpy(cDatumPointName, PointName.c_str());

    ProStringToWstring(wCsysName, csysName);
    status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
    status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);


    //Create Element Tree
    status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
    ruleLog.Write("Tree root status = " + to_string(status));

    // TREE ALLOCATION
    status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
    ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
    ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
    ruleLog.Write("type status = " + to_string(status));

    //feature name
    status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
    status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, cDatumPointName));
    status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
    ruleLog.Write("feature name = " + to_string(status));

    //PRO_E_DPOINT_TYPE
    status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
    status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
    ruleLog.Write("type status = " + to_string(status));

    //Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);

    //ref
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
    status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
    status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);

    //
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);

    //Populating array element
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);

    //Point1
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);

    //Point1 Name
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
    ProStringToWstring(wide_string, "datum_PNT1");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);

    //PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);

    //PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);

    //PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);

    //Point2
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);

    //Point2 Name
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
    ProStringToWstring(wide_string_2, "datum_PNT2");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);

    ////PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);

    ////PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);

    ////PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);

    /* =============================================================== *\
    Create Model Selection Object
    \* =============================================================== */

    status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
    ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
    status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

    opts[0] = PRO_FEAT_CR_NO_OPTS;

    // Create Points
    status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
    ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

    status = ProArrayFree((ProArray*)&opts);
    status = ProElementFree(&elem_tree);
    status = ProSelectionFree(&reqMdlSel);

    ProSelection pnt_Sel;
    status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
    status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_SS_FAILED_ITEMS);
    //PRO_COLOR_SELECTED for green highlight
    ++dtmptcount;
    return 0;
}

#pragma pop
