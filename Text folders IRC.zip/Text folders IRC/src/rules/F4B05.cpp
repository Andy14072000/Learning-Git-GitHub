/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
MATHANPRASATH A	| 24-07-2023	|	V1_0_0		| F4B05 - REAR SUSPENSION RULES
==================================================================================================================*/
#include "F4B05.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER				| DEPENDENT MODULES		| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F4B05-002	| Himanshu Pachpute		| MF4B05				| Standard ARB attachment across platform based on mounting bolt size for Rear suspension
===================================================================================================================*/

#define DLG_IRF4B05_002				"dlg_IR_F4B05_002"
#define PB_RSELECT_IRF4B05_002		"pb_select"
#define PB_ROK_IRF4B05_002			"rule_ok_pb"
#define PB_RCANCEL_IRF4B05_002		"rule_cancel_pb"

string                          str_frame_bolts;
string                          str_axle_bolts;
vector<CompData_F4B05_002>      frame_bolts_vect;
vector<CompData_F4B05_002>      axle_bolts_vect;
vector<string>                  reqValuesFromCsv_IR_F4B05_002{};
vector<string>                  reqValuesFromCsv_IR_F4B05_002_1{};
vector<vector<string>>	        dbList2D_IRF4B05_002{};

ProError getReqValsFrom2DCsvData_IR_F4B05_002(int projCode, vector<string>& reqValsFromCsv1, vector<string>& reqValsFromCsv2)
{
    ruleLog.Write("----------------------------- getReqValsFrom2DCsvData_IR_F4B05_002 -----------------------------");

    for (int i = 1; i < dbList2D_IRF4B05_002.size(); ++i) {
        if (stoi(dbList2D_IRF4B05_002[i][2]) == projCode) {
            istringstream ss(dbList2D_IRF4B05_002[i][3]);
            istringstream ss1(dbList2D_IRF4B05_002[i][4]);
            string tok;
            string tok1;
            bool tokenFound = false;
            bool tokenFound1 = false;
            reqValsFromCsv1.clear();
            reqValsFromCsv2.clear();
            while (std::getline(ss, tok, ';')) {
                reqValsFromCsv1.push_back(tok);
                tokenFound = true;
            }
            while (std::getline(ss1, tok1, ';')) {
                reqValsFromCsv2.push_back(tok1);
                tokenFound1 = true;
            }
            if (!tokenFound)
                reqValsFromCsv1.push_back(dbList2D_IRF4B05_002[i][3]);
            if (!tokenFound1)
                reqValsFromCsv2.push_back(dbList2D_IRF4B05_002[i][4]);
        }
    }

    ruleLog.Write("reqValsFromCsv1.size(): " + to_string(reqValsFromCsv1.size()));
    ruleLog.Write("reqValsFromCsv2.size(): " + to_string(reqValsFromCsv2.size()));
    return PRO_TK_NO_ERROR;
}

int IRF4B05::IRF4B05_002(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF4B05::IRF4B05_002   ==========================");

    isUserQuits = false;
    double Computed_dia1{}, Computed_dia2{};
    SubModuleInfo _reqSMinfo;
    bool condcheck = false;
    bool condcheck1 = false;
    string remarkstring;


    double platform_width;
    for (int i = 0; i < subModulesList.size(); ++i) {
        if (subModulesList[i].name.find("F4B05") != string::npos) {
            _reqSMinfo = subModulesList[i];
            break;
        }
    }

    project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
    ruleLog.Write("Sub-module Name: " + _reqSMinfo.name);
    ruleLog.Write("Project Code: " + to_string(project_code));
    string projectC_str = to_string(project_code);
    dbList2D_IRF4B05_002 = getData2D("IRF4B05002.csv");

    //string con{};
    //for (const auto& row : dbList2D_IRF4B05_002) {
    //    for (const auto& element : row) {
    //        con += "\t" + string(element);
    //    }
    //    ruleLog.Write(con);
    //    con.clear();
    //}

    vector<string> projectCodes;
    for (int i = 1; i < dbList2D_IRF4B05_002.size(); ++i)
    {
        string tok1;
        istringstream ss1(dbList2D_IRF4B05_002[i][2]);
        while (getline(ss1, tok1, ','))
            projectCodes.push_back(tok1);
    }

    bool isProjectCodeFound = false;
    for (int i = 0; i < projectCodes.size(); i++) {
        if ((projectC_str.compare(projectCodes.at(i))) == 0) {
            isProjectCodeFound = true;
            break;
        }
    }

    string acceptance_Frame = "", acceptance_Axle = "";
    if (isProjectCodeFound == true) {
        getReqValsFrom2DCsvData_IR_F4B05_002(project_code, reqValuesFromCsv_IR_F4B05_002, reqValuesFromCsv_IR_F4B05_002_1);
        for (size_t i = 0; i < reqValuesFromCsv_IR_F4B05_002.size(); i++) {
            ruleLog.Write("reqValuesFromCsv_IR_A1A01_007: " + reqValuesFromCsv_IR_F4B05_002[i]);
            if (i != (reqValuesFromCsv_IR_F4B05_002.size() - 1)) {
                acceptance_Frame += reqValuesFromCsv_IR_F4B05_002[i] + ", ";
            }
            else {
                acceptance_Frame += reqValuesFromCsv_IR_F4B05_002[i] + ".";
            }
        }
        for (size_t i = 0; i < reqValuesFromCsv_IR_F4B05_002_1.size(); i++) {
            ruleLog.Write("reqValuesFromCsv_IR_A1A01_007_1: " + reqValuesFromCsv_IR_F4B05_002_1[i]);
            if (i != (reqValuesFromCsv_IR_F4B05_002_1.size() - 1)) {
                acceptance_Axle += reqValuesFromCsv_IR_F4B05_002_1[i] + ", ";
            }
            else {
                acceptance_Axle += reqValuesFromCsv_IR_F4B05_002[i] + ".";
            }
        }
    }
    else {
        _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "Project code " + string(projectC_str) + ", Not found in the database!");
        return 0;
    }

    status = ProUIDialogCreate(DLG_IRF4B05_002, DLG_IRF4B05_002);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF4B05_002, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF4B05_002, PB_RCANCEL_IRF4B05_002, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF4B05_002, PB_ROK_IRF4B05_002, (ProUIAction)ruleDlgOKaction, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF4B05_002, PB_RSELECT_IRF4B05_002, (ProUIAction)select_action_IRF4B05_002, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF4B05_002, &dlg_sts);
    status = ProUIDialogDestroy(DLG_IRF4B05_002);
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    ruleLog.Write("frame_bolts_vect.size(): " + to_string(frame_bolts_vect.size()));
    string rstring1 = "Computed diameter of Frame End Bolts\n";
    for (int i = 0; i < frame_bolts_vect.size(); i++) {
        status = ProGeomitemDiameterEval(frame_bolts_vect[i].ProSelection, &Computed_dia1);
        ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status) + "\tComputed_dia: " + to_string(Computed_dia1));
        ostringstream stream1{};
        stream1 << fixed << setprecision(2) << Computed_dia1;
        string formattedStandardValue = stream1.str();
        rstring1 += "\t\t\t\t\t" + string(frame_bolts_vect[i].Name) + "-->" + string(frame_bolts_vect[i].Description) + "-->" + to_string(frame_bolts_vect[i].ID) + ": " + formattedStandardValue + " mm.\n";
        for (int j = 0; j < reqValuesFromCsv_IR_F4B05_002.size(); j++) {
            if (Computed_dia1 == stod(reqValuesFromCsv_IR_F4B05_002[j])) {
                ruleLog.Write("Computed Diameter: " + to_string(Computed_dia1) + " matches Standard Diameter: " + reqValuesFromCsv_IR_F4B05_002[j]);
                condcheck = false;
                break;
            }
            else {
                ruleLog.Write("Computed Diameter: " + to_string(Computed_dia1) + " does not match Standard Diameter: " + reqValuesFromCsv_IR_F4B05_002[j]);
                condcheck = true;
            }
        }
    }

    ruleLog.Write("axle_bolts_vect.size(): " + to_string(axle_bolts_vect.size()));
    string rstring2 = "Computed diameter of Axle End Bolts\n";
    for (int i = 0; i < axle_bolts_vect.size(); i++) {
        status = ProGeomitemDiameterEval(axle_bolts_vect[i].ProSelection, &Computed_dia2);
        ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status) + "\tComputed_dia: " + to_string(Computed_dia2));
        ostringstream stream2{};
        stream2 << fixed << setprecision(2) << Computed_dia2;
        string formattedStandardValue1 = stream2.str();
        rstring2 += "\t\t\t\t\t" + string(axle_bolts_vect[i].Name) + "-->" + string(axle_bolts_vect[i].Description) + "-->" + to_string(axle_bolts_vect[i].ID) + ": " + formattedStandardValue1 + " mm.\n";
        for (int j = 0; j < reqValuesFromCsv_IR_F4B05_002_1.size(); j++) {
            if (Computed_dia2 == stod(reqValuesFromCsv_IR_F4B05_002_1[j])) {
                ruleLog.Write("Computed Diameter: " + to_string(Computed_dia2) + " matches Standard Diameter: " + reqValuesFromCsv_IR_F4B05_002_1[j]);
                condcheck1 = false;
                break;
            }
            else {
                ruleLog.Write("Computed Diameter: " + to_string(Computed_dia2) + " does not match Standard Diameter: " + reqValuesFromCsv_IR_F4B05_002_1[j]);
                condcheck1 = true;
            }
        }
    }

    remarkstring = rstring1 + rstring2 + "\nAcceptance Criteria for Frame End Bolts diameter (in mm): " + acceptance_Frame + "\nAcceptance Criteria for Axle End Bolts diameter (in mm): " + acceptance_Axle;

    final_res.remark = remarkstring;

    if (condcheck1 == false && condcheck == false)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    frame_bolts_vect.clear();
    axle_bolts_vect.clear();
    reqValuesFromCsv_IR_F4B05_002.clear();
    reqValuesFromCsv_IR_F4B05_002_1.clear();
    dbList2D_IRF4B05_002.clear();
    remarkstring.clear();
    acceptance_Frame.clear();
    acceptance_Axle.clear();
    rstring1.clear();
    rstring2.clear();


    return 0;
}

ProError select_action_IRF4B05_002(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- select_action_IRF4B05_002 -----------------------------");

    frame_bolts_vect.clear();
    axle_bolts_vect.clear();

    int                             curWinId;
    ProSelection* surf_part_Sels1 = nullptr;
    ProSelection* surf_part_Sels2 = nullptr;
    int                             n_sel1;
    int                             n_sel2;
    InterfaceRule                   irule;
    int                             n_frame_bolts = -1;
    int                             n_axle_bolts = -1;

    status = ProWindowCurrentGet(&curWinId);
    status = ProWindowRepaint(curWinId);
    status = ProUIDialogHide(DLG_IRF4B05_002);

    auto handleSelection = [&](const char* prompt1, const char* prompt2, char* filter, ProSelection*& selections, int& default_selections, int& n_selections, std::vector<CompData_F4B05_002>& compDataVector) -> bool {
        InterfaceRule forPrompt;
        forPrompt.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, prompt1, prompt2);

        status = ProSelect(filter, default_selections, nullptr, nullptr, nullptr, nullptr, &selections, &n_selections);
        ruleLog.Write("Proselect: " + std::to_string(status) + "\tNo. of Selections: " + std::to_string(n_selections));

        if (n_selections < 2 || status != PRO_TK_NO_ERROR) {
            irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs in the Selection!. Refer help document for details.");
            status = ProUIDialogShow(DLG_IRF4B05_002);
            return false;
        }

        for (size_t i = 0; i < n_selections; ++i) {
            ProModelitem mdl_item{}, mdl_item_desc{}, mdl_item_hide{}, mdl_item_owner{};
            wchar_t w_name[PRO_PATH_SIZE], Ext[PRO_NAME_SIZE];
            ProParameter param_desc;
            ProParamvalue param_value;
            int lastCompID = -1;
            ProAsmcomppath asm_comp_path;
            CompData_F4B05_002 comp_data{};

            status = ProSelectionModelitemGet(selections[i], &mdl_item);
            status = ProSelectionAsmcomppathGet(selections[i], &asm_comp_path);
            status = ProSelectionCopy(selections[i], &comp_data.ProSelection);
            status = ProMdlMdlnameGet(mdl_item.owner, w_name);
            status = ProMdlToModelitem(mdl_item.owner, &mdl_item_desc);
            status = ProMdlExtensionGet(mdl_item.owner, Ext);
            status = ProParameterInit(&mdl_item_desc, L"DESCRIPTION", &param_desc);
            status = ProParameterValueWithUnitsGet(&param_desc, &param_value, NULL);

            for (int k = 0; k < asm_comp_path.table_num; ++k)
                lastCompID = asm_comp_path.comp_id_table[k];

            comp_data.ID = lastCompID;
            ProWstringToString(comp_data.Name, w_name);
            ProWstringToString(comp_data.Description, param_value.value.s_val);
            ProWstringToString(comp_data.Ext, Ext);
            compDataVector.push_back(comp_data);

            ruleLog.Write("Name: " + string(comp_data.Name) + "." + string(comp_data.Ext) +
                "\tDescription: " + string(comp_data.Description) +
                "\tFeat_ID: " + to_string(comp_data.ID));
        }
        return true;
    };

    // Frame End Bolt Selection
    if (!handleSelection("For Frame End Bolt Selection!", "Select the surface on the bolts.", "surface", surf_part_Sels1, n_frame_bolts, n_sel1, frame_bolts_vect))
        return PRO_TK_NO_ERROR;

    // Axle End Bolt Selection
    if (!handleSelection("For Axle End Bolt Selection!", "Select the surface on the bolts.", "surface", surf_part_Sels2, n_axle_bolts, n_sel2, axle_bolts_vect))
        return PRO_TK_NO_ERROR;

    status = ProUIPushbuttonEnable(DLG_IRF4B05_002, PB_ROK_IRF4B05_002);
    status = ProUIDialogShow(DLG_IRF4B05_002);
    return PRO_TK_NO_ERROR;
}



/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES			| DESCRIPTION
------------------------------------------------------------------------------------------------------------------
IR-F4B05-003	| MATHANPRASATH A	| MF4B05; MF4B02; MF4B03;	|Standard antiroll bar and its attachment across platform based on application.
									  MF4B01; MF4B07; MF4B08; 
									  MF4B09
===================================================================================================================*/
#define DLG_IRF4B05_003		"dlg_IR_F4B05_003"
#define CommitOK            "CommitOK"
#define CommitCancel		"CommitCancel"
#define PB_SELECT           "select_pb"

ProSelection* sel;
double dia_rear;
int num_sel_rear;
int IRF4B05::IRF4B05_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF4B05::IRF4B05_003   ==========================");
	ProCharPath rmrk1{};
	boolean found;
	string ARB_1,ARB_2;
	Utils utl;

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF4B05_003, DLG_IRF4B05_003);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF4B05_003, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4B05_003, PB_SELECT, (ProUIAction)select_action_IRF4B05_003, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4B05_003, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4B05_003, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF4B05_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF4B05_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

	// get the submodule name from list
	for (int i = 0; i < subModulesList.size(); ++i)
	{
		if (subModulesList[i].name.find("F4B05") != string::npos)
		{
			_reqSMinfo = subModulesList[i];
			break;
		}
	}

	//get the project code of opened submodule
	project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
	ruleLog.Write("project code: " + to_string(project_code));

	//Fetch the data from CSV 
	vector<string> reqValsFromCsv;
	vector<string>dia_2;


	//dia1
	utl.getReqValsFrom2DCsvData("IRF4B05003.csv",2,3, project_code, reqValsFromCsv);
	ruleLog.Write("getReqValsFrom2DCsvData1: " + to_string(status));
	ruleLog.Write("Size of vector1 is :" + to_string(reqValsFromCsv.size()));

	//Printing the fetched data of 1st dia
	for (int i = 0; i < reqValsFromCsv.size(); ++i)
	{
		double stand;
		ruleLog.Write(reqValsFromCsv.at(i));
		ARB_1 = reqValsFromCsv.at(i);
		ruleLog.Write("Expec Dia1 :" + ARB_1);
	}

	//dia2
	utl.getReqValsFrom2DCsvData("IRF4B05003.csv",2, 4, project_code, dia_2);
	ruleLog.Write("getReqValsFrom2DCsvData2: " + to_string(status));
	ruleLog.Write("Size of vector2 is :" + to_string(dia_2.size()));

	//Printing the fetched data of 1st dia
	for (int i = 0; i < dia_2.size(); ++i)
	{
		double stand;
		ruleLog.Write(dia_2.at(i));
		ARB_2 = dia_2.at(i);
		ruleLog.Write("Expec Dia2 :" + ARB_2);
	}
	

	status = ProGeomitemDiameterEval(sel[0], &dia_rear);
	ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status) + "\nDiameter :" + to_string(dia_rear));
	string target = to_string(dia_rear);
	ruleLog.Write("Dia :" + target);
	if ((target >= ARB_1)&&(target <= ARB_2))
	{
		found = true;
	}
	else
	{
		found = false;
	}
	if (true)
	{
		final_res.result = "PASS";
		sprintf(remark, "Measured value: Diameter of the Anti Roll Bar is %0.2lfmm.\nAcceptance criteria : Diameter of the Standard Anti Roll Bar is %smm - %smm.", dia_rear, ARB_1,ARB_2);
		final_res.remark = remark;
	}

	else
	{
		final_res.result = "FAIL";
		sprintf(remark, "Measured value: Diameter of the Anti Roll Bar is %0.2lfmm.\nAcceptance criteria : Diameter of the Standard Anti Roll Bar is %smm - %smm.", dia_rear, ARB_1, ARB_2);
		final_res.remark = remark;
	}


	status = ProUIDialogShow(DLG_IRC_MAIN);


	if (isUserQuits)
		return -1;

	return 0;
}

ProError select_action_IRF4B05_003(char* dialog, char* component, ProAppData data)
{
	status = ProSelect((char*)"surface", 1, NULL, NULL, NULL, NULL, &sel, &num_sel_rear);
	ruleLog.Write("ProSelect: " + to_string(status));

	InterfaceRule _inrule;

	if (status == PRO_TK_USER_ABORT)
	{
		//_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, CommitOK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}
	else if (num_sel_rear < 1 || status != PRO_TK_NO_ERROR)
	{
		_inrule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, CommitOK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}

	if (status == PRO_TK_NO_ERROR)
	{
		status = ProUIPushbuttonEnable(DLG_IRF4B05_003, CommitOK);
	}

	return status;
}