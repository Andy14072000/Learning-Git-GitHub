﻿/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	| V1_0_0		| A1A01 - TIPPER BODY RULES
==================================================================================================================*/
#include "A1A01.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-A1A01-006	| Atharva Patil		| MA1A01			| Platform wise common frame width to be ensured. 
===================================================================================================================*/
#define DLG_IRA1A01_006 "dlg_IR_A1A01_006"
#define PB_ROK			"rule_ok_pb"
#define PB_RSELECT		"pb_select"
#define PB_RCANCEL		"rule_cancel_pb"
ProSelection *tipperBodySurfSels;

int IRA1A01::IRA1A01_006(ruleResult &final_res)
{
	ruleLog.Write("==========================   IRA1A01::IRA1A01_006   ==========================");

	double platform_width;
	for (int i = 0; i < subModulesList.size(); ++i){
		if(subModulesList[i].name.find("A1A01") != string::npos){
			_reqSMinfo = subModulesList[i];
			break;
		}
	}

	project_code = stoi(string(_reqSMinfo.name).substr(0,4));
	ruleLog.Write("Project Code: "+ to_string(project_code));

	/*vector<int> reqValsFromCsv;
	getReqValsFrom2DCsvData("IRA1A01006.csv", 2, 3, project_code, reqValsFromCsv);*/
	vector<string> reqValsFromCsv;
	getReqValsFrom2DCsvData("IRA1A01006.csv", 2, 3, project_code, reqValsFromCsv);


	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRA1A01_006, DLG_IRA1A01_006);
	status = ProUIDialogAboveactivewindowSet(DLG_IRA1A01_006, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRA1A01_006, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRA1A01_006, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRA1A01_006, PB_RSELECT, (ProUIAction)select_action_IRA1A01_006, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRA1A01_006, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRA1A01_006);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if(isUserQuits)
		return -1;
	status = measureDistanceBetweenSurfaces(tipperBodySurfSels[0], tipperBodySurfSels[1], platform_width);
	platform_width = round(platform_width*100)/100;	// rounding the value to two decimal places
	ruleLog.Write("platform_width(rounded): " + to_string(platform_width));

	if(status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT){
		UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selected surfaces.");
		return -1;
	}

	for (auto val: reqValsFromCsv)
	{
		acceptance_criteria.append(val);
		acceptance_criteria.append(" mm, ");

		if(compareFloat(stod(val), platform_width)){
			isRightValue = true;
		}
	}

	sprintf(remark, "Measured value = %0.2lf mm; Acceptance criteria = %0.2lf mm.", platform_width, stod(acceptance_criteria));
	final_res.remark = string(remark);

	// DECLARE RESULT
	if(isRightValue){
		final_res.result = "PASS";
	}
	else{
		final_res.result = "FAIL";
	}

	ruleLog.Write("status: "+ final_res.result);
	ruleLog.Write("remark: "+ final_res.remark);

	reqValsFromCsv.clear();
	return 0;
	
}

ProError select_action_IRA1A01_006(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("--------------------------  select_action_IRA1A01_006  --------------------------");
    int n_sels;
    InterfaceRule _irule;

    status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &tipperBodySurfSels, &n_sels);
    if (status == PRO_TK_NO_ERROR && n_sels > 1) {
        status = ProUIPushbuttonEnable(dialog, PB_ROK);
    }
    else
    {
        _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
        status = ProUIPushbuttonDisable(dialog, PB_ROK);
        return status;
    }

	return status;
}

/*===================================================================================================subFrmModel===============
RULE ID			| DEVELOPER				| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-A1A01-007	| Himanshu Pachpute		| MA1A01			| Platform wise common sub frame start point.
===================================================================================================================*/

#define DLG_IRA1A01_007					"dlg_IR_A1A01_007"
#define PB_RULE_RUN_IRA1A01_007			"rule_run_pb"
#define PB_RCANCEL_IRA1A01_007			"rule_cancel_pb"



struct SelectionInfo_IRA1A01_007 {
    ProSelection    p_selection{};
    char            Description[PRO_PATH_SIZE]{};
    char            Name[PRO_PATH_SIZE]{};
    int             id{};
};

vector<feat_id_data>            featIDDataArr{};
Asm_model                       AsmSubFrmModel[1000]{};
Asm_model                       subFrmModel[1000]{};
SelectionInfo_IRA1A01_007       Subframe_Selection{};

int ModelsCount_IRA1A01_007{};
int	AsmModelCount_IRA1A01_007{};
int MdlCount_IRA1A01_007{};
int	OwnerFeatID_IRA1A01_007{};
int Levels_IRA1A01_007{};

vector<vector<string>>	dbList2D_IR_A1A01_007{};
vector<string>          reqValuesFromCsv_IR_A1A01_007{};

int IRA1A01::IRA1A01_007(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRA1A01::IRA1A01_007   ==========================");

    double platform_width;
    for (int i = 0; i < subModulesList.size(); ++i){
    	if(subModulesList[i].name.find("A1A01") != string::npos){
    		_reqSMinfo = subModulesList[i];
    		break;
    	}
    }

    project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
    ruleLog.Write("Sub-module Name: " + _reqSMinfo.name);
    ruleLog.Write("Project Code: " + to_string(project_code));
    string projectC_str = to_string(project_code);

    dbList2D_IR_A1A01_007 = getData2D("IRA1A01007.csv");
    vector<string> projectCodes;
    for (int i = 1; i < dbList2D_IR_A1A01_007.size(); ++i)
    {
        string tok1;
        istringstream ss1(dbList2D_IR_A1A01_007[i][1]);
        while (getline(ss1, tok1, ','))
            projectCodes.push_back(tok1);            
    }

    bool isProjectCodeFound = false;
    for (int i = 0; i < projectCodes.size(); i++) {
        if ((projectC_str.compare(projectCodes.at(i))) == 0) {
            isProjectCodeFound = true;
            break;
        }
    }
   
    if (isProjectCodeFound == true) {
        getReqValsFrom2DCsvData_IRA1A01_007(project_code, reqValuesFromCsv_IR_A1A01_007);
        for(size_t i = 0; i < reqValuesFromCsv_IR_A1A01_007.size(); i++)
            ruleLog.Write("reqValuesFromCsv_IR_A1A01_007: " + reqValuesFromCsv_IR_A1A01_007[i]);
    }
    else{
        _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "Project code " + string(projectC_str) + ", Not found in the database!");
        return 0;
    }

    status = ProUIDialogCreate(DLG_IRA1A01_007, DLG_IRA1A01_007);
    status = ProUIDialogAboveactivewindowSet(DLG_IRA1A01_007, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRA1A01_007, PB_RCANCEL_IRA1A01_007, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRA1A01_007, PB_RULE_RUN_IRA1A01_007, (ProUIAction)ruleDlgOKaction, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRA1A01_007, &dlg_sts);
    status = ProUIDialogDestroy(DLG_IRA1A01_007);
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    ProMdl Mdl{};
    status = ProMdlCurrentGet(&Mdl);

    curMdl = Mdl;
    Levels_IRA1A01_007 = 1;
    subFrmModel[0].Model = Mdl;
    subFrmModel[0].Model_feat_id = 0;
    ModelsCount_IRA1A01_007 = 1;
    AsmModelCount_IRA1A01_007 = 0;

    while (ModelsCount_IRA1A01_007 > 0) {
        for (int a = 0; a < ModelsCount_IRA1A01_007; ++a) {
            OwnerFeatID_IRA1A01_007 = subFrmModel[a].Model_feat_id;
            status = ProSolidFeatVisit((ProSolid)subFrmModel[a].Model, (ProFeatureVisitAction)PartNameAndIdVisitAction_IRA1A01_007, compsFilter, NULL);
        }

        if (AsmModelCount_IRA1A01_007 > 0) {
            ++Levels_IRA1A01_007;
            for (int b = 0; b < AsmModelCount_IRA1A01_007; ++b) {
                subFrmModel[b].Model = AsmSubFrmModel[b].Model;
                subFrmModel[b].Model_feat_id = AsmSubFrmModel[b].Model_feat_id;
            }
            ModelsCount_IRA1A01_007 = AsmModelCount_IRA1A01_007;
            AsmModelCount_IRA1A01_007 = 0;
        }
        else
            ModelsCount_IRA1A01_007 = 0;
    }

    char FACLplnName[PRO_NAME_SIZE] = "ASM_YZ";
    char cReqMdlPath[PRO_PATH_SIZE];
    strcpy(cReqMdlPath, cCurMdlPath);
    strcat(cReqMdlPath, cCurMdlName);
    strcat(cReqMdlPath, ".asm");
    ruleLog.Write("cReqMdlPath: " + string(cReqMdlPath));

    ProPath wReqMdlPath;
    ProStringToWstring(wReqMdlPath, cReqMdlPath);

    ProMdl reqMdl;
    status = ProMdlnameRetrieve(wReqMdlPath, PRO_MDLFILE_ASSEMBLY, &reqMdl);
    ruleLog.Write("plane_name: " + string(FACLplnName));
    wchar_t wPlaneName[PRO_NAME_SIZE];
    ProStringToWstring(wPlaneName, const_cast<char*> (FACLplnName));

    ProModelitem planeMdlitem;
    status = ProModelitemByNameInit(reqMdl, PRO_SURFACE, wPlaneName, &planeMdlitem);
    if (status != PRO_TK_NO_ERROR)
        _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Missing!", "Plane missing: " + string(FACLplnName) + ". Refer help document for details.");

    ProSelection planeSel;
    status = ProSelectionAlloc(NULL, &planeMdlitem, &planeSel);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    Pro2dPnt param_1, param_2;
    Pro3dPnt pnt_1, pnt_2;
    double distance{};
    status = ProSelectionWithOptionsDistanceEval(planeSel, PRO_B_TRUE, Subframe_Selection.p_selection, PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance);
    ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(distance));
    if (status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT || status == PRO_TK_GENERAL_ERROR)
        _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selections.");

    bool conditionCheck{ false };
    for (size_t i = 0; i < reqValuesFromCsv_IR_A1A01_007.size(); i++) {
        if (stoi(reqValuesFromCsv_IR_A1A01_007[i]) == round(distance)) {
            conditionCheck = true;
            break;
        }
    }

    string standard_value{};
    for (size_t i = 0; i < reqValuesFromCsv_IR_A1A01_007.size(); i++) {
        ostringstream stream1{};
        double standardValue = stod(reqValuesFromCsv_IR_A1A01_007[i]);
        
        string formattedStandardValue = doubleToString(standardValue);
        standard_value += " " + formattedStandardValue + "mm,";
    }

    
    string formattedDistance = doubleToString(distance);
    final_res.remark = "Distance between FACL Plane(" + string(FACLplnName) + ") and " + string(Subframe_Selection.Name) + "(" + string(Subframe_Selection.Description) + ")(Feat ID: " + to_string(Subframe_Selection.id) + "): " + string(formattedDistance) + "mm" +
        "\n\nAcceptance Criteria: For Project Code(" + projectC_str + "), Distance should be" + standard_value;

    if (conditionCheck == true)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    featIDDataArr.clear();
    memset(&subFrmModel, 0, sizeof(subFrmModel));
    memset(&AsmSubFrmModel, 0, sizeof(AsmSubFrmModel));
    reqValuesFromCsv_IR_A1A01_007.clear();
    dbList2D_IR_A1A01_007.clear();

    return 0;
}

ProError getReqValsFrom2DCsvData_IRA1A01_007(int projCode, vector<string>& reqValsFromCsv)
{
    ruleLog.Write("----------------------------- getReqValsFrom2DCsvData_IRA1A01_007 -----------------------------");

    for (int i = 1; i < dbList2D_IR_A1A01_007.size(); ++i) {
        if (stoi(dbList2D_IR_A1A01_007[i][1]) == projCode) {
            std::istringstream ss(dbList2D_IR_A1A01_007[i][2]);
            std::string tok;
            bool tokenFound = false;
            while (std::getline(ss, tok, ';')) {
                reqValsFromCsv.push_back(tok);
                tokenFound = true;
            }

            if (!tokenFound)
                reqValsFromCsv.push_back(dbList2D_IR_A1A01_007[i][2]);
        }
    }
    return PRO_TK_NO_ERROR;
}

ProError PartNameAndIdVisitAction_IRA1A01_007(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    //ruleLog.Write("----------------------------- PartNameAndIdVisitAction_IRA1A01_007 -----------------------------");

    SelectionInfo_IRA1A01_007 CompSelection;
    ProMdlfileType    comp_type;
    ProFamilyMdlName  comp_name;
    status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
    char part_no[PRO_PATH_SIZE]{};
    ProWstringToString(part_no, comp_name);
    //ruleLog.Write("ProMdlName: " + string(part_no));

    ++MdlCount_IRA1A01_007;

    ProMdl model;
    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);

    ProMdlType type;
    status = ProMdlTypeGet(model, &type);

    wchar_t wFeatName[PRO_NAME_SIZE]{};
    status = ProMdlMdlnameGet(model, wFeatName);
    ProWstringToString(CompSelection.Name, wFeatName);
    //ruleLog.Write("CompSelection.Name: " + string(CompSelection.Name));

    ProModelitem modelItem;
    status = ProMdlToModelitem(model, &modelItem);

    ProName      pDescName = L"DESCRIPTION";
    ProParameter pDesc;
    status = ProParameterInit(&modelItem, pDescName, &pDesc);

    ProParamvalue pvDesc;
    status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);

    ProWstringToString(CompSelection.Description, pvDesc.value.s_val);
    //ruleLog.Write("CompSelection.Description: " + string(CompSelection.Description));

    CompSelection.id = p_feature->id;
    //ruleLog.Write("CompSelection.id: " + to_string(CompSelection.id));

    feat_id_data  _FeatIDdata;
    if (Levels_IRA1A01_007 == 1) {
        _FeatIDdata.feat_ids[0] = p_feature->id;
        _FeatIDdata.level = Levels_IRA1A01_007;
        featIDDataArr.push_back(_FeatIDdata);
    }
    else {
        for (int j = 0; j < featIDDataArr.size(); ++j) {
            if (featIDDataArr[j].feat_ids[Levels_IRA1A01_007 - 2] == OwnerFeatID_IRA1A01_007) {
                feat_id_data	owner_feat_id_data = featIDDataArr[j];
                for (int i = 0; i < Levels_IRA1A01_007 - 1; ++i) {
                    _FeatIDdata.feat_ids[i] = owner_feat_id_data.feat_ids[i];
                }
                _FeatIDdata.feat_ids[Levels_IRA1A01_007 - 1] = p_feature->id;
                _FeatIDdata.level = Levels_IRA1A01_007;
                break;
            }
        }
        featIDDataArr.push_back(_FeatIDdata);
    }

    bool compfound = false;
    if (strcmp(CompSelection.Description, "SUBFRAME ASSY ") == 0 || strcmp(CompSelection.Description, "SUBFRAME ASSY") == 0) {

        compfound = true;
        ProIdTable			comp_id_table;
        int					table_num;
        ProAsmcomppath		p_comp_path;
        ProModelitem		p_modelitem;

        table_num = Levels_IRA1A01_007;

        for (int m = 0; m < Levels_IRA1A01_007; ++m)
            comp_id_table[m] = _FeatIDdata.feat_ids[m];

        status = ProMdlToModelitem(model, &p_modelitem);

        ProMdl curMdl;
        status = ProMdlCurrentGet(&curMdl);
        status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);

        ProSelection p_selection;
        status = ProSelectionAlloc(&p_comp_path, &p_modelitem, &CompSelection.p_selection);
        //ruleLog.Write("ProSelectionAlloc: " + to_string(status));

        if (status == PRO_TK_NO_ERROR)
            Subframe_Selection = CompSelection;
    }

    if (type == PRO_MDL_ASSEMBLY && compfound == false)
    {
        AsmSubFrmModel[AsmModelCount_IRA1A01_007].Model = model;
        AsmSubFrmModel[AsmModelCount_IRA1A01_007].Model_feat_id = p_feature->id;
        AsmModelCount_IRA1A01_007 += 1;
    }

    return PRO_TK_NO_ERROR;
}


/*==================================================================================================================
RULE ID			| DEVELOPER				| DEPENDENT MODULES				| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-A1A01-002	| Himanshu Pachpute		| MA1A01; MF1A01; MA1A02		| First mtg to be within 250mm from sub frame start, Resilient Mounting span should be with in 750mm & rigid mounting span to be within 1200mm
===================================================================================================================*/

#define DLG_IR_A1A01_002				"dlg_IR_A1A01_002"
#define PB_OK_IR_A1A01_002			    "rule_ok_pb"
#define PB_CANCEL_IR_A1A01_002		    "rule_cancel_pb"
#define PB_LH_SELECT_IR_A1A01_002		"LH_pb_select"
#define PB_RH_SELECT_IR_A1A01_002		"RH_pb_select"
#define OP_MENU_LH_1                    "OPMenu_LH1"
#define OP_MENU_LH_2                    "OPMenu_LH2"
#define OP_MENU_RH_1                    "OPMenu_RH1"
#define OP_MENU_RH_2                    "OPMenu_RH2"

struct CompData_A1A01_002 {
    ProSelection    ProSelection;
    char            Name[PRO_PATH_SIZE];
    char            Description[PRO_PATH_SIZE];
    int             ID;
};

struct Clearance_Data {
    ProSelection    ProSelection_comp1;
    ProSelection    ProSelection_comp2;
    double          Distance;
};

vector<CompData_A1A01_002> CompDataVect_A1A01_002_LH{}, CompDataVect_A1A01_002_RH{};
int LH1, LH2, RH1, RH2;
string str1, str2, str3, str4;

int IRA1A01::IRA1A01_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRA1A01::IRA1A01_002   ==========================");

    string str5, str6;
    Pro2dPnt        param_11, param_21, param_12, param_22;
    Pro3dPnt        pnt_11, pnt_21, pnt_12, pnt_22;
    Clearance_Data distance1{}, distance2{};
    Clearance_Data StartingPointLH{}, StartingPointRH{};
    vector<Clearance_Data> clearanceVect_Resilient_bkt_LH{}, clearanceVect_Resilient_bkt_RH{}, clearanceVect_Rigid_bkt_LH{}, clearanceVect_Rigid_bkt_RH{};
    bool Check1 = false, Check2 = false, Check3 = false;
    vector<ProSelection> ProSel_Highlite{};

    status = ProUIDialogCreate(DLG_IR_A1A01_002, DLG_IR_A1A01_002);
    status = ProUIPushbuttonDisable(DLG_IR_A1A01_002, PB_OK_IR_A1A01_002);
    status = ProUIPushbuttonDisable(DLG_IR_A1A01_002, PB_LH_SELECT_IR_A1A01_002);
    status = ProUIPushbuttonDisable(DLG_IR_A1A01_002, PB_RH_SELECT_IR_A1A01_002);
    status = ProUIOptionmenuDisable(DLG_IR_A1A01_002, OP_MENU_LH_2);
    status = ProUIOptionmenuDisable(DLG_IR_A1A01_002, OP_MENU_RH_1);
    status = ProUIOptionmenuDisable(DLG_IR_A1A01_002, OP_MENU_RH_2);

    status = ProUIDialogAboveactivewindowSet(DLG_IR_A1A01_002, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IR_A1A01_002, PB_CANCEL_IR_A1A01_002, (ProUIAction)ruleDlgCloseAction_A1A01_002, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IR_A1A01_002, PB_OK_IR_A1A01_002, (ProUIAction)ruleDlgOKaction_A1A01_002, NULL);
    status = ProUIOptionmenuSelectActionSet(DLG_IR_A1A01_002, OP_MENU_LH_1, (ProUIAction)Dropdown_Selection_LH_1, NULL);
    status = ProUIOptionmenuSelectActionSet(DLG_IR_A1A01_002, OP_MENU_LH_2, (ProUIAction)Dropdown_Selection_LH_2, NULL);
    status = ProUIOptionmenuSelectActionSet(DLG_IR_A1A01_002, OP_MENU_RH_1, (ProUIAction)Dropdown_Selection_RH_1, NULL);
    status = ProUIOptionmenuSelectActionSet(DLG_IR_A1A01_002, OP_MENU_RH_2, (ProUIAction)Dropdown_Selection_RH_2, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_IR_A1A01_002, PB_LH_SELECT_IR_A1A01_002, (ProUIAction)LH_select_action_IRA1A01_002, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_IR_A1A01_002, PB_RH_SELECT_IR_A1A01_002, (ProUIAction)RH_select_action_IRA1A01_002, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IR_A1A01_002, &dlg_sts);
    status = ProUIDialogDestroy(DLG_IR_A1A01_002);
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    str6 = "Distance between components on LH side\n";
    for (size_t l = 0; l < CompDataVect_A1A01_002_LH.size() - 1; l++) {
        status = ProSelectionWithOptionsDistanceEval(CompDataVect_A1A01_002_LH[l].ProSelection, PRO_B_TRUE, CompDataVect_A1A01_002_LH[l + 1].ProSelection, PRO_B_TRUE, param_11, param_21, pnt_11, pnt_21, &distance1.Distance);
        ruleLog.Write("ProSelectionWithOptionsDistanceEvalLH: " + to_string(status) + "\tDistance: " + to_string(distance1.Distance));

        status = ProSelectionCopy(CompDataVect_A1A01_002_LH[l].ProSelection, &distance1.ProSelection_comp1);
        status = ProSelectionCopy(CompDataVect_A1A01_002_LH[l + 1].ProSelection, &distance1.ProSelection_comp2);

       
        str6 += "\t" + string(CompDataVect_A1A01_002_LH[l].Name) + " [" + string(CompDataVect_A1A01_002_LH[l].Description) + "] [" + 
            to_string(CompDataVect_A1A01_002_LH[l].ID) + "] and \n\t\t\t\t\t" + string(CompDataVect_A1A01_002_LH[l + 1].Name) + " [" + 
            string(CompDataVect_A1A01_002_LH[l + 1].Description) + "] [ID: " + to_string(CompDataVect_A1A01_002_LH[l + 1].ID) + "] is " + doubleToString(distance1.Distance) + "mm.\n";

        if (l == 0)
            StartingPointLH = distance1;
        else if (l > 0 && l <= LH1)
            clearanceVect_Resilient_bkt_LH.push_back(distance1);
        else
            clearanceVect_Rigid_bkt_LH.push_back(distance1);
    }

    str6 += "\nDistance between components on RH side\n";
    for (size_t m = 0; m < CompDataVect_A1A01_002_RH.size() - 1; m++) {
        status = ProSelectionWithOptionsDistanceEval(CompDataVect_A1A01_002_RH[m].ProSelection, PRO_B_TRUE, CompDataVect_A1A01_002_RH[m + 1].ProSelection, PRO_B_TRUE, param_12, param_22, pnt_12, pnt_22, &distance2.Distance);
        ruleLog.Write("ProSelectionWithOptionsDistanceEvalRH: " + to_string(status) + "\tDistance: " + to_string(distance2.Distance));

        status = ProSelectionCopy(CompDataVect_A1A01_002_RH[m].ProSelection, &distance2.ProSelection_comp1);
        status = ProSelectionCopy(CompDataVect_A1A01_002_RH[m + 1].ProSelection, &distance2.ProSelection_comp2);

        
        str6 += "\t" + string(CompDataVect_A1A01_002_RH[m].Name) + " [" + string(CompDataVect_A1A01_002_RH[m].Description) + "] [" + 
            to_string(CompDataVect_A1A01_002_RH[m].ID) + "] and \n\t\t\t\t\t" + string(CompDataVect_A1A01_002_RH[m + 1].Name) + " [" + 
            string(CompDataVect_A1A01_002_RH[m + 1].Description) + "] [ID: " + to_string(CompDataVect_A1A01_002_RH[m + 1].ID) + "] is " + doubleToString(distance2.Distance) + "mm. \n";

        if (m == 0)
            StartingPointRH = distance2;
        else if (m > 0 && m <= RH1)
            clearanceVect_Resilient_bkt_RH.push_back(distance2);
        else
            clearanceVect_Rigid_bkt_RH.push_back(distance2);
    }

    if (StartingPointLH.Distance > 250.00) {
        ProSel_Highlite.push_back(StartingPointLH.ProSelection_comp1);
        ProSel_Highlite.push_back(StartingPointLH.ProSelection_comp2);
        Check1 = true;
    }
    if (StartingPointRH.Distance > 250.00) {
        ProSel_Highlite.push_back(StartingPointRH.ProSelection_comp1);
        ProSel_Highlite.push_back(StartingPointRH.ProSelection_comp2);
        Check1 = true;
    }
        
    for (size_t i = 0; i < clearanceVect_Resilient_bkt_LH.size(); i++) {
        if (clearanceVect_Resilient_bkt_LH[i].Distance > 750.00) {
            ProSel_Highlite.push_back(clearanceVect_Resilient_bkt_LH[i].ProSelection_comp1);
            ProSel_Highlite.push_back(clearanceVect_Resilient_bkt_LH[i].ProSelection_comp2);
        }
    }
    for (size_t i = 0; i < clearanceVect_Resilient_bkt_LH.size(); i++) {
        if (clearanceVect_Resilient_bkt_LH[i].Distance > 750.00) {
            Check2 = true;
            break;
        }
    }
 
    for (size_t i = 0; i < clearanceVect_Resilient_bkt_RH.size(); i++) {
        if (clearanceVect_Resilient_bkt_RH[i].Distance > 750.00) {
            ProSel_Highlite.push_back(clearanceVect_Resilient_bkt_RH[i].ProSelection_comp1);
            ProSel_Highlite.push_back(clearanceVect_Resilient_bkt_RH[i].ProSelection_comp2);
        }
    }
    for (size_t i = 0; i < clearanceVect_Resilient_bkt_RH.size(); i++) {
        if (clearanceVect_Resilient_bkt_RH[i].Distance > 750.00) {
            Check2 = true;
            break;
        }
    }

    for (size_t i = 0; i < clearanceVect_Rigid_bkt_LH.size(); i++) {
        if (clearanceVect_Rigid_bkt_LH[i].Distance > 1200.00) {
            ProSel_Highlite.push_back(clearanceVect_Rigid_bkt_LH[i].ProSelection_comp1);
            ProSel_Highlite.push_back(clearanceVect_Rigid_bkt_LH[i].ProSelection_comp2);
        }
    }
    for (size_t i = 0; i < clearanceVect_Rigid_bkt_LH.size(); i++) {
        if (clearanceVect_Rigid_bkt_LH[i].Distance > 1200.00) {
            Check2 = true;
            break;
        }
    }

    for (size_t i = 0; i < clearanceVect_Rigid_bkt_RH.size(); i++) {
        if (clearanceVect_Rigid_bkt_RH[i].Distance > 1200.00) {
            ProSel_Highlite.push_back(clearanceVect_Rigid_bkt_RH[i].ProSelection_comp1);
            ProSel_Highlite.push_back(clearanceVect_Rigid_bkt_RH[i].ProSelection_comp2);
        }
    }
    for (size_t i = 0; i < clearanceVect_Rigid_bkt_RH.size(); i++) {
        if (clearanceVect_Rigid_bkt_RH[i].Distance > 1200.00) {
            Check2 = true;
            break;
        }
    }

    for (size_t k = 0; k < ProSel_Highlite.size(); k++) {
        status = ProSelectionHighlight(ProSel_Highlite[k], PRO_COLOR_HIGHLITE);
        ruleLog.Write("ProSelectionHighlight: " + to_string(status));
    }

    str5 = "No. of Resilient Bracket on LH side: " + str1 + " and No. of Rigid Bracket on LH side: " + str2 + "\nNo. of Resilient Bracket on RH side: " + str3 + " and No. of Rigid Bracket on RH side: " + str4;
    str6 += "\n\nAcceptance Criteria: \n\tFirst mtg to be within 250.00mm from SUBFRAME_ASSY start,\n\tResilient Mounting span should be with in 750.00mm and \n\tRigid mounting span to be within 1200.00mm";
    final_res.remark = str5 + "\n\n" + str6;

    if (Check1 == false && Check2 == false && Check3 == false)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    CompDataVect_A1A01_002_LH.clear();
    CompDataVect_A1A01_002_RH.clear();
    clearanceVect_Resilient_bkt_LH.clear();
    clearanceVect_Resilient_bkt_RH.clear();
    clearanceVect_Rigid_bkt_LH.clear();
    clearanceVect_Rigid_bkt_RH.clear();
    ProSel_Highlite.clear();
	return 0;
}

ProError LH_select_action_IRA1A01_002(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- LH_select_action_IRA1A01_002 -----------------------------");

    CompDataVect_A1A01_002_LH.clear();
    CompData_A1A01_002 LH_Comps{};
    int curWinId{}, n_sel{}, nos_s = LH1 + LH2 + 1;
    ProSelection* surf_part_Sels = nullptr;

    status = ProWindowCurrentGet(&curWinId);
    status = ProWindowRepaint(curWinId);
    status = ProUIDialogHide(DLG_IR_A1A01_002);
    status = ProSelect("surface", nos_s, NULL, NULL, NULL, NULL, &surf_part_Sels, &n_sel);
    ruleLog.Write("Proselect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel));
    if (n_sel < nos_s || status != PRO_TK_NO_ERROR) {
        InterfaceRule irule_A1A01_002_02;
        irule_A1A01_002_02.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs in the Selection!. Refer help document for details.");
        status = ProUIDialogShow(DLG_IR_A1A01_002);
        return PRO_TK_NO_ERROR;
    }

    for (size_t i = 0; i < n_sel; ++i) {
        ProModelitem Mdl_item2{}, Mdl_item3{};
        wchar_t WName1[PRO_PATH_SIZE];
        ProParameter pDesc;
        ProParamvalue pvDesc;
        int lastCompID = -1;
        ProAsmcomppath asm_comp_path;

        status = ProSelectionModelitemGet(surf_part_Sels[i], &Mdl_item2);
        status = ProMdlMdlnameGet(Mdl_item2.owner, WName1);
        status = ProMdlToModelitem(Mdl_item2.owner, &Mdl_item3);
        status = ProParameterInit(&Mdl_item3, L"DESCRIPTION", &pDesc);
        status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
        status = ProSelectionCopy(surf_part_Sels[i], &LH_Comps.ProSelection);
        status = ProSelectionAsmcomppathGet(surf_part_Sels[i], &asm_comp_path);
        for (int k = 0; k < asm_comp_path.table_num; ++k)
            lastCompID = asm_comp_path.comp_id_table[k];

        LH_Comps.ID = lastCompID;
        ProWstringToString(LH_Comps.Name, WName1);
        ProWstringToString(LH_Comps.Description, pvDesc.value.s_val);

        ruleLog.Write("Name: " + string(LH_Comps.Name) + "\tDescription: " + string(LH_Comps.Description) + "\tFeat_ID: " + to_string(LH_Comps.ID));
        CompDataVect_A1A01_002_LH.push_back(LH_Comps);
    }

    status = ProUIPushbuttonEnable(DLG_IR_A1A01_002, PB_RH_SELECT_IR_A1A01_002);
    status = ProUIDialogShow(DLG_IR_A1A01_002);
    return PRO_TK_NO_ERROR;
}

ProError RH_select_action_IRA1A01_002(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- RH_select_action_IRA1A01_002 -----------------------------");
    CompDataVect_A1A01_002_RH.clear();
    CompData_A1A01_002 RH_Comps{};
    int curWinId{}, n_sel, nos_s = RH1 + RH2 + 1;
    ProSelection* surf_part_Sels = nullptr;

    status = ProWindowCurrentGet(&curWinId);
    status = ProWindowRepaint(curWinId);
    status = ProUIDialogHide(DLG_IR_A1A01_002);
    status = ProSelect("surface", nos_s, NULL, NULL, NULL, NULL, &surf_part_Sels, &n_sel);
    ruleLog.Write("Proselect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel));
    if (n_sel < nos_s || status != PRO_TK_NO_ERROR) {
        InterfaceRule irule_A1A01_002_04;
        irule_A1A01_002_04.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs in the Selection!. Refer help document for details.");
        status = ProUIDialogShow(DLG_IR_A1A01_002);
        return PRO_TK_NO_ERROR;
    }

    for (size_t i = 0; i < n_sel; ++i) {
        ProModelitem Mdl_item2{}, Mdl_item3{};
        wchar_t WName1[PRO_PATH_SIZE];
        ProParameter pDesc;
        ProParamvalue pvDesc;
        int lastCompID = -1;
        ProAsmcomppath asm_comp_path;
        status = ProSelectionModelitemGet(surf_part_Sels[i], &Mdl_item2);
        status = ProMdlMdlnameGet(Mdl_item2.owner, WName1);
        status = ProMdlToModelitem(Mdl_item2.owner, &Mdl_item3);
        status = ProParameterInit(&Mdl_item3, L"DESCRIPTION", &pDesc);
        status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
        status = ProSelectionCopy(surf_part_Sels[i], &RH_Comps.ProSelection);
        status = ProSelectionAsmcomppathGet(surf_part_Sels[i], &asm_comp_path);
        for (int k = 0; k < asm_comp_path.table_num; ++k)
            lastCompID = asm_comp_path.comp_id_table[k];

        RH_Comps.ID = lastCompID;
        ProWstringToString(RH_Comps.Name, WName1);
        ProWstringToString(RH_Comps.Description, pvDesc.value.s_val);

        ruleLog.Write("Name: " + string(RH_Comps.Name) + "\tDescription: " + string(RH_Comps.Description) + "\tFeat_ID: " + to_string(RH_Comps.ID));
        CompDataVect_A1A01_002_RH.push_back(RH_Comps);
    }

    status = ProUIPushbuttonEnable(DLG_IR_A1A01_002, PB_OK_IR_A1A01_002);
    status = ProUIDialogShow(DLG_IR_A1A01_002);
    return PRO_TK_NO_ERROR;
}

ProError Dropdown_Selection_LH_1(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- Dropdown_Selection_LH_1 -----------------------------");

    string* reqData = (string*)data;
    int		n_sel;
    char** selValue;
    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
    ruleLog.Write("Platform: " + string(selValue[0]));
    if (string(selValue[0]) != "Select") {
        LH1 = stoi(selValue[0]);
        str1 = string(selValue[0]);
    }
    else {
        status = ProUIOptionmenuDisable(DLG_IR_A1A01_002, OP_MENU_LH_2);
        InterfaceRule _irule;
        _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs in the dropdown Menu!. Refer help document for details.");
        return PRO_TK_NO_ERROR;
    }

    status = ProUIOptionmenuEnable(DLG_IR_A1A01_002, OP_MENU_LH_2);
    return PRO_TK_NO_ERROR;
}

ProError Dropdown_Selection_LH_2(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- Dropdown_Selection_LH_2 -----------------------------");

    string* reqData = (string*)data;
    int		n_sel;
    char** selValue;
    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
    ruleLog.Write("Platform: " + string(selValue[0]));
    if (string(selValue[0]) != "Select") {
        LH2 = stoi(selValue[0]);
        str2 = string(selValue[0]);
    }
    else {
        status = ProUIOptionmenuDisable(DLG_IR_A1A01_002, OP_MENU_RH_1);
        InterfaceRule _irule;
        _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs in the dropdown Menu!. Refer help document for details.");
        return PRO_TK_NO_ERROR;
    }

    status = ProUIOptionmenuEnable(DLG_IR_A1A01_002, OP_MENU_RH_1);
    return PRO_TK_NO_ERROR;
}

ProError Dropdown_Selection_RH_1(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- Dropdown_Selection_RH_1 -----------------------------");

    string* reqData = (string*)data;
    int		n_sel;
    char** selValue;
    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
    ruleLog.Write("Platform: " + string(selValue[0]));
    if (string(selValue[0]) != "Select") {
        RH1 = stoi(selValue[0]);
        str3 = string(selValue[0]);
    }
    else {
        status = ProUIOptionmenuDisable(DLG_IR_A1A01_002, OP_MENU_RH_2);
        InterfaceRule _irule;
        _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs in the dropdown Menu!. Refer help document for details.");
        return PRO_TK_NO_ERROR;
    }

    status = ProUIOptionmenuEnable(DLG_IR_A1A01_002, OP_MENU_RH_2);
    return PRO_TK_NO_ERROR;
}

ProError Dropdown_Selection_RH_2(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- Dropdown_Selection_RH_2 -----------------------------");

    string* reqData = (string*)data;
    int		n_sel;
    char** selValue;
    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
    ruleLog.Write("Platform: " + string(selValue[0]));
    if (string(selValue[0]) != "Select") {
        RH2 = stoi(selValue[0]);
        str4 = string(selValue[0]);
    }
    else {
        status = ProUIOptionmenuDisable(DLG_IR_A1A01_002, PB_LH_SELECT_IR_A1A01_002);
        InterfaceRule _irule;
        _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs in the dropdown Menu!. Refer help document for details.");
        return PRO_TK_NO_ERROR;
    }

    status = ProUIPushbuttonEnable(DLG_IR_A1A01_002, PB_LH_SELECT_IR_A1A01_002);
    return PRO_TK_NO_ERROR;
}

ProError ruleDlgOKaction_A1A01_002(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgOKaction_A1A01_002 -----------------------------");

    //int curWinId{};
    //status = ProWindowCurrentGet(&curWinId);
    //status = ProWindowRepaint(curWinId);
    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return PRO_TK_NO_ERROR;
}

ProError ruleDlgCloseAction_A1A01_002(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgCloseAction_A1A01_002 -----------------------------");

    int curWinId{};
    status = ProWindowCurrentGet(&curWinId);
    status = ProWindowRepaint(curWinId);

    if (data != NULL) {
        bool* quitAction = (bool*)data;
        *quitAction = true;
    }
    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return status;
}

#pragma pop