/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
Surendra Sarode	| 27-02-2024	|	V1_0_0		| H1A11 - Engine - Cooling System
==================================================================================================================*/
#include "H1A11.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-H1A11-001	| Surendra Sarode	| MH1A14, MH1A01 	| For HCV Application-For engine Mounted Fan & radiator core, minimum allowable gap required is 50 mm
===================================================================================================================*/
//
//#define DLG_IRH1A11_001 "dlg_IR_H1A11_001"
//#define PB_ROK			"rule_ok_pb"
//#define PB_RCANCEL		"rule_cancel_pb"
//#define PB_RSELECT		"pb_select"
//
//static ProSelection PartSelectioncpy;
//static ProSelection SurfSelectioncpy;
//
//int IRH1A11::IRH1A11_001(ruleResult& final_res)
//{
//	ruleLog.Write("==========================   IRH2C01::IRH1A111_001   ==========================");
//
//	isUserQuits = false;
//	status = ProUIDialogCreate(DLG_IRH1A11_001, DLG_IRH1A11_001);
//	status = ProUIDialogAboveactivewindowSet(DLG_IRH1A11_001, PRO_B_FALSE);
//	status = ProUIPushbuttonActivateActionSet(DLG_IRH1A11_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
//	status = ProUIPushbuttonActivateActionSet(DLG_IRH1A11_001, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
//	status = ProUIPushbuttonActivateActionSet(DLG_IRH1A11_001, PB_RSELECT, (ProUIAction)select_action_IRH1A11_001, NULL);
//
//	status = ProUIDialogHide(DLG_IRC_MAIN);
//	status = ProUIDialogActivate(DLG_IRH1A11_001, &dlg_sts);
//	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
//	status = ProUIDialogDestroy(DLG_IRH1A11_001);
//	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
//	status = ProUIDialogShow(DLG_IRC_MAIN);
//
//    if (isUserQuits)
//        return -1;
//
//	double minimumclearance1 = 50.0;
//	Pro2dPnt param_1, param_2;
//	Pro3dPnt pnt_1[2];
//	double distance;
//
//	status = ProSelectionWithOptionsDistanceEval(PartSelectioncpy, PRO_B_TRUE, SurfSelectioncpy, PRO_B_TRUE, param_1, param_2, pnt_1[0], pnt_1[1], &distance);
//	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tDistance: " + to_string(distance));
//	//createDatumPoints(pnt_1, "CSYS_ASM_DEF", "distance_point1");
//
//	//	ruleLog.Write("SS: " + to_string(pnt_1[0][0]));
//	//	ruleLog.Write("SS: " + to_string(pnt_1[0][1]));
//	//	ruleLog.Write("SS: " + to_string(pnt_1[0][2]));
//
//	//	ruleLog.Write("SS: " + to_string(pnt_1[1][0]));
//	//	ruleLog.Write("SS: " + to_string(pnt_1[1][1]));
//	//	ruleLog.Write("SS: " + to_string(pnt_1[1][2]));
//
//	//ProBoolean is_interference_found;
//	//Pro3dPnt pnt_arr1[2];
//	//double distance1;
//	//status = ProFitClearanceCompute(PartSelectioncpy, PRO_FIT_INCLUDE_NONE, SurfSelectioncpy, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance1, NULL, &is_interference_found, pnt_arr1);
//	//createDatumPoints(pnt_arr1, "CSYS_ASM_DEF", "distance_pnnt2");
//	//ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tDistance: " + to_string(distance1));
//
//	//ProBoolean interf;
//	//Pro3dPnt coord[2];
//	//status = ProFitClearanceCompute(PartSelectioncpy, PRO_FIT_INCLUDE_NONE, SurfSelectioncpy, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance, NULL, &interf, coord);
//	if (status != PRO_TK_NO_ERROR && status != PRO_TK_OUT_OF_RANGE) {
//		UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selected parts.");
//		return -1;
//	}
//
//	ProModelitem mdlitem1, mdlitem2;
//	ProMdl Mdl1,Mdl2;
//	ProMdlName wFanname, wRadName;
//	char cFanname[PRO_NAME_SIZE];
//	char cRadname[PRO_NAME_SIZE];
//	vector<int> surId;
//	vector<string> names;
//
//	status = ProSelectionModelitemGet(PartSelectioncpy, &mdlitem1);
//	status = ProSelectionModelitemGet(SurfSelectioncpy, &mdlitem2);
//	status = ProModelitemMdlGet(&mdlitem1, &Mdl1);
//	status = ProModelitemMdlGet(&mdlitem2, &Mdl2);
//	status = ProMdlMdlnameGet(Mdl1, wFanname);
//	status = ProMdlMdlnameGet(Mdl2, wRadName);
//	ProWstringToString(cFanname, wFanname);
//	ProWstringToString(cRadname, wRadName);
//	ruleLog.Write("surId: " + to_string(mdlitem2.id));
//
//	//DECLARE RESULT
//	if (distance < minimumclearance1)
//	{
//		final_res.result = "FAIL";
//		sprintf(remark, "Minimum clearance between Fan ( Part No.: %s ) and\nRadiator core ( Part No.: %s and surface Id: %s) found is %.2lf mm,\n\nAcceptance Criteria: Clearance between engine mounted fan and radiator core >= 50.0 mm  ", cFanname, cRadname, to_string(mdlitem2.id), distance);
//		final_res.remark = string(remark);
//	}
//	else
//	{
//		final_res.result = "PASS";
//		sprintf(remark, "Minimum clearance between Fan ( Part No.: %s ) and\nRadiator core ( Part No.: %s and surface Id: %s ) found is %.2lf mm,\n\nAcceptance Criteria: Clearance between engine mounted fan and radiator core >= 50.0 mm ", cFanname, cRadname, to_string(mdlitem2.id), distance);
//		final_res.remark = string(remark);
//	}
//
//	ruleLog.Write("status: " + string(final_res.result));
//	ruleLog.Write("remark: " + string(final_res.remark));
//
//	return 0;
//}
//
//ProError select_action_IRH1A11_001(char* dialog, char* component, ProAppData data)
//{
//	ruleLog.Write("--------------------------  select_action_IRH1A11_001  --------------------------");
//	int n_sels1;
//	int n_sels2;
//	ProSelection* PartSelection;
//	ProSelection* SurfSelection;
//
//	status = ProSelect("part", 1, NULL, NULL, NULL, NULL, &PartSelection, &n_sels1);
//	status = ProSelectionCopy(PartSelection[0], &PartSelectioncpy);
//	ruleLog.Write("ProSelectionCopy: " + to_string(status));
//
//	status = ProSelect("surface", 1, NULL, NULL, NULL, NULL, &SurfSelection, &n_sels2);
//	status = ProSelectionCopy(SurfSelection[0], &SurfSelectioncpy);
//	ruleLog.Write("ProSelectionCopy: " + to_string(status));
//
//	if (status == PRO_TK_NO_ERROR && n_sels1 > 0 && n_sels2 > 0) {
//		status = ProUIPushbuttonEnable(dialog, PB_ROK);
//	}
//	return status;
//}



