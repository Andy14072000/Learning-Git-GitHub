/*=================================================================================================================
NAME | DATE | VERSION | COMMENTS
================================================================================================================== =
BHUVAN BHARATH | 24 - 04 - 2023 | V1_0_0 | F5A11 - BRAKING SYSTEM RULES
==================================================================================================================*/

#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#include "F5A11.h"

/*==================================================================================================================
RULE ID		| DEVELOPER			| DEPENDENT MODULES    	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5A11002	| Prajakta Bhelawe	| MF5A11; MF1A01; MF5A10|  Clearance of exhaust port of relay valve with other aggregates.
=================================================================================================================*/

#define DLG_F5A11_002	"dlg_IR_F5A11_002" 
#define CommitCancel    "CommitCancel" 
#define CommitOK        "CommitOK"
#define select_pb       "select_pb"

ProSelection p_selectionF5A10, p_selectionF1A01;
vector<ProSelection> p_selVectorF5A10, p_selVectorF1A01;

vector<PartnameDescriptionPairF5A11> reqCompsF5A11_002;
string cFeatNameF1A01, cFeatNameF5A10;
ProSelection selF1A01, selF5A10;
ProSelection copySelF1A01, copySelF5A10;
ProSelection* surf_surfF5A11;

int IRF5A11::IRF5A11_002(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF5A11::IRF5A11_002   ==========================");

    isUserQuits = false;
    status = ProUIDialogCreate(DLG_F5A11_002, DLG_F5A11_002);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));
    status = ProUIDialogAboveactivewindowSet(DLG_F5A11_002, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_F5A11_002, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_F5A11_002, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_F5A11_002, select_pb, (ProUIAction)select_action_IR_F5A11_002, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIDialogHide(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogHide: " + to_string(status));
    status = ProUIDialogActivate(DLG_F5A11_002, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_F5A11_002);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    double clearance1 = 0, clearance2 = 0;
    Pro2dPnt param_1, param_2;
    Pro3dPnt pnt_1, pnt_2;

    status = ProSolidFeatVisit((ProSolid)curMdl, getAsmSelectionF5A11, compsFilter, (ProAppData)&reqCompsF5A11_002);
    ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

    status = ProSelectionWithOptionsDistanceEval(surf_surfF5A11[0], PRO_B_FALSE, copySelF1A01, PRO_B_FALSE, param_1, param_2, pnt_1, pnt_2, &clearance1);
    ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));

    ruleLog.Write("distance1(surf and F1A01) = " + to_string(clearance1));

    status = ProSelectionWithOptionsDistanceEval(surf_surfF5A11[0], PRO_B_FALSE, copySelF5A10, PRO_B_FALSE, param_1, param_2, pnt_1, pnt_2, &clearance2);
    ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));

    ruleLog.Write("distance2(surf and F5A10) = " + to_string(clearance2));

    if (clearance1 >= 25 && clearance2 >= 25)
    {
        sprintf(remark, "Clearance between \n1.Exhaust port of relay valve and Frame Assy(%s.ASM) = %.2fmm \n2.Exhaust port of relay valve and Brake Modulator Unit(%s.ASM) = %.2fmm \n\nAcceptance Criteria: Clearance between exhaust port of relay valve with other aggregates should be minimum 25.00mm", cFeatNameF1A01, clearance1, cFeatNameF5A10, clearance2);

        final_res.remark = string(remark);
        final_res.result = "PASS";
    }

    else
    {
        sprintf(remark, "Clearance between \n1.Exhaust port of relay valve and Frame Assy(%s.ASM) = %.2fmm \n2.Exhaust port of relay valve and Brake Modulator Unit(%s.ASM) = %.2fmm \n\nAcceptance Criteria: Clearance between exhaust port of relay valve with other aggregates should be minimum 25.00mm", cFeatNameF1A01, clearance1, cFeatNameF5A10, clearance2);

        final_res.remark = string(remark);
        final_res.result = "FAIL";
    }

    p_selVectorF5A10.clear();
    p_selVectorF1A01.clear();
    reqCompsF5A11_002.clear();


    return 0;
}

ProError select_action_IR_F5A11_002(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("--------------------------  select_action_IR_F5A11_002  --------------------------");

    int n_sels;
    status = ProSelect((char*)"surface", 1, NULL, NULL, NULL, NULL, &surf_surfF5A11, &n_sels);
    ruleLog.Write("Proselect status= " + to_string(status) + "\nNo.of Selection " + to_string(n_sels));

    if (status == PRO_TK_NO_ERROR && n_sels == 1) {
        status = ProUIPushbuttonEnable(dialog, CommitOK);
    }

    return PRO_TK_NO_ERROR;
}

ProError getAsmSelectionF5A11(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    ruleLog.Write("----------------------------- getAsmSelectionF5A11 -----------------------------");

    vector<PartnameDescriptionPair>* prtname_desc_list = (vector<PartnameDescriptionPair>*)app_data;

    ProMdlType subModuleMdlType;
    ProModelitem modelItem;
    wchar_t wFeatName[PRO_NAME_SIZE];
    char cFeatName[PRO_NAME_SIZE];
    ProMdl reqMdl;
    char existingPval[PRO_NAME_SIZE]{};
    PartnameDescriptionPair compd{};

    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
    ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
    status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
    ruleLog.Write("ProMdlTypeGet: " + to_string(status));
    status = ProMdlMdlnameGet(reqMdl, wFeatName);
    ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
    ProWstringToString(cFeatName, wFeatName);

    status = ProMdlToModelitem(reqMdl, &modelItem);
    ruleLog.Write("ProMdlToModelitem: " + to_string(status));

    ProParameter pDesc;
    ProParamvalue pvDesc;
    ProName pDescName = L"DESCRIPTION";
    string tokenF1A01 = "F1A01";
    string tokenF5A10 = "F5A10";
    ProSolid assembly;

    status = ProParameterInit(&modelItem, pDescName, &pDesc);
    ruleLog.Write("ProParameterInit: " + to_string(status));

    if (status == PRO_TK_NO_ERROR)
    {
        status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
        ProWstringToString(existingPval, pvDesc.value.s_val);
        ruleLog.Write(cFeatName);
        string cFeatNameStr = cFeatName;

        ProIdTable memb_id_tab;
        memb_id_tab[0] = p_feature->id;
        ProAsmcomppath p_comp_path;

        ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);

        if (strlen(cFeatName) == 14 && cFeatNameStr.find(tokenF1A01) != string::npos)
        {
            strcpy(compd.part_name, cFeatName);
            ruleLog.Write("compd.part_name: " + string(compd.part_name));

            cFeatNameF1A01 = cFeatName;

            strcpy(compd.description, existingPval);
            ruleLog.Write("compd.description" + string(compd.description));

            ProMdl curMdl;
            status = ProMdlCurrentGet(&curMdl);

            status = ProAsmcomppathInit((ProSolid)curMdl, memb_id_tab, 1, &p_comp_path);
            ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

            status = ProSelectionAlloc(&p_comp_path, &modelItem, &selF1A01);
            ruleLog.Write("ProSelectionAlloc: " + to_string(status));

            status = ProSelectionCopy(selF1A01, &copySelF1A01);
            ruleLog.Write("ProSelectionCopy ps = " + to_string(status));

        }

        if (strlen(cFeatName) == 14 && cFeatNameStr.find(tokenF5A10) != string::npos)
        {
            strcpy(compd.part_name, cFeatName);
            ruleLog.Write("compd.part_name: " + string(compd.part_name));

            cFeatNameF5A10 = cFeatName;

            strcpy(compd.description, existingPval);
            ruleLog.Write("compd.description" + string(compd.description));

            ProMdl curMdl;
            status = ProMdlCurrentGet(&curMdl);

            status = ProAsmcomppathInit((ProSolid)curMdl, memb_id_tab, 1, &p_comp_path);
            ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

            status = ProSelectionAlloc(&p_comp_path, &modelItem, &selF5A10);
            ruleLog.Write("ProSelectionAlloc: " + to_string(status));

            status = ProSelectionCopy(selF5A10, &copySelF5A10);
            ruleLog.Write("ProSelectionCopy ps = " + to_string(status));

        }
    }

    prtname_desc_list->push_back(compd);
    return PRO_TK_NO_ERROR;
}


