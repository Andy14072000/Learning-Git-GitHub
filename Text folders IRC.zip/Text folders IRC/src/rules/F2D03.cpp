/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 18-04-2023	| V1_0_0		| F2D03 - LIFT SUSPENSION RULES
==================================================================================================================*/
#include "F2D03.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F2D03-003	| Ved Aiyar			| MF2D03; MF5A07	|  Minimum 15mm clearance to be ensured with other static adjacent parts.
===================================================================================================================*/
// UI DEFINITIONS
#define DLG_IRF2D03_003	"dlg_IR_F2D03_003" 
#define PB_RSELECT		"select_pb"
#define PB_ROK			"CommitOK"
#define PB_RCANCEL		"CommitCancel"

// GLOBAL

ComponentData _reqCompsf2d03003[2]{};
double standardf2d03003 = 15;
ProSelection* self2d03003;
ProSelection highlightf2d03003[20];
ProSelection selaf2d03003;
vector<string> selection_parts;
int n_selF2D03_003;
string remf2d03003;


int IRF2D03::IRF2D03_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2D03::IRF2D03_003   ==========================");

	string reqCompSubMod[2] = { "F2D03", "F5A07" };
	string comp_names[2];
	double clearance_vals;
	isUserQuits = false;

	for (int i = 0; i < subModulesList.size(); ++i)
	{
		for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j)
		{
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
			{
				strcpy(_reqCompsf2d03003[j].name, subModulesList[i].name.c_str());
				comp_names[j] = subModulesList[i].name;
			}
		}
	}

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqCompsf2d03003);

	for (auto elem : _reqCompsf2d03003)
	{
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}

	string s = _reqCompsf2d03003[0].name;
	string s1 = _reqCompsf2d03003[1].name;
	remf2d03003.append("Distance Measured from " + s1 + ".asm to parts of " + s + ".asm :" + "\n\n");

	status = ProUIDialogCreate(DLG_IRF2D03_003, DLG_IRF2D03_003);
	ruleLog.Write("ProUIDialogCreate status = " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2D03_003, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet status = " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D03_003, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D03_003, PB_RSELECT, (ProUIAction)select_action_IR_F2D03_003, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D03_003, PB_ROK, (ProUIAction)ruleDlgOKactionf2d03_003, NULL);
	status = ProUIPushbuttonDisable(DLG_IRF2D03_003, PB_ROK);


	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2D03_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF2D03_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);


	if (isUserQuits)
		return -1;


	isRightValue = false;

	if (remf2d03003.find("FAIL") != std::string::npos)
	{
		isRightValue = false;
	}
	else
	{
		isRightValue = true;
	}

	remf2d03003.append("\nAcceptance criteria : >= 15.00mm");

	final_res.remark = remf2d03003;

	// DECLARE RESULT
	if (isRightValue)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: \n" + final_res.remark);

	remf2d03003.clear();

	return 0;
}

ProError select_action_IR_F2D03_003(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IR_F2D03_003  --------------------------");
	status = ProUIDialogHide(dialog);
	ruleLog.Write("ProUIDialogHide status = " + to_string(status));

	ProModelitem annotelem;
	char nameofsel[PRO_NAME_SIZE];
	ProMdl mdl;
	wchar_t model;
	int curWinId;

	status = ProSelect((char*)"part", -1, NULL, NULL, NULL, NULL, &self2d03003, &n_selF2D03_003);
	ruleLog.Write("Proselect status = " + to_string(status));
	ruleLog.Write("Number of selections = " + to_string(n_selF2D03_003));

	status = ProWindowCurrentGet(&curWinId);
	ruleLog.Write("ProWindowCurrentGet status = " + to_string(status));

	status = ProWindowRepaint(curWinId);
	ruleLog.Write("ProWindowRepaint status = " + to_string(status));

	/*status = ProSelectionHighlight(self2d03[0], PRO_COLOR_HIGHLITE);
	ruleLog.Write("ProSelectionHighlight status = " + to_string(status));*/

	status = ProUIDialogShow(dialog);
	ruleLog.Write("ProUIDialogShow status = " + to_string(status));


	for (int i = 0; i < n_selF2D03_003; i++)
	{
		status = ProSelectionModelitemGet(self2d03003[i], &annotelem);
		ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

		status = ProModelitemMdlGet(&annotelem, &mdl);
		ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

		status = ProMdlMdlnameGet(mdl, &model);
		ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

		ProWstringToString(nameofsel, &model);
		std::string models(nameofsel);

		selection_parts.push_back(models);
	}

	//Find air tank assembly from _reqCompsf2d03
	for (int i = 0; i < sizeof(_reqCompsf2d03003) / sizeof(_reqCompsf2d03003[0]); i++)
	{
		string sub = "F5A07";
		string s = _reqCompsf2d03003[i].name;
		for (char& c : s)
		{
			c = std::toupper(c);
		}
		size_t found3 = s.find(sub);

		if (found3 != std::string::npos)//If air tank assembly is found, then allocate it to selection array.
		{
			ruleLog.Write(s);

			ProMdl reqMdlsair;
			ProName compair;
			ProModelitem featureair;
			ProStringToWstring(compair, _reqCompsf2d03003[i].name);
			status = ProMdlnameInit(compair, PRO_MDLFILE_ASSEMBLY, &reqMdlsair);
			status = ProMdlToModelitem(reqMdlsair, &featureair);

			ProAsmcomppath pathair;
			ProIdTable idtblair = { _reqCompsf2d03003[i].id };
			status = ProAsmcomppathInit((ProSolid)curMdl, idtblair, 1, &pathair);
			ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));

			status = ProSelectionAlloc(&pathair, &featureair, &selaf2d03003);
			ruleLog.Write("ProSelectionAlloc status = " + to_string(status));

			break;
		}
	}

	status = ProUIPushbuttonEnable(dialog, PB_ROK);

	return PRO_TK_NO_ERROR;

}

ProError ruleDlgOKactionf2d03_003(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgOKaction -----------------------------");
	int count = 0;
	for (int j = 0; j < n_selF2D03_003; j++)
	{
		ruleLog.Write("check");
		double param[2];
		double pnt[2];
		double distance1;
		ruleLog.Write("check1");
		status = ProSelectionWithOptionsDistanceEval(selaf2d03003, PRO_B_TRUE, self2d03003[j], PRO_B_TRUE, &param[0], &param[1], &pnt[0], &pnt[1], &distance1);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));


		if (distance1 < standardf2d03003)
		{
			remf2d03003.append("- " + selection_parts[j] + ".prt = " + doubleToString(distance1) + "mm [FAIL]\n");
			status = ProSelectionCopy(self2d03003[j], highlightf2d03003);
			ruleLog.Write("ProSelectionCopy status = "+to_string(status));
			count++;
		}
		else
		{
			remf2d03003.append("- " + selection_parts[j] + ".prt = " + doubleToString(distance1) + "mm [PASS]\n");
		}
	}//FOR ENDS

	for (int i = 0; i < 20; i++)
	{
		status = ProSelectionHighlight(highlightf2d03003[i] , PRO_COLOR_HIGHLITE);
		ruleLog.Write("ProSelectionHighlight status = " + to_string(status));
		if (status != 0)
		{
			break;
		}
	}

	selection_parts.clear();

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return PRO_TK_NO_ERROR;
}

ProError ruleDlgCloseActionf2d03_003(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgCloseAction -----------------------------");
	if (data != NULL) 
	{
		bool* quitAction = (bool*)data;
		*quitAction = true;
	}

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}



#pragma pop
