/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F4A01 - FRONT SUSPENSION RULES
==================================================================================================================*/
#include "F4A01.h"
#include "Utils.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES											| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F4A01-002	| MATHANPRASATH A	| MF4A01; MF4A03; MF4A02; MF4A05; MF4A04; MF4A07; MF4A06	| Standard leaf spring attachment across platform based on application.
===================================================================================================================*/

#define DLG_IR_F4A01_002   "dlg_IR_F4A01_002"
#define CommitOK		   "CommitOK"
#define CommitCancel	   "CommitCancel"

char existingPMatval[PRO_NAME_SIZE]{};
ComponentData _reqComps[2]{};
bool PerformF4A01 = FALSE;
string sec_asm, sec_asm_name;
string asm_name;
string Spring_Type{};
string spring_type = "";
string out, tem;
string comp_sub_str;
vector<string>spring_info;

int IRF4A01::IRF4A01_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF4A01::IRF4A01_002   ==========================");
	//Clearing the Vectors

	final_res.result.clear();
	vector<string> reqValsFromCsv;
	vector<leafSpringAttachment> name_desc_list, test1;
	bool Coil_spring{}, Leaf{}, AIR_SPRING{};
	SubModuleInfo _reqSMinfo;
	char cReqMdlPath[PRO_PATH_SIZE];
	ProPath wReqMdlPath;
	bool matchFound{};
	ProMdl reqMdl{};
	ProModelitem reqMdlitem;
	vector<IntAndStringlistMap> leafspringMapList;
	vector<string> optionMenuSpringTypes;
	reqValsFromCsv.clear();
	name_desc_list.clear();
	leafspringMapList.clear();
	optionMenuSpringTypes.clear();
	spring_info.clear();
	int n_opsel;
	char** opsel;
	char opMenuName[PRO_NAME_SIZE]{};
	string output;
	string sub_str;
	string tok2;
	string remarkMsg{};
	string reqCompSubMod[2] = { "F4A01","F4A02" };
	string comp_names[2];
	ProCharPath remark1{};
	ProCharPath remark2{};
	ProUIMessageButton* buttons;
	ProUIMessageButton user_choice;
	bool coilFound{};
	bool AirFound{};


	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IR_F4A01_002, DLG_IR_F4A01_002);
	ruleLog.Write("UI status = " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IR_F4A01_002, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet = " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IR_F4A01_002, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet1 = " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IR_F4A01_002, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet 2= " + to_string(status));
	status = ProUIDialogHide(DLG_IRC_MAIN);

	status = ProUIDialogActivate(DLG_IR_F4A01_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_IR_F4A01_002);
		ruleLog.Write("ProUIDialogDestroy close action: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	// get the submodule name from list
	for (int i = 0; i < subModulesList.size(); ++i)
	{
		if (subModulesList[i].name.find("F4A01") != string::npos)
		{
			_reqSMinfo = subModulesList[i];
			break;
		}
	}

	//get the project code of opened submodule
	project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
	ruleLog.Write("project code: " + to_string(project_code));

	//Fetch the data from CSV 

	getReqValsFrom2DCsvData("IRF4A01002.csv", 2, 3, project_code, reqValsFromCsv);
	ruleLog.Write("getReqValsFrom2DCsvData: " + to_string(status));
	ruleLog.Write("Size of vector is :" + to_string(reqValsFromCsv.size()));
	//Printing the fetched data
	for (int i = 0; i < reqValsFromCsv.size(); ++i)
	{
		ruleLog.Write(reqValsFromCsv.at(i));
	}

	if (status != PRO_TK_NO_ERROR)
		return -1;

	//Visiting feature

	status = ProSolidFeatVisit((ProSolid)curMdl, Typeget, compsFilter, (ProAppData)&name_desc_list);
	ruleLog.Write("Sec ASm Name3:" + sec_asm);

	// Sort the vector based on part_name
	std::sort(name_desc_list.begin(), name_desc_list.end(), comparePartName);

	// Remove duplicates
	name_desc_list.erase(std::unique(name_desc_list.begin(), name_desc_list.end(),
		[](const leafSpringAttachment& a, const leafSpringAttachment& b) {
			return std::strcmp(a.part_name, b.part_name) == 0;
		}), name_desc_list.end());

	for (const auto& elem : name_desc_list)
	{
		ruleLog.Write("Part_Name        : " + (string)elem.part_name);
	}

	for (auto item : name_desc_list)
	{
		ruleLog.Write("Part Name        : " + (string)item.part_name);
		ruleLog.Write("Barrel         : " + to_string(item.barrel));
		ruleLog.Write("item.description : " + (string)item.description);
		ruleLog.Write("Material type    : " + (string)item.MatType);
	//	remarkMsg += ("\n" + (string)item.part_name + ".PRT" + ", " + to_string(item.barrel) + ", [" + item.description + "], [" + (string)item.MatType + "]");

	}

	const regex z("(AIR SPRING)");
	const regex y("(LEAF SPRING)");
	const regex x("(COIL SPRING)");
	for (auto spring : spring_info)
	{
		ruleLog.Write("Leaf spring type =" + spring);
		if ((regex_search(spring, x) != 0))
		{
			ruleLog.Write("Coil spring conditions");
			Coil_spring = true;
			ruleLog.Write("Spring Type : " + to_string(status) + spring);
			ruleLog.Write("Ui-COIL");
			break;
		}
		if ((regex_search(spring, z) != 0))
		{
			ruleLog.Write("Air spring conditions");
			AIR_SPRING = true;
			ruleLog.Write("Spring Type : " + spring);
			ruleLog.Write("Ui-AIR");
			break;
		}
		if ((regex_search(spring, y) != 0))
		{
			ruleLog.Write("Leaf spring conditions");
			ruleLog.Write("Spring Type : " + to_string(status) + spring);
			Leaf = true;
			break;
		}

	}

	ruleLog.Write("Sec ASm Name4:" + sec_asm);

	status = ProUIDialogDestroy(DLG_IR_F4A01_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	//std:: regex a("|Gr\s?\d+\s?[-/]\s?\d+W|\bADI.*900\b|\bADI.*1200\b|GJS\s*1050\s*(?:\/|-|\s)*06");
	const regex a("Fe[-\s]*360|^Fe360|fe360|Fe360|\bFe360\b");
	const regex b("Fe[-\s]*410|^Fe410|fe410|Fe410|\bFe410\b");
	const regex c("E34|\bE34\b|E[-\s]*34");
	const regex d("E46|\bE46\b|E[-\s]*46");
	const regex e("/\bBSK 46/gm|\bBSK\s*46\b|BSK46|^BSK46");
	const regex f("\bFe510\b|/\bFe 510/gm|\bFe\s*510\b|Fe510|^Fe510");
	const regex g("\bSAP.*H440\b|SAPH 440|SAPH[-\s]*440|\bSAPH440\b");
	const regex h("\bHS800\b|HS 800|HS[-\s]*800|\bHS800\b|HS800");
	const regex r("\bHS550\b|HS550|HS[-\s]*550|\bHS550\b|HS550");
	const regex k("SG\s?450\s?\/\s?12|SG 450/12|\bSG 450/12\b");
	const regex l("SG\s?500\s?\/\s?7|SG 500/7|\bSG 500/7\b");
	const regex m("SG\s?550\s?\/\s?6|SG 550/6|\bSG 550/6\b");
	const regex n("Gr\s?\d+\s?[-/]\s?\d+W|Gr\s*340\s*-\s*570W|Gr\s?\d+\s?[-/]\s?\d+W|Gr 340-570W");
	const regex o("\bADI.*900\b|ADI 900|ADI900");
	const regex p("\bADI.*1200\b|ADI 1200|ADI1200");
	const regex q("GJS\s*1050\s*(?:\/|-|\s)*06|\bGJS\s*1050\s*\/\s*06\b|GJS 1050 \/ 06|GJS 1050[ -]?\/? ?06");


	string res_sts;
	int reg_ex;
	// IF COIL SPRING USED
	if (Coil_spring == true)
	{
		ruleLog.Write("Coil spring if condition");
		string Target;
		string sub_prt_coil, sub_coil;
		//matchFound == NULL;
		//AirFound == NULL;
		spring_type = "COIL SPRING";
		int i;
		ruleLog.Write("Size of vector is :" + to_string(name_desc_list.size()));
		ruleLog.Write("Sec ASm Name5:" + sec_asm);
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "INFO", "This rule is only applicable for LEAF SPRING.");
		ruleLog.Write("ProUIMessageDialogDisplay: " + to_string(status));
		
		if (name_desc_list.size() > 0)
		{
			ruleLog.Write("Sec ASm Name5:" + sec_asm);

			ruleLog.Write("Sec ASm Name6:" + sec_asm);

			for (int j = 0; j < name_desc_list.size(); j++)
			{
				sub_prt_coil = name_desc_list.at(j).part_name;
				sub_coil = sub_prt_coil.substr(8, 2);
				if (sub_coil == "33")
				{
					if ((regex_search(name_desc_list.at(j).MatType, a) != 0) || (regex_search(name_desc_list.at(j).MatType, b) != 0) || (regex_search(name_desc_list.at(j).MatType, c) != 0) || (regex_search(name_desc_list.at(j).MatType, d) != 0) || (regex_search(name_desc_list.at(j).MatType, e) != 0)
						|| (regex_search(name_desc_list.at(j).MatType, f) != 0) || (regex_search(name_desc_list.at(j).MatType, g) != 0) || (regex_search(name_desc_list.at(j).MatType, h) != 0) || (regex_search(name_desc_list.at(j).MatType, r) != 0)
						|| (regex_search(name_desc_list.at(j).MatType, k) != 0) || (regex_search(name_desc_list.at(j).MatType, l) != 0) || (regex_search(name_desc_list.at(j).MatType, m) != 0) || (regex_search(name_desc_list.at(j).MatType, n) != 0)
						|| (regex_search(name_desc_list.at(j).MatType, o) != 0) || (regex_search(name_desc_list.at(j).MatType, p) != 0))
					{
						ruleLog.Write("Pass Condition");
						coilFound = true;
						res_sts = "PASS";
						remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
					}
					else
					{
						ruleLog.Write("Fail Condition");
						coilFound = false;
						res_sts = "FAIL";
						remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
						final_res.result = "PASS";
						sprintf(remark, "Result :%s.ASM- %s has %s Type\nThe details of spring attachment are given below as PART NAME, BARREL, [DESCRIPTION], [MAT.TYPE].\n", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
						sprintf(remark1, ("\n\nAcceptance Critertia :Spring type is Coil spring, Hence attachment rule is not applicable."));
						final_res.remark = remark + remarkMsg + remark1;
						break;
					}
				}
				if (sub_coil == "37" || sub_coil == "38")
				{
					if ((regex_search(name_desc_list.at(j).MatType, k) != 0) || (regex_search(name_desc_list.at(j).MatType, l) != 0) || (regex_search(name_desc_list.at(j).MatType, m) != 0) || (regex_search(name_desc_list.at(j).MatType, n) != 0)
						|| (regex_search(name_desc_list.at(j).MatType, o) != 0) || (regex_search(name_desc_list.at(j).MatType, p) != 0))
					{

						ruleLog.Write("Pass Condition");
						coilFound = true;
						res_sts = "PASS";
						remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
					}
					else
					{
						ruleLog.Write("Fail Condition");
						coilFound = false;
						res_sts = "FAIL";
						remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
						final_res.result = "PASS";
						sprintf(remark, "Result :%s.ASM- %s has %s Type\nThe details of spring attachment are given below as PART NAME, BARREL, [DESCRIPTION], [MAT.TYPE].\n", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
						sprintf(remark1, ("\n\nAcceptance Critertia :Spring type is Coil spring, Hence attachment rule is not applicable."));
						final_res.remark = remark + remarkMsg + remark1;
						break;
					}

				}
				if (sub_coil == "71" || sub_coil == "82")
				{
					if ((regex_search(name_desc_list.at(j).MatType, a) != 0) || (regex_search(name_desc_list.at(j).MatType, b) != 0) || (regex_search(name_desc_list.at(j).MatType, c) != 0) || (regex_search(name_desc_list.at(j).MatType, d) != 0) || (regex_search(name_desc_list.at(j).MatType, e) != 0)
						|| (regex_search(name_desc_list.at(j).MatType, f) != 0) || (regex_search(name_desc_list.at(j).MatType, g) != 0) || (regex_search(name_desc_list.at(j).MatType, h) != 0) || (regex_search(name_desc_list.at(j).MatType, r) != 0))
					{
						ruleLog.Write("Pass Condition");
						coilFound = true;
						res_sts = "PASS";
						remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
					}
					else
					{
						ruleLog.Write("Fail Condition");
						coilFound = false;
						res_sts = "FAIL";
						remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
						final_res.result = "PASS";
						sprintf(remark, "Result :%s.ASM- %s has %s Type\nThe details of spring attachment are given below as PART NAME, BARREL, [DESCRIPTION], [MAT.TYPE].\n", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
						sprintf(remark1, ("\n\nAcceptance Critertia :Spring type is Coil spring, Hence attachment rule is not applicable."));
						final_res.remark = remark + remarkMsg + remark1;
						break;
					}

				}


			}

		}
		else
		{
			ruleLog.Write("Coil-Spring found  and material types not found !");
			final_res.result = "PASS";
			sprintf(remark, "Result :%s.ASM- %s has %s Type.\n\nAcceptance Critertia :Spring type is Coil spring, Hence attachment rule is not applicable.", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
			final_res.remark = remark;
		}

	}

	if (coilFound == true)
	{
		ruleLog.Write("Coil-Spring and material types found !");
		final_res.result = "PASS";
		sprintf(remark, ("Result :%s.ASM- %s has %s Type.\nThe details of spring attachment are given below as PART NAME, BARREL, [DESCRIPTION], [MAT.TYPE].\n"), sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
		sprintf(remark1, ("\n\nAcceptance Critertia :Spring type is Coil spring, Hence attachment rule is not applicable."));
		final_res.remark = remark + remarkMsg + remark1;
	}

	// IF AIR SPRING USED
	if (AIR_SPRING == true)
	{
		ruleLog.Write("Air spring if condition");
		//matchFound == NULL;
		//coilFound == NULL;
		string Target;
		string sub_prt_air,sub_air;

		spring_type = "AIR SPRING";
		ruleLog.Write("Size of vector is :" + to_string(name_desc_list.size()));
		ruleLog.Write("Sec ASm Name5:" + sec_asm);
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "INFO", "This rule is only applicable for LEAF SPRING.");
ruleLog.Write("ProUIMessageDialogDisplay: " + to_string(status));
      if (name_desc_list.size() > 0)
      {
	      ruleLog.Write("Sec ASm Name5:" + sec_asm);
	      ruleLog.Write("Sec ASm Name5:" + sec_asm);

	      for (int j = 0; j < name_desc_list.size(); j++)
	      {
		      sub_prt_air = name_desc_list.at(j).part_name;
		      sub_air = sub_prt_air.substr(8, 2);
		     if (sub_air == "33")
		     {
			     if ((regex_search(name_desc_list.at(j).MatType, a) != 0) || (regex_search(name_desc_list.at(j).MatType, b) != 0) || (regex_search(name_desc_list.at(j).MatType, c) != 0) || (regex_search(name_desc_list.at(j).MatType, d) != 0) || (regex_search(name_desc_list.at(j).MatType, e) != 0)
				|| (regex_search(name_desc_list.at(j).MatType, f) != 0) || (regex_search(name_desc_list.at(j).MatType, g) != 0) || (regex_search(name_desc_list.at(j).MatType, h) != 0) || (regex_search(name_desc_list.at(j).MatType, r) != 0)
				|| (regex_search(name_desc_list.at(j).MatType, k) != 0) || (regex_search(name_desc_list.at(j).MatType, l) != 0) || (regex_search(name_desc_list.at(j).MatType, m) != 0) || (regex_search(name_desc_list.at(j).MatType, n) != 0)
				|| (regex_search(name_desc_list.at(j).MatType, o) != 0) || (regex_search(name_desc_list.at(j).MatType, p) != 0))
			     {
				   ruleLog.Write("Pass Condition");
				   AirFound = true;
				   res_sts = "PASS";
				   remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
			     }
			     else
			     {
				     ruleLog.Write("Fail Condition");
				     AirFound = false;
				     res_sts = "FAIL";
				     remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
				     final_res.result = "PASS";
				     sprintf(remark, "Result :%s.ASM- %s has %s Type\nThe details of spring attachment are given below as PART NAME, BARREL, [DESCRIPTION], [MAT.TYPE].\n", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
				     sprintf(remark1, ("\n\nAcceptance Critertia :Spring type is Air spring, Hence attachment rule is not applicable."));
				     final_res.remark = remark + remarkMsg + remark1;
				    break;
			     }
		     }
		     if (sub_air == "37" || sub_air == "38")
		     {
			    if ((regex_search(name_desc_list.at(j).MatType, k) != 0) || (regex_search(name_desc_list.at(j).MatType, l) != 0) || (regex_search(name_desc_list.at(j).MatType, m) != 0) || (regex_search(name_desc_list.at(j).MatType, n) != 0)
				|| (regex_search(name_desc_list.at(j).MatType, o) != 0) || (regex_search(name_desc_list.at(j).MatType, p) != 0))
			    {

				    ruleLog.Write("Pass Condition");
				    AirFound = true;
				    res_sts = "PASS";
				    remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
			    }
			    else
			    {
				ruleLog.Write("Fail Condition");
				AirFound = false;
				res_sts = "FAIL";
				remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
				final_res.result = "PASS";
				sprintf(remark, "Result :%s.ASM- %s has %s Type\nThe details of spring attachment are given below as PART NAME, BARREL, [DESCRIPTION], [MAT.TYPE].\n", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
				sprintf(remark1, ("\n\nAcceptance Critertia :Spring type is Air spring, Hence attachment rule is not applicable."));
				final_res.remark = remark + remarkMsg + remark1;
				break;
			    }

		     }
		     if (sub_air == "71" || sub_air == "82")
		     {
			     if ((regex_search(name_desc_list.at(j).MatType, a) != 0) || (regex_search(name_desc_list.at(j).MatType, b) != 0) || (regex_search(name_desc_list.at(j).MatType, c) != 0) || (regex_search(name_desc_list.at(j).MatType, d) != 0) || (regex_search(name_desc_list.at(j).MatType, e) != 0)
				 || (regex_search(name_desc_list.at(j).MatType, f) != 0) || (regex_search(name_desc_list.at(j).MatType, g) != 0) || (regex_search(name_desc_list.at(j).MatType, h) != 0) || (regex_search(name_desc_list.at(j).MatType, r) != 0))
			     {
				   ruleLog.Write("Pass Condition");
				   AirFound = true;
				   res_sts = "PASS";
				   remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
			     }

			     else
			     {
				    ruleLog.Write("Fail Condition");
				    AirFound = false;
				    res_sts = "FAIL";
				    remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
				    final_res.result = "PASS";
				    sprintf(remark, "Result :%s.ASM- %s has %s Type\nThe details of spring attachment are given below as PART NAME, BARREL, [DESCRIPTION], [MAT.TYPE].\n", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
				    sprintf(remark1, ("\n\nAcceptance Critertia :Spring type is Air spring, Hence attachment rule is not applicable."));
				    final_res.remark = remark + remarkMsg + remark1;
				    break;
			     }

		     }




	      }
	         if (AirFound == true)
	         {
		        ruleLog.Write("Air-Spring and material types found!");
		        final_res.result = "PASS";
		        sprintf(remark, "Result :%s.ASM- %s has %s Type.\nThe details of spring attachment are given below as PART NAME, BARREL, [DESCRIPTION], [MAT.TYPE].\n", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
		        sprintf(remark1, ("\n\nAcceptance Critertia :Spring type is Air spring, Hence attachment rule is not applicable."));
		        final_res.remark = remark + remarkMsg + remark1;
	         }


      }
      else
      {
	     ruleLog.Write("Air-Spring found and material types not found!");
	     final_res.result = "PASS";
	     sprintf(remark, "Result :%s.ASM- %s has %s Type.\n\nAcceptance Critertia :Spring type is Air spring, Hence attachment rule is not applicable.", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
	     final_res.remark = remark;
      }

	}


	// IF LEAF SPRING USED
     if (Leaf == true)
     {
		//Comparing the Material type fetched from csv with parts Material type.
		ruleLog.Write("Leaf spring if condition");

		string Target;
		string sub_prt,sub_str;

		spring_type = "LEAF SPRING";
		ruleLog.Write("Size of vector is :" + to_string(name_desc_list.size()));
		ruleLog.Write("Sec ASm Name5:" + sec_asm);
		int i;


		if (name_desc_list.size() > 0)
		{
			for (int j = 0; j < name_desc_list.size(); j++)
			{
				ruleLog.Write("Material =" + string(name_desc_list.at(j).MatType));
				sub_prt = name_desc_list.at(j).part_name;
				sub_str = sub_prt.substr(8, 2);
				reg_ex = regex_search(name_desc_list.at(j).MatType, a);
				ruleLog.Write("reg_ex value :" + to_string(reg_ex));
				if (sub_str == "33")
				{
					ruleLog.Write("Barell Code 33");
					if ((regex_search(name_desc_list.at(j).MatType, a) != 0) || (regex_search(name_desc_list.at(j).MatType, b) != 0) || (regex_search(name_desc_list.at(j).MatType, c) != 0) || (regex_search(name_desc_list.at(j).MatType, d) != 0) || (regex_search(name_desc_list.at(j).MatType, e) != 0)
						|| (regex_search(name_desc_list.at(j).MatType, f) != 0) || (regex_search(name_desc_list.at(j).MatType, g) != 0) || (regex_search(name_desc_list.at(j).MatType, h) != 0) || (regex_search(name_desc_list.at(j).MatType, r) != 0)
						|| (regex_search(name_desc_list.at(j).MatType, k) != 0) || (regex_search(name_desc_list.at(j).MatType, l) != 0) || (regex_search(name_desc_list.at(j).MatType, m) != 0) || (regex_search(name_desc_list.at(j).MatType, n) != 0)
						|| (regex_search(name_desc_list.at(j).MatType, o) != 0) || (regex_search(name_desc_list.at(j).MatType, p) != 0))
					{
						ruleLog.Write("Pass Condition");
						matchFound = true;
						res_sts = "PASS";
						remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
					}
					else
					{
						ruleLog.Write("Fail Condition");
						matchFound = false;
						res_sts = "FAIL";
						remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
						final_res.result = "FAIL";
						sprintf(remark, "Result :%s.ASM- %s has %s Type\nThe details of spring attachment are given below as PART NAME, BARREL, [DESCRIPTION], [MAT.TYPE].\n", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
						sprintf(remark1, "\n\nAcceptance Critertia :Parts with the following material types and Barrel codes should be used.\n1.Sheet metal(33,37,38)- Fe360, Fe410 , E34, E46, BSK 46, Fe510, SAPH 440, HS800, HS550.");
						sprintf(remark2, "\n2.Casting(33,71,82)- SG 450/12 , SG 500/7, SG 550/6, Gr 340-570W, ADI 900, ADI 1200, GJS 1050/06.");
						final_res.remark = remark + remarkMsg + remark1 + remark2;
						break;
					}
				}
				if (sub_str == "37" || sub_str == "38")
				{
					ruleLog.Write("Barell Code 37 or 38");
					if ((regex_search(name_desc_list.at(j).MatType, k) != 0) || (regex_search(name_desc_list.at(j).MatType, l) != 0) || (regex_search(name_desc_list.at(j).MatType, m) != 0) || (regex_search(name_desc_list.at(j).MatType, n) != 0)
						|| (regex_search(name_desc_list.at(j).MatType, o) != 0) || (regex_search(name_desc_list.at(j).MatType, p) != 0))
					{

						ruleLog.Write("Pass Condition");
						matchFound = true;
						res_sts = "PASS";
						remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
					}
					else
					{
						ruleLog.Write("Fail Condition");
						matchFound = false;
						res_sts = "FAIL";
						remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
						final_res.result = "FAIL";
						sprintf(remark, "Result :%s.ASM- %s has %s Type\nThe details of spring attachment are given below as PART NAME, BARREL, [DESCRIPTION], [MAT.TYPE].\n", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
						sprintf(remark1, "\n\nAcceptance Critertia :Parts with the following material types and Barrel codes should be used.\n1.Sheet metal(33,37,38)- Fe360, Fe410 , E34, E46, BSK 46, Fe510, SAPH 440, HS800, HS550.");
						sprintf(remark2, "\n2.Casting(33,71,82)- SG 450/12 , SG 500/7, SG 550/6, Gr 340-570W, ADI 900, ADI 1200, GJS 1050/06.");
						final_res.remark = remark + remarkMsg + remark1 + remark2;
						break;
					}

				}
				if (sub_str == "71" || sub_str == "82")
				{
					ruleLog.Write("Barell Code 71 or 82");
					if ((regex_search(name_desc_list.at(j).MatType, a) != 0) || (regex_search(name_desc_list.at(j).MatType, b) != 0) || (regex_search(name_desc_list.at(j).MatType, c) != 0) || (regex_search(name_desc_list.at(j).MatType, d) != 0) || (regex_search(name_desc_list.at(j).MatType, e) != 0)
						|| (regex_search(name_desc_list.at(j).MatType, f) != 0) || (regex_search(name_desc_list.at(j).MatType, g) != 0) || (regex_search(name_desc_list.at(j).MatType, h) != 0) || (regex_search(name_desc_list.at(j).MatType, r) != 0))
					{
						ruleLog.Write("Pass Condition");
						matchFound = true;
						res_sts = "PASS";
						remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
					}
					else
					{
						ruleLog.Write("Fail Condition");
						matchFound = false;
						res_sts = "FAIL";
						remarkMsg += ("\n" + (string)name_desc_list.at(j).part_name + ".PRT" + ", " + to_string(name_desc_list.at(j).barrel) + ", [" + name_desc_list.at(j).description + "], [" + (string)name_desc_list.at(j).MatType + "]" + " (" + res_sts + ")");
						final_res.result = "FAIL";
						sprintf(remark, "Result :%s.ASM- %s has %s Type\nThe details of spring attachment are given below as PART NAME, BARREL, [DESCRIPTION], [MAT.TYPE].\n", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
						sprintf(remark1, "\n\nAcceptance Critertia :Parts with the following material types and Barrel codes should be used.\n1.Sheet metal(33,37,38)- Fe360, Fe410 , E34, E46, BSK 46, Fe510, SAPH 440, HS800, HS550.");
						sprintf(remark2, "\n2.Casting(33,71,82)- SG 450/12 , SG 500/7, SG 550/6, Gr 340-570W, ADI 900, ADI 1200, GJS 1050/06.");
						final_res.remark = remark + remarkMsg + remark1 + remark2;
						break;
					}

				}


			}

			int run;
			if (matchFound == true)
			{
				final_res.result = "PASS";
				ruleLog.Write("Sec--asm :" + sec_asm);
				sprintf(remark, "Result :%s.ASM - %s has %s Type.\nThe details of spring attachment are given below as PART NAME, BARREL, [DESCRIPTION], [MAT.TYPE].\n", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
				sprintf(remark1, "\n\nAcceptance Critertia :Parts with the following material types and Barrel codes should be used.\n1.Sheet metal(33,37,38) - Fe360, Fe410 , E34, E46, BSK 46, Fe510, SAPH 440, HS800, HS550.\n2.Casting(33,71,82) - SG 450/12 , SG 500/7, SG 550/6, Gr 340-570W, ADI 900, ADI 1200, GJS 1050/06.");
				final_res.remark = remark + remarkMsg + remark1;
			}
		}
  
     else
     {
         ruleLog.Write("Leaf-Spring found and material types not found!");
         final_res.result = "FAIL";
         sprintf(remark, "Result :%s.ASM- %s has %s Type.\nThe details of spring attachment is not found.\n\nAcceptance Critertia :Parts with the following material types and Barrel codes should be used.\n1.Sheet metal(33,37,38) - Fe360, Fe410 , E34, E46, BSK 46, Fe510, SAPH 440, HS800, HS550.\n2.Casting(33,71,82) - SG 450/12 , SG 500/7, SG 550/6, Gr 340-570W, ADI 900, ADI 1200, GJS 1050/06..", sec_asm.c_str(), sec_asm_name.c_str(), spring_type.c_str());
          final_res.remark = remark;
   
     }

	reqValsFromCsv.clear();
	name_desc_list.clear();
	leafspringMapList.clear();
	optionMenuSpringTypes.clear();

     }
	 return 0;
}

bool comparePartName(const leafSpringAttachment& a, const leafSpringAttachment& b) 
{
	return std::strcmp(a.part_name, b.part_name) < 0;
}
ProError Typeget(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	//Declarations
	vector<PartnameDescriptionPairM>* prtname_desc_list = (vector<PartnameDescriptionPairM>*)app_data;
	ProMdlType subModuleMdlType;
	ProModelitem modelItem;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ProMdl reqMdl;
	char existingPval[PRO_PATH_SIZE];
	PartnameDescriptionPairM compd;
	string asmname_substr;


	//get the info of components in the model tree

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	//ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
	status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
	//ruleLog.Write("ProMdlTypeGet: " + to_string(status));
	status = ProMdlMdlnameGet(reqMdl, wFeatName);
	//ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(cFeatName, wFeatName);

	if (subModuleMdlType == PRO_MDL_ASSEMBLY)
	{
		ruleLog.Write("Assembly Name: ");
		ruleLog.Write(cFeatName);
		strcpy(compd.part_name, cFeatName);
		asm_name.erase();
		asm_name.append(compd.part_name);
		asmname_substr = asm_name.substr(4, 5);
		//Special function for F4A01 module
		if (asmname_substr == "F4A01")
		{
			//Visit the F4A01 module components
			ruleLog.Write("-----------------------------F4A01_ getParameterDescAndPartname -----------------------------");
			ProSolidFeatVisit((ProSolid)reqMdl, f4A01_getParameterDescAndPartname, compsFilter, (ProAppData)app_data);
		}
		//Special function for F4A02 module
		if (asmname_substr == "F4A02")
		{
			ruleLog.Write("Asm Name: " + asm_name);
			sec_asm = asm_name;
			ruleLog.Write("Sec ASm Name:" + sec_asm);
			status = ProMdlToModelitem(reqMdl, &modelItem);
			ruleLog.Write("ProMdlToModelitem: " + to_string(status));
			ProParameter pDesc;
			ProParamvalue pvDesc;
			ProName pDescName = L"DESCRIPTION";
			ProName pMatName = L"MATERIAL";
			status = ProParameterInit(&modelItem, pDescName, &pDesc);

			if (status == PRO_TK_NO_ERROR)
			{
				ruleLog.Write("Sec ASm Name1:" + sec_asm);
				status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
				ProWstringToString(existingPval, pvDesc.value.s_val);
				ruleLog.Write(" " + to_string(status) + "\nASM_Description: " + existingPval); //+"\n Description: " + existingPval
			}
			sec_asm_name = string(existingPval);
			ruleLog.Write("Sec ASm Name2:" + sec_asm);
			//Visit the F4A02 module components
			ruleLog.Write("-----------------------------F4A02_ getParameterDescAndPartname -----------------------------");
			ProSolidFeatVisit((ProSolid)reqMdl, f4A02_getParameterDescAndPartname, compsFilter, (ProAppData)app_data);
		}

	}
	return PRO_TK_NO_ERROR;
}


ProError f4A01_getParameterDescAndPartname(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("-----------------------------F4A01_getParameterDescAndPartname -----------------------------");
	//Declarations
	vector<PartnameDescriptionPairM>* prtname_desc_list = (vector<PartnameDescriptionPairM>*)app_data;
	ProMdlType subModuleMdlType;
	ProModelitem modelItem;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ProMdl reqMdl;
	char existingPval[PRO_PATH_SIZE];
	PartnameDescriptionPairM compd;
	string asm_name, asmname_substr;

	//get the component info
	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
	status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
	ruleLog.Write("ProMdlTypeGet: " + to_string(status));
	status = ProMdlMdlnameGet(reqMdl, wFeatName);
	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(cFeatName, wFeatName);


	//visting assembly
	if (subModuleMdlType == PRO_MDL_ASSEMBLY)
	{
		ruleLog.Write("Assembly Name: ");
		ruleLog.Write(cFeatName);
		ProSolidFeatVisit((ProSolid)reqMdl, f4A01_getParameterDescAndPartname, compsFilter, (ProAppData)app_data);
	}

	//visiting parts
	if (subModuleMdlType == PRO_MDL_PART)
	{
		status = ProMdlToModelitem(reqMdl, &modelItem);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));
		ProParameter pDesc;
		ProParamvalue pvDesc;
		ProName pDescName = L"DESCRIPTION";
		ProName pMatName = L"MATERIAL";
		status = ProParameterInit(&modelItem, pDescName, &pDesc);

		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ProWstringToString(existingPval, pvDesc.value.s_val);
			ruleLog.Write(" " + to_string(status) + "\nDescription: " + existingPval); //+"\n Description: " + existingPval
		}
		//Printing Visted Assembly -parts name
		strcpy(compd.part_name, cFeatName);
		ruleLog.Write("part_name: " + (string)compd.part_name);

		//getting material type parameter - Printing in main func
		out.erase();
		out.append(compd.part_name);
		tem.erase();
		tem.append(existingPval);

		//filter the parts which names length is 12 and filter the barrell code of 33,37,38,71,82 and filter based on the Descriptions "Bracket","BKT","CAP".
		if ((out.length() == 12))
		{
			comp_sub_str = out.substr(8, 2);
			if ((comp_sub_str == "33") || (comp_sub_str == "37") || (comp_sub_str == "38") || (comp_sub_str == "71") || (comp_sub_str == "82"))
			{
				if ((tem.find("BRACKET") != std::string::npos) || (tem.find("BKT") != std::string::npos))
				{
					if ((tem.find("CAP") != std::string::npos))
					{

					}
					else
					{
						//After filtering the above conditions get the Parameters of the part.
						ruleLog.Write("ifloop");
						status = ProParameterInit(&modelItem, pMatName, &pDesc);
						status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
						ProWstringToString(existingPMatval, pvDesc.value.s_val);
						ruleLog.Write(" " + to_string(status) + "\nMaterial: " + existingPMatval);
						string materialtype;
						materialtype.append(existingPMatval);
						if (strlen(existingPMatval) == 0)
						{

						}
						else
						{
							strcpy(compd.MatType, existingPMatval);
						}
						strcpy(compd.part_name, cFeatName);
						strcpy(compd.description, existingPval);

						compd.barrel = stoi(comp_sub_str);
						prtname_desc_list->push_back(compd);
					}


				}


			}

		}


	}

	return PRO_TK_NO_ERROR;
}

ProError f4A02_getParameterDescAndPartname(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("-----------------------------F4A02_getParameterDescAndPartname -----------------------------");
	//Declarations
	vector<PartnameDescriptionPairM>* prtname_list = (vector<PartnameDescriptionPairM>*)app_data;
	ProMdlType subModuleMdlType;
	ProModelitem modelItem;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ProMdl reqMdl;
	char existingPval[PRO_PATH_SIZE];
	PartnameDescriptionPairM compd;
	string asm_name, asmname_substr;

	//comp info 
	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
	if (status == PRO_TK_NO_ERROR)
	{
		status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
		ruleLog.Write("ProMdlTypeGet: " + to_string(status));
		status = ProMdlMdlnameGet(reqMdl, wFeatName);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
		ProWstringToString(cFeatName, wFeatName);
		ruleLog.Write("Assembly Name: ");
		ruleLog.Write(cFeatName);
		strcpy(compd.part_name, cFeatName);
		ProSolidFeatVisit((ProSolid)reqMdl, f4A02_getParameterDescAndPartname, compsFilter, (ProAppData)app_data);

		status = ProMdlToModelitem(reqMdl, &modelItem);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));
		ProParameter pDesc;
		ProParamvalue pvDesc;
		ProName pDescName = L"DESCRIPTION";
		ProName pMatName = L"MATERIAL";
		status = ProParameterInit(&modelItem, pDescName, &pDesc);

		if (status == PRO_TK_NO_ERROR)
		{
			//Get the descriptions of the all parts in the model tree
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ProWstringToString(existingPval, pvDesc.value.s_val);
			ruleLog.Write("ProParameterValueGet =" + to_string(status) + "\nDescription: " + existingPval);
			string partname;
			partname.erase();
			partname.append(existingPval);
			ruleLog.Write("Check if conditions");
			spring_info.push_back(existingPval);
		}
	}


	return PRO_TK_NO_ERROR;
}