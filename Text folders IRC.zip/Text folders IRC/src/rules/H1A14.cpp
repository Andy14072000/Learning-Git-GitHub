/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 20-06-2023	|	V1_0_0		| H1A06 - ENGINE ASSY
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#include "H1A14.h"

/*==================================================================================================================
RULE ID            | DEVELOPER            | DEPENDENT MODULES    | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRH1A06_001        | Vinay Neel           | MH1A14    |  For HCV Application-For location of Deaeration Tank, minimum Coolant level mark should be above Radiator top tank position. (vent point surface)
===================================================================================================================*/
#define dlg_IR_H1A14_001 "dlg_IR_H1A14_001"
#define PB_RSELECT		"pb_select"
#define PB_RCANCEL       "CommitCancel"
#define PB_RUN           "pb_run"

ProSelection* surf_Sel_H1A14_001;
string rem_messageH1A14_001;

struct SurfData_H1A14 {
	string part_name;
	int id;
};
int IRH1A14::IRH1A14_001(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRH1A06::IRH1A14_001   ==========================");
	rem_messageH1A14_001 = "";
	SurfData_H1A14 data;
	vector<SurfData_H1A14> surf_data;
	isUserQuits = false;
	status = ProUIDialogCreate(dlg_IR_H1A14_001, dlg_IR_H1A14_001);
	status = ProUIDialogAboveactivewindowSet(dlg_IR_H1A14_001, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A14_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A14_001, PB_RUN, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A14_001, PB_RSELECT, (ProUIAction)select_action_IRH1A06_001, NULL);

	status = ProUIPushbuttonDisable(dlg_IR_H1A14_001, PB_RUN);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(dlg_IR_H1A14_001, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(dlg_IR_H1A14_001);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;


	double distance;
	ProBoolean is_interference_found;
	Pro3dPnt pnt_arr[2];
	status = ProFitClearanceCompute(surf_Sel_H1A14_001[0], PRO_FIT_INCLUDE_NONE, surf_Sel_H1A14_001[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, surf_Sel_H1A14_001[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));
	ruleLog.Write("pnt_arr[0][0]: " + to_string(pnt_arr[0][0]));
	ruleLog.Write("pnt_arr[0][1]: " + to_string(pnt_arr[0][1]));
	ruleLog.Write("pnt_arr[0][2]: " + to_string(pnt_arr[0][2]));
	ruleLog.Write("pnt_arr[1][0]: " + to_string(pnt_arr[1][0]));
	ruleLog.Write("pnt_arr[1][1]: " + to_string(pnt_arr[1][1]));
	ruleLog.Write("pnt_arr[1][2]: " + to_string(pnt_arr[1][2]));

	for (int i = 0; i < 2; i++) {
		ProMdlName		wname;
		char            cname[PRO_MDLNAME_SIZE];
		ProFeature feature;

		status = ProSelectionModelitemGet(surf_Sel_H1A14_001[i], &feature);
		status = ProMdlMdlnameGet(feature.owner, wname);
		ProWstringToString(cname, wname);
		data.part_name = cname;
		data.id = feature.id;
		surf_data.push_back(data);
		ruleLog.Write("part_names: " + to_string(data.id));
	}

	if (pnt_arr[0][1] < pnt_arr[1][1])
	{

		ruleLog.Write("Min mark is above the radiator top tank");
		final_res.result = "PASS";

		rem_messageH1A14_001 += "Result: \n\nMinimum Coolant level mark is above Radiator top tank position at a distance of";
		sprintf(remark, " %.2lf mm.", distance);
		rem_messageH1A14_001 += remark;

		rem_messageH1A14_001 += "\n\nAcceptance Criteria : Minimum Coolant level mark should be above Radiator top tank position.";

		rem_messageH1A14_001 += "\nUsed Reference part : " + string(surf_data[0].part_name) + ".PRT" + " (Id :" + string(to_string(surf_data[0].id)) + ")";
		rem_messageH1A14_001 += "\nUsed Reference part : " + string(surf_data[1].part_name) + ".PRT" + " (Id :" + string(to_string(surf_data[1].id)) + ")";

		final_res.remark = rem_messageH1A14_001;

		//  sprintf(remark, "Result - Minimum Coolant level mark is above Radiator top tank position at a distance of %0.2lf mm\n\nAcceptance Criteria - Minimum Coolant level mark should be above Radiator top tank position;\n\nUsed Reference part : %s.PRT (Surf. Id : %s);Used Reference part : %s.PRT (Surf. Id : %s)", distance,(surf_data[0].part_name).c_str(), (to_string(surf_data[0].id)).c_str(), (surf_data[1].part_name).c_str(), (to_string(surf_data[1].id)).c_str());

	}
	else
	{
		ruleLog.Write("Min mark is below the radiator top tank");
		final_res.result = "FAIL";

		rem_messageH1A14_001 += "Result: \n\nMinimum Coolant level mark is below Radiator top tank position at a distance of";
		sprintf(remark, " %.2lf mm.", distance);
		rem_messageH1A14_001 += remark;

		rem_messageH1A14_001 += "\n\nAcceptance Criteria : Minimum Coolant level mark should be above Radiator top tank position.";

		rem_messageH1A14_001 += "\nUsed Reference part : " + string(surf_data[0].part_name) + ".PRT" + " (Id :" + string(to_string(surf_data[0].id)) + ")";
		rem_messageH1A14_001 += "\nUsed Reference part : " + string(surf_data[1].part_name) + ".PRT" + " (Id :" + string(to_string(surf_data[1].id)) + ")";

		final_res.remark = rem_messageH1A14_001;
		//  sprintf(remark, "Result - Minimum Coolant level mark is below Radiator top tank position at a distance of %0.2lf mm\n\nAcceptance Criteria - Minimum Coolant level mark should be above Radiator top tank position;\n\nUsed Reference part : %s.PRT (Surf. Id : %s);Used Reference part : %s.PRT (Surf. Id : %s)", distance,(surf_data[0].part_name).c_str(), (to_string(surf_data[0].id)).c_str(), (surf_data[1].part_name).c_str(), (to_string(surf_data[1].id)).c_str());

	}

	//final_res.remark = remark;


	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	surf_data.clear();
	rem_messageH1A14_001.clear();
	return 0;
}

ProError select_action_IRH1A06_001(char* dialog, char* component, ProAppData data)
{

	int n_sels;

	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surf_Sel_H1A14_001, &n_sels);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(dlg_IR_H1A14_001, PB_RUN);
		return status;
	}
	if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dlg_IR_H1A14_001, PB_RUN);
		return status;
	}

	if (n_sels > 0 && n_sels == 2) {
		status = ProUIPushbuttonEnable(dlg_IR_H1A14_001, PB_RUN);
		return status;
	}

	return status;
}



/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR_H1A14_002	| MATHANPRASATH A	| MH1A14, MH1A01	| For HCV Application-For the open blade fan , Radial Clearance between Fan blade Tip & Shroud should be minimum 18 mm.
===================================================================================================================*/
#define dlg_IR_H1A14_002     "dlg_IR_H1A14_002" 
#define FUEL_CAPACITY	     "select_option_menu"
#define PLATFRM_LIST         "platform_option_menu"
#define PB_CANCEL		     "CommitCancel" 
#define PB_OK			     "CommitOK"
#define PB_SELECT            "select_pb"
ProSelection* sel_surf_H1A14_002;
int numsurf_sels_H1A14_002;

int IRH1A14::IRH1A14_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRH1A14::IRH1A14_002   ==========================");

	double fan_dis, dia1, dia2;
	ProCharPath surf_Parents_info{};
	isUserQuits = false;
	status = ProUIDialogCreate(dlg_IR_H1A14_002, dlg_IR_H1A14_002);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(dlg_IR_H1A14_002, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A14_002, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A14_002, PB_OK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A14_002, PB_SELECT, (ProUIAction)select_action_IRH1A14_002, (ProAppData)&isUserQuits);
	ruleLog.Write("fuel_cap_ProUIOptionmenuSelectActionSet: " + to_string(status));


	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(dlg_IR_H1A14_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(dlg_IR_H1A14_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;
	ProModelitem surf_1, surf_2;
	ProFeature surf_feat1, surf_feat2;
	ProMdl sur_mdl1, sur_mdl2;
	wchar_t wsurmdlName1[PRO_NAME_SIZE];
	char csurmdlName1[PRO_NAME_SIZE];
	wchar_t wsurmdlName2[PRO_NAME_SIZE];
	char csurmdlName2[PRO_NAME_SIZE];
	status = ProSelectionModelitemGet(sel_surf_H1A14_002[0], &surf_1);
	status = ProSelectionModelitemGet(sel_surf_H1A14_002[1], &surf_2);

	status = ProGeomitemFeatureGet((ProGeomitem*)&surf_1, &surf_feat1);
	ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id1 = " + to_string(surf_feat1.id));

	status = ProGeomitemFeatureGet((ProGeomitem*)&surf_2, &surf_feat2);
	ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id2 = " + to_string(surf_feat2.id));


	status = ProModelitemMdlGet(&surf_1, &sur_mdl1);
	status = ProModelitemMdlGet(&surf_2, &sur_mdl2);

	status = ProMdlMdlnameGet(sur_mdl1, wsurmdlName1);
	ProWstringToString(csurmdlName1, wsurmdlName1);
	ruleLog.Write("Axis model Name :" + string(csurmdlName1));
	status = ProMdlMdlnameGet(sur_mdl2, wsurmdlName2);
	ProWstringToString(csurmdlName2, wsurmdlName2);
	ruleLog.Write("Axis model Name :" + string(csurmdlName2));

	status = ProGeomitemDiameterEval(sel_surf_H1A14_002[0], &dia1);
	ruleLog.Write("measureDistanceBetweenSurfaces status= " + to_string(status) + "\nFan Blade distance " + to_string(dia1));
	status = ProGeomitemDiameterEval(sel_surf_H1A14_002[1], &dia2);
	ruleLog.Write("measureDistanceBetweenSurfaces status= " + to_string(status) + "\nFan Blade distance " + to_string(dia2));
	/*status = measureDistanceBetweenSurfaces(sel_surf[0], sel_surf[1],fan_dis);
	ruleLog.Write("measureDistanceBetweenSurfaces status= " + to_string(status) + "\nFan Blade distance " + to_string(fan_dis));*/
	double act_dia1 = dia1 / 2.0;
	ruleLog.Write("actual dia1 =" + to_string(act_dia1));
	double act_dia2 = dia2 / 2.0;
	ruleLog.Write("actual dia2 =" + to_string(act_dia2));
	double act_dia = act_dia1 - act_dia2;
	ruleLog.Write("actual dia =" + to_string(act_dia));

	if (act_dia < 0)
	{
		act_dia = std::abs(act_dia);

	}


	if (act_dia >= 18)
	{
		final_res.result = "PASS";
		ruleLog.Write("actual dia =" + to_string(act_dia));
		sprintf(remark, "Measured Value: Distance between fan blade tip and Shroud is %0.2lf mm.\nAcceptance Criteria : Radial Clearance between Fan blade Tip and Shroud should be minimum 18 mm.", act_dia);
		sprintf(surf_Parents_info, "\nReferences:\nSurface_id 1: %d, Partnumber: %s.\nSurface_id 2: %d, Partnumber: %s.", surf_feat1.id, csurmdlName1, surf_feat2.id, csurmdlName2);
		final_res.remark = string(remark) + surf_Parents_info;
	}
	else
	{
		final_res.result = "FAIL";
		ruleLog.Write("actual dia =" + to_string(act_dia));
		sprintf(remark, "Measured Value: Distance between fan blade tip and Shroud is %0.2lf mm.\nAcceptance Criteria : Radial Clearance between Fan blade Tip and Shroud should be minimum 18 mm.", act_dia);
		sprintf(surf_Parents_info, "\nReferences:\nSurface_id 1: %d, Partnumber: %s.\nSurface_id 2: %d, Partnumber: %s.", surf_feat1.id, csurmdlName1, surf_feat2.id, csurmdlName2);
		final_res.remark = string(remark) + surf_Parents_info;
	}

	/* your code goes here */

	return 0;
}

ProError select_action_IRH1A14_002(char* dialog, char* component, ProAppData data)
{
	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &sel_surf_H1A14_002, &numsurf_sels_H1A14_002);
	ruleLog.Write("Proselect status= " + to_string(status) + "\nNo.of Selection " + to_string(numsurf_sels_H1A14_002));

	if (status == PRO_TK_NO_ERROR)
	{
		status = ProUIPushbuttonEnable(dialog, PB_OK);
		ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));
	}
	return status;
}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-H1A11-001	| Surendra Sarode	| MH1A14, MH1A01 	| For HCV Application-For engine Mounted Fan & radiator core, minimum allowable gap required is 50 mm
===================================================================================================================*/

#define DLG_IRH1A14_003 "dlg_IR_H1A14_003"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"
#define PB_RSELECT		"pb_select"

static ProSelection PartSelectioncpy;
static ProSelection SurfSelectioncpy;

int IRH1A14::IRH1A14_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRH2C01::IRH1A14_003   ==========================");

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRH1A14_003, DLG_IRH1A14_003);
	status = ProUIDialogAboveactivewindowSet(DLG_IRH1A14_003, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH1A14_003, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH1A14_003, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH1A14_003, PB_RSELECT, (ProUIAction)select_action_IRH1A11_001, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRH1A14_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRH1A14_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	double minimumclearance1 = 50.0;
	Pro2dPnt param_1, param_2;
	Pro3dPnt pnt_1[2];
	double distance;

	status = ProSelectionWithOptionsDistanceEval(PartSelectioncpy, PRO_B_TRUE, SurfSelectioncpy, PRO_B_TRUE, param_1, param_2, pnt_1[0], pnt_1[1], &distance);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tDistance: " + to_string(distance));
	//createDatumPoints(pnt_1, "CSYS_ASM_DEF", "distance_point1");

	//	ruleLog.Write("SS: " + to_string(pnt_1[0][0]));
	//	ruleLog.Write("SS: " + to_string(pnt_1[0][1]));
	//	ruleLog.Write("SS: " + to_string(pnt_1[0][2]));

	//	ruleLog.Write("SS: " + to_string(pnt_1[1][0]));
	//	ruleLog.Write("SS: " + to_string(pnt_1[1][1]));
	//	ruleLog.Write("SS: " + to_string(pnt_1[1][2]));

	//ProBoolean is_interference_found;
	//Pro3dPnt pnt_arr1[2];
	//double distance1;
	//status = ProFitClearanceCompute(PartSelectioncpy, PRO_FIT_INCLUDE_NONE, SurfSelectioncpy, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance1, NULL, &is_interference_found, pnt_arr1);
	//createDatumPoints(pnt_arr1, "CSYS_ASM_DEF", "distance_pnnt2");
	//ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tDistance: " + to_string(distance1));

	//ProBoolean interf;
	//Pro3dPnt coord[2];
	//status = ProFitClearanceCompute(PartSelectioncpy, PRO_FIT_INCLUDE_NONE, SurfSelectioncpy, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance, NULL, &interf, coord);
	if (status != PRO_TK_NO_ERROR && status != PRO_TK_OUT_OF_RANGE) {
		UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selected parts.");
		return -1;
	}

	ProModelitem mdlitem1, mdlitem2;
	ProMdl Mdl1, Mdl2;
	ProMdlName wFanname, wRadName;
	char cFanname[PRO_NAME_SIZE];
	char cRadname[PRO_NAME_SIZE];
	vector<int> surId;
	vector<string> names;

	status = ProSelectionModelitemGet(PartSelectioncpy, &mdlitem1);
	status = ProSelectionModelitemGet(SurfSelectioncpy, &mdlitem2);
	status = ProModelitemMdlGet(&mdlitem1, &Mdl1);
	status = ProModelitemMdlGet(&mdlitem2, &Mdl2);
	status = ProMdlMdlnameGet(Mdl1, wFanname);
	status = ProMdlMdlnameGet(Mdl2, wRadName);
	ProWstringToString(cFanname, wFanname);
	ProWstringToString(cRadname, wRadName);
	ruleLog.Write("surId: " + to_string(mdlitem2.id));

	//DECLARE RESULT
	if (distance < minimumclearance1)
	{
		final_res.result = "FAIL";
		sprintf(remark, "Minimum clearance between Fan ( Part No.: %s ) and\nRadiator core ( Part No.: %s and surface Id: %s) found is %.2lf mm,\n\nAcceptance Criteria: Clearance between engine mounted fan and radiator core >= 50.0 mm  ", cFanname, cRadname, to_string(mdlitem2.id), distance);
		final_res.remark = string(remark);
	}
	else
	{
		final_res.result = "PASS";
		sprintf(remark, "Minimum clearance between Fan ( Part No.: %s ) and\nRadiator core ( Part No.: %s and surface Id: %s ) found is %.2lf mm,\n\nAcceptance Criteria: Clearance between engine mounted fan and radiator core >= 50.0 mm ", cFanname, cRadname, to_string(mdlitem2.id), distance);
		final_res.remark = string(remark);
	}

	ruleLog.Write("status: " + string(final_res.result));
	ruleLog.Write("remark: " + string(final_res.remark));

	return 0;
}

ProError select_action_IRH1A11_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRH1A11_001  --------------------------");
	int n_sels1;
	int n_sels2;
	ProSelection* PartSelection;
	ProSelection* SurfSelection;

	status = ProSelect("part", 1, NULL, NULL, NULL, NULL, &PartSelection, &n_sels1);
	status = ProSelectionCopy(PartSelection[0], &PartSelectioncpy);
	ruleLog.Write("ProSelectionCopy: " + to_string(status));

	status = ProSelect("surface", 1, NULL, NULL, NULL, NULL, &SurfSelection, &n_sels2);
	status = ProSelectionCopy(SurfSelection[0], &SurfSelectioncpy);
	ruleLog.Write("ProSelectionCopy: " + to_string(status));

	if (status == PRO_TK_NO_ERROR && n_sels1 > 0 && n_sels2 > 0) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	}
	return status;
}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES					| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-H1A14-004	| Prajakta Bhelawe	| MH1A14;H1A01	| For HCV Application-For the Jet Ring fan ,Radial & axial clearance between Fan blade tip & Shroud should be minimum 18 mm
===================================================================================================================*/
#define dlg_IR_H1A14_004  "dlg_IR_H1A14_004"
#define PB_ROK			  "CommitOK"
#define PB_RCANCEL		  "CommitCancel"
#define PB_RSELECT_EDGE    "pb_select_edge"
#define PB_RSELECT_SURFACE "pb_select_surface"

ProSelection* surf_sel_H1A14;
ProSelection* edge_sel_H1A14;
int n_sels_surface, n_sels_edge;
ProSelection sel_edge;
ProSelection sel_surface1, sel_surface2, sel_surface3;
vector<string> name_surf, name_edge;

int IRH1A14::IRH1A14_004(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRH1A14::IRH1A14_004   ==========================");

	isUserQuits = false;
	string remarkFanSh;

	status = ProUIDialogCreate(dlg_IR_H1A14_004, dlg_IR_H1A14_004);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(dlg_IR_H1A14_004, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A14_004, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	if (isUserQuits)
		return -1;

	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A14_004, PB_RSELECT_EDGE, (ProUIAction)select_action_edge, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet = " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A14_004, PB_RSELECT_SURFACE, (ProUIAction)select_action_surface, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet = " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A14_004, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));


	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(dlg_IR_H1A14_004, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(dlg_IR_H1A14_004);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	double clearance_value1, clearance_value2, clearance_value3;

	ruleLog.Write("n_sels_edge = " + to_string(n_sels_edge));
	ruleLog.Write("n_sels_surface = " + to_string(n_sels_surface));

	Pro2dPnt param_1, param_2;
	Pro3dPnt pnt_arr1[2];
	Pro3dPnt pnt_arr2[2];
	Pro3dPnt pnt_arr3[2];

	for (int i = 0; i < name_surf.size(); i++)
	{
		ruleLog.Write("name_surf = " + name_surf[i]);
		ruleLog.Write("name_edge = " + name_edge[0]);
	}

	status = ProSelectionWithOptionsDistanceEval(sel_edge, PRO_B_FALSE, sel_surface1, PRO_B_FALSE, param_1, param_2, pnt_arr1[0], pnt_arr1[1], &clearance_value1);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));

	status = ProSelectionWithOptionsDistanceEval(sel_edge, PRO_B_FALSE, sel_surface2, PRO_B_FALSE, param_1, param_2, pnt_arr2[0], pnt_arr2[1], &clearance_value2);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));

	status = ProSelectionWithOptionsDistanceEval(sel_edge, PRO_B_FALSE, sel_surface3, PRO_B_FALSE, param_1, param_2, pnt_arr3[0], pnt_arr3[1], &clearance_value3);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));

	ruleLog.Write("clearance_value1 = " + to_string(clearance_value1));
	ruleLog.Write("clearance_value2 = " + to_string(clearance_value2));
	ruleLog.Write("clearance_value3 = " + to_string(clearance_value3));

	string strClearance1;
	strClearance1 = to_string(clearance_value1);

	string result1;
	size_t dotPos1 = strClearance1.find('.');

	if (dotPos1 != std::string::npos) {
		// Check if there are at least two characters after the decimal point
		if (dotPos1 + 3 <= strClearance1.size()) {
			result1 = strClearance1.substr(0, dotPos1 + 3);  // Include the dot and two characters after
		}
		else {
			// Less than two characters after the decimal point
			result1 = strClearance1.substr(0, dotPos1 + 1);  // Include only up to the decimal point
		}
	}
	else {
		// No decimal point found
		result1 = strClearance1;
	}

	//2nd
	string strClearance2;
	strClearance2 = to_string(clearance_value2);

	string result2;
	size_t dotPos2 = strClearance2.find('.');

	if (dotPos2 != std::string::npos) {
		// Check if there are at least two characters after the decimal point
		if (dotPos2 + 3 <= strClearance2.size()) {
			result2 = strClearance2.substr(0, dotPos2 + 3);  // Include the dot and two characters after
		}
		else {
			// Less than two characters after the decimal point
			result2 = strClearance2.substr(0, dotPos2 + 1);  // Include only up to the decimal point
		}
	}
	else {
		// No decimal point found
		result2 = strClearance2;
	}

	//3rd
	string strClearance3;
	strClearance3 = to_string(clearance_value3);

	string result3;
	size_t dotPos3 = strClearance3.find('.');

	if (dotPos3 != std::string::npos) {
		// Check if there are at least two characters after the decimal point
		if (dotPos3 + 3 <= strClearance3.size()) {
			result3 = strClearance3.substr(0, dotPos3 + 3);  // Include the dot and two characters after
		}
		else {
			// Less than two characters after the decimal point
			result3 = strClearance3.substr(0, dotPos3 + 1);  // Include only up to the decimal point
		}
	}
	else {
		// No decimal point found
		result3 = strClearance3;
	}


	status = ProWindowRepaint(PRO_VALUE_UNUSED);

	if (clearance_value1 >= 18 && clearance_value2 >= 18 && clearance_value3 >= 18)
	{
		final_res.result = "PASS";
		status = ProSelectionHighlight(sel_edge, PRO_COLOR_SS_REPLACED_COMPS);
		ruleLog.Write("ProSelectionHighlight: " + to_string(status));

		status = ProSelectionHighlight(sel_surface1, PRO_COLOR_SHEETMETAL);
		ruleLog.Write("ProSelectionHighlight: " + to_string(status));

		status = ProSelectionHighlight(sel_surface2, PRO_COLOR_SHEETMETAL);
		ruleLog.Write("ProSelectionHighlight: " + to_string(status));

		status = ProSelectionHighlight(sel_surface3, PRO_COLOR_SHEETMETAL);
		ruleLog.Write("ProSelectionHighlight: " + to_string(status));
	}

	else
	{
		final_res.result = "FAIL";

		if (clearance_value1 < 18)
		{
			status = ProSelectionHighlight(sel_edge, PRO_COLOR_SS_FAILED_ITEMS);
			ruleLog.Write("ProSelectionHighlight: " + to_string(status));

			status = ProSelectionHighlight(sel_surface1, PRO_COLOR_SS_FAILED_ITEMS);
			ruleLog.Write("ProSelectionHighlight: " + to_string(status));
		}

		if (clearance_value2 < 18)
		{
			status = ProSelectionHighlight(sel_edge, PRO_COLOR_SS_FAILED_ITEMS);
			ruleLog.Write("ProSelectionHighlight: " + to_string(status));

			status = ProSelectionHighlight(sel_surface2, PRO_COLOR_SS_FAILED_ITEMS);
			ruleLog.Write("ProSelectionHighlight: " + to_string(status));
		}

		if (clearance_value3 < 18)
		{
			status = ProSelectionHighlight(sel_edge, PRO_COLOR_SS_FAILED_ITEMS);
			ruleLog.Write("ProSelectionHighlight: " + to_string(status));

			status = ProSelectionHighlight(sel_surface3, PRO_COLOR_SS_FAILED_ITEMS);
			ruleLog.Write("ProSelectionHighlight: " + to_string(status));
		}
	}

	remarkFanSh += "Clearance between Shroud " + name_surf[0] + ".PRT and Fan " + name_edge[0] + ".PRT = " + result1 + "mm, " + result2 + "mm, " + result3 + "mm.";
	remarkFanSh += "\nAcceptance Criteria : Clearance between Fan and Shroud should be minimum 18mm.";

	final_res.remark = string(remarkFanSh);

	name_surf.clear();
	name_edge.clear();
	remarkFanSh.clear();

	return 0;
}

ProError select_action_edge(char* dialog, char* component, ProAppData data)
{
	ProModelitem egde_model_item;
	ProName name;
	ProMdl owner;
	ProModelitem part_model_item;
	char str_name[PRO_NAME_SIZE];


	status = ProSelect("edge", 1, NULL, NULL, NULL, NULL, &edge_sel_H1A14, &n_sels_edge);
	ruleLog.Write("ProSelect = " + to_string(status));

	if (status == PRO_TK_NO_ERROR && n_sels_edge > 0 && n_sels_surface > 2) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	}

	status = ProSelectionModelitemGet(edge_sel_H1A14[0], &egde_model_item);
	ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

	status = ProMdlMdlnameGet(egde_model_item.owner, name);
	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

	ruleLog.Write("ProWstringToString: " + string(ProWstringToString(str_name, name)));
	name_edge.push_back(str_name);

	status = ProSelectionCopy(edge_sel_H1A14[0], &sel_edge);
	ruleLog.Write("ProSelectionCopy edge = " + to_string(status));

	return status;
}

ProError select_action_surface(char* dialog, char* component, ProAppData data)
{
	ProModelitem surf_model_item;
	ProName name;
	ProMdl owner;
	ProModelitem part_model_item;
	char str_name[PRO_NAME_SIZE];

	status = ProSelect((char*)"surface", 3, NULL, NULL, NULL, NULL, &surf_sel_H1A14, &n_sels_surface);
	ruleLog.Write("ProSelect = " + to_string(status));

	if (status == PRO_TK_NO_ERROR && n_sels_edge > 0 && n_sels_surface > 2) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	}

	for (int i = 0; i < n_sels_surface; i++)
	{
		status = ProSelectionModelitemGet(surf_sel_H1A14[i], &surf_model_item);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

		status = ProMdlMdlnameGet(surf_model_item.owner, name);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

		ruleLog.Write("ProWstringToString: " + string(ProWstringToString(str_name, name)));
		name_surf.push_back(str_name);

	}

	status = ProSelectionCopy(surf_sel_H1A14[0], &sel_surface1);
	ruleLog.Write("ProSelectionCopy surface = " + to_string(status));
	status = ProSelectionCopy(surf_sel_H1A14[1], &sel_surface2);
	ruleLog.Write("ProSelectionCopy surface = " + to_string(status));
	status = ProSelectionCopy(surf_sel_H1A14[2], &sel_surface3);
	ruleLog.Write("ProSelectionCopy surface = " + to_string(status));

	return status;
}
