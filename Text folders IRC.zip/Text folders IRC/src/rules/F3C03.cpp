/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F3B04 - EXHAUST SYSTEM RULES
==================================================================================================================*/
#include "F3C03.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES					| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F3C03-004	| Pallavi Garodi	| MF3C03; MF3C04; MH1A01	| For all the standardized frame width RH arm of  mounting bracket distance from frame to be standardized.
===================================================================================================================*/

#define DLG_IRF3C03_004     "dlg_IR_F3C03_004"
#define CommitOK            "CommitOK"
#define CommitCancel		"CommitCancel"
#define PB_SELECT           "select_pb"
#define PB_SELECT2          "select_pb2"
#define Radio               "RadioGroup_1"

ProSelection       *sur_sel, *sur_edge_sel;
double              surf_dis1, surf_dis2;
int                 num_surf_sel, num, LH_arm;
vector<double>      bracketDistance1, bracketDistance2;
vector<string>      Surf_Name, Surf_Name2;
vector<int>         Surf_id, Surf_id2;


ProMdl	            parent_mdl;
wchar_t             wParentMdlName[PRO_NAME_SIZE];
ProModelitem        modelItem;
ProParameter        pDesc;
ProParamvalue       pvDesc;
ProName             pDescName = L"DESCRIPTION";
ProAsmcomppath	    Sel_comp_path;
char                MdlName[PRO_NAME_SIZE];
ProAnnotationElem   annotelem;

int IRF3C03::IRF3C03_004(ruleResult& final_res)
{
    bracketDistance1.clear();
    bracketDistance2.clear();
    Surf_id.clear();
    Surf_id2.clear();
    Surf_Name.clear();
    Surf_Name2.clear();

    ruleLog.Write("==========================   IRF3C03::IRF3C03_004   ==========================");
    isUserQuits = false;
    status = ProUIDialogCreate(DLG_IRF3C03_004, DLG_IRF3C03_004);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF3C03_004, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF3C03_004, PB_SELECT, (ProUIAction)select_action1_IRF3C03_004, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF3C03_004, PB_SELECT2, (ProUIAction)select_action2_IRF3C03_004, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF3C03_004, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF3C03_004, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIRadiogroupSelectActionSet(DLG_IRF3C03_004, Radio, (ProUIAction)rg_select_action_IRF3C03_004, NULL);
    ruleLog.Write("ProUIRadiogroupSelectActionSet status: " + to_string(status));

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF3C03_004, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF3C03_004);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    if (((to_string(bracketDistance1[0])) == (to_string(bracketDistance1[1]))) && ((to_string(bracketDistance2[0])) == (to_string(bracketDistance2[1])))) {
        final_res.result = "PASS";
    }
    else {
        final_res.result = "FAIL";
    }
        

   string rem_message;

   rem_message += "For RH arm\nDistance between frame and mounting bracket is " + doubleToString(bracketDistance1[0]) + " mm.";
   rem_message += "\nDistance between bolt surface and edge of the mounting bracket is " + doubleToString(bracketDistance2[0])+ " mm";

   rem_message += "\n\nFor LH arm\nDistance between frame and mounting bracket is " + doubleToString(bracketDistance1[1]) + " mm.";
   rem_message += "\nDistance between bolt surface and edge of the mounting bracket is " + doubleToString(bracketDistance2[1]) + " mm.";

   rem_message += "\n\nAcceptance criteria";
   rem_message += "\nFor all the standardized frame width RH and LH arm of mounting bracket distance from frame to be standardized.";

   rem_message += "\n\nSelected refrences for RH Arm:-(Part No & Surface ID)\n" + Surf_Name[0] +".prt(Feature Id:- "+to_string(Surf_id[1]) +")";
   rem_message += "\n"+ Surf_Name2[0] + ".prt(Feature Id:-" + to_string(Surf_id2[1]) + ")";
   rem_message += "\n\nSelected refrences for LH Arm:-(Part No & Surface ID)\n" + Surf_Name[2] + ".prt(Feature Id:-" + to_string(Surf_id[3]) + ")";
   rem_message += "\n" + Surf_Name2[2] + ".prt(Feature Id : -" + to_string(Surf_id2[3]) + ")";
   final_res.remark = rem_message;

    bracketDistance1.clear();
    bracketDistance2.clear();
    Surf_id.clear();
    Surf_id2.clear();
    Surf_Name.clear();
    Surf_Name2.clear();
    return 0;

}

ProError rg_select_action_IRF3C03_004(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("============== rg_select_action_IRF3C03_005 ==============");
    
    char** buttonNames;
    char R1[PRO_NAME_SIZE] = "rb1";
    char* ptrR1 = R1;
    char R2[PRO_NAME_SIZE] = "rb2";
    char* ptrR2 = R2;

    status = ProUIRadiogroupSelectednamesSet(dialog, component, 1, &ptrR1);
    ruleLog.Write("ProUIRadiogroupSelectednamesSet: " + to_string(status));

    if ((bracketDistance1.size() == 1) && (bracketDistance2.size() == 1)) {
        status = ProUIRadiogroupSelectednamesSet(dialog, component, 1, &ptrR2);
        ruleLog.Write("ProUIRadiogroupSelectednamesSet: " + to_string(status));
        LH_arm++;
        status = ProUIPushbuttonEnable(dialog, PB_SELECT);
        status = ProUIPushbuttonEnable(dialog, PB_SELECT2);
    }

    return status;

}

ProError select_action1_IRF3C03_004(char* dialog, char* component, ProAppData data)
{
    InterfaceRule     _irule;
    int               curWinId;

    ProWindowCurrentGet(&curWinId);
    ProWindowRepaint(curWinId);

    status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &sur_sel, &num_surf_sel);
    ruleLog.Write("ProSelect: " + to_string(status));

    if (status == PRO_TK_USER_ABORT) {
        status = ProUIPushbuttonDisable(dialog, RULE_UI_OK);
        _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide inputs again!. Refer help document for details.");
        status = ProUIDialogShow(dialog);
        return status;
    }

    if (num_surf_sel < 2 || status != PRO_TK_NO_ERROR) {
        _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
        status = ProUIDialogShow(dialog);
        status = ProUIPushbuttonDisable(dialog, RULE_UI_OK);
        return status;
    }
    status = _irule.measureDistanceBetweenSurfaces(sur_sel[0], sur_sel[1], surf_dis1);
    ruleLog.Write("measureDistanceBetweenSurfaces1: " + to_string(status));

    bracketDistance1.push_back(surf_dis1);
    
    status = ProUIPushbuttonDisable(dialog, PB_SELECT);

    for (int i = 0; i < num_surf_sel; ++i) {
        status = ProSelectionAsmcomppathGet(sur_sel[i], &Sel_comp_path);
        //ruleLog.Write("ProSelectionAsmcomppathGet = " + to_string(status));

        status = ProAsmcomppathMdlGet(&Sel_comp_path, &parent_mdl);
        //ruleLog.Write("ProAsmcomppathMdlGet = " + to_string(status));

        status = ProMdlMdlnameGet(parent_mdl, wParentMdlName);
        ProWstringToString(MdlName, wParentMdlName);
        ruleLog.Write("cParentMdlName = " + (string)MdlName);
        Surf_Name2.push_back(MdlName);

        status = ProSelectionModelitemGet(sur_sel[i], &annotelem);
        ruleLog.Write("ProSelectionModelitemGet: " + to_string(status) + "\tSurface Id: " + to_string(annotelem.id));
        Surf_id2.push_back(annotelem.id);
    }

    return status;
}

ProError select_action2_IRF3C03_004(char* dialog, char* component, ProAppData data)
{
    InterfaceRule     _irule;
    int               curWinId;

    ProWindowCurrentGet(&curWinId);
    ProWindowRepaint(curWinId);

    status = ProSelect((char*)"surface,edge", 2, NULL, NULL, NULL, NULL, &sur_edge_sel, &num);
    ruleLog.Write("ProSelect: " + to_string(status));

    if (status == PRO_TK_USER_ABORT) {
        status = ProUIPushbuttonDisable(dialog, RULE_UI_OK);
        _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide inputs again!. Refer help document for details.");
        status = ProUIDialogShow(dialog);
        return status;
    }

    if (num < 2 || status != PRO_TK_NO_ERROR) {
        _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
        status = ProUIDialogShow(dialog);
        status = ProUIPushbuttonDisable(dialog, RULE_UI_OK);
        return status;
    }
    status = _irule.measureDistanceBetweenSurfaces(sur_sel[0], sur_sel[1], surf_dis2);
    ruleLog.Write("measureDistanceBetweenSurfaces1: " + to_string(status));

   /* if (LH_arm == 1) {
        bracketDistance2.push_back(surf_dis1);
    }
    else {*/
        bracketDistance2.push_back(surf_dis2);
    //}
    status = ProUIPushbuttonDisable(dialog, PB_SELECT2);

    for (int i = 0; i < num_surf_sel; ++i) {
        status = ProSelectionAsmcomppathGet(sur_sel[i], &Sel_comp_path);
        //ruleLog.Write("ProSelectionAsmcomppathGet = " + to_string(status));

        status = ProAsmcomppathMdlGet(&Sel_comp_path, &parent_mdl);
        //ruleLog.Write("ProAsmcomppathMdlGet = " + to_string(status));

        status = ProMdlMdlnameGet(parent_mdl, wParentMdlName);
        ProWstringToString(MdlName, wParentMdlName);
        ruleLog.Write("cParentMdlName = " + (string)MdlName);
        Surf_Name.push_back(MdlName);

        status = ProSelectionModelitemGet(sur_sel[i], &annotelem);
        ruleLog.Write("ProSelectionModelitemGet: " + to_string(status) + "\tSurface Id: " + to_string(annotelem.id));
        Surf_id.push_back(annotelem.id);
    }

    ruleLog.Write("bracketDistance1.size()" + to_string(bracketDistance1.size()));
    ruleLog.Write("bracketDistance2.size()" + to_string(bracketDistance2.size()));
    if(bracketDistance2.size() == 1)
    rg_select_action_IRF3C03_004(dialog, Radio, data);
    if (bracketDistance2.size() == 2)
    status = ProUIPushbuttonEnable(dialog, RULE_UI_OK);

    return status;
}

//string doubleToStringf3c03004(double value)
//{
//    std::stringstream stream;
//    stream << std::fixed << std::setprecision(2) << value;
//    return stream.str();
//}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF3C03_010    | Mathanprasath A	|MF3C03	|For all the standardized frame width, LH arm of mounting bracket distance from frame to be standardized.
===================================================================================================================*/
#define DLG_IRF3C03_010     "dlg_IR_F3C03_010"
#define CommitOK            "CommitOK"
#define CommitCancel		"CommitCancel"
#define PB_SELECT           "select_pb"
#define PB_SELECT_2         "select_pb2"

//Global Declaration of Remarks and Pitch values.
string Selection_F3C03_010;
string remark_F3C03_010;
bool RightValue1{};
double  R_VP1, R_HP1;
double  L_VP1, L_HP1;
int Num_sel1;
ProSelection* Arm_sel1;
int Num_sel_RH1;
ProSelection* Arm_sel_RH1;

int IRF3C03::IRF3C03_010(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF3C03::IRF3C03_010   ==========================");
	ProModelitem mdlitem_1, mdlitem_2;
	ProMdl mdl_1, mdl_2;
	wchar_t model_1, model_2;
	char namesel_1[PRO_NAME_SIZE];
	char namesel_2[PRO_NAME_SIZE];

	Selection_F3C03_010.clear();
	remark_F3C03_010.clear();
	ruleLog.Write("1");
	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF3C03_010, DLG_IRF3C03_010);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF3C03_010, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF3C03_010, PB_SELECT, (ProUIAction)select_action_IRF3C03_010_LH, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF3C03_010, PB_SELECT_2, (ProUIAction)select_action_IRF3C03_010_RH, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF3C03_010, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF3C03_010, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("2");
	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("3");

	status = ProUIDialogActivate(DLG_IRF3C03_010, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF3C03_010);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits == true)
	{
		status = ProUIDialogDestroy(DLG_IRF3C03_010);
		ruleLog.Write("ProUIDialogDestroy close action: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	else
	{
		Selection_F3C03_010 += "\nSelection Info: Engine Mounting Arm, LH";
		if (Num_sel1 == 3)
		{

			// Selection information for result window - LH ARM
			for (int i = 0; i < Num_sel1; ++i)
			{
				status = ProSelectionModelitemGet(Arm_sel1[i], &mdlitem_1);
				ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

				status = ProModelitemMdlGet(&mdlitem_1, &mdl_1);
				ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

				status = ProMdlMdlnameGet(mdl_1, &model_1);
				ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

				ProWstringToString(namesel_1, &model_1);

				Selection_F3C03_010 += "\nPart Name:" + string(namesel_1) + ".PRT,Surace Id :" + to_string(mdlitem_1.id);

			}

		}
		Selection_F3C03_010 += "\nSelection Info: Engine Mounting Arm, RH";

		if (Num_sel_RH1 == 3)
		{
			// Selection information for result window - RH ARM
			for (int i = 0; i < Num_sel_RH1; ++i)
			{
				status = ProSelectionModelitemGet(Arm_sel_RH1[i], &mdlitem_1);
				ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

				status = ProModelitemMdlGet(&mdlitem_1, &mdl_1);
				ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

				status = ProMdlMdlnameGet(mdl_1, &model_1); 
				ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

				ProWstringToString(namesel_1, &model_1); 

				Selection_F3C03_010 += "\nPart Name:" + string(namesel_1) + ".PRT,Surace Id :" + to_string(mdlitem_1.id);

			}
		}

		ruleLog.Write("LH VP = " + to_string(L_VP1) + "mm");
		ruleLog.Write("RH VP = " + to_string(R_VP1) + "mm");
		ruleLog.Write("LH HP = " + to_string(L_HP1) + "mm");
		ruleLog.Write("RH HP = " + to_string(R_HP1) + "mm");

		if (compareFloat(L_VP1, R_VP1) && compareFloat(L_HP1, R_HP1))
		{
			final_res.result = "PASS";
		}

		else
		{
			final_res.result = "FAIL";
		}

		remark_F3C03_010 += "\nAcceptance Criteria:\nStandardised vertical and horizontal pitch has to be maintained.\n";
		ruleLog.Write("5");

		final_res.remark = remark_F3C03_010 + Selection_F3C03_010;

	}

	return 0;
}

ProError select_action_IRF3C03_010_LH(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("==========================   select_action_IRF3C01_008_LH   ==========================");
	//Declarations for Measurment and Selection Info
	double param_1, param_2;
	double pnt_1, pnt_2;
	ProModelitem mdlitem_1, mdlitem_2;
	ProMdl mdl_1, mdl_2;
	wchar_t model_1, model_2;
	char namesel_1[PRO_NAME_SIZE];
	char namesel_2[PRO_NAME_SIZE];


	//Selection of LH
	status = ProSelect((char*)"surface", 3, NULL, NULL, NULL, NULL, &Arm_sel1, &Num_sel1);
	ruleLog.Write("ProSelect action: " + to_string(status));

	InterfaceRule _irule_F3C01;
	if (status == PRO_TK_USER_ABORT || Num_sel1 < 3)
	{
		_irule_F3C01.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, CommitOK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}


	if (Num_sel1 == 3)
	{
		//Remarks and Measurement of LH- ARM Pitch
		//Verical Pitch
		remark_F3C03_010 += "Measured Value:\n";
		remark_F3C03_010 += "Vertical Pitch of Engine Mounting Arm, LH is ";
		status = ProSelectionWithOptionsDistanceEval(Arm_sel1[0], PRO_B_TRUE, Arm_sel1[1], PRO_B_TRUE, &param_1, &param_2, &pnt_1, &pnt_2, &L_VP1);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
		ruleLog.Write("Distance = " + to_string(L_VP1) + "mm");
		remark_F3C03_010 += doubleToStringf3c03(L_VP1) + " mm\n";
		//Horizontal Pitch
		status = ProSelectionWithOptionsDistanceEval(Arm_sel1[1], PRO_B_TRUE, Arm_sel1[2], PRO_B_TRUE, &param_1, &param_2, &pnt_1, &pnt_2, &L_HP1);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
		ruleLog.Write("Distance = " + to_string(L_HP1) + "mm");
		remark_F3C03_010 += "Horizontal Pitch of Engine Mounting Arm, LH is ";
		remark_F3C03_010 += doubleToStringf3c03(L_HP1) + " mm\n";

		status = ProUIPushbuttonDisable(dialog, PB_SELECT);
		status = ProUIPushbuttonEnable(dialog, PB_SELECT_2);
	}

	return status;
}

ProError select_action_IRF3C03_010_RH(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("==========================   select_action_IRF3C01_008_RH   ==========================");
	//Declarations for Measurment 
	double param_1, param_2;
	double pnt_1, pnt_2;

	//Selection of RH
	status = ProSelect((char*)"surface", 3, NULL, NULL, NULL, NULL, &Arm_sel_RH1, &Num_sel_RH1);
	ruleLog.Write("ProSelect close action: " + to_string(status));

	InterfaceRule _irule_F3C01;
	if (status == PRO_TK_USER_ABORT || Num_sel_RH1 < 3)
	{
		_irule_F3C01.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, CommitOK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}

	if (Num_sel_RH1 == 3)
	{
		//Remarks and Measurement of LH- ARM Pitch
		//Verical Pitch
		remark_F3C03_010 += "\nVertical Pitch of Engine Mounting Arm, RH is ";
		status = ProSelectionWithOptionsDistanceEval(Arm_sel_RH1[0], PRO_B_TRUE, Arm_sel_RH1[1], PRO_B_TRUE, &param_1, &param_2, &pnt_1, &pnt_2, &R_VP1);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
		ruleLog.Write("Distance = " + to_string(R_VP1) + "mm");
		remark_F3C03_010 += doubleToStringf3c03(R_VP1) + " mm\n";

		//Horizontal Pitch
		status = ProSelectionWithOptionsDistanceEval(Arm_sel_RH1[1], PRO_B_TRUE, Arm_sel_RH1[2], PRO_B_TRUE, &param_1, &param_2, &pnt_1, &pnt_2, &R_HP1);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
		ruleLog.Write("Distance = " + to_string(R_HP1) + "mm");
		remark_F3C03_010 += "Horizontal Pitch of Engine Mounting Arm, RH is ";
		remark_F3C03_010 += doubleToStringf3c03(R_HP1) + " mm\n";

		status = ProUIPushbuttonDisable(dialog, PB_SELECT_2);
		status = ProUIPushbuttonEnable(dialog, CommitOK);
	}
	return status;
}

string doubleToStringf3c03(double value)
{
	std::stringstream stream;
	stream << std::fixed << std::setprecision(2) << value;
	return stream.str();
}


#pragma pop