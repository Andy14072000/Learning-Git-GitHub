/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 20-06-2023	|	V1_0_0		| F2B04 - STEERING SYSTEM RULES
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#include "F2B04.h"

/*==================================================================================================================
RULE ID            | DEVELOPER            | DEPENDENT MODULES    | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2B04_005        | Aniket Satpute    | MF2B04; MF1A01 ;MF2B06    |  For RCBT, ensure clearance between Steering gear box assy & Frame >10mm in nominal conditions.
===================================================================================================================*/
#define DLG_IRF2B04_005 "dlg_IR_f2b04_005"
#define PB_RSELECT        "pb_select"
#define PB_ROK            "rule_ok_pb"
#define PB_CANCEL        "CommitCancel"
//double Surfclear1;

int IRF2B04::IRF2B04_005(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2B04::IRF2B04_005   ==========================");

	Pro3dPnt pnt_arr[2];

	ComponentData _reqComps[3]{};
	string reqCompSubMod[3] = { "F2B06", "F1A01","F2B04" };
	double clearance_value, std_clearance = 10.0;

	for (int i = 0; i < subModulesList.size(); ++i)
		for (int j = 0; j < 3; ++j)
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
				strcpy(_reqComps[j].name, subModulesList[i].name.c_str());

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
	for (auto elem : _reqComps) {
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_IRF2B04_005, DLG_IRF2B04_005);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2B04_005, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2B04_005, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2B04_005, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2B04_005, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF2B04_005);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	deleteDatumPoint("datum_PNT1");

	deleteDatumPoint("datum_PNT2");

	if (isUserQuits)
		return -1;

	rule_sts = measureDistanceBetweenComponents(_reqComps[0], _reqComps[1], clearance_value, pnt_arr);
	clearance_value = round(clearance_value * 100) / 100;
	createDatumPoints(pnt_arr, "CSYS_ASM_DEF", "CLEARANCE_HIGHLITE_PNT");

	// DECLARE RESULT
	sprintf(remark, "Measured values between %s.ASM and %s.ASM  = %.2lfmm; Acceptance criteria:> %.2lfmm", _reqComps[0].name, _reqComps[1].name, clearance_value, std_clearance);
	final_res.remark = string(remark);

	if (clearance_value > std_clearance)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	return 0;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES					| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F2B04-006	| Vinay Neel		| MF2B04; MF5A27; MF2B05; MF5A20	| For RCBT steering, ensure clearance between Steering gear box/ Steering mtg bkt & Brake piping >15mm in nominal conditions.
===================================================================================================================*/
#define DLG_IRF2B04_006 "dlg_IR_F2B04_006"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"

int IRF2B04::IRF2B04_006(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2B04::IRF2B04_006   ==========================");

	/* your code goes here */

	Pro3dPnt pnt_arr[2];
	ComponentData _reqComps[4]{};
	string reqCompSubMod[4] = { "F2B04","F5A27","F2B05","F5A20" };
	double clearance_value, std_clearance = 15.0;

	for (int i = 0; i < subModulesList.size(); ++i)
		for (int j = 0; j < 4; ++j)
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
				strcpy(_reqComps[j].name, subModulesList[i].name.c_str());

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

	for (auto elem : _reqComps) {
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_IRF2B04_006, DLG_IRF2B04_006);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2B04_006, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2B04_006, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2B04_006, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2B04_006, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF2B04_006);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	deleteDatumPoint("datum_PNT1");
	deleteDatumPoint("datum_PNT2");

	if (isUserQuits)
		return -1;

	rule_sts = measureDistanceBetweenComponents(_reqComps[1], _reqComps[2], clearance_value, pnt_arr);
	createDatumPoints(pnt_arr, "CSYS_ASM_DEF","CLEARANCE_HIGHLITE_PNT");
	clearance_value = round(clearance_value * 100) / 100;

	// DECLARE RESULT
	//sprintf(remark, "Measured values = %.2lfmm; Acceptance criteria: >%.2lfmm", clearance_value, std_clearance);
	sprintf(remark, "Measured value: \nClearance between %s.ASM and %s.ASM : %.2lf mm; \nAcceptance criteria: >%.2lf mm", _reqComps[1].name, _reqComps[2].name, clearance_value, std_clearance);
	final_res.remark = string(remark);

	if (clearance_value > std_clearance)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);
	return 0;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES			| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2B04_009		| Vinay Neel		| MF2B04; MF2B05; MF4A01	|  For RCBT steering, ensure clearance between Steering gear/ Steering mtg bkt & Suspension bracket >10mm in nominal conditions
===================================================================================================================*/
#define DLG_IRF2B04_009 "dlg_IR_F2B04_009"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"

ProFeattype				F2B04_feat_type;

int IRF2B04::IRF2B04_009(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2B04::IRF2B04_009   ==========================");

	ComponentData _reqComps[3]{};
	string reqCompSubMod[3] = { "F2B04","F2B05", "F4A01" };
	double clearance_value, std_clearance = 10.0;
	Pro3dPnt pnt_arr[2];

	for (int i = 0; i < subModulesList.size(); ++i)
		for (int j = 0; j < 3; ++j)
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
				strcpy(_reqComps[j].name, subModulesList[i].name.c_str());

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

	for (auto elem : _reqComps) {
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF2B04_009, DLG_IRF2B04_009);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2B04_009, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2B04_009, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2B04_009, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2B04_009, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF2B04_009);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	deleteDatumPoint("datum_PNT1");
	deleteDatumPoint("datum_PNT2");

	if (isUserQuits)
		return -1;

	rule_sts = measureDistanceBetweenComponents(_reqComps[1], _reqComps[2], clearance_value, pnt_arr);
	createDatumPoints(pnt_arr, "CSYS_ASM_DEF", "CLEARANCE_HIGHLITE_PNT");
	clearance_value = round(clearance_value * 100) / 100;


	// DECLARE RESULT
	sprintf(remark, "Measured value: \nClearance between %s.ASM and %s.ASM : %.2lf mm; \nAcceptance criteria: >%.2lf mm", _reqComps[1].name, _reqComps[2].name, clearance_value, std_clearance);
	final_res.remark = string(remark);

	if (clearance_value > std_clearance)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	return 0;
}
#pragma pop