/*================================================================================================================ =
 NAME			| DATE			| VERSION	| COMMENTS
================================================================================================================== =
 BHUVAN BHARATH | 24-04-2023	| V1_0_0	| F5A24 - BRAKING SYSTEM RULES
==================================================================================================================*/
#include "F5A24.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5A24001		| Himanshu Pachpute	| MF5A24			|  Equalizer mechanism to be provided in order to equalize the pull of both rear-brake cables.
===================================================================================================================*/
#define DLG_F5A24_006			"dlg_IR_F5A24_006" 
#define PB_RCANCEL				"rule_cancel_pb" 
#define PB_ROK					"rule_ok_pb"
#define PB_RSELECT				"pb_select"

char			cMdlName1[PRO_NAME_SIZE];
bool			check = false;
ProSelection*	PlnSel;

int IRF5A24::IRF5A24_001(ruleResult& final_res)
{

	ruleLog.Write("==========================>>   IRF5A24::IRF5A24_006   <<==========================");

	isUserQuits = false;
	InterfaceRule _irule;

	status = ProSolidFeatVisit((ProSolid)curMdl, CompVisitAction_IRF5A24_006, NULL, NULL);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

	if (check == false) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Equalizer Mechanism Not Found", "Please check whether equalizer mechanism is present in the model or not.");
		status = ProUIDialogShow(DLG_IRC_MAIN);
	}
	else {
		status = ProUIDialogCreate(DLG_F5A24_006, DLG_F5A24_006);
		status = ProUIDialogAboveactivewindowSet(DLG_F5A24_006, PRO_B_FALSE);
		status = ProUIPushbuttonActivateActionSet(DLG_F5A24_006, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
		//status = ProUIDialogCloseActionSet(DLG_F5A24_006, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
		status = ProUIPushbuttonActivateActionSet(DLG_F5A24_006, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
		status = ProUIPushbuttonActivateActionSet(DLG_F5A24_006, PB_RSELECT, (ProUIAction)select_action_IRF5A24_006, NULL);

		status = ProUIDialogHide(DLG_IRC_MAIN);
		status = ProUIDialogActivate(DLG_F5A24_006, &dlg_sts);
		status = ProUIDialogDestroy(DLG_F5A24_006);
		status = ProUIDialogShow(DLG_IRC_MAIN);

		if (isUserQuits)
			return -1;

		double Angle;
		status = MeasureAngleBetPln(PlnSel[0], PlnSel[1], Angle);
		ruleLog.Write("measureAngleBetweenPlanes: " + to_string(Angle));

		if (check == true) {
			if (int(Angle) == 90) {
				final_res.result = "PASS";
				sprintf(remark, "Equalizer Mechanism (%s.prt) is present,\nPull of the both rear cable is EQUAL.", cMdlName1);
				final_res.remark = string(remark);
			}
			else {
				final_res.result = "FAIL";
				sprintf(remark, "Equalizer Mechanism (%s.prt) is present,\nPull of the both rear cable is NOT EQUAL.", cMdlName1);
				final_res.remark = string(remark);
			}
		}

		ruleLog.Write("\nstatus: " + final_res.result);
		ruleLog.Write("remark: " + final_res.remark);
	}

	check = false;
	return 0;
}

ProError MeasureAngleBetPln(ProSelection& sel_surf1, ProSelection& sel_surf2, double& angle)
{
	ruleLog.Write("-------------------------> MeasureAngleBetPln <-------------------------");

	ProModelitem	model_item1, model_item2;
	ProMdl			owner1, owner2;
	ProSurface		surface1, surface2;
	ProAsmcomppath  p_cmp_path1, p_cmp_path2;
	ProMatrix		transformation1, transformation2;
	ProVector		normal_vec_1, normal_vec_2;

	status = ProSelectionModelitemGet(sel_surf1, &model_item1);
	ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

	status = ProSelectionAsmcomppathGet(sel_surf1, &p_cmp_path1);
	ruleLog.Write("ProSelectionAsmcomppathGet: " + to_string(status));

	status = ProAsmcomppathTrfGet(&p_cmp_path1, PRO_B_TRUE, transformation1);
	ruleLog.Write("ProAsmcomppathTrfGet: " + to_string(status));

	status = ProSelectionModelitemGet(sel_surf2, &model_item2);
	ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

	status = ProSelectionAsmcomppathGet(sel_surf2, &p_cmp_path2);
	ruleLog.Write("ProSelectionAsmcomppathGet: " + to_string(status));

	status = ProAsmcomppathTrfGet(&p_cmp_path2, PRO_B_TRUE, transformation2);
	ruleLog.Write("ProAsmcomppathTrfGet: " + to_string(status));

	status = ProModelitemMdlGet(&model_item1, &owner1);
	ruleLog.Write("ProModelitemMdlGet: " + to_string(status));

	status = ProSurfaceInit(owner1, model_item1.id, &surface1);
	ruleLog.Write("ProSurfaceInit: " + to_string(status));

	status = ProModelitemMdlGet(&model_item2, &owner2);
	ruleLog.Write("ProModelitemMdlGet: " + to_string(status));

	status = ProSurfaceInit(owner2, model_item2.id, &surface2);
	ruleLog.Write("ProSurfaceInit: " + to_string(status));

	ProUvParam	uv_point1;
	ProVector	xyz_point1, xyz_point2, deriv1[2], deriv2[2], normal1, normal2;

	status = ProSurfaceXyzdataEval(surface1, uv_point1, xyz_point1, deriv1, deriv2, normal1);
	ruleLog.Write("ProSurfaceXyzdataEval: " + to_string(status));

	status = ProVectorTrfEval(normal1, transformation1, normal_vec_1);
	ruleLog.Write("ProVectorTrfEval: " + to_string(status));

	ruleLog.Write("normal_vec_1: " + to_string(normal_vec_1[0]) + to_string(normal_vec_1[1]) + to_string(normal_vec_1[2]));

	status = ProSurfaceXyzdataEval(surface2, uv_point1, xyz_point1, deriv1, deriv2, normal2);
	ruleLog.Write("ProSurfaceXyzdataEval: " + to_string(status));

	status = ProVectorTrfEval(normal2, transformation2, normal_vec_2);
	ruleLog.Write("ProVectorTrfEval: " + to_string(status));

	ruleLog.Write("normal_vec_2: " + to_string(normal_vec_2[0]) + to_string(normal_vec_2[1]) + to_string(normal_vec_2[2]));

	double a_x_b = normal_vec_1[0] * normal_vec_2[0] + normal_vec_1[1] * normal_vec_2[1] + normal_vec_1[2] * normal_vec_2[2];
	ruleLog.Write("a_x_b: " + to_string(a_x_b));

	double mod_a_x_mod_b = (sqrt(normal_vec_1[0] * normal_vec_1[0] + normal_vec_1[1] * normal_vec_1[1] + normal_vec_1[2] * normal_vec_1[2])) *
		(sqrt(normal_vec_2[0] * normal_vec_2[0] + normal_vec_2[1] * normal_vec_2[1] + normal_vec_2[2] * normal_vec_2[2]));
	ruleLog.Write("mod_a_x_mod_b: " + to_string(mod_a_x_mod_b));

	double rad_angle = acos(a_x_b / mod_a_x_mod_b);
	ruleLog.Write("rad_angle: " + to_string(rad_angle));

	double deg_angle = rad_angle * (180 / 3.141592);
	ruleLog.Write("deg_angle: " + to_string(deg_angle));

	angle = deg_angle;

	return status;
}

ProError select_action_IRF5A24_006(char* dialog, char* component)
{
	ruleLog.Write("-------------------------> select_action_IRF5A24_006 <-------------------------");

	int n_sel;
	InterfaceRule _irule;
	PlnSel = nullptr;

	int curWinId;
	status = ProWindowCurrentGet(&curWinId);
	ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

	status = ProWindowRepaint(curWinId);
	ruleLog.Write("ProWindowRepaint: " + to_string(status));

	status = ProUIDialogHide(dialog);
	ruleLog.Write("ProUIDialogHide: " + to_string(status));

	status = ProSelect("datum", 2, NULL, NULL, NULL, NULL, &PlnSel, &n_sel);
	ruleLog.Write("Proselect status: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel));

	status = ProUIDialogShow(dialog);
	ruleLog.Write("ProUIDialogHide: " + to_string(status));

	if (n_sel < 2 || status != PRO_TK_NO_ERROR) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));

		status = ProUIPushbuttonEnable(dialog, PB_RSELECT);
		ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));
	}
	else {
		/*status = ProUIPushbuttonDisable(dialog, PB_RSELECT);
		ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));*/

		status = ProUIPushbuttonEnable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));
	}

	return status;
}

ProError CompVisitAction_IRF5A24_006(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("-------------------------> CompVisitAction_IRF5A24_006 <-------------------------");

	ProMdl reqMdl;
	ProMdlType subModuleMdlType;

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));

	status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
	ruleLog.Write("ProMdlTypeGet: " + to_string(status));

	if (subModuleMdlType == PRO_MDL_ASSEMBLY)
		ProSolidFeatVisit((ProSolid)reqMdl, CompVisitAction_IRF5A24_006, compsFilter, (ProAppData)app_data);
	else if (subModuleMdlType == PRO_MDL_PART) {

		ProMdl equalizerMdl;
		status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &equalizerMdl);
		ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));

		ProMdlType equalizerMdltype;
		status = ProMdlTypeGet(equalizerMdl, &equalizerMdltype);
		ruleLog.Write("ProMdlTypeGet: " + to_string(status));

		ProModelitem equalizerMdlitem;
		status = ProMdlToModelitem(equalizerMdl, &equalizerMdlitem);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		ProParameter pDesc;
		ProName	pDescName = L"DESCRIPTION";
		status = ProParameterInit(&equalizerMdlitem, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit: " + to_string(status));

		if (status == PRO_TK_NO_ERROR) {
			ProParamvalue pvDesc;
			char existingPval[PRO_NAME_SIZE];
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ProWstringToString(existingPval, pvDesc.value.s_val);
			ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);


			string targetStrings[] = { "LINK", "LINK ", " LINK", " LINK " };
			int targetCount = sizeof(targetStrings) / sizeof(targetStrings[0]);

			for (int i = 0; i < targetCount; ++i)
				if (targetStrings[i].compare(existingPval) == 0) {
					ruleLog.Write("Match Found!!");
					check = true;

					wchar_t wMdlName[PRO_NAME_SIZE];
					int status = ProMdlMdlnameGet(equalizerMdl, wMdlName);
					ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

					ProWstringToString(cMdlName1, wMdlName);
					ruleLog.Write("cMdlName: " + string(cMdlName1));

					break;
				}
		}

	}
	return status;
}
#pragma pop