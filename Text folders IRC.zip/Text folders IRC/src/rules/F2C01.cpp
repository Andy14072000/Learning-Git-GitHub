﻿/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 05-07-2023	|	V1_0_0		| F2C01 - PROPELLER SHAFT RULES
==================================================================================================================*/
#include "F2C01.h"
#include "ProMechGeometry.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F2C01-003 	|  Pallavi Garodi	| MF2C01; MH2C01         | Ensure ≥10 mm clearance between propeller shaft and PTO (for gear box having PTO)
===================================================================================================================*/
 //UI DEFINITIONS
#define DLG_F2C01_003	  "dlg_IR_F2C01_003"
#define SELECT_PARTS_PB   "select_pb"
#define MEASURE_PART_PB	  "measure_pb"
#define RULE_UI_CANCEL    "CommitCancel"
#define RULE_UI_OK        "CommitOK"

ComponentData				reqComps_F2C01_003[3];
ProSelection*				selection_1;
int							_sel;
vector<vals>				values;
vals						_temp;
double						output;
char						description[PRO_NAME_SIZE]{};

int IRF2C01::IRF2C01_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF3A01::IRF2C01_003   ==========================");
	char				formattedNumber[20];
	string				rem_message;
	deleteDatumPoint("datum_PNT1");
	deleteDatumPoint("datum_PNT2");

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_F2C01_003, DLG_F2C01_003);
	status = ProUIDialogAboveactivewindowSet(DLG_F2C01_003, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_F2C01_003, RULE_UI_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F2C01_003, RULE_UI_OK, (ProUIAction)ruleDlgOKaction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F2C01_003, SELECT_PARTS_PB, (ProUIAction)select_action_IRF2C01_003, (ProAppData)&isUserQuits);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_F2C01_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_F2C01_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	//DECLARE RESULT

	rem_message += "Clearance between ";
	values.at(0).Distance = round(values.at(0).Distance * 100) / 100;

	// Remove trailing zeros from the second decimal place
	sprintf(formattedNumber, "%.2f", values.at(0).Distance);
	int length = strlen(formattedNumber);
	while (length > 0 && formattedNumber[length - 1] == '0') {
		formattedNumber[length - 1] = '\0';
		length--;
	}
	ruleLog.Write(formattedNumber);
	ruleLog.Write(string(values.at(0).name));
	ruleLog.Write(string(values.at(0).description));
	ruleLog.Write(string(values.at(1).name));
	ruleLog.Write(string(values.at(1).description));
	//DECLARE RESULT
	rem_message += string(values.at(0).name) + ".PRT" /*+ string(values.at(0).description) +*/" and\n";
	rem_message += string(values.at(1).name) + ".PRT" /*+ string(values.at(1).description) +*/ " = " + string(formattedNumber) + "mm\n";

	rem_message += "\nAcceptance criteria : clearance between propeller shaft and PTO >= 10 mm.";

	double acceptedClearance = 20.0;
	final_res.remark = rem_message;

	//DECLARE RESULT
	for (int i = 0; i < _sel; ++i)
	{
		ruleLog.Write(to_string(values.at(i).Distance));
		if (values.at(i).Distance < 20.0)
		{
			final_res.result = "FAIL";
			break;
		}
		else
		{
			final_res.result = "PASS";
		}
	}

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	//final_res.result.clear();
	values.clear();

	return 0;
}

ProError select_action_IRF2C01_003(char* dialog, char* component, ProAppData data)
{
	InterfaceRule     _irule;
	int               curWinId;
	int				  rule_sts;
	ProAsmcomppath	  part_asmcomp_path;
	ProMdl	          parent_mdl;
	wchar_t           wParentMdlName[PRO_NAME_SIZE];
	char              cParentMdlName[PRO_NAME_SIZE];
	ProAsmcomppath    path;
	ProModelitem      modelItem;
	ProParameter      pDesc;
	ProParamvalue     pvDesc;
	ProName pDescName = L"DESCRIPTION";

	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);

	status = ProSelect((char*)"prt_or_asm", 2, NULL, NULL, NULL, NULL, &selection_1, &_sel);
	ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(_sel));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_F2C01_003, RULE_UI_OK);
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide inputs again!. Refer help document for details.");
		status = ProUIDialogShow(DLG_F2C01_003);
		return status;
	}

	if (_sel < 2 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIDialogShow(DLG_F2C01_003);
		status = ProUIPushbuttonDisable(DLG_F2C01_003, RULE_UI_OK);
		return status;
	}

	//  Compute distances

	/*double distance;
	ProBoolean is_interference_found;
	Pro3dPnt pnt_arr[2];
	status = ProFitClearanceCompute(sel[0], PRO_FIT_INCLUDE_NONE, sel[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, sel[1], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));
	output = distance;
	createDatumPointsF2C01003(pnt_arr, "CSYS_ASM_DEF");*/


	rule_sts = _irule.measureDistanceBetweenSurfaces(selection_1[0], selection_1[1], output);
	ruleLog.Write("measureDistanceBetweenSurfaces = " + to_string(rule_sts));
	if (output <= 10) {
		ProWindowRepaint(curWinId);
		status = ProSelectionHighlight(selection_1[0], PRO_COLOR_HIGHLITE);
		status = ProSelectionHighlight(selection_1[1], PRO_COLOR_HIGHLITE);
		ruleLog.Write("ProSelectionHighlight = " + to_string(status));
	}
	_temp.Distance = output;

	for (int i = 0; i < _sel; ++i)
	{
		status = ProSelectionAsmcomppathGet(selection_1[i], &part_asmcomp_path);
		ruleLog.Write("ProSelectionAsmcomppathGet = " + to_string(status));

		// to find the parent component
		//part_asmcomp_path.comp_id_table[part_asmcomp_path.table_num - 1] = -1;
		//part_asmcomp_path.table_num = part_asmcomp_path.table_num - 1;

		status = ProAsmcomppathMdlGet(&part_asmcomp_path, &parent_mdl);
		ruleLog.Write("ProAsmcomppathMdlGet = " + to_string(status));

		status = ProMdlMdlnameGet(parent_mdl, wParentMdlName);
		ProWstringToString(cParentMdlName, wParentMdlName);
		ruleLog.Write("cParentMdlName = " + (string)cParentMdlName);


		status = ProMdlToModelitem(parent_mdl, &modelItem);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&modelItem, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit: " + to_string(status));

		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ProWstringToString(description, pvDesc.value.s_val);
			ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + description);
		}
		////  Compute distances
		//rule_sts = measureDistanceBetweenAsmAndPart_F2C01(reqComps_F2C01_003[0], &sel[i], output);
		//if (output <= 10) {
		//	ProWindowRepaint(curWinId);
		//	status = ProSelectionHighlight(sel[i], PRO_COLOR_HIGHLITE);
		//	ruleLog.Write("ProSelectionHighlight = " + to_string(status));
		//}

		strcpy(_temp.description, description);
		strcpy(_temp.name, cParentMdlName);
		ruleLog.Write(_temp.name);
		values.push_back(_temp);

	}
	ProWindowRepaint(curWinId);
	status = ProSelectionHighlight(selection_1[0], PRO_COLOR_HIGHLITE);
	ruleLog.Write("ProSelectionHighlight = " + to_string(status));
	status = ProSelectionHighlight(selection_1[1], PRO_COLOR_HIGHLITE);
	ruleLog.Write("ProSelectionHighlight = " + to_string(status));

	_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention!",
		"The computed clearance is distance between the highlighted parts.\nclick on Ok to dispaly the results.");

	status = ProUIDialogShow(DLG_F2C01_003);
	status = ProUIPushbuttonEnable(DLG_F2C01_003, RULE_UI_OK);

	return status;
}

//int createDatumPointsF2C01003(Pro3dPnt pnt_arr[2], char* csysName)
//{
//
//	ruleLog.Write("=================> InterfaceRule::createDatumPoints <=================");
//	ProElement  elem_tree, elem_ftype, elem_feature_name,
//		pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
//		pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
//		pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
//	ProReference REPDEP_ref1;
//	wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wide_string[PRO_NAME_SIZE], wide_string_2[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE];
//	//CSYS_ASM_DEF
//	ProModelitem refCsysitem;
//	ProSelection refCsysSel, reqMdlSel;
//	ProFeatureCreateOptions* opts = 0;
//	ProFeature pnt_feat;
//	ProErrorlist errors;
//	//converting negative values to positive
//	double d1 = -pnt_arr[0][2];
//	double d2 = -pnt_arr[1][2];
//	char cDatumPointName[PRO_NAME_SIZE] = "Dist_highlght_pnt";
//
//	ProStringToWstring(wCsysName, csysName);
//	status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
//	status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);
//
//
//	//Create Element Tree
//	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
//	ruleLog.Write("Tree root status = " + to_string(status));
//
//	// TREE ALLOCATION
//	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
//	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
//	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
//	ruleLog.Write("type status = " + to_string(status));
//
//	//feature name
//	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
//	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, cDatumPointName));
//	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
//	ruleLog.Write("feature name = " + to_string(status));
//
//	//PRO_E_DPOINT_TYPE
//	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
//	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
//	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
//	ruleLog.Write("type status = " + to_string(status));
//
//	//Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
//	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
//	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);
//
//	//ref
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
//	status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
//	status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
//	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);
//
//	//
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
//	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
//	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);
//
//	//Populating array element
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
//	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);
//
//	//Point1
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);
//
//	//Point1 Name
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
//	ProStringToWstring(wide_string, "datum_PNT1");
//	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);
//
//	//PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
//	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
//	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);
//
//	//PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
//	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
//	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);
//
//	//PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
//	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
//	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);
//
//	//Point2
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);
//
//	//Point2 Name
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
//	ProStringToWstring(wide_string_2, "datum_PNT2");
//	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);
//
//	////PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
//	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
//	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);
//
//	////PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
//	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
//	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);
//
//	////PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
//	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
//	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);
//
//	/* =============================================================== *\
//	Create Model Selection Object
//	\* =============================================================== */
//
//	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
//	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
//	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
//
//	opts[0] = PRO_FEAT_CR_NO_OPTS;
//
//	// Create Points
//	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
//	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));
//
//	status = ProArrayFree((ProArray*)&opts);
//	status = ProElementFree(&elem_tree);
//	status = ProSelectionFree(&reqMdlSel);
//
//	ProSelection pnt_Sel;
//	status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
//	status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_ERROR);
//	//PRO_COLOR_SELECTED for green highlight
//	return 0;
//}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2C01_008 	| Mathanprasath A	| MF2C01          | Target GB inclination to be with in ± 1 deg of RA inclination. Else, decision based on Performance evaluation.
===================================================================================================================*/

#define DLG_IR_F2C01_008   "dlg_IR_F2C01_008"
#define CommitOK		   "CommitOK"
#define CommitCancel	   "CommitCancel"
#define Select_pb		   "select_pb"

ProSelection* sel_axis;
ProSelection axis_sel1, axis_sel2;
int n_sels_008;
double Angle1, Angle2;
ProMdl p_handle;
ProName name1, name2, name3, axis_name1, axis_name2;
ProSelection sel1, sel2, sel3;
ProModelitem p_item1, p_item2, p_item3, axis_item1, axis_item2;
float Deviated, abs_Deviated;

bool result = NULL;
int IRF2C01::IRF2C01_008(ruleResult& final_res)
{
	ruleLog.Write("========================== IRF2C01::IRF2C01_008========================");
	ProCharPath Parents_info{};
	for (int i = 0; i < subModulesList.size(); ++i)
	{
		if (subModulesList[i].name.find("F2C01") != std::string::npos)
		{
			_reqSMinfo = subModulesList[i];
			break;
		}

	}
	status = ProMdlCurrentGet(&p_handle);
	ruleLog.Write("ProMdlcurrentGet = " + to_string(status));

	ProStringToWstring(name1, "ASM_XY");
	status = ProModelitemByNameInit(p_handle, PRO_SURFACE, name1, &p_item1);
	ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

	status = ProSelectionAlloc(NULL, &p_item1, &sel1);
	ruleLog.Write("ProSelectionAlloc 1= " + to_string(status));
	ruleLog.Write("Selected plane:ASM_XY");
	bool nomencltre_found = NULL;

	ruleLog.Write("5-----------------------------");
	isUserQuits = false;
	ruleLog.Write("6-----------------------------");
	status = ProUIDialogCreate(DLG_IR_F2C01_008, DLG_IR_F2C01_008);
	ruleLog.Write("UI status = " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IR_F2C01_008, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet = " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IR_F2C01_008, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet1 = " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IR_F2C01_008, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet 2= " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IR_F2C01_008, Select_pb, (ProUIAction)selection_action_IRF2C01_008, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet 3 = " + to_string(status));
	ruleLog.Write("8-----------------------------");

	/*if (nomencltre_found == false)
	{
		ruleLog.Write("9-----------------------------");
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "INFO", "AXIS_END1 & AXIS_END2 is not found. Create the axis as mentioned else click Select button in the UI to Proceed Manual selection.");
		ruleLog.Write("ProUIMessageDialogDisplay: " + to_string(status));

	}*/
	ruleLog.Write("7-----------------------------");
	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IR_F2C01_008, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IR_F2C01_008);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	/*if (n_sels == 2)
	{
		status = ProUIPushbuttonEnable(DLG_IR_F2C01_011, CommitOK);

		status = ProSelectionModelitemGet(sel_axis[0], &axisitem1);
		status = ProSelectionModelitemGet(sel_axis[1], &axisietm2);

		status = ProGeomitemFeatureGet((ProGeomitem*)&axisitem1, &axis_featid1);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id1 = " + to_string(axis_featid1.id));

		status = ProGeomitemFeatureGet((ProGeomitem*)&axisietm2, &axis_featid2);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id2 = " + to_string(axis_featid2.id));


		status = ProModelitemMdlGet(&axisitem1, &axis_mdlmdl1);
		status = ProModelitemMdlGet(&axisietm2, &axis_mdlmdl2);

		status = ProMdlMdlnameGet(axis_mdlmdl1, waxsmdlName1);
		ProWstringToString(caxsmdlName1, waxsmdlName1);
		ruleLog.Write("Axis model Name :" + string(caxsmdlName1));
		status = ProMdlMdlnameGet(axis_mdlmdl2, waxsmdlName2);
		ProWstringToString(caxsmdlName2, waxsmdlName2);
		ruleLog.Write("Axis model Name :" + string(caxsmdlName2));

		char tempAxs2Name[PRO_NAME_SIZE] = "TEMP_AXIS2";
		int iOut = createTangentDatumAxisWithReference(sel_axis[0], "A_2", tempAxs2Name);
		ruleLog.Write("createTangentDatumAxisWithReference = " + to_string(status));

		ProStringToWstring(name3, "TEMP_AXIS2");
		status = ProModelitemByNameInit(p_handle, PRO_AXIS, name3, &p_item3);
		ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

		status = ProSelectionAlloc(NULL, &p_item3, &sel3);
		ruleLog.Write("ProSelectionAlloc2 = " + to_string(status));

		status = measureAngleBetweenSurfaceAndAxis(sel1, sel3, Angle1);
		ruleLog.Write("Angle1: " + to_string(Angle1));

		char tempAxs1Name[PRO_NAME_SIZE] = "TEMP_AXIS1";
		int Out = createTangentDatumAxisWithReference(sel_axis[1], "A_1", tempAxs1Name);
		ruleLog.Write("createTangentDatumAxisWithReference = " + to_string(status));

		ProStringToWstring(name2, "TEMP_AXIS1");
		status = ProModelitemByNameInit(p_handle, PRO_AXIS, name2, &p_item2);
		ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

		status = ProSelectionAlloc(NULL, &p_item2, &sel2);
		ruleLog.Write("ProSelectionAlloc2 = " + to_string(status));

		status = measureAngleBetweenSurfaceAndAxis(sel1, sel2, Angle2);
		ruleLog.Write("Angle2: " + to_string(Angle2));

		int del = deleteDatumAxis(tempAxs1Name);
		ruleLog.Write("deleteDatumAxis = " + to_string(status));

		int del2 = deleteDatumAxis(tempAxs2Name);
		ruleLog.Write("deleteDatumAxis = " + to_string(status));
	}*/
	/*float Deviated;
	Deviated = Angle1 - Angle2;
	if (Deviated < 0) {
		Deviated = std::abs(Deviated);
		ruleLog.Write("abs Deviated: " + to_string(Deviated));
	}
	else {
		ruleLog.Write("Deviated: " + to_string(Deviated));
	}

	char in[50];
	if (Angle1 >= Angle2 - 1.0 && Angle1 <= Angle2 + 1.0)
	{
		final_res.result = "PASS";
		sprintf(remark, "Measured Value :RA inclination is in ± 1 deg of AGB inclination. ;\nAcceptance criteria:Target RA inclination to be with in ± 1 deg of GB inclination");
		sprintf(Parents_info, "\nAxis_id 1: %d, Partnumber: %s.\nAixs_id 2: %d, Partnumber: %s.", axis_featid1.id, caxsmdlName1, axis_featid2.id, caxsmdlName2);
		final_res.remark = string(remark) + Parents_info;
	}
	else
	{
		final_res.result = "FAIL";
		sprintf(remark, "Measured Value :RA inclination is %0.2f deg of AGB inclination.;\nAcceptance criteria:Target RA inclination to be with in ± 1 deg of GB inclination.", Deviated);
		sprintf(Parents_info, "\nAxis_id 1: %d, Partnumber: %s.\nAixs_id 2: %d, Partnumber: %s.", axis_featid1.id, caxsmdlName1, axis_featid2.id, caxsmdlName2);
		final_res.remark = string(remark) + Parents_info;
	}*/


	if (n_sels_008 == 2)
	{
		status = ProUIPushbuttonEnable(DLG_IR_F2C01_008, CommitOK);
		int id1, id2;
		ProModelitem axis1, axis2;
		ProFeature axis_feat1, axis_feat2;
		status = ProSelectionModelitemGet(sel_axis[0], &axis1);
		status = ProSelectionModelitemGet(sel_axis[1], &axis2);

		status = ProGeomitemFeatureGet((ProGeomitem*)&axis1, &axis_feat1);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id1 = " + to_string(axis_feat1.id));
		ProAnalysis* Analysis_1;
		status = ProFeatureAnalysisGet(&axis_feat1, Analysis_1);
		ruleLog.Write("ProFeatureAnalysisGet status = " + to_string(status));

		status = ProGeomitemFeatureGet((ProGeomitem*)&axis2, &axis_feat2);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id2 = " + to_string(axis_feat2.id));

		ProMdl axis_mdl1, axis_mdl2;
		status = ProModelitemMdlGet(&axis1, &axis_mdl1);
		status = ProModelitemMdlGet(&axis2, &axis_mdl2);
		wchar_t waxsMdlName1[PRO_NAME_SIZE];
		char caxsMdlName1[PRO_NAME_SIZE];
		wchar_t waxsMdlName2[PRO_NAME_SIZE];
		char caxsMdlName2[PRO_NAME_SIZE];
		status = ProMdlMdlnameGet(axis_mdl1, waxsMdlName1);
		ProWstringToString(caxsMdlName1, waxsMdlName1);
		ruleLog.Write("Axis model Name :" + string(caxsMdlName1));
		status = ProMdlMdlnameGet(axis_mdl2, waxsMdlName2);
		ProWstringToString(caxsMdlName2, waxsMdlName2);
		ruleLog.Write("Axis model Name :" + string(caxsMdlName2));

		/*status = ProAxisIdGet(ProAxis(sel_axis[0]), &id1);
		ruleLog.Write("ProAxisIdGet 1= " + to_string(status));
		ruleLog.Write("Axis 1 ID :" + id1);

		status = ProAxisIdGet(ProAxis(sel_axis[0]), &id2);
		ruleLog.Write("ProAxisIdGet 2= " + to_string(status));
		ruleLog.Write("Axis 2 ID :" + id2)*/;

		char tempAxs2Name[PRO_NAME_SIZE] = "TEMP_AXIS2";
		int iOut = createTangentDatumAxisWithReference(sel_axis[0], "AXIS_END1", tempAxs2Name);
		ruleLog.Write("createTangentDatumAxisWithReference = " + to_string(status));

		ProStringToWstring(name3, "TEMP_AXIS2");
		status = ProModelitemByNameInit(p_handle, PRO_AXIS, name3, &p_item3);
		ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

		status = ProSelectionAlloc(NULL, &p_item3, &sel3);
		ruleLog.Write("ProSelectionAlloc2 = " + to_string(status));

		status = measureAngleBetweenSurfaceAndAxis(sel1, sel3, Angle1);
		ruleLog.Write("Angle1: " + to_string(Angle1));
		
	/*	ProAnnotationPlane* plane{};
		ProDimAttachment* DimAtt{};
		ProDimSense *Dimsen{};
		ProDimOrient DimOri{};
		ProDimension* P_Dimension{};
		double* loc{};
		status = ProDimensionCreate(ProSolid(p_handle), PRO_DIMENSION, plane,DimAtt,Dimsen,DimOri,loc, P_Dimension);
		ruleLog.Write("ProDimensionCreate = " + to_string(status));*/

		char tempAxs1Name[PRO_NAME_SIZE] = "TEMP_AXIS1";
		int Out = createTangentDatumAxisWithReference(sel_axis[1], "AXIS_END2", tempAxs1Name);
		ruleLog.Write("createTangentDatumAxisWithReference = " + to_string(status));

		ProStringToWstring(name2, "TEMP_AXIS1");
		status = ProModelitemByNameInit(p_handle, PRO_AXIS, name2, &p_item2);
		ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

		status = ProSelectionAlloc(NULL, &p_item2, &sel2);
		ruleLog.Write("ProSelectionAlloc2 = " + to_string(status));

		status = measureAngleBetweenSurfaceAndAxis(sel1, sel2, Angle2);
		ruleLog.Write("Angle2: " + to_string(Angle2));

		int del = deleteDatumAxis(tempAxs1Name);
		ruleLog.Write("deleteDatumAxis = " + to_string(status));

		int del2 = deleteDatumAxis(tempAxs2Name);
		ruleLog.Write("deleteDatumAxis = " + to_string(status));


		Deviated = Angle1 - Angle2;
		ruleLog.Write("DEVIATION :" + to_string(Deviated));
		if (Deviated < 0)
		{
			abs_Deviated = std::abs(Deviated);
			ruleLog.Write("abs Deviated: " + to_string(Deviated));
		}
		else
		{
			abs_Deviated = Deviated;
			ruleLog.Write("Deviated: " + to_string(abs_Deviated));
		}

		char in[50];
		if (abs_Deviated >= -1.0 && abs_Deviated <= +1.0)
		{
			final_res.result = "PASS";
			sprintf(remark, "Measured Value :RA inclination is in %0.1f deg of GB inclination. ; Acceptance criteria:Target RA inclination to be with in ± 1 deg of GB inclination", abs_Deviated);
			sprintf(Parents_info, "\nAxis_id 1: %d, Partnumber: %s.\nAixs_id 2: %d, Partnumber: %s.", axis_feat1.id, caxsMdlName1, axis_feat2.id, caxsMdlName2);
			final_res.remark = string(remark) + Parents_info;
		}
		else
		{
			final_res.result = "FAIL";
			sprintf(remark, "Measured Value :RA inclination is %0.1f deg of GB inclination.; Acceptance criteria:Target RA inclination to be with in ± 1 deg of GB inclination.", abs_Deviated);
			sprintf(Parents_info, "\nAxis_id 1: %d, Partnumber:%s.\nAixs_id 2: %d, Partnumber:%s.", axis_feat1.id, caxsMdlName1, axis_feat2.id, caxsMdlName2);
			final_res.remark = string(remark) + Parents_info;
		}
	}

	
	if (isUserQuits)
		return -1;


	return 0;

}

ProError selection_action_IRF2C01_008(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF2C01_008 -----------------------------");

	int rule_sts;
	InterfaceRule _irule;
	bool* quitAction = (bool*)data;

	status = ProSelect((char*)"axis", 2, NULL, NULL, NULL, NULL, &sel_axis, &n_sels_008);
	ruleLog.Write("ProSelect = " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_IR_F2C01_008, CommitOK);
		if (quitAction != NULL)
			*quitAction = true;
		return status;
	}

	else if (n_sels_008 < 2 || status != PRO_TK_NO_ERROR) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		if (quitAction != NULL)
			*quitAction = true;
		status = ProUIPushbuttonDisable(DLG_IR_F2C01_008, CommitOK);
		return status;
	}

	status = ProUIPushbuttonEnable(DLG_IR_F2C01_008, CommitOK);

	/*if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_IR_F2C01_008, CommitOK);
		if (quitAction != NULL)
			*quitAction = true;
		return status;
	}

	else if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		if (quitAction != NULL)
			*quitAction = true;
		status = ProUIPushbuttonDisable(DLG_IR_F2C01_008, CommitOK);
		return status;
	}*/


	//int(status)=0

	return status;

}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2C01_011 	| Pallavi Garodi	| MF2C01          | Target AGB inclination to be with in ± 1 deg of RA inclination. Else, decision based on Performance evaluation.
===================================================================================================================*/

#define DLG_IR_F2C01_011   "dlg_IR_F2C01_011"
#define CommitOK		   "CommitOK"
#define CommitCancel	   "CommitCancel"
#define select_pb		   "select_pb"

int n_sels_011;
int IRF2C01::IRF2C01_011(ruleResult& final_res)
{
	ProCharPath Parents_info{};
	int id1, id2;
	ProModelitem axisitem1, axisietm2;
	ProFeature axis_featid1, axis_featid2;

	ProMdl axis_mdlmdl1, axis_mdlmdl2;
	wchar_t waxsmdlName1[PRO_NAME_SIZE];
	char caxsmdlName1[PRO_NAME_SIZE];
	wchar_t waxsmdlName2[PRO_NAME_SIZE];
	char caxsmdlName2[PRO_NAME_SIZE];
	ruleLog.Write("========================== IRF2C01::IRF2C01_008========================");
	for (int i = 0; i < subModulesList.size(); ++i) {
		if (subModulesList[i].name.find("F2C01") != std::string::npos) {
			_reqSMinfo = subModulesList[i];
			break;
		}

	}
	isUserQuits = false;


	status = ProUIDialogCreate(DLG_IR_F2C01_011, DLG_IR_F2C01_011);
	ruleLog.Write("UI status = " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IR_F2C01_011, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet = " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IR_F2C01_011, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet1 = " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IR_F2C01_011, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet 2= " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IR_F2C01_011, select_pb, (ProUIAction)selection_action_IRF2C01_011, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet 3 = " + to_string(status));


	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IR_F2C01_011, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IR_F2C01_011);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	status = ProMdlCurrentGet(&p_handle);
	ruleLog.Write("ProMdlcurrentGet = " + to_string(status));

	ProStringToWstring(name1, "ASM_XY");
	status = ProModelitemByNameInit(p_handle, PRO_SURFACE, name1, &p_item1);
	ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

	status = ProSelectionAlloc(NULL, &p_item1, &sel1);
	ruleLog.Write("ProSelectionAlloc 1= " + to_string(status));
	ruleLog.Write("Selected plane:ASM_XY");

	if (n_sels_011 == 2)
	{
		status = ProUIPushbuttonEnable(DLG_IR_F2C01_011, CommitOK);

		status = ProSelectionModelitemGet(sel_axis[0], &axisitem1);
		status = ProSelectionModelitemGet(sel_axis[1], &axisietm2);

		status = ProGeomitemFeatureGet((ProGeomitem*)&axisitem1, &axis_featid1);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id1 = " + to_string(axis_featid1.id));

		status = ProGeomitemFeatureGet((ProGeomitem*)&axisietm2, &axis_featid2);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id2 = " + to_string(axis_featid2.id));


		status = ProModelitemMdlGet(&axisitem1, &axis_mdlmdl1);
		status = ProModelitemMdlGet(&axisietm2, &axis_mdlmdl2);

		status = ProMdlMdlnameGet(axis_mdlmdl1, waxsmdlName1);
		ProWstringToString(caxsmdlName1, waxsmdlName1);
		ruleLog.Write("Axis model Name :" + string(caxsmdlName1));
		status = ProMdlMdlnameGet(axis_mdlmdl2, waxsmdlName2);
		ProWstringToString(caxsmdlName2, waxsmdlName2);
		ruleLog.Write("Axis model Name :" + string(caxsmdlName2));

		char tempAxs2Name[PRO_NAME_SIZE] = "TEMP_AXIS2";
		int iOut = createTangentDatumAxisWithReference(sel_axis[0], "A_2", tempAxs2Name);
		ruleLog.Write("createTangentDatumAxisWithReference = " + to_string(status));

		ProStringToWstring(name3, "TEMP_AXIS2");
		status = ProModelitemByNameInit(p_handle, PRO_AXIS, name3, &p_item3);
		ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

		status = ProSelectionAlloc(NULL, &p_item3, &sel3);
		ruleLog.Write("ProSelectionAlloc2 = " + to_string(status));

		status = measureAngleBetweenSurfaceAndAxis(sel1, sel3, Angle1);
		ruleLog.Write("Angle1: " + to_string(Angle1));

		char tempAxs1Name[PRO_NAME_SIZE] = "TEMP_AXIS1";
		int Out = createTangentDatumAxisWithReference(sel_axis[1], "A_1", tempAxs1Name);
		ruleLog.Write("createTangentDatumAxisWithReference = " + to_string(status));

		ProStringToWstring(name2, "TEMP_AXIS1");
		status = ProModelitemByNameInit(p_handle, PRO_AXIS, name2, &p_item2);
		ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

		status = ProSelectionAlloc(NULL, &p_item2, &sel2);
		ruleLog.Write("ProSelectionAlloc2 = " + to_string(status));

		status = measureAngleBetweenSurfaceAndAxis(sel1, sel2, Angle2);
		ruleLog.Write("Angle2: " + to_string(Angle2));

		int del = deleteDatumAxis(tempAxs1Name);
		ruleLog.Write("deleteDatumAxis = " + to_string(status));

		int del2 = deleteDatumAxis(tempAxs2Name);
		ruleLog.Write("deleteDatumAxis = " + to_string(status));
	}
	float Deviated;
	Deviated = Angle1 - Angle2;
	if (Deviated < 0) {
		Deviated = std::abs(Deviated);
		ruleLog.Write("abs Deviated: " + to_string(Deviated));
	}
	else {
		ruleLog.Write("Deviated: " + to_string(Deviated));
	}

	char in[50];
	if (Angle1 >= Angle2 - 1.0 && Angle1 <= Angle2 + 1.0)
	{
		final_res.result = "PASS";
		sprintf(remark, "Measured Value :RA inclination is in %0.1f deg of AGB inclination. ;\nAcceptance criteria:Target RA inclination to be with in ± 1 deg of AGB inclination", Deviated);
		sprintf(Parents_info, "\nAxis_id 1: %d, Partnumber: %s.\nAixs_id 2: %d, Partnumber: %s.", axis_featid1.id, caxsmdlName1, axis_featid2.id, caxsmdlName2);
		final_res.remark = string(remark) + Parents_info;
	}
	else
	{
		final_res.result = "FAIL";
		sprintf(remark, "Measured Value :RA inclination is %0.2f deg of AGB inclination.;\nAcceptance criteria:Target RA inclination to be with in ± 1 deg of AGB inclination.", Deviated);
		sprintf(Parents_info, "\nAxis_id 1: %d, Partnumber: %s.\nAixs_id 2: %d, Partnumber: %s.", axis_featid1.id, caxsmdlName1, axis_featid2.id, caxsmdlName2);
		final_res.remark = string(remark) + Parents_info;
	}
	return 0;
}

ProError selection_action_IRF2C01_011(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF2C01011 -----------------------------");

	int rule_sts;
	InterfaceRule _irule;
	bool* quitAction = (bool*)data;

	status = ProSelect((char*)"axis", 2, NULL, NULL, NULL, NULL, &sel_axis, &n_sels_011);
	ruleLog.Write("ProSelect = " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_IR_F2C01_011, CommitOK);
		if (quitAction != NULL)
			*quitAction = true;
		return status;
	}

	else if (n_sels_011 < 2 || status != PRO_TK_NO_ERROR) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		if (quitAction != NULL)
			*quitAction = true;
		status = ProUIPushbuttonDisable(DLG_IR_F2C01_011, CommitOK);
		return status;
	}

	status = ProUIPushbuttonEnable(DLG_IR_F2C01_011, CommitOK);
	return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES		| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F2C01-012	| Pallavi Garodi   | MF2C01; MF1A01		| Minimum 20mm clearance to be ensured with propeller shaft and cross member.
===================================================================================================================*/

struct SelectionStruct {
	ProSelection p_selection{};
	char         Description[PRO_PATH_SIZE]{};
	char         Name[PRO_PATH_SIZE]{};
	int          FeatId{};
	bool         Flag = false;
};

#define DLG_IRF2C01_012 "dlg_IR_F2C01_012"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"

int ModelsCount_09{}, AsmModelCount_09{}, NoOfAsmFixed_09{}, MdlCount_09{}, OwnerFeatID_09{}, Levels_09{};

vector<SelectionStruct>		SelectionInfo{};
Asm_model	                 AsmC_Model[1000]{};
Asm_model	                 C_Model[1000]{};
vector<feat_id_data>		Feat_ID_DataArr{};
vector<string> crssmbrPartName;

int IRF2C01::IRF2C01_012(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2C02::IRF2C01_012  ==========================");

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF2C01_012, DLG_IRF2C01_012);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2C01_012, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2C01_012, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2C01_012, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2C01_012, &dlg_sts);
	//ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF2C01_012);
	//ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	//To get F2C01 model

	ComponentData	reqComps_f2co1[1]{};
	string reqCompSubModAuto[1] = { "F2C01" };
	for (int i = 0; i < subModulesList.size(); ++i) {
		for (int j = 0; j < sizeof(reqCompSubModAuto) / sizeof(reqCompSubModAuto[0]); ++j) {
			if (subModulesList[i].name.find(reqCompSubModAuto[j]) != string::npos) {
				strcpy(reqComps_f2co1[j].name, subModulesList[i].name.c_str());
			}
		}
	}
	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&reqComps_f2co1);
	for (auto elem : reqComps_f2co1) {
		ruleLog.Write("reqComps_f5a07_002[].name = " + string(elem.name));
		ruleLog.Write("reqComps_f5a07_002[].id = " + to_string(elem.id));
	}

	ProFeature* pFeature;
	ProSelection sels;
	ProName comp_name;
	ProModelitem feature;
	ProMdl reqMdls;

	ProStringToWstring(comp_name, reqComps_f2co1->name);
	ruleLog.Write("comp1_name: " + string(reqComps_f2co1->name));
	status = ProMdlnameInit(comp_name, PRO_MDLFILE_ASSEMBLY, &reqMdls);
	//ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls, &feature);
	//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProAsmcomppath path;

	status = ProAsmcomppathInit((ProSolid)curMdl, ProIdTable{ reqComps_f2co1->id }, 1, &path);
	//ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path, &feature, &sels);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));


	// To get cross member models

	SelectionInfo.clear();
	ProMdl Mdl{};
	status = ProMdlCurrentGet(&Mdl);
	ProPath modelFullPath = { 0 };
	status = ProMdlOriginGet(Mdl, modelFullPath);
	ruleLog.Write("ProMdlOriginGet: " + to_string(status));
	char PathName[PRO_NAME_SIZE]{};
	ProWstringToString(PathName, modelFullPath);
	ruleLog.Write("modelFullPath: " + string(PathName));

	curMdl = Mdl;
	Levels_09 = 1;
	NoOfAsmFixed_09 = 0;
	C_Model[0].Model = Mdl;
	C_Model[0].Model_feat_id = 0;
	ModelsCount_09 = 1;
	AsmModelCount_09 = 0;

	while (ModelsCount_09 > 0) {
		for (int a = 0; a < ModelsCount_09; ++a) {
			OwnerFeatID_09 = C_Model[a].Model_feat_id;
			status = ProSolidFeatVisit((ProSolid)C_Model[a].Model, (ProFeatureVisitAction)NameAndIdVisitAction, compsFilter, NULL);
			ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
		}

		if (AsmModelCount_09 > 0) {
			++Levels_09;
			for (int b = 0; b < AsmModelCount_09; ++b) {
				C_Model[b].Model = AsmC_Model[b].Model;
				C_Model[b].Model_feat_id = AsmC_Model[b].Model_feat_id;
			}
			ModelsCount_09 = AsmModelCount_09;
			AsmModelCount_09 = 0;
		}
		else {
			ModelsCount_09 = 0;
		}
	}
	//End

	double minimumclearance1 = 20.0;
	vector <double> distances;

	for (int c = 0; c < SelectionInfo.size(); c++) {
		ProBoolean is_interference_found;
		Pro3dPnt pnt_arr[2];
		double distance;
		status = ProFitClearanceCompute(sels, PRO_FIT_INCLUDE_NONE, SelectionInfo[c].p_selection, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
		distances.push_back(distance);
	}

	//DECLARE RESULT
	for (int b = 0; b < distances.size(); b++) {
		ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistances " + to_string(b + 1) + ": " + to_string(distances[b]));
		//ruleLog.Write("Part Name:  " +  to_string(b + 1) + ": " + string(partname[b]));
	}

	int min_element_index = min_element(distances.begin(), distances.end()) - distances.begin();
	ruleLog.Write("min_element_index:  " + to_string(min_element_index));
	ruleLog.Write("min_element_index:  " + to_string(distances[min_element_index]));
	ruleLog.Write("SelectionInfo[c].Name: " + string(SelectionInfo[min_element_index].Name));

	ProSelectionHighlight(SelectionInfo[min_element_index].p_selection, PRO_COLOR_HIGHLITE);

	if (distances[min_element_index] < minimumclearance1)
	{
		final_res.result = "FAIL";
		sprintf(remark, "Minimum clearance between propeller shaft and cross member found is %.2lf mm,\nCross Member Part Number is %s.prt,\nNote: DVA/Vehicle trials are required,\n\nAcceptance Criteria: Minimum 20mm clearance to be ensured with propeller shaft and cross member", distances[min_element_index], SelectionInfo[min_element_index].Name);
		final_res.remark = string(remark);
	}
	else
	{
		final_res.result = "PASS";
		sprintf(remark, "Minimum clearance between propeller shaft and cross member found is %.2lf mm,\nCross Member Part Number is %s.prt, \n\nAcceptance Criteria: Minimum 20mm clearance to be ensured with propeller shaft and cross member", distances[min_element_index], SelectionInfo[min_element_index].Name);
		final_res.remark = string(remark);
	}

	ruleLog.Write("status: " + string(final_res.result));
	ruleLog.Write("remark: " + string(final_res.remark));

	status = ProUIDialogDestroy(DLG_IRF2C01_012);
	//ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	return 0;
}

ProError NameAndIdVisitAction(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	//ruleLog.Write("----------------------------- NameAndIdVisitAction -----------------------------");

	SelectionStruct CM_Selection;
	ProMdlfileType    comp_type;
	ProFamilyMdlName  comp_name;
	status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
	//ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));

	char part_no[PRO_PATH_SIZE]{};
	ProWstringToString(part_no, comp_name);
	//ruleLog.Write("ProMdlName: " + string(part_no));

	++MdlCount_09;

	ProMdl model;
	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
	//ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));

	ProMdlType type;
	status = ProMdlTypeGet(model, &type);
	//ruleLog.Write("ProMdlTypeGet:" + to_string(status));

	wchar_t wFeatName[PRO_NAME_SIZE]{};
	status = ProMdlMdlnameGet(model, wFeatName);
	//ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(CM_Selection.Name, wFeatName);

	ProModelitem modelItem;
	status = ProMdlToModelitem(model, &modelItem);
	//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProName      pDescName = L"DESCRIPTION";
	ProParameter pDesc;
	status = ProParameterInit(&modelItem, pDescName, &pDesc);
	//ruleLog.Write("ProParameterInit: " + to_string(status));

	if (status == PRO_TK_E_NOT_FOUND) {
		ProName      pTmlDescName = L"TML_PART_DESC";
		status = ProParameterInit(&modelItem, pTmlDescName, &pDesc);
		//ruleLog.Write("ProParameterInit: " + to_string(status));
	}

	ProParamvalue pvDesc;
	status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
	//ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));

	ProWstringToString(CM_Selection.Description, pvDesc.value.s_val);
	//ruleLog.Write("ProWstringToString: " + string(CM_Selection.Description));

	CM_Selection.FeatId = p_feature->id;

	feat_id_data  _FeatIDdata;
	if (Levels_09 == 1) {
		_FeatIDdata.feat_ids[0] = p_feature->id;
		_FeatIDdata.level = Levels_09;
		Feat_ID_DataArr.push_back(_FeatIDdata);
	}
	else {
		for (int j = 0; j < Feat_ID_DataArr.size(); ++j) {
			if (Feat_ID_DataArr[j].feat_ids[Levels_09 - 2] == OwnerFeatID_09) {
				feat_id_data   owner_feat_id_data = Feat_ID_DataArr[j];
				for (int i = 0; i < Levels_09 - 1; ++i) {
					_FeatIDdata.feat_ids[i] = owner_feat_id_data.feat_ids[i];
				}
				_FeatIDdata.feat_ids[Levels_09 - 1] = p_feature->id;
				_FeatIDdata.level = Levels_09;
				break;
			}
		}
		Feat_ID_DataArr.push_back(_FeatIDdata);
	}

	const char* searchString1 = "CROSS MEMBER ";
	bool    compfound{ false };
	//regex   pattern1(searchString1);
	if (strcmp(CM_Selection.Description, searchString1) == 0) {
		compfound = true;

		ProIdTable          comp_id_table;
		int                 table_num;
		ProAsmcomppath      p_comp_path;
		ProModelitem        p_modelitem;

		table_num = Levels_09;

		for (int m = 0; m < Levels_09; ++m) {
			comp_id_table[m] = _FeatIDdata.feat_ids[m];
		}

		status = ProMdlToModelitem(model, &p_modelitem);
		//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		ProMdl curMdl;
		status = ProMdlCurrentGet(&curMdl);
		//ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

		status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
		//ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
		//ruleLog.Write("ProAsmcomppathInit: " + to_string(&p_comp_path));

		status = ProSelectionAlloc(&p_comp_path, &p_modelitem, &CM_Selection.p_selection);
		//ruleLog.Write("ProSelectionAlloc: " + to_string(status));

		if (status == PRO_TK_NO_ERROR) {
			SelectionInfo.push_back(CM_Selection);
		}
	}

	if (type == PRO_MDL_ASSEMBLY && compfound == false)
	{
		AsmC_Model[AsmModelCount_09].Model = model;
		AsmC_Model[AsmModelCount_09].Model_feat_id = p_feature->id;
		AsmModelCount_09 += 1;
	}
	return PRO_TK_NO_ERROR;
}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2C01013		| Prajakta Bhelawe	| MF2C01; MF1A01	|  Minimum 15mm clearance to be ensured with propeller shaft fasteners and cross member.
===================================================================================================================*/

#define DLG_F2C01_013	 "dlg_IR_F2C01_013" 
#define PR_CANCEL        "CommitCancel" 
#define CommitOK         "CommitOK"
#define RB_Grp1				"RadioGroup1"
#define Label2				"Label2"
#define Select1				"Select1"

vector<string> targetStr_crossMem = { "CROSS MEMBER", "CROSS MEMBER,REAR SUSPENSION", "CROSS MEMBER,SHOCK ABSORBER" };

ProMdl Mdl;
//F1A01
ProMdl reqMdl_F1A01;
int models_cnt_F1A01;
int	owner_feat_id_F1A01;
Asm_model_F1A01 models_F1A01[1000];
Asm_model_F1A01 Assy_models[1000];
int level_F1A01;
int	Assy_models_cnt_F1A01;
int model_count_F1A01;
vector<PartNames_F1A01> reqComps_F1A01;
vector<feat_id_data_F1A01> feat_id_data_arr_F1A01;

//F2C01
ProMdl reqMdl_F2C01;
int models_cnt_F2C01;
int	owner_feat_id_F2C01;
Asm_model_F2C01 models_F2C01[1000];
Asm_model_F2C01 Assy_models_F2C01[1000];
int level_F2C01;
int	Assy_models_cnt_F2C01;
int model_count_F2C01;
vector<PartNames_F2C01> reqComps_F2C01;
vector<feat_id_data_F2C01> feat_id_data_arr_F2C01;

//F2C02
vector<PartnameDescriptionPairF2C01>	reqCompsF2C02;

//vector<string> first_level_asm;
pathVariables pathVar;
ProSelection p_selection_CrossMem, p_selection_fastners, p_selection_bracket;
vector<ProSelection> p_selCrossMem, p_selFastners, p_selBracket;
string boltRemark{}, PartName_fastners{}, PartName_CrossMem{};
string exsitingPvalspacesRem;

double clearanceVal1 = 0, clearanceVal2 = 0;

vector<double> clearanceValVector, clearanceValVectorPass;
vector<string> PartNameCrossMemVector, PartNameFastnerVector;

int feature_id_F2C01{};
int feature_id_F1A01{};

ProBoolean is_interference_found = PRO_B_FALSE;
Pro3dPnt coord[2];
vector<ProSelection> crossmembHighlightPass, crossmembHighlightFail, fastenersHighlightPass, fastenersHighlightFail;
bool isManual = NULL;
ProSelection* selectionF2C01_013 = nullptr;
int n_selectionF2C01_013;
vector<string>  name_asmF2C01_013;

int IRF2C01::IRF2C01_013(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2C01::IRF2C01_013   ==========================");

	deleteDatumPoint("distance_pnnt1");

	InterfaceRule _irule;
	isManual = NULL;
	string crossMember, propShaftFastener;

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_F2C01_013, DLG_F2C01_013);
	status = ProUIDialogAboveactivewindowSet(DLG_F2C01_013, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_F2C01_013, PR_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F2C01_013, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIPushbuttonDisable(DLG_F2C01_013, PB_RUN);

	status = ProUILabelHide(DLG_F2C01_013, Label2);
	ruleLog.Write("ProUILabelHide status: " + to_string(status));
	status = ProUIPushbuttonHide(DLG_F2C01_013, Select1);
	ruleLog.Write("ProUIPushbuttonHide status: " + to_string(status));


	status = ProUIPushbuttonActivateActionSet(DLG_F2C01_013, Select1, (ProUIAction)selectActionF2C01_013, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));

	status = ProUIRadiogroupSelectActionSet(DLG_F2C01_013, RB_Grp1, (ProUIAction)radioGrpSelectAction, NULL);
	ruleLog.Write("ProUIRadiogroupSelectActionSet status: " + to_string(status));
	status = ProUIDialogHide(DLG_IRC_MAIN);
	int radioGrpNames[2];
	char** buttonNames;

	//Radio button, selected for first button (default)
	status = ProUIRadiogroupSelectednamesGet(DLG_F2C01_013, RB_Grp1, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status main: " + to_string(status));
	ruleLog.Write("selected button name: " + (string)buttonNames[0]);

	if (buttonNames[0] == "rb1")
	{
		isManual = false;
	}

	status = ProUIDialogActivate(DLG_F2C01_013, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_F2C01_013);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	status = ProUIDialogDestroy(DLG_F2C01_013);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	//Automatic verification
	if (isManual == false)
	{
		deleteDatumPoint("distance_pnnt1");
		status = ProMdlCurrentGet(&Mdl);
		ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));

		//F1A01
		level_F1A01 = 1;
		models_cnt_F1A01 = 1;
		models_F1A01[0].Model = Mdl;
		models_F1A01[0].Model_feat_id = 0;

	F1A01_begin:
		for (int a = 0; a < models_cnt_F1A01; a++)
		{
			owner_feat_id_F1A01 = models_F1A01[a].Model_feat_id;
			status = ProSolidFeatVisit((ProSolid)models_F1A01[a].Model, (ProFeatureVisitAction)cross_memb_fetch_F1A01, compsFilter, (ProAppData)&reqComps_F1A01);
			ruleLog.Write("ProSolidFeatVisit status = " + to_string(status));
		}

		if (Assy_models_cnt_F1A01 > 0) {
			++level_F1A01;

			for (int b = 0; b < Assy_models_cnt_F1A01; ++b)
			{
				models_F1A01[b].Model = Assy_models[b].Model;
				models_F1A01[b].Model_feat_id = Assy_models[b].Model_feat_id;
			}
			models_cnt_F1A01 = Assy_models_cnt_F1A01;
			Assy_models_cnt_F1A01 = 0;
			goto F1A01_begin;
		}
		//F1A01 END

		//F2C01
		level_F2C01 = 1;
		models_cnt_F2C01 = 1;
		models_F2C01[0].Model = Mdl;
		models_F2C01[0].Model_feat_id = 0;

	F2C01_begin:
		for (int a = 0; a < models_cnt_F2C01; a++)
		{
			owner_feat_id_F2C01 = models_F2C01[a].Model_feat_id;
			status = ProSolidFeatVisit((ProSolid)models_F2C01[a].Model, (ProFeatureVisitAction)propShaft_fasteners_fetch_F2C01, compsFilter, (ProAppData)&reqComps_F2C01);
			ruleLog.Write("ProSolidFeatVisitF2C01 status = " + to_string(status));
		}

		if (Assy_models_cnt_F2C01 > 0) {
			++level_F2C01;

			for (int b = 0; b < Assy_models_cnt_F2C01; ++b)
			{
				models_F2C01[b].Model = Assy_models[b].Model;
				models_F2C01[b].Model_feat_id = Assy_models[b].Model_feat_id;
			}
			models_cnt_F2C01 = Assy_models_cnt_F2C01;
			Assy_models_cnt_F2C01 = 0;
			goto F2C01_begin;

		}
		//F2C01 END

		//F2C02
		status = ProSolidFeatVisit((ProSolid)Mdl, mouting_bkt_fetch_F2C02, compsFilter, (ProAppData)&reqCompsF2C02);
		ruleLog.Write("ProSolidFeatVisitF2C02 status =" + to_string(status));

		boltRemark += "Clearance between ";
		for (int i = 0; i < p_selFastners.size(); i++) {
			for (int j = 0; j < p_selBracket.size(); j++) {
				status = ProFitClearanceCompute(p_selFastners[i], PRO_FIT_INCLUDE_NONE, p_selection_bracket, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearanceVal1, NULL, &is_interference_found, coord);
				//ruleLog.Write("ProFitClearanceCompute FOR-1 = " + to_string(status) + "\ndistance1 = " + to_string(clearanceVal1));

				if (is_interference_found == 0) {
					for (int k = 0; k < p_selCrossMem.size(); k++) {
						status = ProFitClearanceCompute(p_selFastners[i], PRO_FIT_INCLUDE_NONE, p_selCrossMem[k], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearanceVal2, NULL, &is_interference_found, coord);
						// ruleLog.Write("ProFitClearanceCompute FOR-2 = " + to_string(status) + "\ndistance2 = " + to_string(clearanceVal2));

						if (clearanceVal2 <= 15)
						{
							fastenersHighlightFail.push_back(p_selFastners[i]);
							crossmembHighlightFail.push_back(p_selCrossMem[k]);
							clearanceValVector.push_back(clearanceVal2);

							boltRemark += PartNameFastnerVector[i] + ".PRT and ";
							boltRemark += PartNameCrossMemVector[k] + ".PRT =";
							boltRemark += to_string(clearanceVal2) + "mm";
							boltRemark += "\n";
						}

						else
						{
							clearanceValVectorPass.push_back(clearanceVal2);
							fastenersHighlightPass.push_back(p_selFastners[i]);
							crossmembHighlightPass.push_back(p_selCrossMem[k]);

						}
					}
				}
			}
		}

		if (clearanceValVector.size() == 0 && p_selFastners.size() != 0 && p_selCrossMem.size() != 0)
		{
			final_res.result = "PASS";
			boltRemark += "all propeller shaft fasteners and cross members is greater than 15mm.";
			ruleLog.Write("clearanceValVector: " + to_string(clearanceValVectorPass.size()));

			double smallest = clearanceValVectorPass[0];
			size_t smallest_index = 0;

			for (int i = 1; i < clearanceValVectorPass.size(); ++i) {
				ruleLog.Write("insde for");
				if (clearanceValVectorPass[i] < smallest) {
					ruleLog.Write("clearanceValVectorPass = " + to_string(clearanceValVectorPass[i]));
					smallest = clearanceValVectorPass[i];
					smallest_index = i;
				}
			}
			ruleLog.Write("smallest = " + to_string(smallest));
			ruleLog.Write("smallest_index = " + to_string(smallest_index));

			string strClearanceF2C01_1;
			strClearanceF2C01_1 = to_string(smallest);

			string result1;
			size_t dotPos1 = strClearanceF2C01_1.find('.');

			if (dotPos1 != std::string::npos) {
				// Check if there are at least two characters after the decimal point
				if (dotPos1 + 3 <= strClearanceF2C01_1.size()) {
					result1 = strClearanceF2C01_1.substr(0, dotPos1 + 3);  // Include the dot and two characters after
				}
				else {
					// Less than two characters after the decimal point
					result1 = strClearanceF2C01_1.substr(0, dotPos1 + 1);  // Include only up to the decimal point
				}
			}
			else {
				// No decimal point found
				result1 = strClearanceF2C01_1;
			}

			ruleLog.Write("result " + (result1));

			ProModelitem part_model_item1, part_model_item2;
			ProName w_name1, w_name2;
			char name1[PRO_NAME_SIZE];
			char name2[PRO_NAME_SIZE];

			status = ProFitClearanceCompute(fastenersHighlightPass[smallest_index], PRO_FIT_INCLUDE_NONE, crossmembHighlightPass[smallest_index], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearanceVal2, NULL, &is_interference_found, coord);

			string strClearanceF2C01;
			strClearanceF2C01 = to_string(clearanceVal2);

			string result2;
			size_t dotPos2 = strClearanceF2C01.find('.');

			if (dotPos2 != std::string::npos) {
				// Check if there are at least two characters after the decimal point
				if (dotPos2 + 3 <= strClearanceF2C01.size()) {
					result2 = strClearanceF2C01.substr(0, dotPos2 + 3);  // Include the dot and two characters after
				}
				else {
					// Less than two characters after the decimal point
					result2 = strClearanceF2C01.substr(0, dotPos2 + 1);  // Include only up to the decimal point
				}
			}
			else {
				// No decimal point found
				result2 = strClearanceF2C01;
			}

			ruleLog.Write("result " + (result2));

			status = ProSelectionModelitemGet(fastenersHighlightPass[smallest_index], &part_model_item1);
			ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

			status = ProSelectionModelitemGet(crossmembHighlightPass[smallest_index], &part_model_item2);
			ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

			status = ProMdlMdlnameGet(part_model_item1.owner, w_name1);
			ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

			status = ProMdlMdlnameGet(part_model_item2.owner, w_name2);
			ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

			ProWstringToString(name1, w_name1);
			ProWstringToString(name2, w_name2);

			ruleLog.Write("name1 = " + string(name1));
			ruleLog.Write("name2 = " + string(name2));

			createDatumPoints(coord, "CSYS_ASM_DEF", "distance_pnnt1");
			boltRemark += "\n\nSmallest Clearance is between " + string(name1) + ".PRT & " + string(name2) + ".PRT: " + (result2)+".mm";

			_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "PASS", "Distance between highlighted cross members and propeller shaft fasteners is greater than 15.00mm.");
		}

		else
		{
			final_res.result = "FAIL";
			boltRemark += "\n";
			for (int i = 0; i < fastenersHighlightFail.size(); i++)
			{
				for (int j = 0; j < crossmembHighlightFail.size(); j++)
				{
					status = ProSelectionHighlight(fastenersHighlightFail[i], PRO_COLOR_SS_FAILED_ITEMS);
					//ruleLog.Write("ProSelectionHighlight: " + to_string(status));
					status = ProSelectionHighlight(crossmembHighlightFail[j], PRO_COLOR_SS_FAILED_ITEMS);
					//ruleLog.Write("ProSelectionHighlight: " + to_string(status));
				}
			}
			_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "FAIL", "Distance between highlighted cross members and propeller shaft fasteners is less than 15.00mm.");
		}
	}

	else // manual selection of surfaces
	{
		deleteDatumPoint("distance_pnnt1");

		if (n_selectionF2C01_013 < 2)
		{
			UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			return -1;
		}
		else
		{
			ruleLog.Write("manual selection");
			status = ProFitClearanceCompute(selectionF2C01_013[0], PRO_FIT_INCLUDE_NONE, selectionF2C01_013[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearanceVal2, NULL, &is_interference_found, coord);
			ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));
			ruleLog.Write("clearance1 = " + to_string(clearanceVal2));

			string strClearanceA1B01;
			strClearanceA1B01 = to_string(clearanceVal2);

			string result3;
			size_t dotPos3 = strClearanceA1B01.find('.');

			if (dotPos3 != std::string::npos) {
				// Check if there are at least two characters after the decimal point
				if (dotPos3 + 3 <= strClearanceA1B01.size()) {
					result3 = strClearanceA1B01.substr(0, dotPos3 + 3);  // Include the dot and two characters after
				}
				else {
					// Less than two characters after the decimal point
					result3 = strClearanceA1B01.substr(0, dotPos3 + 1);  // Include only up to the decimal point
				}
			}
			else {
				// No decimal point found
				result3 = strClearanceA1B01;
			}

			ruleLog.Write("result " + (result3));


			crossMember = name_asmF2C01_013[0];
			propShaftFastener = name_asmF2C01_013[1];

			ruleLog.Write("crossMember = " + crossMember);
			ruleLog.Write("propShaftFastener = " + propShaftFastener);

			boltRemark += "Clearance between Cross Member and Propeller Shaft Fastener";
			boltRemark += "(" + string(crossMember) + ".PRT and " + string(propShaftFastener) + ".PRT) ";
			boltRemark += "= " + (result3)+".mm";

			createDatumPoints(coord, "CSYS_ASM_DEF", "distance_pnnt1");

			if (clearanceVal2 >= 15)
			{
				final_res.result = "PASS";
			}

			else
			{
				final_res.result = "FAIL";
			}
		}
	}
	boltRemark += "\n\nAcceptance Criteria: Clearance between propeller shaft fasteners and cross memeber should be minimum 15.00mm. ";
	final_res.remark = boltRemark;

	reqComps_F1A01.clear();
	feat_id_data_arr_F1A01.clear();
	reqComps_F2C01.clear();
	feat_id_data_arr_F2C01.clear();
	reqCompsF2C02.clear();
	p_selCrossMem.clear();
	p_selFastners.clear();
	p_selBracket.clear();
	clearanceValVector.clear();
	clearanceValVectorPass.clear();
	PartNameCrossMemVector.clear();
	PartNameFastnerVector.clear();
	crossmembHighlightPass.clear();
	crossmembHighlightFail.clear();
	fastenersHighlightPass.clear();
	fastenersHighlightFail.clear();
	boltRemark.clear();
	PartName_fastners.clear();
	exsitingPvalspacesRem.clear();
	isManual = NULL;
	is_interference_found = PRO_B_FALSE;
	name_asmF2C01_013.clear();

	return 0;
}

ProError cross_memb_fetch_F1A01(ProFeature* p_feature, ProError status, ProAppData appdata)
{
	ruleLog.Write("----------------------------- cross_memb_fetch_F1A01 -----------------------------");
	vector<PartNames_F1A01>* prtname_list = (vector<PartNames_F1A01>*)appdata;

	char existingPval[PRO_LINE_SIZE]{};
	ProMdl					model;
	ProFeattype				ftype;

	status = ProFeatureTypeGet(p_feature, &ftype);

	if (ftype == PRO_FEAT_COMPONENT)
	{
		++model_count_F1A01;

		ProMdlType				type;
		status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
		//ruleLog.Write("ProAsmcompMdlGet status  =  " + to_string(status));
		status = ProMdlTypeGet(model, &type);
		//ruleLog.Write("ProMdlTypeGet status  =  " + to_string(status));

		feat_id_data_F1A01  _feat_id_data_F1A01;
		if (level_F1A01 == 1) {

			wchar_t					wMdlName[PRO_NAME_SIZE];
			char					cMdlName[PRO_NAME_SIZE];
			string part_name;
			string tokenF1A01 = "F1A01";
			char charcFeatNameF1A01[PRO_NAME_SIZE];

			status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl_F1A01);
			status = ProMdlMdlnameGet(reqMdl_F1A01, wMdlName);
			ProWstringToString(cMdlName, wMdlName);
			part_name = cMdlName;

			if (part_name.find(tokenF1A01) != string::npos)
			{
				_feat_id_data_F1A01.feat_ids[0] = p_feature->id;
				_feat_id_data_F1A01.level = level_F1A01;
				feat_id_data_arr_F1A01.push_back(_feat_id_data_F1A01);

				strcpy(charcFeatNameF1A01, cMdlName);
				//ruleLog.Write("Char Feat Name = " + string(charcFeatNameF2C01));
				if (p_feature->id != 0)
					feature_id_F1A01 = p_feature->id;
				ruleLog.Write("feature_id_F1A01 check1 = " + to_string(feature_id_F1A01));
			}
		}

		else {
			for (int j = 0; j < feat_id_data_arr_F1A01.size(); ++j) {

				if (feat_id_data_arr_F1A01[j].feat_ids[level_F1A01 - 2] == owner_feat_id_F1A01) {
					feat_id_data_F1A01	owner_feat_id_data = feat_id_data_arr_F1A01[j];
					for (int i = 0; i < level_F1A01 - 1; ++i) {
						_feat_id_data_F1A01.feat_ids[i] = owner_feat_id_data.feat_ids[i];
					}
					_feat_id_data_F1A01.feat_ids[level_F1A01 - 1] = p_feature->id;
					_feat_id_data_F1A01.level = level_F1A01;
					break;
				}
			}
			feat_id_data_arr_F1A01.push_back(_feat_id_data_F1A01);
		}

		wchar_t wFeatName[PRO_NAME_SIZE];
		char cFeatName[PRO_NAME_SIZE];
		ProModelitem modelItem;
		ProParameter pDesc;
		ProParamvalue pvDesc;
		ProName pDescName = L"DESCRIPTION";
		string                  description;

		status = ProMdlMdlnameGet(model, wFeatName);
		//ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

		ProWstringToString(cFeatName, wFeatName);

		status = ProMdlToModelitem(model, &modelItem);
		//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&modelItem, pDescName, &pDesc);
		//ruleLog.Write("ProParameterInit: " + to_string(status));

		if (status != PRO_TK_E_NOT_FOUND)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			//ruleLog.Write("ProParameterValueWithUnitsGet : " + to_string(status));

			ProWstringToString(existingPval, pvDesc.value.s_val);
			//ruleLog.Write("Existing val: " + existingPval + "Feature ID = " + to_string(p_feature->id));

			exsitingPvalspacesRem = remSpacesAtBothEnds1(string(existingPval));
		}

		//for cross members
		for (int i = 0; i < targetStr_crossMem.size(); i++)
		{
			if (targetStr_crossMem[i] == exsitingPvalspacesRem)
			{
				//int feature_ID = p_feature->id;
				//ruleLog.Write("Feature ID = " + to_string(feature_ID) + "Description = " + exsitingPvalspacesRem);

				ProIdTable			comp_id_table;
				int table_num;
				ProAsmcomppath		p_comp_path;

				table_num = level_F1A01;
				//ruleLog.Write("table_num =  " + to_string(table_num));
				pathVar.table_num_Vector.push_back(table_num);

				for (int m = 0; m < level_F1A01; ++m) {
					comp_id_table[m] = _feat_id_data_F1A01.feat_ids[m];
					ruleLog.Write("comp_id_table[] =  " + to_string(m) + "  " + to_string(comp_id_table[m]));
				}

				ruleLog.Write("comp_id_table[0] = " + to_string(comp_id_table[0]));
				ruleLog.Write("feature_id_F1A01 = " + to_string(feature_id_F1A01));

				if (comp_id_table[0] == feature_id_F1A01)
				{
					ProMdl curMdl;
					status = ProMdlCurrentGet(&curMdl);

					status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
					//ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

					status = ProSelectionAlloc(&p_comp_path, &modelItem, &p_selection_CrossMem);
					ruleLog.Write("ProSelectionAlloc: " + to_string(status));
					ruleLog.Write("Part Name crossMemb= " + string(cFeatName));
					PartName_CrossMem = cFeatName;

					PartNameCrossMemVector.push_back(PartName_CrossMem);
					p_selCrossMem.push_back(p_selection_CrossMem);
				}
			}
		}

		// for asm
		if (type == PRO_MDL_ASSEMBLY)
		{
			Assy_models[Assy_models_cnt_F1A01].Model = model;
			Assy_models[Assy_models_cnt_F1A01].Model_feat_id = p_feature->id;
			Assy_models_cnt_F1A01 += 1;
		}
	}
	return PRO_TK_NO_ERROR;
}

ProError propShaft_fasteners_fetch_F2C01(ProFeature* p_feature, ProError status, ProAppData appdata)
{
	ruleLog.Write("----------------------------- propShaft_fasteners_fetch_F2C01 -----------------------------");
	vector<PartNames_F2C01>* prtname_list = (vector<PartNames_F2C01>*)appdata;

	char existingPval[PRO_LINE_SIZE]{};
	ProMdl					model;
	ProFeattype				ftype;

	status = ProFeatureTypeGet(p_feature, &ftype);

	if (ftype == PRO_FEAT_COMPONENT)
	{
		++model_count_F2C01;

		ProMdlType				type;
		status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
		//ruleLog.Write("ProAsmcompMdlGet status  =  " + to_string(status));
		status = ProMdlTypeGet(model, &type);
		//ruleLog.Write("ProMdlTypeGet status  =  " + to_string(status));

		feat_id_data_F2C01  _feat_id_data_F2C01;
		if (level_F2C01 == 1) {

			wchar_t					wMdlName[PRO_NAME_SIZE];
			char					cMdlName[PRO_NAME_SIZE];
			string part_name;
			string tokenF2C01 = "F2C01";
			char charcFeatNameF2C01[PRO_NAME_SIZE];

			status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl_F2C01);
			status = ProMdlMdlnameGet(reqMdl_F2C01, wMdlName);
			ProWstringToString(cMdlName, wMdlName);
			part_name = cMdlName;

			if (part_name.find(tokenF2C01) != string::npos)
			{
				_feat_id_data_F2C01.feat_ids[0] = p_feature->id;
				_feat_id_data_F2C01.level = level_F2C01;
				feat_id_data_arr_F2C01.push_back(_feat_id_data_F2C01);

				strcpy(charcFeatNameF2C01, cMdlName);
				//ruleLog.Write("Char Feat Name = " + string(charcFeatNameF2C01));
				if (p_feature->id != 0)
					feature_id_F2C01 = p_feature->id;
				ruleLog.Write("feature_id_F2C01 check1 = " + to_string(feature_id_F2C01));
			}
		}

		else {
			for (int j = 0; j < feat_id_data_arr_F2C01.size(); ++j) {

				if (feat_id_data_arr_F2C01[j].feat_ids[level_F2C01 - 2] == owner_feat_id_F2C01) {
					feat_id_data_F2C01	owner_feat_id_data = feat_id_data_arr_F2C01[j];
					for (int i = 0; i < level_F2C01 - 1; ++i) {
						_feat_id_data_F2C01.feat_ids[i] = owner_feat_id_data.feat_ids[i];
					}
					_feat_id_data_F2C01.feat_ids[level_F2C01 - 1] = p_feature->id;
					_feat_id_data_F2C01.level = level_F2C01;
					break;
				}
			}
			feat_id_data_arr_F2C01.push_back(_feat_id_data_F2C01);
		}

		wchar_t wFeatName[PRO_NAME_SIZE];
		char cFeatName[PRO_NAME_SIZE];
		ProModelitem modelItem;
		ProParameter pDesc;
		ProParamvalue pvDesc;
		ProName pDescName = L"DESCRIPTION";
		string                  description;
		//int ID = 0;
		//string str_hidden;

		status = ProMdlMdlnameGet(model, wFeatName);

		//ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
		ProWstringToString(cFeatName, wFeatName);

		status = ProMdlToModelitem(model, &modelItem);
		//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&modelItem, pDescName, &pDesc);
		//ruleLog.Write("ProParameterInit: " + to_string(status));

		if (status != PRO_TK_E_NOT_FOUND)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			//ruleLog.Write("ProParameterValueWithUnitsGet : " + to_string(status));

			ProWstringToString(existingPval, pvDesc.value.s_val);

			//ID_Map.push_back(p_feature->id);

			//ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval + "Feature ID = " + to_string(p_feature->id));
			exsitingPvalspacesRem = remSpacesAtBothEnds1(string(existingPval));
		}

		// for fastners
		description.append(exsitingPvalspacesRem);
		//ruleLog.Write(description);

		const regex p("(SCREW)");
		const regex q("(SCR)");
		const regex r("(BOLT)");
		const regex s("(NUT)");
		const regex t("(WELD)");

		if ((regex_search(description, p) != 0) || (regex_search(description, q) != 0) ||
			(regex_search(description, r) != 0) || ((regex_search(description, s) != 0) && (regex_search(description, t) == 0)))
		{
			ruleLog.Write(description);
			ProIdTable			comp_id_table{};
			int table_num;
			ProAsmcomppath		p_comp_path;
			int check = 0;

			table_num = level_F2C01;

			//ruleLog.Write("table_num =  " + to_string(table_num));
			pathVar.table_num_Vector.push_back(table_num);

			for (int m = 0; m < level_F2C01; ++m) {
				comp_id_table[m] = _feat_id_data_F2C01.feat_ids[m];
				//ruleLog.Write("comp_id_table[] =  " + to_string(m) + "  " + to_string(comp_id_table[m]));
				check++;
			}

			ruleLog.Write("comp_id_table[0] = " + to_string(comp_id_table[1]));
			ruleLog.Write("feature_id_F2C01 = " + to_string(feature_id_F2C01));

			if (comp_id_table[0] == feature_id_F2C01)
			{
				if (check == 2)
				{
					regex numberRegex("-(\\d+)");
					regex decimalRegex("\\b\\d+\\.\\d");
					smatch                    matchFound;
					string                    grade;
					double                    gradeInt;
					string::const_iterator searchStart(description.cbegin());
					if (regex_search(description, matchFound, decimalRegex))
					{
						grade = matchFound.str();
						//ruleLog.Write("check for decimal");

					}
					else if (regex_search(searchStart, description.cend(), matchFound, numberRegex))
					{
						grade = matchFound[1].str();
						//ruleLog.Write("check for number");
					}

					ProMdl curMdl;
					status = ProMdlCurrentGet(&curMdl);

					status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
					ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

					status = ProSelectionAlloc(&p_comp_path, &modelItem, &p_selection_fastners);
					ruleLog.Write("ProSelectionAlloc: " + to_string(status));
					ruleLog.Write("Part Name fastners= " + string(cFeatName));
					PartName_fastners = cFeatName;

					PartNameFastnerVector.push_back(PartName_fastners);
					p_selFastners.push_back(p_selection_fastners);
				}
			}
		}

		// for asm
		if (type == PRO_MDL_ASSEMBLY)
		{
			Assy_models[Assy_models_cnt_F2C01].Model = model;
			Assy_models[Assy_models_cnt_F2C01].Model_feat_id = p_feature->id;
			Assy_models_cnt_F2C01 += 1;
		}
	}
	return PRO_TK_NO_ERROR;

}

ProError mouting_bkt_fetch_F2C02(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("----------------------------- mouting_bkt_fetch_F2C02 -----------------------------");

	vector<PartnameDescriptionPair>* prtname_desc_list = (vector<PartnameDescriptionPair>*)app_data;

	ProMdl                  reqMdl;
	ProFeattype				ftype;
	wchar_t					wMdlName[PRO_NAME_SIZE];
	char					cMdlName[PRO_NAME_SIZE];
	string                  part_name;
	string                  tokenF2C02 = "F2C02";
	ProModelitem            modelItem;
	ProIdTable			    comp_id_table{};
	int feature_idF2C02;

	status = ProFeatureTypeGet(p_feature, &ftype);
	//ruleLog.Write("ProFeatureTypeGet status = " + to_string(status));

	feature_idF2C02 = p_feature->id;
	comp_id_table[0] = feature_idF2C02;

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	status = ProMdlMdlnameGet(reqMdl, wMdlName);
	ProWstringToString(cMdlName, wMdlName);
	part_name = cMdlName;

	if (part_name.find(tokenF2C02) != string::npos)
	{
		ProAsmcomppath path[1];

		status = ProMdlToModelitem(reqMdl, &modelItem);
		//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, 1, &path[0]);
		//ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

		status = ProSelectionAlloc(&path[0], &modelItem, &p_selection_bracket);
		ruleLog.Write("ProSelectionAlloc: " + to_string(status));

		p_selBracket.push_back(p_selection_bracket);

	}


	return PRO_TK_NO_ERROR;
}

ProError selectActionF2C01_013(char* dialog, char* component, ProAppData appD)
{
	ruleLog.Write("===============selectActionF2C01_013=================");

	ProModelitem part_model_item;
	ProName name;
	char str_name[PRO_NAME_SIZE];
	ProModelitem parent_model_item;
	ProParameter pDesc;
	ProParamvalue pvDesc;
	ProName pDescName = L"DESCRIPTION";
	string description;
	char existingPval[PRO_LINE_SIZE]{};

	status = ProSelect((char*)"prt_or_asm", 2, NULL, NULL, NULL, NULL, &selectionF2C01_013, &n_selectionF2C01_013);
	ruleLog.Write("Proselect status= " + to_string(status) + "\nNo.of Selection " + to_string(n_selectionF2C01_013));

	if (status == PRO_TK_NO_ERROR && n_selectionF2C01_013 == 2) {
		status = ProUIPushbuttonEnable(dialog, CommitOK);
	}

	for (int i = 0; i < n_selectionF2C01_013; i++)
	{
		status = ProSelectionModelitemGet(selectionF2C01_013[i], &part_model_item);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

		status = ProMdlMdlnameGet(part_model_item.owner, name);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

		ProWstringToString(str_name, name);
		ruleLog.Write("str_name = " + string(str_name));

		status = ProMdlToModelitem(part_model_item.owner, &parent_model_item);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&parent_model_item, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit status = " + to_string(status));
		if (status != PRO_TK_E_NOT_FOUND)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ruleLog.Write("ProParameterValueWithUnitsGet status = " + to_string(status));
			ProWstringToString(existingPval, pvDesc.value.s_val);
		}
		name_asmF2C01_013.push_back(str_name);

	}
	return PRO_TK_NO_ERROR;
}

string remSpacesAtBothEnds1(const string& str) {
	mainLog.Write("================= Utils::remSpacesAtBothEnds ==================");
	string strVal = str;
	if (str.empty())
		strVal;
	size_t start = strVal.find_first_not_of(" \t\n");
	if (start != string::npos) {
		strVal = strVal.substr(start);
	}
	size_t end = strVal.find_last_not_of(" \t\n");
	if (end != string::npos) {
		strVal = strVal.substr(0, end + 1);
	}
	return strVal;
}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2C01_016 	| Mathanprasath A	| MF2C01;MF5A16;MF5A15          | Ensure ≥ 20 mm clearance between propeller shaft and Brake chamber.
===================================================================================================================*/

ComponentData _reqCompsf2c01_016[2]{};
#define DLG_IRF2C01_016 "dlg_IR_F2C01_016"
#define PB_RCANCEL       "CommitCancel"
#define PB_ROK           "CommitOK"
#define Radio            "RadioGroup_1"
#define Select_M         "Select_1"

ProSelection* prt;
bool isManual_F2C01_016;
vector<string>  name_asmF2C01_16;
double clearance1, clearance2;
int IRF2C01::IRF2C01_016(ruleResult& final_res)
{
	final_res.result.clear();
	final_res.remark.clear();
	isManual_F2C01_016 = false;//If user does not select any then default radio button will be first button, and action related to that will be performed on clicking RUN
	isUserQuits = false;
	string reqCompSubMod[2] = { "F2C01","F5A15" };
	string comp_names[2];

	for (int i = 0; i < subModulesList.size(); ++i)
	{
		for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j)
		{
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
			{
				strcpy(_reqCompsf2c01_016[j].name, subModulesList[i].name.c_str());
				comp_names[j] = subModulesList[i].name;
			}
		}

	}

	status = ProUIDialogCreate(DLG_IRF2C01_016, DLG_IRF2C01_016);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2C01_016, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2C01_016, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2C01_016, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2C01_016, Select_M, (ProUIAction)select_action_IRF2C01_016, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));

	status = ProUIRadiogroupSelectActionSet(DLG_IRF2C01_016, Radio, (ProUIAction)rg_select_action_IRF2C01_016, NULL);
	ruleLog.Write("ProUIRadiogroupSelectActionSet status: " + to_string(status));
	status = ProUIDialogHide(DLG_IRC_MAIN);
	int radioGrpNames[2];
	char** buttonNames;

	//Radio button, selected for first button (default)
	status = ProUIRadiogroupSelectednamesGet(DLG_IRF2C01_016, Radio, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status main: " + to_string(status));
	ruleLog.Write("selected button name: " + (string)buttonNames[0]);


	status = ProUIDialogActivate(DLG_IRF2C01_016, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));


	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_IRF2C01_016);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}



	status = ProUIDialogDestroy(DLG_IRF2C01_016);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	ruleLog.Write("isManual_F2C01_016: " + to_string(isManual_F2C01_016));
	ProAnalysis** p_analyses;

	status = ProSolidAnalysisVisit((ProSolid)curMdl, (ProAnalysisVisitAction)ProUtilCollect3ParamOpaqueVisitAction,(ProAnalysisFilterAction)ProUtilDefaultFilter,(ProAppData)&p_analyses);
	ruleLog.Write("ProSolidAnalysisVisit = " + to_string(status));

	//manual selection
	if (isManual_F2C01_016 == 1)
	{
		ruleLog.Write("manual selection");
		ProBoolean is_interference_found;
		Pro3dPnt coord[2];
		status = ProFitClearanceCompute(prt[0], PRO_FIT_INCLUDE_NONE, prt[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearance1, NULL, &is_interference_found, coord);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));
		ruleLog.Write("clearance1 = " + to_string(clearance1));

		string act_clearance;
		act_clearance.append(doubleToString(clearance1));
		string psRemark;
		psRemark += "Measured Value:\nClerance between Brake chamber and Propeller Shaft";
		psRemark += "(" + string(name_asmF2C01_16.at(0)) + ".PRT and " + string(name_asmF2C01_16.at(1)) + ".PRT) ";
		psRemark += "= " + act_clearance + ".mm";
		psRemark += "\nAcceptance Criteria: The Standard clearance between propeller shaft and Brake chamber is >=20mm.";


		if (clearance1 >= 20)
		{
			final_res.result = "PASS";
		}

		else
		{
			final_res.result = "FAIL";
		}
		final_res.remark = psRemark;

	}

	//Automatic selection
	else
	{
		InterfaceRule _ir;
		_ir.deleteDatumPoint("distance_pnnt1");
		ruleLog.Write("Automatic Selection");

		status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqCompsf2c01_016);
		ruleLog.Write("ProSolidFeatVisit: " + to_string(status));


		for (auto elem : _reqCompsf2c01_016)
		{
			ruleLog.Write("_reqComps[].name = " + string(elem.name));
			ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
		}

		Pro3dPnt pnt_arr[2];
		_ir.measureDistanceBetweenComponents(_reqCompsf2c01_016[0], _reqCompsf2c01_016[1], clearance2);
		ruleLog.Write("measureDistanceBetweenComponents: " + to_string(status));

		/*int sta = createDatumPoints(pnt_arr, "CSYS_ASM_DEF", "Dist_highlght_pnt");
	ruleLog.Write("createDatumPoints: " + to_string(sta));*/
		string act_clearance;
		act_clearance.append(doubleToString(clearance2));
		string r_msg;
		r_msg += "Measured Value:\nClerance between " + string(_reqCompsf2c01_016[0].name) + ".ASM" + " and " + string(_reqCompsf2c01_016[1].name) + ".ASM" + " is " + act_clearance + "mm.\n";

		if (clearance2 >= 20)
		{
			final_res.result = "PASS";
			sprintf(remark, "\nAcceptance criteria:The Standard clearance between propeller shaft and Brake chamber is >=20mm.");
			final_res.remark = r_msg + remark;
		}
		else
		{
			final_res.result = "FAIL";
			sprintf(remark, "\nAcceptance criteria:The Standard clearance between propeller shaft and Brake chamber is >=20mm.");
			final_res.remark = r_msg + remark;
		}

	}
	
	name_asmF2C01_16.clear();
	return 0;
}

ProError ProUtilDefaultFilter()
{
	return (PRO_TK_NO_ERROR);
}


ProError ProUtilCollect3ParamOpaqueVisitAction(
	void* p_object,	/* In:	The opaque handle being visited */
	ProError	    status,	/* In:  The status returned by filter func */
	ProAppData	    app_data)	/* In:	In fact it's ProArray** */
{
	return (ProUtilCollect2ParamDBVisitAction((void*)&p_object, app_data));
}

ProError ProUtilCollect2ParamDBVisitAction(
	void* p_object,	/* In:	The pointer to the object being visited */
	ProAppData	    app_data)	/* In:	In fact it's ProArray** */
{
	ProError status;
	ProArray* p_array;

	p_array = (ProArray*)((void**)app_data)[0];
	status = ProArrayObjectAdd(p_array, PRO_VALUE_UNUSED, 1, p_object);
	return (status);
}

ProError select_action_IRF2C01_016(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF2C01_016 -----------------------------");

	ProModelitem part_model_item;
	ProName name;
	char str_name[PRO_NAME_SIZE];
	ProModelitem parent_model_item;
	ProParameter pDesc;
	ProParamvalue pvDesc;
	ProName pDescName = L"DESCRIPTION";
	string                  description;
	char existingPval[PRO_LINE_SIZE]{};

	InterfaceRule _irule;
	int n_sel;
	bool* quitAction = (bool*)data;

	status = ProSelect((char*)"part", 2, NULL, NULL, NULL, NULL, &prt, &n_sel);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_USER_ABORT)
	{
		status = ProUIPushbuttonDisable(DLG_IRF2C01_016, CommitOK);
		if (quitAction != NULL)
			*quitAction = true;
		return status;
	}
	if (n_sel < 2 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		if (quitAction != NULL)
			*quitAction = true;
		status = ProUIPushbuttonDisable(DLG_IRF2C01_016, CommitOK);
		return status;
	}


	if (status == PRO_TK_NO_ERROR && n_sel == 2) 
	{
		status = ProUIPushbuttonEnable(dialog, CommitOK);
	}

	for (int i = 0; i < n_sel; i++)
	{
		status = ProSelectionModelitemGet(prt[i], &part_model_item);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

		status = ProMdlMdlnameGet(part_model_item.owner, name);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

		ProWstringToString(str_name, name);
		ruleLog.Write("str_name = " + string(str_name));

		status = ProMdlToModelitem(part_model_item.owner, &parent_model_item);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&parent_model_item, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit status = " + to_string(status));
		if (status != PRO_TK_E_NOT_FOUND)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ruleLog.Write("ProParameterValueWithUnitsGet status = " + to_string(status));
			ProWstringToString(existingPval, pvDesc.value.s_val);
		}
		name_asmF2C01_16.push_back(str_name);

	}

	return status;
}

ProError rg_select_action_IRF2C01_016(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("============== radioGrpSelectAction ==============");
	int radioGrpNames[2];
	char** buttonNames;
	char selectedButton[PRO_NAME_SIZE];
	InterfaceRule iRule;
	//status = ProUIPushbuttonDisable(dialog, PB_OK);
	status = ProUIRadiogroupSelectednamesGet(dialog, component, radioGrpNames, &buttonNames);

	ruleLog.Write("ProUIRadiogroupSelectednamesGet status: " + to_string(status));

	//strcpy(selectedButton, buttonNames[0]);
	ruleLog.Write("selected button name: " + (string)buttonNames[0]);
	if (strcmp(buttonNames[0], "rb1") == 0)
	{
		isManual_F2C01_016 = false;
		ruleLog.Write("IsManual? : " + to_string(isManual_F2C01_016));
		status = ProUIPushbuttonEnable(dialog, CommitOK);
	}
	else
	{
		status = ProUIPushbuttonEnable(dialog, Select_M);
		status = ProUIPushbuttonDisable(dialog, CommitOK);
		isManual_F2C01_016 = true;
		ruleLog.Write("IsManual? : " + to_string(isManual_F2C01_016));
	}

	return status;
}

ProError ruleDlgOKaction_F2C01_016(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgOKaction -----------------------------");

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return PRO_TK_NO_ERROR;
}

ProError ruleDlgCloseAction_F2C01_016(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgCloseAction -----------------------------");

	if (data != NULL) {
		bool* quitAction = (bool*)data;
		*quitAction = true;
	}
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2C01_017 	| Pallavi Garodi	| MF2C01          | Target GB inclination to be with in ± 1 deg of RA inclination. Else, decision based on Performance evaluation.
===================================================================================================================*/

#define DLG_IR_F2C01_017   "dlg_IR_F2C01_017"
#define CommitOK		   "CommitOK"
#define CommitCancel	   "CommitCancel"
#define Select_pb		   "select_pb"

ProSelection* sel_axis1;
ProSelection axis_sel_1, axis_sel_2;
int n_sels_017;
double Angle_1, Angle_2;
ProMdl p_handle1;
ProName name_1, name_2, name_3, axis_name_1, axis_name_2;
ProSelection sel_1, sel_2, sel_3;
ProModelitem p_item_1, p_item_2, p_item_3, axis_item_1, axis_item_2;
float Deviated1, abs_Deviated1;

//bool result1 = NULL;

int IRF2C01::IRF2C01_017(ruleResult& final_res)
{
	ruleLog.Write("========================== IRF2C01::IRF2C01_017========================");
	ProCharPath Parents_info{};
	for (int i = 0; i < subModulesList.size(); ++i)
	{
		if (subModulesList[i].name.find("F2C01") != std::string::npos)
		{
			_reqSMinfo = subModulesList[i];
			break;
		}

	}
	bool isSelectionRight = NULL;
	ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
	msg_buttons[0] = PRO_UI_MESSAGE_YES;
	msg_buttons[1] = PRO_UI_MESSAGE_NO;
	user_choice = _utils.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation", "Is interaxle rule applicable to this submodule?", msg_buttons);
	ruleLog.Write("userchoice: " + to_string(user_choice));
	if (user_choice == msg_buttons[0])
		isSelectionRight = false;	//user confirmed
	else if (user_choice == msg_buttons[1])
		isSelectionRight = true;	//user doesn't confirm
	else if (user_choice == PRO_TK_USER_ABORT)
		return status;

	if (isSelectionRight == true)
	{
		final_res.result = "PASS";
		string rem_message = "Interaxle rule is not applicable to this submodule ";
		final_res.remark = (rem_message);
		return status;
	}

	ProArrayFree((ProArray*)&msg_buttons);

	status = ProMdlCurrentGet(&p_handle1);
	ruleLog.Write("ProMdlcurrentGet = " + to_string(status));

	ProStringToWstring(name_1, "ASM_XY");
	status = ProModelitemByNameInit(p_handle1, PRO_SURFACE, name_1, &p_item_1);
	ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

	status = ProSelectionAlloc(NULL, &p_item_1, &sel_1);
	ruleLog.Write("ProSelectionAlloc 1= " + to_string(status));
	ruleLog.Write("Selected plane:ASM_XY");
	bool nomencltre_found = NULL;

	ruleLog.Write("5-----------------------------");
	isUserQuits = false;
	ruleLog.Write("6-----------------------------");
	status = ProUIDialogCreate(DLG_IR_F2C01_017, DLG_IR_F2C01_017);
	ruleLog.Write("UI status = " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IR_F2C01_017, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet = " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IR_F2C01_017, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet1 = " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IR_F2C01_017, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet 2= " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IR_F2C01_017, Select_pb, (ProUIAction)selection_action_IRF2C01_017, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet 3 = " + to_string(status));
	ruleLog.Write("8-----------------------------");

	/*if (nomencltre_found == false)
	{
		ruleLog.Write("9-----------------------------");
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "INFO", "AXIS_END1 & AXIS_END2 is not found. Create the axis as mentioned else click Select button in the UI to Proceed Manual selection.");
		ruleLog.Write("ProUIMessageDialogDisplay: " + to_string(status));

	}*/
	ruleLog.Write("7-----------------------------");
	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IR_F2C01_017, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IR_F2C01_017);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	/*if (n_sels == 2)
	{
		status = ProUIPushbuttonEnable(DLG_IR_F2C01_011, CommitOK);

		status = ProSelectionModelitemGet(sel_axis[0], &axisitem1);
		status = ProSelectionModelitemGet(sel_axis[1], &axisietm2);

		status = ProGeomitemFeatureGet((ProGeomitem*)&axisitem1, &axis_featid1);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id1 = " + to_string(axis_featid1.id));

		status = ProGeomitemFeatureGet((ProGeomitem*)&axisietm2, &axis_featid2);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id2 = " + to_string(axis_featid2.id));


		status = ProModelitemMdlGet(&axisitem1, &axis_mdlmdl1);
		status = ProModelitemMdlGet(&axisietm2, &axis_mdlmdl2);

		status = ProMdlMdlnameGet(axis_mdlmdl1, waxsmdlName1);
		ProWstringToString(caxsmdlName1, waxsmdlName1);
		ruleLog.Write("Axis model Name :" + string(caxsmdlName1));
		status = ProMdlMdlnameGet(axis_mdlmdl2, waxsmdlName2);
		ProWstringToString(caxsmdlName2, waxsmdlName2);
		ruleLog.Write("Axis model Name :" + string(caxsmdlName2));

		char tempAxs2Name[PRO_NAME_SIZE] = "TEMP_AXIS2";
		int iOut = createTangentDatumAxisWithReference(sel_axis[0], "A_2", tempAxs2Name);
		ruleLog.Write("createTangentDatumAxisWithReference = " + to_string(status));

		ProStringToWstring(name3, "TEMP_AXIS2");
		status = ProModelitemByNameInit(p_handle, PRO_AXIS, name3, &p_item3);
		ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

		status = ProSelectionAlloc(NULL, &p_item3, &sel3);
		ruleLog.Write("ProSelectionAlloc2 = " + to_string(status));

		status = measureAngleBetweenSurfaceAndAxis(sel1, sel3, Angle1);
		ruleLog.Write("Angle1: " + to_string(Angle1));

		char tempAxs1Name[PRO_NAME_SIZE] = "TEMP_AXIS1";
		int Out = createTangentDatumAxisWithReference(sel_axis[1], "A_1", tempAxs1Name);
		ruleLog.Write("createTangentDatumAxisWithReference = " + to_string(status));

		ProStringToWstring(name2, "TEMP_AXIS1");
		status = ProModelitemByNameInit(p_handle, PRO_AXIS, name2, &p_item2);
		ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

		status = ProSelectionAlloc(NULL, &p_item2, &sel2);
		ruleLog.Write("ProSelectionAlloc2 = " + to_string(status));

		status = measureAngleBetweenSurfaceAndAxis(sel1, sel2, Angle2);
		ruleLog.Write("Angle2: " + to_string(Angle2));

		int del = deleteDatumAxis(tempAxs1Name);
		ruleLog.Write("deleteDatumAxis = " + to_string(status));

		int del2 = deleteDatumAxis(tempAxs2Name);
		ruleLog.Write("deleteDatumAxis = " + to_string(status));
	}*/
	/*float Deviated;
	Deviated = Angle1 - Angle2;
	if (Deviated < 0) {
		Deviated = std::abs(Deviated);
		ruleLog.Write("abs Deviated: " + to_string(Deviated));
	}
	else {
		ruleLog.Write("Deviated: " + to_string(Deviated));
	}

	char in[50];
	if (Angle1 >= Angle2 - 1.0 && Angle1 <= Angle2 + 1.0)
	{
		final_res.result = "PASS";
		sprintf(remark, "Measured Value :RA inclination is in ± 1 deg of AGB inclination. ;\nAcceptance criteria:Target RA inclination to be with in ± 1 deg of GB inclination");
		sprintf(Parents_info, "\nAxis_id 1: %d, Partnumber: %s.\nAixs_id 2: %d, Partnumber: %s.", axis_featid1.id, caxsmdlName1, axis_featid2.id, caxsmdlName2);
		final_res.remark = string(remark) + Parents_info;
	}
	else
	{
		final_res.result = "FAIL";
		sprintf(remark, "Measured Value :RA inclination is %0.2f deg of AGB inclination.;\nAcceptance criteria:Target RA inclination to be with in ± 1 deg of GB inclination.", Deviated);
		sprintf(Parents_info, "\nAxis_id 1: %d, Partnumber: %s.\nAixs_id 2: %d, Partnumber: %s.", axis_featid1.id, caxsmdlName1, axis_featid2.id, caxsmdlName2);
		final_res.remark = string(remark) + Parents_info;
	}*/


	if (n_sels_017 == 2)
	{
		status = ProUIPushbuttonEnable(DLG_IR_F2C01_017, CommitOK);
		int id1, id2;
		ProModelitem axis1, axis2;
		ProFeature axis_feat1, axis_feat2;
		status = ProSelectionModelitemGet(sel_axis1[0], &axis1);
		status = ProSelectionModelitemGet(sel_axis1[1], &axis2);

		status = ProGeomitemFeatureGet((ProGeomitem*)&axis1, &axis_feat1);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id1 = " + to_string(axis_feat1.id));

		status = ProGeomitemFeatureGet((ProGeomitem*)&axis2, &axis_feat2);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\naxis_feat.id2 = " + to_string(axis_feat2.id));

		ProMdl axis_mdl1, axis_mdl2;
		status = ProModelitemMdlGet(&axis1, &axis_mdl1);
		status = ProModelitemMdlGet(&axis2, &axis_mdl2);
		wchar_t waxsMdlName1[PRO_NAME_SIZE];
		char caxsMdlName1[PRO_NAME_SIZE];
		wchar_t waxsMdlName2[PRO_NAME_SIZE];
		char caxsMdlName2[PRO_NAME_SIZE];
		status = ProMdlMdlnameGet(axis_mdl1, waxsMdlName1);
		ProWstringToString(caxsMdlName1, waxsMdlName1);
		ruleLog.Write("Axis model Name :" + string(caxsMdlName1));
		status = ProMdlMdlnameGet(axis_mdl2, waxsMdlName2);
		ProWstringToString(caxsMdlName2, waxsMdlName2);
		ruleLog.Write("Axis model Name :" + string(caxsMdlName2));

		/*status = ProAxisIdGet(ProAxis(sel_axis[0]), &id1);
		ruleLog.Write("ProAxisIdGet 1= " + to_string(status));
		ruleLog.Write("Axis 1 ID :" + id1);

		status = ProAxisIdGet(ProAxis(sel_axis[0]), &id2);
		ruleLog.Write("ProAxisIdGet 2= " + to_string(status));
		ruleLog.Write("Axis 2 ID :" + id2)*/;

		char tempAxs2Name[PRO_NAME_SIZE] = "TEMP_AXIS2";
		int iOut = createTangentDatumAxisWithReference(sel_axis1[0], "AXIS_END1", tempAxs2Name);
		ruleLog.Write("createTangentDatumAxisWithReference = " + to_string(status));

		ProStringToWstring(name_3, "TEMP_AXIS2");
		status = ProModelitemByNameInit(p_handle1, PRO_AXIS, name_3, &p_item_3);
		ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

		status = ProSelectionAlloc(NULL, &p_item_3, &sel_3);
		ruleLog.Write("ProSelectionAlloc2 = " + to_string(status));

		status = measureAngleBetweenSurfaceAndAxis(sel_1, sel_3, Angle_1);
		ruleLog.Write("Angle1: " + to_string(Angle_1));

		char tempAxs1Name[PRO_NAME_SIZE] = "TEMP_AXIS1";
		int Out = createTangentDatumAxisWithReference(sel_axis1[1], "AXIS_END2", tempAxs1Name);
		ruleLog.Write("createTangentDatumAxisWithReference = " + to_string(status));

		ProStringToWstring(name_2, "TEMP_AXIS1");
		status = ProModelitemByNameInit(p_handle1, PRO_AXIS, name_2, &p_item_2);
		ruleLog.Write("ProModelitemByNameInit = " + to_string(status));

		status = ProSelectionAlloc(NULL, &p_item_2, &sel_2);
		ruleLog.Write("ProSelectionAlloc2 = " + to_string(status));

		status = measureAngleBetweenSurfaceAndAxis(sel_1, sel_2, Angle_2);
		ruleLog.Write("Angle2: " + to_string(Angle_2));

		int del = deleteDatumAxis(tempAxs1Name);
		ruleLog.Write("deleteDatumAxis = " + to_string(status));

		int del2 = deleteDatumAxis(tempAxs2Name);
		ruleLog.Write("deleteDatumAxis = " + to_string(status));


		Deviated1 = Angle_1 - Angle_2;
		ruleLog.Write("DEVIATION :" + to_string(Deviated1));
		if (Deviated1 < 0)
		{
			abs_Deviated1 = std::abs(Deviated1);
			ruleLog.Write("abs Deviated: " + to_string(Deviated1));
		}
		else
		{
			abs_Deviated1 = Deviated1;
			ruleLog.Write("Deviated: " + to_string(abs_Deviated1));
		}

		char in[50];
		if (abs_Deviated1 >= -1.0 && abs_Deviated1 <= +1.0)
		{
			final_res.result = "PASS";
			sprintf(remark, "Measured Value :RA inclination is in %0.1f deg of GB inclination. ; Acceptance criteria:Target RA inclination to be with in ± 1 deg of GB inclination", abs_Deviated1);
			sprintf(Parents_info, "\nAxis_id 1: %d, Partnumber: %s.\nAixs_id 2: %d, Partnumber: %s.", axis_feat1.id, caxsMdlName1, axis_feat2.id, caxsMdlName2);
			final_res.remark = string(remark) + Parents_info;
		}
		else
		{
			final_res.result = "FAIL";
			sprintf(remark, "Measured Value :RA inclination is %0.1f deg of GB inclination.; Acceptance criteria:Target RA inclination to be with in ± 1 deg of GB inclination.", abs_Deviated1);
			sprintf(Parents_info, "\nAxis_id 1: %d, Partnumber:%s.\nAixs_id 2: %d, Partnumber:%s.", axis_feat1.id, caxsMdlName1, axis_feat2.id, caxsMdlName2);
			final_res.remark = string(remark) + Parents_info;
		}
	}
	if (isUserQuits)
		return -1;


	return 0;

}

ProError selection_action_IRF2C01_017(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF2C01_008 -----------------------------");

	int rule_sts;
	InterfaceRule _irule;
	bool* quitAction = (bool*)data;

	status = ProSelect((char*)"axis", 2, NULL, NULL, NULL, NULL, &sel_axis1, &n_sels_017);
	ruleLog.Write("ProSelect = " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_IR_F2C01_017, CommitOK);
		if (quitAction != NULL)
			*quitAction = true;
		return status;
	}

	else if (n_sels_017 < 2 || status != PRO_TK_NO_ERROR) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		if (quitAction != NULL)
			*quitAction = true;
		status = ProUIPushbuttonDisable(DLG_IR_F2C01_017, CommitOK);
		return status;
	}

	status = ProUIPushbuttonEnable(DLG_IR_F2C01_017, CommitOK);

	/*if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_IR_F2C01_008, CommitOK);
		if (quitAction != NULL)
			*quitAction = true;
		return status;
	}

	else if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		if (quitAction != NULL)
			*quitAction = true;
		status = ProUIPushbuttonDisable(DLG_IR_F2C01_008, CommitOK);
		return status;
	}*/


	//int(status)=0

	return status;

}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2C01019		| Prajakta Bhelawe	| MF2C01; MF2D04	|  Minimum 40 mm clearance to be ensured between lift axle main bellow and propeller shaft for fully pressured bellow diameter.
===================================================================================================================*/

#define DLG_F2C01_019	    "dlg_IR_F2C01_019" 
#define PR_CANCEL           "CommitCancel" 
#define CommitOK            "CommitOK"
#define RB_Grp1				"RadioGroup1"
#define Label2				"Label2"
#define Select1				"Select1"

vector<PartnameDescriptionPairF2C01>	reqCompsF2C01_019;
ProSelection selPropShaft, selMainBellow, copyselPropShaftSel, copymainBellowPrtSel;
string propShaftName, mainBellowName, propShaftNameManual, mainBellowNameManual;
vector<string>  name_asmF2C01_019;
ProSelection* selectionF2C01_019 = nullptr;
int n_selectionF2C01_019;

int IRF2C01::IRF2C01_019(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2C01::IRF2C01_019   ==========================");

	deleteDatumPoint("distance_pnnt1");

	reqCompsF2C01_019.clear();
	final_res.result.clear();
	final_res.remark.clear();
	name_asmF2C01_019.clear();
	mainBellowNameManual.clear();
	propShaftNameManual.clear();

	double clearance1 = 0;
	isManual = NULL;
	string psRemark;

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_F2C01_019, DLG_F2C01_019);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_F2C01_019, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F2C01_019, PR_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F2C01_019, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUILabelHide(DLG_F2C01_019, Label2);
	ruleLog.Write("ProUILabelHide status: " + to_string(status));
	status = ProUIPushbuttonHide(DLG_F2C01_019, Select1);
	ruleLog.Write("ProUIPushbuttonHide status: " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_F2C01_019, Select1, (ProUIAction)selectActionF2C01_019, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));

	status = ProUIRadiogroupSelectActionSet(DLG_F2C01_019, RB_Grp1, (ProUIAction)radioGrpSelectAction, NULL);
	ruleLog.Write("ProUIRadiogroupSelectActionSet status: " + to_string(status));
	status = ProUIDialogHide(DLG_IRC_MAIN);
	int radioGrpNames[2];
	char** buttonNames;

	//Radio button, selected for first button (default)
	status = ProUIRadiogroupSelectednamesGet(DLG_F2C01_019, RB_Grp1, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status main: " + to_string(status));
	ruleLog.Write("selected button name: " + (string)buttonNames[0]);

	if (buttonNames[0] == "rb1")       //If user does not select any then default radio button will be first button, 
										//and action related to that will be performed on clicking Ok								
	{
		isManual = false;
	}

	status = ProUIDialogActivate(DLG_F2C01_019, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_F2C01_019);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	status = ProUIDialogDestroy(DLG_F2C01_019);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	Pro2dPnt param_1, param_2;
	Pro3dPnt pnt_1, pnt_2;


	//Automatic verification
	if (isManual == false)
	{
		deleteDatumPoint("distance_pnnt1");
		ruleLog.Write("Automatic Selection");

		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Attention!!", "It may take a moment to measure the clearance between two components.");

		status = ProSolidFeatVisit((ProSolid)curMdl, getParameterDescAndPartnameF2C01, compsFilter, (ProAppData)&reqCompsF2C01_019);
		ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

		status = ProFitClearanceCompute(copyselPropShaftSel, PRO_FIT_INCLUDE_NONE, copymainBellowPrtSel, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearance1, NULL, &is_interference_found, coord);
		ruleLog.Write("distance1 = " + to_string(clearance1));

		if (clearance1 >= 40)
		{
			sprintf(remark, "Clearance between Lift axle main bellow and Propeller Shaft \n(%s.ASM and %s.ASM) = %.2fmm. \n\nAcceptance Criteria: Clearance between Lift axle main bellow and Propeller Shaft should be minimum 40.00mm", mainBellowName, propShaftName, clearance1);
			final_res.remark = string(remark);
			final_res.result = "PASS";
		}

		else
		{
			sprintf(remark, "Clearance between Lift axle main bellow and Propeller Shaft \n(%s.ASM and %s.ASM) = %.2fmm. \n\nAcceptance Criteria: Clearance between Lift axle main bellow and Propeller Shaft should be minimum 40.00mm", mainBellowName, propShaftName, clearance1);
			final_res.remark = string(remark);
			final_res.result = "FAIL";
		}
	}

	else // manual selection of surfaces
	{
		deleteDatumPoint("distance_pnnt1");
		if (n_selectionF2C01_019 < 2)
		{
			UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			return -1;
		}
		else
		{
			ruleLog.Write("manual selection");

			status = ProFitClearanceCompute(selectionF2C01_019[0], PRO_FIT_INCLUDE_NONE, selectionF2C01_019[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearance1, NULL, &is_interference_found, coord);
			ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));
			ruleLog.Write("clearance1 = " + to_string(clearance1));

			string strclearance1 = to_string(clearance1);
			string result;
			size_t dotPos = strclearance1.find('.');

			if (dotPos != std::string::npos) {
				// Check if there are at least two characters after the decimal point
				if (dotPos + 3 <= strclearance1.size()) {
					result = strclearance1.substr(0, dotPos + 3);  // Include the dot and two characters after
				}
				else {
					// Less than two characters after the decimal point
					result = strclearance1.substr(0, dotPos + 1);  // Include only up to the decimal point
				}
			}
			else {
				// No decimal point found
				result = strclearance1;
			}

			ruleLog.Write("result " + (result));

			mainBellowNameManual = name_asmF2C01_019[0];
			propShaftNameManual = name_asmF2C01_019[1];

			ruleLog.Write("mainBellowNameManual = " + mainBellowNameManual);
			ruleLog.Write("propShaftNameManual = " + propShaftNameManual);

			psRemark += "Clearance between Lift axle main bellow and Propeller Shaft\n";
			psRemark += "(" + string(mainBellowNameManual) + ".PRT and " + string(propShaftNameManual) + ".PRT) ";
			psRemark += "= " + to_string(clearance1) + ".mm";
			psRemark += "\n\nAcceptance Criteria: Clearance between Lift axle main bellow and Propeller Shaft should be minimum 40.00mm";

			if (clearance1 >= 40)
			{
				final_res.result = "PASS";
			}
			else
			{
				final_res.result = "FAIL";
			}
			final_res.remark = psRemark;
		}
	}
	createDatumPoints(coord, "CSYS_ASM_DEF", "distance_pnnt1");

	name_asmF2C01_019.clear();
	mainBellowName.empty();;
	propShaftName.empty();
	psRemark.clear();

	return 0;
}

ProError selectActionF2C01_019(char* dialog, char* component, ProAppData appD)
{
	ruleLog.Write("===============selectActionF2C02=================");

	ProModelitem part_model_item;
	ProName name;
	char str_name[PRO_NAME_SIZE];
	ProModelitem parent_model_item;
	ProParameter pDesc;
	ProParamvalue pvDesc;
	ProName pDescName = L"DESCRIPTION";
	string description;
	char existingPval[PRO_LINE_SIZE]{};

	status = ProSelect((char*)"prt_or_asm", 2, NULL, NULL, NULL, NULL, &selectionF2C01_019, &n_selectionF2C01_019);
	ruleLog.Write("Proselect status= " + to_string(status) + "\nNo.of Selection " + to_string(n_selectionF2C01_019));

	if (status == PRO_TK_NO_ERROR && n_selectionF2C01_019 == 2) {
		status = ProUIPushbuttonEnable(dialog, CommitOK);
	}

	for (int i = 0; i < n_selectionF2C01_019; i++)
	{
		status = ProSelectionModelitemGet(selectionF2C01_019[i], &part_model_item);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

		status = ProMdlMdlnameGet(part_model_item.owner, name);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

		ProWstringToString(str_name, name);
		ruleLog.Write("str_name = " + string(str_name));

		status = ProMdlToModelitem(part_model_item.owner, &parent_model_item);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&parent_model_item, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit status = " + to_string(status));
		if (status != PRO_TK_E_NOT_FOUND)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ruleLog.Write("ProParameterValueWithUnitsGet status = " + to_string(status));
			ProWstringToString(existingPval, pvDesc.value.s_val);
		}
		name_asmF2C01_019.push_back(str_name);

	}
	return PRO_TK_NO_ERROR;
}

ProError radioGrpSelectAction(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("============== radioGrpSelectAction ==============");
	int radioGrpNames[2];
	char** buttonNames;
	char selectedButton[PRO_NAME_SIZE];
	InterfaceRule iRule;

	status = ProUIRadiogroupSelectednamesGet(dialog, component, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status: " + to_string(status));

	ruleLog.Write("selected button name: " + (string)buttonNames[0]);
	if (strcmp(buttonNames[0], "rb1") == 0)
	{
		status = ProUILabelHide(dialog, Label2);
		status = ProUIPushbuttonHide(dialog, Select1);

		isManual = false;
		ruleLog.Write("IsManual? : " + to_string(isManual));
		status = ProUIPushbuttonEnable(dialog, CommitOK);
	}
	else
	{
		status = ProUILabelShow(dialog, Label2);
		status = ProUIPushbuttonShow(dialog, Select1);

		status = ProUIPushbuttonDisable(dialog, CommitOK);
		isManual = true;
		ruleLog.Write("IsManual? : " + to_string(isManual));
	}

	return PRO_TK_NO_ERROR;
}

ProError getParameterDescAndPartnameF2C01(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("----------------------------- getParameterDescAndPartname -----------------------------");

	vector<PartnameDescriptionPair>* prtname_desc_list = (vector<PartnameDescriptionPair>*)app_data;

	ProMdlType subModuleMdlType;
	ProModelitem modelItem;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ProMdl reqMdl;
	char existingPval[PRO_NAME_SIZE]{};
	PartnameDescriptionPair compd{};

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
	status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
	ruleLog.Write("ProMdlTypeGet: " + to_string(status));
	status = ProMdlMdlnameGet(reqMdl, wFeatName);
	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(cFeatName, wFeatName);
	status = ProMdlToModelitem(reqMdl, &modelItem);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProParameter pDesc;
	ProParamvalue pvDesc;
	ProName pDescName = L"DESCRIPTION";
	string tokenF2C01 = "F2C01";
	string tokenF2D04 = "F2D04";
	ProSolid assembly;

	status = ProParameterInit(&modelItem, pDescName, &pDesc);
	ruleLog.Write("ProParameterInit: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)
	{
		status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
		ProWstringToString(existingPval, pvDesc.value.s_val);
		ruleLog.Write(cFeatName);
		string cFeatNameStr = cFeatName;

		ProIdTable memb_id_tab;
		memb_id_tab[0] = p_feature->id;
		ProAsmcomppath p_comp_path;

		ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);

		const regex p("(PROPELLER)");
		const regex q("(SHAFT)");
		if (cFeatNameStr.find(tokenF2C01) != string::npos && (regex_search(existingPval, p) != 0) && (regex_search(existingPval, q) != 0))
		{
			strcpy(compd.part_name, cFeatName);
			ruleLog.Write("compd.part_name: " + string(compd.part_name));

			propShaftName = cFeatName;

			strcpy(compd.description, existingPval);
			ruleLog.Write("compd.description" + string(compd.description));

			ProMdl curMdl;
			status = ProMdlCurrentGet(&curMdl);

			status = ProAsmcomppathInit((ProSolid)curMdl, memb_id_tab, 1, &p_comp_path);
			//ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

			status = ProSelectionAlloc(&p_comp_path, &modelItem, &selPropShaft);
			ruleLog.Write("ProSelectionAlloc: " + to_string(status));

			status = ProSelectionCopy(selPropShaft, &copyselPropShaftSel);
			ruleLog.Write("ProSelectionCopy ps = " + to_string(status));

			status = ProSelectionHighlight(copyselPropShaftSel, PRO_COLOR_SHEETMETAL);
			ruleLog.Write("ProSelectionHighlight: " + to_string(status));
		}

		const regex r("(MAIN)");
		const regex s("(BELLOW)");
		if (cFeatNameStr.find(tokenF2D04) != string::npos && (regex_search(existingPval, r) != 0) && (regex_search(existingPval, s) != 0))
		{
			strcpy(compd.part_name, cFeatName);
			ruleLog.Write("compd.part_name: " + string(compd.part_name));

			mainBellowName = cFeatName;

			strcpy(compd.description, existingPval);
			ruleLog.Write("compd.description" + string(compd.description));

			ProMdl curMdl;
			status = ProMdlCurrentGet(&curMdl);

			status = ProAsmcomppathInit((ProSolid)curMdl, memb_id_tab, 1, &p_comp_path);

			status = ProSelectionAlloc(&p_comp_path, &modelItem, &selMainBellow);
			ruleLog.Write("ProSelectionAlloc: " + to_string(status));

			status = ProSelectionCopy(selMainBellow, &copymainBellowPrtSel);
			ruleLog.Write("ProSelectionCopy ps = " + to_string(status));

			status = ProSelectionHighlight(copymainBellowPrtSel, PRO_COLOR_SHEETMETAL);
			ruleLog.Write("ProSelectionHighlight: " + to_string(status));
		}
	}
	prtname_desc_list->push_back(compd);
	return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER				| DEPENDENT MODULES		| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F2C01-020	| Himanshu Pachpute		| MF2C01; MF3B03		|  Minimum 40mm clearance to be ensured with propeller shaft and EGP/ATS.
===================================================================================================================*/

#define DLG_IRF2C01_020     "dlg_IR_F2C01_020"
#define PB_RCLOSE           "CommitCancel"
#define PB_ROK              "CommitOK"
#define RB_GRP			    "RadioGroup1"
#define LABEL1				"Label2"
#define SELECT_PB			"Select_PB"
#define LABEL2				"Label4"
#define MEASURE_PB			"Measure_PB"


struct ComponentData_IR_F2C01_020 {
	char name[PRO_PATH_SIZE];
	char desc[PRO_PATH_SIZE];
	int  id{};
};

ComponentData_IR_F2C01_020      reqComps_IR_F2C01_020[2]{};
string                          ComputedDist_IR_F2C01_020{};
double                          distance_IR_F2C01_020;
bool                            ManualCheck = false;

bool is_alphanumeric_and_space_IR_F2C01_020(const std::string& str) {
	for (char c : str) {
		if (!isalnum(c) && !isspace(c) && c != '-' && c != '.' && c != 'X') {
			return false;
		}
	}
	return true;
}

int IRF2C01::IRF2C01_020(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2C01::IRF2C01_020   ==========================");

	string reqCompSubMod[2] = { "F2C01", "F3B03" };
	isUserQuits = false;

	for (int i = 0; i < subModulesList.size(); ++i) {
		for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j) {
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
				strcpy(reqComps_IR_F2C01_020[j].name, subModulesList[i].name.c_str());
		}
	}

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId_IR_F2C01_020, compsFilter_IR_F2C01_020, (ProAppData)&reqComps_IR_F2C01_020);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

	for (size_t m = 0; m < 2; m++) {
		ruleLog.Write("reqComps[].name = " + string(reqComps_IR_F2C01_020[m].name));
		ruleLog.Write("reqComps[].id = " + to_string(reqComps_IR_F2C01_020[m].id));
		ruleLog.Write("reqComps[].desc = " + string(reqComps_IR_F2C01_020[m].desc));
	}

	status = ProUIDialogCreate(DLG_IRF2C01_020, DLG_IRF2C01_020);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2C01_020, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2C01_020, PB_RCLOSE, (ProUIAction)ruleDlgCloseAction_IR_F2C01_020, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2C01_020, PB_ROK, (ProUIAction)ruleDlgOKaction_IR_F2C01_020, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2C01_020, MEASURE_PB, (ProUIAction)measure_action_IR_F2C01_020, NULL);
	status = ProUIRadiogroupSelectActionSet(DLG_IRF2C01_020, RB_GRP, (ProUIAction)radioGrpSelectAction_F2C01_020, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2C01_020, SELECT_PB, (ProUIAction)selectaction_F2C01_020, NULL);
	status = ProUILabelHide(DLG_IRF2C01_020, LABEL2);
	status = ProUIPushbuttonHide(DLG_IRF2C01_020, MEASURE_PB);
	status = ProUIPushbuttonDisable(DLG_IRF2C01_020, PB_ROK);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2C01_020, &dlg_sts);
	status = ProUIDialogDestroy(DLG_IRF2C01_020);
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	ostringstream stream{};
	stream << fixed << setprecision(2) << distance_IR_F2C01_020;
	ComputedDist_IR_F2C01_020 += "Clearance between " + string(reqComps_IR_F2C01_020[0].name) + " [" + string(reqComps_IR_F2C01_020[0].desc) + "] [Feat ID: " + to_string(reqComps_IR_F2C01_020[0].id) + "] and\n " +
		string(reqComps_IR_F2C01_020[1].name) + " [" + string(reqComps_IR_F2C01_020[1].desc) + "] [Feat ID: " + to_string(reqComps_IR_F2C01_020[1].id) + "]: " + stream.str() + "mm" +
		"\n\nAcceptance criteria : \n\tClearance between MF2C01(PROPELLER SHAFT ASSY) and MF3B03(EGP,ATS & PROTECTIVE SHIELD KIT) needs to be >=40mm.";

	if (distance_IR_F2C01_020 >= 40)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	final_res.remark = ComputedDist_IR_F2C01_020;

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	memset(reqComps_IR_F2C01_020, 0, sizeof(reqComps_IR_F2C01_020));
	ComputedDist_IR_F2C01_020.clear();
	return 0;
}

ProError selectaction_F2C01_020(char* dialog, char* component, ProAppData appD)
{
	ruleLog.Write("----------------------------- selectaction_F2C01_020 -----------------------------");

	deleteDatumPointCreatedUsingCsys_IR_F2C01_020("datum_PNT1");
	deleteDatumPointCreatedUsingCsys_IR_F2C01_020("datum_PNT2");

	status = ProUIDialogHide(dialog);
	memset(reqComps_IR_F2C01_020, 0, sizeof(reqComps_IR_F2C01_020));

	ProSelection* compSelection = nullptr;
	int  curWinId{}, n_sel{};

	status = ProWindowCurrentGet(&curWinId);
	status = ProWindowRepaint(curWinId);

	status = ProSelect((char*)"prt_or_asm", 2, NULL, NULL, NULL, NULL, &compSelection, &n_sel);
	ruleLog.Write("Proselect: " + to_string(status) + "\tNo.of Selection " + to_string(n_sel));

	for (int i = 0; i < n_sel; i++)
	{
		int                         lastCompID = -1;
		ProAsmcomppath              asm_comp_path{};
		ComponentData_IR_F2C01_020  CompData{};
		ProModelitem                part_model_item{};
		ProName                     name{};
		ProParameter                pDesc{};
		ProParamvalue               pvDesc{};
		char                        Desc[PRO_PATH_SIZE]{};
		char                        NotFound[PRO_PATH_SIZE] = { "Error! Description not found." };

		status = ProSelectionModelitemGet(compSelection[i], &part_model_item);
		status = ProMdlMdlnameGet(part_model_item.owner, name);
		ProWstringToString(CompData.name, name);
		ruleLog.Write("CompData.name:" + string(CompData.name));
		status = ProSelectionAsmcomppathGet(compSelection[i], &asm_comp_path);
		for (int k = 0; k < asm_comp_path.table_num; ++k)
			lastCompID = asm_comp_path.comp_id_table[k];

		status = ProParameterInit(&part_model_item, L"DESCRIPTION", &pDesc);
		status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
		ProWstringToString(Desc, pvDesc.value.s_val);
		is_alphanumeric_and_space_IR_F2C01_020(Desc) ? strcpy(CompData.desc, Desc) : strcpy(CompData.desc, NotFound);
		CompData.id = lastCompID;
		reqComps_IR_F2C01_020[i] = CompData;
		ruleLog.Write("reqComps_IR_F2C01_020[i].id: " + to_string(reqComps_IR_F2C01_020[i].id) + "\treqComps_IR_F2C01_020[i].name: " + string(reqComps_IR_F2C01_020[i].name) + "\t reqComps_IR_F2C01_020[i].desc: " + string(reqComps_IR_F2C01_020[i].desc));
	}

	ProBoolean  interf{};
	Pro3dPnt    coord[2]{};
	status = ProFitClearanceCompute(compSelection[0], PRO_FIT_INCLUDE_NONE, compSelection[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance_IR_F2C01_020, NULL, &interf, coord);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance_IR_F2C01_020));

	createDatumPointsusingCSYS_IR_F2C01_020(coord, "CSYS_ASM_DEF");

	//ProUvParam param1, param2;
	//Pro3dPnt point1, point2;
	//double distance;
	//status = ProSelectionWithOptionsDistanceEval(compSelection[0], PRO_B_TRUE, compSelection[1], PRO_B_TRUE, param1, param2, point1, point2, &distance);

	//createDatumPointsusingCSYS_IR_F2C01_020(point1, point2, "CSYS_ASM_DEF");


	status = ProUIDialogShow(dialog);
	status = ProUIPushbuttonEnable(dialog, PB_ROK);

	return PRO_TK_NO_ERROR;
}

ProError radioGrpSelectAction_F2C01_020(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- radioGrpSelectAction_F2C01_020 -----------------------------");;
	int radioGrpNames[2];
	char** buttonNames;
	char selectedButton[PRO_NAME_SIZE];
	InterfaceRule iRule;

	status = ProUIPushbuttonDisable(dialog, PB_ROK);

	status = ProUIRadiogroupSelectednamesGet(dialog, component, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet: " + to_string(status) + "\tselectedbutton name: " + (string)buttonNames[0]);

	if (strcmp(buttonNames[0], "rb1") == 0)
	{
		status = ProUILabelHide(dialog, LABEL1);
		status = ProUIPushbuttonHide(dialog, SELECT_PB);
		status = ProUILabelShow(dialog, LABEL2);
		status = ProUIPushbuttonShow(dialog, MEASURE_PB);
		ManualCheck = false;
		ruleLog.Write("ManualCheck: " + to_string(ManualCheck));
	}
	else
	{
		status = ProUILabelHide(dialog, LABEL2);
		status = ProUIPushbuttonHide(dialog, MEASURE_PB);
		status = ProUILabelShow(dialog, LABEL1);
		status = ProUIPushbuttonShow(dialog, SELECT_PB);
		ManualCheck = true;
		ruleLog.Write("ManualCheck: " + to_string(ManualCheck));
	}

	return PRO_TK_NO_ERROR;

}

ProError compsFilter_IR_F2C01_020(ProFeature* p_feature, ProAppData app_data)
{
	ruleLog.Write("----------------------------- compsFilter_IR_F2C01_020 -----------------------------");

	ProFeattype feat_type;
	status = ProFeatureTypeGet(p_feature, &feat_type);
	ruleLog.Write("ProFeatureTypeGet: " + to_string(status));

	return (feat_type == PRO_FEAT_COMPONENT ? PRO_TK_NO_ERROR : PRO_TK_CONTINUE);
}

ProError getReqComponentsId_IR_F2C01_020(ProFeature* pFeat, ProError status, ProAppData appD)
{
	ruleLog.Write("----------------------------- getReqComponentsId_IR_F2C01_020 -----------------------------");

	ComponentData_IR_F2C01_020* reqs = (ComponentData_IR_F2C01_020*)appD;
	int reqs_size = 2;
	ProMdl req_mdl;
	wchar_t wMdlName[PRO_NAME_SIZE];
	char cMdlName[PRO_NAME_SIZE];
	ProModelitem part_model_item{};
	ProParameter pDesc;
	ProParamvalue pvDesc;
	char cDesc[PRO_PATH_SIZE];

	status = ProAsmcompMdlGet((ProAsmcomp*)pFeat, &req_mdl);
	ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));

	status = ProMdlMdlnameGet(req_mdl, wMdlName);
	ProWstringToString(cMdlName, wMdlName);
	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status) + "\t cMdlName: " + string(cMdlName));

	status = ProMdlToModelitem(req_mdl, &part_model_item);
	status = ProParameterInit(&part_model_item, L"DESCRIPTION", &pDesc);
	status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
	ProWstringToString(cDesc, pvDesc.value.s_val);
	ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\t Description: " + string(cDesc));

	for (int i = 0; i < reqs_size; ++i) {
		if (strcmp(cMdlName, reqs[i].name) == 0) {
			reqs[i].id = pFeat->id;
			ProWstringToString(reqs[i].desc, pvDesc.value.s_val);
		}
		ruleLog.Write("reqs[i].id: " + to_string(reqs[i].id) + "\t reqs[i].name" + string(reqs[i].name) + "\t reqs[i].desc" + string(reqs[i].desc));
	}

	return PRO_TK_NO_ERROR;
}

ProError measure_action_IR_F2C01_020(char* dialog, char* component)
{
	ruleLog.Write("----------------------------- measure_action_IR_F2C01_020 -----------------------------");

	deleteDatumPointCreatedUsingCsys_IR_F2C01_020("datum_PNT1");
	deleteDatumPointCreatedUsingCsys_IR_F2C01_020("datum_PNT2");

	ProSelection sels[2];
	ProIdTable idtbl1 = { reqComps_IR_F2C01_020[0].id };
	ProIdTable idtbl2 = { reqComps_IR_F2C01_020[1].id };

	ProName comp1_name, comp2_name;
	ProModelitem feature[2];
	ProMdl reqMdls[2];

	ProStringToWstring(comp1_name, reqComps_IR_F2C01_020[0].name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));

	status = ProMdlToModelitem(reqMdls[0], &feature[0]);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProStringToWstring(comp2_name, reqComps_IR_F2C01_020[1].name);
	status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));

	status = ProMdlToModelitem(reqMdls[1], &feature[1]);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProAsmcomppath path[2];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl2, 1, &path[1]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	ProBoolean  interf{};
	Pro3dPnt    coord[2]{};
	status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_NONE, sels[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance_IR_F2C01_020, NULL, &interf, coord);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance_IR_F2C01_020));
	createDatumPointsusingCSYS_IR_F2C01_020(coord, "CSYS_ASM_DEF");

	//ProUvParam param1, param2;
	//Pro3dPnt point1, point2;
	//double distance;
	//status = ProSelectionWithOptionsDistanceEval(sels[0], PRO_B_TRUE, sels[1], PRO_B_TRUE, param1, param2, point1, point2, &distance);
	//createDatumPointsusingCSYS_IR_F2C01_020(point1, point2, "CSYS_ASM_DEF");

	status = ProUIPushbuttonEnable(dialog, PB_ROK);
	ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));

	return PRO_TK_NO_ERROR;
}

ProError createDatumPointsusingCSYS_IR_F2C01_020(Pro3dPnt pnt_arr[2], char* csysName)
{
	ruleLog.Write("----------------------------- createDatumPointsusingCSYS_IR_F2C01_020 -----------------------------");

	wchar_t wCsysName[PRO_PATH_SIZE]{};
	ProStringToWstring(wCsysName, csysName);
	ProModelitem refCsysitem{};
	status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
	ruleLog.Write("ProModelitemByNameInit: " + to_string(status));

	ProSelection refCsysSel{};
	status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	ProElement	elem_tree{};
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	ProElement	elem_ftype{};
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
	ruleLog.Write("ProElementIntegerSet: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	elem_feature_name{};
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	wchar_t wDatumPointName[PRO_PATH_SIZE]{};
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, "Dist_highlght_pnt"));
	ruleLog.Write("ProElementWstringSet: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_type{};
	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
	ruleLog.Write("ProElementIntegerSet: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement pro_e_dpoint_ofst_csys_type{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
	ruleLog.Write("ProElementIntegerSet: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_ref{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	ProReference REPDEP_ref1{};
	status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
	ruleLog.Write("ProSelectionToReference: " + to_string(status));

	status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
	ruleLog.Write("ProElementReferenceSet: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_with_dims{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
	ruleLog.Write("ProElementIntegerSet: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_pnts_array{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_pnt_1{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_pnt_name_1{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	wchar_t wide_string[PRO_NAME_SIZE]{};
	ProStringToWstring(wide_string, "datum_PNT1");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
	ruleLog.Write("ProElementWstringSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_dir1_val_1{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
	ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
	ruleLog.Write("ProElementDoubleSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement pro_e_dpoint_ofst_csys_dir2_val_1{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
	ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

	double d1 = -pnt_arr[0][2];
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
	ruleLog.Write("ProElementDoubleSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_dir3_val_1{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
	ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
	ruleLog.Write("ProElementDoubleSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_pnt_2{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement pro_e_dpoint_ofst_csys_pnt_name_2{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	wchar_t wide_string_2[PRO_PATH_SIZE]{};
	ProStringToWstring(wide_string_2, "datum_PNT2");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
	ruleLog.Write("ProElementWstringSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_dir1_val_2{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
	ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
	ruleLog.Write("ProElementDoubleSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_dir2_val_2{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
	ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

	double d2 = -pnt_arr[1][2];
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
	ruleLog.Write("ProElementDoubleSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement pro_e_dpoint_ofst_csys_dir3_val_2{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
	ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
	ruleLog.Write("ProElementDoubleSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProSelection reqMdlSel{};
	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	ProFeatureCreateOptions* opts = 0;
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
	ruleLog.Write("ProArrayAlloc: " + to_string(status));

	ProFeature pnt_feat{};
	opts[0] = PRO_FEAT_CR_NO_OPTS;
	ProErrorlist errors{};
	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate: " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	ruleLog.Write("ProArrayFree: " + to_string(status));

	status = ProElementFree(&elem_tree);
	ruleLog.Write("ProElementFree: " + to_string(status));

	status = ProSelectionFree(&reqMdlSel);
	ruleLog.Write("ProSelectionFree: " + to_string(status));

	ProSelection pnt_Sel{};
	status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_SS_FAILED_ITEMS);
	ruleLog.Write("ProSelectionHighlight: " + to_string(status));

	return PRO_TK_NO_ERROR;
}

ProError ruleDlgOKaction_IR_F2C01_020(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgOKaction_IR_F2C01_020 -----------------------------");

	int curWinId1{};
	status = ProWindowCurrentGet(&curWinId1);
	ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

	status = ProWindowRepaint(curWinId1);
	ruleLog.Write("ProWindowRepaint: " + to_string(status));

	deleteDatumPointCreatedUsingCsys_IR_F2C01_020("datum_PNT1");
	deleteDatumPointCreatedUsingCsys_IR_F2C01_020("datum_PNT2");

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return PRO_TK_NO_ERROR;
}

ProError ruleDlgCloseAction_IR_F2C01_020(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgCloseAction_IR_F2C01_020 -----------------------------");

	int curWinId2{};
	status = ProWindowCurrentGet(&curWinId2);
	ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

	status = ProWindowRepaint(curWinId2);
	ruleLog.Write("ProWindowRepaint: " + to_string(status));

	deleteDatumPointCreatedUsingCsys_IR_F2C01_020("datum_PNT1");
	deleteDatumPointCreatedUsingCsys_IR_F2C01_020("datum_PNT2");

	if (data != NULL) {
		bool* quitAction = (bool*)data;
		*quitAction = true;
	}
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}

ProError deleteDatumPointCreatedUsingCsys_IR_F2C01_020(char* dtmpoint_name)
{
	ruleLog.Write("----------------------------- deleteDatumPointCreatedUsingCsys_IR_F2C01_020 -----------------------------");

	ProIdTable idtbl1{};
	ProAsmcomppath path{};
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	wchar_t wdatum_pt[PRO_PATH_SIZE]{};
	ProStringToWstring(wdatum_pt, dtmpoint_name);
	ProModelitem mdl_item{};
	status = ProModelitemByNameInit(curMdl, PRO_POINT, wdatum_pt, &mdl_item);
	ruleLog.Write("ProModelitemByNameInit: " + to_string(status));

	if (status == PRO_TK_NO_ERROR) {

		int* feat_ids = NULL;
		status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
		ruleLog.Write("ProArrayAlloc: " + to_string(status));

		ProFeature feat{};
		status = ProGeomitemFeatureGet((ProGeomitem*)&mdl_item, &feat);
		ruleLog.Write("ProGeomitemFeatureGet: " + to_string(status));
		feat_ids[0] = feat.id;

		ProFeatureDeleteOptions* delete_opts = 0;
		status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
		ruleLog.Write("ProArrayAlloc: " + to_string(status));

		delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;
		status = ProFeatureWithoptionsDelete((ProSolid)curMdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
		ruleLog.Write("ProFeatureWithoptionsDelete: " + to_string(status));

		status = ProArrayFree((ProArray*)&delete_opts);
		ruleLog.Write("ProArrayFree: " + to_string(status));

		status = ProArrayFree((ProArray*)&feat_ids);
		ruleLog.Write("ProArrayFree: " + to_string(status));
	}

	return PRO_TK_NO_ERROR;
}