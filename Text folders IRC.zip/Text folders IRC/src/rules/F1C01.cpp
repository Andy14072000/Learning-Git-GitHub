/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F1C01 - PNEUMATIC SYSTEM RULES
==================================================================================================================*/
#include "F1C01.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F1C01-006	| MATHANPRASATH A	| MF1C01			| Use of standard hardware for breather clamp mounting.
===================================================================================================================*/
#define DLG_IRF1C01_006 "dlg_IR_F1C01_006"
#define PB_ROK			"CommitOK"
#define PB_RCANCEL		"CommitCancel"

struct description
{
    char    prtname[PRO_NAME_SIZE];
    string  desc;
};

vector<string>Nonstdfasteners, Stdfasteners;
string dsc_nd_name;
description objname;
wchar_t* wDescName;

int IRF1C01::IRF1C01_006(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF1C01::IRF1C01_006   ==========================");
    status = ProWindowRepaint(PRO_VALUE_UNUSED);
    Stdfasteners.clear();
    Nonstdfasteners.clear();
    isUserQuits = false;
    status = ProUIDialogCreate(DLG_IRF1C01_006, DLG_IRF1C01_006);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF1C01_006, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF1C01_006, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF1C01_006, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF1C01_006, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF1C01_006);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);
    if (isUserQuits)
        return -1;

    string remarkMsg{};
    string remarkMsg1{};

    status = ProSolidFeatVisit((ProSolid)curMdl, visit11DigitFasteners, compsFilter, NULL);

    map<string, int> elementCount;
    //Nonstdfasteners count
    for (const auto& part : Nonstdfasteners)
    {
        elementCount[part]++;


    }
    for (const auto& entry : elementCount)
    {
        remarkMsg += entry.first;
        remarkMsg += "(";
        remarkMsg += to_string(entry.second);
        remarkMsg += ")\n";
    }
    elementCount.clear();

    //Stdfasteners count

    if (Stdfasteners.size() != 0 && Nonstdfasteners.size() == 0)
    {
        final_res.result = "PASS";
        remarkMsg1 += "Standard Hardware used for breather clamp mounting.\n Acceptance criteria: Only 11 digit fasteners should be used for breather clamp mounting. ";
        final_res.remark = remarkMsg1;

    }
    else if (Stdfasteners.size() == 0 && Nonstdfasteners.size() != 0)
    {
        final_res.result = "FAIL";
        remarkMsg += "Standard Hardware not used for breather clamp mounting.\n Acceptance criteria: Only 11 digit fasteners should be used for breather clamp mounting. ";
        final_res.remark = remarkMsg;
    }
    else if (Stdfasteners.size() == 0 && Nonstdfasteners.size() == 0) {
        final_res.result = "PASS";
        sprintf(remark, "There are no fasteners present in the model, hence the rule is passed.\n Acceptance criteria: Only 11 digit fasteners should be used for breather clamp mounting.");
        final_res.remark = string(remark);
    }
    ruleLog.Write(remarkMsg1);
    ruleLog.Write(remarkMsg);


    return 0;
}

ProError visit11DigitFasteners(ProFeature* p_feature, ProError status, ProAppData appD)
{
    ruleLog.Write("--------------------------  visit11DigitComponents  --------------------------");


    ProMdl                  subModuleMdl;
    wchar_t                 wFeatName[PRO_NAME_SIZE];
    char                    cFeatName[PRO_NAME_SIZE];
    ProMdlType              subModuleMdlType;
    string                  description;
    ProModelitem            subModuleModelItem;
    ProParameter            pDesc;
    ProParamvalue           pvDesc;
    ProName                 pDescName = L"DESCRIPTION";
    char                    existingPval[PRO_NAME_SIZE];
    wchar_t* wparamname;
    int					    table_num{};
    ProAsmcomppath		    p_comp_path;
    ProSelection            sel;

    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &subModuleMdl);
    status = ProMdlMdlnameGet(subModuleMdl, wFeatName);
    status = ProMdlTypeGet(subModuleMdl, &subModuleMdlType);



    /*if (subModuleMdlType == PRO_MDL_ASSEMBLY && level<=1)
    {
    status = ProSolidFeatVisit((ProSolid)subModuleMdl, visit11DigitFasteners, compsFilter, NULL);
    ruleLog.Write("SolidfeatVisit1");
    level++;
    }*/

    if (subModuleMdlType == PRO_MDL_PART)
    {
        ruleLog.Write("--------------------------  visitingparts  --------------------------");
        ProWstringToString(cFeatName, wFeatName);
        ruleLog.Write(cFeatName);

        int strlength;

        status = ProMdlToModelitem(subModuleMdl, &subModuleModelItem);
        ruleLog.Write("ProMdlToModelitem: " + to_string(status));
        status = ProParameterInit(&subModuleModelItem, pDescName, &pDesc);
        ruleLog.Write("ProParameterInit: " + to_string(status));

        if (status != PRO_TK_E_NOT_FOUND)
        {
            status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
            ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));
            (ProWstringToString(existingPval, pvDesc.value.s_val));

            description.append(existingPval);


            const regex p("(SCREW)");
            const regex q("(SCR)");
            const regex r("(BOLT)");
            const regex s("(NUT)");
            const regex t("(WELD)");

            if ((regex_search(description, p) != 0) || (regex_search(description, q) != 0) ||
                (regex_search(description, r) != 0) || ((regex_search(description, s) != 0) && (regex_search(description, t) == 0)))
            {
                strlength = strlen(cFeatName);
                if (strlength != 11)
                {

                    /*status = ProAsmcomppathInit((ProSolid)subModuleMdl, comp_id_table, table_num, &p_comp_path);
                    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
                    status = ProSelectionAlloc(&p_comp_path, &subModuleModelItem, &sel);
                    ruleLog.Write("ProSelectionAlloc: " + to_string(status));
                    status = ProSelectionHighlight(sel, PRO_COLOR_HIGHLITE);
                    ruleLog.Write("ProSelectionHighlight: " + to_string(status));*/
                    // p_feature->id;
                    int comp_id_table = p_feature->id;
                    table_num = 1;


                    status = ProAsmcomppathInit((ProSolid)curMdl, &comp_id_table, table_num, &p_comp_path);
                    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
                    status = ProSelectionAlloc(&p_comp_path, &subModuleModelItem, &sel);
                    ruleLog.Write("ProSelectionAlloc: " + to_string(status));
                    status = ProSelectionHighlight(sel, PRO_COLOR_HIGHLITE);
                    ruleLog.Write("ProSelectionHighlight: " + to_string(status));

                    dsc_nd_name.append(cFeatName);
                    dsc_nd_name.append(".PRT");
                    dsc_nd_name.append("(");
                    dsc_nd_name.append(description);
                    dsc_nd_name.append(")");
                    Nonstdfasteners.push_back(dsc_nd_name);
                    dsc_nd_name.erase();
                }
                else {
                    Stdfasteners.push_back(cFeatName);
                }
                /* else
                {
                dsc_nd_name.append(cFeatName);
                dsc_nd_name.append(".PRT");
                dsc_nd_name.append("(");
                dsc_nd_name.append(description);
                dsc_nd_name.append(")");
                Stdfasteners.push_back(dsc_nd_name);
                dsc_nd_name.erase();


                }*/

            }
        }

    }
    return PRO_TK_NO_ERROR;
}
#pragma pop