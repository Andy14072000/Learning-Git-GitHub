/*================================================================================================================ =
NAME | DATE | VERSION | COMMENTS
================================================================================================================== =
BHUVAN BHARATH | 24 - 04 - 2023 | V1_0_0 | F2A02 - FRONT AXLE / LIFT AXLE RULES
==================================================================================================================*/
#include "F1D01.h"
#pragma warning(push)    //TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F1D01-001	| Atharva Patil 	| MF1D01  	        | Winch should be mounted at approximately near the center of 
                                                          Vehicle in longitudinal direction(OR as per Customer Requirement)
===================================================================================================================*/

#define DLG_F1D01_001    "dlg_IR_F1D01_001" 
#define CommitCancel     "CommitCancel" 
#define CommitOK         "CommitOK"
#define select_pb1       "select_pb1"
#define select_pb2       "select_pb2"
#define rule_img         "rule_img"

ProSelection* winchSurfaces, winchcopy1, winchcopy2;
ProSelection* winchAxis;
int n_sels1;
int rule_sts1;

double lengthOfWinch, distance1, distance2, halfLength, d1;
string remarkMsg;

int IRF1D01::IRF1D01_001(ruleResult &final_res)
{
    ruleLog.Write("==========================   IRF1D01::IRF1D01_001   ==========================");
    ruleLog.Write("Winch should be mounted at approximately near the center of Vehicle in longitudinal direction");
    ProWindowRepaint(PRO_VALUE_UNUSED);
    remarkMsg.erase();
    isUserQuits = false;
    status = ProUIDialogCreate(DLG_F1D01_001, DLG_F1D01_001);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));
    status = ProUIDialogAboveactivewindowSet(DLG_F1D01_001, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_F1D01_001, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_F1D01_001, CommitOK, (ProUIAction)run_action_IRF1D01001, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_F1D01_001, select_pb1, (ProUIAction)select_action_IRF1D01001_surf, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_F1D01_001, select_pb2, (ProUIAction)select_action_IRF1D01001_axis, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonDisable(DLG_F1D01_001, select_pb2);
    status = ProUIPushbuttonDisable(DLG_F1D01_001, CommitOK);
    status = ProUIDialogHide(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogHide: " + to_string(status));
    status = ProUIDialogActivate(DLG_F1D01_001, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));

    if (isUserQuits) {
        status = ProUIDialogDestroy(DLG_F1D01_001);
        status = ProUIDialogShow(DLG_IRC_MAIN);
        return -1;
    }
    status = ProUIDialogDestroy(DLG_F1D01_001);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);
    string d1Msg = to_string(abs(round(d1)));
    d1Msg.erase(d1Msg.find_last_not_of('0') + 3, string::npos);

    if (abs(d1) <= 1000)
    {
        remarkMsg += "Winch is mounted approx. at the centre\nMeasured Deviation from exact centre = " + d1Msg + " mm.";
        final_res.result = "PASS";
    }
    else {
        final_res.result = "FAIL";
        remarkMsg += "Winch is deviated by " + d1Msg + " mm from the center.";
    }
    remarkMsg += "\nAcceptance criteria : Winch Should be mounted approx. at centre (1000 mm tolerance).";
    final_res.remark = remarkMsg;
    return 0;
}

ProError select_action_IRF1D01001_surf(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("================select_action_IRF1D01001_surf==============");
    ProUIDialogHide(DLG_F1D01_001);

    ProWindowRepaint(PRO_VALUE_UNUSED);
    status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &winchSurfaces, &n_sels1);
    ruleLog.Write("Proselect_status_surf = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels1));
    if (status == PRO_TK_USER_ABORT)
    {
        status = ProUIDialogShow(DLG_F1D01_001);
        return status;
    }
    status = ProSelectionCopy(winchSurfaces[0], &winchcopy1);
    ruleLog.Write("ProSelectionCopy 1 status: " + to_string(status));
    status = ProSelectionCopy(winchSurfaces[1], &winchcopy2);
    ruleLog.Write("ProSelectionCopy 2 status: " + to_string(status));

    status = ProUIDialogShow(DLG_F1D01_001);
    status = ProUIPushbuttonEnable(DLG_F1D01_001, select_pb2);
    return PRO_TK_NO_ERROR;
}

ProError select_action_IRF1D01001_axis(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("================select_action_IRF1D01001_axis==============");
    ProUIDialogHide(DLG_F1D01_001);
    status = ProSelect((char*)"surface", 1, NULL, NULL, NULL, NULL, &winchAxis, &n_sels1);
    ruleLog.Write("Proselect_status_axis = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels1));
    if (status == PRO_TK_USER_ABORT)
    {
        status = ProUIDialogShow(DLG_F1D01_001);
        return status;
    }
    status = ProUIDialogShow(DLG_F1D01_001);
    status = ProUIPushbuttonEnable(DLG_F1D01_001, CommitOK);
    return PRO_TK_NO_ERROR;
}

ProError run_action_IRF1D01001(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("================ run_action_IRF1D01001 ==============");
    InterfaceRule _irule;
    status = ProGeomitemDistanceEval(winchcopy1, winchcopy2, &lengthOfWinch);
    ruleLog.Write("ProGeomitemDistanceEval status = " + to_string(status) + "\nDistance is: " + to_string(lengthOfWinch));
    halfLength = lengthOfWinch / 2;
    ruleLog.Write("half length is :" + to_string(halfLength));

    rule_sts1 = _irule.measureDistanceBetweenSurfaces(winchcopy1, winchAxis[0], distance1);
    //status = ProGeomitemDistanceEval(winchcopy1, winchAxis[0], &distance1);
    ruleLog.Write("measureDistanceBetweenSurfaces status 1 = " + to_string(rule_sts1) + "\nDistance is: " + to_string(distance1));
    rule_sts1 = _irule.measureDistanceBetweenSurfaces(winchcopy2, winchAxis[0], distance2);
    //status = ProGeomitemDistanceEval(winchcopy2, winchAxis[0], &distance2);
    ruleLog.Write("measureDistanceBetweenSurfaces status 2 = " + to_string(rule_sts1) + "\nDistance is: " + to_string(distance2));

    d1 = distance1 - halfLength;
    ruleLog.Write("D1 distance is : " + to_string(d1));
    /*double d2 = distance2 - halfLength;
    ruleLog.Write("D2 distance is : " + to_string(d2));*/

    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F1D01-003	| Aniket Satpute	| MF1D01;       	| Bolts of minimum 10.9 Grade to be used
===================================================================================================================*/
#define DLG_IRF1D01_003     "dlg_IR_F1D01_003"
#define CommitOK			"CommitOK"
#define CommitCancel		"CommitCancel"
#define rule_img            "rule_img"

int IRF1D01::IRF1D01_003(ruleResult& final_res)
{
    ruleLog.Write("-------------->IR_F1D01_003<--------------");
    ruleLog.Write("\nStandard fasteners of 10.9 grade or above should be used for mounting arrangements");

    string                  remarkMsg{};
    double                  stdGradeBolt = 10.9;
    double                  stdGradeNut = 10.0;
    vector<HardwareInfo>    _hwInfo;
    vector<HardwareInfo>    _nonStdHwInfo;
    string                  typeOfHw;
    typeOfHw = "NUT";

    //Clearing the vectors for fresh run
    _hwInfo.clear();
    _nonStdHwInfo.clear();

    isUserQuits = false;

    status = ProUIDialogCreate(DLG_IRF1D01_003, DLG_IRF1D01_003);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF1D01_003, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF1D01_003, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF1D01_003, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF1D01_003, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF1D01_003);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;
    ProAsmcomppath             path;
    ProSelection               selection;

    status = ProSolidFeatVisit((ProSolid)curMdl, (ProFeatureVisitAction)visit11DigitComponents, compsFilter, &_hwInfo);
    ruleLog.Write(to_string(_hwInfo.size()));

    for (int i = 0; i < _hwInfo.size(); i++)
    {
        if (((_hwInfo.at(i).typeOfHw == typeOfHw) && (_hwInfo.at(i).gradeDb < stdGradeNut)) ||
            ((_hwInfo.at(i).typeOfHw != typeOfHw) && (_hwInfo.at(i).gradeDb < stdGradeBolt)))
        {
            _nonStdHwInfo.push_back(_hwInfo.at(i));
            status = ProAsmcomppathInit((ProSolid)curMdl, &_hwInfo.at(i).ID, 1, &path);
            ruleLog.Write("ProAsmcomppathInit : " + to_string(status));
            status = ProSelectionAlloc(&path, &_hwInfo.at(i).Item, &selection);
            ruleLog.Write("ProSelectionAlloc : " + to_string(status));
            status = ProSelectionHighlight(selection, PRO_COLOR_HIGHLITE);
            ruleLog.Write("ProSelectionHighlight : " + to_string(status));
        }
    }

    //Write the remarks
    if ((_nonStdHwInfo.size() == 0) && (_hwInfo.size() != 0))
    {
        remarkMsg += "All the fasteners used in the model are of standard grade.";
        ruleLog.Write("All the fasteners used in the model are of standard grade.");
    }
    if (_hwInfo.size() == 0)
    {
        remarkMsg += "There are no fasteners present in the model, hence the rule is passed.";
        ruleLog.Write("There are no fasteners present in the model\n");
        ruleLog.Write("Hence the rule is passed.");

    }
    if (_nonStdHwInfo.size() != 0)
    {
        remarkMsg += "List of hardware part numbers of non standard grade\n";
        vector<double>      uniqueGradeList;
        vector<string>      partsOfSpecificGrade;
        uniqueGradeList.clear();
        int srNo{ 0 };

        //Create a grade list with non repeating values
        for (int i = 0; i < _nonStdHwInfo.size(); i++)
        {
            uniqueGradeList.push_back(_nonStdHwInfo.at(i).gradeDb);
            sort(uniqueGradeList.begin(), uniqueGradeList.end(), [](double a, double b)
                {
                    return a > b; // Compare in descending order
                });
            auto last = unique(uniqueGradeList.begin(), uniqueGradeList.end());
            uniqueGradeList.erase(last, uniqueGradeList.end());
        }

        //create a vector of part names having a specific grade
        for (int i = 0; i < uniqueGradeList.size(); i++)
        {
            srNo = 0;
            partsOfSpecificGrade.clear();
            double target = uniqueGradeList.at(i);
            remarkMsg += "\nGrade ";
            double rounded1 = round(target * 10) / 10;
            string t = to_string(rounded1);
            t.erase(t.find_last_not_of('0') + 1, string::npos);
            remarkMsg += t;
            remarkMsg += "-\n";

            for (int j = 0; j < _nonStdHwInfo.size(); j++)
            {
                if (target == _nonStdHwInfo.at(j).gradeDb)
                {
                    partsOfSpecificGrade.push_back(_nonStdHwInfo.at(j).compName);
                }
            }
            //Count the repetitions of a part
            map<string, int> elementCount;
            for (const auto& part : partsOfSpecificGrade)
            {
                elementCount[part]++;
            }
            for (const auto& entry : elementCount)
            {
                remarkMsg += entry.first;
                remarkMsg += ".PRT (";
                remarkMsg += to_string(entry.second);
                remarkMsg += ") , ";
                srNo++;
                if (srNo == 4)
                    remarkMsg += "\n";
            }
            elementCount.clear();
        }
        double rounded = round(stdGradeBolt * 10) / 10;
        string outputStdGrd = to_string(rounded);
        outputStdGrd.erase(outputStdGrd.find_last_not_of('0') + 1, string::npos);
        remarkMsg += "\nAcceptance Criteria = ";
        remarkMsg += outputStdGrd;
        remarkMsg += " or above";

    }

    //Declare result
    if ((_hwInfo.size() == 0) || (_nonStdHwInfo.size() == 0))
    {
        final_res.result = "PASS";
        final_res.remark = remarkMsg;
        ruleLog.Write("Status = " + final_res.result);
    }
    else
    {
        final_res.result = "FAIL";
        final_res.remark = remarkMsg;
        ruleLog.Write(final_res.remark);
        ruleLog.Write("Status = " + final_res.result);
        ruleLog.Write("Reason : ");
        ruleLog.Write("Non standard hardware used in the model");
    }
    ruleLog.Write(remarkMsg);
    return 0;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			  | DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F1D01-006	| Himanshu Pachpute   | MF1D01; MF1A01  	| Distance between two consecutive rope pulley or roller bracket mounting 
                                                              brackets should not be more than 2m.
===================================================================================================================*/

#define DLG_IR_F1D01_006			    "dlg_IR_F1D01_006"
#define PB_OK_IR_F1D01_006			    "rule_ok_pb"
#define PB_CANCEL_IR_F1D01_006		    "rule_cancel_pb"
#define PB_SELECT_IR_F1D01_006		    "pb_select"

vector<Surface_Info> Surface_Info_Vec{};

int IRF1D01::IRF1D01_006(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF1D01::IRF1D01_006   ==========================");

    Pro2dPnt        param_1, param_2;
    Pro3dPnt        pnt_1, pnt_2;
    double          distance{};
    vector<double>  Dist_Vect{};
    string          RemarkString{};

    status = ProUIDialogCreate(DLG_IR_F1D01_006, DLG_IR_F1D01_006);
    status = ProUIPushbuttonDisable(DLG_IR_F1D01_006, PB_OK_IR_F1D01_006);
    status = ProUIDialogAboveactivewindowSet(DLG_IR_F1D01_006, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IR_F1D01_006, PB_CANCEL_IR_F1D01_006, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IR_F1D01_006, PB_OK_IR_F1D01_006, (ProUIAction)ruleDlgOKaction, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_IR_F1D01_006, PB_SELECT_IR_F1D01_006, (ProUIAction)select_action_IRF1D01_006, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IR_F1D01_006, &dlg_sts);
    status = ProUIDialogDestroy(DLG_IR_F1D01_006);
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    RemarkString = "No. of Surface Selections: " + to_string(Surface_Info_Vec.size()) + "\n\nDistance between";
    for (size_t l = 0; l < Surface_Info_Vec.size() - 1; l++) {
        status = ProSelectionWithOptionsDistanceEval(Surface_Info_Vec[l].Edge_Sel, PRO_B_TRUE, Surface_Info_Vec[l + 1].Edge_Sel, PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance);
        ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tDistance: " + to_string(distance));
        
        RemarkString += "\n\t " + string(Surface_Info_Vec[l].Mdl_name) + " [" + string(Surface_Info_Vec[l].Mdl_Desc) + "] [Model Feat ID: " + to_string(Surface_Info_Vec[l].Mdl_id) + "] [Edge Feat ID: " + to_string(Surface_Info_Vec[l].surface_id) + "] & \n\t\t\t\t\t" +
            string(Surface_Info_Vec[l + 1].Mdl_name) + " [" + string(Surface_Info_Vec[l + 1].Mdl_Desc) + "] [Model Feat ID: " + to_string(Surface_Info_Vec[l + 1].Mdl_id) + "] [Edge Feat ID: " + to_string(Surface_Info_Vec[l + 1].surface_id) + "]: " + doubleToString(distance) + "mm\n";

        Dist_Vect.push_back(distance);
    }

    RemarkString += "\nAccentance Criteria: Distance between two consecutive rope pulley should be < 2000.00mm";

    isRightValue = true;
    for (auto val : Dist_Vect) {
        if (val >= 2000) {
            isRightValue = false;
            break;
        }
    }

    final_res.remark = RemarkString;
    if (isRightValue)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    RemarkString.clear();
    Dist_Vect.clear();
    Surface_Info_Vec.clear();
    return 0;
}

bool is_alphanumeric_and_space(const string& str) {
    for (char c : str) {
        if (!isalnum(c) && !isspace(c) && c != '-' && c != '.' && c != 'X' && c != ',') {
            return false;
        }
    }
    return true;
}

ProError select_action_IRF1D01_006(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- select_action_IRF1D01_006 -----------------------------");

    Surface_Info_Vec.clear();
    int curWinId{}, n_sel;
    ProSelection* surf_Sels = nullptr;
    Surface_Info Edge_Info_Obj{};

    status = ProWindowCurrentGet(&curWinId);
    status = ProWindowRepaint(curWinId);
    status = ProUIDialogHide(dialog);
    status = ProSelect("edge", -1, NULL, NULL, NULL, NULL, &surf_Sels, &n_sel);
    ruleLog.Write("Proselect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel));
    if (n_sel <= 0 || status != PRO_TK_NO_ERROR) {
        InterfaceRule irule_A1A01_002_04;
        irule_A1A01_002_04.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs in the Selection!. Refer help document for details.");
        status = ProUIDialogShow(dialog);
        return PRO_TK_NO_ERROR;
    }

    for (size_t i = 0; i < n_sel; ++i) {
        ProModelitem        Mdl_item{}, Mdl_item_2{};
        wchar_t             WName1[PRO_PATH_SIZE];
        ProParameter        pDesc;
        ProParamvalue       pvDesc;
        int                 lastCompID = -1;
        ProAsmcomppath      asm_comp_path;
        char                Desc[PRO_PATH_SIZE];
        char                NotFound[PRO_PATH_SIZE] = { "Description not found." };

        status = ProSelectionModelitemGet(surf_Sels[i], &Mdl_item);
        status = ProMdlMdlnameGet(Mdl_item.owner, WName1);
        status = ProMdlToModelitem(Mdl_item.owner, &Mdl_item_2);
        status = ProParameterInit(&Mdl_item_2, L"DESCRIPTION", &pDesc);
        status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
        status = ProSelectionAsmcomppathGet(surf_Sels[i], &asm_comp_path);
        for (int k = 0; k < asm_comp_path.table_num; ++k)
            lastCompID = asm_comp_path.comp_id_table[k];

        status = ProSelectionCopy(surf_Sels[i], &Edge_Info_Obj.Edge_Sel);
        Edge_Info_Obj.Mdl_id = lastCompID;
        Edge_Info_Obj.surface_id = Mdl_item.id;
        ProWstringToString(Edge_Info_Obj.Mdl_name, WName1);
        ProWstringToString(Desc, pvDesc.value.s_val);
        (is_alphanumeric_and_space(Desc) ? strcpy(Edge_Info_Obj.Mdl_Desc, Desc) : strcpy(Edge_Info_Obj.Mdl_Desc, NotFound));

        ruleLog.Write("Name: " + string(Edge_Info_Obj.Mdl_name) + "\tDescription: " + string(Edge_Info_Obj.Mdl_Desc) + "\tMdl_Feat_ID: " + to_string(Edge_Info_Obj.Mdl_id) + "\tEdge_Feat_ID: " + to_string(Edge_Info_Obj.surface_id));
        Surface_Info_Vec.push_back(Edge_Info_Obj);
    }

    status = ProUIPushbuttonEnable(dialog, PB_OK_IR_F1D01_006);
    status = ProUIDialogShow(dialog);
    return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF1D01_007     | Prajakta Bhelawe	| MF1D01			|  D-shackle need to be provided for Rope hook mounting
===================================================================================================================*/
#define DLG_F1D01_007  "dlg_IR_F1D01_007" 
#define PB_RCANCEL     "rule_cancel_pb" 
#define PB_ROK         "rule_ok_pb"

vector<string> targetStrings{ "D-SHACKLE", "D-SHACKLE ASSY", "DEE_SHACKLE" };
vector<PartnameDescriptionPair> reqComps;

int IRF1D01::IRF1D01_007(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF1D01::IRF1D01_007   ==========================");

    string descValue;
    string fDesc;
    string fPartName;
    boolean isDescFound = false;
    boolean isValueEqual;

    isUserQuits = false;
    status = ProUIDialogCreate(DLG_F1D01_007, DLG_F1D01_007);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));
    status = ProUIDialogAboveactivewindowSet(DLG_F1D01_007, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_F1D01_007, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_F1D01_007, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIDialogHide(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogHide: " + to_string(status));
    status = ProUIDialogActivate(DLG_F1D01_007, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_F1D01_007);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    status = ProSolidFeatVisit((ProSolid)curMdl, getParameterDescAndPartname_F1D01_007, compsFilter, (ProAppData)&reqComps);
    ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

    for (int i = 0; i < reqComps.size(); i++) {
        descValue = remSpacesAtBothEnds(reqComps[i].description);
        isValueEqual = find(targetStrings.begin(), targetStrings.end(), descValue) != targetStrings.end();

        if (isValueEqual == true)
        {
            ruleLog.Write("inside true");
            fDesc = reqComps[i].description;
            fPartName = reqComps[i].part_name;
            isDescFound = true;
            break;
        }
        else if (isValueEqual == false)
        {
            ruleLog.Write("inside false");
            isDescFound = false;
        }
    }

    if (isDescFound == true) {
        ruleLog.Write("Part_Name = " + fPartName);
        ruleLog.Write("Description = " + fDesc);
        final_res.result = "PASS";
        sprintf(remark, "Found D-Shackle is %s.PRT; Acceptance Criteria: D-Shackle to be provided for Rope hook mounting ", fPartName.c_str());
        final_res.remark = string(remark);
    }
    else if (isDescFound == false) {
        final_res.result = "FAIL";
        sprintf(remark, "D-SHACKLE not present");
        final_res.remark = string(remark);
    }

    descValue.clear();
    reqComps.clear();
    isValueEqual = false;
    isDescFound = false;

    return 0;
}

ProError getParameterDescAndPartname_F1D01_007(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    ruleLog.Write("----------------------------- getParameterDescAndPartname -----------------------------");

    vector<PartnameDescriptionPair>* prtname_desc_list = (vector<PartnameDescriptionPair>*)app_data;

    ProMdlType subModuleMdlType;
    ProModelitem modelItem;
    wchar_t wFeatName[PRO_NAME_SIZE];
    char cFeatName[PRO_NAME_SIZE];
    ProMdl reqMdl;
    char existingPval[PRO_NAME_SIZE]{};
    PartnameDescriptionPair compd{};

    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
    //ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
    status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
    //ruleLog.Write("ProMdlTypeGet: " + to_string(status));
    status = ProMdlMdlnameGet(reqMdl, wFeatName);
    //ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
    ProWstringToString(cFeatName, wFeatName);
    ruleLog.Write("cFeatName = " + string(cFeatName));

    if (subModuleMdlType == PRO_MDL_ASSEMBLY)
    {
        //ruleLog.Write("Assembly Name: ");
        //ruleLog.Write(cFeatName);
        ProSolidFeatVisit((ProSolid)reqMdl, getParameterDescAndPartname, compsFilter, (ProAppData)app_data);
    }

    else if (subModuleMdlType == PRO_MDL_PART)
    {
        status = ProMdlToModelitem(reqMdl, &modelItem);
        //ruleLog.Write("ProMdlToModelitem: " + to_string(status));

        ProParameter pDesc;
        ProParamvalue pvDesc;
        ProName pDescName = L"DESCRIPTION";

        status = ProParameterInit(&modelItem, pDescName, &pDesc);
        //ruleLog.Write("ProParameterInit: " + to_string(status));

        if (status == PRO_TK_NO_ERROR)
        {
            status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
            ProWstringToString(existingPval, pvDesc.value.s_val);
            //ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);

            strcpy(compd.description, existingPval);
            //ruleLog.Write("compd.description" + string(compd.description));
        }
        strcpy(compd.part_name, cFeatName);
        //ruleLog.Write("compd.part_name: " + string(compd.part_name));

        prtname_desc_list->push_back(compd);
        //memset(compd.description, 0, sizeof(compd.description));
    }
    return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			  | DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F1D01-009	| Himanshu Pachpute   | MF1D01; MF1A01  	| Minimum one clamp to be provided in distance of 2m to hold the hydraulic pipe
===================================================================================================================*/

//For Rule UI
#define DLG_F1D01_009           "dlg_IR_F1D01_009" 
//For Table
#define TBL_CLAMP_LAYOUT	    "Table_Layout"
#define TBL_CLAMP_LIBRARY		"Clmp_tbl"
#define CB_SELECT				"select_cb"
#define PB_CANCEL               "Cancel_pb" 
#define PB_OK                   "Ok_pb"

vector<ClampSelectionStruct>    ClampSelectionInfo{}, ClampSelectionInfoAfterSorting{};
vector<feat_id_data>            featIdDataArr{};
Asm_model                       AsmClampModel[1000]{}, clampModel[1000]{};
ClampSelectionStruct            SortedClamps;

int ModelsCount09{};
int	AsmModelCount09{};
int	NoOfAsmFixed09{};
int MdlCount09{};
int	OwnerFeatID09{};
int Levels09{};

FILE* Valuefile09;
wchar_t w_cellLabel009[PRO_PATH_SIZE];
char    c_cellLabel009[PRO_PATH_SIZE];
string  SCompName;
bool    isUserQuitsfortable = false;
int     indexnum;

int IRF1D01::IRF1D01_009(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF1D01::IRF1D01_009   ==========================");

    ClampSelectionInfoAfterSorting.clear();
    ClampSelectionInfo.clear();

    ProMdl Mdl{};
    status = ProMdlCurrentGet(&Mdl);
    ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

    ProPath modelFullPath = { 0 };
    status = ProMdlOriginGet(Mdl, modelFullPath);
    ruleLog.Write("ProMdlOriginGet: " + to_string(status));
    char PathName[PRO_NAME_SIZE]{};
    ProWstringToString(PathName, modelFullPath);
    ruleLog.Write("modelFullPath: " + string(PathName));

    string outputPath;
    for (char c : string(PathName)) {
        if (c == '\\')
            outputPath += "\\\\";
        else
            outputPath += c;
    }

    size_t lastBackslash = outputPath.rfind("\\");
    if (lastBackslash != string::npos)
        outputPath = outputPath.substr(0, lastBackslash + 1) + "Indentified_Clamps.txt";

    ruleLog.Write(outputPath);

    char charArray[PRO_PATH_SIZE];
    strcpy(charArray, outputPath.c_str());

    ruleLog.Write(string(charArray));

    Valuefile09 = fopen(charArray, "w");

    curMdl = Mdl;
    Levels09 = 1;
    NoOfAsmFixed09 = 0;
    clampModel[0].Model = Mdl;
    clampModel[0].Model_feat_id = 0;
    ModelsCount09 = 1;
    AsmModelCount09 = 0;

    while (ModelsCount09 > 0) {
        for (int a = 0; a < ModelsCount09; ++a) {
            OwnerFeatID09 = clampModel[a].Model_feat_id;
            status = ProSolidFeatVisit((ProSolid)clampModel[a].Model, (ProFeatureVisitAction)ClampNameAndIdVisitAction, compsFilter, NULL);
            //ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
        }

        if (AsmModelCount09 > 0) {
            ++Levels09;
            for (int b = 0; b < AsmModelCount09; ++b) {
                clampModel[b].Model = AsmClampModel[b].Model;
                clampModel[b].Model_feat_id = AsmClampModel[b].Model_feat_id;
            }
            ModelsCount09 = AsmModelCount09;
            AsmModelCount09 = 0;
        }
        else {
            ModelsCount09 = 0;
        }
    }

    status = ProUIDialogCreate(DLG_F1D01_009, DLG_F1D01_009);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));

    status = ProUIDialogAboveactivewindowSet(DLG_F1D01_009, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));

    status = ProUIPushbuttonActivateActionSet(DLG_F1D01_009, PB_CANCEL, (ProUIAction)ClampSelectionDlgCloseaction, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIPushbuttonActivateActionSet(DLG_F1D01_009, PB_OK, (ProUIAction)ClampSelectionDlgOKaction, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUILayoutTableRemove(DLG_F1D01_009, TBL_CLAMP_LAYOUT, TBL_CLAMP_LIBRARY);
    ruleLog.Write("ProUILayoutTableRemove: " + to_string(status));

    ProUIGridopts ui_gopts;
    PRO_UI_GRIDOPTS_DEFAULT(ui_gopts);
    ui_gopts.row = 0;
    ui_gopts.column = 0;

    status = ProUILayoutTableAdd(DLG_F1D01_009, TBL_CLAMP_LAYOUT, TBL_CLAMP_LIBRARY, &ui_gopts);
    ruleLog.Write("ProUILayoutTableAdd: " + to_string(status));

    char* columnNames[] = { "s_no", "clamp_name","clamp_description", "clamp_feat_id", "select" };
    wchar_t* columnLabels[] = { L"S. no", L"Name",L"Description", L"Feat ID", L"Select" };
    int columnWidths[] = { 3,7,20,5,3 };

    status = ProUITableColumnnamesSet(DLG_F1D01_009, TBL_CLAMP_LIBRARY, 5, columnNames);
    ruleLog.Write("ProUITableColumnnamesSet: " + to_string(status));

    status = ProUITableColumnlabelsSet(DLG_F1D01_009, TBL_CLAMP_LIBRARY, 5, columnLabels);
    ruleLog.Write("ProUITableColumnlabelsSet: " + to_string(status));

    status = ProUITableColumnwidthsSet(DLG_F1D01_009, TBL_CLAMP_LIBRARY, 5, columnWidths);
    ruleLog.Write("ProUITableColumnwidthsSet: " + to_string(status));

    status = ProUITableShowgridSet(DLG_F1D01_009, TBL_CLAMP_LIBRARY, PRO_B_TRUE);
    ruleLog.Write("ProUITableShowgridSet: " + to_string(status));

    status = ProUITableCheckbuttonAdd(DLG_F1D01_009, TBL_CLAMP_LIBRARY, CB_SELECT);
    ruleLog.Write("ProUITableCheckbuttonAdd: " + to_string(status));

    status = ProUICheckbuttonSizeSet(DLG_F1D01_009, CB_SELECT, 80, 80);
    ruleLog.Write("ProUICheckbuttonSizeSet: " + to_string(status));

    int libTblRowsCount = ClampSelectionInfo.size();
    char** libTblRows = new char* [libTblRowsCount];
    for (int i = 0; i < libTblRowsCount; ++i) {
        libTblRows[i] = new char[PRO_PATH_SIZE];
        ProTKSprintf(libTblRows[i], "r%d", i + 1);
    }
    status = ProUITableRowsInsert(DLG_F1D01_009, TBL_CLAMP_LIBRARY, NULL, libTblRowsCount, libTblRows);
    ruleLog.Write("ProUITableRowsInsert: " + to_string(status));

    for (int i = 0; i < libTblRowsCount; ++i)
    {
        ruleLog.Write("---------------------------------- Adding New Rows -----------------------------------");
        char cbSelectName[PRO_NAME_SIZE];

        ProTKSprintf(c_cellLabel009, " %d. ", i + 1);
        ProStringToWstring(w_cellLabel009, c_cellLabel009);
        status = ProUITableCellLabelSet(DLG_F1D01_009, TBL_CLAMP_LIBRARY, libTblRows[i], "s_no", w_cellLabel009);
        ruleLog.Write("ProUITableCellLabelSet: " + to_string(status));

        ProTKSprintf(c_cellLabel009, "  %s", ClampSelectionInfo[i].Name);
        ProStringToWstring(w_cellLabel009, c_cellLabel009);
        status = ProUITableCellLabelSet(DLG_F1D01_009, TBL_CLAMP_LIBRARY, libTblRows[i], "clamp_name", w_cellLabel009);
        ruleLog.Write("ProUITableCellLabelSet: " + to_string(status));

        ProTKSprintf(c_cellLabel009, "  %s", ClampSelectionInfo[i].Description);
        ProStringToWstring(w_cellLabel009, c_cellLabel009);
        status = ProUITableCellLabelSet(DLG_F1D01_009, TBL_CLAMP_LIBRARY, libTblRows[i], "clamp_description", w_cellLabel009);
        ruleLog.Write("ProUITableCellLabelSet: " + to_string(status));

        ProTKSprintf(c_cellLabel009, "  %d", ClampSelectionInfo[i].FeatId);
        ProStringToWstring(w_cellLabel009, c_cellLabel009);
        status = ProUITableCellLabelSet(DLG_F1D01_009, TBL_CLAMP_LIBRARY, libTblRows[i], "clamp_feat_id", w_cellLabel009);
        ruleLog.Write("ProUITableCellLabelSet: " + to_string(status));

        ProTKSprintf(cbSelectName, "%s", libTblRows[i]);
        status = ProUITableCellComponentCopy(DLG_F1D01_009, TBL_CLAMP_LIBRARY, libTblRows[i], "select", DLG_F1D01_009, CB_SELECT, cbSelectName);
        ruleLog.Write("cbSelectName: " + string(cbSelectName) + "\tProUITableCellComponentCopy: " + to_string(status));

        status = ProUICheckbuttonSet(DLG_F1D01_009, cbSelectName);
        ruleLog.Write("ProUICheckbuttonSet: " + to_string(status));

        SCompName = string(cbSelectName);
        SCompName.erase(0, 1);
        ruleLog.Write("SCompName.erased: " + SCompName);

        indexnum = stoi(SCompName);
        indexnum = indexnum - 1;
        ruleLog.Write("indexnum: " + to_string(indexnum));

        strcpy(SortedClamps.Name, ClampSelectionInfo[indexnum].Name);
        strcpy(SortedClamps.Description, ClampSelectionInfo[indexnum].Description);
        SortedClamps.FeatId = ClampSelectionInfo[indexnum].FeatId;
        SortedClamps.p_selection = ClampSelectionInfo[indexnum].p_selection;

        ProBoolean verifyCbChecked;
        status = ProUICheckbuttonGetState(DLG_F1D01_009, cbSelectName, &verifyCbChecked);
        ruleLog.Write("ProUICheckbuttonGetState: " + to_string(status));

        if (verifyCbChecked) {
            SortedClamps.Flag = true;
            ClampSelectionInfoAfterSorting.push_back(SortedClamps);
            ruleLog.Write(to_string(indexnum) + " index Clamp inserted successfully");
        }

        status = ProUICheckbuttonActivateActionSet(DLG_F1D01_009, cbSelectName, (ProUIAction)Select_cb_action, NULL);
        ruleLog.Write("ProUICheckbuttonActivateActionSet: " + to_string(status));

        status = ProUITableSelectionpolicySet(DLG_F1D01_009, TBL_CLAMP_LIBRARY, PROUISELPOLICY_NONE);
        ruleLog.Write("ProUITableSelectionpolicySet: " + to_string(status));
    }

    status = ProUIDialogHide(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogHide: " + to_string(status));

    status = ProUIDialogActivate(DLG_F1D01_009, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));

    status = ProUIDialogDestroy(DLG_F1D01_009);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

    status = ProUIDialogShow(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogShow: " + to_string(status));

    if (isUserQuits)
        return -1;

    ClampSelectionInfoAfterSorting.erase(remove_if(ClampSelectionInfoAfterSorting.begin(), ClampSelectionInfoAfterSorting.end(),
        [](const ClampSelectionStruct& myStruct) {
            return !myStruct.Flag;
        }
    ), ClampSelectionInfoAfterSorting.end());

    vector<bool> ClampSelectionConditionVect{};
    fprintf(Valuefile09,
        "\nNote: Please be advised that the content provided is intended solely for temporary viewing purposes."
        "\n========================================================================>>"
        "\nClamps selected by the user in the current assembly."
        "\n------------------------------------------------------------------------>>\n");
    fflush(Valuefile09);

    string msg6;
    for (int j = 0; j < ClampSelectionInfoAfterSorting.size(); j++) {
        string CombElement = string(ClampSelectionInfoAfterSorting[j].Name) + "\t" + ClampSelectionInfoAfterSorting[j].Description + "\t" + to_string(ClampSelectionInfoAfterSorting[j].FeatId);
        msg6 += "\t" + CombElement + "\n";
    }

    fprintf(Valuefile09, "\n%s", msg6.c_str());
    fflush(Valuefile09);

    Pro2dPnt        param_1, param_2;
    Pro3dPnt        pnt_1, pnt_2;
    double          distance{};

    string msg1{};
    string msg2{};
    string msg3 = "Every Clamp has atleast one Clamp present in the radius of 2.00m.";
    string msg4{};
    string msg5 = "No Clamps found within the 2.00m radius of\n";

    fprintf(Valuefile09,
        "\n============================================================================>>"
        "\nClamps found in the radius of 2m of respective Clamp."
        "\n---------------------------------------------------------------------------->>\n");
    fflush(Valuefile09);

    for (int j = 0; j < ClampSelectionInfoAfterSorting.size(); j++) {

        string firstElement = "(" + string(ClampSelectionInfoAfterSorting[j].Name) + ") " + ClampSelectionInfoAfterSorting[j].Description + " (" + to_string(ClampSelectionInfoAfterSorting[j].FeatId) + ")";
        string message = "\t" + firstElement + " and\n";
        string message2 = "\t" + firstElement + " and\n";
        bool conditioncheck1{ false };

        for (int k = 0; k < ClampSelectionInfoAfterSorting.size(); k++) {
            status = ProSelectionWithOptionsDistanceEval(ClampSelectionInfoAfterSorting[j].p_selection, PRO_B_TRUE, ClampSelectionInfoAfterSorting[k].p_selection, PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance);
            //ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status));

            string secondElement = "(" + string(ClampSelectionInfoAfterSorting[k].Name) + ") " + ClampSelectionInfoAfterSorting[k].Description + " (" + to_string(ClampSelectionInfoAfterSorting[k].FeatId) + ")";
            
            string formattedDistance = doubleToString(distance);
            message2 += "\t\t\t" + secondElement + ": " + formattedDistance + "\n";

            if (distance < 2000 && firstElement != secondElement) {
                conditioncheck1 = true;
                message += "\t\t\t" + secondElement + ": " + formattedDistance + "\n";
            }
        }

        ClampSelectionConditionVect.push_back(conditioncheck1);
        if (message != "\t" + firstElement + " and\n") {
            //msg1 += message + "\n";
            msg4 += message + "\n";
        }

        if (message2 != "\t" + firstElement + " and\n") {
            msg2 += message2 + "\n";
        }

        if (conditioncheck1 == false) {
            msg5 += "\t" + firstElement + "\n";
            msg1 = msg5;
            msg4 += message + "\t\tNo Clamps found within the 2.00m radius.\n\n";

            status = ProSelectionHighlight(ClampSelectionInfoAfterSorting[j].p_selection, PRO_COLOR_SS_FAILED_ITEMS);
            ruleLog.Write("ProSelectionHighlight: " + to_string(status));
        }
    }

    fprintf(Valuefile09, "\n%s\n", msg4.c_str());
    fflush(Valuefile09);

    ClampSelectionConditionVect.pop_back();

    bool conditioncheck2{ false };
    for (int v = 0; v < ClampSelectionConditionVect.size(); v++) {
        //ruleLog.Write("Identifying the point of Failure: " + to_string(ClampSelectionConditionVect[v]));

        if (ClampSelectionConditionVect[v] != ClampSelectionConditionVect[0]) {
            conditioncheck2 = true;
            break;
        }
    }

    if (msg1.empty())
        final_res.remark = msg3 + "\nAcceptance Criteria: Minimum one clamp needs to be present in the radius of 2.00m of each clamp" + "\n\nFor more details open-- > \n'" + string(charArray) + "'";
    else {
        msg1 += "\nAcceptance Criteria: Minimum one clamp needs to be present in the radius of 2.00m of each clamp\n\nFor more details open -->\n'" + string(charArray) + "'";
        final_res.remark = msg1;
    }

    wchar_t wname[PRO_PATH_SIZE];
    ProInfoWindowSize size;
    size.columns = 100;
    ProStringToWstring(wname, charArray);
    status = ProInfoWindowDisplay(wname, NULL, &size);
    ruleLog.Write("ProInfoWindowDisplay: " + to_string(status));

    if (conditioncheck2 == false)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("\nstatus: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    ClampSelectionInfo.clear();
    featIdDataArr.clear();
    ClampSelectionConditionVect.clear();
    ClampSelectionInfoAfterSorting.clear();
    memset(&clampModel, 0, sizeof(clampModel));
    memset(&AsmClampModel, 0, sizeof(AsmClampModel));
    fclose(Valuefile09);

    return 0;
}

ProError Select_cb_action(char* dialog, char* component, ProAppData app_data)
{
    ruleLog.Write("----------------------------- Select_cb_action -----------------------------");

    ProBoolean verifyCbCheck;
    status = ProUICheckbuttonGetState(dialog, component, &verifyCbCheck);
    ruleLog.Write("ProUICheckbuttonGetState: " + to_string(status));

    string SCompRowName = string(component);
    //ruleLog.Write("SCompName: " + SCompRowName);

    SCompRowName.erase(0, 1);
    //ruleLog.Write("SCompRowName.erased: " + SCompRowName);

    int index = stoi(SCompRowName);
    index = index - 1;
    //ruleLog.Write("index: " + to_string(index));

    if (!verifyCbCheck) {
        ClampSelectionInfoAfterSorting.at(index).Flag = false;
        ruleLog.Write(to_string(index) + " index value replaced to false");
    }
    else if (verifyCbCheck) {
        ClampSelectionInfoAfterSorting.at(index).Flag = true;
        ruleLog.Write(to_string(index) + " index value replaced to true");
    }

    return PRO_TK_NO_ERROR;
}

ProError ClampNameAndIdVisitAction(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    //ruleLog.Write("----------------------------- PartNameAndIdVisitAction -----------------------------");

    ClampSelectionStruct ClampSelection;

    //ruleLog.Write("Component Level: " + to_string(Levels09));

    ProMdlfileType    comp_type;
    ProFamilyMdlName  comp_name;
    status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
    //ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));

    char part_no[PRO_PATH_SIZE]{};
    ProWstringToString(part_no, comp_name);
    //ruleLog.Write("ProMdlName: " + string(part_no));

    ++MdlCount09;

    ProMdl model;
    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
    //ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));

    ProMdlType type;
    status = ProMdlTypeGet(model, &type);
    //ruleLog.Write("ProMdlTypeGet:" + to_string(status));

    wchar_t wFeatName[PRO_NAME_SIZE]{};
    status = ProMdlMdlnameGet(model, wFeatName);
    //ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
    ProWstringToString(ClampSelection.Name, wFeatName);

    ProModelitem modelItem;
    status = ProMdlToModelitem(model, &modelItem);
    //ruleLog.Write("ProMdlToModelitem: " + to_string(status));

    ProName      pDescName = L"DESCRIPTION";
    ProParameter pDesc;
    status = ProParameterInit(&modelItem, pDescName, &pDesc);
    //ruleLog.Write("ProParameterInit: " + to_string(status));

    if (status == PRO_TK_E_NOT_FOUND) {
        ProName      pTmlDescName = L"TML_PART_DESC";
        status = ProParameterInit(&modelItem, pTmlDescName, &pDesc);
        //ruleLog.Write("ProParameterInit: " + to_string(status));
    }

    ProParamvalue pvDesc;
    status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
    //ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));

    ProWstringToString(ClampSelection.Description, pvDesc.value.s_val);
    //ruleLog.Write("ProWstringToString: " + string(ClampSelection.Description));

    ClampSelection.FeatId = p_feature->id;

    feat_id_data  _FeatIDdata;
    if (Levels09 == 1) {
        _FeatIDdata.feat_ids[0] = p_feature->id;
        _FeatIDdata.level = Levels09;
        featIdDataArr.push_back(_FeatIDdata);
    }
    else {
        for (int j = 0; j < featIdDataArr.size(); ++j) {
            if (featIdDataArr[j].feat_ids[Levels09 - 2] == OwnerFeatID09) {
                feat_id_data	owner_feat_id_data = featIdDataArr[j];
                for (int i = 0; i < Levels09 - 1; ++i) {
                    _FeatIDdata.feat_ids[i] = owner_feat_id_data.feat_ids[i];
                }
                _FeatIDdata.feat_ids[Levels09 - 1] = p_feature->id;
                _FeatIDdata.level = Levels09;
                break;
            }
        }
        featIdDataArr.push_back(_FeatIDdata);
    }

    string  searchString1 = { "CLAMP" };
    bool    compfound{ false };
    regex   pattern1("\\b" + searchString1 + "\\b");
    if (regex_search(ClampSelection.Description, pattern1)) {
        compfound = true;
        //ruleLog.Write("========================================================");
        //ruleLog.Write("ClampNameAndIdVisitAction Level: " + to_string(Levels09));
        //ruleLog.Write("Clamp Found: Level " + to_string(Levels09) + " (" + string(ClampSelection.Description) + ") (" + ClampSelection.Name + ") " + to_string(ClampSelection.FeatId));

        ProIdTable			comp_id_table;
        int					table_num;
        ProAsmcomppath		p_comp_path;
        ProModelitem		p_modelitem;

        table_num = Levels09;

        //ruleLog.Write("table_num: " + to_string(table_num));

        for (int m = 0; m < Levels09; ++m) {
            comp_id_table[m] = _FeatIDdata.feat_ids[m];
            //ruleLog.Write("comp_id_table[]: " + to_string(m) + " " + to_string(comp_id_table[m]));
        }

        status = ProMdlToModelitem(model, &p_modelitem);
        //ruleLog.Write("ProMdlToModelitem: " + to_string(status));

        ProMdl curMdl;
        status = ProMdlCurrentGet(&curMdl);
        //ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

        status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
        //ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

        status = ProSelectionAlloc(&p_comp_path, &p_modelitem, &ClampSelection.p_selection);
        //ruleLog.Write("ProSelectionAlloc: " + to_string(status));

        if (status == PRO_TK_NO_ERROR) {
            ClampSelectionInfo.push_back(ClampSelection);
        }
        //ruleLog.Write("========================================================");
    }

    if (type == PRO_MDL_ASSEMBLY && compfound == false)
    {
        AsmClampModel[AsmModelCount09].Model = model;
        AsmClampModel[AsmModelCount09].Model_feat_id = p_feature->id;
        AsmModelCount09 += 1;
    }

    return PRO_TK_NO_ERROR;
}

ProError ClampSelectionDlgCloseaction(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ClampSelectionDlgCloseaction -----------------------------");

    if (data != NULL) {
        bool* quitAction = (bool*)data;
        *quitAction = true;
    }

    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    ruleLog.Write("ProUIDialogExit: " + to_string(status));
    return status;
}

ProError ClampSelectionDlgOKaction(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ClampSelectionDlgOKaction -----------------------------");

    bool allFalse = all_of(ClampSelectionInfoAfterSorting.begin(), ClampSelectionInfoAfterSorting.end(), [](const ClampSelectionStruct& s) {
        return !s.Flag;
        });

    int countTrue = count_if(ClampSelectionInfoAfterSorting.begin(), ClampSelectionInfoAfterSorting.end(), [](const ClampSelectionStruct& s) {
        return s.Flag;
        });

    if (allFalse || countTrue == 1) {
        _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs! Refer to the help document for details.");
        status = ProUIDialogShow(dialog);
        ruleLog.Write("ProUIDialogShow: " + to_string(status));
    }
    else {
        status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
        ruleLog.Write("ProUIDialogExit: " + to_string(status));
    }

    return PRO_TK_NO_ERROR;
}
#pragma pop