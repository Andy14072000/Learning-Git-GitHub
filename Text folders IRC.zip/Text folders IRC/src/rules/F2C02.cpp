/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F2C02 - PROPELLER SHAFT RULES
==================================================================================================================*/
#include "F2C02.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES		| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F2C02-003	| Atharva Patil		| MF2C02; MF3B03		| Minimum 40mm clearance to be ensured with center bearing bracket and EGP/ATS.
===================================================================================================================*/

#define DLG_IRF2C02_003		"dlg_IR_F2C02_003"
#define PB_OK				"CommitOK"
#define PB_CANCEL			"CommitCancel"
#define RB_Grp1				"RadioGroup1"
#define Label2				"Label2"
#define Select1				"Select1"


//Declare the variables for visiting and creatinng ID table of each comp
Asm_model					models_cbm[1000];
int							models_cnt_cbm;
Asm_model					Asm_models[1000];
int							Assy_models_cnt_cbm;
int							num_of_assy_fixed_cbm = 0;
int							model_count_cbm;
vector<feat_id_data>		feat_id_data_arr_cbm;
int							level_cbm;
int							owner_feat_id_cbm;
ProMdl						cur_model;


int selButnCount = 0;

int IRF2C02::IRF2C02_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2C02::IRF2C02_003   ==========================");

	vector<clearanceData>		vectorClearance;
	double						clearance_value = 0;
	string				reqCompSubMod[2] = { "F2C02","F3B03" };
	string				msgRemF;
	string				target;
	vector<ComponentIdTableData>		_reqComps(sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]));
	bool isManual = NULL;


	msgRemF.clear();
	vectorClearance.clear();
	deleteDatumPoint("POINT_FROM");
	deleteDatumPoint("POINT_TO");
	deleteDatumPoint("POINT_FROM1");
	deleteDatumPoint("POINT_TO1");
	deleteDatumPoint("POINT_FROM2");
	deleteDatumPoint("POINT_TO2");
	deleteDatumPoint("POINT_FROM3");
	deleteDatumPoint("POINT_TO3");

	ProWindowRepaint(PRO_VALUE_UNUSED);

	ruleLog.Write("================ before entering the for loop ==================");
	for (int i = 0; i < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++i)
	{
		target = reqCompSubMod[i];
		ruleLog.Write("target comp: " + target);
		for (int j = 0; j < subModulesList.size(); ++j)
		{
			ruleLog.Write("submodule name being visited: " + subModulesList[j].name);
			if (subModulesList[j].name.find(target) != string::npos)
			{
				ruleLog.Write("match found for: " + subModulesList[j].name);
				strcpy(_reqComps[i].name, subModulesList[j].name.c_str());
			}

		}
	}

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_IRF2C02_003, DLG_IRF2C02_003);
	ruleLog.Write("ProUIDialogCreate status: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2C02_003, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2C02_003, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIDialogAboveactivewindowSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2C02_003, PB_OK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIDialogAboveactivewindowSet status: " + to_string(status));
	status = ProUILabelHide(DLG_IRF2C02_003, Label2);
	ruleLog.Write("ProUILabelHide status: " + to_string(status));
	status = ProUIPushbuttonHide(DLG_IRF2C02_003, Select1);
	ruleLog.Write("ProUIPushbuttonHide status: " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_IRF2C02_003, Select1, (ProUIAction)selectActionManualMode_F2C02, &vectorClearance);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));

	status = ProUIRadiogroupSelectActionSet(DLG_IRF2C02_003, RB_Grp1, (ProUIAction)radioGrpSelectAction_F2C02, &isManual);
	ruleLog.Write("ProUIRadiogroupSelectActionSet status: " + to_string(status));
	status = ProUIDialogHide(DLG_IRC_MAIN);
	int radioGrpNames[2];
	char** buttonNames;

	//Radio button, selected for first button (default)
	status = ProUIRadiogroupSelectednamesGet(DLG_IRF2C02_003, RB_Grp1, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status main: " + to_string(status));
	ruleLog.Write("selected button name: " + (string)buttonNames[0]);

	if (buttonNames[0] == "rb1")       //If user does not select any then default radio button will be first button, 
										//and action related to that will be performed on clicking Ok								
	{
		isManual = false;
	}

	status = ProUIDialogActivate(DLG_IRF2C02_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));


	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_IRF2C02_003);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	status = ProUIDialogDestroy(DLG_IRF2C02_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	//Automatic verification
	if (isManual == false)
	{

		ruleLog.Write("Automatic Selection");

		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Attention!!", "It may take a moment to measure the clearance between two components.");

		//Visit the features of opened submodule
		FILE* fp{};
		level_cbm = 1;

		num_of_assy_fixed_cbm = 0;

		models_cbm[0].Model = curMdl;
		models_cbm[0].Model_feat_id = 0;
		models_cnt_cbm = 1;
		Assy_models_cnt_cbm = 0;

	begin:

		for (int a = 0; a < models_cnt_cbm; ++a)
		{
			owner_feat_id_cbm = models_cbm[a].Model_feat_id;
			status = ProSolidFeatVisit((ProSolid)models_cbm[a].Model, (ProFeatureVisitAction)visitActionF2C02, compsFilter, &_reqComps);
			ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
		}

		if (Assy_models_cnt_cbm > 0)
		{
			++level_cbm;
			for (int b = 0; b < Assy_models_cnt_cbm; ++b)
			{
				models_cbm[b].Model = Asm_models[b].Model;
				models_cbm[b].Model_feat_id = Asm_models[b].Model_feat_id;
			}
			models_cnt_cbm = Assy_models_cnt_cbm;
			Assy_models_cnt_cbm = 0;
			goto begin;
		}

		for (auto elem : _reqComps) {
			ruleLog.Write("_reqComps[].name = " + string(elem.name));
			ruleLog.Write("_reqComps[].id = " + to_string(elem.compIdTab[elem.tableNum - 1]));
		}
		msgRemF += "\nReferences Selected for verification: -\nSelection1: " + string(_reqComps[0].name) + "\t\t id: " + to_string(_reqComps[0].compIdTab[_reqComps[0].tableNum - 1]);
		msgRemF += "\nSelection2: " + string(_reqComps[1].name) + "\t\t id : " + to_string(_reqComps[1].compIdTab[_reqComps[1].tableNum - 1]) + "\n";

		ruleLog.Write("Remark message: " + msgRemF);
		Pro3dPnt pntArr[2];
		measureDistanceBetweenComponents_F2C02(_reqComps[0], _reqComps[1], clearance_value, pntArr);
		ruleLog.Write("measureDistanceBetweenComponents_F2C02");

		createDistHighlightDatumPoints_F2C02_SP(pntArr[0], "POINT_FROM", "CSYS_ASM_DEF");
		ruleLog.Write("Coordinates of POINT_1: " + to_string(pntArr[0][0]) + to_string(pntArr[0][1]) + to_string(pntArr[0][2]));
		createDistHighlightDatumPoints_F2C02_SP(pntArr[1], "POINT_TO", "CSYS_ASM_DEF");
		ruleLog.Write("Coordinates of POINT_1: " + to_string(pntArr[1][0]) + to_string(pntArr[1][1]) + to_string(pntArr[1][2]));
	}
	else // manual selection of surfaces
	{
		ruleLog.Write("manual selection");

		ruleLog.Write("size of vector: " + to_string(vectorClearance.size()));

		if (vectorClearance.size() < 0) // if size is zero that means no surfaces are selected
		{
			UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			return -1;
		}
		else
		{
			//sort vector in ascending order
			sort(vectorClearance.begin(), vectorClearance.end(), [](const clearanceData& a, const clearanceData& b) {
				return a.clearance < b.clearance;
				});
			ruleLog.Write("sort after");

			//writing remark message
			msgRemF += "Reference surfaces Selected - \n";
			for (int i = 0; i < vectorClearance.size(); i++)
			{
				msgRemF += "Selection" + to_string(i + 1) + ": " + (string)vectorClearance[i].nameOfSel1 + ".PRT (surf. id = " + to_string(vectorClearance[i].id1) + ") and "
					+ (string)vectorClearance[i].nameOfSel2 + ".PRT (surf id = " + to_string(vectorClearance[i].id2) + ") = " + vectorClearance[i].clea + " mm.\n";

				//point creation in case measured clearance is less than 10
				char pointNameFrom[PRO_NAME_SIZE] = "POINT_FROM", pointNameTo[PRO_NAME_SIZE] = "POINT_TO";
				strcat(pointNameFrom, to_string(i + 1).c_str());
				strcat(pointNameTo, to_string(i + 1).c_str());
				ruleLog.Write("point name: " + (string)pointNameTo);
				if (vectorClearance[i].clearance < 40)
				{
					createDistHighlightDatumPoints_F2C02_SP(vectorClearance[i].pntArr[0], pointNameFrom, "CSYS_ASM_DEF");
					createDistHighlightDatumPoints_F2C02_SP(vectorClearance[i].pntArr[1], pointNameTo, "CSYS_ASM_DEF");
					ruleLog.Write("Datum point created");
				}
			}

			//highlighting components 
			/* ***Imp Note - Do not merge following for loop with the above, separated for highlighting purpose.
							 If merged highlighting might face challenges*/
			status = ProWindowRepaint(PRO_VALUE_UNUSED);
			for (int i = 0; i < vectorClearance.size(); i++)
			{
				if (vectorClearance[i].clearance < 40)
				{
					status = ProSelectionHighlight(vectorClearance[i].sel1, PRO_COLOR_ERROR);
					status = ProSelectionHighlight(vectorClearance[i].sel2, PRO_COLOR_ERROR);
				}
			}

			clearance_value = vectorClearance[0].clearance;
		}
	}

	//DECLARE RESULT
	sprintf(remark, "\nmin. Clearance between CBM bracket and EGP/ATS: = %0.2lfmm; Acceptance criteria: minimum 40.00 mm.\n", clearance_value);

	final_res.remark = string(remark) + "\n" + msgRemF;

	if (clearance_value >= 40.0)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	return 0;
}

int createDistHighlightDatumPoints_F2C02_SP(Pro3dPnt pnt_arr, char pointName[PRO_NAME_SIZE], char* csysName)
{
	ruleLog.Write("=================> InterfaceRule::createDatumPoints <=================");
	ProElement	elem_tree, elem_ftype, elem_feature_name,
		pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
		pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
		pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
	ProReference REPDEP_ref1;
	wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE], wDatumPointName2[PRO_NAME_SIZE];
	//CSYS_ASM_DEF
	ProModelitem refCsysitem;
	ProSelection refCsysSel, reqMdlSel;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pnt_feat;
	ProErrorlist errors;
	//converting negative values to positive
	double d1 = -pnt_arr[2];

	//char cDatumPointName[PRO_NAME_SIZE] = "Dist_highlght_pnt";

	ProStringToWstring(wCsysName, csysName);
	status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
	status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);


	//Create Element Tree
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	//feature name
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, L"MY_PNT0");
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
	ruleLog.Write("feature name = " + to_string(status));

	//PRO_E_DPOINT_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
	ruleLog.Write("type status = " + to_string(status));

	//Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);

	//ref
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
	status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
	status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);

	//
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);

	//Populating array element
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);

	//Point1
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);

	//Point1 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);

	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, ProStringToWstring(wDatumPointName, pointName));
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);

	/* =============================================================== *\
	Create Model Selection Object
	\* =============================================================== */

	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Points
	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	status = ProElementFree(&elem_tree);
	status = ProSelectionFree(&reqMdlSel);

	ruleLog.Write("==================function end=================");
	return 0;
}

ProError visitActionF2C02(ProFeature* p_feature, ProError status, vector<ComponentIdTableData>* _reqComps)
{
	ruleLog.Write("====================== visitActionH2D01 =========================");
	ProMdlfileType			comp_type;
	ProFamilyMdlName		comp_name;
	char					part_no[PRO_PATH_SIZE];
	ProAsmcompconstraint* constr_array;
	ProMdl					model;
	ProFeattype				ftype;
	ProAsmcompconstraint	constraint;
	ProAsmcompconstraint* constraints;
	ProPatternStatus 		p_pattern_status;
	ProFeatStatus 			p_status;




	status = ProFeatureTypeGet(p_feature, &ftype);
	ruleLog.Write("ProFeatureTypeGet status: " + to_string(status));

	if (ftype == PRO_FEAT_COMPONENT)
	{
		ruleLog.Write("Component Level = " + to_string(level_cbm));
		status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
		ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));
		ProWstringToString(part_no, comp_name);
		ruleLog.Write("Part name: " + (string)part_no);
		++model_count_cbm;

		feat_id_data  _feat_id_data;

		if (level_cbm == 1) {
			ruleLog.Write("inside if loop level_cbm ==1 ");
			_feat_id_data.feat_ids[0] = p_feature->id;
			_feat_id_data.level = level_cbm;

			feat_id_data_arr_cbm.push_back(_feat_id_data);

		}
		else
		{
			for (int j = 0; j < feat_id_data_arr_cbm.size(); ++j)
			{
				if (feat_id_data_arr_cbm[j].feat_ids[level_cbm - 2] == owner_feat_id_cbm)
				{
					feat_id_data owner_feat_id_data = feat_id_data_arr_cbm[j];
					for (int i = 0; i < level_cbm - 1; ++i)
					{
						_feat_id_data.feat_ids[i] = owner_feat_id_data.feat_ids[i];
					}

					_feat_id_data.feat_ids[level_cbm - 1] = p_feature->id;
					_feat_id_data.level = level_cbm;

					break;
				}

			}

			feat_id_data_arr_cbm.push_back(_feat_id_data);
		}

		ProMdl reqMdl;
		ProMdlType reqMdlType;
		wchar_t wMdlName[PRO_NAME_SIZE];
		char cMdlName[PRO_NAME_SIZE];

		status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
		ruleLog.Write("ProAsmcompMdlGet status: " + to_string(status));

		if (status == PRO_TK_NO_ERROR)
		{
			status = ProMdlMdlnameGet(reqMdl, wMdlName);
			ruleLog.Write("ProMdlMdlnameGet status: " + to_string(status));
			ProWstringToString(cMdlName, wMdlName);
			ruleLog.Write("cMdlName: " + (string)cMdlName);

			ruleLog.Write("reqs_size: " + to_string(_reqComps->size()));
			for (int i = 0; i < _reqComps->size(); ++i)
			{
				/*ruleLog.Write("running for: " + to_string(i) + "th time");*/
				ruleLog.Write("reqs[" + to_string(i) + "].name: " + _reqComps->at(i).name);
				if (strcmp(cMdlName, _reqComps->at(i).name) == 0)
				{
					//Creating ID table for coupling flange
					ProIdTable			comp_id_table;
					int					table_num;
					ProAsmcomppath		p_comp_path;
					table_num = level_cbm;
					_reqComps->at(i).tableNum = table_num;
					ruleLog.Write("the table num is: " + to_string(table_num));

					for (int m = 0; m < level_cbm; ++m) {

						_reqComps->at(i).compIdTab[m] = _feat_id_data.feat_ids[m];
						ruleLog.Write("comp_ID-Table " + to_string(m) + ": " + to_string(_reqComps->at(i).compIdTab[m]));
					}
				}
			}
		}


		if (reqMdlType == PRO_MDL_ASSEMBLY)
		{
			Asm_models[Assy_models_cnt_cbm].Model = model;
			Asm_models[Assy_models_cnt_cbm].Model_feat_id = p_feature->id;
			Assy_models_cnt_cbm += 1;
		}
	}

	return PRO_TK_NO_ERROR;
}

int measureDistanceBetweenComponents_F2C02(ComponentIdTableData reqComp1, ComponentIdTableData reqComp2, double& distance, Pro3dPnt pntArr[2])
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenComponents <=================");

	ProSelection sels[2];

	ProName comp1_name, comp2_name;
	ProModelitem feature[2];
	ProMdl reqMdls[2];

	ProStringToWstring(comp1_name, reqComp1.name);
	//ruleLog.Write("comp1_name: " + (string)reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProStringToWstring(comp2_name, reqComp2.name);
	//ruleLog.Write("comp1_name: " + (string)reqComp2.name);
	status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[1], &feature[1]);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProAsmcomppath path[2];
	status = ProAsmcomppathInit((ProSolid)curMdl, reqComp1.compIdTab, reqComp1.tableNum, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
	status = ProAsmcomppathInit((ProSolid)curMdl, reqComp2.compIdTab, reqComp2.tableNum, &path[1]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));
	status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	ProBoolean is_interference_found;
	Pro2dPnt param_surfs1, param_surfs2;

	/*status = ProSelectionWithOptionsDistanceEval(sels[0], PRO_B_FALSE, sels[1], PRO_B_FALSE, param_surfs1, param_surfs2, pnt1, pnt2, &distance);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(distance));*/

	status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_FROM_FACETS_N_QUILTS, sels[1], PRO_FIT_INCLUDE_TO_FACETS_N_QUILTS, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance, NULL, &is_interference_found, pntArr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));

	ruleLog.Write("Coordinates of the point1: X - " + to_string(pntArr[0][0]) + "\tY - " + to_string(pntArr[0][1]) + "\tZ - " + to_string(pntArr[0][2]));
	ruleLog.Write("Coordinates of the point2: X - " + to_string(pntArr[1][0]) + "\tY - " + to_string(pntArr[1][1]) + "\tZ - " + to_string(pntArr[1][2]));
	/*pntArr[0][0] = pnt1[0];
	pntArr[0][1] = pnt1[1];
	pntArr[0][2] = pnt1[2];
	pntArr[1][0] = pnt2[0];
	pntArr[1][1] = pnt2[1];
	pntArr[1][2] = pnt2[2];*/

	return 0;
}

ProError radioGrpSelectAction_F2C02(char* dialog, char* component, bool* booleanVal)
{
	ruleLog.Write("============== radioGrpSelectAction ==============");
	int radioGrpNames[2];
	char** buttonNames;
	char selectedButton[PRO_NAME_SIZE];
	InterfaceRule iRule;

	//status = ProUIPushbuttonDisable(dialog, PB_OK);
	status = ProUIRadiogroupSelectednamesGet(dialog, component, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status: " + to_string(status));

	//strcpy(selectedButton, buttonNames[0]);
	ruleLog.Write("selected button name: " + (string)buttonNames[0]);
	if (strcmp(buttonNames[0], "rb1") == 0)
	{
		status = ProUILabelHide(dialog, "Label2");
		status = ProUIPushbuttonHide(dialog, "Select1");
		status = ProUILabelHide(dialog, "Label_STR");
		status = ProUIInputpanelHide(dialog, "InputPanel_STR");

		*booleanVal = false;

		status = ProUIPushbuttonEnable(dialog, "CommitOK");
	}
	else if (strcmp(buttonNames[0], "rb2") == 0)
	{
		status = ProUILabelShow(dialog, "Label2");
		status = ProUIPushbuttonShow(dialog, "Select1");
		status = ProUILabelShow(dialog, "Label_STR");
		wchar_t wOffSetVal[PRO_NAME_SIZE];
		ProStringToWstring(wOffSetVal, "0");
		status = ProUIInputpanelValueSet(dialog, "InputPanel_STR", wOffSetVal);
		status = ProUIInputpanelShow(dialog, "InputPanel_STR");
		status = ProUIPushbuttonDisable(dialog, "CommitOK");
		*booleanVal = true;

	}

	return PRO_TK_NO_ERROR;
}

ProError selectActionManualMode_F2C02(char* dialog, char* component, vector<clearanceData>* vectorClearance)
{
	ruleLog.Write("===============selectActionF2C02=================");

	InterfaceRule		iRule;
	ProSelection* surfSels;
	int					surfCount;
	clearanceData		obj;
	vector<ownerInfo>	selDetails;
	selButnCount = 0;

	status = ProUIDialogHide(dialog);
	iRule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Attention!!", "Please select adjacent pair of surfaces on required components that are close to each other");

Begin:
	{
		status = ProWindowRepaint(PRO_VALUE_UNUSED);
		selDetails.clear();
		//selecting surfaces
		status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surfSels, &surfCount);
		ruleLog.Write("ProSelect status: " + to_string(status) + "\nNo. of Selection: " + to_string(surfCount));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIDialogShow(dialog);
			selButnCount--;
			return status;

		}
		if (surfCount < 2) {
			iRule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			status = ProUIDialogShow(dialog);
			selButnCount--;
			return status;
		}
		selButnCount++;

		// storing the owner info of selected surfaces to display in the output window
		ProModelitem		selItem;
		wchar_t				wName[PRO_NAME_SIZE];
		char				cName[PRO_NAME_SIZE];
		ownerInfo			item{};

		for (int i = 0; i < surfCount; i++)
		{
			status = ProSelectionModelitemGet(surfSels[i], &selItem);
			ruleLog.Write("ProSelectionModelitemGet status: " + to_string(status));
			ruleLog.Write("id of selected surface: " + to_string(selItem.id));

			status = ProMdlMdlnameGet(selItem.owner, wName);
			ruleLog.Write("ProMdlMdlnameGet status: " + to_string(status));
			ProWstringToString(cName, wName);
			ruleLog.Write("Owner name: " + (string)cName);

			item.id = selItem.id;
			ruleLog.Write("id stored: " + to_string(item.id));
			strcpy(item.name, cName);
			ruleLog.Write("obj.name copied: " + (string)item.name);
			selDetails.push_back(item);
			ruleLog.Write("obj pushed back");
		}

		//measuring the clearance between selected surfaces
		/*using ProSelectionWithOptionsDistanceEval
		Pro3dPnt			pnt_arr1[2];
		Pro2dPnt			param_surfs[2];
		double				distance;
		status = ProSelectionWithOptionsDistanceEval(surfSels[0], PRO_B_FALSE, surfSels[1], PRO_B_FALSE, param_surfs[0], param_surfs[1], pnt_arr1[0], pnt_arr1[1], &distance);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(distance));
		ruleLog.Write("Coordinates from PSWODE: " + to_string(pnt_arr1[0][0]) + ", " + to_string(pnt_arr1[0][1]) + ", " + to_string(pnt_arr1[0][2]) + ", " + to_string(pnt_arr1[1][0]) + ", " + to_string(pnt_arr1[1][1]) + ", " + to_string(pnt_arr1[1][2]));*/

		//using ProFitClearanceCompute
		ProBoolean			is_interference_found;
		Pro3dPnt			pnt_arr[2];
		double				pntCreationClearance;
		status = ProFitClearanceCompute(surfSels[0], PRO_FIT_INCLUDE_NONE, surfSels[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &pntCreationClearance, NULL, &is_interference_found, pnt_arr);
		ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(pntCreationClearance));
		ruleLog.Write("Coordinates from PFCC: " + to_string(pnt_arr[0][0]) + ", " + to_string(pnt_arr[0][1]) + ", " + to_string(pnt_arr[0][2]) + ", " + to_string(pnt_arr[1][0]) + ", " + to_string(pnt_arr[1][1]) + ", " + to_string(pnt_arr[1][2]));

		//storing the selection for highlighting, selection name & id, point array for point creation 
		if (pntCreationClearance > 0)
		{
			ProSelectionCopy(surfSels[0], &obj.sel1);
			ruleLog.Write("ProSelectionCopy1");
			ProSelectionCopy(surfSels[1], &obj.sel2);
			ruleLog.Write("ProSelectionCopy2");

			strcpy(obj.nameOfSel1, selDetails[0].name);
			ruleLog.Write("strcpy1");
			strcpy(obj.nameOfSel2, selDetails[1].name);
			ruleLog.Write("strcpy2");

			obj.id1 = selDetails[0].id;
			ruleLog.Write("id stored 1");
			obj.id2 = selDetails[1].id;
			ruleLog.Write("id stored 2");

			obj.clearance = pntCreationClearance;
			ruleLog.Write("distance stored");

			obj.clea = to_string(pntCreationClearance);
			obj.clea.erase(obj.clea.find_last_not_of('0'));
			ruleLog.Write("distance remark stored");

			obj.pntArr[0][0] = pnt_arr[0][0];
			obj.pntArr[0][1] = pnt_arr[0][1];
			obj.pntArr[0][2] = pnt_arr[0][2];
			obj.pntArr[1][0] = pnt_arr[1][0];
			obj.pntArr[1][1] = pnt_arr[1][1];
			obj.pntArr[1][2] = pnt_arr[1][2];
			ruleLog.Write("point array stored");

			vectorClearance->push_back(obj);
			ruleLog.Write("pushing back for distance: " + to_string(pntCreationClearance));
		}
		else
		{
			selButnCount--;
		}
	}

	ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
	msg_buttons[0] = PRO_UI_MESSAGE_YES;
	msg_buttons[1] = PRO_UI_MESSAGE_NO;

	string questionMsg;
	questionMsg += "You have selected " + to_string(selButnCount) + " pair of surfaces\nDo you want to add more pairs?";
	user_choice = iRule.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation!!", questionMsg, msg_buttons);
	if (user_choice == PRO_UI_MESSAGE_NO)
	{
		status = ProUIDialogShow(dialog);
		status = ProUIPushbuttonEnable(dialog, "CommitOK");
		selDetails.clear();
		return PRO_TK_NO_ERROR;
	}
	else
	{
		questionMsg.erase();
		goto Begin;
	}


	return PRO_TK_NO_ERROR;
}