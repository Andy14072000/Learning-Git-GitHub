/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-04-2023	| V1_0_0		| F2A02 - FRONT AXLE/LIFT AXLE RULES
==================================================================================================================*/
#include "F2A02.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2A02003		| Mathanprasath A	| MF2A02; MF5A01	| Ensure clearance between Stub Axle and Brake disc.
===================================================================================================================*/
#define DLG_IRF2A02_003 "dlg_IR_F2A02_003"
#define PB_RSELECT		"pb_select"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"
ProSelection* disc_sel;
char cPartName[PRO_NAME_SIZE];
int IRF2A02::IRF2A02_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2A02::IRF2A02_003   ==========================");
	double std_clearance = 4.0;

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_IRF2A02_003, DLG_IRF2A02_003);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2A02_003, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_003, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_003, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_003, PB_RSELECT, (ProUIAction)select_action_IRF2A02_003, NULL);

	ComponentData _reqComps{};
	string reqCompSubMod[1] = { "F2A02" };
	double clearance_value;

	for (int i = 0; i < subModulesList.size(); ++i)
		if (subModulesList[i].name.find(reqCompSubMod[0]) != string::npos)
			strcpy(_reqComps.name, subModulesList[i].name.c_str());

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps);

	ProSelection comp1Sel;
	ProIdTable idtbl1 = { _reqComps.id };
	ProName comp1_name;
	ProModelitem feat1;
	ProMdl reqMdl1;
	ProAsmcomppath path1;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];

	ProStringToWstring(comp1_name, _reqComps.name);
	status = ProMdlnameInit(comp1_name, _reqComps.comp_type, &reqMdl1);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlMdlnameGet(reqMdl1, wFeatName);
	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(cFeatName, wFeatName);
	status = ProMdlToModelitem(reqMdl1, &feat1);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path1);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path1, &feat1, &comp1Sel);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));
	ruleLog.Write("Assembly Name: ");
	ruleLog.Write(cFeatName);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2A02_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF2A02_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	ProBoolean is_interference_found;
	Pro3dPnt pnt_arr[2];
	status = ProFitClearanceCompute(comp1Sel, PRO_FIT_INCLUDE_NONE, disc_sel[0], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, comp1Sel, PRO_B_FALSE, &clearance_value, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tclearance_value: " + to_string(clearance_value));

	clearance_value = round(clearance_value * 100) / 100;


	// DECLARE RESULT
	sprintf(remark, "Measured values = Distance between %s.asm and %s.prt is %.2lf mm.; Acceptance criteria: Clearance Between Stub Axle and Brake disc should be equal or greater than %.2lf mm.", cFeatName, cPartName, clearance_value, std_clearance);
	final_res.remark = string(remark);

	if (clearance_value >= std_clearance)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	return 0;
}

ProError select_action_IRF2A02_003(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRF2A02_003  --------------------------");
	int n_sels;
	char cFeatName[PRO_NAME_SIZE];
	ProModelitem prtmdlitem;
	ProMdl prtMdl;
	wchar_t wPartName[PRO_NAME_SIZE];

	status = ProSelect((char*)"part", 1, NULL, NULL, NULL, NULL, &disc_sel, &n_sels);
	InterfaceRule _irule;
	if (status == PRO_TK_USER_ABORT)
	{
		//_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}
	else if (n_sels < 1 || status != PRO_TK_NO_ERROR)
	{
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}
	

	status = ProSelectionModelitemGet(disc_sel[0], &prtmdlitem);
	status = ProModelitemMdlGet(&prtmdlitem, &prtMdl);
	status = ProMdlMdlnameGet(prtMdl, wPartName);
	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(cPartName, wPartName);
	ruleLog.Write("PartName: ");
	ruleLog.Write(cPartName);
	if (status == PRO_TK_NO_ERROR && n_sels > 0) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	}

	return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2A02004		| Himanshu Pachpute	| MF2A02; MF5A01	| Ensure clearance between Stub Axle and Brake Caliper.
===================================================================================================================*/

#define DLG_IRF2A02_004 "dlg_IR_F2A02_004"
#define PB_RSELECT		"pb_select"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"

ProSelection* axle_caliper_surfSels;

int IRF2A02::IRF2A02_004(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2A02::IRF2A02_004   ==========================");

	isUserQuits = false;
	double clearance_value{};
	double std_clearance{ 4.0 };

	status = ProUIDialogCreate(DLG_IRF2A02_004, DLG_IRF2A02_004);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2A02_004, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_004, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_004, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_004, PB_RSELECT, (ProUIAction)select_action_IRF2A02_004, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2A02_004, &dlg_sts);
	status = ProUIDialogDestroy(DLG_IRF2A02_004);
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	ProBoolean interf;
	Pro3dPnt coord[2];
	status = ProFitClearanceCompute(axle_caliper_surfSels[0], PRO_FIT_INCLUDE_NONE, axle_caliper_surfSels[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearance_value, NULL, &interf, coord);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status));
	clearance_value = round(clearance_value);

	sprintf(remark, "Measured value: %.2lfmm; Acceptance criteria: Clearance greater than %.2lfmm.", clearance_value, std_clearance);
	final_res.remark = string(remark);

	if (clearance_value > std_clearance)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	return 0;
}

ProError select_action_IRF2A02_004(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF4B02004 -----------------------------");
	int n_sel;
	InterfaceRule _irule;
	int curWinId;
	axle_caliper_surfSels = nullptr;

	status = ProWindowCurrentGet(&curWinId);
	ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

	status = ProWindowRepaint(curWinId);
	ruleLog.Write("ProWindowRepaint: " + to_string(status));

	status = ProSelect("point,edge,datum,surface", 2, NULL, NULL, NULL, NULL, &axle_caliper_surfSels, &n_sel);
	ruleLog.Write("Proselect status: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel));
	if (status == PRO_TK_NO_ERROR && n_sel > 0) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));
	}

	if (n_sel < 2 || status != PRO_TK_NO_ERROR) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));
	}

	return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER				| DEPENDENT MODULES					| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F2A02-007	| Himanshu Pachpute		| MF2A02; MF2A05; MF5A01; MF5A02	| Ensure Gap between Brake Cover plate & Knuckle/Tie rod arm.
===================================================================================================================*/

#define DLG_IRF2A02_007 "dlg_IR_F2A02_007"
#define PB_RSELECT		"pb_select"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"

class SelectionData {
public:
	ProSelection	Surf_Comp_Selection{};
	int				ID{};
	char			Name[300]{};
	char			Description[300]{};
	string	        IdType{};
};



vector<SelectionData>	ProSVect{};

int IRF2A02::IRF2A02_007(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2A02::IRF2A02_007   ==========================");

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_IRF2A02_007, DLG_IRF2A02_007);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));

	status = ProUIDialogAboveactivewindowSet(DLG_IRF2A02_007, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_007, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_007, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_007, PB_RSELECT, (ProUIAction)select_action_IRF2A02_007, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogHide: " + to_string(status));

	status = ProUIDialogActivate(DLG_IRF2A02_007, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	status = ProUIDialogDestroy(DLG_IRF2A02_007);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

	status = ProUIDialogShow(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogShow: " + to_string(status));

	if (isUserQuits)
		return -1;

	vector<double> ClearanceVect{};
	string CompString = "Clearance between \n";
	for (size_t n = 0; n < ProSVect.size(); n += 2) {
		if (n + 1 < ProSVect.size()) {
			ruleLog.Write(to_string(ProSVect[n].ID));
			ProBoolean interf{};
			Pro3dPnt coord[2]{};
			double clearance_value{};
			status = ProFitClearanceCompute(ProSVect[n].Surf_Comp_Selection, PRO_FIT_INCLUDE_NONE, ProSVect[n + 1].Surf_Comp_Selection, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearance_value, NULL, &interf, coord);
			ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\t" + to_string(ProSVect[n].ID) + " & " + to_string(ProSVect[n + 1].ID) + "\t Clearance_Value: " + to_string(clearance_value));

			CompString += " \t" + string(ProSVect[n].Name) + " [" + string(ProSVect[n].Description) + "] [" + ProSVect[n].IdType + ": " + to_string(ProSVect[n].ID) + "] and \n\t\t\t\t" + string(ProSVect[n + 1].Name) + " [" + string(ProSVect[n + 1].Description) + "] [" + ProSVect[n + 1].IdType + ": " + to_string(ProSVect[n + 1].ID) + "]: " + doubleToString(clearance_value) + "mm.\n\n";

			ClearanceVect.push_back(clearance_value);
		}
	}

	double std_clearance{ 5.00 };
	bool conditioncheck{ false };
	for (int m = 0; m < ClearanceVect.size(); m++) {
		if (ClearanceVect[m] < std_clearance) {
			conditioncheck = true;
			break;
		}
	}

	CompString += "\nAcceptance criteria : Gap/Clearances needs to be > 5mm";

	final_res.remark = CompString;

	if (conditioncheck == false)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	ProSVect.clear();
	ClearanceVect.clear();
	return 0;
}

ProError select_action_IRF2A02_007(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF2A02_007 -----------------------------");

	InterfaceRule _irule{};
	int curWinId{};
	int	n_sel1{}, n_sel2{};
	ProSVect.clear();

	status = ProWindowCurrentGet(&curWinId);
	ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

	status = ProWindowRepaint(curWinId);
	ruleLog.Write("ProWindowRepaint: " + to_string(status));

	for (int i = 0; i < 5; i++) {

		SelectionData SelecData1{}, SelecData2{};
		ProSelection* ProCompSel1 = nullptr, * ProSurfSel2 = nullptr;

		if (i < 3) {
			status = ProSelect("part", 1, NULL, NULL, NULL, NULL, &ProCompSel1, &n_sel1);
			ruleLog.Write("Proselect status: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel1));

			SelecData1.IdType = "Part Feat ID";
		}
		else {
			status = ProSelect("surface", 1, NULL, NULL, NULL, NULL, &ProCompSel1, &n_sel1);
			ruleLog.Write("Proselect status: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel1));

			SelecData1.IdType = "Surface Feat ID";
		}

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIDialogShow(DLG_IRF2A02_007);
			ruleLog.Write("ProUIDialogShow: " + to_string(status));
			break;
		}
		else if (n_sel1 < 1 && status != PRO_TK_USER_ABORT) {
			_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			goto exit;
		}

		status = ProSelectionCopy(ProCompSel1[0], &SelecData1.Surf_Comp_Selection);
		ruleLog.Write("ProSelectionCopy: " + to_string(status));

		ProModelitem mdlitem{};
		status = ProSelectionModelitemGet(ProCompSel1[0], &mdlitem);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status) + "\tFeatID: " + to_string(mdlitem.id));

		if (mdlitem.type == PRO_PART || mdlitem.type == PRO_ASSEMBLY) {
			ProAsmcomppath comppath{};
			status = ProSelectionAsmcomppathGet(ProCompSel1[0], &comppath);
			ruleLog.Write("ProSelectionCopy: " + to_string(status));

			int temp = comppath.comp_id_table[comppath.table_num - 1];
			ruleLog.Write("temp: " + to_string(temp));
			SelecData1.ID = temp;
		}
		else {
			SelecData1.ID = mdlitem.id;
		}

		ProModelitem modelitem{};
		status = ProMdlToModelitem(mdlitem.owner, &modelitem);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		if (modelitem.type == PRO_PART || modelitem.type == PRO_ASSEMBLY) {
			ProName      pDescName = L"DESCRIPTION";
			ProParameter pDesc;
			status = ProParameterInit(&modelitem, pDescName, &pDesc);
			ruleLog.Write("ProParameterInit: " + to_string(status));

			ProParamvalue pvDesc;
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));
			ProWstringToString(SelecData1.Description, pvDesc.value.s_val);
			ruleLog.Write("Description: " + string(SelecData1.Description));
		}

		wchar_t MdlName{};
		status = ProMdlMdlnameGet(mdlitem.owner, &MdlName);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

		ProWstringToString(SelecData1.Name, &MdlName);
		ruleLog.Write("SelecData1.Name: " + string(SelecData1.Name));

		status = ProSelect("surface", 1, NULL, NULL, NULL, NULL, &ProSurfSel2, &n_sel2);
		ruleLog.Write("Proselect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel2));

		SelecData2.IdType = "Surface Feat ID";

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIDialogShow(DLG_IRF2A02_007);
			ruleLog.Write("ProUIDialogShow: " + to_string(status));
			break;
		}
		else if (n_sel2 < 1 && status != PRO_TK_USER_ABORT) {
			_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			goto exit;
		}

		status = ProSelectionCopy(ProSurfSel2[0], &SelecData2.Surf_Comp_Selection);
		ruleLog.Write("ProSelectionCopy: " + to_string(status));

		ProModelitem mdlitem1{};
		status = ProSelectionModelitemGet(ProSurfSel2[0], &mdlitem1);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status) + "\tFeatID: " + to_string(mdlitem1.id));
		SelecData2.ID = mdlitem1.id;

		ProModelitem modelitem1{};
		status = ProMdlToModelitem(mdlitem1.owner, &modelitem1);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		if (modelitem1.type == PRO_PART || modelitem1.type == PRO_ASSEMBLY) {
			ProName      pDescName1 = L"DESCRIPTION";
			ProParameter pDesc1;
			status = ProParameterInit(&modelitem1, pDescName1, &pDesc1);
			ruleLog.Write("ProParameterInit: " + to_string(status));

			ProParamvalue pvDesc1;
			status = ProParameterValueWithUnitsGet(&pDesc1, &pvDesc1, NULL);
			ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));
			ProWstringToString(SelecData2.Description, pvDesc1.value.s_val);
			ruleLog.Write("Description: " + string(SelecData2.Description));
		}

		wchar_t MdlName1{};
		status = ProMdlMdlnameGet(mdlitem1.owner, &MdlName1);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

		ProWstringToString(SelecData2.Name, &MdlName1);
		ruleLog.Write("SelecData1.Name: " + string(SelecData2.Name));

		ProSVect.push_back(SelecData1);
		ProSVect.push_back(SelecData2);
	}

	if (status == PRO_TK_NO_ERROR && n_sel1 > 0 && n_sel2 > 0) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));
	}

	if (n_sel1 < 1 || n_sel2 < 1 || status != PRO_TK_NO_ERROR) {
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));
	}

exit:
	return status;
}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	                | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2A02008  	| Vinay Neel    	| MF2A02; MF2A01; MF2A03; MF5A15	| Ensure Gap of Brake chamber mounting bracket with beam , stub axle & STEERING ARM
===================================================================================================================*/

#define DLG_IRF2A02_008 "dlg_IR_F2A02_008"
#define PB_ROK			"pb_run"
#define PB_RCANCEL		"CommitCancel"
#define PB_RSELECT		"pb_select"
ProSelection* mtgBkt_Surfsel;

int IRF2A02::IRF2A02_008(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2A02::IRF2A02_008   ==========================");
	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	ComponentData _reqComps[4]{};
	string reqCompSubMod[4] = { "F2A02","F2A01", "F2A03", "F5A01"};//MF2A02; MF2A01; MF2A03; MF5A15
	double clearance_values[3], std_clearance = 10.0;
	

	for (int i = 0; i < subModulesList.size(); ++i)
		for (int j = 0; j < 4; ++j)
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
				strcpy(_reqComps[j].name, subModulesList[i].name.c_str());

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

	for (auto elem : _reqComps) {
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF2A02_008, DLG_IRF2A02_008);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2A02_008, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_008, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_008, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_008, PB_RSELECT, (ProUIAction)select_action_IRF2A02_008, NULL);

	status = ProUIPushbuttonDisable(DLG_IRF2A02_008, PB_ROK);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2A02_008, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF2A02_008);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

		rule_sts = measureDistanceBetweenAsmAndPart_F2A02_008(_reqComps[0], &mtgBkt_Surfsel[0], clearance_values[0]);
		rule_sts = measureDistanceBetweenAsmAndPart_F2A02_008(_reqComps[1], &mtgBkt_Surfsel[0], clearance_values[1]);
		rule_sts = measureDistanceBetweenAsmAndPart_F2A02_008(_reqComps[2], &mtgBkt_Surfsel[0], clearance_values[2]);

	for(int i = 0; i < 3; i++) {
		if (clearance_values[i] <= std_clearance) {
			 highlightParts(_reqComps[i], PRO_COLOR_HIGHLITE);
		}
	}


	for (int i = 0; i < 3; i++) {
		clearance_values[i] = round(clearance_values[i] * 100) / 100;
	}


	ProAsmcomppath comp_path, comppath;
	ProFeature feature;
	ProMdl model;
	ProMdlName		wname;
	char            cname[PRO_MDLNAME_SIZE];

	
	status = ProSelectionAsmcomppathGet(mtgBkt_Surfsel[0], &comppath);
	ruleLog.Write("ProSelectionAsmcomppathGet status: " + to_string(status));

	/*
	for (int i = 0; i < (comppath.table_num); i++) {
		ruleLog.Write("Selected Surface part id: " + to_string(comppath.comp_id_table[i]));
	}
	status = ProAsmcomppathMdlGet(&comppath, &model);
	ruleLog.Write("ProAsmcomppathMdlGet status: " + to_string(status));

	status = ProMdlMdlnameGet(model, wname);
	ruleLog.Write("ProMdlMdlnameGet status: " + to_string(status));

	ProWstringToString(cname, wname);
	ruleLog.Write("model_names: " + string(cname));
	*/

	//Get the id of selected surface
	status = ProSelectionModelitemGet(mtgBkt_Surfsel[0], &feature);
	status = ProMdlMdlnameGet(feature.owner, wname);
	ProWstringToString(cname, wname);
	ruleLog.Write("model_names: " + string(cname));


	// DECLARE RESULT
	sprintf(remark, "Measured values :\nClearance between Mounting bracket and \n -%s.ASM (Stub Axle) : %.2lf mm, \n -%s.ASM (Axle Beam) : %.2lf mm,\n -%s.ASM (Steering Arm) : %.2lf mm; \nAcceptance criteria: > %.2lf mm; \nUsed Reference part : %s.PRT (Surf. Id : %s)", _reqComps[0].name, clearance_values[0], _reqComps[1].name, clearance_values[1], _reqComps[2].name, clearance_values[2], std_clearance, (string(cname)).c_str(), (to_string(feature.id)).c_str());
	final_res.remark = string(remark);

	isRightValue = true;
	for(auto vals : clearance_values) {
		if (vals < std_clearance) {
			isRightValue = false;
			break;
		}
	}

	if(isRightValue)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	
	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	return 0;
}

ProError select_action_IRF2A02_008(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRF2A02_008  --------------------------");
	int n_sels;
	status = ProSelect((char*)"surface", 1, NULL, NULL, NULL, NULL, &mtgBkt_Surfsel, &n_sels);
	if (status == PRO_TK_NO_ERROR && n_sels > 0) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	}

	return status;
}

int measureDistanceBetweenAsmAndPart_F2A02_008(ComponentData reqComp1, ProSelection* Part_sel, double& distance)
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenAsmAndPart <=================");
	ProSelection sels[1];
	ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected
	ProName comp1_name;
	ProModelitem feature[1];
	ProMdl reqMdls[1];

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProAsmcomppath path[1];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));


	////ProSelection* Part_sel;
	//int n_sels;
	//status = ProSelect((char*)"prt_or_asm", 1, NULL, NULL, NULL, NULL, &Part_sel, &n_sels);
	//ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels));

	ProBoolean is_interference_found;
	Pro3dPnt pnt_arr[1];
	status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_NONE, *Part_sel, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, sels[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));

	return 0;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2A02009		| Surendra Sarode	| MF2A02; MF2A04; MF5A01; MF5A02	| Ensure Gap between Hub/Stub axle and Brake shoe rim /Web /spring.
===================================================================================================================*/

#define DLG_IRF2A02_009 "dlg_IR_F2A02_009"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"
#define PB_RSELECT1		"pb_select1"
#define PB_RSELECT2		"pb_select2"

ProSelection SurfSelections1, SurfSelections2, SurfSelections3, SurfSelections4;
//ProSelection SurfSelections2;


int IRF2A02::IRF2A02_009(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2A02::IRF2A02_009   ==========================");

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF2A02_009, DLG_IRF2A02_009);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2A02_009, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_009, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_009, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_009, PB_RSELECT1, (ProUIAction)select_action_IRF2A02_009_01, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A02_009, PB_RSELECT2, (ProUIAction)select_action_IRF2A02_009_02, NULL);

	status = ProUIPushbuttonDisable(DLG_IRF2A02_009, PB_ROK);
	status = ProUIPushbuttonDisable(DLG_IRF2A02_009, PB_RSELECT2);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2A02_009, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF2A02_009);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	double Clearance1, Clearance2;
	double minValue = 5;

	status = computeClearanceBetweenSurfaces(SurfSelections1, SurfSelections2, Clearance1);
	Clearance1 = round(Clearance1 * 100) / 100;	// rounding the value to two decimal places
	ruleLog.Write("Distance between Hub axle and Brake shoe Rim/Web/Spring: " + to_string(Clearance1));

	status = computeClearanceBetweenSurfaces(SurfSelections3, SurfSelections4, Clearance2);
	Clearance2 = round(Clearance2 * 100) / 100;	// rounding the value to two decimal places
	ruleLog.Write("Distance between Stub axle and Brake shoe Rim/Web/Spring: " + to_string(Clearance2));

	ProModelitem mdlitem[4];
	ProMdl Mdl[4];
	ProMdlName nameget[4];
	char mdlnames[PRO_NAME_SIZE];
	vector<int> surId;
	vector<string> names;

	status = ProSelectionModelitemGet(SurfSelections1, &mdlitem[0]);
	status = ProSelectionModelitemGet(SurfSelections2, &mdlitem[1]);
	status = ProSelectionModelitemGet(SurfSelections3, &mdlitem[2]);
	status = ProSelectionModelitemGet(SurfSelections4, &mdlitem[3]);

	for (int i = 0; i < 4; i++) {

		status = ProModelitemMdlGet(&mdlitem[i], &Mdl[i]);
		ruleLog.Write("ProModelitemMdlGet: " + to_string(status));
		status = ProMdlMdlnameGet(Mdl[i], nameget[i]);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
		ProWstringToString(mdlnames, nameget[i]);
		ruleLog.Write("ProMdlMdlnameGet: " + string(mdlnames));
		surId.push_back(mdlitem[i].id);
		names.push_back(mdlnames);
		ruleLog.Write("surId: " + to_string(mdlitem[i].id));
	}

	if (status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT) {
		UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selected surfaces.");
		return -1;
	}

	sprintf(remark, "Measured value between Hub axle (Part No.:%s, Surface Id: %s) and\nBrake shoe Rim/Web/Spring (Part No.:%s, Surface Id: %s) = %0.2lfmm, \n\nMeasured value between Stub axle (Part No.:%s, Surface Id: %s) and\nBrake shoe Rim/Web/Spring (Part No.:%s, Surface Id: %s) = %0.2lfmm, \n\nAcceptance criteria: > %0.2lfmm.", names[0].c_str(), to_string(surId[0]).c_str(), names[1].c_str(), to_string(surId[1]).c_str(), Clearance1, names[2].c_str(), to_string(surId[2]).c_str(), names[3].c_str(), to_string(surId[3]).c_str(), Clearance2, minValue);
	final_res.remark = string(remark);

	// DECLARE RESULT
	if (Clearance1 > minValue && Clearance2 > minValue) {
		final_res.result = "PASS";
	}
	else {
		final_res.result = "FAIL";
	}

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	surId.clear();
	names.clear();

	return 0;
}

ProError select_action_IRF2A02_009_01(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRF2A02_009_01  --------------------------");
	int n_sels1;
	ProSelection* HubaxleSel;
	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &HubaxleSel, &n_sels1);
	status = ProSelectionCopy(HubaxleSel[0], &SurfSelections1);
	status = ProSelectionCopy(HubaxleSel[1], &SurfSelections2);
	if (status == PRO_TK_NO_ERROR && n_sels1 > 0) {
		status = ProUIPushbuttonEnable(dialog, PB_RSELECT2);
	}

	return status;
}

ProError select_action_IRF2A02_009_02(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRF2A02_009_02  --------------------------");
	int n_sels2;
	ProSelection* StubaxleSel;
	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &StubaxleSel, &n_sels2);
	status = ProSelectionCopy(StubaxleSel[0], &SurfSelections3);
	status = ProSelectionCopy(StubaxleSel[1], &SurfSelections4);
	if (status == PRO_TK_NO_ERROR && n_sels2 > 0) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	}

	return status;
}

#pragma pop