﻿/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 18-04-2023	| V1_0_0		| A1B01 - CARGO BODY RULES
==================================================================================================================*/
#include "A1B01.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
/*==================================================================================================================
RULE ID			| DEVELOPER		| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRA1B01005		| Ved Aiyar		| MA1B01			| Optimize the overall width of loadbodies to control the variants 
===================================================================================================================*/
#define DLG_IRA1B01_005 "dlg_IR_A1B01_005"
#define PB_RSELECT		"select_pb"
#define PB_ROK			"CommitOK"
#define PB_RCANCEL		"CommitCancel"
ProSelection* cargoBodySurfSels;

int IRA1B01::IRA1B01_005(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRA1B01::IRA1B01_005   ==========================");
	double cargobodyWidth;
	string outputstr = "";


	for (int i = 0; i < subModulesList.size(); ++i)
	{
		if (subModulesList[i].name.find("A1B01") != std::string::npos)
		{
			_reqSMinfo = subModulesList[i];
			break;
		}
	}
	project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
	ruleLog.Write("Project Code: " + to_string(project_code));

	/*vector<int> reqValsFromCsv;
	getReqValsFrom2DCsvData("IRA1B01005.csv", 2, 3, project_code, reqValsFromCsv);*/
	vector<string> reqValsFromCsv;
	getReqValsFrom2DCsvData("IRA1B01005.csv", 2, 3, project_code, reqValsFromCsv);

	for (const std::string& value : reqValsFromCsv)
	{
		ruleLog.Write(value);
	}

	status = ProUIDialogCreate(DLG_IRA1B01_005, DLG_IRA1B01_005);
	status = ProUIDialogAboveactivewindowSet(DLG_IRA1B01_005, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRA1B01_005, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRA1B01_005, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRA1B01_005, PB_RSELECT, (ProUIAction)select_action_IRA1B01_005, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRA1B01_005, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRA1B01_005);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	status = measureDistanceBetweenSurfaces(cargoBodySurfSels[0], cargoBodySurfSels[1], cargobodyWidth);
	cargobodyWidth = round(cargobodyWidth * 100) / 100;	// rounding the value to two decimal places

	if (status != PRO_TK_NO_ERROR)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selected surfaces.");
		return -1;
	}
	outputstr = "Measured value = " + doubleToString(cargobodyWidth) + "mm;Acceptance criteria = ";


	//cargobodyWidth = 2254;
	std::string result;

	for (size_t i = 0; i < reqValsFromCsv.size(); ++i)
	{
		result += reqValsFromCsv[i] + ".00";
		if (i != reqValsFromCsv.size() - 1)
		{
			result += ", ";
		}
	}
	outputstr.append(result + "mm\n");
	outputstr.append("\nNote: A Tolerance of +/-10.00mm is accepted.");

	for (auto val : reqValsFromCsv)
	{
		if (cargobodyWidth<(stod(val) + 10) && cargobodyWidth>(stod(val) - 10))
		{
			isRightValue = true;
		}
	}


	//sprintf(remark, "Measured value = %0.2lfmm; Acceptance criteria = %0.2lfmm.", cargobodyWidth, stod(acceptance_criteria));

	// DECLARE RESULT
	if (isRightValue)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	final_res.remark = string(outputstr);

	ruleLog.Write("final_res.status: " + string(final_res.result));
	ruleLog.Write("final_res.remark: " + string(final_res.remark));

	reqValsFromCsv.clear();
	return 0;
}

ProError select_action_IRA1B01_005(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRA1B01_005  --------------------------");
	status = ProUIDialogHide(dialog);

	int n_sels;
	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &cargoBodySurfSels, &n_sels);
	//status = ProUIDialogHide(dialog);


	if (status == PRO_TK_NO_ERROR && n_sels > 0)
	{
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	}
	status = ProUIDialogShow(dialog);

	return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER		        | DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRA1B01007		| Prajakta Bhelawe		| MA1B01			| Standardize and fix loadbody start positions for each cab
===================================================================================================================*/
//manual
#define DLG_IRA1B01_007 "dlg_IR_A1B01_007"
#define PB_RSELECT		"pb_select"
#define PB_ROK			"Commit_Ok"
#define PB_RCANCEL		"Commit_Cancel"
#define Select1			"Select1"
#define Select2			"Select2"

int n_selectionA1BO1_1, n_selectionA1BO1_2;
vector<string>  name_asmA1B01;
double clearanceA1B01;
ProSelection selectionA1B01_copy1;
ProSelection selectionA1B01_copy2;
vector<string> asmModuleNames;
string tokenA1B01 = "A1B01";

int IRA1B01::IRA1B01_007(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRA1B01::IRA1B01_007   ==========================");
	isUserQuits = false;
	string lbRemark;
	vector<string> loadbodyFACLDistance;
	vector<string> subModuleList;
	boolean loadBodyPartNoFound = false;
	string loadBodyPart;
	ProMdlName wname;
	char str_name[PRO_NAME_SIZE];

	lbRemark.clear();

	status = ProMdlMdlnameGet(curMdl, wname);
	ruleLog.Write("ProMdlMdlnameGet = " + to_string(status));
	string curMdlName = ProWstringToString(str_name, wname);
	ruleLog.Write("curMdlName = " + curMdlName);

	if (curMdlName.find(tokenA1B01) != string::npos)
		asmModuleNames.push_back(curMdlName);

	else {
		status = ProSolidFeatVisit((ProSolid)curMdl, asm_retrieve_callback, NULL, NULL);
		ruleLog.Write("ProSolidFeatVisit = " + to_string(status));
	}

	loadBodyPart = asmModuleNames[0];
	ruleLog.Write("loadBodyPart = " + loadBodyPart);

	vector<vector<string>> dbList2D = getData2D("IRA1B01007.csv");
	//ruleLog.Write("dbList2D.size(): " + to_string(dbList2D.size()));

	for (int i = 0; i < dbList2D.size(); i++)
	{
		//ruleLog.Write("dbList2D["+to_string(i)+"][0] = " + dbList2D[i][0]);
		subModuleList.push_back(dbList2D[i][0]);
	}

	//ruleLog.Write("subModuleList = " + to_string(subModuleList.size()));
	for (int i = 0; i < subModuleList.size(); i++)
	{
		if (loadBodyPart == subModuleList[i]) {
			ruleLog.Write("Inside if ");
			loadbodyFACLDistance.push_back(dbList2D[i][1]);
			ruleLog.Write("dbList2D[i][1] =" + dbList2D[i][1]);
			loadBodyPartNoFound = true;
			ruleLog.Write("loadBodyPartNoFound = " + to_string(loadBodyPartNoFound));
			break;
		}
	}

	if (loadBodyPartNoFound == false)
	{
		lbRemark += "SUBMODULE NOT FOUND. PLEASE UPDATE THE DATABASE ";
		final_res.remark = lbRemark;
		final_res.result = "FAIL";
		return 0;
	}

	status = ProUIDialogCreate(DLG_IRA1B01_007, DLG_IRA1B01_007);
	status = ProUIDialogAboveactivewindowSet(DLG_IRA1B01_007, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRA1B01_007, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRA1B01_007, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRA1B01_007, Select1, (ProUIAction)selectActionA1B01_007, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRA1B01_007, Select2, (ProUIAction)selectActionA1B01_007_2, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRA1B01_007, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRA1B01_007);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	if (n_selectionA1BO1_1 < 0 && n_selectionA1BO1_2 < 0)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		return -1;
	}

	else
	{
		Pro2dPnt uv1a, uv2a;
		Pro3dPnt xyz1a, xyz2a;

		status = ProSelectionWithOptionsDistanceEval(selectionA1B01_copy1, PRO_B_FALSE, selectionA1B01_copy2, PRO_B_FALSE, uv1a, uv2a, xyz1a, xyz2a, &clearanceA1B01);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval " + to_string(status));
		ruleLog.Write("clearanceA1B01 " + to_string(clearanceA1B01));

		double rounded_number = std::round(clearanceA1B01 * 100.0) / 100.0;
		ruleLog.Write("clearanceA1B01 " + to_string(clearanceA1B01) + "mm.");

		string strClearanceA1B01;
		strClearanceA1B01 = to_string(clearanceA1B01);

		string result;
		size_t dotPos = strClearanceA1B01.find('.');

		if (dotPos != std::string::npos) {
			// Check if there are at least two characters after the decimal point
			if (dotPos + 3 <= strClearanceA1B01.size()) {
				result = strClearanceA1B01.substr(0, dotPos + 3);  // Include the dot and two characters after
			}
			else {
				// Less than two characters after the decimal point
				result = strClearanceA1B01.substr(0, dotPos + 1);  // Include only up to the decimal point
			}
		}
		else {
			// No decimal point found
			result = strClearanceA1B01;
		}

		lbRemark += "Clearance between " + string(name_asmA1B01[0]) + ".PRT and ASM_YZ plane";

		ruleLog.Write("result " + (result));
		lbRemark += " = " + (result)+"mm.";
		lbRemark += "\n\nAcceptance criteria: Clearance between Load body start position and FACL plane \nfor " + loadBodyPart + " = " + loadbodyFACLDistance[0] + ".00mm within a tolerance of \u00B150mm";
		ruleLog.Write("lbRemark = " + lbRemark);
		double tolerance = 50.0;
		if (abs(stod(loadbodyFACLDistance[0]) - stod(result)) <= tolerance)
		{
			final_res.result = "PASS";
		}

		else
		{
			final_res.result = "FAIL";
		}
	}
	final_res.remark = lbRemark;

	name_asmA1B01.clear();
	lbRemark.clear();
	loadBodyPartNoFound = false;
	loadbodyFACLDistance.clear();
	subModuleList.clear();
	dbList2D.clear();
	asmModuleNames.clear();
	loadBodyPart.clear();

	return 0;
}

ProError selectActionA1B01_007(char* dialog, char* component, ProAppData appD)
{
	ruleLog.Write("===============selectActionA1B01_007=================");

	ProSelection* selectionA1B01_1 = nullptr;

	status = ProSelect((char*)"prt_or_asm", 1, NULL, NULL, NULL, NULL, &selectionA1B01_1, &n_selectionA1BO1_1);
	ruleLog.Write("Proselect status= " + to_string(status) + "\nNo.of Selection " + to_string(n_selectionA1BO1_1));

	status = ProSelectionCopy(selectionA1B01_1[0], &selectionA1B01_copy1);

	if (status == PRO_TK_NO_ERROR && n_selectionA1BO1_1 == 1) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	}

	for (int i = 0; i < n_selectionA1BO1_1; i++)
	{
		ProModelitem part_model_item;
		ProName name;
		char str_name[PRO_NAME_SIZE];
		ProModelitem parent_model_item;
		ProParameter pDesc;
		ProParamvalue pvDesc;
		ProName pDescName = L"DESCRIPTION";
		char existingPval[PRO_LINE_SIZE]{};

		status = ProSelectionModelitemGet(selectionA1B01_1[i], &part_model_item);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

		status = ProMdlMdlnameGet(part_model_item.owner, name);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

		ProWstringToString(str_name, name);
		ruleLog.Write("str_name = " + string(str_name));

		status = ProMdlToModelitem(part_model_item.owner, &parent_model_item);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&parent_model_item, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit status = " + to_string(status));
		if (status != PRO_TK_E_NOT_FOUND)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ruleLog.Write("ProParameterValueWithUnitsGet status = " + to_string(status));
			ProWstringToString(existingPval, pvDesc.value.s_val);
		}
		name_asmA1B01.push_back(str_name);
	}
	return PRO_TK_NO_ERROR;
}

ProError selectActionA1B01_007_2(char* dialog, char* component, ProAppData appD)
{
	ruleLog.Write("----------------------------- selectPlane -----------------------------");
	ProSelection* selectionA1B01_2 = nullptr;

	status = ProSelect((char*)"datum", 1, NULL, NULL, NULL, NULL, &selectionA1B01_2, &n_selectionA1BO1_2);
	ruleLog.Write("Proselect status= " + to_string(status) + "\nNo.of Selection " + to_string(n_selectionA1BO1_2));

	status = ProSelectionCopy(selectionA1B01_2[0], &selectionA1B01_copy2);

	if (status == PRO_TK_NO_ERROR && n_selectionA1BO1_2 == 1) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	}

	return PRO_TK_NO_ERROR;
}

ProError asm_retrieve_callback(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	//mainLog.Write("================================ submodule_retrieve_callback ================================");

	ProFeattype feat_type;
	status = ProFeatureTypeGet(p_feature, &feat_type);
	if (feat_type == PRO_FEAT_COMPONENT)
	{
		ProMdl subModuleMdl;
		status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &subModuleMdl);

		ProMdlType subModuleMdlType;
		status = ProMdlTypeGet(subModuleMdl, &subModuleMdlType);

		wchar_t wFeatName[PRO_NAME_SIZE];
		char cFeatName[PRO_NAME_SIZE];
		status = ProMdlMdlnameGet(subModuleMdl, wFeatName);
		ProWstringToString(cFeatName, wFeatName);

		string cFeatNameStr = cFeatName;
		ruleLog.Write("cFeatNameStr = " + cFeatNameStr);
		if (subModuleMdlType == PRO_MDL_ASSEMBLY && cFeatNameStr.find(tokenA1B01) != std::string::npos) {
			asmModuleNames.push_back(cFeatName);
		}
	}
	return PRO_TK_NO_ERROR;
}
#pragma pop