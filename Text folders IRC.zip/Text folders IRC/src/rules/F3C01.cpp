/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
Mathanprasath A	| 06-09-2024	|	V1_0_0		| F3C01 - Engine Mounts
==================================================================================================================*/

#include "F3C01.h"

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF3C01_008     | Mathanprasath A	|MF3C03; MF3C04; MF1A01	|For all the standardized frame width, LH arm of mounting bracket distance from frame to be standardized.
===================================================================================================================*/
#define DLG_IRF3C01_008     "dlg_IR_F3C01_008"
#define CommitOK            "CommitOK"
#define CommitCancel		"CommitCancel"
#define PB_SELECT           "select_pb"
#define PB_SELECT_2         "select_pb2"

//Global Declaration of Remarks and Pitch values.
string Selection_F3C01_008;
string remark_F3C01_008;
//bool RightValue1{};
double  R_VP, R_HP;
double  L_VP, L_HP;
int Num_sel;
ProSelection* Arm_sel;
int Num_sel_RH;
ProSelection* Arm_sel_RH;

int IRF3C01::IRF3C01_008(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF3C01::IRF3C01_008   ==========================");
	ProModelitem mdlitem_1, mdlitem_2;
	ProMdl mdl_1, mdl_2;
	wchar_t model_1, model_2;
	char namesel_1[PRO_NAME_SIZE];
	char namesel_2[PRO_NAME_SIZE];

	Selection_F3C01_008.clear();
	remark_F3C01_008.clear();
	ruleLog.Write("1");
	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF3C01_008, DLG_IRF3C01_008);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF3C01_008, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF3C01_008, PB_SELECT, (ProUIAction)select_action_IRF3C01_008_LH, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF3C01_008, PB_SELECT_2, (ProUIAction)select_action_IRF3C01_008_RH, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF3C01_008, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF3C01_008, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("2");
	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("3");

	status = ProUIDialogActivate(DLG_IRF3C01_008, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF3C01_008);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits == true)
	{
		status = ProUIDialogDestroy(DLG_IRF3C01_008);
		ruleLog.Write("ProUIDialogDestroy close action: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	else 
	{
		Selection_F3C01_008 += "\nSelection Info: Engine Mounting Arm, LH";
		if (Num_sel == 3)
		{

			// Selection information for result window - LH ARM
			for (int i = 0; i < Num_sel; ++i)
			{
				status = ProSelectionModelitemGet(Arm_sel[i], &mdlitem_1);
				ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

				status = ProModelitemMdlGet(&mdlitem_1, &mdl_1);
				ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

				status = ProMdlMdlnameGet(mdl_1, &model_1);
				ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

				ProWstringToString(namesel_1, &model_1);

				Selection_F3C01_008 += "\nPart Name:" + string(namesel_1) + ".PRT,Surace Id :" + to_string(mdlitem_1.id);

			}

		}
		Selection_F3C01_008 += "\nSelection Info: Engine Mounting Arm, RH";

		if (Num_sel_RH == 3)
		{
			// Selection information for result window - RH ARM
			for (int i = 0; i < Num_sel_RH; ++i)
			{
				status = ProSelectionModelitemGet(Arm_sel_RH[i], &mdlitem_1);
				ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

				status = ProModelitemMdlGet(&mdlitem_1, &mdl_1);
				ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

				status = ProMdlMdlnameGet(mdl_1, &model_1);
				ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

				ProWstringToString(namesel_1, &model_1);

				Selection_F3C01_008 += "\nPart Name:" + string(namesel_1) + ".PRT,Surace Id :" + to_string(mdlitem_1.id);

			}


		}

		ruleLog.Write("LH VP = " + to_string(L_VP) + "mm");
		ruleLog.Write("RH VP = " + to_string(R_VP) + "mm");
		ruleLog.Write("LH HP = " + to_string(L_HP) + "mm");
		ruleLog.Write("RH HP = " + to_string(R_HP) + "mm");

		if (compareFloat(L_VP, R_VP) && compareFloat(L_HP, R_HP))
		{
			final_res.result = "PASS";
		}

		else
		{
			final_res.result = "FAIL";
		}

		remark_F3C01_008 += "\nAcceptance Criteria:\nStandardised vertical and horizontal pitch has to be maintained.\n";
		ruleLog.Write("5");

		final_res.remark = remark_F3C01_008 + Selection_F3C01_008;

	}


	
	return 0;
}

ProError select_action_IRF3C01_008_LH(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("==========================   select_action_IRF3C01_008_LH   ==========================");
	//Declarations for Measurment and Selection Info
	double param_1, param_2;
	double pnt_1, pnt_2;
	ProModelitem mdlitem_1, mdlitem_2;
	ProMdl mdl_1, mdl_2;
	wchar_t model_1, model_2;
	char namesel_1[PRO_NAME_SIZE];
	char namesel_2[PRO_NAME_SIZE];
	

	//Selection of LH
	status = ProSelect((char*)"surface", 3,NULL, NULL,NULL,NULL, &Arm_sel, &Num_sel);
	ruleLog.Write("ProSelect action: " + to_string(status));

	InterfaceRule _irule_F3C01;
	if (status == PRO_TK_USER_ABORT || Num_sel < 3)
	{
		_irule_F3C01.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, CommitOK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}
	
	
	if (Num_sel == 3)
	{
		//Remarks and Measurement of LH- ARM Pitch
		//Verical Pitch
		remark_F3C01_008 += "Measured Value:\n";
		remark_F3C01_008 += "Vertical Pitch of Engine Mounting Arm, LH is ";
		status = ProSelectionWithOptionsDistanceEval(Arm_sel[0], PRO_B_TRUE, Arm_sel[1], PRO_B_TRUE, &param_1, &param_2, &pnt_1, &pnt_2, &L_VP);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
		ruleLog.Write("Distance = " + to_string(L_VP) + "mm");
		remark_F3C01_008 += doubleToStringf3c01(L_VP) + " mm\n";
		//Horizontal Pitch
		status = ProSelectionWithOptionsDistanceEval(Arm_sel[1], PRO_B_TRUE, Arm_sel[2], PRO_B_TRUE, &param_1, &param_2, &pnt_1, &pnt_2, &L_HP);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
		ruleLog.Write("Distance = " + to_string(L_HP) + "mm");
		remark_F3C01_008 += "Horizontal Pitch of Engine Mounting Arm, LH is ";
		remark_F3C01_008 += doubleToStringf3c01(L_HP) + " mm\n";

		status = ProUIPushbuttonDisable(dialog, PB_SELECT);
		status = ProUIPushbuttonEnable(dialog, PB_SELECT_2);
	}
	
	return status;
}

ProError select_action_IRF3C01_008_RH(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("==========================   select_action_IRF3C01_008_RH   ==========================");
	//Declarations for Measurment 
	double param_1, param_2;
	double pnt_1, pnt_2;

	//Selection of RH
	status = ProSelect((char*)"surface", 3, NULL, NULL, NULL, NULL, &Arm_sel_RH, &Num_sel_RH);
	ruleLog.Write("ProSelect close action: " + to_string(status));

	InterfaceRule _irule_F3C01;
	if (status == PRO_TK_USER_ABORT || Num_sel_RH < 3)
	{
		_irule_F3C01.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, CommitOK);
		ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		return status;
	}
	
	if (Num_sel_RH == 3) 
	{
		//Remarks and Measurement of LH- ARM Pitch
		//Verical Pitch
		remark_F3C01_008 += "\nVertical Pitch of Engine Mounting Arm, RH is ";
		status = ProSelectionWithOptionsDistanceEval(Arm_sel_RH[0], PRO_B_TRUE, Arm_sel_RH[1], PRO_B_TRUE, &param_1, &param_2, &pnt_1, &pnt_2, &R_VP);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
		ruleLog.Write("Distance = " + to_string(R_VP) + "mm");
		remark_F3C01_008 += doubleToStringf3c01(R_VP) + " mm\n";

		//Horizontal Pitch
		status = ProSelectionWithOptionsDistanceEval(Arm_sel_RH[1], PRO_B_TRUE, Arm_sel_RH[2], PRO_B_TRUE, &param_1, &param_2, &pnt_1, &pnt_2, &R_HP);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
		ruleLog.Write("Distance = " + to_string(R_HP) + "mm");
		remark_F3C01_008 += "Horizontal Pitch of Engine Mounting Arm, RH is ";
		remark_F3C01_008 += doubleToStringf3c01(R_HP) + " mm\n";

		status = ProUIPushbuttonDisable(dialog, PB_SELECT_2);
		status = ProUIPushbuttonEnable(dialog, CommitOK);
	}
	return status;
}

string doubleToStringf3c01(double value)
{
	std::stringstream stream;
	stream << std::fixed << std::setprecision(2) << value;
	return stream.str();
}