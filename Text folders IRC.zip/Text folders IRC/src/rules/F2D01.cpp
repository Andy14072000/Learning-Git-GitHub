/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 20-06-2023	|	V1_0_0		| F2D01 - LIFT SUSPENSION RULES
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#include "F2D01.h"

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2D01_002		| Vinay Neel		| MF2D01; MF1A01	| Ensure distance between LH & RH Hanger mounting faces is matches with Frame width
===================================================================================================================*/
#define DLG_IRF2D01_002 "dlg_IR_F2D01_002"
#define PB_RSELECT		"pb_select"
#define PB_RCANCEL       "CommitCancel"
#define PB_RUN           "pb_run"
#define Input_Panel    "Input_width"
ProSelection* surf_Sel_F2D01;
double input_width;

int IRF2D01::IRF2D01_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2D01::IRF2D01_002   ==========================");
	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	double distance;

	vector<SurfDataF2D01002> surf_data;
	SurfDataF2D01002 data;

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF2D01_002, DLG_IRF2D01_002);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2D01_002, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D01_002, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D01_002, PB_RUN, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D01_002, PB_RSELECT, (ProUIAction)select_action_IRF2D01_002, NULL);

	status = ProUIPushbuttonDisable(DLG_IRF2D01_002, PB_RUN);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2D01_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF2D01_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;
	status = measureDistanceBetweenSurfaces(surf_Sel_F2D01[0], surf_Sel_F2D01[1], distance);
	ruleLog.Write("measureDistanceBetweenSurfaces: " + to_string(status));
	if (status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selected surfaces.");
		return -1;
	}

	//Get the id of selected planes
	for (int i = 0; i < 2; i++) {
		ProMdlName		wname;
		char            cname[PRO_MDLNAME_SIZE];
		ProFeature feature;

		status = ProSelectionModelitemGet(surf_Sel_F2D01[i], &feature);
		status = ProMdlMdlnameGet(feature.owner, wname);
		ProWstringToString(cname, wname);
		data.part_name = cname;
		data.id = feature.id;
		surf_data.push_back(data);
		ruleLog.Write("part_names: " + to_string(data.id));
	}


	sprintf(remark, "Measured value = %0.2lf mm; Acceptance criteria Frame width = %0.2lf mm;\nNote: A Tolerance of -3 mm and +2 mm is accepted;\nUsed Reference part : %s.PRT (Surf. Id : %s);Used Reference part : %s.PRT (Surf. Id : %s)", distance, input_width, (surf_data[0].part_name).c_str(), (to_string(surf_data[0].id)).c_str(), (surf_data[1].part_name).c_str(), (to_string(surf_data[1].id)).c_str());
	final_res.remark = string(remark);

	double std_dist_min = (input_width - 3), std_dist_max = (input_width + 2);

	// DECLARE RESULT
	if (distance >= std_dist_min && distance <= std_dist_max) {
		final_res.result = "PASS";
	}
	else {
		final_res.result = "FAIL";
	}

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	input_width = NULL;
	return 0;
}

ProError select_action_IRF2D01_002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRF2D01_002  --------------------------");

	int n_sels;
	wchar_t* wstr;
	char   cstr[PRO_NAME_SIZE]{};
	status = ProUIInputpanelValueGet(DLG_IRF2D01_002, Input_Panel, &wstr);
	ruleLog.Write("ProUIInputpanelValueGet: " + to_string(status));
	ProWstringToString(cstr, wstr);
	ruleLog.Write("Frame width User input: " + string(cstr));

	if (string(cstr) != "") {

		try {
			input_width = stod(string(cstr));
		}
		catch (const exception& e) {
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please provide a valid frame width.");
			status = ProUIPushbuttonDisable(dialog, PB_RUN);
			ruleLog.Write("Exception occurred");
			return status;
		}

		//input_width = stod(string(cstr));
		ruleLog.Write("input_width: " + to_string(input_width));

		status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surf_Sel_F2D01, &n_sels);
		ruleLog.Write("ProSelect: " + to_string(status));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIPushbuttonDisable(DLG_IRF2D01_002, PB_RUN);
			return status;
		}
		if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			status = ProUIPushbuttonDisable(DLG_IRF2D01_002, PB_RUN);
			return status;
		}

		for (int i = 0; i < 2; i++) {
			double D;
			status = ProGeomitemDiameterEval(surf_Sel_F2D01[i], &D);
			ruleLog.Write("ProGeomitemDiameterEval = " + to_string(status));
			if (status == PRO_TK_NO_ERROR) {
				_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid surfaces!. Refer help document for details.");
				status = ProUIPushbuttonDisable(DLG_IRF2D01_002, "pb_run");
				return status;
			}
		}
	}
	else
	{
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide frame width Value.");
		status = ProUIPushbuttonDisable(DLG_IRF2D01_002, PB_RUN);
		return status;
	}


	if (n_sels > 0 && n_sels == 2) {
		status = ProUIPushbuttonEnable(DLG_IRF2D01_002, PB_RUN);
		return status;
	}

	return status;
}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES			| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F2D01-010	| MATHANPRASATH A	| MF2D01; MF2A02; MF2A01	| Minimum 15mm clearance to be ensured with other static adjacent parts
===================================================================================================================*/
#define DLG_IRF2D01_010 "dlg_IR_F2D01_010"
#define PB_RCANCEL       "CommitCancel"
#define PB_ROK           "CommitOK"

ComponentData		_reqCompsf2d01[2]{};
ProFeattype			feat_type;

int IRF2D01::IRF2D01_010(ruleResult& final_res)
{
	double clearance;
	string output = "Measured Value: Clearance between ";
	ruleLog.Write("==========================   IRF2D01::IRF2D01_010   ==========================");
	string reqCompSubMod[2] = { "F2D01", "F2A02" };
	string comp_names[2];
	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	status = ProWindowClear(PRO_VALUE_UNUSED);
	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF2D01_010, DLG_IRF2D01_010);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2D01_010, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D01_010, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D01_010, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2D01_010, &dlg_sts);
	status = ProUIDialogDestroy(DLG_IRF2D01_010);
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	for (int i = 0; i < subModulesList.size(); ++i)
	{
		for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j)
		{
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
			{
				strcpy(_reqCompsf2d01[j].name, subModulesList[i].name.c_str());
				comp_names[j] = subModulesList[i].name;
			}
		}

	}

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqCompsf2d01);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
	/*
	wchar_t feat_name;
	char *featurename;
	ProStringToWstring(&feat_name, featurename);
	ruleLog.Write(featurename);*/
	if (feat_type == PRO_FEAT_DATUM_POINT)
	{
		ruleLog.Write("-----------------------------If Loop -----------------------------");
		status = f2D01_deleteDatumPoint();
		ruleLog.Write("deleteDatumPoint: " + to_string(status));
	}

	for (auto elem : _reqCompsf2d01)
	{
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}

	ProSelection sels[2];
	status = ProUIDialogHide(DLG_IRC_MAIN);
	int status = f2D01_measureDistanceBetweenComponents(_reqCompsf2d01[0], _reqCompsf2d01[1], clearance);
	ruleLog.Write("measureDistanceBetweenComponents: " + to_string(status));
	ruleLog.Write(doubleToString(clearance));
	status = ProUIDialogActivate(DLG_IRF2D01_010, &dlg_sts);
	status = ProUIDialogDestroy(DLG_IRF2D01_010);
	status = ProUIDialogShow(DLG_IRC_MAIN);

	output.append(_reqCompsf2d01[0].name);
	output.append(" and ");
	output.append(_reqCompsf2d01[1].name);
	output.append(" is ");
	output.append(doubleToString(clearance));
	output.append("mm.\nAcceptance criteria:Minimum 15mm clearance to be ensured with other static adjacent parts. ");

	if (clearance >= 15) {
		final_res.result = "PASS";
		final_res.remark = string(output);
	}
	else {
		final_res.result = "FAIL";
		final_res.remark = string(output);
	}


	return 0;
}

ProError  f2D01_deleteDatumPoint()
{
	ruleLog.Write("=================> InterfaceRule::deleteDatumPoints <=================");
	ProError status;
	int* feat_ids = NULL;
	ProMdl mdl;
	ProModelitem mdl_item;
	ProFeature feat;
	ProFeatureDeleteOptions* delete_opts = 0;
	ProSelection* selections;
	ProName name1, name2;
	ProIdTable idtbl1;
	ProAsmcomppath path;

	status = ProMdlCurrentGet(&mdl);
	ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));

	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path);
	ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));

	ProStringToWstring(name1, "datum_PNT1");
	status = ProModelitemByNameInit(mdl, PRO_POINT, name1, &mdl_item);
	ruleLog.Write("ProModelitemByNameInit 1 status = " + to_string(status));

	/*status = ProSelectionAlloc(&path, &mdl_item, &selections[0]);
	ruleLog.Write("ProSelectionAlloc 1 status = " + to_string(status));*/

	ProStringToWstring(name2, "datum_PNT2");
	status = ProModelitemByNameInit(mdl, PRO_POINT, name2, &mdl_item);
	ruleLog.Write("ProModelitemByNameInit 2 status = " + to_string(status));

	/*status = ProSelectionAlloc(&path, &mdl_item, &selections[1]);
	ruleLog.Write("ProSelectionAlloc 2 status = " + to_string(status));*/

	for (int i = 0; i < 1; i++)
	{
		/*status = ProSelectionModelitemGet(selections[i], &mdl_item);
		ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));*/

		status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
		ruleLog.Write("ProArrayAlloc status = " + to_string(status));

		status = ProGeomitemFeatureGet((ProGeomitem*)&mdl_item, &feat);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status));

		feat_ids[0] = feat.id;

		status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
		delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;
		status = ProFeatureWithoptionsDelete((ProSolid)mdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
		ruleLog.Write("ProFeatureWithoptionsDelete status = " + to_string(status));

		status = ProArrayFree((ProArray*)&delete_opts);
		status = ProArrayFree((ProArray*)&feat_ids);


	}
	return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2D01_014		| Atharva Patil		| MF2D01; MF5A07	| Minimum 15mm clearance to be ensured with other static adjacent parts.
===================================================================================================================*/
#define DLG_IRF2D01_014 "dlg_IR_F2D01_014"
#define PB_ROK			"CommitOK"
#define PB_RCANCEL		"CommitCancel"
#define PB_Select		"Pb_Select"

ProSelection* surfSels;

vector<clearanceData>			distances;
int								selButton = 0;
vector<ownerInfo>				ownerdetails;
vector<clearanceData>			clearVector;

int IRF2D01::IRF2D01_014(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2D01::IRF2D01_014   ==========================");

	InterfaceRule		iRule;

	selButton = 0;

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF2D01_014, DLG_IRF2D01_014);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2D01_014, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D01_014, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D01_014, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D01_014, PB_Select, (ProUIAction)selectActionF2D01_014, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIPushbuttonDisable(DLG_IRF2D01_014, PB_ROK);
	status = ProUIDialogActivate(DLG_IRF2D01_014, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_IRF2D01_014);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);

		return -1;
	}

	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	ruleLog.Write("size of vector: " + to_string(clearVector.size()));

	sort(clearVector.begin(), clearVector.end(), [](const clearanceData& a, const clearanceData& b) {
		return a.clearance < b.clearance;
		});

	//Write remarks
	string msgRem;

	msgRem += "\nMin. clearance Measured: " + (clearVector[0].clea) + " mm.";
	msgRem += "\nAcceptance Criteria: >= 15.00 mm\n\nReferences Selected - \n";

	for (int i = 0; i < clearVector.size(); i++)
	{
		msgRem += to_string(i + 1) + ")" + (string)clearVector[i].nameOfSel1 + ".PRT (surf ID: " + to_string(clearVector[i].id1) + ")\t & \t" + (string)clearVector[i].nameOfSel2 + ".PRT (surf ID: " + to_string(clearVector[i].id2) + ") = " + clearVector[i].clea + " mm.\n";

		char pointName[PRO_NAME_SIZE] = "CLEARANCE_HIGHLITE_PNT";
		strcat(pointName, to_string(i + 1).c_str());
		ruleLog.Write("point name: " + (string)pointName);
		createDatumPointsF2D01_014(clearVector[i].pntArr, pointName, "CSYS_ASM_DEF");
		ruleLog.Write("Datum point created: " + (string)pointName);
	}

	//Highlighting selections having less clearances
	for (int i = 0; i < clearVector.size(); i++)
	{
		if (round(clearVector[i].clearance) < 15)
		{
			status = ProSelectionHighlight(clearVector[i].sel1, PRO_COLOR_ERROR);
			status = ProSelectionHighlight(clearVector[i].sel2, PRO_COLOR_ERROR);
		}
	}

	final_res.remark = msgRem;
	//Declare Result
	for (int i = 0; i < clearVector.size(); i++)
	{
		if (round(clearVector[i].clearance) >= 15.00)
		{
			final_res.result = "PASS";
		}
		else
		{
			final_res.result = "FAIL";
			break;
		}
	}

	status = ProUIDialogDestroy(DLG_IRF2D01_014);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	return 0;
}

ProError selectActionF2D01_014(char* dialog, char* component, ProAppData data)
{
	InterfaceRule			_irule;
	wchar_t					wName[PRO_NAME_SIZE];
	char					cName[PRO_NAME_SIZE];
	ownerInfo				obj;
	clearanceData			item;
	int						countSel;


	_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Notice", "Select all the adjacent pair of surfaces on Lift kit and air tank.");
	status = ProUIDialogHide(dialog);


Begin:
	{
		ownerdetails.clear();
		status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surfSels, &countSel);
		ruleLog.Write("ProSelect: " + to_string(status));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIPushbuttonDisable(dialog, PB_ROK);
			status = ProUIDialogShow(dialog);
			selButton--;
			return status;
		}
		if (countSel < 2 || status != PRO_TK_NO_ERROR) {
			_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Two Surfaces should be selected");
			status = ProUIPushbuttonDisable(dialog, PB_ROK);
			ProSelectionFree(surfSels);
			selButton--;
			goto Begin;
		}

		selButton++;
		ProModelitem selItem;
		for (int i = 0; i < countSel; i++)
		{
			status = ProSelectionModelitemGet(surfSels[i], &selItem);
			ruleLog.Write("ProSelectionModelitemGet status: " + to_string(status));
			ruleLog.Write("id of selected surface: " + to_string(selItem.id));

			status = ProMdlMdlnameGet(selItem.owner, wName);
			ruleLog.Write("ProMdlMdlnameGet status: " + to_string(status));
			ProWstringToString(cName, wName);
			ruleLog.Write("Owner name: " + (string)cName);

			obj.id = selItem.id;
			ruleLog.Write("id stored: " + to_string(obj.id));
			strcpy(obj.name, cName);
			ruleLog.Write("obj.name copied: " + (string)obj.name);
			ownerdetails.push_back(obj);
			ruleLog.Write("obj pushed back");
		}


		ProBoolean is_interference_found;
		Pro3dPnt pnt_arr[2];
		Pro3dPnt pnt_arr1[2];
		Pro2dPnt param_surfs[2];
		double clearance;
		double pntCreationClearance;

		/*status = ProSelectionWithOptionsDistanceEval(surfSels[0], PRO_B_TRUE, surfSels[1], PRO_B_TRUE, param_surfs[0], param_surfs[1], pnt_arr1[0], pnt_arr1[1], &clearance);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(clearance));
		ruleLog.Write("Coordinates from PSWODE: " + to_string(pnt_arr1[0][0]) + ", " + to_string(pnt_arr1[0][1]) + ", " + to_string(pnt_arr1[0][2]) + ", " + to_string(pnt_arr1[1][0]) + ", " + to_string(pnt_arr1[1][1]) + ", " + to_string(pnt_arr1[1][2]));*/

		status = ProFitClearanceCompute(surfSels[0], PRO_FIT_INCLUDE_NONE, surfSels[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &pntCreationClearance, NULL, &is_interference_found, pnt_arr);
		ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(pntCreationClearance));
		ruleLog.Write("Coordinates from PFCC: " + to_string(pnt_arr[0][0]) + ", " + to_string(pnt_arr[0][1]) + ", " + to_string(pnt_arr[0][2]) + ", " + to_string(pnt_arr[1][0]) + ", " + to_string(pnt_arr[1][1]) + ", " + to_string(pnt_arr[1][2]));

		if (pntCreationClearance > 0)
		{
			item.pntArr[0][0] = pnt_arr[0][0];
			item.pntArr[0][1] = pnt_arr[0][1];
			item.pntArr[0][2] = pnt_arr[0][2];
			item.pntArr[1][0] = pnt_arr[1][0];
			item.pntArr[1][1] = pnt_arr[1][1];
			item.pntArr[1][2] = pnt_arr[1][2];

			ProSelectionCopy(surfSels[0], &item.sel1);
			ProSelectionCopy(surfSels[1], &item.sel2);
			ruleLog.Write("Selections Copied");
			strcpy(item.nameOfSel1, ownerdetails[0].name);
			strcpy(item.nameOfSel2, ownerdetails[1].name);
			ruleLog.Write("Selection names Copied");
			item.id1 = ownerdetails[0].id;
			item.id2 = ownerdetails[1].id;
			ruleLog.Write("ID assigned");
			item.clea = to_string(round(pntCreationClearance));
			item.clea.erase(item.clea.find_last_not_of('0') + 3);
			item.clearance = pntCreationClearance;
			ruleLog.Write("clearances stored");
			clearVector.push_back(item);
			ruleLog.Write("item pushed back for: " + to_string(clearance));
		}
	}

	ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
	msg_buttons[0] = PRO_UI_MESSAGE_YES;
	msg_buttons[1] = PRO_UI_MESSAGE_NO;

	string questionMsg;
	questionMsg += "You have selected " + to_string(selButton) + " pair of surfaces\nDo you want to add more pairs?";
	user_choice = _irule.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation!!", questionMsg, msg_buttons);
	ruleLog.Write("UserDisplayPopupMessageUserChoice: " + to_string(user_choice));

	if (user_choice == PRO_UI_MESSAGE_NO)
	{
		ruleLog.Write("inside user_choice == PRO_UI_MESSAGE_NO");
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonEnable status: " + to_string(status));
		status = ProUIDialogShow(dialog);
	}
	else
	{
		ruleLog.Write("inside user_choice == PRO_UI_MESSAGE_YES");
		questionMsg.erase();
		goto Begin;
	}

	ownerdetails.clear();
	return PRO_TK_NO_ERROR;
}

int createDatumPointsF2D01_014(Pro3dPnt pnt_arr[2], char pointName[PRO_NAME_SIZE], char* csysName)
{
	ruleLog.Write("=================> InterfaceRule::createDatumPoints <=================");
	ProElement	elem_tree, elem_ftype, elem_feature_name,
		pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
		pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
		pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
	ProReference REPDEP_ref1;
	wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wide_string[PRO_NAME_SIZE], wide_string_2[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE];
	//CSYS_ASM_DEF
	ProModelitem refCsysitem;
	ProSelection refCsysSel, reqMdlSel;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pnt_feat;
	ProErrorlist errors;
	//converting negative values to positive
	double d1 = -pnt_arr[0][2];
	double d2 = -pnt_arr[1][2];
	//char cDatumPointName[PRO_NAME_SIZE] = "Dist_highlght_pnt";

	ProStringToWstring(wCsysName, csysName);
	status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
	status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);


	//Create Element Tree
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	//feature name
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, pointName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
	ruleLog.Write("feature name = " + to_string(status));

	//PRO_E_DPOINT_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
	ruleLog.Write("type status = " + to_string(status));

	//Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);

	//ref
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
	status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
	status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);

	//
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);

	//Populating array element
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);

	//Point1
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);

	//Point1 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
	ProStringToWstring(wide_string, "datum_PNT1");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);

	//Point2
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);

	//Point2 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
	ProStringToWstring(wide_string_2, "datum_PNT2");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);

	/* =============================================================== *\
	Create Model Selection Object
	\* =============================================================== */

	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Points
	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	status = ProElementFree(&elem_tree);
	status = ProSelectionFree(&reqMdlSel);

	/*ProSelection pnt_Sel;
	status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
	status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_HIGHLITE);*/
	//PRO_COLOR_SELECTED for green highlight
	ruleLog.Write("==================function end=================");
	return 0;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2D01_015		| Vinay Neel		| MF2D01; MF5B01	| Minimum 25 mm clearance to be ensured between Tire and Hanger Bracket.
===================================================================================================================*/
#define DLG_IRF2D01_015 "dlg_IR_F2D01_015"
#define PB_RSELECT		"pb_select"
#define PB_RSELECT1		"pb_select2"
#define PB_RCANCEL       "CommitCancel"
#define PB_RUN           "pb_run"
#define RB_GRP           "RadioGroup"
ProSelection* tireSurf_Sel_F2D01015;
ProSelection* hangerBracket_Sel_F2D01015;
ProSelection Sel1;
bool ishangerBracketSel;
struct SurfData015 {
	string part_name015;
	int id015;
};


int IRF2D01::IRF2D01_015(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2D01::IRF2D01_015   ==========================");
	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	double distance, distance2, std_distance = 25.00;
	ishangerBracketSel = false;
	vector<SurfData015> surf_data;
	SurfData015 data, data1;

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF2D01_015, DLG_IRF2D01_015);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2D01_015, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D01_015, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D01_015, PB_RUN, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D01_015, PB_RSELECT1, (ProUIAction)select_action_tire_IRF2D01_015, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D01_015, PB_RSELECT, (ProUIAction)select_action_hangerbracket_IRF2D01_015, NULL);

	status = ProUIPushbuttonDisable(DLG_IRF2D01_015, PB_RUN);
	status = ProUIPushbuttonDisable(DLG_IRF2D01_015, PB_RSELECT1);


	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2D01_015, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF2D01_015);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	deleteDatumPoint("datum_PNT1");
	deleteDatumPoint("datum_PNT2");


	if (isUserQuits)
		return -1;


	ProBoolean interf;
	Pro3dPnt coord[2];
	status = ProFitClearanceCompute(Sel1, PRO_FIT_INCLUDE_NONE, hangerBracket_Sel_F2D01015[0], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance, NULL, &interf, coord);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + " Distance1:" + to_string(distance));

	createDatumPoints(coord, "CSYS_ASM_DEF", "Dist_highlght_pnt");


	if (status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selected surfaces.");
		return -1;
	}

	ProMdlName		wname, wname1;
	char            cname[PRO_MDLNAME_SIZE], cname1[PRO_MDLNAME_SIZE];
	ProFeature feature, feature1;

	status = ProSelectionModelitemGet(Sel1, &feature);
	status = ProMdlMdlnameGet(feature.owner, wname);
	ProWstringToString(cname, wname);
	data.part_name015 = cname;
	data.id015 = feature.id;
	surf_data.push_back(data);
	ruleLog.Write("data.id015: " + to_string(data.id015));

	status = ProSelectionModelitemGet(tireSurf_Sel_F2D01015[0], &feature1);
	status = ProMdlMdlnameGet(feature1.owner, wname1);
	ProWstringToString(cname1, wname1);
	data1.part_name015 = cname1;
	data1.id015 = feature1.id;
	surf_data.push_back(data1);
	ruleLog.Write("data.id015: " + to_string(data1.id015));


	sprintf(remark, "Clearance between Tire and Hanger Bracket is %0.2lf mm.;\nAcceptance criteria: The clearance between Tire and Hanger Bracket should be a minimum of %0.2lf mm.;\n\nUsed Reference part : %s.PRT (Surf. Id : %s);Used Reference part : %s.PRT (Surf. Id : %s)", distance, std_distance, (surf_data[0].part_name015).c_str(), (to_string(surf_data[0].id015)).c_str(), (surf_data[1].part_name015).c_str(), (to_string(surf_data[1].id015)).c_str());
	final_res.remark = string(remark);

	// DECLARE RESULT
	if (distance >= std_distance) {
		final_res.result = "PASS";
	}
	else {
		final_res.result = "FAIL";
	}

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);


	return 0;
}

ProError select_action_tire_IRF2D01_015(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_tire_IRF2D01_015  --------------------------");
	int n_sels;


	status = ProSelect((char*)"surface", 1, NULL, NULL, NULL, NULL, &tireSurf_Sel_F2D01015, &n_sels);
	ruleLog.Write("ProSelect surface: " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(dialog, PB_RUN);
		return status;
	}
	if (n_sels < 1 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_RUN);
		return status;
	}

	if (n_sels > 0 && n_sels == 1) {
		status = ProUIPushbuttonEnable(dialog, PB_RUN);
		return status;
	}

	return status;
}

ProError select_action_hangerbracket_IRF2D01_015(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_hangerbracket_IRF2D01_015  --------------------------");
	int n_sels;
	int radioGrpNames[3];
	char** buttonNames;
	char selectedButton[PRO_NAME_SIZE];
	ProSelection Sel2;

	status = ProUIRadiogroupSelectednamesGet(dialog, RB_GRP, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status: " + to_string(status));

	ruleLog.Write("selected button name: " + (string)buttonNames[0]);
	//if (strcmp(buttonNames[0], "Select") == 0)
	//{
	//	ruleLog.Write("inside if: ");
	//	_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please select Part or Surface for the selection of Hanger Bracket.");
	//	status = ProUIPushbuttonDisable(dialog, PB_RSELECT1);
	//	return status;
	//}
	//else {
	//	ruleLog.Write("inside else: ");
	//	_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please select Part or Surface for the selection of Hanger Bracket.");
	//	status = ProUIPushbuttonDisable(dialog, PB_RSELECT1);
	//	return status;
	//}

	if (strcmp(buttonNames[0], "Part") == 0)
	{
		status = ProSelect((char*)"part", 1, NULL, NULL, NULL, NULL, &hangerBracket_Sel_F2D01015, &n_sels);
		ruleLog.Write("ProSelect part: " + to_string(status));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIPushbuttonDisable(dialog, PB_RSELECT1);
			return status;
		}

		status = ProSelectionCopy(hangerBracket_Sel_F2D01015[0], &Sel1);
		ruleLog.Write("ProSelectionCopy: " + to_string(status));


	}
	else if (strcmp(buttonNames[0], "Surface") == 0)
	{
		status = ProSelect((char*)"surface", 1, NULL, NULL, NULL, NULL, &hangerBracket_Sel_F2D01015, &n_sels);
		ruleLog.Write("ProSelect surface: " + to_string(status));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIPushbuttonDisable(dialog, PB_RSELECT1);
			return status;
		}

		status = ProSelectionCopy(hangerBracket_Sel_F2D01015[0], &Sel1);
		ruleLog.Write("ProSelectionCopy: " + to_string(status));

	}
	else {
		ruleLog.Write("inside else: ");
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please select Part or Surface for the selection of Hanger Bracket.");
		status = ProUIPushbuttonDisable(dialog, PB_RSELECT1);
		return status;
	}

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(dialog, PB_RSELECT1);
		return status;
	}
	if (n_sels < 1 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_RSELECT1);
		return status;
	}

	if (n_sels > 0 && n_sels == 1) {
		status = ProUIPushbuttonEnable(dialog, PB_RSELECT1);
		return status;
	}

	return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES			| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F2D01-017	| Ved Aiyar			| MF2D01; MF2C01			| Minimum 15mm clearance to be ensured with other static adjacent parts
===================================================================================================================*/

#define DLG_F2D01_017	    "dlg_IR_F2D01_017" 
#define PR_CANCEL           "CommitCancel" 
#define CommitOK            "CommitOK"
#define RB_Grp1				"RadioGroup1"
#define Label2				"Label2"
#define Select1				"Select1"

vector<PartnameDescriptionPair> reqCompsF2D01_017;
ProSelection   selF2D01, selF2C01;
ProSelection copyselF2D01Sel, copyF2C01Sel;
string F2D01Name, F2C01Name;
string F2D01NameManual, F2C01NameManual;
string RemarkF2D01;

bool isManualF2D01 = NULL;
vector<string>  name_asmF2D01;
int n_selectionF2D01_017;
ProSelection* selectionF2D01_017 = nullptr;

ProBoolean interfF2D01;
Pro3dPnt coordF2D01[2];
ProBoolean is_interference_foundF2D01 = PRO_B_FALSE;

int IRF2D01::IRF2D01_017(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2D01::IRF2D01_017   ==========================");


	reqCompsF2D01_017.clear();
	final_res.result.clear();
	final_res.remark.clear();

	double clearance1 = 0, clearance2 = 0;
	ProBoolean interf1, interf2;
	Pro3dPnt coord1[2], coord2[2];
	vector<PartnameDescriptionPair> reqcomps;
	isManualF2D01 = NULL;

	name_asmF2D01.clear();
	F2D01NameManual.clear();
	F2C01NameManual.clear();

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_F2D01_017, DLG_F2D01_017);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_F2D01_017, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F2D01_017, PR_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F2D01_017, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUILabelHide(DLG_F2D01_017, Label2);
	ruleLog.Write("ProUILabelHide status: " + to_string(status));
	status = ProUIPushbuttonHide(DLG_F2D01_017, Select1);
	ruleLog.Write("ProUIPushbuttonHide status: " + to_string(status));


	status = ProUIPushbuttonActivateActionSet(DLG_F2D01_017, Select1, (ProUIAction)selectActionF2D01_017, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));

	status = ProUIRadiogroupSelectActionSet(DLG_F2D01_017, RB_Grp1, (ProUIAction)radioGrpSelectActionF2D01, NULL);
	ruleLog.Write("ProUIRadiogroupSelectActionSet status: " + to_string(status));
	status = ProUIDialogHide(DLG_IRC_MAIN);
	int radioGrpNames[2];
	char** buttonNames;

	//Radio button, selected for first button (default)
	status = ProUIRadiogroupSelectednamesGet(DLG_F2D01_017, RB_Grp1, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status main: " + to_string(status));
	ruleLog.Write("selected button name: " + (string)buttonNames[0]);

	if (buttonNames[0] == "rb1")       //If user does not select any then default radio button will be first button, 
										//and action related to that will be performed on clicking Ok								
	{

		isManualF2D01 = false;
	}

	status = ProUIDialogActivate(DLG_F2D01_017, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));


	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_F2D01_017);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	status = ProUIDialogDestroy(DLG_F2D01_017);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	Pro2dPnt param_1, param_2;
	Pro3dPnt pnt_1, pnt_2;


	//Automatic verification
	if (isManualF2D01 == false)
	{

		ruleLog.Write("Automatic Selection");

		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Attention!!", "It may take a moment to measure the clearance between two components.");

		status = ProSolidFeatVisit((ProSolid)curMdl, getParameterDescAndPartnameF2D01, compsFilter, (ProAppData)&reqCompsF2D01_017);
		ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

		status = ProSelectionWithOptionsDistanceEval(copyselF2D01Sel, PRO_B_FALSE, copyF2C01Sel, PRO_B_FALSE, param_1, param_2, pnt_1, pnt_2, &clearance1);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));

		//status = ProFitClearanceCompute(copyselF2D01Sel, PRO_FIT_INCLUDE_NONE, copyF2C01Sel, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearance1, NULL, &is_interference_foundF2D01, coordF2D01);

		ruleLog.Write("distance1 = " + to_string(clearance1));

		string strclearance1 = to_string(clearance1);
		string result;
		size_t dotPos = strclearance1.find('.');

		if (dotPos != std::string::npos) {
			// Check if there are at least two characters after the decimal point
			if (dotPos + 3 <= strclearance1.size()) {
				result = strclearance1.substr(0, dotPos + 3);  // Include the dot and two characters after
			}
			else {
				// Less than two characters after the decimal point
				result = strclearance1.substr(0, dotPos + 1);  // Include only up to the decimal point
			}
		}
		else {
			// No decimal point found
			result = strclearance1;
		}

		ruleLog.Write("result " + (result));


		if (clearance1 >= 15)
		{
			sprintf(remark, "Clearance between %s.ASM and %s.ASM = %smm. \nAcceptance Criteria: Minimum 15mm clearance to be ensured with other static adjacent parts.", F2D01Name, F2C01Name, result);

			final_res.remark = string(remark);
			final_res.result = "PASS";
		}

		else
		{
			sprintf(remark, "Clearance between %s.ASM and %s.ASM = %smm. \nAcceptance Criteria: Minimum 15mm clearance to be ensured with other static adjacent parts.", F2D01Name, F2C01Name, result);
			final_res.remark = string(remark);
			final_res.result = "FAIL";
		}
	}

	else // manual selection of surfaces
	{

		if (n_selectionF2D01_017 < 2)
		{
			UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			return -1;
		}
		else
		{
			ruleLog.Write("manual selection");

			/*status = ProSelectionWithOptionsDistanceEval(selectionF2C01_019[0], PRO_B_FALSE, selectionF2C01_019[1], PRO_B_FALSE, param_1, param_2, pnt_1, pnt_2, &clearance1);
			ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));*/

			status = ProSelectionWithOptionsDistanceEval(selectionF2D01_017[0], PRO_B_FALSE, selectionF2D01_017[1], PRO_B_FALSE, param_1, param_2, pnt_1, pnt_2, &clearance1);
			ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));

			/* status = ProFitClearanceCompute(selectionF2D01_017[0], PRO_FIT_INCLUDE_NONE, selectionF2D01_017[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearance1, NULL, &is_interference_foundF2D01, coordF2D01);
			 ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));
			 */
			ruleLog.Write("clearance1 = " + to_string(clearance1));

			string strclearance1 = to_string(clearance1);
			string result;
			size_t dotPos = strclearance1.find('.');

			if (dotPos != std::string::npos) {
				// Check if there are at least two characters after the decimal point
				if (dotPos + 3 <= strclearance1.size()) {
					result = strclearance1.substr(0, dotPos + 3);  // Include the dot and two characters after
				}
				else {
					// Less than two characters after the decimal point
					result = strclearance1.substr(0, dotPos + 1);  // Include only up to the decimal point
				}
			}
			else {
				// No decimal point found
				result = strclearance1;
			}

			ruleLog.Write("result " + (result));


			F2D01NameManual = name_asmF2D01[0];
			F2C01NameManual = name_asmF2D01[1];

			ruleLog.Write("mainBellowNameManual = " + F2D01NameManual);
			ruleLog.Write("propShaftNameManual = " + F2C01NameManual);


			// "Clearance between %s.ASM and %s.ASM = %smm. \nAcceptance Criteria: Minimum 15mm clearance to be ensured with other static adjacent parts.", F2D01Name, F2C01Name, result);
			RemarkF2D01 += "Clearance between ";
			RemarkF2D01 += "" + string(F2D01NameManual) + ".PRT and " + string(F2C01NameManual) + ".PRT ";
			RemarkF2D01 += "= " + to_string(clearance1) + ".mm";
			RemarkF2D01 += "\nAcceptance Criteria: Minimum 15mm clearance to be ensured with other static adjacent parts.";


			if (clearance1 >= 15)
			{

				//sprintf(remark, "Clearance between Lift axle main bellow and Propeller Shaft (%s.PRT & %s.PRT) = %.2fmm.\nAcceptance Criteria: Clearance between Lift axle main bellow and Propeller Shaft should be minimum 40.00mm", mainBellowNameManual, propShaftNameManual, clearance1);


				//final_res.remark = string(remark);
				final_res.result = "PASS";
			}

			else
			{
				//sprintf(remark, "Clearance between Lift axle main bellow and Propeller Shaft (%s.PRT & %s.PRT) = %.2fmm. \nAcceptance Criteria: Clearance between Lift axle main bellow and Propeller Shaft should be minimum 40.00mm", mainBellowNameManual, propShaftNameManual, clearance1);
			   // final_res.remark = string(remark);
				final_res.result = "FAIL";
			}
			final_res.remark = RemarkF2D01;
		}

	}


	reqcomps.clear();
	name_asmF2D01.clear();
	F2D01Name.empty();;
	F2C01Name.empty();
	RemarkF2D01.clear();
	clearance1 = 0;

	return 0;

}

ProError selectActionF2D01_017(char* dialog, char* component, ProAppData appD)
{
	ruleLog.Write("===============selectActionF2C02=================");

	ProModelitem part_model_item;
	ProName name;
	char str_name[PRO_NAME_SIZE];
	InterfaceRule ir;
	ProModelitem parent_model_item;
	ProParameter pDesc;
	ProParamvalue pvDesc;
	ProName pDescName = L"DESCRIPTION";
	string                  description;
	char existingPval[PRO_LINE_SIZE]{};

	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &selectionF2D01_017, &n_selectionF2D01_017);
	ruleLog.Write("Proselect status= " + to_string(status) + "\nNo.of Selection " + to_string(n_selectionF2D01_017));

	if (status == PRO_TK_NO_ERROR && n_selectionF2D01_017 == 2) {
		status = ProUIPushbuttonEnable(dialog, CommitOK);
	}

	for (int i = 0; i < n_selectionF2D01_017; i++)
	{
		status = ProSelectionModelitemGet(selectionF2D01_017[i], &part_model_item);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

		status = ProMdlMdlnameGet(part_model_item.owner, name);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

		ProWstringToString(str_name, name);
		ruleLog.Write("str_name = " + string(str_name));

		status = ProMdlToModelitem(part_model_item.owner, &parent_model_item);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&parent_model_item, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit status = " + to_string(status));
		if (status != PRO_TK_E_NOT_FOUND)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ruleLog.Write("ProParameterValueWithUnitsGet status = " + to_string(status));
			ProWstringToString(existingPval, pvDesc.value.s_val);
		}
		name_asmF2D01.push_back(str_name);

		/*description.append(existingPval);
		ruleLog.Write("description = " + description);
		const regex mainBellowrex("(MAIN BELLOW)");
		const regex propShaftrex("(PROPELLER SHAFT)");

		if (regex_search(description, mainBellowrex) != 0)
		{
			name_asmF2D04.push_back("5166F2D0433001");
		}

		if (regex_search(description, propShaftrex) != 0)
		{
			name_asmF2C01.push_back("5162F2C0141003");
		}*/
	}

	return PRO_TK_NO_ERROR;
}

ProError radioGrpSelectActionF2D01(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("============== radioGrpSelectAction ==============");
	int radioGrpNames[2];
	char** buttonNames;
	char selectedButton[PRO_NAME_SIZE];
	InterfaceRule iRule;

	//status = ProUIPushbuttonDisable(dialog, PB_OK);
	status = ProUIRadiogroupSelectednamesGet(dialog, component, radioGrpNames, &buttonNames);

	ruleLog.Write("ProUIRadiogroupSelectednamesGet status: " + to_string(status));

	//strcpy(selectedButton, buttonNames[0]);
	ruleLog.Write("selected button name: " + (string)buttonNames[0]);
	if (strcmp(buttonNames[0], "rb1") == 0)
	{
		status = ProUILabelHide(dialog, Label2);
		status = ProUIPushbuttonHide(dialog, Select1);

		isManualF2D01 = false;
		ruleLog.Write("IsManual? : " + to_string(isManualF2D01));
		status = ProUIPushbuttonEnable(dialog, CommitOK);
	}
	else
	{
		status = ProUILabelShow(dialog, Label2);
		status = ProUIPushbuttonShow(dialog, Select1);

		status = ProUIPushbuttonDisable(dialog, CommitOK);
		isManualF2D01 = true;
		ruleLog.Write("IsManual? : " + to_string(isManualF2D01));
	}

	return PRO_TK_NO_ERROR;

}

ProError getParameterDescAndPartnameF2D01(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("----------------------------- getParameterDescAndPartname -----------------------------");

	vector<PartnameDescriptionPair>* prtname_desc_list = (vector<PartnameDescriptionPair>*)app_data;

	ProMdlType subModuleMdlType;
	ProModelitem modelItem;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ProMdl reqMdl;
	char existingPval[PRO_NAME_SIZE]{};
	PartnameDescriptionPair compd{};

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
	status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
	ruleLog.Write("ProMdlTypeGet: " + to_string(status));
	status = ProMdlMdlnameGet(reqMdl, wFeatName);
	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(cFeatName, wFeatName);

	status = ProMdlToModelitem(reqMdl, &modelItem);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProParameter pDesc;
	ProParamvalue pvDesc;
	ProName pDescName = L"DESCRIPTION";
	string tokenF2D01 = "F2D01";
	string tokenF2C01 = "F2C01";
	ProSolid assembly;


	status = ProParameterInit(&modelItem, pDescName, &pDesc);
	ruleLog.Write("ProParameterInit: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)
	{
		status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
		ProWstringToString(existingPval, pvDesc.value.s_val);
		ruleLog.Write(cFeatName);
		string cFeatNameStr = cFeatName;

		ProIdTable memb_id_tab;
		memb_id_tab[0] = p_feature->id;
		ProAsmcomppath p_comp_path;

		ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);

		if (strlen(cFeatName) == 14 && cFeatNameStr.find(tokenF2D01) != string::npos)
		{
			strcpy(compd.part_name, cFeatName);
			ruleLog.Write("compd.part_name: " + string(compd.part_name));

			F2D01Name = cFeatName;

			strcpy(compd.description, existingPval);
			ruleLog.Write("compd.description" + string(compd.description));

			ProMdl curMdl;
			status = ProMdlCurrentGet(&curMdl);

			//status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, 1, &path[0]);

			status = ProAsmcomppathInit((ProSolid)curMdl, memb_id_tab, 1, &p_comp_path);
			//ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

			status = ProSelectionAlloc(&p_comp_path, &modelItem, &selF2D01);
			ruleLog.Write("ProSelectionAlloc: " + to_string(status));

			status = ProSelectionCopy(selF2D01, &copyselF2D01Sel);
			ruleLog.Write("ProSelectionCopy ps = " + to_string(status));

		}

		if (strlen(cFeatName) == 14 && cFeatNameStr.find(tokenF2C01) != string::npos)
		{
			strcpy(compd.part_name, cFeatName);
			ruleLog.Write("compd.part_name: " + string(compd.part_name));

			F2C01Name = cFeatName;

			strcpy(compd.description, existingPval);
			ruleLog.Write("compd.description" + string(compd.description));

			ProMdl curMdl;
			status = ProMdlCurrentGet(&curMdl);

			//status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, 1, &path[0]);

			status = ProAsmcomppathInit((ProSolid)curMdl, memb_id_tab, 1, &p_comp_path);
			//ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

			status = ProSelectionAlloc(&p_comp_path, &modelItem, &selF2C01);
			ruleLog.Write("ProSelectionAlloc: " + to_string(status));

			status = ProSelectionCopy(selF2C01, &copyF2C01Sel);
			ruleLog.Write("ProSelectionCopy ps = " + to_string(status));

		}

	}

	prtname_desc_list->push_back(compd);
	return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID		    |  DEVELOPER			| DEPENDENT MODULES			| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F2D01-018	|  Himanshu Pachpute	| MF2D04; MF5B01			| Minimum 45 mm clearance to be ensured between Tire and Main Bellow.
===================================================================================================================*/



#define DLG_IRF2D04_002		"dlg_IR_F2D04_002"
#define PB_RSELECT			"PB_Select"
#define PB_ROK				"CommitOK"
#define PB_RCANCEL			"CommitClose"

struct ComponentData_IRF2D04_002 {
	ProSelection    Surf_Sel{};
	char			name[PRO_PATH_SIZE];
	char			desc[PRO_PATH_SIZE];
	int				Mdl_id{};
	int				Surf_id{};
};

struct Clearance_Struct_IRF2D04_002 {
	double          clearance_value{};
	ProBoolean      interf;
	Pro3dPnt        coord[2];
	char			name1[PRO_PATH_SIZE];
	char			desc1[PRO_PATH_SIZE];
	int				Mdl_id1{};
	int				Surf_id1{};
	char			name2[PRO_PATH_SIZE];
	char			desc2[PRO_PATH_SIZE];
	int				Mdl_id2{};
	int				Surf_id2{};
};

vector<ComponentData_IRF2D04_002> ComponentData_IRF2D04_002_array1{};
vector<ComponentData_IRF2D04_002> ComponentData_IRF2D04_002_array2{};

bool is_alphanumeric_and_space_IRF2D04_002(const string& str) {
	if (str.empty()) {
		return false;
	}
	for (char c : str) {
		if (!isalnum(c) && !isspace(c) && c != '-' && c != '.' && c != 'X' && c != ',') {
			return false;
		}
	}
	return true;
}

size_t findIndexOfSmallestClearanceValue(const std::vector<Clearance_Struct_IRF2D04_002>& vec) {
	if (vec.empty()) {
		throw std::runtime_error("Vector is empty");
	}

	auto minElementIt = std::min_element(vec.begin(), vec.end(), [](const Clearance_Struct_IRF2D04_002& a, const Clearance_Struct_IRF2D04_002& b) {
		return a.clearance_value < b.clearance_value;
		});

	return std::distance(vec.begin(), minElementIt);
}

int IRF2D01::IRF2D01_018(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2D04::IRF2D04_002   ==========================");

	isUserQuits = false;

	vector<Clearance_Struct_IRF2D04_002> clearance_value_vect{};
	string RemarkString{};
	int index_val;

	deleteDatumPointCreatedUsingCsys_IR_F2D04_002("datum_PNT1");
	deleteDatumPointCreatedUsingCsys_IR_F2D04_002("datum_PNT2");

	status = ProUIDialogCreate(DLG_IRF2D04_002, DLG_IRF2D04_002);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2D04_002, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D04_002, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D04_002, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2D04_002, PB_RSELECT, (ProUIAction)select_action_IRF2D04_002, NULL);
	status = ProUIPushbuttonDisable(DLG_IRF2D04_002, PB_ROK);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2D04_002, &dlg_sts);
	status = ProUIDialogDestroy(DLG_IRF2D04_002);
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	for (int i = 0; i < ComponentData_IRF2D04_002_array1.size(); i++) {
		for (int j = 0; j < ComponentData_IRF2D04_002_array2.size(); j++) {
			Clearance_Struct_IRF2D04_002 clear_obj{};
			status = ProFitClearanceCompute(ComponentData_IRF2D04_002_array1[i].Surf_Sel, PRO_FIT_INCLUDE_NONE, ComponentData_IRF2D04_002_array2[j].Surf_Sel, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clear_obj.clearance_value, NULL, &clear_obj.interf, clear_obj.coord);
			ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tDistance: " + to_string(clear_obj.clearance_value));
			clear_obj.Mdl_id1 = ComponentData_IRF2D04_002_array1[i].Mdl_id;
			clear_obj.Mdl_id2 = ComponentData_IRF2D04_002_array2[j].Mdl_id;
			clear_obj.Surf_id1 = ComponentData_IRF2D04_002_array1[i].Surf_id;
			clear_obj.Surf_id2 = ComponentData_IRF2D04_002_array2[j].Surf_id;
			strcpy(clear_obj.name1, ComponentData_IRF2D04_002_array1[i].name);
			strcpy(clear_obj.name2, ComponentData_IRF2D04_002_array2[j].name);
			strcpy(clear_obj.desc1, ComponentData_IRF2D04_002_array1[i].desc);
			strcpy(clear_obj.desc2, ComponentData_IRF2D04_002_array2[j].desc);
			clearance_value_vect.push_back(clear_obj);
		}
	}

	try {
		size_t index = findIndexOfSmallestClearanceValue(clearance_value_vect);
		ruleLog.Write("The index of the smallest clearance value is: " + to_string(index));
		ruleLog.Write("The smallest clearance value is: " + to_string(clearance_value_vect[index].clearance_value));
		index_val = index;
	}
	catch (const std::runtime_error& e) {
		std::cerr << e.what() << std::endl;
	}

	createDatumPointsusingCSYS_IR_F2D04_002(clearance_value_vect[index_val].coord, "CSYS_ASM_DEF");

	ostringstream stream{};
	stream << fixed << setprecision(2) << clearance_value_vect[index_val].clearance_value;
	RemarkString = "Clearance between Tyre and Rubber Bellow is " + stream.str() + "mm" + "\nAcceptance Criteria: Clearance between Tyre and Main Bellow needs to be >= 45mm."
		+ "\n\nSelected reference surfaces for distance calculation.: \n"
		+ "\t\t" + string(clearance_value_vect[index_val].name1) + " " + string(clearance_value_vect[index_val].desc1) + " [Model Feat ID: " + to_string(clearance_value_vect[index_val].Mdl_id1) + "] [Surface Feat ID: " + to_string(clearance_value_vect[index_val].Surf_id1) + "]\n"
		+ "\t\t" + string(clearance_value_vect[index_val].name2) + " " + string(clearance_value_vect[index_val].desc2) + " [Model Feat ID: " + to_string(clearance_value_vect[index_val].Mdl_id2) + "] [Surface Feat ID: " + to_string(clearance_value_vect[index_val].Surf_id2) + "]";

	final_res.remark = string(RemarkString);

	if (clearance_value_vect[index_val].clearance_value >= 45)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	RemarkString.clear();
	clearance_value_vect.clear();
	ComponentData_IRF2D04_002_array1.clear();
	ComponentData_IRF2D04_002_array2.clear();
	return 0;
}

ProError select_action_IRF2D04_002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF2D04_002 -----------------------------");

	status = ProUIDialogHide(DLG_IRF2D04_002);

	int					n_sel1, n_sel2, curWinId;
	InterfaceRule	    irule1, irule2, irule3, irule4;
	ProSelection* surfSels_F2D04_002_1 = nullptr, * surfSels_F2D04_002_2 = nullptr;
	ComponentData_IRF2D04_002_array1.clear();
	ComponentData_IRF2D04_002_array2.clear();
	deleteDatumPointCreatedUsingCsys_IR_F2D04_002("datum_PNT1");
	deleteDatumPointCreatedUsingCsys_IR_F2D04_002("datum_PNT2");

	status = ProWindowCurrentGet(&curWinId);
	status = ProWindowRepaint(curWinId);

	irule1.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Tyre Surface Selection!", "Please select the required surfaces from Tyre");
	status = ProSelect("surface", -1, NULL, NULL, NULL, NULL, &surfSels_F2D04_002_1, &n_sel1);
	ruleLog.Write("Proselect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel1));
	if (status == PRO_TK_NO_ERROR && n_sel1 > 0)
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	if (n_sel1 < 1 || status != PRO_TK_NO_ERROR) {
		irule2.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
	}

	for (int i = 0; i < n_sel1; i++)
	{
		ProModelitem				Selection_model_item, parent_model_item;
		int                         lastCompID = -1;
		ProAsmcomppath              asm_comp_path{};
		ProParameter				pDesc;
		ProParamvalue				pvDesc;
		ProName						name;
		ComponentData_IRF2D04_002	CompData{};
		char			            desc[PRO_PATH_SIZE];
		char                        NotFound[30] = { "Description not found." };

		status = ProSelectionCopy(surfSels_F2D04_002_1[i], &CompData.Surf_Sel);
		ruleLog.Write("ProSelectionCopy: " + to_string(status));

		status = ProSelectionModelitemGet(surfSels_F2D04_002_1[i], &Selection_model_item);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

		status = ProMdlMdlnameGet(Selection_model_item.owner, name);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

		status = ProMdlToModelitem(Selection_model_item.owner, &parent_model_item);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&parent_model_item, L"DESCRIPTION", &pDesc);
		ruleLog.Write("ProParameterInit: " + to_string(status));

		status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
		ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));

		status = ProSelectionAsmcomppathGet(surfSels_F2D04_002_1[i], &asm_comp_path);
		ruleLog.Write("ProSelectionAsmcomppathGet: " + to_string(status));
		for (int k = 0; k < asm_comp_path.table_num; ++k)
			lastCompID = asm_comp_path.comp_id_table[k];

		ProWstringToString(CompData.name, name);
		ProWstringToString(desc, pvDesc.value.s_val);
		ruleLog.Write("desc: " + string(desc));
		(is_alphanumeric_and_space_IRF2D04_002(desc) ? strcpy(CompData.desc, desc) : strcpy(CompData.desc, NotFound));

		CompData.Mdl_id = lastCompID;
		CompData.Surf_id = Selection_model_item.id;
		ComponentData_IRF2D04_002_array1.push_back(CompData);
		ruleLog.Write("CompArray_F2D04_002[i].name: " + string(ComponentData_IRF2D04_002_array1[i].name) + "\tCompArray_F2D04_002[i].desc: " + string(ComponentData_IRF2D04_002_array1[i].desc) + "\tCompArray_F2D04_002[i].id: " + to_string(ComponentData_IRF2D04_002_array1[i].Mdl_id) + "\tCompArray_F2D04_002[i].Surf_id: " + to_string(ComponentData_IRF2D04_002_array1[i].Surf_id));
	}

	irule3.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Rubber Bellow Selection Info", "Please select the required surfaces from Rubber Bellow.");
	status = ProSelect("surface", -1, NULL, NULL, NULL, NULL, &surfSels_F2D04_002_2, &n_sel2);
	ruleLog.Write("Proselect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel2));
	if (status == PRO_TK_NO_ERROR && n_sel2 > 0)
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	if (n_sel2 < 1 || status != PRO_TK_NO_ERROR) {
		irule4.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
	}


	for (int i = 0; i < n_sel2; i++)
	{
		ProModelitem				Selection_model_item1, parent_model_item1;
		int                         lastCompID1 = -1;
		ProAsmcomppath              asm_comp_path1{};
		ProParameter				pDesc1;
		ProParamvalue				pvDesc1;
		ProName						name1;
		ComponentData_IRF2D04_002	CompData1{};
		char			            desc1[PRO_PATH_SIZE];
		char                        NotFound1[30] = { "Description not found." };

		status = ProSelectionCopy(surfSels_F2D04_002_2[i], &CompData1.Surf_Sel);
		ruleLog.Write("ProSelectionCopy: " + to_string(status));

		status = ProSelectionModelitemGet(surfSels_F2D04_002_2[i], &Selection_model_item1);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

		status = ProMdlMdlnameGet(Selection_model_item1.owner, name1);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

		status = ProMdlToModelitem(Selection_model_item1.owner, &parent_model_item1);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&parent_model_item1, L"DESCRIPTION", &pDesc1);
		ruleLog.Write("ProParameterInit: " + to_string(status));

		status = ProParameterValueWithUnitsGet(&pDesc1, &pvDesc1, NULL);
		ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));

		status = ProSelectionAsmcomppathGet(surfSels_F2D04_002_2[i], &asm_comp_path1);
		ruleLog.Write("ProSelectionAsmcomppathGet: " + to_string(status));
		for (int k = 0; k < asm_comp_path1.table_num; ++k)
			lastCompID1 = asm_comp_path1.comp_id_table[k];

		ProWstringToString(CompData1.name, name1);
		ProWstringToString(desc1, pvDesc1.value.s_val);
		ruleLog.Write("desc: " + string(desc1));
		(is_alphanumeric_and_space_IRF2D04_002(desc1) ? strcpy(CompData1.desc, desc1) : strcpy(CompData1.desc, NotFound1));

		CompData1.Mdl_id = lastCompID1;
		CompData1.Surf_id = Selection_model_item1.id;
		ComponentData_IRF2D04_002_array2.push_back(CompData1);
		ruleLog.Write("CompArray_F2D04_002[i].name: " + string(ComponentData_IRF2D04_002_array2[i].name) + "\tCompArray_F2D04_002[i].desc: " + string(ComponentData_IRF2D04_002_array2[i].desc) + "\tCompArray_F2D04_002[i].id: " + to_string(ComponentData_IRF2D04_002_array2[i].Mdl_id) + "\tCompArray_F2D04_002[i].Surf_id: " + to_string(ComponentData_IRF2D04_002_array2[i].Surf_id));
	}

	status = ProUIDialogShow(DLG_IRF2D04_002);
	return status;
}

ProError createDatumPointsusingCSYS_IR_F2D04_002(Pro3dPnt pnt_arr[2], char* csysName)
{
	ruleLog.Write("----------------------------- createDatumPointsusingCSYS_IR_F2D04_002 -----------------------------");

	wchar_t wCsysName[PRO_PATH_SIZE]{};
	ProStringToWstring(wCsysName, csysName);
	ProModelitem refCsysitem{};
	status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
	ruleLog.Write("ProModelitemByNameInit: " + to_string(status));

	ProSelection refCsysSel{};
	status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	ProElement	elem_tree{};
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	ProElement	elem_ftype{};
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
	ruleLog.Write("ProElementIntegerSet: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	elem_feature_name{};
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	wchar_t wDatumPointName[PRO_PATH_SIZE]{};
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, "Dist_highlght_pnt"));
	ruleLog.Write("ProElementWstringSet: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_type{};
	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
	ruleLog.Write("ProElementIntegerSet: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement pro_e_dpoint_ofst_csys_type{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
	ruleLog.Write("ProElementIntegerSet: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_ref{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	ProReference REPDEP_ref1{};
	status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
	ruleLog.Write("ProSelectionToReference: " + to_string(status));

	status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
	ruleLog.Write("ProElementReferenceSet: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_with_dims{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
	ruleLog.Write("ProElementIntegerSet: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_pnts_array{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_pnt_1{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_pnt_name_1{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	wchar_t wide_string[PRO_NAME_SIZE]{};
	ProStringToWstring(wide_string, "datum_PNT1");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
	ruleLog.Write("ProElementWstringSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_dir1_val_1{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
	ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
	ruleLog.Write("ProElementDoubleSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement pro_e_dpoint_ofst_csys_dir2_val_1{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
	ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

	double d1 = -pnt_arr[0][2];
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
	ruleLog.Write("ProElementDoubleSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_dir3_val_1{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
	ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
	ruleLog.Write("ProElementDoubleSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_pnt_2{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement pro_e_dpoint_ofst_csys_pnt_name_2{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	wchar_t wide_string_2[PRO_PATH_SIZE]{};
	ProStringToWstring(wide_string_2, "datum_PNT2");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
	ruleLog.Write("ProElementWstringSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_dir1_val_2{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
	ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
	ruleLog.Write("ProElementDoubleSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement	pro_e_dpoint_ofst_csys_dir2_val_2{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
	ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

	double d2 = -pnt_arr[1][2];
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
	ruleLog.Write("ProElementDoubleSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProElement pro_e_dpoint_ofst_csys_dir3_val_2{};
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
	ruleLog.Write("ProElementAlloc: " + to_string(status));

	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
	ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
	ruleLog.Write("ProElementDoubleSet: " + to_string(status));

	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);
	ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

	ProSelection reqMdlSel{};
	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	ProFeatureCreateOptions* opts = 0;
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
	ruleLog.Write("ProArrayAlloc: " + to_string(status));

	ProFeature pnt_feat{};
	opts[0] = PRO_FEAT_CR_NO_OPTS;
	ProErrorlist errors{};
	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate: " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	ruleLog.Write("ProArrayFree: " + to_string(status));

	status = ProElementFree(&elem_tree);
	ruleLog.Write("ProElementFree: " + to_string(status));

	status = ProSelectionFree(&reqMdlSel);
	ruleLog.Write("ProSelectionFree: " + to_string(status));

	ProSelection pnt_Sel{};
	status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_SS_FAILED_ITEMS);
	ruleLog.Write("ProSelectionHighlight: " + to_string(status));

	return PRO_TK_NO_ERROR;
}

ProError deleteDatumPointCreatedUsingCsys_IR_F2D04_002(char* dtmpoint_name)
{
	ruleLog.Write("----------------------------- deleteDatumPointCreatedUsingCsys_IR_F2D04_002 -----------------------------");

	ProIdTable idtbl1{};
	ProAsmcomppath path{};
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	wchar_t wdatum_pt[PRO_PATH_SIZE]{};
	ProStringToWstring(wdatum_pt, dtmpoint_name);
	ProModelitem mdl_item{};
	status = ProModelitemByNameInit(curMdl, PRO_POINT, wdatum_pt, &mdl_item);
	ruleLog.Write("ProModelitemByNameInit: " + to_string(status));

	if (status == PRO_TK_NO_ERROR) {

		int* feat_ids = NULL;
		status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
		ruleLog.Write("ProArrayAlloc: " + to_string(status));

		ProFeature feat{};
		status = ProGeomitemFeatureGet((ProGeomitem*)&mdl_item, &feat);
		ruleLog.Write("ProGeomitemFeatureGet: " + to_string(status));
		feat_ids[0] = feat.id;

		ProFeatureDeleteOptions* delete_opts = 0;
		status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
		ruleLog.Write("ProArrayAlloc: " + to_string(status));

		delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;
		status = ProFeatureWithoptionsDelete((ProSolid)curMdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
		ruleLog.Write("ProFeatureWithoptionsDelete: " + to_string(status));

		status = ProArrayFree((ProArray*)&delete_opts);
		ruleLog.Write("ProArrayFree: " + to_string(status));

		status = ProArrayFree((ProArray*)&feat_ids);
		ruleLog.Write("ProArrayFree: " + to_string(status));
	}

	return PRO_TK_NO_ERROR;
}