/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	|	V1_0_0		| F1E06 - CHASSIS CONTROLS RULES
==================================================================================================================*/
#include "F1E06.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF1E06005		| Atharva Patil		| MF1E06; MF1E04	| Clutch fluid reservoir outlet should be higher than the inlet port of clutch master cylinder/Vacuum Booster.
===================================================================================================================*/
#define DLG_IRF1E06_005 "dlg_IR_F1E06_005"
#define PB_ROK			"CommitOK"
#define PB_RCANCEL		"CommitCancel"
#define PB_Select		"select_pb"

ProSelection*		asmSel;
int					selCount;
ProModelitem		mi;
ProAsmcomppath		surfPath;
vector<edgeSel>		vectr;
vector<myStruct>	vector1;
double				heightDifference;

int IRF1E06::IRF1E06_005(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF1E06::IRF1E06_005   ==========================");
	
	
	ProPoint		pnt1, pnt2;
	ProVector		coords1, coords2;
	ProModelitem	pnt1MdlItem, pnt2MdlItem;
	InterfaceRule	iRule;
	ProFeature		pFeat;
	myStruct		obj;
	char			pointName[PRO_NAME_SIZE];
	//ProSelection	edgeS[2];
	string			remMsg;
	status = ProWindowClear(PRO_VALUE_UNUSED);
	remMsg.clear();

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF1E06_005, DLG_IRF1E06_005);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF1E06_005, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF1E06_005, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF1E06_005, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF1E06_005, PB_Select, (ProUIAction)selectActionF1E06, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIPushbuttonDisable(DLG_IRF1E06_005, PB_ROK);
	status = ProUIDialogActivate(DLG_IRF1E06_005, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_IRF1E06_005);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);

		return -1;
	}

	ProSelection copySels[2];
	remMsg += "\nReferences Selected: \n";
	for (int i = 0; i < selCount; i++)
	{
		ruleLog.Write("========Inside for loop for: " + to_string(i) + "th time ============");

		//Creating a vetor to contain sel,mdlItem,path feat handle together
		vector1.push_back(obj);
		vector1[i].sel = asmSel[i];

		//getting asmcomppath and modelitem to highlight the edges
		status = ProSelectionAsmcomppathGet(vector1[i].sel, &vector1[i].path);
		ruleLog.Write("ProSelectionAsmcomppathGet status: " + to_string(status));

		status = ProSelectionModelitemGet(vector1[i].sel, &vector1[i].mdlItem);
		ruleLog.Write("ProSelectionModelitemGet status: " + to_string(status));
		/*wchar_t wMdlName[PRO_PATH_SIZE];
		char cMdlName[PRO_PATH_SIZE];*/
		wchar_t wOwnerName[PRO_PATH_SIZE];
		char cOwnerName[PRO_PATH_SIZE];
		/*status = ProModelitemNameGet(&vector1[i].mdlItem, wMdlName);
		ruleLog.Write("ProModelitemNameGet status: " + to_string(status));
		ruleLog.Write("name of selection: " + string(cMdlName));
		ProWstringToString(cMdlName, wMdlName);*/
		status = ProMdlMdlnameGet(vector1[i].mdlItem.owner, wOwnerName);
		ProWstringToString(cOwnerName, wOwnerName);
		remMsg += "Selection: " + to_string(i + 1) + "\nsurface ID- " + to_string(vector1[i].mdlItem.id) + "\t\tOwner- " + cOwnerName + "\n";

		//modelitem of selected object is not of PRO_FEATURE type 
		if (mi.type != PRO_FEATURE)
		{
			status = ProGeomitemFeatureGet((ProGeomitem*)&vector1[i].mdlItem, &vector1[i].pFeat);
			ruleLog.Write("ProGeomitemFeatureGet status: " + to_string(status));
		}

		status = ProFeatureGeomitemVisit(&vector1[i].pFeat, PRO_EDGE, (ProGeomitemAction)geomItemVisit, NULL, &vectr);
		ruleLog.Write("ProFeatureGeomitemVisit status : " + to_string(status));

		ruleLog.Write("size vectr: " + to_string(vectr.size()));

		sort(vectr.begin(), vectr.end(), [](const edgeSel& a, const edgeSel& b) {
			return a.dia > b.dia;
			});
		ruleLog.Write("sort check");

		for (int j = 0; j < vectr.size(); j++)
		{
			double dia = vectr[0].dia;
			if (vectr[j].dia == dia)
			{
				ruleLog.Write("Dia of visiting edge: " + to_string(vectr[j].dia));
				ProModelitem item1;
				status = ProModelitemInit(vector1[i].mdlItem.owner, vectr[j].id, PRO_EDGE, &item1);
				//ruleLog.Write("ProModelitemInit status: " + to_string(status));

				ProSelection sel1;
				status = ProSelectionAlloc(&vector1[i].path, &item1, &vectr[j].sel);
				//ruleLog.Write("ProSelectionAlloc status: " + to_string(status));	
			}
		}
		sprintf(pointName, "MY_PNT%d", i + 1);
		ruleLog.Write("pointName: " + (string)pointName);
		ruleLog.Write("diameter of edge: " + to_string(vectr[0].dia));

		rule_sts = createDatumPointAtCenterOfEdge(vectr[0].sel, pointName);
		vectr.clear();
	}


	status = ProModelitemByNameInit(curMdl, PRO_POINT, L"MY_PNT1", &pnt1MdlItem);
	ruleLog.Write("ProModelitemByNameInit status1: " + to_string(status));
	ruleLog.Write("ID of point: " + to_string(pnt1MdlItem.id));

	status = ProPointInit((ProSolid)pnt1MdlItem.owner, pnt1MdlItem.id, &pnt1);
	ruleLog.Write("ProPointInit status: " + to_string(status));
	status = ProPointCoordGet(pnt1, coords1);
	ruleLog.Write("ProPointCoordGet status:" + to_string(status) + "\nCoordinates of the point pnt1: " +
		to_string(coords1[0]) + ", " + to_string(coords1[1]) + ", " + to_string(coords1[2]));

	status = ProModelitemByNameInit(curMdl, PRO_POINT, L"MY_PNT2", &pnt2MdlItem);
	ruleLog.Write("ProModelitemByNameInit status2: " + to_string(status));
	ruleLog.Write("ID of point: " + to_string(pnt2MdlItem.id));
	status = ProPointInit((ProSolid)pnt2MdlItem.owner, pnt2MdlItem.id, &pnt2);
	ruleLog.Write("ProPointInit status: " + to_string(status));
	status = ProPointCoordGet(pnt2, coords2);
	ruleLog.Write("ProPointCoordGet status:" + to_string(status) + "\nCoordinates of the point pnt2: " +
		to_string(coords2[0]) + ", " + to_string(coords2[1]) + ", " + to_string(coords2[2]));
	
	ProCharPath remark{};
	//Declare result comparing coordinates of points
	if (abs(coords1[2]) > abs(coords2[2]))
	{
		//ruleLog.Write("coords1 = " + to_string(coords1[1]) + " is lesser than coords2 = " + to_string(coords2[1]));
		ruleLog.Write("outlet is positioned lower");
		final_res.result = "FAIL";
		sprintf(remark, "Outlet of clutch fluid reservoir is lower than the inlet of CMC\nAcceptance Criteria - Outlet of reservoir should be higher than the inlet of CMC or Vacuum booster.\n\nVertical distance between two ports is %0.2lf mm\n\n", heightDifference);
		//remMsg += "\nOutlet of clutch fluid reservoir is lower than the inlet of CMC";	
	}
	else
	{
		//ruleLog.Write("coords1 = " + to_string(coords1[1]) + " is smaller than coords2 = " + to_string(coords2[1]));
		ruleLog.Write("outlet is positioned higher");
		final_res.result = "PASS";
		sprintf(remark, "Outlet of reservoir is positioned higher than the inlet of CMC.\nAcceptance Criteria - Outlet of reservoir should be higher than the inlet of CMC or Vacuum booster.\n\nVertical distance between two ports is %0.2lf mm\n\n", heightDifference);

		//remMsg += "\nOutlet of clutch fluid reservoir is positioned higher than the inlet of CMC";
	}

	//remMsg += "\nAcceptance Criteria - Outlet of reservoir should be higher than the inlet of CMC/Vacuum booster.";

	final_res.remark = remark + remMsg;

	status = ProUIDialogDestroy(DLG_IRF1E06_005);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	//ruleLog.Write("sizeof copySels: " + to_string(sizeof(copySels)));

	//iRule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention!!", "MY_PNT1 and MY_PNT2 are created to compare the position.");
	iRule.deleteDatumPoint("MY_PNT1");
	iRule.deleteDatumPoint("MY_PNT2");

	return 0;
}

ProError selectActionF1E06(char* dialog, char* component, ProAppData data)
{
	InterfaceRule _irule;

	_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention", "Select a surface on Inlet port of CMC and \noutlet port of reservoir as shown in the image");

	status = ProUIDialogHide(dialog);

Begin:
	{
		ProWindowRepaint(PRO_VALUE_UNUSED);
		selCount = 0;
		status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &asmSel, &selCount);
		ruleLog.Write("ProSelect: " + to_string(status));


		if (status == PRO_TK_USER_ABORT) {
			status = ProUIPushbuttonDisable(dialog, PB_ROK);
			return status;
		}
		if (selCount < 2 || status != PRO_TK_NO_ERROR) {
			_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			status = ProUIPushbuttonDisable(dialog, PB_ROK);
			return status;
		}
	}

	ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
	msg_buttons[0] = PRO_UI_MESSAGE_YES;
	msg_buttons[1] = PRO_UI_MESSAGE_NO;

	user_choice = _irule.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation?", "Do you want to proceed with the selected surfaces?", msg_buttons);
	if (user_choice == PRO_UI_MESSAGE_YES)
	{
		Pro3dPnt pnt_arr1[2];
		Pro2dPnt param_surfs[2];

		status = ProSelectionWithOptionsDistanceEval(asmSel[0], PRO_B_TRUE, asmSel[1], PRO_B_TRUE, param_surfs[0], param_surfs[1], pnt_arr1[0], pnt_arr1[1], &heightDifference);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\heightDifference: " + to_string(heightDifference));
		status = ProUIDialogShow(dialog);
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	}
	else
	{
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention!!", "Please select two surfaces again");
		goto Begin;
	}

	return PRO_TK_NO_ERROR;
}

ProError geomItemVisit(ProGeomitem* p_handle, ProError status, vector<edgeSel>* vectr)
{
	//ruleLog.Write("================geomItemVisit======================");
	ProEdge pEdge;
	ProEnttype typeEdge;
	int id;
	edgeSel object;
	double dia;
	ProGeomitemdata* dat1;
	ProBoolean inactive;
	object.gItem = *p_handle;
	status = ProGeomitemIsInactive(p_handle, &inactive);
	//ruleLog.Write("ProGeomitemIsInactive status: " + to_string(status) + "\nIs it inactive? " + to_string(inactive));
	if (inactive != PRO_B_TRUE)
	{
		status = ProGeomitemToEdge(p_handle, &pEdge);
		//ruleLog.Write("ProGeomitemToEdge status: " + to_string(status));

		status = ProEdgeTypeGet(pEdge, &typeEdge);
		//ruleLog.Write("ProEdgeTypeGet status: " + to_string(status) + "\nedgetype: " + to_string(typeEdge));

		if (typeEdge == PRO_ENT_ARC)
		{
			status = ProEdgeIdGet(pEdge, &id);
			//ruleLog.Write("ProEdgeIdGet status: " + to_string(status));
			object.id = id;


			//object.sel = sel1;
			//ProSelectionHighlight(sel1, PRO_COLOR_HIGHLITE);
			status = ProGeomitemdataGet(&object.gItem, &dat1);
			//ruleLog.Write("ProGeomitemdataGet status: " + to_string(status));
			//ruleLog.Write("dia of edge: " + to_string(dat1->data.p_curve_data->arc.radius * 2));
			object.dia = dat1->data.p_curve_data->arc.radius * 2;

			vectr->push_back(object);
			//ruleLog.Write("vector check");
		}
	}
	return PRO_TK_NO_ERROR;
}
#pragma pop