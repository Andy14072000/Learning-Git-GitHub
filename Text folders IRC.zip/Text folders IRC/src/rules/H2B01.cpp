#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#include "H2B01.h"

/*==================================================================================================================
RULE ID			| DEVELOPER				| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-H2B01-001	| Himanshu Pachpute		| MH2B01; MF1A01	| One track width FA family per product line- should be in accordance with frame architecture
===================================================================================================================*/

#define DLG_IR_H2B01_001		"dlg_IR_H2B01_001"
#define PB_RSELECT				"pb_select"
#define RULE_IMG				"rule_img"
#define PB_ROK					"CommitOK"
#define PB_RCANCEL				"CommitCancel"
#define IP_STD_TRACK_WIDTH		"input_std_width"
#define IP_OFST_LEN				"input_ofst_len"

vector<compdata_IRH2B01_001>	compselvec_IRH2B01_001{};
double							stan_track_width{};
double							ofst_dist{};

bool isInteger_IRH2B01_001(const string& input) {
	stringstream ss(input);
	int intValue;
	return (ss >> intValue) && (ss.eof());
}

bool isDouble_IRH2B01_001(const string& input) {
	stringstream ss(input);
	double doubleValue;
	char leftover;
	if ((ss >> doubleValue) && !(ss >> leftover))
		return true;
	return false;
}

int IRH2B01::IRH2B01_001(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRH2B01::IRH2B01_001   ==========================");

	ProBoolean			interf;
	Pro3dPnt			coord[2];
	double				clearanceVal{};
	vector<double>		clear_vec{};
	string				remark_str;
	const double        epsilon = 0.01;

	status = ProUIDialogCreate(DLG_IR_H2B01_001, DLG_IR_H2B01_001);
	status = ProUIPushbuttonDisable(DLG_IR_H2B01_001, PB_ROK);
	status = ProUIDialogAboveactivewindowSet(DLG_IR_H2B01_001, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IR_H2B01_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IR_H2B01_001, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IR_H2B01_001, PB_RSELECT, (ProUIAction)select_action_IR_H2B01_001, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IR_H2B01_001, &dlg_sts);
	status = ProUIDialogDestroy(DLG_IR_H2B01_001);
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	for (size_t i = 0; i < compselvec_IRH2B01_001.size() - 1; i++) {
		status = ProFitClearanceCompute(compselvec_IRH2B01_001[i].sel, PRO_FIT_INCLUDE_NONE, compselvec_IRH2B01_001[i + 1].sel, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearanceVal, NULL, &interf, coord);
		ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tDist: " + to_string(clearanceVal));
		clear_vec.push_back(clearanceVal);
	}

	double total_len = clear_vec[0] + clear_vec[1] + clear_vec[0];
	string formatted_total_len = doubleToString(total_len);
	ruleLog.Write("total_len: " + formatted_total_len);

	double track_width = total_len - (ofst_dist * 2);
	string formatted_track_width = doubleToString(track_width);
	ruleLog.Write("track_width: " + formatted_track_width);

	string formatted_stan_track_width = doubleToString(stan_track_width);
	string formatted_ofst_dist = doubleToString(ofst_dist);

	remark_str = "Standard track width provided by the user: " + formatted_stan_track_width + " mm.\nOffset length provided by the user: " + formatted_ofst_dist + " mm * 2.\n" +
		"Calculated track width: " + formatted_track_width + " mm.\n\nAcceptance criteria: Calculated track width should match the standard track width provided by the user." +
		"\n\nReferences Selected by the User: \n\t\t\t1. Surface is selected from [" +
		string(compselvec_IRH2B01_001[0].Comp_name) + "." + string(compselvec_IRH2B01_001[0].Comp_type) + +"-->Feat ID " + to_string(compselvec_IRH2B01_001[0].Comp_Feat_ID) + "] and Surface Feat ID is " + to_string(compselvec_IRH2B01_001[0].Selection_Feat_ID) +
		".\n\t\t\t2. 1st Point Selected from [" + string(compselvec_IRH2B01_001[1].Comp_name) + "." + string(compselvec_IRH2B01_001[1].Comp_type) + "-->Feat ID " + to_string(compselvec_IRH2B01_001[1].Comp_Feat_ID) + "] and Point Feat ID is " + to_string(compselvec_IRH2B01_001[1].Selection_Feat_ID) +
		".\n\t\t\t3. 2nd Point Selected from [" + string(compselvec_IRH2B01_001[2].Comp_name) + "." + string(compselvec_IRH2B01_001[2].Comp_type) + "-->Feat ID " + to_string(compselvec_IRH2B01_001[2].Comp_Feat_ID) + "] and Point Feat ID is " + to_string(compselvec_IRH2B01_001[2].Selection_Feat_ID) + ".";

	if (fabs(track_width - stan_track_width) < epsilon)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	final_res.remark = string(remark_str);

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	remark_str.clear();
	clear_vec.clear();
	compselvec_IRH2B01_001.clear();
	return 0;
}

ProError select_action_IR_H2B01_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------- select_action_IR_H2B01_001 ---------------------------");

	int                         curWinId{};
	int                         n_sel{};
	int                         n_sel2{};
	ProSelection* comp_point_sel;
	ProSelection* comp_surf_sel;
	InterfaceRule               irule{};
	compdata_IRH2B01_001        compinfo{};
	ProModelitem                comp_surf_Modelitem3;
	ProModelitem                comp_part_Modelitem1;
	ProMdlExtension             modelExtension{};
	ProName                     pDescName = L"DESCRIPTION";
	ProParameter                pDesc;
	ProParamvalue               pvDesc;
	wchar_t                     MdlName[PRO_PATH_SIZE]{};
	wchar_t* wstr_track_width;
	char		                cstr_track_width[PRO_PATH_SIZE]{};
	wchar_t* wstr_ofst_len;
	char		                cstr_ofst_len[PRO_PATH_SIZE]{};

	status = ProWindowCurrentGet(&curWinId);
	status = ProWindowRepaint(curWinId);
	status = ProUIDialogHide(DLG_IR_H2B01_001);

	status = ProUIInputpanelValueGet(DLG_IR_H2B01_001, IP_STD_TRACK_WIDTH, &wstr_track_width);
	ruleLog.Write("ProUIInputpanelValueGet: " + to_string(status));
	ProWstringToString(cstr_track_width, wstr_track_width);
	ruleLog.Write("Standard track width provided by the user: " + string(cstr_track_width));

	if (!isInteger_IRH2B01_001(cstr_track_width) && !isDouble_IRH2B01_001(cstr_track_width)) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please provide valid inputs. For more details, refer to the Help document.");
		status = ProUIPushbuttonDisable(DLG_IR_H2B01_001, PB_ROK);
		ruleLog.Write("INVALID INPUT RECEIVED IN TRACK WIDTH....!");
		status = ProUIDialogShow(DLG_IR_H2B01_001);
		return status;
	}

	status = ProUIInputpanelValueGet(DLG_IR_H2B01_001, IP_OFST_LEN, &wstr_ofst_len);
	ruleLog.Write("ProUIInputpanelValueGet: " + to_string(status));
	ProWstringToString(cstr_ofst_len, wstr_ofst_len);
	ruleLog.Write("Offset lenth provided by the user: " + string(cstr_ofst_len));

	if (!isInteger_IRH2B01_001(cstr_ofst_len) && !isDouble_IRH2B01_001(cstr_ofst_len)) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please provide valid inputs. For more details, refer to the Help document.");
		status = ProUIPushbuttonDisable(DLG_IR_H2B01_001, PB_ROK);
		ruleLog.Write("INVALID INPUT RECEIVED IN OFFSET LENTH....!");
		status = ProUIDialogShow(DLG_IR_H2B01_001);
		return status;
	}

	stan_track_width = stod(string(cstr_track_width));
	ofst_dist = stod(string(cstr_ofst_len));

	auto process_selection = [&](ProSelection selection, compdata_IRH2B01_001& compinfo) {
		status = ProSelectionCopy(selection, &compinfo.sel);
		ruleLog.Write("ProSelectionCopy: " + to_string(status));

		status = ProSelectionModelitemGet(selection, &comp_part_Modelitem1);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

		status = ProSelectionAsmcomppathGet(selection, &compinfo.comp_path);
		ruleLog.Write("ProSelectionAsmcomppathGet: " + to_string(status));

		status = ProMdlToModelitem(comp_part_Modelitem1.owner, &comp_surf_Modelitem3);
		ruleLog.Write("ProModelitemMdlGet: " + to_string(status));

		status = ProMdlExtensionGet(comp_part_Modelitem1.owner, modelExtension);
		ruleLog.Write("ProMdlExtensionGet: " + to_string(status));
		ProWstringToString(compinfo.Comp_type, modelExtension);
		ruleLog.Write("Type: " + string(compinfo.Comp_type));

		status = ProParameterInit(&comp_surf_Modelitem3, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit: " + to_string(status));

		status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
		ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));
		ProWstringToString(compinfo.Comp_Description, pvDesc.value.s_val);
		ruleLog.Write("Description: " + string(compinfo.Comp_Description));

		status = ProMdlMdlnameGet(comp_part_Modelitem1.owner, MdlName);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
		ProWstringToString(compinfo.Comp_name, MdlName);
		ruleLog.Write("Name: " + string(compinfo.Comp_name));

		compinfo.Selection_Feat_ID = comp_part_Modelitem1.id;
		ruleLog.Write("Selection_Feat_ID: " + to_string(compinfo.Selection_Feat_ID));
		compinfo.Comp_Feat_ID = compinfo.comp_path.comp_id_table[compinfo.comp_path.table_num - 1];
		ruleLog.Write("Comp_Feat_ID: " + to_string(compinfo.Comp_Feat_ID));
	};


	irule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Surface Selection!", "Please select the required surface.");
	status = ProSelect("surface", 1, NULL, NULL, NULL, NULL, &comp_surf_sel, &n_sel);
	ruleLog.Write("ProSelect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIDialogShow(DLG_IR_H2B01_001);
		return status;
	}
	else if (n_sel < 1) {
		irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIDialogShow(DLG_IR_H2B01_001);
		return status;
	}
	else
		process_selection(comp_surf_sel[0], compinfo);

	compselvec_IRH2B01_001.push_back(compinfo);

	irule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Points Selection!", "Please select the two KPC points, starting with the one closest to the selected surface.");
	status = ProSelect("point", 2, NULL, NULL, NULL, NULL, &comp_point_sel, &n_sel2);
	ruleLog.Write("ProSelect: " + to_string(status) + "\tNo. of Selections: " + to_string(n_sel2));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIDialogShow(DLG_IR_H2B01_001);
		return status;
	}
	else if (n_sel2 < 1) {
		irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIDialogShow(DLG_IR_H2B01_001);
		return status;
	}
	else {
		for (size_t i = 0; i < 2; ++i) {
			compdata_IRH2B01_001 temp_compinfo{};
			process_selection(comp_point_sel[i], temp_compinfo);
			compselvec_IRH2B01_001.push_back(temp_compinfo);
		}
	}

	status = ProUIPushbuttonEnable(DLG_IR_H2B01_001, PB_ROK);
	ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));

	status = ProUIDialogShow(DLG_IR_H2B01_001);
	ruleLog.Write("ProUIDialogShow: " + to_string(status));

	return PRO_TK_NO_ERROR;
}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	        | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRH2B01002      | Vinay Neel		| MH2B01; MF2C01			|  Single coupling flange type for FA family.
===================================================================================================================*/
#define DLG_IRH2B01_002 "dlg_IR_H2B01_002"
#define PB_RUN			"pb_run"
#define PB_RCANCEL		"CommitCancel"
#define PB_RSELECT		"pb_select"
ProSelection* surfSelH2B01002;
int n_selsH2B01002;

struct SurfDataH2B01002 {
	string part_name;
	int id;
};

int IRH2B01::IRH2B01_002(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRH2B01::IRH2B01_002   ==========================");
	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	n_selsH2B01002 = 0;

	double distance;
	vector<double> mDistance, reqValsFromCsvholeCDdouble;
	double std_values[2] = { 73,40 };
	vector<SurfDataH2B01002> surf_data;
	SurfDataH2B01002 data;
	ComponentData _reqComps[1]{};
	bool isProjectCodeFound = false;
	vector<string> projectCodes, reqValsFromCsvholeCD;
	vector<vector<string>> dbList2DH2B01002;

	for (int i = 0; i < subModulesList.size(); ++i)
		for (int j = 0; j < 1; ++j)
			if (subModulesList[i].name.find("H2B01") != string::npos)
				strcpy(_reqComps[j].name, subModulesList[i].name.c_str());

	project_code = stoi(string(_reqComps[0].name).substr(0, 4));
	ruleLog.Write("Project Code:" + to_string(project_code));
	string projectC_str = to_string(project_code);

	dbList2DH2B01002 = getData2D("IRH2B01002.csv");
	ruleLog.Write("dbList2DH2B01002.size(): " + to_string(dbList2DH2B01002.size()));

	for (int i = 1; i < dbList2DH2B01002.size(); ++i)	// i = 1 for skipping the headers
	{
		string tok1, tok2;
		std::istringstream ss1(dbList2DH2B01002[i][2]);
		while (std::getline(ss1, tok1, ';'))
		{
			ruleLog.Write("project code from CSV:" + tok1);
			//storing list of project codes from db
			projectCodes.push_back(tok1);
		}
	}
	ruleLog.Write("projectCodes.size(): " + to_string(projectCodes.size()));

	isUserQuits = false;

	//check whether the project code is available or not in db
	for (int i = 0; i < projectCodes.size(); i++) {
		if ((projectC_str.compare(projectCodes.at(i))) == 0) {
			isProjectCodeFound = true;
			break;
		}
	}

	if (isProjectCodeFound == false) {
		ProUIMessageButton* buttons;
		ProUIMessageButton user_choice;
		ProArrayAlloc(2, sizeof(ProUIMessageButton), 1, (ProArray*)&buttons);
		buttons[0] = PRO_UI_MESSAGE_OK;
		buttons[1] = PRO_UI_MESSAGE_CANCEL;

		wchar_t wTitle[PRO_NAME_SIZE], wMsg[PRO_PATH_SIZE];
		char cTitle[PRO_NAME_SIZE] = "Confirmation";
		char cMsg[PRO_PATH_SIZE];
		string message = "The project code is not found in the database, so this rule is not applicable. \n\nKindly verify the CAD data or confirm to proceed with this rule";
		strcpy(cMsg, message.c_str());
		ProStringToWstring(wTitle, cTitle);
		ProStringToWstring(wMsg, cMsg);

		status = ProUIMessageDialogDisplay(PROUIMESSAGE_QUESTION, wTitle, wMsg, buttons, buttons[0], &user_choice);
		mainLog.Write("ProUIMessageDialogDisplay: " + to_string(status));

		sprintf(remark, "This rule is not applicable for %s.ASM.\nHence Passed", _reqComps[0].name);
		if (user_choice == PRO_UI_MESSAGE_OK) {
			final_res.result = "PASS";
			final_res.remark = remark;
			return 0;
		}
		else
			return 0;
	}
	else {
		getReqValsFrom2DCsvData("IRH2B01002.csv", 2, 4, project_code, reqValsFromCsvholeCD);

		if (reqValsFromCsvholeCD.size() != 0) {
			for (int i = 0; i < reqValsFromCsvholeCD.size(); ++i) {
				reqValsFromCsvholeCDdouble.push_back(stod(reqValsFromCsvholeCD.at(i)));
			}

			sort(reqValsFromCsvholeCDdouble.begin(), reqValsFromCsvholeCDdouble.end(), greater<double>());
		}
		else {
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "The hole CD values are not available in the database.");
			return 0;
		}
	}


    isUserQuits = false;
    status = ProUIDialogCreate(DLG_IRH2B01_002, DLG_IRH2B01_002);
    status = ProUIDialogAboveactivewindowSet(DLG_IRH2B01_002, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRH2B01_002, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRH2B01_002, PB_RUN, (ProUIAction)ruleDlgOKaction, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_IRH2B01_002, PB_RSELECT, (ProUIAction)select_action_IRH2B01_002, NULL);

	status = ProUIPushbuttonDisable(DLG_IRH2B01_002, PB_RUN);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRH2B01_002, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRH2B01_002);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

	ruleLog.Write("n_selsH2B01002: " + to_string(n_selsH2B01002));

	for (int i = 0; i < n_selsH2B01002; i++)
	{
		for (int j = 0; j < n_selsH2B01002; j++)
		{
			status = measureDistanceBetweenSurfaces(surfSelH2B01002[i], surfSelH2B01002[j], distance);
			if (distance > 0)
			{
					mDistance.push_back(distance);
			}						
		}
	}

	sort(mDistance.begin(), mDistance.end(), greater<double>()); //sort the vector containing measurements in descending order

	for (auto val : mDistance) {
		ruleLog.Write("mDistance: " + to_string(val));
	}

	mDistance.erase(mDistance.begin(), mDistance.begin() + 2);

	for (auto val : mDistance) {
		ruleLog.Write("mDistance1: " + to_string(val));
	}

	mDistance.erase(mDistance.begin() + 1);
	mDistance.erase(mDistance.begin() + 2);


	for (auto val : mDistance) {
		ruleLog.Write("mDistance2: " + to_string(val));
	}
	for (auto val : reqValsFromCsvholeCDdouble) {
		ruleLog.Write("reqValsFromCsvholeCDdouble: " + to_string(val));
	}

	bool isdistancematch;	

	if ((compareFloat(mDistance.at(0), reqValsFromCsvholeCDdouble.at(0))) && (mDistance.at(1), reqValsFromCsvholeCDdouble.at(1)))
		isdistancematch = true;
	else
		isdistancematch = false;


	if (isdistancematch) {
		final_res.result = "PASS";
	}
	else {
		final_res.result = "FAIL";
	}

	//Get the id of selected surfaces
	for (int i = 0; i < 3; ++i) {
		ProMdlName		wname;
		char            cname[PRO_MDLNAME_SIZE];
		ProFeature feature;

		status = ProSelectionModelitemGet(surfSelH2B01002[i], &feature);
		status = ProMdlMdlnameGet(feature.owner, wname);
		ProWstringToString(cname, wname);
		data.part_name = cname;
		data.id = feature.id;
		surf_data.push_back(data);
		ruleLog.Write("data.id: " + to_string(data.id));
	}

	sprintf(remark, "Measured CD: %0.2lf mm and %0.2lf mm;Acceptance Creiteria: End yoke with %0.2lf * %0.2lf hole CD \n\nUsed Reference part : %s.PRT (Surf. Id : %s);Used Reference part : %s.PRT (Surf. Id : %s);Used Reference part : %s.PRT (Surf. Id : %s)",mDistance.at(0),mDistance.at(1), reqValsFromCsvholeCDdouble.at(0), reqValsFromCsvholeCDdouble.at(1), (surf_data[0].part_name).c_str(), (to_string(surf_data[0].id)).c_str(), (surf_data[1].part_name).c_str(), (to_string(surf_data[1].id)).c_str(), (surf_data[2].part_name).c_str(), (to_string(surf_data[2].id)).c_str());
	final_res.remark = string(remark);

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	surf_data.clear();
    return 0;
}
ProError select_action_IRH2B01_002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRH2B01_002  --------------------------");
	status = ProSelect((char*)"surface", 3, NULL, NULL, NULL, NULL, &surfSelH2B01002, &n_selsH2B01002);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(dialog, PB_RUN);
		return status;
	}
	if (n_selsH2B01002 < 3 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_RUN);
		return status;
	}

	if (n_selsH2B01002 > 0 && n_selsH2B01002 == 3) {
		status = ProUIPushbuttonEnable(dialog, PB_RUN);
		return status;
	}

	return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-H2B01-003	| Prajakta Bhelawe	| MH2B01; MF4A03	| No variation in SPCD for similar suspension type for a RA family.
===================================================================================================================*/

#define DLG_IRH2B01_003 "dlg_IR_H2B01_003"
#define PB_RSELECT		"pb_select"
#define PB_RCANCEL       "CommitCancel"
#define PB_RUN           "pb_run"
#define Input_Panel    "input_spcd"
ProSelection* surf_selh2b01_003;
double input_spcd_1st_H2B01;
double input_spcd_H2B01;
string rem_mes_H2B01;
vector<vector<string>> dbList2D_H2B01;
struct partDataH2B01 {
	string part_name;
	int id;
};
string raFamilyH2B01_003 = "";
int IRH2B01::IRH2B01_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRH2B01::IRH2B01_003   ==========================");

	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	vector<partDataH2B01> part_data;
	partDataH2B01 data;
	rem_mes_H2B01 = "";
	raFamilyH2B01_003 = "";
	dbList2D_H2B01.clear();
	double distance;

	ComponentData _reqComps[1]{};
	string reqCompSubMod[] = { "H2B01" };

	for (int i = 0; i < subModulesList.size(); ++i)
		for (int j = 0; j < 1; ++j)
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
				strcpy(_reqComps[j].name, subModulesList[j].name.c_str());

	int project_code = stoi(string(_reqComps[0].name).substr(0, 4));
	ruleLog.Write("Project Code:" + to_string(project_code));

	vector<string> reqvalfromcsv;
	getReqValsFrom2DCsvData("IRH2B01003.csv", 0, 1, project_code, reqvalfromcsv);

	if (reqvalfromcsv.size() == 0) {
		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "The project code is not found in the database, so this rule is not applicable. \n\nKindly verify the CAD data or confirm to proceed with this rule.");

		rem_mes_H2B01 += "This rule is not applicable for " + to_string(project_code) + " project code.\nHence Passed";
		final_res.remark = rem_mes_H2B01;
		final_res.result = "PASS";

		return 0;
	}

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRH2B01_003, DLG_IRH2B01_003);
	status = ProUIDialogAboveactivewindowSet(DLG_IRH2B01_003, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2B01_003, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2B01_003, PB_RUN, (ProUIAction)run_action_IRH2B01003, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2B01_003, PB_RSELECT, (ProUIAction)select_action_IRH2B01003, NULL);

	status = ProUIPushbuttonDisable(DLG_IRH2B01_003, PB_RUN);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRH2B01_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRH2B01_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	status = measureDistanceBetweenSurfacesH2B01(surf_selh2b01_003[0], surf_selh2b01_003[1], distance);
	ruleLog.Write("measureDistanceBetweenSurfaces: " + to_string(status));
	if (status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selected surfaces.");
		return -1;
	}


	//Get the id of selected planes
	for (int i = 0; i < 2; i++) {
		ProMdlName		wname;
		char            cname[PRO_MDLNAME_SIZE];
		ProFeature feature;

		status = ProSelectionModelitemGet(surf_selh2b01_003[i], &feature);
		status = ProMdlMdlnameGet(feature.owner, wname);
		ProWstringToString(cname, wname);
		data.part_name = cname;
		data.id = feature.id;
		part_data.push_back(data);
		ruleLog.Write("part_names: " + to_string(data.id));
	}

	sprintf(remark, "Measured SPCD = %0.2lf mm.;Acceptance criteria: SPCD = %0.2lf mm.;\nSPCD provided by user: %0.2lf mm.", distance, input_spcd_H2B01, input_spcd_H2B01);

	rem_mes_H2B01 += remark;
	//rem_mes_H2B01 += "\nRevision & Sequence: " + revision + " , " + sequence;
	rem_mes_H2B01 += "\nUsed Reference part : " + string(part_data[0].part_name) + ".PRT(Surface Id :" + (to_string(part_data[0].id)) + ")";
	rem_mes_H2B01 += "\nUsed Reference part : " + string(part_data[0].part_name) + ".PRT(Surface Id :" + (to_string(part_data[0].id)) + ")";

	final_res.remark = string(rem_mes_H2B01);


	// DECLARE RESULT

	ruleLog.Write("round(distance)" + to_string(round(distance)));
	ruleLog.Write("input_spcd_H2B01" + to_string(input_spcd_H2B01));

	if (compareFloat(round(distance), input_spcd_H2B01)) {
		final_res.result = "PASS";
	}
	else {
		final_res.result = "FAIL";
	}


	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	dbList2D_H2B01.clear();
	part_data.clear();
	rem_mes_H2B01.clear();
	return 0;
}

ProError select_action_IRH2B01003(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRH2B01003 -----------------------------");
	status = ProWindowRepaint(PRO_VALUE_UNUSED);

	int n_sels;
	wchar_t* wstr;
	char   cstr[PRO_NAME_SIZE]{};
	status = ProUIInputpanelValueGet(DLG_IRH2B01_003, Input_Panel, &wstr);
	ruleLog.Write("ProUIInputpanelValueGet: " + to_string(status));
	ProWstringToString(cstr, wstr);
	ruleLog.Write("Frame width User input: " + string(cstr));

	try {
		input_spcd_H2B01 = stod(string(cstr));
	}
	catch (const exception& e) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please provide a valid SPCD.");
		status = ProUIPushbuttonDisable(DLG_IRH2B01_003, PB_RUN);
		ruleLog.Write("Exception occurred");
		return status;
	}

	if (string(cstr) != "") {

		input_spcd_H2B01 = stod(string(cstr));
		ruleLog.Write("input_spcd: " + to_string(input_spcd_H2B01));

		status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surf_selh2b01_003, &n_sels);
		ruleLog.Write("ProSelect: " + to_string(status));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIPushbuttonDisable(DLG_IRH2B01_003, PB_RUN);
			return status;
		}
		if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			status = ProUIPushbuttonDisable(DLG_IRH2B01_003, PB_RUN);
			return status;
		}

	}
	else
	{
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please provide SPCD.");
		status = ProUIPushbuttonDisable(DLG_IRH2B01_003, PB_RUN);
		return status;
	}

	if (status == PRO_TK_NO_ERROR && n_sels == 2) {
		status = ProUIPushbuttonEnable(dialog, PB_RUN);
	}

	return status;
}

ProError run_action_IRH2B01003(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- run_action_IRH2B01003 -----------------------------");

	wchar_t* wstr;
	char   cstr[PRO_NAME_SIZE]{};
	status = ProUIInputpanelValueGet(DLG_IRH2B01_003, Input_Panel, &wstr);
	ruleLog.Write("ProUIInputpanelValueGet: " + to_string(status));
	ProWstringToString(cstr, wstr);
	ruleLog.Write("Frame width changed User input: " + string(cstr));
	ruleLog.Write("input_spcd: " + to_string(input_spcd_H2B01));

	try {
		double input_val = stod(string(cstr));
	}
	catch (const exception& e) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please provide a valid SPCD.");
		status = ProUIPushbuttonDisable(DLG_IRH2B01_003, PB_RUN);
		ruleLog.Write("Exception occurred");
		return status;
	}


	if (string(cstr) == "" || input_spcd_H2B01 != stod(string(cstr))) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please provide a valid SPCD.");
		status = ProUIPushbuttonDisable(DLG_IRH2B01_003, PB_RUN);
		return status;
	}


	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}

ProError measureDistanceBetweenSurfacesH2B01(ProSelection& sel_surf1, ProSelection& sel_surf2, double& distance_bw_surfs)
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenSurfaces <=================");

	Pro2dPnt param_surfs1, param_surfs2;
	Pro3dPnt pnt_surfs1, pnt_surfs2;

	status = ProSelectionWithOptionsDistanceEval(sel_surf1, PRO_B_TRUE, sel_surf2, PRO_B_TRUE, param_surfs1, param_surfs2, pnt_surfs1, pnt_surfs2, &distance_bw_surfs);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance_bw_surfs: " + to_string(distance_bw_surfs));

	return status;
}

#pragma pop