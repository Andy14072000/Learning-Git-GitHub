/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F3B04 - EXHAUST SYSTEM RULES
==================================================================================================================*/
#include "F3B04.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES					| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F3B04-001	| Prajakta Bhelawe	| MF3B04; MH1A17; MF3B06; MF3B05	| Standardization of Gasket which can withstand for higher Exhaust Gas temperatures.
===================================================================================================================*/

#define DLG_F3B04_001      "dlg_IR_F3B04_001" 
#define rule_cancel_pb     "rule_cancel_pb" 
#define CommitOK           "CommitOK"
#define rule_select_pb     "rule_select_pb"
#define emission_norm_dd    "emission_norm_dd"

vector<gasketData>		compList1;
vector<string> emissionNormsList1;
vector<string>			partNoOrGrpIdList, emissionNormsList;
vector<vector<string>> dbList2D_F3B04;
string					gasketRemark;
string pipediaCalc_twoDP;
int n_selSF3B04;
char** selValueF3B04;
vector<string>emissionNormF3B04;

int IRF3B04::IRF3B04_001(ruleResult& final_res)
{

	ruleLog.Write("==========================   IRF3B04::IRF3B04_001   ==========================");

	char** emissionNormsNames;
	wchar_t** emissionNormsLables;
	int isValEqualF3B04 = 0;

	string emmNormList;

	//Get the pipe diameter from CSV
	vector<vector<string>> dbList2D = getData2D("IRF3B04001.csv");
	ruleLog.Write("dbList2D.size(): " + to_string(dbList2D.size()));

	for (int i = 1; i < dbList2D.size(); ++i)	// i = 1 for skipping the headers
	{
		emissionNormsList.push_back(dbList2D[i][0]);
	}

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_F3B04_001, DLG_F3B04_001);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_F3B04_001, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F3B04_001, rule_cancel_pb, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F3B04_001, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIOptionmenuSelectActionSet(DLG_F3B04_001, emission_norm_dd, (ProUIAction)emissionNormsDDF3B04, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status:" + to_string(status));

	status = ProArrayAlloc(emissionNormsList.size(), sizeof(char*), 50, (ProArray*)&emissionNormsNames);
	ruleLog.Write("ProArrayAlloc1: " + to_string(status));
	status = ProArrayAlloc(emissionNormsList.size(), sizeof(wchar_t*), 50, (ProArray*)&emissionNormsLables);
	ruleLog.Write("ProArrayAlloc2: " + to_string(status));

	for (int i = 0; i < emissionNormsList.size(); ++i)
	{
		emissionNormsNames[i] = (char*)calloc(50, sizeof(char));
		ProTKSprintf(emissionNormsNames[i], "%s", emissionNormsList[i]);
		ruleLog.Write("size = " + to_string(emissionNormsList.size()));
		ruleLog.Write("i = " + to_string(i));
		ruleLog.Write("tonnage = " + emissionNormsList[i]);
		ruleLog.Write("tonnageNames SET: ");

		emissionNormsLables[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
		ProStringToWstring(emissionNormsLables[i], emissionNormsNames[i]);
		ruleLog.Write("tonnageLabels SET: ");
	}

	status = ProUIOptionmenuNamesSet(DLG_F3B04_001, emission_norm_dd, int(emissionNormsList.size()), emissionNormsNames);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(DLG_F3B04_001, emission_norm_dd, int(emissionNormsList.size()), emissionNormsLables);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

	status = ProArrayFree((ProArray*)&emissionNormsNames);
	ruleLog.Write("ProArrayFree N" + to_string(status));
	status = ProArrayFree((ProArray*)&emissionNormsLables);
	ruleLog.Write("ProArrayFree L" + to_string(status));

	status = ProUIPushbuttonDisable(DLG_F3B04_001, CommitOK);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_F3B04_001, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_F3B04_001);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits) {
		return -1;
	}

	for (int i = 1; i < dbList2D.size(); ++i)	// i = 1 for skipping the headers
	{
		ruleLog.Write("emissionNorms = " + dbList2D[i][0]);

		emmNormList.assign(dbList2D[i][0]);

		ruleLog.Write("emissionNormF3B04 = " + string(selValueF3B04[0]));
		if (dbList2D[i][0] == string(selValueF3B04[0]))
		{
			string tok1;
			std::istringstream ss1(dbList2D[i][1]);
			while (std::getline(ss1, tok1, ';'))
			{
				partNoOrGrpIdList.push_back(tok1);
			}
			break;
		}
	}

	ruleLog.Write("partNoOrGrpIdList = " + to_string(partNoOrGrpIdList.size()));

	ruleLog.Write("emmNormList = " + emmNormList);
	for (int j = 0; j < partNoOrGrpIdList.size(); j++)
	{
		ruleLog.Write("partNoOrGrpIdList1 = " + partNoOrGrpIdList[j]);
	}

	status = ProSolidFeatVisit((ProSolid)curMdl, (ProFeatureVisitAction)getVisitedCompAsmNamesAndDescription_F3B04, compsFilter, &compList1);
	ruleLog.Write("ProSolidFeatVisit status : " + to_string(status));

	ruleLog.Write("Comps size = " + to_string(compList1.size()));;

	gasketRemark += "Gasket IDs/Part no. used: ";

	string tokenF3B04 = "F3B04";

	ruleLog.Write("check 1");
	for (int i = 0; i < compList1.size(); i++)
	{
		ruleLog.Write("inside for1");
		for (int j = 0; j < partNoOrGrpIdList.size(); j++)
		{
			ruleLog.Write("inside for2");
			ruleLog.Write("compList1[i].part_name = " + string(compList1[i].part_name));
			ruleLog.Write("partNoOrGrpIdList = " + (partNoOrGrpIdList[j]));

			if (compList1[i].part_name == partNoOrGrpIdList[j])
			{
				ruleLog.Write("inside if");
				gasketRemark += string(compList1[i].part_name) + ".ASM, ";

				isValEqualF3B04++;
			}
		}
	}

	for (int i = 0; i < compList1.size(); i++)
	{
		if (isValEqualF3B04 == 0 && compList1.size() != 0)
			gasketRemark += string(compList1[i].part_name) + ".ASM, ";
	}

	if (isValEqualF3B04 == 0 && compList1.size() == 0)
		gasketRemark += "No gaskets used.";

	gasketRemark += "\n";
	gasketRemark += "\nAcceptance Criteria: ";
	gasketRemark += "\nMentioned Gasket IDs / Part no. should be used: \n";

	ruleLog.Write("partNoOrGrpIdList = " + (partNoOrGrpIdList.size()));

	int count = 0;  // To track how many items we've added in the current line

	for (int j = 0; j < partNoOrGrpIdList.size(); j++)
	{
		ruleLog.Write("partNoOrGrpIdList[j] = " + partNoOrGrpIdList[j]);

		// Add part number to gasketRemark
		gasketRemark += (partNoOrGrpIdList[j]) + ".ASM";

		count++;

		// After every 4 values, add a newline
		if (count % 5 == 0 && j < partNoOrGrpIdList.size() - 1) {
			gasketRemark += "\n";  // Add a newline after 4th item
		}
		else {
			gasketRemark += ", ";  // Add comma and space between values
		}
	}


	/*gasketRemark += "\n";
	gasketRemark += "\nAcceptance Criteria: ";
	gasketRemark += "\nMentioned Gasket IDs / Part no. should be used: ";

	ruleLog.Write("partNoOrGrpIdList = "+(partNoOrGrpIdList.size()));

	for (int j = 0; j < partNoOrGrpIdList.size(); j++)
	{
		ruleLog.Write("partNoOrGrpIdList[j] = "+partNoOrGrpIdList[j]);
		gasketRemark += (partNoOrGrpIdList[j]) + ".ASM, ";
	}*/

	ruleLog.Write("Length of gasketRemark: " + to_string(gasketRemark.length()));

	if (isValEqualF3B04 != 0)
	{
		final_res.result = "PASS";
	}

	else
	{
		final_res.result = "FAIL";
	}

	final_res.remark = gasketRemark;

	compList1.clear();
	partNoOrGrpIdList.clear();
	gasketRemark.clear();
	emissionNormsList.clear();
	dbList2D_F3B04.clear();
	emissionNormF3B04.clear();
	emissionNormsList1.clear();
	dbList2D.clear();

	return 0;
}

ProError getVisitedCompAsmNamesAndDescription_F3B04(ProFeature* p_feature, ProError status, vector<PartnameDescriptionPair>* compList1)
{
	ProMdl							reqMdl;
	wchar_t							wMdlName[PRO_NAME_SIZE];
	char							cMdlName[PRO_NAME_SIZE];
	PartnameDescriptionPair			comp;
	ProModelitem					modelItem;
	ProParameter					pDesc;
	ProParamvalue					pvDesc;
	ProName							pDescName = L"DESCRIPTION";
	char							existingPval[PRO_NAME_SIZE];
	ProMdlType						mdlType;
	string							description;

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	if (status == PRO_TK_NO_ERROR)
	{
		status = ProMdlMdlnameGet(reqMdl, wMdlName);
		ProWstringToString(cMdlName, wMdlName);
		strcpy(comp.part_name, cMdlName);

		status = ProMdlToModelitem(reqMdl, &modelItem);
		status = ProParameterInit(&modelItem, pDescName, &pDesc);
		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ProWstringToString(existingPval, pvDesc.value.s_val);

		}

		description.append(existingPval);
		ruleLog.Write(description);
		const regex p("(GASKET)");

		if ((regex_search(description, p) != 0))
		{
			ruleLog.Write("comp.part_name = " + string(comp.part_name));
			ruleLog.Write("exsitingPval = " + string(existingPval));
			strcpy(comp.description, existingPval);
			status = ProMdlTypeGet(reqMdl, &mdlType);

			compList1->push_back(comp);


		}

		if (mdlType == PRO_MDL_ASSEMBLY)
		{
			status = ProSolidFeatVisit((ProSolid)reqMdl, (ProFeatureVisitAction)getVisitedCompAsmNamesAndDescription_F3B04, compsFilter, compList1);
		}

	}

	return PRO_TK_NO_ERROR;
}

ProError emissionNormsDDF3B04(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- emissionNormsDDF3B04 -----------------------------");

	string* reqData = (string*)data;

	status = ProUIOptionmenuSelectednamesGet(dialog, emission_norm_dd, &n_selSF3B04, &selValueF3B04);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValueF3B04[0]));
	if (selValueF3B04[0] == emissionNormsList[0])
	{
		ruleLog.Write("inside if");
		status = ProUIPushbuttonDisable(DLG_F3B04_001, CommitOK);
	}

	else
	{
		ruleLog.Write("inside else");
		status = ProUIPushbuttonEnable(DLG_F3B04_001, CommitOK);

		for (int i = 0; i < emissionNormsList.size(); i++)
		{
			ruleLog.Write("emissionNormsList=  " + emissionNormsList[i]);
			emissionNormF3B04 = emissionNormsList;
		}
	}


	return status;
}
