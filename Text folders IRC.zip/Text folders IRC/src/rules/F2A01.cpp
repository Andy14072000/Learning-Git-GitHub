/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	|	V1_0_0		| F2A01 - FRONT AXLE/LIFT AXLE RULES
==================================================================================================================*/
#include "F2A01.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812


/*==================================================================================================================
IRF2A01_001		|	FRONT AXLE/LIFT AXLE	|	Fix U-Bolt/Bolts/ARB Holes size & Pitch as per suspension requirement.
===================================================================================================================*/
#define DLG_F2A01_001   "dlg_IR_F2A01_001"
#define PB_RCANCEL      "rule_cancel_pb"
#define PB_ROK          "rule_ok_pb"
#define SELECT_PB       "pb_select"
#define SELECT_PB2      "pb_select2"
#define Radio           "Radio"

char**	buttonNames;
char	R1[PRO_NAME_SIZE] = "r1", R2[PRO_NAME_SIZE] = "r2";
char*	ptrR1 = R1;
char*	ptrR2 = R2;

vector<double>				leafHole1, leafHole2, holePitch1, holePitch2, uBoltPitch1, uBoltPitch2, uBolt1, uBolt2;
vector<string>				HoleName1, HoleName2, UBoltName1, UBoltName2;
vector<int>					HoleId1,HoleId2, UBoltId1, UBoltId2;
ProSelection*				holes;
int							isDiffVal = 0, isDiffHoleVal = 0, sameHolepitch = 0, secSet = 0;


int IRF2A01::IRF2A01_001(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2C02::IRF2C01_012  ==========================");

	string rem_message;

	bool MatchDia = true;
	bool MatchPitch = true;
	rem_message.clear();
	leafHole1.clear();
	leafHole2.clear();
	holePitch1.clear();
	holePitch2.clear();
	uBoltPitch1.clear();
	uBoltPitch2.clear();
	uBolt1.clear();
	uBolt2.clear();
	HoleName1.clear();
	HoleName2.clear();
	UBoltName1.clear();
	UBoltName2.clear();
	HoleId1.clear();
	HoleId2.clear();
	UBoltId1.clear();
	UBoltId2.clear();

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_F2A01_001, DLG_F2A01_001);
	ruleLog.Write("ProUIDialogCreate status: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_F2A01_001, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F2A01_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F2A01_001, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_F2A01_001, SELECT_PB, (ProUIAction)selectHole_action_IRF2A01_001, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_F2A01_001, SELECT_PB2, (ProUIAction)select_action_IRF2A01_001, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));

	status = ProUIRadiogroupSelectActionSet(DLG_F2A01_001, Radio, (ProUIAction)rg_select_action_IRF2A01_001, NULL);
	ruleLog.Write("ProUIRadiogroupSelectActionSet status: " + to_string(status));

	//status = ProUIPushbuttonDisable(DLG_F2A01_001, SELECT_PB);
	status = ProUIDialogHide(DLG_IRC_MAIN);

	int radioGrpNames[2];


	//Radio button, selected for first button (default)
	status = ProUIRadiogroupSelectednamesGet(DLG_F2A01_001, Radio, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status main: " + to_string(status));
	ruleLog.Write("selected button name: " + (string)buttonNames[0]);

	status = ProUIDialogActivate(DLG_F2A01_001, &dlg_sts);
	//ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_F2A01_001);
	//ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	for (int i = 0; i < 4; i++) {
		if (((leafHole1[i] < uBolt1[i]) || ((leafHole1[i] - uBolt1[i]) > 1)) || ((leafHole2[i] < uBolt2[i]) || ((leafHole2[i] - uBolt2[i]) > 1))) {
			ruleLog.Write("Check 1--------------------");
			MatchDia = false;
			break;
		}
		/*if ((leafHole1[i]-1 >= uBolt1[i]) &&(uBolt1[i] <= leafHole1[i]) &&  (leafHole2[i] - 1 >= uBolt2[i]) && (uBolt2[i] <= leafHole2[i]) ){
			notMatch = false;
			break;
		}*/
	}
	for (int i = 0; i < 2; i++) {
		if ((holePitch1[i] != uBoltPitch1[i]) || (holePitch2[i] != uBoltPitch2[i])) {
			ruleLog.Write("Check 2--------------------");
			MatchPitch = false;
			break;
		}
	}


	if (MatchPitch && MatchDia) {
		final_res.result = "PASS";
		rem_message += "U-Bolt Hole size & Pitch is as per U-Bolt dimension";
	}
	else {
		final_res.result = "FAIL";
		rem_message += "U-Bolt Hole size & Pitch is not as per U-Bolt dimension";
	}

	rem_message += "\n\nFor 1st LEAF\nU-bolt hole size:- ";
	vector<string> formattedHole1 = formatNumbers(leafHole1);
	for (int i = 0; i < 4; i++) {
		if (i != 0)
			rem_message += ", ";
		rem_message += (formattedHole1[i]);
	}
	rem_message += " mm.\nU-bolt size:- ";
	vector<string> formatteduBolt1 = formatNumbers(uBolt1);
	for (int i = 0; i < 4; i++) {
		if (i != 0)
			rem_message += ", ";
		rem_message += (formatteduBolt1[i]);
	}
	rem_message += " mm.\nU-bolt hole pitch:- ";
	vector<string> formattedholePitch1 = formatNumbers(holePitch1);
	for (int i = 0; i < 2; i++) {
		if (i != 0)
			rem_message += ", ";
		rem_message += (formattedholePitch1[i]);
	}
	rem_message += " mm.\nU-bolt pitch:- ";
	vector<string> formatteduBoltPitch1 = formatNumbers(uBoltPitch1);
	for (int i = 0; i < 2; i++) {
		if (i != 0)
			rem_message += ", ";
		rem_message += (formatteduBoltPitch1[i]);
	}
	rem_message += " mm.\n\nFor 2st LEAF\nU-bolt hole size:- ";
	vector<string> formattedleafHole2 = formatNumbers(leafHole2);
	for (int i = 0; i < 4; i++) {
		if (i != 0)
			rem_message += ", ";
		rem_message += (formattedleafHole2[i]);
	}
	rem_message += " mm.\nU-bolt size:- ";
	vector<string> formatteduBolt2 = formatNumbers(uBolt2);
	for (int i = 0; i < 4; i++) {
		if (i != 0)
			rem_message += ", ";
		rem_message += (formatteduBolt2[i]);
	}
	rem_message += " mm.\nU-bolt hole pitch:- ";
	vector<string> formattedHolePitch2 = formatNumbers(holePitch2);
	for (int i = 0; i < 2; i++) {
		if (i != 0)
			rem_message += ", ";
		rem_message += (formattedHolePitch2[i]);
	}
	rem_message += " mm.\nU-bolt pitch:- ";
	vector<string> formatteduBoltPitch2 = formatNumbers(uBoltPitch2);
	for (int i = 0; i < 2; i++) {
		if (i != 0)
			rem_message += ", ";
		rem_message += (formatteduBoltPitch2[i]);
	}
	rem_message += "  mm.";
	rem_message += "\n\nAcceptance criteria:- U-Bolt Hole size & Pitch need to be as per U-Bolt dimension, \n                      . Bolt-hole clearance = 1 mm";
	rem_message += "\n\nSelected refrences for 1st LEAF:-\nU-Bolt Hole(Part No & Surface ID)           U-Bolt (Part No & Surface ID)\n" + string(HoleName1[0]) + "(" + to_string(HoleId1[0]) + ")                         " + UBoltName1[0] + "(" + to_string(UBoltId1[0]) + ")\n";
	rem_message += HoleName1[1] + "(" + to_string(HoleId1[1]) + ")                         " + UBoltName1[1] + "(" + to_string(UBoltId1[1]) + ")\n";
	rem_message += HoleName1[2] + "(" + to_string(HoleId1[2]) + ")                          " + UBoltName1[2] + "(" + to_string(UBoltId1[2]) + ")\n";
	rem_message += HoleName1[3] + "(" + to_string(HoleId1[3]) + ")                          " + UBoltName1[3] + "(" + to_string(UBoltId1[3]) + ")\n";
	rem_message += "\n\nSelected refrences for 2st LEAF:-\nU-Bolt Hole(Part No & Surface ID)           U-Bolt (Part No & Surface ID)\n" + string(HoleName2[0]) + "(" + to_string(HoleId2[0]) + ")                         " + UBoltName2[0] + "(" + to_string(UBoltId2[0]) + ")\n";
	rem_message += HoleName2[1] + "(" + to_string(HoleId2[1]) + ")                         " + UBoltName2[1] + "(" + to_string(UBoltId2[1]) + ")\n";
	rem_message += HoleName2[2] + "(" + to_string(HoleId2[2]) + ")                         " + UBoltName2[2] + "(" + to_string(UBoltId2[2]) + ")\n";
	rem_message += HoleName2[3] + "(" + to_string(HoleId2[3]) + ")                         " + UBoltName2[3] + "(" + to_string(UBoltId2[3]) + ")\n";
	final_res.remark = rem_message;
	ruleLog.Write(final_res.remark);

	leafHole1.clear();
	leafHole2.clear();
	holePitch1.clear();
	holePitch2.clear();
	uBoltPitch1.clear();
	uBoltPitch2.clear();
	uBolt1.clear();
	uBolt2.clear();
	HoleName1.clear();
	HoleName2.clear();
	UBoltName1.clear();
	UBoltName2.clear();
	HoleId1.clear();
	HoleId2.clear();
	UBoltId1.clear();
	UBoltId2.clear();

	return PRO_TK_NO_ERROR;
}

ProError rg_select_action_IRF2A01_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("============== radioGrpSelectAction ==============");
	//int radioGrpNames[2];
	//char** buttonNames;
	/*char R1[PRO_NAME_SIZE] = "r1";

	char R2[PRO_NAME_SIZE] = "r2";
	char* ptrR2 = R2;*/
	//char selectedButton[PRO_NAME_SIZE];
	InterfaceRule iRule;

	//status = ProUIRadiogroupSelectednamesGet(dialog, component, radioGrpNames, &buttonNames);
	//ruleLog.Write("ProUIRadiogroupSelectednamesGet status: " + to_string(status));

	status = ProUIRadiogroupSelectednamesSet(dialog, component, 1, &ptrR1);
	ruleLog.Write("ProUIRadiogroupSelectednamesSet: " + to_string(status));

	if ((leafHole1.size() == 4) && (holePitch1.size() == 2) && (uBoltPitch1.size() == 2) && (uBolt1.size() == 4)) {

		status = ProUIRadiogroupSelectednamesSet(dialog, component, 1, &ptrR2);
		ruleLog.Write("ProUIRadiogroupSelectednamesSet: " + to_string(status));
		status = ProUIPushbuttonEnable(DLG_F2A01_001, SELECT_PB);
		status = ProUIPushbuttonDisable(DLG_F2A01_001, SELECT_PB2);
		leafHole2.clear();
		holePitch2.clear();
		uBoltPitch2.clear();
		uBolt2.clear();
		HoleName2.clear();
		UBoltName2.clear();
		HoleId2.clear();
		UBoltId2.clear();
	}


	return status;
}

ProError selectHole_action_IRF2A01_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF2A01_001 -----------------------------");

	InterfaceRule _irule;
	int n_sels;
	double D;
	ProMdl	          parent_mdl;
	wchar_t           wParentMdlName[PRO_NAME_SIZE];
	ProModelitem      modelItem;
	ProParameter      pDesc;
	ProParamvalue     pvDesc;
	ProName pDescName = L"DESCRIPTION";
	ProAsmcomppath	  DPS_comp_path;
	char              cParentMdlName[PRO_NAME_SIZE];
	char              existingPval[PRO_NAME_SIZE]{};
	ProAnnotationElem annotelem;
	double param1, param2;
	double pnt1, pnt2;
	double dist1, dist2, dist3, dist4;

	isDiffHoleVal == 0;
	sameHolepitch == 0;
	//secSet == 0;

	int curWinId;
	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);
	status = ProUIPushbuttonDisable(DLG_F2A01_001, SELECT_PB2);

	/*if ((buttonNames[0] == "r1") || (ptrR1[0] == *"r1")) {
		leafHole1.clear();
	}*/

	status = ProSelect((char*)"surface", 4, NULL, NULL, NULL, NULL, &holes, &n_sels);
	ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels));

	if (status == PRO_TK_USER_ABORT) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide inputs again!. Refer help document for details.");
		status = ProUIPushbuttonDisable(DLG_F2A01_001, PB_ROK);
		return status;
	}

	if ((n_sels < 2) || (status != PRO_TK_NO_ERROR)) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide 2 surface selection. Refer help document for details.");
		status = ProUIPushbuttonDisable(DLG_F2A01_001, PB_ROK);
		return status;
	}

	for (int i = 0; i < 4; ++i) {
		status = ProSelectionAsmcomppathGet(holes[i], &DPS_comp_path);
		//ruleLog.Write("ProSelectionAsmcomppathGet = " + to_string(status));

		status = ProAsmcomppathMdlGet(&DPS_comp_path, &parent_mdl);
		//ruleLog.Write("ProAsmcomppathMdlGet = " + to_string(status));

		status = ProMdlMdlnameGet(parent_mdl, wParentMdlName);
		ProWstringToString(cParentMdlName, wParentMdlName);
		ruleLog.Write("cParentMdlName = " + (string)cParentMdlName);
		if (HoleName1.size() < 4) {
			HoleName1.push_back(cParentMdlName);
		}
		else
			HoleName2.push_back(cParentMdlName);

		status = ProMdlToModelitem(parent_mdl, &modelItem);
		//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&modelItem, pDescName, &pDesc);
		//ruleLog.Write("ProParameterInit: " + to_string(status));

		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ProWstringToString(existingPval, pvDesc.value.s_val);
			ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);
			//Des.push_back(existingPval);
		}
		status = ProSelectionModelitemGet(holes[i], &annotelem);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status) + "\tSurface Id: " + to_string(annotelem.id));
		if (HoleId1.size() < 4) {
			HoleId1.push_back(annotelem.id);
		}
		else
			HoleId2.push_back(annotelem.id);
	}

	for (int i = 0; i < 4; i++) {
		status = ProGeomitemDiameterEval(holes[i], &D);
		if ((leafHole1.size() < 4)) {
			leafHole1.push_back(D);
		}
		else {
			leafHole2.push_back(D);
			secSet++;
			//ruleLog.Write("secSet ");
		}
	}

	for (int i = 0; i < 4; ++i)
	{
		for (int j = i + 1; j < 4; ++j)
		{
			if ((leafHole1[i]) != (leafHole1[j]))
				isDiffHoleVal++;
			if (secSet != 0) {
				if ((leafHole2[i]) != (leafHole2[j]))
					isDiffHoleVal++;
			}
		}
	}
	if (isDiffHoleVal != 0) {
		ruleLog.Write("Different hole size");
	}
	ProBoolean is_interference_found;
	Pro3dPnt pnt_arr[2];
	status = ProSelectionWithOptionsDistanceEval(holes[0], PRO_B_TRUE, holes[1], PRO_B_TRUE, &param1, &param2, &pnt1, &pnt2, &dist1);
	status = ProSelectionWithOptionsDistanceEval(holes[2], PRO_B_TRUE, holes[3], PRO_B_TRUE, &param1, &param2, &pnt1, &pnt2, &dist2);
	//status = ProSelectionWithOptionsDistanceEval(holes[1], PRO_B_TRUE, holes[2], PRO_B_TRUE, &param1, &param2, &pnt1, &pnt2, &dist3);
	//status = ProSelectionWithOptionsDistanceEval(holes[0], PRO_B_TRUE, holes[3], PRO_B_TRUE, &param1, &param2, &pnt1, &pnt2, &dist4);
	if ((holePitch1.size() < 2)) {
		holePitch1.push_back(dist1);
		holePitch1.push_back(dist2);
		//holePitch1.push_back(dist3);
		//holePitch1.push_back(dist4);
	}
	else {
		holePitch2.push_back(dist1);
		holePitch2.push_back(dist2);
		//holePitch2.push_back(dist3);
		//holePitch2.push_back(dist4);
	}

	if ((dist1 == dist2) /*&& (dist3 == dist4)*/) {
		sameHolepitch++;
	}

	if (sameHolepitch != 0) {
		ruleLog.Write("Same pitch");
	}


	/*if (secSet != 0) {
		for (int i = 0; i < 4; i++) {
			ruleLog.Write("leafHole1 =" + to_string(leafHole1[i]));
			ruleLog.Write(" leafHole2 =" + to_string(leafHole2[i]));
			ruleLog.Write("holePitch1 =" + to_string(holePitch1[i]));
			ruleLog.Write("holePitch2 =" + to_string(holePitch2[i]));
		}
	}*/
	status = ProUIPushbuttonDisable(DLG_F2A01_001, SELECT_PB);
	status = ProUIPushbuttonEnable(DLG_F2A01_001, SELECT_PB2);

	return PRO_TK_NO_ERROR;
}

ProError select_action_IRF2A01_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF2A01_001 -----------------------------");

	InterfaceRule _irule;
	int n_sels;
	double D;
	ProMdl	          parent_mdl;
	wchar_t           wParentMdlName[PRO_NAME_SIZE];
	ProModelitem      modelItem;
	ProParameter      pDesc;
	ProParamvalue     pvDesc;
	ProName pDescName = L"DESCRIPTION";
	ProAsmcomppath	  DPS_comp_path;
	char              cParentMdlName[PRO_NAME_SIZE];
	char              existingPval[PRO_NAME_SIZE]{};
	ProAnnotationElem annotelem;
	double param3, param4;
	double pnt3, pnt4;
	double dist5, dist6, dist7, dist8;
	char R2[PRO_NAME_SIZE] = "r2";
	char* ptrR2 = R2;

	isDiffVal == 0;

	int curWinId;
	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);

	status = ProSelect((char*)"surface", 4, NULL, NULL, NULL, NULL, &holes, &n_sels);
	ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels));

	if (status == PRO_TK_USER_ABORT) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide inputs again!. Refer help document for details.");
		status = ProUIPushbuttonDisable(DLG_F2A01_001, PB_ROK);
		return status;
	}

	if ((n_sels < 2) || (status != PRO_TK_NO_ERROR)) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide 2 surface selection. Refer help document for details.");
		status = ProUIPushbuttonDisable(DLG_F2A01_001, PB_ROK);
		return status;
	}

	for (int i = 0; i < 4; ++i) {
		status = ProSelectionAsmcomppathGet(holes[i], &DPS_comp_path);
		//ruleLog.Write("ProSelectionAsmcomppathGet = " + to_string(status));

		status = ProAsmcomppathMdlGet(&DPS_comp_path, &parent_mdl);
		//ruleLog.Write("ProAsmcomppathMdlGet = " + to_string(status));

		status = ProMdlMdlnameGet(parent_mdl, wParentMdlName);
		ProWstringToString(cParentMdlName, wParentMdlName);
		ruleLog.Write("cParentMdlName = " + (string)cParentMdlName);
		if (UBoltName1.size() < 4) {
			UBoltName1.push_back(cParentMdlName);
		}
		else
			UBoltName2.push_back(cParentMdlName);

		status = ProMdlToModelitem(parent_mdl, &modelItem);
		//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&modelItem, pDescName, &pDesc);
		//ruleLog.Write("ProParameterInit: " + to_string(status));

		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ProWstringToString(existingPval, pvDesc.value.s_val);
			ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);
			//Des.push_back(existingPval);
		}

		else {
			char note[PRO_NAME_SIZE] = " description_not_found";
			//Des.push_back(note);
		}
		status = ProSelectionModelitemGet(holes[i], &annotelem);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status) + "\tSurface Id: " + to_string(annotelem.id));
		if (UBoltId1.size() < 4) {
			UBoltId1.push_back(annotelem.id);
		}
		else
			UBoltId2.push_back(annotelem.id);
	}

	for (int i = 0; i < 4; i++) {
		status = ProGeomitemDiameterEval(holes[i], &D);
		if ((uBolt1.size() < 4)) {
			uBolt1.push_back(D);
		}
		else {
			uBolt2.push_back(D);
			//secSet++;
			//ruleLog.Write("secSet ");
		}

	}

	for (int i = 0; i < 4; ++i)
	{
		for (int j = i + 1; j < 4; ++j)
		{
			if ((uBolt1[i]) != (uBolt1[j]))
				isDiffVal++;
			if (secSet != 0) {
				if ((uBolt2[i]) != (uBolt2[j]))
					isDiffHoleVal++;
			}
		}
	}
	if (isDiffVal != 0) {
		ruleLog.Write("Hole are of different size");
	}

	ProBoolean is_interference_found;
	Pro3dPnt pnt_arr[2];
	status = ProSelectionWithOptionsDistanceEval(holes[0], PRO_B_TRUE, holes[1], PRO_B_TRUE, &param3, &param4, &pnt3, &pnt4, &dist5);
	status = ProSelectionWithOptionsDistanceEval(holes[2], PRO_B_TRUE, holes[3], PRO_B_TRUE, &param3, &param4, &pnt3, &pnt4, &dist6);
	//status = ProSelectionWithOptionsDistanceEval(holes[1], PRO_B_TRUE, holes[2], PRO_B_TRUE, &param3, &param4, &pnt3, &pnt4, &dist7);
	//status = ProSelectionWithOptionsDistanceEval(holes[0], PRO_B_TRUE, holes[3], PRO_B_TRUE, &param3, &param4, &pnt3, &pnt4, &dist8);
	if ((uBoltPitch1.size() < 2)) {
		uBoltPitch1.push_back(dist5);
		uBoltPitch1.push_back(dist6);
		//uBoltPitch1.push_back(dist7);
		//uBoltPitch1.push_back(dist8);
	}
	else {
		uBoltPitch2.push_back(dist5);
		uBoltPitch2.push_back(dist6);
		//uBoltPitch2.push_back(dist7);
		//uBoltPitch2.push_back(dist8);
	}

	if ((dist5 == dist6) /*&& (dist7 == dist8)*/) {
		sameHolepitch++;
	}

	if (sameHolepitch != 0) {
		ruleLog.Write("Same pitch");
	}

	/*if (secSet != 0) {
		for (int i = 0; i < 4; i++) {
			ruleLog.Write("uBolt1 = " + to_string(uBolt1[i]));
			ruleLog.Write("uBolt2 "+ to_string(uBolt2[i]));
			ruleLog.Write("uBoltPitch1 " + to_string(uBoltPitch1[i]));
			ruleLog.Write("uBoltPitch2 "+ to_string(uBoltPitch2[i]));
		}
	}*/

	ruleLog.Write("leafHole1.size" + to_string(leafHole1.size()));
	ruleLog.Write("leafHole2.size" + to_string(leafHole2.size()));
	ruleLog.Write("holePitch1.size" + to_string(holePitch1.size()));
	ruleLog.Write("holePitch2.size" + to_string(holePitch2.size()));
	ruleLog.Write("uBolt1.size" + to_string(uBolt1.size()));
	ruleLog.Write("uBolt2.size" + to_string(uBolt2.size()));
	ruleLog.Write("uBoltPitch1.size" + to_string(uBoltPitch1.size()));
	ruleLog.Write("uBoltPitch2.size" + to_string(uBoltPitch2.size()));

	if ((leafHole1.size() == 4) && (leafHole2.size() == 0)) {
		rg_select_action_IRF2A01_001(dialog, Radio, data);
	}

	if ((leafHole2.size() == 4) && (holePitch2.size() == 2) && (uBoltPitch2.size() == 2) && (uBolt2.size() == 4)) {
		status = ProUIPushbuttonDisable(DLG_F2A01_001, SELECT_PB2);
		status = ProUIPushbuttonEnable(DLG_F2A01_001, PB_ROK);
	}

	return PRO_TK_NO_ERROR;
}

string formatNumber(double number) {
	ostringstream oss;
	oss << fixed << setprecision(2) << number;
	string formattedNumber = oss.str();

	// Remove trailing zeros
	//formattedNumber.erase(formattedNumber.find_last_not_of('0') + 1, std::string::npos);
	// If the last character is a dot, remove it
	if (formattedNumber.back() == '.') {
		formattedNumber.pop_back();
	}

	return formattedNumber;
}

vector<string> formatNumbers(const vector<double>& numbers) {
	vector<string> formattedNumbers;
	for (double number : numbers) {
		formattedNumbers.push_back(formatNumber(number));
	}
	return formattedNumbers;
}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES			| DESCRIPTION
------------------------------------------------------------------------------------------------------------------
IR-F2A01-002	| MATHANPRASATH A	| MF2A01; MF4A03; MF4A02	| Fix Spring CD as per suspension requirement 3D/2D.
===================================================================================================================*/
#define DLG_IRF2A01_002    "dlg_IR_F2A01_002"
#define CommitOK            "CommitOK"
#define CommitCancel		"CommitCancel"
#define PB_SELECT           "select_pb"

int n_sel_f2a01;
string IRF2A01_002_info;
ProSelection* SurfaceSels;
int IRF2A01::IRF2A01_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2A01::IRF2A01_002   ==========================");
    IRF2A01_002_info.clear();

	ProMdlType subModuleMdlType;
	double dis1, dis2;


	SubModuleInfo _reqSMinfo;
	ProAppData app_data;
	boolean res;
	/*Asm_model					models[1000];
	int							models_cnt;
	Asm_model					Assy_models[1000];
	int							Assy_models_cnt;
	int							num_of_assy_fixed = 0;
	int							model_count;
	vector<feat_id_data>		feat_id_data_arr;
	int							level;
	int							owner_feat_id;
	ProMdl						curr_model;*/


	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF2A01_002, DLG_IRF2A01_002);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2A01_002, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A01_002, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A01_002, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A01_002, PB_SELECT, (ProUIAction)select_action_IRF2A01_002, (ProAppData)&isUserQuits);


	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2A01_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF2A01_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);


	if (isUserQuits)
		return -1;


    if (n_sel_f2a01 == 4)
    {
        ruleLog.Write("ifloop");
        IRF2A01_002_info += "\nSelection Info:";
        ProModelitem mdlitem_1, mdlitem_2;
        ProMdl mdl_1, mdl_2;
        wchar_t model_1, model_2;
        char namesel_1[PRO_NAME_SIZE];
        for (int i = 0; i < 4; ++i)
        {
            status = ProSelectionModelitemGet(SurfaceSels[i], &mdlitem_1);
            ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

            /*status = ProModelitemMdlGet(&mdlitem_1, &mdl_1);
            ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));*/

            status = ProMdlMdlnameGet(mdlitem_1.owner, &model_1);
            ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

            ProWstringToString(namesel_1, &model_1);
            IRF2A01_002_info += "\nPart Name:" + string(namesel_1) + ",Surace Id :" + to_string(mdlitem_1.id);
        }
    }


	vector<double>distance;

	status = measureDistanceBetweenSurfaces(SurfaceSels[0], SurfaceSels[1], dis1);
	ruleLog.Write("measureDistanceBetweenSurfaces 1: " + to_string(status) + "\nDistance 1 :" + to_string(dis1));
	status = measureDistanceBetweenSurfaces(SurfaceSels[2], SurfaceSels[3], dis2);
	ruleLog.Write("measureDistanceBetweenSurfaces 2: " + to_string(status) + "\nDistance 1 :" + to_string(dis2));

	/*float deviated;
	if (dis1 > dis2)
	{
		deviated = dis1 - dis2;
		ruleLog.Write("Deviated: " + to_string(deviated));
	}
	else
	{
		deviated = dis2 - dis1;
		ruleLog.Write("Deviated: " + to_string(deviated));
	}
	*/
	if (dis1 >= dis2 - 1.0 && dis1 <= dis2 + 1.0)
	{
		final_res.result = "PASS";
		sprintf(remark, "Measured value :Fix Spring Center Distance is as per suspension requirement.\n Axle Center Distance: %0.2lfmm.\n Spring Center Distance: %0.2lfmm.\nAcceptance Criteria: Fix Spring Center Distance as per suspension requirement +/-1.", dis1, dis2);
		final_res.remark = remark + IRF2A01_002_info;
	}
	else
	{
		final_res.result = "FAIL";
		sprintf(remark, "Measured value :Fix Spring Center Distance isn't as per suspension requirement.\n Axle Center Distance: %0.2lfmm.\n Spring Center Distance: %0.2lfmm.\nAcceptance Criteria: Fix Spring Center Distance as per suspension requirement +/-1.", dis1, dis2);
		final_res.remark = remark+ IRF2A01_002_info;
	}

	//For Automatic selection of surfaces

	// 
	// 
	//	vector<PartnameDescriptionPair> name_desc_list;
	//	
	//
	//	//Visit the features of opened submodule
	//	FILE* fp{};
	//	level = 1;
	//
	//	num_of_assy_fixed = 0;
	//
	//	models[0].Model = curMdl;
	//	models[0].Model_feat_id = 0;
	//	models_cnt = 1;
	//	Assy_models_cnt = 0;
	//
	//begin:
	//
	//	for (int a = 0; a < models_cnt; ++a)
	//	{
	//		owner_feat_id = models[a].Model_feat_id;
	//		status = ProSolidFeatVisit((ProSolid)models[a].Model, (ProFeatureVisitAction)Type, compsFilter, fp);
	//		ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
	//	}
	//
	//	if (Assy_models_cnt > 0)
	//	{
	//		++level;
	//		for (int b = 0; b < Assy_models_cnt; ++b)
	//		{
	//			models[b].Model = Assy_models[b].Model;
	//			models[b].Model_feat_id = Assy_models[b].Model_feat_id;
	//		}
	//		models_cnt = Assy_models_cnt;
	//		Assy_models_cnt = 0;
	//		goto begin;
	//	}
	//
	//	
	//	ruleLog.Write("Size of vector<surfaces> :" + to_string(surfaces.size()));
	//
	//	// 1st Vector
	//	vector< double > distances;
	//	double distance;
	//	for (i = 0; i < F2A01_info.size(); i++)
	//	{
	//		for (int j = 1; j < F2A01_info.size(); j++)
	//		{
	//			ruleLog.Write("SURFACE ID :" + to_string (F2A01_info[i].id) + to_string (F2A01_info[j].id));
	//			status = measureDistanceBetweenSurfaces(F2A01_info[i].surf_sel, F2A01_info[j].surf_sel, distance);
	//			ruleLog.Write("measureDistanceBetweenSurfaces status: " + to_string(status));
	//			distances.push_back(distance);
	//
	//		}
	//	}
	//
	//	ruleLog.Write("Size of vector<distances> :" + to_string(distances.size()));
	//
	//	sort(distances.begin(), distances.end());
	//	for (double dis : distances) 
	//	{
	//		ruleLog.Write("sorted distance :"+ to_string (dis));
	//	}
	//	

	return 0;
}

ProError select_action_IRF2A01_002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("==========================   IRF2A01::select_action_IRF2A01_002   ==========================");

	status = ProSelect((char*)"surface", 4, NULL, NULL, NULL, NULL, &SurfaceSels, &n_sel_f2a01);
	ruleLog.Write("ProSelect: " + to_string(status));

    InterfaceRule _intrule;

    if (status == PRO_TK_USER_ABORT)

    {

        //_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");

        status = ProUIPushbuttonDisable(dialog, CommitOK);

        ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));

        return status;

    }

    else if (n_sel_f2a01 < 4 || status != PRO_TK_NO_ERROR)

    {

        _intrule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");

        status = ProUIPushbuttonDisable(dialog, CommitOK);

        ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));

        return status;

    }


	if (n_sel_f2a01 == 4)
	{
		status = ProUIPushbuttonEnable(DLG_IRF2A01_002, CommitOK);
	}

	return status;
}

/*==================================================================================================================
RULE ID		    |  DEVELOPER			| DEPENDENT MODULES			| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR_F2A01_005	|  Himanshu Pachpute	| MF2A01; MF2A02; MF2B07	| Ensure Clearance of Ball Joint/Draglink with stub axle & Front Axle Beam.
===================================================================================================================*/
#define DLG_IRF2A01_005     "dlg_IR_F2A01_005"
#define PB_RCLOSE           "CommitClose"
#define PB_ROK              "CommitOK"
#define PB_RMEASURE         "pb_measure"

ComponentData           reqComps_IR_F2A01_005[3]{};
vector<double>          clearances_IR_F2A01_005{};
string                  ComputedDist_IR_F2A01_005{};
int                     iteration_IR_F2A01_005 = 0;
vector<ProSelection>    SelectionhighliteVector{};

int IRF2A01::IRF2A01_005(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF2A01::IRF2A01_005   ==========================");

    string reqCompSubMod[3] = { "F2A01", "F2A02", "F2B07" };
    isUserQuits = false;

    for (int i = 0; i < subModulesList.size(); ++i) {
        for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j) {
            if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
                strcpy(reqComps_IR_F2A01_005[j].name, subModulesList[i].name.c_str());
        }
    }

    status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&reqComps_IR_F2A01_005);
    ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

    for (auto comps : reqComps_IR_F2A01_005) {
        ruleLog.Write("reqComps[].name = " + string(comps.name));
        ruleLog.Write("reqComps[].id = " + to_string(comps.id));
    }

    status = ProUIDialogCreate(DLG_IRF2A01_005, DLG_IRF2A01_005);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));

    status = ProUIDialogAboveactivewindowSet(DLG_IRF2A01_005, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));

    status = ProUIPushbuttonActivateActionSet(DLG_IRF2A01_005, PB_RCLOSE, (ProUIAction)ruleDlgCloseAction_IR_F2A01_005, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIPushbuttonActivateActionSet(DLG_IRF2A01_005, PB_RMEASURE, (ProUIAction)measure_action_IR_F2A01_005, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIPushbuttonActivateActionSet(DLG_IRF2A01_005, PB_ROK, (ProUIAction)ruleDlgOKaction_IR_F2A01_005, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIDialogHide(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogHide: " + to_string(status));

    status = ProUIDialogActivate(DLG_IRF2A01_005, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));

    status = ProUIDialogDestroy(DLG_IRF2A01_005);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

    status = ProUIDialogShow(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogShow: " + to_string(status));

    if (isUserQuits)
        return -1;

    if (!clearances_IR_F2A01_005.empty())
        clearances_IR_F2A01_005.pop_back();

    ComputedDist_IR_F2A01_005 += "\nAcceptance criteria: \n\tClearance from MF2B07(DRAGLINK) to MF2A01(AXLE BEAM) & MF2A02(STUB AXLE ASSY) >10mm.";

    isRightValue = true;
    for (auto clear_val : clearances_IR_F2A01_005) {
        if (clear_val < 10) {
            isRightValue = false;
            break;
        }
    }

    final_res.remark = ComputedDist_IR_F2A01_005;

    if (isRightValue == true)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    memset(reqComps_IR_F2A01_005, 0, sizeof(reqComps_IR_F2A01_005));
    ComputedDist_IR_F2A01_005.clear();
    clearances_IR_F2A01_005.clear();
    iteration_IR_F2A01_005 = 0;
    SelectionhighliteVector.clear();
    return 0;
}

ProError Clearance_Compute_Action_IR_F2A01_005(ComponentData reqComp1, ComponentData reqComp2, double& distance)
{
    ruleLog.Write("==========================   Clearance_Compute_Action_IR_F2A01_005   ==========================");

    ProSelection sels[2];
    ProIdTable idtbl1 = { reqComp1.id };
    ProIdTable idtbl2 = { reqComp2.id };

    ProName comp1_name, comp2_name;
    ProModelitem feature[2];
    ProMdl reqMdls[2];

    ProStringToWstring(comp1_name, reqComp1.name);
    status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
    ruleLog.Write("ProMdlnameInit: " + to_string(status));

    status = ProMdlToModelitem(reqMdls[0], &feature[0]);
    ruleLog.Write("ProMdlToModelitem: " + to_string(status));

    ProStringToWstring(comp2_name, reqComp2.name);
    status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
    ruleLog.Write("ProMdlnameInit: " + to_string(status));

    status = ProMdlToModelitem(reqMdls[1], &feature[1]);
    ruleLog.Write("ProMdlToModelitem: " + to_string(status));

    ProAsmcomppath path[2];
    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl2, 1, &path[1]);
    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

    status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    ProBoolean  interf{};
    Pro3dPnt    coord[2]{};
    status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_FROM_QUILTS, sels[1], PRO_FIT_INCLUDE_TO_QUILTS, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance, NULL, &interf, coord);
    ruleLog.Write("ProFitClearanceComputeForQuilts: " + to_string(status) + "\tdistance: " + to_string(distance));

    if (distance < 10)
        SelectionhighliteVector.push_back(sels[0]);

    createDatumPointsusingCSYS_IR_F2A01_005(coord, "CSYS_ASM_DEF");

    return PRO_TK_NO_ERROR;
}

ProError measure_action_IR_F2A01_005(char* dialog, char* component)
{
    ruleLog.Write("==========================   measure_action_IR_F2A01_005   ==========================");

    ComputedDist_IR_F2A01_005.clear();
    ComputedDist_IR_F2A01_005 = "Clearance between\n";

    for (int i = 0; i < 3; ++i) {
        if (reqComps_IR_F2A01_005[i].id != reqComps_IR_F2A01_005[2].id) {

            double Dist{};
            status = Clearance_Compute_Action_IR_F2A01_005(reqComps_IR_F2A01_005[i], reqComps_IR_F2A01_005[2], Dist);
            ruleLog.Write(string(reqComps_IR_F2A01_005[i].name) + " & " + string(reqComps_IR_F2A01_005[2].name) + ": " + to_string(Dist));

            
            string formattedDistance = doubleToString(Dist);
            ComputedDist_IR_F2A01_005 += "\t" + string(reqComps_IR_F2A01_005[2].name) + " & " + string(reqComps_IR_F2A01_005[i].name) + ": " + formattedDistance + "mm\n";

            clearances_IR_F2A01_005.push_back(Dist);
            char ipVal[50], ipName[50];
            wchar_t wIpVal[50];
            ProTKSprintf(ipName, "ip%d", i + 1);

            if (Dist > 10.00)
                ProTKSprintf(ipVal, "%dmm [Pass]", int(Dist));
            else
                ProTKSprintf(ipVal, "%dmm [Fail]", int(Dist));

            status = ProUIInputpanelEnable(dialog, ipName);
            status = ProUIInputpanelValueSet(dialog, ipName, ProStringToWstring(wIpVal, ipVal));
            status = ProUIInputpanelReadOnly(dialog, ipName);

            formattedDistance.clear();
        }
    }

    status = ProUIPushbuttonEnable(dialog, PB_ROK);
    status = ProUIPushbuttonDisable(DLG_IRF2A01_005, PB_RMEASURE);

    for (size_t n = 0; n < SelectionhighliteVector.size(); n++) {
        status = ProSelectionHighlight(SelectionhighliteVector[n], PRO_COLOR_HIGHLITE);
        ruleLog.Write("ProSelectionHighlight: " + to_string(status));
    }

    return PRO_TK_NO_ERROR;
}

ProError createDatumPointsusingCSYS_IR_F2A01_005(Pro3dPnt pnt_arr[2], char* csysName)
{
    ruleLog.Write("----------------------------- createDatumPointsusingCSYS_IR_F2A01_005 -----------------------------");

    iteration_IR_F2A01_005++;

    wchar_t wCsysName[PRO_PATH_SIZE]{};
    ProStringToWstring(wCsysName, csysName);
    ProModelitem refCsysitem{};
    status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
    ruleLog.Write("ProModelitemByNameInit: " + to_string(status));

    ProSelection refCsysSel{};
    status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    ProElement	elem_tree{};
    status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    ProElement	elem_ftype{};
    status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
    ruleLog.Write("ProElementIntegerSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	elem_feature_name{};
    status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    wchar_t wDatumPointName[PRO_PATH_SIZE]{};
    string iterationString = to_string(iteration_IR_F2A01_005);
    char cDatumPointName[PRO_PATH_SIZE];
    strcpy(cDatumPointName, "Dist_highlght_pnt_");
    strcat(cDatumPointName, iterationString.c_str());
    status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, cDatumPointName));
    ruleLog.Write("ProElementWstringSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_type{};
    status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
    ruleLog.Write("ProElementIntegerSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement pro_e_dpoint_ofst_csys_type{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
    ruleLog.Write("ProElementIntegerSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_ref{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    ProReference REPDEP_ref1{};
    status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
    ruleLog.Write("ProSelectionToReference: " + to_string(status));

    status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
    ruleLog.Write("ProElementReferenceSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_with_dims{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
    ruleLog.Write("ProElementIntegerSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_pnts_array{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_pnt_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_pnt_name_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    wchar_t wide_string[PRO_NAME_SIZE]{};
    ProStringToWstring(wide_string, "datum_PNT1");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
    ruleLog.Write("ProElementWstringSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_dir1_val_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement pro_e_dpoint_ofst_csys_dir2_val_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    double d1 = -pnt_arr[0][2];
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_dir3_val_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_pnt_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement pro_e_dpoint_ofst_csys_pnt_name_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    wchar_t wide_string_2[PRO_PATH_SIZE]{};
    ProStringToWstring(wide_string_2, "datum_PNT2");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
    ruleLog.Write("ProElementWstringSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_dir1_val_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_dir2_val_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    double d2 = -pnt_arr[1][2];
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement pro_e_dpoint_ofst_csys_dir3_val_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProSelection reqMdlSel{};
    status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    ProFeatureCreateOptions* opts = 0;
    status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
    ruleLog.Write("ProArrayAlloc: " + to_string(status));

    ProFeature pnt_feat{};
    opts[0] = PRO_FEAT_CR_NO_OPTS;
    ProErrorlist errors{};
    status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
    ruleLog.Write("ProFeatureWithoptionsCreate: " + to_string(status));

    status = ProArrayFree((ProArray*)&opts);
    ruleLog.Write("ProArrayFree: " + to_string(status));

    status = ProElementFree(&elem_tree);
    ruleLog.Write("ProElementFree: " + to_string(status));

    status = ProSelectionFree(&reqMdlSel);
    ruleLog.Write("ProSelectionFree: " + to_string(status));

    ProSelection pnt_Sel{};
    status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    SelectionhighliteVector.push_back(pnt_Sel);
    return PRO_TK_NO_ERROR;
}

ProError ruleDlgOKaction_IR_F2A01_005(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgOKaction_IR_F2A01_005 -----------------------------");

    int curWinId1{};
    status = ProWindowCurrentGet(&curWinId1);
    ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

    status = ProWindowRepaint(curWinId1);
    ruleLog.Write("ProWindowRepaint: " + to_string(status));

    deleteDatumPointCreatedUsingCsys_IR_F2A01_005("datum_PNT1");
    deleteDatumPointCreatedUsingCsys_IR_F2A01_005("datum_PNT2");

    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return PRO_TK_NO_ERROR;
}

ProError ruleDlgCloseAction_IR_F2A01_005(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgCloseAction_IR_F2A01_005 -----------------------------");

    int curWinId2{};
    status = ProWindowCurrentGet(&curWinId2);
    ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

    status = ProWindowRepaint(curWinId2);
    ruleLog.Write("ProWindowRepaint: " + to_string(status));

    deleteDatumPointCreatedUsingCsys_IR_F2A01_005("datum_PNT1");
    deleteDatumPointCreatedUsingCsys_IR_F2A01_005("datum_PNT2");

    if (data != NULL) {
        bool* quitAction = (bool*)data;
        *quitAction = true;
    }
    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return status;
}

ProError deleteDatumPointCreatedUsingCsys_IR_F2A01_005(char* dtmpoint_name)
{
    ruleLog.Write("----------------------------- deleteDatumPointCreatedUsingCsys_IR_F2A01_005 -----------------------------");

    ProIdTable idtbl1{};
    ProAsmcomppath path{};
    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path);
    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

    wchar_t wdatum_pt[PRO_PATH_SIZE]{};
    ProStringToWstring(wdatum_pt, dtmpoint_name);
    ProModelitem mdl_item{};
    status = ProModelitemByNameInit(curMdl, PRO_POINT, wdatum_pt, &mdl_item);
    ruleLog.Write("ProModelitemByNameInit: " + to_string(status));

    if (status == PRO_TK_NO_ERROR) {

        int* feat_ids = NULL;
        status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
        ruleLog.Write("ProArrayAlloc: " + to_string(status));

        ProFeature feat{};
        status = ProGeomitemFeatureGet((ProGeomitem*)&mdl_item, &feat);
        ruleLog.Write("ProGeomitemFeatureGet: " + to_string(status));
        feat_ids[0] = feat.id;

        ProFeatureDeleteOptions* delete_opts = 0;
        status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
        ruleLog.Write("ProArrayAlloc: " + to_string(status));

        delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;
        status = ProFeatureWithoptionsDelete((ProSolid)curMdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
        ruleLog.Write("ProFeatureWithoptionsDelete: " + to_string(status));

        status = ProArrayFree((ProArray*)&delete_opts);
        ruleLog.Write("ProArrayFree: " + to_string(status));

        status = ProArrayFree((ProArray*)&feat_ids);
        ruleLog.Write("ProArrayFree: " + to_string(status));

    }

    return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID		    |  DEVELOPER			| DEPENDENT MODULES			| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR_F2A01_006	|  Pallavi Garodi		| MF2A01; MF2A02; MF2B07	| Ensure clearance between Beam /Tie rod assembly & Oil sump.
===================================================================================================================*/
#define DLG_F2A01_006   "dlg_IR_F2A01_006"
#define PB_RCANCEL      "PB_RCANCEL"
#define PB_ROK          "PB_ROK"
#define SELECT_PARTS_PB "select_pb"

ComponentData			reqComps_F2A01_006[2]{};
ProSelection*           _sel;
double			        output1, output2;
char                    ParentMdlName[PRO_NAME_SIZE];
int                     curWinId;

vector<ProSelection> ProSelectionVector;

int IRF2A01::IRF2A01_006(ruleResult& final_res)
{
	deleteDatumPointCreatedUsingCsys_IR_F2A01_005("datum_PNT1");
	deleteDatumPointCreatedUsingCsys_IR_F2A01_005("datum_PNT2");

	double               minDistance;
	ruleLog.Write("==========================   IRF2A01::IRF2A01_006   ==========================");

	string reqCompSubModAuto[2] = { "F2A01" , "F2A05" };	// F5A17 will be selected Automatically.
	for (int i = 0; i < subModulesList.size(); ++i) {
		for (int j = 0; j < sizeof(reqCompSubModAuto) / sizeof(reqCompSubModAuto[0]); ++j) {
			if (subModulesList[i].name.find(reqCompSubModAuto[j]) != string::npos) {
				strcpy(reqComps_F2A01_006[j].name, subModulesList[i].name.c_str());
				ruleLog.Write(reqComps_F2A01_006[j].name);
			}
		}
	}
	ruleLog.Write(reqComps_F2A01_006[0].name);
	ruleLog.Write(reqComps_F2A01_006[1].name);
	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&reqComps_F2A01_006);
	for (auto elem : reqComps_F2A01_006) {
		ruleLog.Write("reqComps_F2A01_006[].name = " + string(elem.name));
		ruleLog.Write("reqComps_F2A01_006[].id = " + to_string(elem.id));
	}

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_F2A01_006, DLG_F2A01_006);
	status = ProUIDialogAboveactivewindowSet(DLG_F2A01_006, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_F2A01_006, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F2A01_006, PB_ROK, (ProUIAction)ruleDlgOKaction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F2A01_006, SELECT_PARTS_PB, (ProUIAction)select_action_IRF2A01_006, (ProAppData)&isUserQuits);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_F2A01_006, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_F2A01_006);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);

	//  Compute distances
	rule_sts = measureDistanceBetweenAsmAndPart_IRF2A01_006(reqComps_F2A01_006[0], &_sel[0], output1);
	rule_sts = measureDistanceBetweenAsmAndPart_IRF2A01_006(reqComps_F2A01_006[1], &_sel[0], output2);
	//status = ProSelectionHighlight(_sel[0], PRO_COLOR_HIGHLITE);

	for (size_t i = 0; i < ProSelectionVector.size(); i++) {
		status = ProSelectionHighlight(ProSelectionVector[i], PRO_COLOR_HIGHLITE);
	}

	if (output1 <= 30) {
		//ProWindowRepaint(curWinId);
		rule_sts = highlightParts(reqComps_F2A01_006[0], PRO_COLOR_LETTER);
		status = ProSelectionHighlight(_sel[0], PRO_COLOR_HIGHLITE);
		ruleLog.Write("ProSelectionHighlight = " + to_string(status));
	}
	if (output2 <= 30) {
		//ProWindowRepaint(curWinId);
		rule_sts = highlightParts(reqComps_F2A01_006[1], PRO_COLOR_LETTER);
		status = ProSelectionHighlight(_sel[0], PRO_COLOR_HIGHLITE);
		ruleLog.Write("ProSelectionHighlight = " + to_string(status));
	}

	//UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention!",
		//"The computed clearance is between oil sump to Beam and Tie rod assembly. Parts are highlighted in cad session.\nclick on Ok to dispaly the results.");

	char				formattedNumber1[20];
	output1 = round(output1 * 100) / 100;
	// Remove trailing zeros from the second decimal place
	sprintf(formattedNumber1, "%.2f", output1);
	int length1 = strlen(formattedNumber1);
	while (length1 > 0 && formattedNumber1[length1 - 1] == '0') {
		formattedNumber1[length1 - 1] = '\0';
		length1--;
	}
	double num = stod((1, formattedNumber1)); // Convert char to int

	char				formattedNumber2[20];
	output2 = round(output2 * 100) / 100;
	// Remove trailing zeros from the second decimal place
	sprintf(formattedNumber2, "%.2f", output2);
	int length = strlen(formattedNumber2);
	while (length > 0 && formattedNumber2[length - 1] == '0') {
		formattedNumber2[length - 1] = '\0';
		length--;
	}
	double num1 = stod((1, formattedNumber2)); // Convert char to int

	// Find the min distance
	minDistance = ((num) < (num1)) ? (num) : (num1);

	char				formattedNumber3[20];
	minDistance = round(minDistance * 100) / 100;
	// Remove trailing zeros from the second decimal place
	sprintf(formattedNumber3, "%.2f", minDistance);
	int length2 = strlen(formattedNumber3);
	while (length2 > 0 && formattedNumber3[length2 - 1] == '0') {
		formattedNumber3[length2 - 1] = '\0';
		length2--;
	}

	if (minDistance < 30.0)
	{
		final_res.result = "FAIL";
	}
	else
	{
		final_res.result = "PASS";
	}

	string rem_message;
	//DECLARE RESULT

	rem_message += "Minimum clearance between Beam /Tie rod assembly & Oil sump is ";
	rem_message += (formattedNumber3);
	rem_message += "mm.\n\n";
	rem_message += "Selected Refrences:" + (string)ParentMdlName + ".prt\n";
	for (auto elem : reqComps_F2A01_006) {
		rem_message += "Clearance between " + (string)ParentMdlName + ".prt and " + (string)reqComps_F2A01_006[0].name + ".ASM is " + (formattedNumber1)+"mm.\n";
		break;
	}
	for (auto elem : reqComps_F2A01_006) {
		rem_message += "Clearance between " + (string)ParentMdlName + ".prt and " + (string)reqComps_F2A01_006[1].name + ".ASM is " + (formattedNumber2)+"mm.\n\n";
		break;
	}

	rem_message += "Acceptance criteria: Clearance between Beam/Tie rod assembly & Oil sump shoule be greater than 30.";
	rem_message += "\n                   (Suspention metal to metal condition)";
	final_res.remark = rem_message;

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	ProSelectionVector.clear();
	return 0;
}

ProError select_action_IRF2A01_006(char* dialog, char* component, ProAppData data)
{

	int	                      nsel;
	InterfaceRule     _irule;
	ProAsmcomppath	  part_asmcomp_path;
	ProMdl	          parent_mdl;
	wchar_t           wParentMdlName[PRO_NAME_SIZE];
	status = ProUIPushbuttonDisable(DLG_F2A01_006, PB_ROK);
	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);

	status = ProSelect((char*)"part", 1, NULL, NULL, NULL, NULL, &_sel, &nsel);
	ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(nsel));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_F2A01_006, PB_ROK);
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide inputs again!. Refer help document for details.");
		status = ProUIDialogShow(DLG_F2A01_006);
		return status;
	}

	if (nsel < 1 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIDialogShow(DLG_F2A01_006);
		status = ProUIPushbuttonDisable(DLG_F2A01_006, PB_ROK);
		return status;
	}

	status = ProSelectionAsmcomppathGet(_sel[0], &part_asmcomp_path);
	ruleLog.Write("ProSelectionAsmcomppathGet = " + to_string(status));

	// to find the parent component
	//part_asmcomp_path.comp_id_table[part_asmcomp_path.table_num - 1] = -1;
	//part_asmcomp_path.table_num = part_asmcomp_path.table_num - 1;

	status = ProAsmcomppathMdlGet(&part_asmcomp_path, &parent_mdl);
	ruleLog.Write("ProAsmcomppathMdlGet = " + to_string(status));

	status = ProMdlMdlnameGet(parent_mdl, wParentMdlName);
	ProWstringToString(ParentMdlName, wParentMdlName);
	ruleLog.Write("cParentMdlName = " + (string)ParentMdlName);

	status = ProUIPushbuttonEnable(DLG_F2A01_006, PB_ROK);
	return status;
}

int measureDistanceBetweenAsmAndPart_IRF2A01_006(ComponentData reqComp1, ProSelection* Part_sel, double& distance)
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenAsmAndPart <=================");
	ProSelection sels[1];
	ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected
	ProName comp1_name;
	ProModelitem feature[1];
	ProMdl reqMdls[1];
	InterfaceRule     _irule;

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProAsmcomppath path[1];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	//status = ProSelectionHighlight(sels[0], PRO_COLOR_HIGHLITE);

	////ProSelection* Part_sel;
	//int n_sels;
	//status = ProSelect((char*)"prt_or_asm", 1, NULL, NULL, NULL, NULL, &Part_sel, &n_sels);
	//ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels));

	ProBoolean is_interference_found;
	Pro3dPnt pnt_arr[2];
	status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_NONE, *Part_sel, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, sels[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));


	if (distance < 30) {
		ProSelectionVector.push_back(sels[0]);
	}

	ProWindowRepaint(curWinId);
	createDatumPointsusingCSYS_IR_F2A01_005(pnt_arr, "CSYS_ASM_DEF");
	_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention!",
		"The computed clearance is distance between the highlighted points.(DIST_HIGHLIGHT_PNT)\nclick on Ok to dispaly the results.");

	/*Pro2dPnt param_surfs1, param_surfs2;
	Pro3dPnt pnt_surfs[2];

	status = ProSelectionWithOptionsDistanceEval(sels[0], PRO_B_TRUE, *Part_sel, PRO_B_TRUE, param_surfs1, param_surfs2, pnt_surfs[0], pnt_surfs[1], &distance);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance_bw_surfs: " + to_string(distance));*/
	return 0;
}

#pragma pop