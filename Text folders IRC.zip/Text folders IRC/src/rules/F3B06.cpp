/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F3B06 - EXHAUST SYSTEM RULES
==================================================================================================================*/
#include "F3B06.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F3B06-003	| Pallavi Garodi 	| MF3B06			| Verify orientation of Diffuser in tail pipe against design rule recommendation of 15 Deg
===================================================================================================================*/
#define DLG_IRF3B06_003 "dlg_IR_F3B06_003"
#define PB_RCANCEL      "rule_cancel_pb"
#define PB_ROK			"rule_ok_pb"
#define PB_IMG			"pb_image"
#define PB_RBUTTON      "pb_rbutton"
#define InputPanel	    "InputPanel"

boolean  _ruleSts;
wchar_t* enterValue;
char     c_Value[PRO_NAME_SIZE];
vector<double>finalValue;
int rightInput = 0;

int IRF3B06::IRF3B06_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF3B02::IRF3B06_003   ==========================");

	int	n_names;
	char** r_names;
	rightInput = 0;
	char R2[PRO_NAME_SIZE] = "r2";
	char* ptrR2 = R2;
	_ruleSts = TRUE;
	char		  formattedNumber[20];

	status = ProUIDialogCreate(DLG_IRF3B06_003, DLG_IRF3B06_003);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRF3B06_003, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF3B06_003, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIOptionmenuInputActionSet(DLG_IRF3B06_003, InputPanel, (ProUIAction)input, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF3B06_003, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));


	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF3B06_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF3B06_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	// rounding the values to two decimal place
	finalValue[0] = round(finalValue[0] * 100) / 100;

	// Remove trailing zeros from the second decimal place
	sprintf(formattedNumber, "%.2f", finalValue[0]);
	int length = strlen(formattedNumber);
	while (length > 0 && formattedNumber[length - 1] == '0') {
		formattedNumber[length - 1] = '\0';
		length--;
	}
	ruleLog.Write(formattedNumber);

	ruleLog.Write("check = " + to_string(rightInput));
	if (rightInput != 0)
	{
		if ((finalValue[0]) >= 15) {
			isRightValue = true;
		}

		// DECLARE RESULT
		if (isRightValue)
			final_res.result = "PASS";
		else
			final_res.result = "FAIL";

		string rem_message;
		rem_message += "Provided orientation of Diffuser in tail pipe is " + string(formattedNumber) + "0 Deg.\n\n";
		rem_message += "Acceptance Criteria :- \n";
		rem_message += "Orientation of Diffuser in tail pipe must be greater than or equal to 15 Deg.";
		final_res.remark = rem_message;

		ruleLog.Write("status: " + final_res.result);
		ruleLog.Write("remark: " + final_res.remark);
	}
	else
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide diffuser angle in deg, Refer help document for details.");
		status = ProUIDialogShow(DLG_IRF3B06_003);
		status = ProUIPushbuttonDisable(DLG_IRF3B06_003, PB_ROK);
		//return status;
	}

	finalValue.clear();
	return 0;
}

ProError input(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- input -----------------------------");
	finalValue.clear();
	double A;

	status = ProUIPushbuttonDisable(DLG_IRF3B06_003, PB_ROK);
	status = ProUIInputpanelValueGet(DLG_IRF3B06_003, "InputPanel", &enterValue);
	ruleLog.Write("PoUIInputpanelValueGet  status = " + to_string(status));
	ProWstringToString(c_Value, enterValue);

	ruleLog.Write("check 1");
	//double A = stod(c_offsetValue);
	ruleLog.Write("check 2");
	string str(c_Value);
	if (foundDouble(str))
	{
		ruleLog.Write("Valid");
		A = stod(c_Value);
		/*B = abs(A);
		ruleLog.Write("check 3");
		C = B * -1;*/
		ruleLog.Write("finalValue: " + to_string(A));
		finalValue.push_back(A);
		++rightInput;
	}

	if ((finalValue.size()) != 0) {
		status = ProUIPushbuttonEnable(DLG_IRF3B06_003, PB_ROK);
	}
	return PRO_TK_NO_ERROR;
}

bool foundDouble(const string& str) {
	istringstream ss(str);
	double value;
	ss >> noskipws >> value;
	return ss.eof() && !ss.fail();
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES			| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F3B06-004	| ATHARVA PATIL 	| MF3B03;					| Routing on Tail pipe Assembly in vehicle should consider clearance 
																  with ramp over and departure angles while designing.
===================================================================================================================*/
//#define DLG_F3B06_004		"dlg_IR_F3B06_004"
//#define PB_RCANCEL			"Commit_Cancel"
//#define PB_ROK				"Commit_Ok"
//#define PB_SELECT_TYRE      "pb_select_tyre"
//#define Label_tyre			"Lable_sel_tyre"
//#define PB_SELECT_FRAME     "pb_select_frame"
//#define Label_frame			"Lable_sel_frame"
//#define Label_SLRf			"Label_SLRf"
//#define Label_SLRr			"Label_SLRr"
//#define InputPanel_Rrf		"InputPanel_Rrf"
//#define InputPanel_Rrr		"InputPanel_Rrr"
//
//int IRF3B06::IRF3B06_004(ruleResult& final_res)
//{
//	ruleLog.Write("==========================   IRF3B06::IRF3B06_004   ==========================");
//	
//	return 0;
//}