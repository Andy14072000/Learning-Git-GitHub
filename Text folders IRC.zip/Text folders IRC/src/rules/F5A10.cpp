/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 18-03-2023	|	V1_0_0		| F5A20 - BRAKING SYSTEM RULES
==================================================================================================================*/
#include "F5A10.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER		| DEPENDENT MODULES    | DESCRIPTION
------------------------------------------------------------------------------------------------------------------
IRF5A10_001 	| Ved Aiyar     | MF5A10               | Clearance of brake electronic valve with dynamic parts to be maintained.
===================================================================================================================*/

#define DLG_IRF5A10_001 "dlg_IR_F5A10_001"
#define PB_ROK			"CommitOK"
#define PB_RCLOSE		"CommitCancel"

double                              standard_clearance_F5A10001 = 40.00, measured_clearance_F5A10001;
//double toleranceF5A10001 = 0.001;
vector<int>                         ID_mapf5a10001;
string                              remF5A10001 = "";
int                                 tarrayf5a10001[100] = { 0 }; // Initialize all elements to 0 (or any default value)
vector<Model_Tree_Information>      treeInformationVectorf5a10001, selection_items_F5A10001;

int IRF5A10::IRF5A10_001(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF5A10::IRF5A10_007   ==========================");

    deleteDatumPoint("datum_PNT1");
    deleteDatumPoint("datum_PNT2");
    Clear_Memory_F5A10001();

    //remF5A10001.append("Distance measured from Electronic Brake Valve to propeller shaft is: \n\n");

    status = ProUIDialogCreate(DLG_IRF5A10_001, DLG_IRF5A10_001);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF5A10_001, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A10_001, PB_RCLOSE, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A10_001, PB_ROK, (ProUIAction)ruleDlgOKactionf5a10001, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF5A10_001, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF5A10_001);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;


    //selection_items_F5A10001[2].dist_chk = FALSE;

    /*for (int i = 1; i < selection_items_F5A10001.size(); i++)
    {
        ruleLog.Write("Name: " + selection_items_F5A10001[i].name + " Description: " + selection_items_F5A10001[i].description + " Distance " + to_string(selection_items_F5A10001[i].distance) + "mm [" + to_string(selection_items_F5A10001[i].dist_chk) + "] ID Path:");
        for (int id : selection_items_F5A10001[i].ID_path)
        {
            ruleLog.Write(to_string(id));
        }
    }*/

    isRightValue = FALSE;
    if (measured_clearance_F5A10001 >= standard_clearance_F5A10001)
    {
        isRightValue = TRUE;
    }


    remF5A10001.append("Measured distance between " + selection_items_F5A10001[0].name + ".asm [" + selection_items_F5A10001[0].description + "] \n");
    remF5A10001.append("and " + selection_items_F5A10001[1].name + ".asm [" + selection_items_F5A10001[1].description + "] is " + doubleToString(measured_clearance_F5A10001) + "mm.\n\n");

    /*
    * selection_items_F5A10001[0].name
    * selection_items_F5A10001[0].description
    * selection_items_F5A10001[1].name
    * selection_items_F5A10001[1].description
    measured_clearance_F5A10001

    */
    remF5A10001.append("Acceptance criteria: Clearance between Electronic valve and Propeller shaft  >= 40.00mm");

    final_res.remark = remF5A10001;

    // DECLARE RESULT
    if (isRightValue)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    return 0;
}

ProError UserAsmCompFilterf5a10001(ProFeature* feature, ProAppData app_data)
{
    ProError status;
    ProFeattype ftype;

    status = ProFeatureTypeGet(feature, &ftype);

    if (ftype == PRO_FEAT_COMPONENT)
        return(PRO_TK_NO_ERROR);
    return(PRO_TK_CONTINUE);
}

ProError user_actionf5a10001(ProFeature* feature, ProError status, ProAppData appdata)
{
    FILE* fp;
    int level;
    ProMdl mdl27;
    char name27[PRO_MDLNAME_SIZE];
    char type[PRO_MDLEXTENSION_SIZE];
    UserAppdata* appd, appd1;
    ProMdlName modelName;
    ProMdlExtension modelExtension;
    ProAsmcomppath comppath;
    ProModelitem modelItem;
    char existingPval[PRO_NAME_SIZE]{};

    //ProModelitem p_item27;
    ProIdTable table;
    //table[0] = -1;
    //int ID;

    appd = (UserAppdata*)appdata;
    fp = appd->fp;
    level = appd->level;

    status = ProAsmcompMdlGet(feature, &mdl27);
    status = ProMdlMdlnameGet(mdl27, modelName);
    status = ProMdlExtensionGet(mdl27, modelExtension);

    ProWstringToString(name27, modelName);
    ProWstringToString(type, modelExtension);

    //if (strncmp(type, "ASM", 3) == 0 || strncmp(type, "PRT", 3))
    //{
    ID_mapf5a10001.push_back(feature->id);
    //component_path.push_back(ID_mapf2c01004);

    appd1.fp = appd->fp;
    appd1.level = appd->level + 1;

    //numberofasm++;

    status = ProMdlToModelitem(mdl27, &modelItem);
    //ruleLog.Write("ProMdlToModelitem: " + to_string(status));
    ProParameter pDesc;
    ProParamvalue pvDesc;
    ProName pDescName = L"DESCRIPTION";
    status = ProParameterInit(&modelItem, pDescName, &pDesc);
    //ruleLog.Write("ProParameterInit: " + to_string(status));

    if (status == PRO_TK_NO_ERROR)
    {
        status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
        ProWstringToString(existingPval, pvDesc.value.s_val);
        Model_Tree_Information tree1;
        tree1.name = string(name27);
        tree1.extension = string(type);
        tree1.ID = feature->id;
        tree1.description = existingPval;
        tree1.ID_path = ID_mapf5a10001;
        tree1.ID_table_size = ID_mapf5a10001.size();

        treeInformationVectorf5a10001.push_back(tree1);
        /*ruleLog.Write("Name of assembly = " + string(name27) + " , ID = " + to_string(feature->id) + " , Description = " + existingPval);
        for (int id : tree1.ID_path)
        {
            ruleLog.Write(to_string(id) + " ");
        }*/
    }

    status = ProSolidFeatVisit((ProSolid)mdl27, user_actionf5a10001, UserAsmCompFilterf5a10001, &appd1);
    ID_mapf5a10001.pop_back();
    //}
    return(PRO_TK_CONTINUE);
}

ProError ruleDlgOKactionf5a10001(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgOKaction -----------------------------");

    char name[PRO_MDLNAME_SIZE];
    char type[PRO_MDLEXTENSION_SIZE];
    ProError status;
    UserAppdata appdata;
    FILE* fp{};
    ProMdl p_asm;
    ProMdl reqMdlsair1hs, mdl;
    ProMdlName modelName;
    ProMdlExtension modelExtension;
    //double distance;
    int count = -1;
    Pro3dPnt pnt_arr[2];
    //int ex, tail, sil;


    status = ProMdlCurrentGet(&p_asm);
    status = ProMdlMdlnameGet(p_asm, modelName);
    ProWstringToString(name, modelName);
    status = ProMdlExtensionGet(p_asm, modelExtension);
    ProWstringToString(type, modelExtension);

    appdata.fp = fp;
    appdata.level = 1;

    status = ProSolidFeatVisit((ProSolid)p_asm, user_actionf5a10001, UserAsmCompFilterf5a10001, &appdata);


    for (int i = 0; i < treeInformationVectorf5a10001.size(); i++)
    {
        if (treeInformationVectorf5a10001[i].name.find("F5A10") != std::string::npos)
        {
            selection_items_F5A10001.push_back(treeInformationVectorf5a10001[i]);
        }
    }
    for (int i = 0; i < treeInformationVectorf5a10001.size(); i++)
    {
        if (treeInformationVectorf5a10001[i].name.find("F2C01") != std::string::npos)
        {
            selection_items_F5A10001.push_back(treeInformationVectorf5a10001[i]);
        }
    }
    for (int i = 0; i < selection_items_F5A10001.size(); i++)
    {
        ruleLog.Write("Sub-Module: " + selection_items_F5A10001[i].sub_mod_name + "Name: " + selection_items_F5A10001[i].name + " ID: " + to_string(selection_items_F5A10001[i].ID) + " Description: " + selection_items_F5A10001[i].description + " ID Path:");
        for (int id : selection_items_F5A10001[i].ID_path)
        {
            ruleLog.Write(to_string(id));
        }
    }

    //Set Selections
    for (int i = 0; i < selection_items_F5A10001.size(); i++)
    {
        ProIdTable id_table{};
        ProMdl reqMdlsair;
        ProName compair;
        ProModelitem featureair;
        // Create a character array with a size one larger than the string to accommodate the null terminator
        char charArray[100];

        // Copy the contents of the std::string to the character array
        strcpy(charArray, selection_items_F5A10001[i].name.c_str());
        ProStringToWstring(compair, charArray);

        status = ProMdlnameInit(compair, PRO_MDLFILE_ASSEMBLY, &reqMdlsair);
        ruleLog.Write("ProMdlnameInit status = " + to_string(status));

        status = ProMdlToModelitem(reqMdlsair, &featureair);
        ruleLog.Write("ProMdlToModelitem status = " + to_string(status));

        vector temp = selection_items_F5A10001[i].ID_path;
        int vectorSize = selection_items_F5A10001[i].ID_path.size();
        //tbl1_sizef5a27006 = vectorSize;

        for (int j = 0; j < vectorSize; ++j)
        {
            tarrayf5a10001[j] = temp[j];
        }

        // Print the elements in the array
        //std::cout << "Array elements:";

        for (int j = 0; j < vectorSize; ++j)
        {
            id_table[j] = tarrayf5a10001[j];
        }

        ProAsmcomppath pathair;
        ProSelection sel;
        status = ProAsmcomppathInit((ProSolid)curMdl, id_table, vectorSize, &pathair);
        ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));

        status = ProSelectionAlloc(&pathair, &featureair, &sel);
        ruleLog.Write("ProSelectionAlloc status = " + to_string(status));

        selection_items_F5A10001[i].sela = sel;
        /*status = ProSelectionHighlight(selection_items_F5A10001[i].sela, PRO_COLOR_HIGHLITE);
        ruleLog.Write("ProSelectionHighlight status = " + to_string(status));*/
    }


    double distance;
    ProBoolean is_interference_found;
    status = ProFitClearanceCompute(selection_items_F5A10001[0].sela, PRO_FIT_INCLUDE_NONE, selection_items_F5A10001[1].sela, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, selection_items_F5A10001[1].sela, PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
    ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));
    measured_clearance_F5A10001 = distance;
    createDatumPointsF5A10001(pnt_arr, "CSYS_ASM_DEF");

    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return PRO_TK_NO_ERROR;
}

int createDatumPointsF5A10001(Pro3dPnt pnt_arr[2], char* csysName)
{

    ruleLog.Write("=================> InterfaceRule::createDatumPoints <=================");
    ProElement  elem_tree, elem_ftype, elem_feature_name,
        pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
        pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
        pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
    ProReference REPDEP_ref1;
    wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wide_string[PRO_NAME_SIZE], wide_string_2[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE];
    //CSYS_ASM_DEF
    ProModelitem refCsysitem;
    ProSelection refCsysSel, reqMdlSel;
    ProFeatureCreateOptions* opts = 0;
    ProFeature pnt_feat;
    ProErrorlist errors;
    //converting negative values to positive
    double d1 = -pnt_arr[0][2];
    double d2 = -pnt_arr[1][2];
    char cDatumPointName[PRO_NAME_SIZE] = "Dist_highlght_pnt";

    ProStringToWstring(wCsysName, csysName);
    status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
    status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);


    //Create Element Tree
    status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
    ruleLog.Write("Tree root status = " + to_string(status));

    // TREE ALLOCATION
    status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
    ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
    ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
    ruleLog.Write("type status = " + to_string(status));

    //feature name
    status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
    status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, cDatumPointName));
    status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
    ruleLog.Write("feature name = " + to_string(status));

    //PRO_E_DPOINT_TYPE
    status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
    status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
    ruleLog.Write("type status = " + to_string(status));

    //Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);

    //ref
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
    status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
    status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);

    //
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);

    //Populating array element
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);

    //Point1
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);

    //Point1 Name
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
    ProStringToWstring(wide_string, "datum_PNT1");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);

    //PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);

    //PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);

    //PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);

    //Point2
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);

    //Point2 Name
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
    ProStringToWstring(wide_string_2, "datum_PNT2");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);

    ////PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);

    ////PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);

    ////PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);

    /* =============================================================== *\
    Create Model Selection Object
    \* =============================================================== */

    status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
    ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
    status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

    opts[0] = PRO_FEAT_CR_NO_OPTS;

    // Create Points
    status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
    ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

    status = ProArrayFree((ProArray*)&opts);
    status = ProElementFree(&elem_tree);
    status = ProSelectionFree(&reqMdlSel);

    ProSelection pnt_Sel;
    status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
    status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_ERROR);
    //PRO_COLOR_SELECTED for green highlight
    return 0;
}

void Clear_Memory_F5A10001()
{
    treeInformationVectorf5a10001.clear();
    selection_items_F5A10001.clear();
    ID_mapf5a10001.clear();
    remF5A10001.clear();
}

/*==================================================================================================================
RULE ID			| DEVELOPER		| DEPENDENT MODULES    | DESCRIPTION
------------------------------------------------------------------------------------------------------------------
IRF5A10_007 	| Ved Aiyar     | MF5A10               | Clearance between electronic valve and mounting bracket to be defined.
===================================================================================================================*/

#define DLG_IRF5A10_007 "dlg_IR_F5A10_007"
#define PB_RSELECT		"pb_select"
#define PB_ROK			"CommitOK"
#define PB_RCLOSE		"CommitClose"

vector<double> distance_Xf5a10007;

int IRF5A10::IRF5A10_007(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF5A10::IRF5A10_007   ==========================");

    int curWinId;
    double Standard_valuef5a10007 = 5;

    status = ProUIDialogCreate(DLG_IRF5A10_007, DLG_IRF5A10_007);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));
    status = ProUIDialogAboveactivewindowSet(DLG_IRF5A10_007, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A10_007, PB_RCLOSE, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A10_007, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A10_007, PB_RSELECT, (ProUIAction)select_action_IRF5A10_007, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIDialogHide(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogHide: " + to_string(status));
    status = ProUIDialogActivate(DLG_IRF5A10_007, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF5A10_007);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogShow: " + to_string(status));

    if (isUserQuits)
        return -1;

    string rmkstr = "";
    for (int i = 0; i < distance_Xf5a10007.size(); i++) {
        double roundedValue = round(distance_Xf5a10007[i] * 100) / 100;
        rmkstr += "Clearance between pair " + to_string(i + 1) + " = " + to_string(roundedValue) + "mm";
        rmkstr += "\n";
        if (distance_Xf5a10007[i] < Standard_valuef5a10007) {
            isRightValue = false;
            break;
        }
    }

    rmkstr += "Acceptance criteria: Clerance needs to be >= 5mm";

    if (isRightValue == true)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    final_res.remark = rmkstr;

    ruleLog.Write("final_res.status: " + string(final_res.result));
    ruleLog.Write("final_res.remark: " + string(final_res.remark));

    distance_Xf5a10007.clear();
    rmkstr.clear();
    return 0;
}

ProError select_action_IRF5A10_007(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("--------------------------  select_action_IRF5A10_007  --------------------------");

    int n_sels1, n_sels2;
    ProSelection* Selsf5a100071 = nullptr;
    ProSelection* Selsf5a100072 = nullptr;
    double clearance{};
    double clearance2{};
    int curWinId;

    status = ProWindowCurrentGet(&curWinId);
    ruleLog.Write("ProWindowCurrentGet status = " + to_string(status));

    status = ProWindowRepaint(curWinId);
    ruleLog.Write("ProWindowRepaint status = " + to_string(status));

    _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Pair 1 Selection", "Please select valid surfaces for pair 1 ");

    status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &Selsf5a100071, &n_sels1);
    ruleLog.Write("ProSelect: " + to_string(status));

    Pro2dPnt param_surfs11{}, param_surfs21{};
    Pro3dPnt pnt_surfs11{}, pnt_surfs21{};

    status = ProSelectionWithOptionsDistanceEval(Selsf5a100071[0], PRO_B_TRUE, Selsf5a100071[1], PRO_B_TRUE, param_surfs11, param_surfs21, pnt_surfs11, pnt_surfs21, &clearance);
    ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance_bw_surfs: " + to_string(clearance));
    distance_Xf5a10007.push_back(clearance);

    _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Pair 2 Selection", "Please select valid surfaces for pair 2 ");

    status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &Selsf5a100072, &n_sels2);
    ruleLog.Write("ProSelect: " + to_string(status));

    Pro2dPnt param_surfs12{}, param_surfs22{};
    Pro3dPnt pnt_surfs12{}, pnt_surfs22{};

    status = ProSelectionWithOptionsDistanceEval(Selsf5a100072[0], PRO_B_TRUE, Selsf5a100072[1], PRO_B_TRUE, param_surfs12, param_surfs22, pnt_surfs12, pnt_surfs22, &clearance2);
    ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance_bw_surfs: " + to_string(clearance2));
    distance_Xf5a10007.push_back(clearance);

    status = ProUIPushbuttonEnable(dialog, PB_ROK);
    return status;
}
#pragma pop