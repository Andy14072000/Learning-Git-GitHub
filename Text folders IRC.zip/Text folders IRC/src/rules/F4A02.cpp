/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-04-2023	|	V1_0_0		| F4A02 - FRONT SUSPENSION RULES
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#include "F4A02.h"

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF4A02001		| Ved Aiyar			| MF4A02			|  Standard leaf spring type across platform based on application.  E.g.parabolic, semielliptical etc
===================================================================================================================*/
// UI DEFINITIONS
#define DLG_F4A02_001		"dlg_IR_F4A02_001" 
#define OM_SPRING_TYPE		"spring_type_option_menu" 
#define PB_RCANCEL			"rule_cancel_pb" 
#define PB_ROK				"rule_ok_pb"
#define PB_RIMG				"suspension_img"
string sSpringType = "";
string final_acceptance_criteria = "";

int IRF4A02::IRF4A02_001(ruleResult &final_res)
{
	ruleLog.Write("==========================   IRF4A02::IRF4A02_001   ==========================");

	SubModuleInfo _reqSMinfo;
	char cReqMdlPath[PRO_PATH_SIZE];
	ProPath wReqMdlPath;
	ProMdl reqMdl{};
	ProModelitem reqMdlitem;
	vector<IntAndStringlistMap> leafspringMapList;
	vector<string> optionMenuSpringTypes;
	int n_opsel;
	char** opsel;
	char opMenuName[PRO_NAME_SIZE]{};

	// get the submodule name from list
	for (int i = 0; i < subModulesList.size(); ++i)
		if(subModulesList[i].name.find("F4A02") != string::npos){
			_reqSMinfo = subModulesList[i];
			break;
		}

	// retrieve the submodule model
	sprintf(cReqMdlPath, "%s%s.asm", cCurMdlPath, _reqSMinfo.name.c_str());
	ruleLog.Write("cReqMdlPath: "+string(cReqMdlPath));
	ProStringToWstring(wReqMdlPath, cReqMdlPath);
	status = ProMdlnameRetrieve(wReqMdlPath, PRO_MDLFILE_ASSEMBLY, &reqMdl);
	ruleLog.Write("ProMdlnameRetrieve: "+to_string(status));
	if(status != PRO_TK_NO_ERROR)
		return -1;

	// retrieve the mapped data from csv
	vector<vector<string>> dbList2D = getData2D("IRF4A02001.csv");
	ruleLog.Write("dbList2D.size(): "+ to_string(dbList2D.size()));
	for(int i = 1; i< dbList2D.size(); ++i)	// i = 1 for skipping the headers
	{
		IntAndStringlistMap _temp;
		_temp.intval = stoi(dbList2D[i][2]);		
		ruleLog.Write("project_code: "+ dbList2D[i][2]);

		std::istringstream ss2(dbList2D[i][3]);
		string tok2;
		while (std::getline(ss2, tok2, ';'))
		{
			trimString(tok2);
			ruleLog.Write("spring type: "+tok2);
			_temp.strList.push_back(tok2);
			if(find(optionMenuSpringTypes.begin(), optionMenuSpringTypes.end(), tok2) == optionMenuSpringTypes.end()){
				optionMenuSpringTypes.push_back(tok2);
			}
		}
		leafspringMapList.push_back(_temp);
	}
	status = ProUIPushbuttonHide(DLG_F4A02_001, PB_RIMG);
	//optionMenuSpringTypes.insert(optionMenuSpringTypes.begin(), "   -   ");

	// get the description of the components
	vector<PartnameDescriptionPair> name_desc_list;
	status = ProSolidFeatVisit((ProSolid)reqMdl, getParameterDescAndPartname_F4A02_001, compsFilter, (ProAppData)&name_desc_list);

	// optionally assign the spring type found from description
	int pos = -1;
	for (auto item : name_desc_list)
	{
		ruleLog.Write("item.description : "+string(item.description));
		for(auto type : optionMenuSpringTypes)
		{
			int pos = string(item.description).find(type);
			if(pos >= 0){
				sSpringType = type;
				break;
			}
		}
	}
	//ruleLog.Write(sSpringType);

	if (sSpringType != "")
	{
		ruleLog.Write("Description sSpringType: " + sSpringType);
		// Bring the sSpringType to the start of the vector
		auto it = std::find(optionMenuSpringTypes.begin(), optionMenuSpringTypes.end(), sSpringType);
		if (it != optionMenuSpringTypes.end()) {
			std::rotate(optionMenuSpringTypes.begin(), it, it + 1);
		}
		// Remove Select from vector
		optionMenuSpringTypes.erase(std::remove(optionMenuSpringTypes.begin(), optionMenuSpringTypes.end(), "Select"), optionMenuSpringTypes.end());
		ProUIPushbuttonEnable(DLG_F4A02_001 , PB_ROK);
	}
	// GET USER INPUT FOR LEAF SPRING TYPE
	status = ProUIDialogCreate(DLG_F4A02_001, DLG_F4A02_001);
	status = ProUIDialogAboveactivewindowSet(DLG_F4A02_001, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_F4A02_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	if (sSpringType != ""){
		status = ProUIPushbuttonEnable(DLG_F4A02_001, PB_ROK);
		status = ProUIPushbuttonShow(DLG_F4A02_001, PB_RIMG);
	}
	else{
		status = ProUIPushbuttonDisable(DLG_F4A02_001, PB_ROK);
		status = ProUIPushbuttonHide(DLG_F4A02_001, PB_RIMG);
	}
	// For Spring Dropdown
	string SpringtypeOpMenuSelActionData[2] = {OM_SPRING_TYPE, sSpringType};
	status = ProUIPushbuttonActivateActionSet(DLG_F4A02_001, PB_ROK, (ProUIAction)getSelectedTypeOpMenuf4a02, (ProAppData)&SpringtypeOpMenuSelActionData);	
	// For Spring Image
	string optionMenuActionData[2] = {PB_RIMG, "IR_F4A02_001"};
	status = ProUIOptionmenuSelectActionSet(DLG_F4A02_001, OM_SPRING_TYPE, (ProUIAction)optionMenuImageChangeActionf4a02, (ProAppData)&optionMenuActionData);

	// set option menu names
	char **springtypeListNames;
	wchar_t **springtypeListLabels;
	status = ProArrayAlloc(optionMenuSpringTypes.size(), sizeof(char *), 1, (ProArray *)&springtypeListNames);
	status = ProArrayAlloc(optionMenuSpringTypes.size(), sizeof(wchar_t *), 1, (ProArray *)&springtypeListLabels);
	for (int i=0; i<optionMenuSpringTypes.size(); ++i)
	{
		springtypeListNames[i] = (char *)calloc(PRO_NAME_SIZE, sizeof(char));
		ProTKSprintf(springtypeListNames[i], "%s", optionMenuSpringTypes[i]);

		springtypeListLabels[i] = (wchar_t *)calloc(PRO_NAME_SIZE, sizeof(wchar_t));
		ProStringToWstring(springtypeListLabels[i], springtypeListNames[i]);
	}
	status = ProUIOptionmenuNamesSet (DLG_F4A02_001, OM_SPRING_TYPE, int(optionMenuSpringTypes.size()), springtypeListNames);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet (DLG_F4A02_001, OM_SPRING_TYPE, int(optionMenuSpringTypes.size()), springtypeListLabels);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

	status = ProArrayFree((ProArray*)&springtypeListNames);
	status = ProArrayFree((ProArray*)&springtypeListLabels);

	// setting up default image for both cases
	if (sSpringType != "")
	{
		string img = "IR_F4A02_001/" + sSpringType + ".png";
		//const char* charPtr = img.data();
		const char* constCharPtr = img.data();
		char* charPtr = const_cast<char*>(constCharPtr);
		status = ProUIPushbuttonBitmapSet(DLG_F4A02_001, PB_RIMG, charPtr);	// default image
		ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));
	}
	else{
		status = ProUIPushbuttonBitmapSet(DLG_F4A02_001, PB_RIMG, "IR_F4A02_001/blank.png");// default image
		ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));
	}
	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_F4A02_001, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_F4A02_001);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if(isUserQuits)	// check for user quits in close_action
		return -1;

	project_code = stoi(string(_reqSMinfo.name).substr(0,4));
	ruleLog.Write("Project Code: "+ to_string(project_code));

	bool springFound = false;
	for(auto item : leafspringMapList)//looping the list of VC codes and corresponding spring types
	{
		if(item.intval == project_code)//check if the opened project code is present in the list
		{
			ruleLog.Write("Spring Types:");
			for (auto type : item.strList)
			{
				ruleLog.Write("\t"+type);
				// remarks (acceptance criteria)
				acceptance_criteria.append(type + ", ");
				if(type.compare(sSpringType) == 0)
				{
					springFound = true;
				}
			}
		}
	}
	bool first = true;
	for (const std::string& option : optionMenuSpringTypes)
	{
		//ruleLog.Write(option);
		if (acceptance_criteria.find(option) != std::string::npos)
		{
			if (!first)
			{
				final_acceptance_criteria.append(", ");
			}
			final_acceptance_criteria.append(option);
			first = false;
			//std::cout << "found!" << '\n';
		}
	}

	// DECLARE RESULT
	sprintf(remark, "Used Leaf spring = %s;Acceptance criteria: %s", sSpringType.c_str(), final_acceptance_criteria.c_str());
	if(!springFound){
		final_res.result = "FAIL";
	}
	else{
		final_res.result = "PASS";
	}
	final_res.remark = string(remark);

	ruleLog.Write("status: "+string(final_res.result));
	ruleLog.Write("remark: "+string(final_res.remark));

	name_desc_list.clear();
	dbList2D.clear();
	optionMenuSpringTypes.clear();
	leafspringMapList.clear();
	final_acceptance_criteria.clear();
	acceptance_criteria.clear();
	sSpringType.clear();

	return 0;
	return -1;
}

ProError getSelectedTypeOpMenuf4a02(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- getSelectedTypeOpMenuf4a02 -----------------------------");

	status = ProUIPushbuttonShow(dialog , component);
	string* _data = (string*)data;
	int n_sel;
	char** selValue;
	char opMenuName[PRO_NAME_SIZE]{};
	strcpy(opMenuName, _data[0].c_str());
	status = ProUIOptionmenuSelectednamesGet(dialog, opMenuName, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	*_data = selValue[0];	
	sSpringType = *_data;
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);

	return status;
}

ProError optionMenuImageChangeActionf4a02(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- optionMenuImageChangeActionf4a02 -----------------------------");

	string* reqData = (string*)data;
	int n_sel;
	char** selValue;
	string blank = "Select";
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue[0]));

	if ((string(selValue[0])).compare(blank) == 0)
	{
		status = ProUIPushbuttonDisable(dialog, PB_ROK);
		ruleLog.Write("Blank selected");
		status = ProUIPushbuttonHide(dialog , PB_RIMG);
	}
	else
	{
		status = ProUIPushbuttonEnable(dialog , PB_ROK);
		ProUIPushbuttonShow(dialog, PB_RIMG);
		char imgName[PRO_NAME_SIZE], cPbName[PRO_NAME_SIZE];
		ProTKSprintf(imgName, "%s/%s.png", reqData[1], selValue[0]);
		strcpy(cPbName, reqData[0].c_str());
		status = ProUIPushbuttonBitmapSet(dialog, cPbName, imgName);
		ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));
	}
	return PRO_TK_NO_ERROR;
}

ProError getParameterDescAndPartname_F4A02_001(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("----------------------------- getParameterDescAndPartname_F4A02_001 -----------------------------");

	vector<PartnameDescriptionPair>* prtname_desc_list = (vector<PartnameDescriptionPair>*)app_data;
	ProMdlType subModuleMdlType;
	ProModelitem modelItem;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ProMdl reqMdl;
	char existingPval[PRO_NAME_SIZE]{};
	PartnameDescriptionPair compd{};

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));

	status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
	ruleLog.Write("ProMdlTypeGet: " + to_string(status));

	status = ProMdlMdlnameGet(reqMdl, wFeatName);
	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(cFeatName, wFeatName);

	if (subModuleMdlType == PRO_MDL_ASSEMBLY)
	{
		ruleLog.Write("-------- Assembly found --------");
		ruleLog.Write("Assembly Name: " + string(cFeatName));
		ProSolidFeatVisit((ProSolid)reqMdl, getParameterDescAndPartname_F4A02_001, compsFilter, (ProAppData)app_data);
	}
	else if (subModuleMdlType == PRO_MDL_PART)
	{
		ruleLog.Write("-------- Part found --------");
		ProParameter pDesc;
		ProParamvalue pvDesc;
		ProName pDescName = L"DESCRIPTION";

		status = ProMdlToModelitem(reqMdl, &modelItem);
		ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		status = ProParameterInit(&modelItem, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit: " + to_string(status));

		status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
		ProWstringToString(existingPval, pvDesc.value.s_val);
		ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);

		strcpy(compd.description, existingPval);
		ruleLog.Write("compd.description" + string(compd.description));
		strcpy(compd.part_name, cFeatName);
		ruleLog.Write("compd.part_name: " + string(compd.part_name));

		prtname_desc_list->push_back(compd);
	}
	return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES											| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F4A02-002	| Aniket Satpute	| MF4A02; MF4A03; MF4A05; MF4A04; MF4A01; MF4A07; MF4A06	| Standard leaf spring span and width across platform based on application.
===================================================================================================================*/
#define DLG_IRF4A02_002		"dlg_IR_F4A02_002"
#define PB_RSELECT			"pb_select"
#define PB_ROK				"pb_run"
#define PB_CANCEL			"CommitCancel"
#define SPRING_TYPE			"OptionMenu"
#define PB_RIMG				"pb_img"

string remF4A02002;
vector<int>ID_mapF4A02002;
vector<Model_Tree_Information> treeInformationVectorF4A02002;
vector<Leaf_Information> Leaf_InformationVectorF4A02002;
ProSelection Four_axis_sel[4];
vector<Standard_span_data> Leaf_span_Table;
double standardF4A02002;
vector<string> spring_type;
bool Is_not_leaf;
bool found_matchF4A02002; // Flag to track if a match is found
int projF4A02002;
string Selected_type;

//int sel_counter = 0;

//coil spring, air spring or hydro pneumatic ,leaf spring


int IRF4A02::IRF4A02_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF4B02::IRF4A02_002   ==========================");

	Clear_Memory_F4A02002();

	for (int i = 0; i < subModulesList.size(); ++i) {
		if (subModulesList[i].name.find("F4A02") != string::npos)
		{
			_reqSMinfo = subModulesList[i];
			break;
		}
	}

	vector<string> reqValsFromCsv1;
	project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
	ruleLog.Write("Project Code: " + to_string(project_code));

	projF4A02002 = project_code;
	/*Utils utr;
	vector<string> values;
	utr.getReqValsFrom2DCsvData("IRF4A02002.csv" , 2,3,project_code , values);

	ruleLog.Write("values[0]: " + (values[0] + "\values[1]: " + values[1]));*/




	if (isUserQuits)
		return -1;

	char name[PRO_MDLNAME_SIZE];
	char type[PRO_MDLEXTENSION_SIZE];
	ProError status;
	UserAppdata appdata;
	FILE* fp{};
	ProMdl p_asm;
	ProMdl reqMdlsair1hs, mdl;
	ProMdlName modelName;
	ProMdlExtension modelExtension;
	//double distance;
	ProBoolean  interf;
	Pro3dPnt coord[2];
	int count = -1;
	//int ex, tail, sil;


	status = ProMdlCurrentGet(&p_asm);
	status = ProMdlMdlnameGet(p_asm, modelName);
	ProWstringToString(name, modelName);
	status = ProMdlExtensionGet(p_asm, modelExtension);
	ProWstringToString(type, modelExtension);

	appdata.fp = fp;
	appdata.level = 1;

	status = ProSolidFeatVisit((ProSolid)p_asm, user_actionF4A02002, compsFilter, &appdata);

	for (int i = 0; i < treeInformationVectorF4A02002.size(); i++)
	{

		if (treeInformationVectorF4A02002[i].ID_table_size == 1)
		{
			Leaf_Information leaf;
			leaf.leaf_name = treeInformationVectorF4A02002[i].name;
			leaf.ID = treeInformationVectorF4A02002[i].ID;
			leaf.selection_done = FALSE;

			Leaf_InformationVectorF4A02002.push_back(leaf);

			ruleLog.Write("Name: " + treeInformationVectorF4A02002[i].name + " ID: " + to_string(treeInformationVectorF4A02002[i].ID) + " Description: " + treeInformationVectorF4A02002[i].description + " ID Path:");
			for (int id : treeInformationVectorF4A02002[i].ID_path)
			{
				ruleLog.Write(to_string(id));
			}
		}
		//ruleLog.Write("\n");
	}

	spring_type.push_back("SELECT");
	spring_type.push_back("LEAF");
	spring_type.push_back("COIL");
	spring_type.push_back("AIR");
	spring_type.push_back("HYDROPNEUMATIC");
	//spring_type.push_back("SELECT TYPE");

	status = ProUIDialogCreate(DLG_IRF4A02_002, DLG_IRF4A02_002);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF4A02_002, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A02_002, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A02_002, PB_ROK, (ProUIAction)ruleDlgOKactionF4A02002, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A02_002, "pb_select", (ProUIAction)select_action_IRF4A02002, NULL);
	status = ProUIOptionmenuSelectActionSet(DLG_IRF4A02_002, SPRING_TYPE, (ProUIAction)get_selected_option_f4a02002, NULL);
	status = ProUIPushbuttonDisable(DLG_IRF4A02_002, PB_ROK);
	status = ProUIPushbuttonDisable(DLG_IRF4A02_002, PB_RSELECT);

	status = ProUIPushbuttonBitmapSet(DLG_IRF4A02_002, PB_RIMG, "IR_F4A02_002/SELECT.png");// default image
	ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));
	option_menu_set(DLG_IRF4A02_002, spring_type, SPRING_TYPE);
	//spring_type.clear();

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF4A02_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF4A02_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	//remF4B02002 = "INF0_WINDOW";




	if (found_matchF4A02002)
	{
		isRightValue = TRUE;
	}
	else
	{
		isRightValue = FALSE;
	}

	if (isRightValue)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	final_res.remark = remF4A02002;

	ruleLog.Write("final_res.status: " + string(final_res.result));
	ruleLog.Write("final_res.remark: " + string(final_res.remark));

	void Clear_Memory_F4A02002();

	return 0;
}

ProError user_actionF4A02002(ProFeature* feature, ProError status, ProAppData appdata)
{
	FILE* fp;
	int level;
	ProMdl mdl27;
	char name27[PRO_MDLNAME_SIZE];
	char type[PRO_MDLEXTENSION_SIZE];
	UserAppdata* appd, appd1;
	ProMdlName modelName;
	ProMdlExtension modelExtension;
	ProAsmcomppath comppath;
	ProModelitem modelItem;
	char existingPval[PRO_NAME_SIZE]{};

	//ProModelitem p_item27;
	ProIdTable table;
	//table[0] = -1;
	//int ID;

	appd = (UserAppdata*)appdata;
	fp = appd->fp;
	level = appd->level;

	status = ProAsmcompMdlGet(feature, &mdl27);
	status = ProMdlMdlnameGet(mdl27, modelName);
	status = ProMdlExtensionGet(mdl27, modelExtension);

	ProWstringToString(name27, modelName);
	ProWstringToString(type, modelExtension);

	//if (strncmp(type, "ASM", 3) == 0 || strncmp(type, "PRT", 3))
	//{
	ID_mapF4A02002.push_back(feature->id);
	//component_path.push_back(ID_mapf2c01004);

	appd1.fp = appd->fp;
	appd1.level = appd->level + 1;

	//numberofasm++;

	status = ProMdlToModelitem(mdl27, &modelItem);
	//ruleLog.Write("ProMdlToModelitem: " + to_string(status));
	ProParameter pDesc;
	ProParamvalue pvDesc;
	ProName pDescName = L"DESCRIPTION";
	status = ProParameterInit(&modelItem, pDescName, &pDesc);
	//ruleLog.Write("ProParameterInit: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)
	{
		status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
		ProWstringToString(existingPval, pvDesc.value.s_val);
		Model_Tree_Information tree1;
		tree1.name = string(name27);
		tree1.ID = feature->id;
		tree1.description = existingPval;
		tree1.ID_path = ID_mapF4A02002;
		tree1.ID_table_size = ID_mapF4A02002.size();

		treeInformationVectorF4A02002.push_back(tree1);
		ruleLog.Write("Name of assembly = " + string(name27) + " , ID = " + to_string(feature->id) + " , Description = " + existingPval);
		for (int id : tree1.ID_path)
		{
			ruleLog.Write(to_string(id) + " ");
		}
	}

	status = ProSolidFeatVisit((ProSolid)mdl27, user_actionF4A02002, compsFilter, &appd1);
	ID_mapF4A02002.pop_back();
	//}
	return(PRO_TK_CONTINUE);
}

ProError select_action_IRF4A02002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF4A02002 -----------------------------");
	InterfaceRule _irule{};
	int n_sels{};
	ProModelitem annotelem{};
	int curWinId{};
	ProMdl mdl{};
	wchar_t model{};
	char nameofsel[PRO_NAME_SIZE]{};
	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);
	ProAsmcomppath path;
	ProIdTable tab;
	vector<int> Axis_Ownwer_Ids;
	//int num_of_leafs = Leaf_InformationVectorF4A02002.size();

	for (int i = 0; i < 2; i++)
	{
		n_sels = 0;
		ProSelection* axis_sel;
		int own_ID = -1; // Initialize with some default value indicating "not found"
		status = ProSelect((char*)"axis", 2, NULL, NULL, NULL, NULL, &axis_sel, &n_sels);
		ruleLog.Write("Leaf Select" + to_string(i) + " Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels));

		if (n_sels < 2 || status != PRO_TK_NO_ERROR)
		{
			_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			status = ProUIPushbuttonDisable(DLG_IRF4A02_002, RULE_UI_OK);
			ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		}
		else if (status == PRO_TK_USER_ABORT)
		{
			status = ProUIPushbuttonDisable(DLG_IRF4A02_002, RULE_UI_OK);
			ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
		}
		else if (status == PRO_TK_NO_ERROR)
		{

			Axis_Ownwer_Ids.clear();
			for (int j = 0; j < 2; j++)
			{
				status = ProSelectionModelitemGet(axis_sel[j], &annotelem);
				ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

				status = ProSelectionAsmcomppathGet(axis_sel[j], &path);
				ruleLog.Write("ProSelectionAsmcomppathGet status = " + to_string(status));
				//ruleLog.Write("Owner ID = " + to_string(path.comp_id_table[0]));

				int Root_ID = path.comp_id_table[0];
				Axis_Ownwer_Ids.push_back(Root_ID);

			}

			/*for (int k = 0; k < Axis_Ownwer_Ids.size() ; k++)
			{
				ruleLog.Write("OWNER ID: " + to_string(Axis_Ownwer_Ids[k]));
			}*/

			// Check if the vector has exactly 2 elements and both elements are equal
			if (Axis_Ownwer_Ids[0] == Axis_Ownwer_Ids[1])
			{
				ruleLog.Write("From same asm");

				// Iterate through the vector using a traditional for loop
				for (int k = 0; k < Leaf_InformationVectorF4A02002.size(); k++)
				{
					// Check if ID matches own_ID
					if ((Leaf_InformationVectorF4A02002[k].ID == Axis_Ownwer_Ids[0]) && (Leaf_InformationVectorF4A02002[k].ID == Axis_Ownwer_Ids[1]))
					{
						//ruleLog.Write("MATCH FOUND");
						// Check if LEAF has been visited before or not
						if (Leaf_InformationVectorF4A02002[k].selection_done == TRUE)
						{
							//ruleLog.Write("IS ALREADY TRUE");

							Leaf_InformationVectorF4A02002[0].selection_done = FALSE;
							Leaf_InformationVectorF4A02002[1].selection_done = FALSE;

							_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Axis Selection from this Leaf is done, Please provide all valid inputs again!. Refer help document for details.");
							return status;
						}
						else
						{
							// Found the matching ID, perform further operations
							Leaf_InformationVectorF4A02002[k].selection_done = TRUE;
							ruleLog.Write("ALL SELECTIONS ARE VALID");

							ProBoolean  interf;
							Pro3dPnt coord[2];
							double param[2];
							double pnt[2];
							double distance;
							//int count1 =0 ;

							if (i == 0)
							{
								Four_axis_sel[0] = axis_sel[0];
								Four_axis_sel[1] = axis_sel[1];
								status = ProSelectionWithOptionsDistanceEval(Four_axis_sel[0], PRO_B_TRUE, Four_axis_sel[1], PRO_B_TRUE, &param[0], &param[1], &pnt[0], &pnt[1], &distance);
								ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
								ruleLog.Write("Distance = " + to_string(distance));

								Leaf_InformationVectorF4A02002[i].span_length = distance;
							}
							else if (i == 1)
							{
								Four_axis_sel[2] = axis_sel[0];
								Four_axis_sel[3] = axis_sel[1];
								status = ProSelectionWithOptionsDistanceEval(Four_axis_sel[2], PRO_B_TRUE, Four_axis_sel[3], PRO_B_TRUE, &param[0], &param[1], &pnt[0], &pnt[1], &distance);
								ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
								ruleLog.Write("Distance = " + to_string(distance));

								Leaf_InformationVectorF4A02002[i].span_length = distance;
							}



							Axis_data ax_info[2];
							for (int l = 0; l < 2; l++)
							{
								ProModelitem p_item;

								status = ProSelectionModelitemGet(axis_sel[l], &p_item);
								ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));
								ruleLog.Write("AXIS ID = " + to_string(p_item.id));
								ProName feature_name;
								status = ProModelitemNameGet(&p_item, feature_name);
								ruleLog.Write("ProModelitemNameGet status = " + to_string(status));
								char A_name[PRO_NAME_SIZE];
								ProWstringToString(A_name, feature_name);
								string Axis_name_in_string(A_name);
								ruleLog.Write("AxisName: " + Axis_name_in_string);
								ruleLog.Write("OWNER: " + Axis_Ownwer_Ids[l]);

								ax_info[l].axis_name = Axis_name_in_string;
								ax_info[l].axis_ID = p_item.id;
								//ax_info[l].owner_name = Axis_Ownwer_Ids[l];
								Leaf_InformationVectorF4A02002[k].Axis_info.push_back(ax_info[l]);
							}

							//status = ProSelectionFree(axis_sel);
						}
					}
				}
			}
			else
			{
				ruleLog.Write("From Diff asm");
				Leaf_InformationVectorF4A02002[0].selection_done = FALSE;
				Leaf_InformationVectorF4A02002[1].selection_done = FALSE;
				_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please select Axis from SAME Leaf only!. Refer help document for details.");
				return status;
			}
		}//IF_PRO_TK_NO_ERROR BLOCK ENDS
	}//Selection ends


	ruleLog.Write("Distance = " + to_string(Leaf_InformationVectorF4A02002[0].span_length));
	ruleLog.Write("Distance = " + to_string(Leaf_InformationVectorF4A02002[1].span_length));


	/*if (Leaf_InformationVectorF4B02002[0].span_length != Leaf_InformationVectorF4B02002[1].span_length)
	{
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "ERROR", "Possible reasons:\n1. Leaf Distances do not match\n2. Invalid axis selections");


		return status;
	}*/

	status = ProUIPushbuttonEnable(DLG_IRF4A02_002, PB_ROK);
	ruleLog.Write("ProUIPushbuttonEnable status = " + to_string(status));

	return status;
}

ProError ruleDlgCloseActionF4A02002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgCloseAction -----------------------------");

	if (data != NULL) {
		bool* quitAction = (bool*)data;
		*quitAction = true;
	}

	void Clear_Memory_F4A02002();


	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}

ProError ruleDlgOKactionF4A02002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgOKaction -----------------------------");

	if (Is_not_leaf)
	{
		remF4A02002.append("Rule is not Applicable for this type suspension\nSelected type is " + Selected_type);
		found_matchF4A02002 = TRUE;


		status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
		return PRO_TK_NO_ERROR;
	}

	else
	{
		//Leaf_InformationVectorF4B02002[0].span_length = 1449.00;
		//Leaf_InformationVectorF4B02002[0].span_length = 1447.01;
		//Leaf_InformationVectorF4B02002[0].span_length = 1452.99;
		//Leaf_InformationVectorF4B02002[0].span_length = 1453.01;

		/*status = ProSelectionModelitemGet(Four_axis_sel[0], &AxisData.annotelem1);
		ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

		ProName feature_name;
		status = ProModelitemNameGet(&AxisData.annotelem1, feature_name);
		ruleLog.Write("ProModelitemNameGet status = " + to_string(status));

		ProWstringToString(AxisData.AxisName, feature_name);
		ruleLog.Write("AxisData.AxisName: " + string(AxisData.AxisName));

		wchar_t OwnerName1[PRO_PATH_SIZE]{};
		status = ProMdlMdlnameGet(AxisData.annotelem1.owner, OwnerName1);
		ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

		ProWstringToString(AxisData.AxisOwnerName, OwnerName1);
		ruleLog.Write("OwnerNmeChar: " + string(AxisData.AxisOwnerName));*/

		//Leaf_InformationVectorF4B02002[1].span_length = 1455.47;
		//Leaf_InformationVectorF4B02002[1].span_length = 1448.01;
		//Leaf_InformationVectorF4B02002[1].span_length = 1452.99;
		//Leaf_InformationVectorF4B02002[1].span_length = 1453.01;

		/*if (doubleToStringF4B02002(Leaf_InformationVectorF4B02002[0].span_length) != doubleToStringF4B02002(Leaf_InformationVectorF4B02002[1].span_length))
		{
			status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
			return PRO_TK_NO_ERROR;
		}*/

		InterfaceRule itr;
		vector<vector<string>> IRF4A02002 = itr.getData2D("IRF4A02002.csv");

		for (int i = 0; i < IRF4A02002.size(); ++i)
		{
			Standard_span_data temp;

			temp.project_codes = IRF4A02002[i][3];

			temp.span_length = IRF4A02002[i][2];

			//ruleLog.Write(IRF4B02002[i][2] + ": " + IRF4B02002[i][3]);

			Leaf_span_Table.push_back(temp);
		}


		std::string target = to_string(projF4A02002); // String to search for

		// String to search for
		std::string search_project_code = target;


		for (const auto& data : Leaf_span_Table)
		{
			// Construct the string representation of the current data object
			std::string logString = data.project_codes + " " + data.span_length;

			// Print to log file
			ruleLog.Write(logString);
		}


		// Vector to store corresponding lengths
		std::vector<std::string> corresponding_lengths;

		// Iterate over each Standard_span_data object in the vector
		for (const auto& data : Leaf_span_Table)
		{
			// Check if the current data's project_code matches the search_project_code
			if (data.project_codes == search_project_code)
			{
				// Split the span_length string into individual lengths
				std::vector<std::string> lengths = split(data.span_length, ';');

				// Append the lengths to the corresponding_lengths vector
				corresponding_lengths.insert(corresponding_lengths.end(), lengths.begin(), lengths.end());
			}
		}

		// Remove leading and trailing spaces from each element
		for (auto& length : corresponding_lengths) {
			// Remove leading spaces
			length.erase(length.begin(), std::find_if(length.begin(), length.end(), [](unsigned char ch) {
				return !std::isspace(ch);
				}));
			// Remove trailing spaces
			length.erase(std::find_if(length.rbegin(), length.rend(), [](unsigned char ch) {
				return !std::isspace(ch);
				}).base(), length.end());
		}

		// Sort the vector and remove adjacent duplicates
		std::sort(corresponding_lengths.begin(), corresponding_lengths.end());
		corresponding_lengths.erase(std::unique(corresponding_lengths.begin(), corresponding_lengths.end()), corresponding_lengths.end());

		std::vector<std::string> unique_lengths;
		// Iterate through the original vector
		for (const std::string& length : corresponding_lengths) {
			// Check if the current value is not already in the unique vector
			if (std::find(unique_lengths.begin(), unique_lengths.end(), length) == unique_lengths.end()) {
				// If not, add it to the unique vector
				unique_lengths.push_back(length);
			}
		}

		// Sort the vector using a lambda function as a custom comparator
		std::sort(corresponding_lengths.begin(), corresponding_lengths.end(),
			[](const std::string& a, const std::string& b) {
				return a.length() < b.length();
			});

		// Output the corresponding lengths
		for (const auto& length : corresponding_lengths) {
			ruleLog.Write(length + " ;");
		}



		// Store unique elements in a string with at most 5 elements per line
		std::string acceptance_criteria_F4A02002;
		for (size_t i = 0; i < unique_lengths.size(); ++i) {
			acceptance_criteria_F4A02002 += unique_lengths[i];
			if ((i + 1) % 5 == 0 && i < unique_lengths.size() - 1) {
				acceptance_criteria_F4A02002 += ",\n";
			}
			else if (i < unique_lengths.size() - 1) {
				acceptance_criteria_F4A02002 += ", ";
			}
			else {
				acceptance_criteria_F4A02002 += ".";
			}
		}

		// Find the position of "mm" in the string
		size_t pos = acceptance_criteria_F4A02002.find("mm");

		// While "mm" is found in the string
		while (pos != std::string::npos) {
			// Insert ".00" before "mm"
			acceptance_criteria_F4A02002.insert(pos, ".00");

			// Move to the position after the inserted ".00mm"
			pos += 4;

			// Find the next occurrence of "mm" after the current position
			pos = acceptance_criteria_F4A02002.find("mm", pos);
		}

		// Convert string elements to double, round to 2 decimal places, and store in a vector of type double
		std::vector<double> double_vector;
		for (const auto& str : unique_lengths) {
			std::istringstream iss(str);
			double value;
			if (iss >> value) {
				// Round the double value to 2 decimal places
				value = std::round(value * 100.0) / 100.0;
				double_vector.push_back(value);
			}
		}
		//ruleLog.Write("Acceptance Criteria = \n" + acceptance_criteria_F4B02002);


		// Iterate over each element in Leaf_InformationVectorF4B02002
		for (size_t i = 0; i < Leaf_InformationVectorF4A02002.size(); ++i)
		{
			Leaf_Information& leafInfo = Leaf_InformationVectorF4A02002[i];

			// Iterate over each element in double_vector
			for (size_t j = 0; j < double_vector.size(); ++j)
			{
				double value = double_vector[j];

				// Compare the span_length with each value in double_vector
				// Round both to 2 decimal places for comparison
				double roundedSpan = std::round(leafInfo.span_length * 100.0) / 100.0;
				double roundedValue = std::round(value * 100.0) / 100.0;


				// Check if the difference between the values is within plus or minus 3.00
				if (std::abs(roundedSpan - roundedValue) <= 3.00)
				{
					ruleLog.Write(to_string(roundedSpan) + " , " + to_string(roundedValue));
					leafInfo.valid_length = true;
					leafInfo.leaf_status = "PASS";
					break;
				}
			}
		}


		ruleLog.Write(to_string(Leaf_InformationVectorF4A02002[0].valid_length) + " , " + to_string(Leaf_InformationVectorF4A02002[1].valid_length));

		if (Leaf_InformationVectorF4A02002[0].valid_length == TRUE && Leaf_InformationVectorF4A02002[1].valid_length == TRUE)
		{
			found_matchF4A02002 = TRUE;
		}
		else
		{
			found_matchF4A02002 = FALSE;
		}

		/*remf4a02002.append("Leaf Spring Spans are: \n\n");
		for (int i = 0; i < Leaf_InformationVectorF4A02002.size(); i++)
		{
			remf4a02002.append(to_string(i+1) + ". "+ Leaf_InformationVectorF4A02002[i].leaf_name + " [" + to_string(Leaf_InformationVectorF4A02002[i].ID) + "] = " + doubleToStringf4a02002(Leaf_InformationVectorF4A02002[i].span_length) + "mm\n");

		}*/
		for (int i = 0; i < Leaf_InformationVectorF4A02002.size(); i++)
		{
			remF4A02002.append(to_string(i + 1) + ". Distance between " + Leaf_InformationVectorF4A02002[i].Axis_info[0].axis_name +
				" [" + to_string(Leaf_InformationVectorF4A02002[i].Axis_info[0].axis_ID) + "] " + "[" + Leaf_InformationVectorF4A02002[i].leaf_name +
				"] and " + Leaf_InformationVectorF4A02002[i].Axis_info[1].axis_name +
				" [" + to_string(Leaf_InformationVectorF4A02002[i].Axis_info[1].axis_ID) + "] " +
				"[" + Leaf_InformationVectorF4A02002[i].leaf_name + "] = " +
				doubleToString(Leaf_InformationVectorF4A02002[i].span_length) + "mm [" + Leaf_InformationVectorF4A02002[i].leaf_status + "]\n");

		}


		remF4A02002.append("\nAcceptance Criteria: \n" + acceptance_criteria_F4A02002 + "\n(Tolerance of �3.00mm has been provided to acceptance criterion)");

		status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
		return PRO_TK_NO_ERROR;
	}
}

ProError get_selected_option_f4a02002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- optionMenuImageChangeActionf4a02 -----------------------------");

	//string* reqData = (string*)data;
	int n_sel;
	char** selValue;
	string blank = "Select";
	InterfaceRule itr;
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue[0]));
	Selected_type = string(selValue[0]);

	ProUIPushbuttonShow(dialog, PB_RIMG);
	char imgName[PRO_NAME_SIZE];
	ProTKSprintf(imgName, "%s/%s.png", "IR_F4A02_002", selValue[0]);
	//strcpy(cPbName, reqData[0].c_str());
	status = ProUIPushbuttonBitmapSet(dialog, PB_RIMG, imgName);
	ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));
	//standardf5a01 = string(selValue[0]);
	if (Selected_type != "LEAF")
	{
		if (Selected_type == "SELECT")
		{
			status = ProUIPushbuttonDisable(DLG_IRF4A02_002, PB_ROK);
			status = ProUIPushbuttonDisable(DLG_IRF4A02_002, PB_RSELECT);
			Is_not_leaf = TRUE;
		}
		else
		{
			status = ProUIPushbuttonEnable(DLG_IRF4A02_002, PB_ROK);
			status = ProUIPushbuttonDisable(DLG_IRF4A02_002, PB_RSELECT);
			itr.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Suspension Type", "Rule is applicable only for LEAF type.\nClick on OK to validate for selected type.");
			Is_not_leaf = TRUE;
		}
	}
	else
	{
		status = ProUIPushbuttonDisable(DLG_IRF4A02_002, PB_ROK);
		status = ProUIPushbuttonEnable(DLG_IRF4A02_002, PB_RSELECT);
		Is_not_leaf = FALSE;
	}
	return PRO_TK_NO_ERROR;
}

void Clear_Memory_F4A02002()
{
	spring_type.clear();
	//Four_axis_sel.clear();
	Leaf_span_Table.clear();
	remF4A02002.clear();
	ID_mapF4A02002.clear();
	treeInformationVectorF4A02002.clear();
	Leaf_InformationVectorF4A02002.clear();
	Selected_type.clear();
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF4A02003		| Prajakta Bhelawe	    | MF4A02			|  Standard leaf width across platform based on application.
===================================================================================================================*/
// GLOBAL ENTITIES
#define DLG_IRF4A02_003				"dlg_IR_F4A02_003"
#define PB_SELECT					"select_pb"
#define PB_CANCEL					"CommitCancel"
#define PB_OK						"CommitOK"
#define PB_IMG						"rule_img"
#define type_of_susp				"type_of_susp"

bool					isRight_003;
bool					isPlane_003 = false;
double					frontSuspLeafWidth;
ProSelection* frontSuspSurfSels;
ProSelection* coilSuspSurfSelsF4A02;
int						front_widthCalcMethod = 0, n_selF4A02;
ProName					front_susp_pEnvlName = L"ENVELOPE";
ProParameter			front_susp_pEnvl;
ProParamvalue			front_susp_pvEnvl;
char					front_susp_existingValue[PRO_NAME_SIZE], refPlaneNameF4A02[PRO_NAME_SIZE];
string					type_selected1F4A02, rmMsgF4A02;
vector <string>			 newfront_susp_existingValue, reqValsFromCsvF4A02;
vector<string> front_susp_widthPreDesc = { "60.00", "70.00", "80.00", "90.00","100.00" };
char** type_selectedF4A02;

ProMdl					refPlaneMdlF4A02;
vector<ownerInfo>		selDet_003;
bool shouldBreak = FALSE;


int IRF4A02::IRF4A02_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF4A02::IRF4A02_003   ==========================");
	rmMsgF4A02.clear();

	//Get the project code
	for (int i = 0; i < subModulesList.size(); ++i) {
		if (subModulesList[i].name.find("F4A02") != string::npos) {
			_reqSMinfo = subModulesList[i];
			break;
		}
	}
	project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
	ruleLog.Write("Project Code: " + to_string(project_code));

	reqValsFromCsvF4A02.clear();
	//Get the value associated with Project code from the file
	//getReqValsFrom2DCsvData("IRF4B02003.csv", 2, 3, project_code, reqValsFromCsvF4A02);

	/////
	vector<vector<string>> F4A02003 = getData2D("IRF4A02003.csv");
	vector<string> projectCodeCSV;
	vector<double> widthCSV;

	for (int i = 1; i < F4A02003.size(); ++i)
	{

		projectCodeCSV.push_back(F4A02003[i][2]);
		ruleLog.Write("projectCodeCSV: " + F4A02003[i][2]);
		reqValsFromCsvF4A02.push_back((F4A02003[i][3]));
		ruleLog.Write("reqValsFromCsvF4A02: " + F4A02003[i][3]);

	}

	/////

	for (int i = 0; i < reqValsFromCsvF4A02.size(); i++)
		ruleLog.Write("reqValsFromCsvF4A02 = " + reqValsFromCsvF4A02[i]);

	vector<planeData>		datumPlaneNames;
	status = ProSolidFeatVisit((ProSolid)curMdl, (ProFeatureVisitAction)getVisiblePlanesF4A02, NULL, &datumPlaneNames);
	ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));

	const regex planeNamePattn("(ASM_XZ)");
	smatch planeFound;
	string source;
	source.erase();

	for (int i = 0; i < datumPlaneNames.size(); i++)
	{
		ruleLog.Write("plane name in the vector at " + to_string(i) + " is: " + datumPlaneNames.at(i).name);
		source.append(datumPlaneNames.at(i).name);
		if (regex_search(source, planeFound, planeNamePattn))
		{
			strcpy(refPlaneNameF4A02, datumPlaneNames.at(i).name);
			refPlaneMdlF4A02 = datumPlaneNames.at(i).ownerMdl;
			ruleLog.Write("Name of reference plane: " + (string)refPlaneNameF4A02);
			break;
		}
		else
			source.erase();
	}
	datumPlaneNames.clear();
	source.erase();

	//Create an UI and define the actions of Pb
	status = ProUIDialogCreate(DLG_IRF4A02_003, DLG_IRF4A02_003);
	ruleLog.Write("ProUIDialogCreate " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRF4A02_003, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A02_003, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIDialogAboveactivewindowSet " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A02_003, PB_OK, (ProUIAction)run_action_IRF4A02003, NULL);
	ruleLog.Write("ProUIDialogAboveactivewindowSet " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A02_003, PB_SELECT, (ProUIAction)select_action_IRF4A02003, NULL);
	ruleLog.Write("ProUIDialogAboveactivewindowSet " + to_string(status));
	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIPushbuttonDisable(DLG_IRF4A02_003, PB_OK);
	ruleLog.Write("ProUIPushbuttonDisable " + to_string(status));
	status = ProUIPushbuttonDisable(DLG_IRF4A02_003, PB_SELECT);
	ruleLog.Write("ProUIPushbuttonDisable " + to_string(status));

	string optionMenuActionData[2] = { PB_IMG,"IR_F4A02_003" };
	status = ProUIOptionmenuSelectActionSet(DLG_IRF4A02_003, type_of_susp, (ProUIAction)optionMenuImageChangeAction_F4A02003, (ProAppData)&optionMenuActionData);
	ruleLog.Write("ProUIOptionmenuSelectActionSet " + to_string(status));

	// Create a drop down selection menu
	char** type_of_susp_names;
	wchar_t** type_of_susp_labels;
	vector<string> type_of_susp_vec;
	type_of_susp_vec = { "Select","LEAF","COIL","AIR","HYDROPNEUMATIC" };

	status = ProArrayAlloc(type_of_susp_vec.size(), sizeof(char*), type_of_susp_vec.size(), (ProArray*)&type_of_susp_names);
	ruleLog.Write("ProArrayAlloc names " + to_string(status));
	status = ProArrayAlloc(type_of_susp_vec.size(), sizeof(wchar_t*), type_of_susp_vec.size(), (ProArray*)&type_of_susp_labels);
	ruleLog.Write("ProArrayAlloc lables" + to_string(status));

	for (int i = 0; i < type_of_susp_vec.size(); ++i)
	{
		ruleLog.Write("length of " + type_of_susp_vec[i] + " is: " + to_string(strlen(type_of_susp_vec[i].c_str())));
		type_of_susp_names[i] = (char*)calloc(PRO_PATH_SIZE, sizeof(char));
		ProTKSprintf(type_of_susp_names[i], "%s", type_of_susp_vec[i]);

		type_of_susp_labels[i] = (wchar_t*)calloc(PRO_PATH_SIZE, sizeof(wchar_t));
		ProStringToWstring(type_of_susp_labels[i], type_of_susp_names[i]);
	}

	status = ProUIOptionmenuNamesSet(DLG_IRF4A02_003, type_of_susp, int(type_of_susp_vec.size()), type_of_susp_names);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(DLG_IRF4A02_003, type_of_susp, int(type_of_susp_vec.size()), type_of_susp_labels);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));
	status = ProUIPushbuttonBitmapSet(DLG_IRF4A02_003, PB_IMG, "IR_F4B02_003/LEAF.png");	// default image
	ruleLog.Write("ProUIPushbuttonBitmapSet rule: " + to_string(status));

	status = ProUIDialogActivate(DLG_IRF4A02_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProArrayFree((ProArray*)&type_of_susp_names);
	ruleLog.Write("ProArrayFree: " + to_string(status));
	status = ProArrayFree((ProArray*)&type_of_susp_labels);
	ruleLog.Write("ProArrayFree: " + to_string(status));

	// check for user quits in close_action
	if (isUserQuits) {
		status = ProUIDialogDestroy(DLG_IRF4A02_003);
		ruleLog.Write("ProUIDialogDestroy close action: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	//Close after rule run
	status = ProUIDialogDestroy(DLG_IRF4A02_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	//DECLARE RESULT
	if (isRight_003)
	{
		final_res.result = "PASS";
	}
	else
	{
		final_res.result = "FAIL";
	}
	final_res.remark = rmMsgF4A02;
	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);
	type_selected1F4A02.clear();
	newfront_susp_existingValue.clear();
	shouldBreak = FALSE;
	reqValsFromCsvF4A02.clear();

	return 0;
}

ProError optionMenuImageChangeAction_F4A02003(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- optionMenuImageChangeAction -----------------------------");
	status = ProUIPushbuttonDisable(dialog, PB_OK);
	ruleLog.Write("ProUIPushbuttonDisable " + to_string(status));


	string* reqData = (string*)data;
	int n_sel;
	char** selValue;

	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet cb fn: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue[0]));
	type_selected1F4A02.erase();
	type_selected1F4A02.append(selValue[0]);
	ruleLog.Write("Type of suspension selected = " + type_selected1F4A02);

	char imgName[PRO_NAME_SIZE], cPbName[PRO_NAME_SIZE];
	ProTKSprintf(imgName, "%s/%s.png", reqData[1], selValue[0]);
	strcpy(cPbName, reqData[0].c_str());
	status = ProUIPushbuttonBitmapSet(dialog, cPbName, imgName);
	ruleLog.Write("ProUIPushbuttonBitmapSet cb fn: " + to_string(status));

	if (strcmp(selValue[0], "AIR") == 0 || strcmp(selValue[0], "HYDROPNEUMATIC") == 0)
	{
		ruleLog.Write("----------------------------- (AIR/HYDROPNEUMATIC)-----------------------------");
		ProUIMessageButton* button;
		ProUIMessageButton user_choice;
		ProArrayAlloc(1, sizeof(ProUIMessageButton), 1, (ProArray*)&button);
		button[0] = PRO_UI_MESSAGE_OK;

		status = ProUIPushbuttonDisable(dialog, PB_SELECT);
		ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));
		status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Attention!!",
			L"The rule is not applicable for this type of suspension", button, PRO_UI_MESSAGE_OK, &user_choice);
		ruleLog.Write("ProUIMessageDialogDisplay status: " + to_string(status));
		if (user_choice == PRO_UI_MESSAGE_OK)
		{
			status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Attention!!",
				L"Please Click on 'RUN' to execute the rule", button, PRO_UI_MESSAGE_OK, &user_choice);

			status = ProUIPushbuttonEnable(dialog, PB_OK);
		}
	}
	else
	{
		ruleLog.Write("Else condition");
		status = ProUIPushbuttonEnable(dialog, PB_SELECT);
		ruleLog.Write("ProUIPushbuttonEnable status: " + to_string(status));
	}


	return status;
}

ProError select_action_IRF4A02003(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF4B02003----------------------------");
	selDet_003.clear();

	InterfaceRule			_irule;
	int						n_sels;
	int						curWinId;
	double					D;
	ownerInfo				obj;
	wchar_t					ownerName[PRO_NAME_SIZE];
	ProModelitem			mItem;

	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);
	if (type_selected1F4A02 == "LEAF")
	{
		ruleLog.Write("----------------------------- (Leaf)-----------------------------");
		status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &frontSuspSurfSels, &n_sels);
		//ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIPushbuttonDisable(dialog, PB_OK);
			return status;
		}
		if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
			_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			status = ProUIPushbuttonDisable(dialog, PB_OK);
			return status;
		}


		for (int i = 0; i < n_sels; i++) {

			status = ProSelectionModelitemGet(frontSuspSurfSels[i], &mItem);
			ruleLog.Write("ProSelectionModelitemGet status: " + to_string(status));

			status = ProMdlMdlnameGet(mItem.owner, ownerName);
			ProWstringToString(obj.name, ownerName);
			obj.id = mItem.id;
			selDet_003.push_back(obj);

			status = ProGeomitemDiameterEval(frontSuspSurfSels[i], &D);
			//ruleLog.Write("ProGeomitemDiameterEval = " + to_string(status));

			if (status == PRO_TK_NO_ERROR)
			{
				front_widthCalcMethod = 1;
			}
			if (status != PRO_TK_NO_ERROR) {
				front_widthCalcMethod = 2;
			}
		}

		status = ProUIPushbuttonEnable(dialog, PB_OK);
	}
	if (type_selected1F4A02 == "COIL")
	{
		ruleLog.Write("----------------------------- (Coil)-----------------------------");
		status = ProSelect((char*)"surface", 1, NULL, NULL, NULL, NULL, &coilSuspSurfSelsF4A02, &n_sels);

		status = ProSelectionModelitemGet(coilSuspSurfSelsF4A02[0], &mItem);
		ruleLog.Write("ProSelectionModelitemGet status: " + to_string(status));

		status = ProMdlMdlnameGet(mItem.owner, ownerName);
		ProWstringToString(obj.name, ownerName);
		obj.id = mItem.id;
		selDet_003.push_back(obj);

		status = ProUIPushbuttonEnable(dialog, PB_OK);
	}
	//if (type_selected1 == "AIR")
	//{
	//	/*ruleLog.Write("----------------------------- (AIR)-----------------------------");
	//	ProUIMessageButton* button;
	//	ProUIMessageButton user_choice;
	//	ProArrayAlloc(1, sizeof(ProUIMessageButton), 1, (ProArray*)&button);
	//	button[0] = PRO_UI_MESSAGE_OK;
	//	status = ProUIPushbuttonDisable(dialog, component);
	//	ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));
	//	status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Attention!!",
	//		L"The rule is not applicable for Air based suspension", button, PRO_UI_MESSAGE_OK, &user_choice);
	//	ruleLog.Write("ProUIMessageDialogDisplay status: " + to_string(status));
	//	if (user_choice == PRO_UI_MESSAGE_OK)
	//	{
	//		status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Attention!!",
	//			L"Please Click on 'RUN' to exit the application", button, PRO_UI_MESSAGE_OK, &user_choice);
	//		
	//		status = ProUIPushbuttonEnable(dialog, PB_OK);
	//	}*/
	//}

	return status;
}

ProError run_action_IRF4A02003(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- run_action_IRF4B02003 -----------------------------");
	int rule_sts;
	InterfaceRule _irule;
	char sudModlName[PRO_NAME_SIZE];
	regex pattern("(\\d+)\\|(\\d+)");
	smatch match;
	double measuredValue = 0;
	ruleLog.Write("Check for declarations done");
	rmMsgF4A02.erase();
	string mvRm;
	//mvRm.erase();
	if (type_selected1F4A02 == "LEAF")
	{
		ruleLog.Write("Check for inside if loop leaf");
		if (front_widthCalcMethod == 1)
		{
			ruleLog.Write("Check for inside if loop calc method1");
			double rearSusprear_susp_leafWidthCalc;

			char tempPln1Name[PRO_NAME_SIZE] = "TEMP_PLN1", tempPln2Name[PRO_NAME_SIZE] = "TEMP_PLN2";
			rule_sts = _irule.createTangentDatumPlaneWithReference(frontSuspSurfSels[0], refPlaneMdlF4A02, refPlaneNameF4A02, tempPln1Name);
			ruleLog.Write("createTangentDatumPlaneWithReference1 status : " + to_string(rule_sts));
			rule_sts = _irule.createTangentDatumPlaneWithReference(frontSuspSurfSels[1], refPlaneMdlF4A02, refPlaneNameF4A02, tempPln2Name);
			ruleLog.Write("createTangentDatumPlaneWithReference2 status : " + to_string(rule_sts));

			rule_sts = _irule.measureDistanceBetweenPlanes(cCurMdlName, tempPln1Name, tempPln2Name, rearSusprear_susp_leafWidthCalc);
			ruleLog.Write("measureDistanceBetweenPlanes status : " + to_string(rule_sts));

			measuredValue = round(rearSusprear_susp_leafWidthCalc * 100) / 100;	// rounding the value to two decimal places
			ruleLog.Write("Measured value in first method leaf is: " + to_string(measuredValue));
			_irule.deleteDatumPlane(tempPln1Name);
			ruleLog.Write("Check for delete plane1");
			_irule.deleteDatumPlane(tempPln2Name);
			ruleLog.Write("Check for delete plane2");

		}
		else if (front_widthCalcMethod == 2)
		{
			ruleLog.Write("Check for inside if loop calcMethod2");
			ProModelitem surf_model_item;
			ProName name;
			char str_name[PRO_NAME_SIZE];
			ProMdl owner;
			ProModelitem part_model_item;

			status = ProSelectionModelitemGet(frontSuspSurfSels[0], &surf_model_item);
			ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

			status = ProMdlMdlnameGet(surf_model_item.owner, name);
			ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

			status = ProModelitemMdlGet(&surf_model_item, &owner);
			ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

			status = ProMdlToModelitem(owner, &part_model_item);
			ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

			status = ProParameterInit(&part_model_item, front_susp_pEnvlName, &front_susp_pEnvl);
			ruleLog.Write("ProParameterInit: " + to_string(status));

			if (status == PRO_TK_NO_ERROR)
			{
				//to fetch envelope parameters
				status = ProParameterValueWithUnitsGet(&front_susp_pEnvl, &front_susp_pvEnvl, NULL);
				ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + string(ProWstringToString(front_susp_existingValue, front_susp_pvEnvl.value.s_val)));
				ruleLog.Write("check 1");
			}

			stringstream ss(front_susp_existingValue);
			string word;
			char deli = ' ';

			//to seperate envelope parameters
			while (getline(ss, word, deli))
			{
				if (word != "x") {
					ruleLog.Write("word = " + word);
					newfront_susp_existingValue.push_back(word);
				}
			}

			for (int i = 0; i < newfront_susp_existingValue.size(); i++) {
				ruleLog.Write("newfront_susp_existingValue = " + newfront_susp_existingValue[i]);
			}

			for (int i = 0; i < front_susp_widthPreDesc.size(); i++) {
				ruleLog.Write("newfront_susp_existingValue = " + front_susp_widthPreDesc[i]);
			}


			//compare envelope parameters with predescribed width 

			ruleLog.Write("front_susp_widthPreDesc = " + to_string(front_susp_widthPreDesc.size()));
			ruleLog.Write("newfront_susp_existingValue = " + to_string(newfront_susp_existingValue.size()));

			for (int i = 0; i < front_susp_widthPreDesc.size(); i++) {
				for (int j = 0; j < newfront_susp_existingValue.size(); j++) {
					ruleLog.Write("inside for");
					ruleLog.Write("front_susp_widthPreDesc = " + front_susp_widthPreDesc[i]);
					ruleLog.Write("newfront_susp_existingValue = " + newfront_susp_existingValue[j]);

					if (stod(front_susp_widthPreDesc[i]) == stod(newfront_susp_existingValue[j])) {
						ruleLog.Write("inside if");
						ruleLog.Write("front_susp_widthPreDesc = " + front_susp_widthPreDesc[i]);

						// Only push the value if it's a valid decimal number
						measuredValue = stod(front_susp_widthPreDesc[i]);
						ruleLog.Write("Added to front_susp_leafWidthCalc: " + front_susp_widthPreDesc[i]);
						shouldBreak = true;
						break; // Exit inner loop
					}
					if (shouldBreak == true)
						break;

					//if (stod(front_susp_widthPreDesc[i]) == stod(newfront_susp_existingValue[j])) {
					//	ruleLog.Write("inside if");
					//	ruleLog.Write("front_susp_widthPreDesc = "+ front_susp_widthPreDesc[i]);
					//	front_susp_leafWidthCalc.push_back(front_susp_widthPreDesc[i]);
					//	ruleLog.Write(front_susp_leafWidthCalc[i]);
					//	break;
					//}
				}
			}

			//if (!front_susp_leafWidthCalc.empty())
			//{
			//	ruleLog.Write("Inside not empty");
			//	measuredValue = round(stod(front_susp_leafWidthCalc[0]) * 100) / 100;	// rounding the value to two decimal places
			//	ruleLog.Write("Width2 = " + to_string(measuredValue));
			//}
		}

		mvRm = to_string(round(measuredValue));
		mvRm.erase(mvRm.find_last_not_of('0') + 3, string::npos);
		rmMsgF4A02 += "Measured Value : " + mvRm + " mm.";
		rmMsgF4A02 += "\nAcceptance criteria: ";

		for (int i = 0; i < reqValsFromCsvF4A02.size(); i++)
		{
			if (regex_search(reqValsFromCsvF4A02.at(i), match, pattern) == 0)
				rmMsgF4A02 += reqValsFromCsvF4A02.at(i) + " mm, ";
			if (stod(reqValsFromCsvF4A02.at(i)) == measuredValue)
			{
				ruleLog.Write("inside valfromCSV == rearSuspLeafWidth");
				isRight_003 = true;
				break;
			}
			else
				isRight_003 = false;
		}

		rmMsgF4A02 += "\n\nType of susp selected: " + type_selected1F4A02;
		rmMsgF4A02 += "\nReferences Selected: \n";
		for (int i = 0; i < selDet_003.size(); i++)
		{
			rmMsgF4A02 += "Selection" + to_string(i + 1) + ") surf ID: " + to_string(selDet_003[i].id) + "\t\tOwner: " + selDet_003[i].name + ".PRT\n";
		}
	}
	if (type_selected1F4A02 == "COIL")
	{
		ruleLog.Write("Code entered in coil method");
		ProModelitem surf_model_item;
		ProSurface surface;
		double area;
		double dia_of_coil;
		double target1, target2;

		status = ProSelectionModelitemGet(coilSuspSurfSelsF4A02[0], &surf_model_item);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

		status = ProGeomitemToSurface(&surf_model_item, &surface);

		status = ProSurfaceAreaEval(surface, &area);
		ruleLog.Write("Value = " + to_string(area));

		dia_of_coil = 2 * sqrt(area / PI);
		ruleLog.Write("Diameter = " + to_string(dia_of_coil));
		status = ProUIPushbuttonEnable(DLG_IRF4A02_003, PB_OK);

		measuredValue = dia_of_coil;
		mvRm = to_string(round(measuredValue));
		mvRm.erase(mvRm.find_last_not_of('0') + 3, string::npos);
		rmMsgF4A02 += "Measured Value: " + mvRm + " mm.";
		ruleLog.Write("Diameter of the coil: " + to_string(measuredValue));
		string targ1, targ2;
		ruleLog.Write("reqValsFromCsvF4A02 =" + to_string(reqValsFromCsvF4A02.size()));
		for (int i = 0; i < reqValsFromCsvF4A02.size(); i++)
		{

			if (regex_search(reqValsFromCsvF4A02.at(i), match, pattern)) {
				ruleLog.Write("Match found:" + match.str());
				target1 = stod(match[1].str());
				ruleLog.Write("first target:" + to_string(target1));
				target2 = stod(match[2].str());
				ruleLog.Write("second target:" + to_string(target2));
				if (target1 < measuredValue < target2)
				{
					isRight_003 = true;
					break;
				}
				else
					isRight_003 = false;
			}
		}
		targ1 = to_string(target1);
		targ1.erase(targ1.find_last_not_of('0') + 3, string::npos);
		targ2 = to_string(target2);
		targ2.erase(targ2.find_last_not_of('0') + 3, string::npos);
		rmMsgF4A02 += "\nAcceptance Criteria: Coil Diameter " + targ1 + " - " + targ2 + " mm.";
		rmMsgF4A02 += "\n\nType of susp selected: " + type_selected1F4A02;
		rmMsgF4A02 += "\nReferences Selected: \n";
		for (int i = 0; i < selDet_003.size(); i++)
		{
			rmMsgF4A02 += "Selection" + to_string(i + 1) + ") surf ID: " + to_string(selDet_003[i].id) + "\t\tOwner: " + selDet_003[i].name + ".PRT\n";
		}
	}
	if (type_selected1F4A02 == "AIR" || type_selected1F4A02 == "HYDROPNEUMATIC")
	{
		rmMsgF4A02 += "The Rule is not applicable for this type of suspension.\nHence Passed.";
		rmMsgF4A02 += "\nType of Suspension Selected: " + type_selected1F4A02;
		isRight_003 = true;
	}
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}

ProError getVisiblePlanesF4A02(ProFeature* pFeat, ProError status, vector<planeData>* datumPlaneNames)
{
	ruleLog.Write("----------------------------- getReqPlane -----------------------------");
	/*vector<ComponentData>* planeData = (vector<ComponentData>*)appD;*/
	planeData planeD;
	ProFeattype FeatType;
	ProMdl reqMdl, planeOwnerMdl;
	ProMdlType typeMdl;
	wchar_t wPlaneName[PRO_NAME_SIZE];
	char cPlaneName[PRO_NAME_SIZE];
	ProBoolean isVisible;
	char* cpyName;

	status = ProFeatureTypeGet(pFeat, &FeatType);
	ruleLog.Write("ProFeatureTypeGet status: " + to_string(status));

	if (FeatType == PRO_FEAT_COMPONENT)
	{
		status = ProAsmcompMdlGet((ProAsmcomp*)pFeat, &reqMdl);
		status = ProMdlTypeGet(reqMdl, &typeMdl);
		if (typeMdl == PRO_MDL_ASSEMBLY)
		{
			status = ProSolidFeatVisit((ProSolid)reqMdl, (ProFeatureVisitAction)getVisiblePlanesF4A02, planeFilter, datumPlaneNames);
			ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));

		}
	}
	if (FeatType == PRO_FEAT_DATUM)
	{
		status = ProFeatureVisibilityGet(pFeat, &isVisible);
		ruleLog.Write("ProFeatureVisibilityGet" + to_string(status));

		if (isVisible == PRO_B_TRUE)
		{
			status = ProModelitemNameGet((ProModelitem*)pFeat, wPlaneName);
			ruleLog.Write("ProModelitemNameGet" + to_string(status));

			status = ProModelitemMdlGet((ProModelitem*)pFeat, &planeOwnerMdl);
			ruleLog.Write("ProModelitemMdlGet" + to_string(status));

			ProWstringToString(cPlaneName, wPlaneName);
			ruleLog.Write("Name of the Plane is: " + (string)cPlaneName);
			strcpy(planeD.name, cPlaneName);
			planeD.ownerMdl = planeOwnerMdl;
			datumPlaneNames->push_back(planeD);
		}
	}

	return PRO_TK_NO_ERROR;
}

//ProError getVisiblePlanesF4A02(ProFeature* pFeat, ProError status, vector<planeData>* datumPlaneNames)
//{
//	ruleLog.Write("----------------------------- getReqPlane -----------------------------");
//	/*vector<ComponentData>* planeData = (vector<ComponentData>*)appD;*/
//	planeData planeD;
//	ProFeattype FeatType;
//	ProMdl reqMdl, planeOwnerMdl;
//	ProMdlType typeMdl;
//	wchar_t wPlaneName[PRO_NAME_SIZE];
//	char cPlaneName[PRO_NAME_SIZE];
//	ProBoolean isVisible;
//	char* cpyName;
//
//	status = ProFeatureTypeGet(pFeat, &FeatType);
//	ruleLog.Write("ProFeatureTypeGet status: " + to_string(status));
//
//	if (FeatType == PRO_FEAT_COMPONENT)
//	{
//		status = ProAsmcompMdlGet((ProAsmcomp*)pFeat, &reqMdl);
//		status = ProMdlTypeGet(reqMdl, &typeMdl);
//		if (typeMdl == PRO_MDL_ASSEMBLY)
//		{
//			status = ProSolidFeatVisit((ProSolid)reqMdl, (ProFeatureVisitAction)getVisiblePlanesF4A02, planeFilter, datumPlaneNames);
//			ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
//
//		}
//	}
//	if (FeatType == PRO_FEAT_DATUM)
//	{
//		status = ProFeatureVisibilityGet(pFeat, &isVisible);
//		ruleLog.Write("ProFeatureVisibilityGet" + to_string(status));
//
//		if (isVisible == PRO_B_TRUE)
//		{
//			status = ProModelitemNameGet((ProModelitem*)pFeat, wPlaneName);
//			ruleLog.Write("ProModelitemNameGet" + to_string(status));
//
//			status = ProModelitemMdlGet((ProModelitem*)pFeat, &planeOwnerMdl);
//			ruleLog.Write("ProModelitemMdlGet" + to_string(status));
//
//			ProWstringToString(cPlaneName, wPlaneName);
//			ruleLog.Write("Name of the Plane is: " + (string)cPlaneName);
//			strcpy(planeD.name, cPlaneName);
//			planeD.ownerMdl = planeOwnerMdl;
//			datumPlaneNames->push_back(planeD);
//		}
//	}
//
//	return PRO_TK_NO_ERROR;
//}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES											| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F4A02-005	| Vinay Neel    	| MF4A02; 	     | Standard leaf spring track across platform based on application.
===================================================================================================================*/
#define DLG_IRF4A02_005 "dlg_IR_F4A02_005"
#define PB_RSELECT		"pb_select"
#define PB_RCANCEL       "CommitCancel"
#define PB_RUN           "pb_run"
#define spring_type "spring_type"
#define PB_IMG1 "rule_img1"

string type_Selected005 = "";
ProSelection* surf_Sel_F4A02;
bool isdistancematch = false;
vector<double> reqvalfromcsvdouble;
double distance005;
string rem_mes_005 = "";
struct surfDataF4A02 {
	string part_name;
	int id;
};

int IRF4A02::IRF4A02_005(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF4A02::IRF4A02_005   ==========================");

	/* your code goes here */
	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	distance005 = 0;
	reqvalfromcsvdouble.clear();
	type_Selected005 = "";
	rem_mes_005 = "";
	isdistancematch = false;


	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF4A02_005, DLG_IRF4A02_005);
	ruleLog.Write("ProUIDialogCreate" + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRF4A02_005, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet" + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A02_005, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet" + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A02_005, PB_RUN, (ProUIAction)run_action_IRF4A02005, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet" + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF4A02_005, PB_RSELECT, (ProUIAction)select_action_IRF4A02005, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet" + to_string(status));
	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogHide: " + to_string(status));
	status = ProUIPushbuttonDisable(DLG_IRF4A02_005, PB_RSELECT);
	ruleLog.Write("ProUIPushbuttonDisable" + to_string(status));
	status = ProUIPushbuttonDisable(DLG_IRF4A02_005, PB_RUN);
	ruleLog.Write("ProUIPushbuttonDisable" + to_string(status));

	string optionMenuActionData[2] = { PB_IMG1,"IR_F4A02_005" };
	status = ProUIOptionmenuSelectActionSet(DLG_IRF4A02_005, spring_type, (ProUIAction)optionMenuImageChangeAction_F4A02005, (ProAppData)&optionMenuActionData);

	// Create a drop down selection menu
	char** type_of_susp_names;
	wchar_t** type_of_susp_labels;
	vector<string> type_of_susp_vec;
	type_of_susp_vec = { "Select","Leaf","Coil", "Air", "Pneumatic" };

	status = ProArrayAlloc(type_of_susp_vec.size(), sizeof(char*), 1, (ProArray*)&type_of_susp_names);
	//ruleLog.Write("ProArrayAlloc names " + to_string(status));
	status = ProArrayAlloc(type_of_susp_vec.size(), sizeof(wchar_t*), 1, (ProArray*)&type_of_susp_labels);
	//ruleLog.Write("ProArrayAlloc lables" + to_string(status));

	for (int i = 0; i < type_of_susp_vec.size(); ++i)
	{
		type_of_susp_names[i] = (char*)calloc(10, sizeof(char));
		ProTKSprintf(type_of_susp_names[i], "%s", type_of_susp_vec[i]);

		type_of_susp_labels[i] = (wchar_t*)calloc(10, sizeof(wchar_t));
		ProStringToWstring(type_of_susp_labels[i], type_of_susp_names[i]);
	}

	status = ProUIOptionmenuNamesSet(DLG_IRF4A02_005, spring_type, int(type_of_susp_vec.size()), type_of_susp_names);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(DLG_IRF4A02_005, spring_type, int(type_of_susp_vec.size()), type_of_susp_labels);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));
	status = ProUIPushbuttonBitmapSet(DLG_IRF4A02_005, PB_IMG1, "IR_F4A02_005/Select.png");    // default image
   //ruleLog.Write("ProUIPushbuttonBitmapSet rule: " + to_string(status));

	status = ProUIDialogActivate(DLG_IRF4A02_005, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	ruleLog.Write("dlg_sts: " + to_string(dlg_sts));
	status = ProArrayFree((ProArray*)&type_of_susp_names);
	ruleLog.Write("ProArrayFree: " + to_string(status));
	status = ProArrayFree((ProArray*)&type_of_susp_labels);
	ruleLog.Write("ProArrayFree: " + to_string(status));


	// check for user quits in close_action
	if (isUserQuits) {
		status = ProUIDialogDestroy(DLG_IRF4A02_005);
		ruleLog.Write("ProUIDialogDestroy close action: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	//Close after rule run
	status = ProUIDialogDestroy(DLG_IRF4A02_005);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isdistancematch) {
		final_res.result = "PASS";
		final_res.remark = rem_mes_005;
	}
	else {
		final_res.result = "FAIL";
		final_res.remark = rem_mes_005;
	}

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	reqvalfromcsvdouble.clear();

	return 0;
}
ProError select_action_IRF4A02005(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRF4A02005  --------------------------");

	int n_sels;

	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surf_Sel_F4A02, &n_sels);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_IRF4A02_005, PB_RUN);
		return status;
	}
	if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(DLG_IRF4A02_005, PB_RUN);
		return status;
	}



	if (n_sels > 0 && n_sels == 2) {
		status = ProUIPushbuttonEnable(DLG_IRF4A02_005, PB_RUN);
		return status;
	}

	return status;
}
ProError optionMenuImageChangeAction_F4A02005(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- optionMenuImageChangeActionF4A02005 -----------------------------");

	status = ProUIPushbuttonDisable(DLG_IRF4A02_005, PB_RUN);
	ruleLog.Write("ProUIPushbuttonDisable " + to_string(status));

	char** selValue;
	string* reqData = (string*)data;
	int n_sel;
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet cb fn: " + to_string(status));
	ruleLog.Write("selValue1 = " + string(selValue[0]));
	type_Selected005.erase();
	type_Selected005.append(selValue[0]);
	ruleLog.Write("Type of suspension selected = " + type_Selected005);

	char imgName[PRO_NAME_SIZE], cPbName[PRO_NAME_SIZE];
	ProTKSprintf(imgName, "%s/%s.png", reqData[1], selValue[0]);
	ruleLog.Write("imgName = " + string(imgName));

	strcpy(cPbName, reqData[0].c_str());
	ruleLog.Write("cPbName = " + string(cPbName));
	status = ProUIPushbuttonBitmapSet(dialog, cPbName, imgName);
	ruleLog.Write("ProUIPushbuttonBitmapSet cb fn: " + to_string(status));


	if (strcmp(selValue[0], "Select") == 0)
	{
		ProUIPushbuttonDisable(DLG_IRF4A02_005, PB_RSELECT);
		ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));
		ProUIPushbuttonDisable(DLG_IRF4A02_005, PB_RUN);
	}

	if (strcmp(selValue[0], "Air") == 0 || strcmp(selValue[0], "Pneumatic") == 0 || strcmp(selValue[0], "Coil") == 0)
	{
		ruleLog.Write("----------------------------- (AIR/HYDROPNEUMATIC/COIL)-----------------------------");
		ProUIMessageButton* button;
		ProUIMessageButton user_choice;
		ProArrayAlloc(1, sizeof(ProUIMessageButton), 1, (ProArray*)&button);
		button[0] = PRO_UI_MESSAGE_OK;

		status = ProUIPushbuttonDisable(DLG_IRF4A02_005, PB_RSELECT);
		ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));
		status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Attention!!",
			L"The rule is not applicable for this type of suspension", button, PRO_UI_MESSAGE_OK, &user_choice);
		ruleLog.Write("ProUIMessageDialogDisplay status: " + to_string(status));
		if (user_choice == PRO_UI_MESSAGE_OK)
		{
			status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Attention!!",
				L"Please Click on 'RUN' to execute the rule", button, PRO_UI_MESSAGE_OK, &user_choice);

			status = ProUIPushbuttonEnable(DLG_IRF4A02_005, PB_RUN);
		}
	}
	if (strcmp(selValue[0], "Leaf") == 0)
	{
		status = ProUIPushbuttonEnable(DLG_IRF4A02_005, PB_RSELECT);
		ruleLog.Write("ProUIPushbuttonEnable status: " + to_string(status));
		ruleLog.Write("Else condition");
	}

	ProStringarrayFree(selValue, n_sel);
	return status;
}
ProError run_action_IRF4A02005(char* dialog, char* component, ProAppData data)
{
	surfDataF4A02 surfdata;
	vector<surfDataF4A02> part_data;
	ProCharPath remark{};
	InterfaceRule irc;
	Utils utl;
	if (type_Selected005 == "Leaf")
	{

		ComponentData _reqComps[1]{};
		string reqCompSubMod[] = { "F4A02" };

		for (int i = 0; i < subModulesList.size(); ++i)
			for (int j = 0; j < 1; ++j)
				if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
					strcpy(_reqComps[j].name, subModulesList[j].name.c_str());

		int project_code = stoi(string(_reqComps[0].name).substr(0, 4));
		ruleLog.Write("Project Code:" + to_string(project_code));

		vector<string> reqvalfromcsv;
		utl.getReqValsFrom2DCsvData("IRF4A02005.csv", 2, 3, project_code, reqvalfromcsv);

		if (reqvalfromcsv.size() == 0) {
			utl.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", "The Project code is not available in the database.");
			status = ProUIPushbuttonDisable(DLG_IRF4A02_005, PB_RUN);
			return status;
		}

		for (auto val : reqvalfromcsv) {
			ruleLog.Write("val:" + val);
		}

		for (int i = 0; i < reqvalfromcsv.size(); ++i) {
			reqvalfromcsvdouble.push_back(stod(reqvalfromcsv.at(i)));
		}


		status = irc.measureDistanceBetweenSurfaces(surf_Sel_F4A02[0], surf_Sel_F4A02[1], distance005);
		ruleLog.Write("measureDistanceBetweenSurfaces: " + to_string(status));
		if (status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT) {
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selected surfaces.");
			return status;
		}


		for (int i = 0; i < reqvalfromcsvdouble.size(); ++i) {
			if (utl.compareFloat(distance005, reqvalfromcsvdouble.at(i))) {
				isdistancematch = true;
				break;
			}
		}

		//Get the id of selected surfaces
		for (int i = 0; i < 2; ++i) {
			ProMdlName		wname;
			char            cname[PRO_MDLNAME_SIZE];
			ProFeature feature;

			status = ProSelectionModelitemGet(surf_Sel_F4A02[i], &feature);
			status = ProMdlMdlnameGet(feature.owner, wname);
			ProWstringToString(cname, wname);

			surfdata.part_name = cname;
			surfdata.id = feature.id;
			part_data.push_back(surfdata);
			ruleLog.Write("surfdata.id: " + to_string(surfdata.id));
		}

		sort(reqvalfromcsvdouble.begin(), reqvalfromcsvdouble.end());

		sprintf(remark, " \nMeasured Spring track: %.2lfmm", distance005);
		rem_mes_005 += remark;

		rem_mes_005 += "\n\nFollowing are the applicable spring track values: ";

		//if (reqvalfromcsvdouble.size() > 4) {
		//    for (int i = 0; i < 4; ++i)
		//    {
		//        sprintf(remark, "%.2lfmm, ", reqvalfromcsvdouble[i]);
		//        rem_mes_005 += remark;
		//    }
		//    rem_mes_005 += " \n";
		//    for (int i = 4; i < reqvalfromcsvdouble.size(); ++i)
		//    {
		//        sprintf(remark, "%.2lfmm, ", reqvalfromcsvdouble[i]);
		//        rem_mes_005 += remark;
		//    }
		//}
		//else 
		//{
		//    for (int i = 0; i < reqvalfromcsvdouble.size(); i++)
		//    {
		//        sprintf(remark, "%.2lfmm, ", reqvalfromcsvdouble[i]);
		//        rem_mes_005 += remark;
		//    }
		//}

		rem_mes_005 += "\n";

		for (size_t i = 0; i < reqvalfromcsvdouble.size(); ++i) {
			// Round each value to two decimal places and convert to string with ".00mm" appended
			stringstream ss;
			ss << fixed << setprecision(2) << reqvalfromcsvdouble[i] << "mm";
			rem_mes_005 += ss.str();

			// Add comma and line break after every 5 elements (except for the last one)
			if ((i + 1) % 5 == 0 && i != reqvalfromcsvdouble.size() - 1) {
				rem_mes_005 += ",\n";
			}
			else if (i != reqvalfromcsvdouble.size() - 1) {
				rem_mes_005 += ", ";
			}
		}

		// Add full stop at the end
		rem_mes_005 += ".";


		rem_mes_005 += "\n\nUsed reference part: " + part_data[0].part_name + ".PRT" + " (Surf ID:" + to_string(part_data[0].id) + ")";
		rem_mes_005 += "\nUsed reference part: " + part_data[1].part_name + ".PRT" + " (Surf ID:" + to_string(part_data[1].id) + ")";
	}


	if (type_Selected005 == "Air" || type_Selected005 == "Pneumatic" || type_Selected005 == "Coil")
	{
		rem_mes_005 += "The Rule is not applicable for this type of suspension.\nHence Passed.";
		rem_mes_005 += "\nType of Suspension Selected: " + type_Selected005;
		isdistancematch = true;
	}

	part_data.clear();

	ruleLog.Write("=========run action end=========");
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
}

#pragma pop
