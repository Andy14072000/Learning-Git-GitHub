#include "F4A04.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES | DESCRIPTION
------------------------------------------------------------------------------------------------------------------
IR-F4A04-002	|  Prajakta Bhelawe	| MF4A04	        | Standard Shock Absorber mounting bolt size measured at axle end for Front suspension
===================================================================================================================*/
#define dlg_IR_F4A04_002     "dlg_IR_F4A04_002" 
#define PB_SELECT		     "select_pb"
#define PB_SELECT_2		     "select_pb_2"
#define PB_CANCEL		     "CommitCancel" 
#define PB_OK			     "CommitOK"


vector<double>dia_frame_F4A04;
vector<double> dia_axle_F4A04;
string remarkF4A04;
vector<string> name_asmAxle_F4A04;
vector<string> name_asmFrame_F4A04;

boolean frameEndMatchBool1 = FALSE;
boolean axleEndMatchBool1 = FALSE;


int IRF4A04::IRF4A04_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF4A04::IRF4A04_002   ==========================");
	dia_frame_F4A04.clear();
	dia_axle_F4A04.clear();

	boolean frontEndMatchBool = FALSE;
	boolean	axleEndMatchBool = FALSE;
	frameEndMatchBool1 = FALSE;
	axleEndMatchBool1 = FALSE;

	vector<string> resultFrameEnd;
	vector<string> resultAxleEnd;

	for (int i = 0; i < subModulesList.size(); ++i) {
		if (subModulesList[i].name.find("F4A04") != string::npos) {
			_reqSMinfo = subModulesList[i];
			break;
		}
	}

	project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
	ruleLog.Write("Project Code: " + to_string(project_code));

	vector<string> reqValsFromCsv1, reqValsFromCsv2;
	getReqValsFrom2DCsvData("IRF4A04002.csv", 2, 3, project_code, reqValsFromCsv1);
	getReqValsFrom2DCsvData("IRF4A04002.csv", 2, 4, project_code, reqValsFromCsv2);

	if (reqValsFromCsv1.size() == 0 && reqValsFromCsv2.size() == 0)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Project Code not found. \nPlease update the CSV.");
		return 0;
	}

	isUserQuits = false;
	status = ProUIDialogCreate(dlg_IR_F4A04_002, dlg_IR_F4A04_002);
	status = ProUIDialogAboveactivewindowSet(dlg_IR_F4A04_002, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(dlg_IR_F4A04_002, PB_SELECT, (ProUIAction)select_action_IRF4A04_002, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(dlg_IR_F4A04_002, PB_SELECT_2, (ProUIAction)select_action_IRF4A04_002_2, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(dlg_IR_F4A04_002, PB_OK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(dlg_IR_F4A04_002, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(dlg_IR_F4A04_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(dlg_IR_F4A04_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	ruleLog.Write("dia_frame_F4A04: " + to_string(dia_frame_F4A04.size()));
	ruleLog.Write("dia_axle_F4A04: " + to_string(dia_axle_F4A04.size()));

	for (int i = 0; i < reqValsFromCsv1.size(); ++i)
	{
		for (int j = 0; j < dia_frame_F4A04.size(); ++j)
		{
			ruleLog.Write("reqValsFromCsv1 = " + reqValsFromCsv1[i]);
			ruleLog.Write("Dia of the frame boult :" + to_string(dia_frame_F4A04.at(j)));

			if (stod(reqValsFromCsv1[i]) == dia_frame_F4A04[j])
			{
				//frontEndMatch.push_back(dia_frame[j]);
				ruleLog.Write("inside = " + (reqValsFromCsv1[i]));
				ruleLog.Write("inside = " + to_string(dia_frame_F4A04[j]));
				frontEndMatchBool = TRUE;
				ruleLog.Write("frontEndMatchBool = " + to_string(frontEndMatchBool));
				break;

			}
		}
	}

	for (int i = 0; i < reqValsFromCsv2.size(); ++i)
	{
		for (int j = 0; j < dia_axle_F4A04.size(); ++j)
		{
			ruleLog.Write("reqValsFromCsv2 = " + reqValsFromCsv2[i]);
			ruleLog.Write("Dia of the axle boult :" + to_string(dia_axle_F4A04.at(j)));

			if (stod(reqValsFromCsv2[i]) == dia_axle_F4A04[j])
			{

				ruleLog.Write("inside = " + (reqValsFromCsv2[i]));
				ruleLog.Write("inside = " + to_string(dia_axle_F4A04[j]));

				axleEndMatchBool = TRUE;
				ruleLog.Write("axleEndMatchBool = " + to_string(axleEndMatchBool));
				break;

			}
		}
	}
	ruleLog.Write("frameEndMatchBool1 = " + to_string(frameEndMatchBool1));
	ruleLog.Write("axleEndMatchBool1 = " + to_string(axleEndMatchBool1));

	//dia_frame_F4A04[0]
	string strClearanceDia_frame_1;
	strClearanceDia_frame_1 = to_string(dia_frame_F4A04[0]);

	string result1;
	size_t dotPos1 = strClearanceDia_frame_1.find('.');

	if (dotPos1 != std::string::npos) {
		// Check if there are at least two characters after the decimal point
		if (dotPos1 + 3 <= strClearanceDia_frame_1.size()) {
			result1 = strClearanceDia_frame_1.substr(0, dotPos1 + 3);  // Include the dot and two characters after
		}
		else {
			// Less than two characters after the decimal point
			result1 = strClearanceDia_frame_1.substr(0, dotPos1 + 1);  // Include only up to the decimal point
		}
	}
	else {
		// No decimal point found
		result1 = strClearanceDia_frame_1;
	}

	//dia_frame_F4A04[1]
	string strClearanceDia_frame_2;
	strClearanceDia_frame_2 = to_string(dia_frame_F4A04[1]);

	string result2;
	size_t dotPos2 = strClearanceDia_frame_2.find('.');

	if (dotPos2 != std::string::npos) {
		// Check if there are at least two characters after the decimal point
		if (dotPos2 + 3 <= strClearanceDia_frame_2.size()) {
			result2 = strClearanceDia_frame_2.substr(0, dotPos2 + 3);  // Include the dot and two characters after
		}
		else {
			// Less than two characters after the decimal point
			result2 = strClearanceDia_frame_2.substr(0, dotPos2 + 1);  // Include only up to the decimal point
		}
	}
	else {
		// No decimal point found
		result2 = strClearanceDia_frame_2;
	}

	//dia_axle_F4A04[0]
	string strClearanceDia_axle_1;
	strClearanceDia_axle_1 = to_string(dia_axle_F4A04[0]);

	string result3;
	size_t dotPos3 = strClearanceDia_axle_1.find('.');

	if (dotPos3 != std::string::npos) {
		// Check if there are at least two characters after the decimal point
		if (dotPos3 + 3 <= strClearanceDia_axle_1.size()) {
			result3 = strClearanceDia_axle_1.substr(0, dotPos3 + 3);  // Include the dot and two characters after
		}
		else {
			// Less than two characters after the decimal point
			result3 = strClearanceDia_axle_1.substr(0, dotPos3 + 1);  // Include only up to the decimal point
		}
	}
	else {
		// No decimal point found
		result3 = strClearanceDia_axle_1;
	}


	//dia_axle_F4A04[1]
	string strClearanceDia_axle_2;
	strClearanceDia_axle_2 = to_string(dia_axle_F4A04[1]);

	string result4;
	size_t dotPos4 = strClearanceDia_axle_2.find('.');

	if (dotPos4 != std::string::npos) {
		// Check if there are at least two characters after the decimal point
		if (dotPos4 + 3 <= strClearanceDia_axle_2.size()) {
			result4 = strClearanceDia_axle_2.substr(0, dotPos4 + 3);  // Include the dot and two characters after
		}
		else {
			// Less than two characters after the decimal point
			result4 = strClearanceDia_axle_2.substr(0, dotPos4 + 1);  // Include only up to the decimal point
		}
	}
	else {
		// No decimal point found
		result4 = strClearanceDia_axle_2;
	}

	remarkF4A04 += "Frame end :";
	remarkF4A04 += "\n1) Bolt size for " + name_asmFrame_F4A04[0] + ".PRT = " + result1 + "mm";
	remarkF4A04 += "\n2) Bolt size for " + name_asmFrame_F4A04[1] + ".PRT = " + result2 + "mm";
	remarkF4A04 += "\nAxle end :";
	remarkF4A04 += "\n1) Bolt size for " + name_asmAxle_F4A04[0] + ".PRT = " + result3 + "mm";
	remarkF4A04 += "\n2) Bolt size for " + name_asmAxle_F4A04[1] + ".PRT = " + result4 + "mm";

	remarkF4A04 += "\n\nAcceptance Crietria: \nFrame end(in mm) : ";
	for (int i = 0; i < reqValsFromCsv1.size(); i++)
	{
		remarkF4A04 += reqValsFromCsv1[i] + ".00, ";
	}
	remarkF4A04 += "\nAxle end(in mm) : ";
	for (int i = 0; i < reqValsFromCsv2.size(); i++)
	{
		remarkF4A04 += reqValsFromCsv2[i] + ".00, ";
	}

	if (axleEndMatchBool == TRUE && frontEndMatchBool == TRUE && frameEndMatchBool1 == TRUE && axleEndMatchBool1 == TRUE)
	{
		ruleLog.Write("PASS");
		final_res.result = "PASS";
		final_res.remark = remarkF4A04;
	}

	else
	{
		ruleLog.Write("FAIL");
		final_res.result = "FAIL";
		final_res.remark = remarkF4A04;
	}

	remarkF4A04.clear();
	dia_axle_F4A04.clear();
	dia_frame_F4A04.clear();
	name_asmAxle_F4A04.clear();
	name_asmFrame_F4A04.clear();
	frontEndMatchBool = FALSE;;
	axleEndMatchBool = FALSE;

	return 0;
}

ProError select_action_IRF4A04_002(char* dialog, char* component, ProAppData data)
{
	int num_sel;
	ProSelection* sel_frame;
	double dia_frame_1, dia_frame_2;
	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &sel_frame, &num_sel);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)
	{
		status = ProUIPushbuttonEnable(dialog, PB_SELECT_2);
		status = ProGeomitemDiameterEval(sel_frame[0], &dia_frame_1);
		ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status));

		status = ProGeomitemDiameterEval(sel_frame[1], &dia_frame_2);
		ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status));

		for (int i = 0; i < num_sel; i++)
		{

			ProModelitem part_model_item;
			ProName name;
			char str_name[PRO_NAME_SIZE];
			ProModelitem parent_model_item;
			ProParameter pDesc;
			ProParamvalue pvDesc;
			ProName pDescName = L"DESCRIPTION";
			string                  description;
			char existingPval[PRO_LINE_SIZE]{};

			status = ProSelectionModelitemGet(sel_frame[i], &part_model_item);
			ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

			status = ProMdlMdlnameGet(part_model_item.owner, name);
			ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

			ProWstringToString(str_name, name);
			ruleLog.Write("str_name = " + string(str_name));

			status = ProMdlToModelitem(part_model_item.owner, &parent_model_item);
			ruleLog.Write("ProMdlToModelitem: " + to_string(status));

			status = ProParameterInit(&parent_model_item, pDescName, &pDesc);
			ruleLog.Write("ProParameterInit status = " + to_string(status));
			if (status != PRO_TK_E_NOT_FOUND)
			{
				status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
				ruleLog.Write("ProParameterValueWithUnitsGet status = " + to_string(status));
				ProWstringToString(existingPval, pvDesc.value.s_val);
			}
			name_asmFrame_F4A04.push_back(str_name);
		}

		ruleLog.Write(to_string(dia_frame_1));
		ruleLog.Write(to_string(dia_frame_2));

		dia_frame_F4A04.push_back(dia_frame_1);
		dia_frame_F4A04.push_back(dia_frame_2);

		if (dia_frame_1 == dia_frame_2)
		{
			frameEndMatchBool1 = TRUE;
		}
		else
		{
			remarkF4A04 += "Bolt diameters for front end does not match\n";
		}
	}

	return status;
}

ProError select_action_IRF4A04_002_2(char* dialog, char* component, ProAppData data)
{
	double dia_axle_1, dia_axle_2;
	int num_sel;
	ProSelection* sel_axle;

	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &sel_axle, &num_sel);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)

	{
		status = ProUIPushbuttonEnable(dialog, PB_OK);
		status = ProGeomitemDiameterEval(sel_axle[0], &dia_axle_1);
		ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status));

		status = ProGeomitemDiameterEval(sel_axle[1], &dia_axle_2);
		ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status));

		for (int i = 0; i < num_sel; i++)
		{

			ProModelitem part_model_item;
			ProName name;
			char str_name[PRO_NAME_SIZE];
			ProModelitem parent_model_item;
			ProParameter pDesc;
			ProParamvalue pvDesc;
			ProName pDescName = L"DESCRIPTION";
			string                  description;
			char existingPval[PRO_LINE_SIZE]{};

			status = ProSelectionModelitemGet(sel_axle[i], &part_model_item);
			ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));

			status = ProMdlMdlnameGet(part_model_item.owner, name);
			ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

			ProWstringToString(str_name, name);
			ruleLog.Write("str_name = " + string(str_name));

			status = ProMdlToModelitem(part_model_item.owner, &parent_model_item);
			ruleLog.Write("ProMdlToModelitem: " + to_string(status));

			status = ProParameterInit(&parent_model_item, pDescName, &pDesc);
			ruleLog.Write("ProParameterInit status = " + to_string(status));
			if (status != PRO_TK_E_NOT_FOUND)
			{
				status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
				ruleLog.Write("ProParameterValueWithUnitsGet status = " + to_string(status));
				ProWstringToString(existingPval, pvDesc.value.s_val);
			}
			name_asmAxle_F4A04.push_back(str_name);

		}

		ruleLog.Write(to_string(dia_axle_1));
		ruleLog.Write(to_string(dia_axle_2));

		dia_axle_F4A04.push_back(dia_axle_1);
		dia_axle_F4A04.push_back(dia_axle_2);

		if (dia_axle_1 == dia_axle_2)
		{
			axleEndMatchBool1 = TRUE;
		}
		else
		{
			remarkF4A04 += "Bolt diameters for rear end does not match\n";
		}

	}

	return status;
}

