/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
ABHINAV PAWASE	| 18-03-2023	|	V1_0_0		| F5A20 - BRAKING SYSTEM RULES
==================================================================================================================*/
#include "F5A20.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5A20001		| Aniket Satpute 	| MF5A20			| Pipe connector selection to be done to avoid flow restriction and pressure drop.
===================================================================================================================*/
#define DLG_IRF5A20_001 "dlg_IR_F5A20_001"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"
FILE* fp;
vector<connector> _connectors;
struct connector_remark{
	string elbow;
	string straight;
	string owner;
};
vector<connector_remark> Remark_message1 , Remark_message2;

//ProMdl models[1000];
//ProMdl Assy_models[1000];
int								models_cnt_pipe, Assy_models_cnt_pipe, num_of_assy_fixed_pipe = 0,model_count_pipe, owner_feat_id_pipe, level_pipe;
vector<connector_in_model>		_connectors_in_assembly;
vector<feat_id_data>			feat_id_data_Arry;
Asm_model						models_pipe[2000], Assy_models_pipe[2000];


int IRF5A20::IRF5A20_001(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5A20::IRF5A20_001   ==========================");
	
	string				reqCompSubMod[2] = { "F5A20","F5A21"};
	string target;
	//Search in the main assembly if submodule, that is to be selected Programmatically, is available
	
	vector<ComponentData>_reqComps(sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]));
	ruleLog.Write("_reqComps size: " + to_string(_reqComps.size()));
	bool F5A20_present = NULL, F5A21_present = NULL;
	for (int i = 0; i < _reqComps.size(); ++i)
	{
		target = reqCompSubMod[i];
		ruleLog.Write("target comp: " + target);
		for (int j = 0; j < subModulesList.size(); ++j)
		{
			ruleLog.Write("submodule name being visited: " + subModulesList[j].name);
			if (subModulesList[j].name.find(target) != string::npos)
			{
				ruleLog.Write("match found for: " + subModulesList[j].name);
				strcpy(_reqComps[i].name, subModulesList[j].name.c_str());
				if (target == "F5A20")
				{
					ruleLog.Write("F5A20 marked true ");
					F5A20_present = true;
					
				}
				if (target == "F5A21")
				{
					ruleLog.Write("F5A21 marked true ");
					F5A21_present = true;
				}
				
			}
		}
	}
	ruleLog.Write("F5A20_present status: " + to_string(F5A20_present));
	ruleLog.Write("F5A21_present status: " + to_string(F5A21_present));

	string popupMsg{};
	
	if (F5A20_present == 1 && F5A21_present == 1)
	{
		popupMsg += "F5A20 and F5A21 both the submodules are present.\nDo you want to proceed?";
	}
	if ((F5A20_present != 1) || (F5A21_present != 1))
	{
		ruleLog.Write("Inside 2nd if condition");
		popupMsg += "One submodule is not present.\nMissing submodule - ";
		if (F5A20_present != 1)
		{
			ruleLog.Write("F5A20 not present");
			popupMsg += "F5A20";
		}
		if (F5A21_present != 1)
		{
			ruleLog.Write("F5A21 not present");
			popupMsg += "F5A21";
		}
		popupMsg += "\nDo you want to proceed?";
	}

	ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
	msg_buttons[0] = PRO_UI_MESSAGE_YES;
	msg_buttons[1] = PRO_UI_MESSAGE_NO;
	ProUIMessageButton		userChoice;
	userChoice = UserDisplayPopupMessageUserChoice(PROUIMESSAGE_INFO, "Attention!",popupMsg, msg_buttons);
	
	if (userChoice == PRO_UI_MESSAGE_NO)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention!", "Click 'Ok' to return to main UI");
		return -1;
	}
	vector<string>f5a20Names{"F5A20"};
	status = ProSolidFeatVisit((ProSolid)curMdl, (ProFeatureVisitAction)getAsmNamesOnly, compsFilter, &f5a20Names);
	ruleLog.Write("ProSolidFeatVisit getAsmNamesOnly F5A20 status: " + to_string(status));
	ruleLog.Write("size of f5a20Names: " + to_string(f5a20Names.size()));
	
	auto last = unique(f5a20Names.begin(), f5a20Names.end());
	f5a20Names.erase(last, f5a20Names.end());
	ruleLog.Write("size of f5a20Names after: " + to_string(f5a20Names.size()));

	for (auto elem : f5a20Names)
	{
		ruleLog.Write(elem);
	}
	vector<string>f5a21Names{ "F5A21" };
	if (F5A21_present == 1)
	{
		status = ProSolidFeatVisit((ProSolid)curMdl, (ProFeatureVisitAction)getAsmNamesOnly, compsFilter, &f5a21Names);
		ruleLog.Write("ProSolidFeatVisit getAsmNamesOnly F5A21 status: " + to_string(status));
		ruleLog.Write("size of f5a21Names: " + to_string(f5a21Names.size()));
		auto last = unique(f5a21Names.begin(), f5a21Names.end());
		f5a21Names.erase(last, f5a21Names.end());
		ruleLog.Write("size of f5a21Names after: " + to_string(f5a21Names.size()));
		for (auto elem : f5a21Names)
		{
			ruleLog.Write(elem);
		}
	}


	//isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF5A20_001, DLG_IRF5A20_001);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRF5A20_001, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A20_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A20_001, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF5A20_001, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF5A20_001);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	ProMdlType		type;
	ProMdlName 		name;
	ProName     	name_wchar;
	ProMdl      	Mdl;
	ProAppData      visit_data;
	ProCharLine		connector_File;
	string			line;
	int				line_no = 0;
	FILE* fp;

	fp = fopen("C:\\tmp\\IRF5A20001.log", "w");
	model_count_pipe = 0;

	ProTKSprintf(connector_File, "%s%s", PROE_TML_STD_PATH, "\\irc_application\\rules_db\\DB_elbow_conn.txt");
	ruleLog.Write("connector_File: " + string(connector_File));

	ifstream mtrl_file1(connector_File);
	if (mtrl_file1.is_open()) {

		while (std::getline(mtrl_file1, line))
		{
			++line_no;
			if (line_no == 1) {
				continue;
			}

			ProCharName C_line;
			strcpy(C_line, line.c_str());

			char* token = strtok(C_line, ",");

			connector _connector;
			strcpy(_connector.elbo_connector, token);

			token = strtok(NULL, "\n");
			strcpy(_connector.straight_connector, token);

			_connectors.push_back(_connector);
		}

	}

	for (int i = 0; i < _connectors.size(); ++i) {
		//ruleLog.Write( "%d. Elbo - %s , straight - %s\n" + i + string( _connectors[i].elbo_connector) + string(_connectors[i].straight_connector));
		ruleLog.Write(to_string(i) + ". Elbo - " + _connectors[i].elbo_connector + ", straight - " + _connectors[i].straight_connector);
	}

	status = ProMdlCurrentGet(&Mdl);
	ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));


	curMdl = Mdl;
	level_pipe = 1;
	num_of_assy_fixed_pipe = 0;
	models_pipe[0].Model = Mdl;
	models_pipe[0].Model_feat_id = 0;
	models_cnt_pipe = 1;
	Assy_models_cnt_pipe = 0;

begin:

	for (int a = 0; a < models_cnt_pipe; ++a) {

		owner_feat_id_pipe = models_pipe[a].Model_feat_id;
		status = ProSolidFeatVisit((ProSolid)models_pipe[a].Model, (ProFeatureVisitAction)connectors_visit_action, NULL, NULL);
		ruleLog.Write("ProSolidFeatVisit status = " + to_string(status));

	}

	if (Assy_models_cnt_pipe > 0) {

		++level_pipe;

		for (int b = 0; b < Assy_models_cnt_pipe; ++b)
		{
			models_pipe[b].Model = Assy_models_pipe[b].Model;
			models_pipe[b].Model_feat_id = Assy_models_pipe[b].Model_feat_id;
		}
		models_cnt_pipe = Assy_models_cnt_pipe;
		Assy_models_cnt_pipe = 0;
		goto begin;
	}

	ruleLog.Write("model_count_pipe in asssmbly = " + model_count_pipe);
	ruleLog.Write("connectors in asssmbly : ");

	ruleLog.Write(to_string(_connectors_in_assembly.size()));

	for (int j = 0; j < _connectors_in_assembly.size(); ++j) {

		ruleLog.Write(to_string(j) + ". Elbow connector - " + _connectors_in_assembly[j].elbo_connector + ", straight connector - " + _connectors_in_assembly[j].straight_connector + ", owner : " + _connectors_in_assembly[j].owner_model);

	}
	//new
	//fclose(fp);
	//end
	_connectors.clear();
	feat_id_data_Arry.clear();

	string popmsg = "Replace elbow connectors with straight connectors.\nConnectors in F5A20 Submodule: -\n";

	string popmsg2{};
	if (F5A21_present == 1)
	{
		popmsg2 = "\nConnectors in F5A21 Submodule: -\n";
	}
	else {
		popmsg2 += "\nF5A21 submodule is not available.";
	}
	string f5a20RemMsg{}, targetAsm{};
	
	for (int i = 0; i < _connectors_in_assembly.size(); i++)
	{
		ruleLog.Write("owner name from connectors vector: " + (string)_connectors_in_assembly[i].owner_model);
		targetAsm = _connectors_in_assembly[i].owner_model;
		for (int j = 0; j < f5a20Names.size(); j++)
		{
			ruleLog.Write("owner name from f5a20 names vector: " + f5a20Names[j]);
			if (targetAsm == f5a20Names[j])
			{
				connector_remark obj;

				ruleLog.Write("name matched for: " + f5a20Names[j]);
				
				/*string e1 = _connectors_in_assembly[i].elbo_connector;
				string s1 = _connectors_in_assembly[i].straight_connector;
				string o1 = _connectors_in_assembly[i].owner_model;*/

				 obj.elbow   = _connectors_in_assembly[i].elbo_connector;
				 obj.straight = _connectors_in_assembly[i].straight_connector;
				 obj.owner = _connectors_in_assembly[i].owner_model;

				 Remark_message1.push_back(obj);

				/*popmsg = popmsg.append(to_string(i + 1) + " . " + o1 + ".asm -> " + e1 + ".prt with " + s1 + ".prt\n");
				e1.clear();
				s1.clear();
				o1.clear();*/
				break;
			}
			
		}
		ruleLog.Write("size of f5a21Names in the for loop: " + to_string(f5a21Names.size()));
		
		for (int k = 0; k < f5a21Names.size(); k++)
		{
			ruleLog.Write("owner name from f5a21 names vector: " + f5a20Names[k]);
			if (targetAsm == f5a21Names[k])
			{
				connector_remark obj;

				ruleLog.Write("name matched for: " + f5a21Names[k]);
				/*string e1 = _connectors_in_assembly[i].elbo_connector;
				string s1 = _connectors_in_assembly[i].straight_connector;
				string o1 = _connectors_in_assembly[i].owner_model;*/


				obj.elbow = _connectors_in_assembly[i].elbo_connector;
				obj.straight = _connectors_in_assembly[i].straight_connector;
				obj.owner = _connectors_in_assembly[i].owner_model;

				Remark_message2.push_back(obj);


				//popmsg2 = popmsg2.append(to_string(i + 1) + ". " + o1 + ".asm -> " + e1 + ".prt with " + s1 + ".prt\n");
				//e1.clear();
				//s1.clear();
				//o1.clear();
				break;
			}
			
		}	
	}

	// For writing the remark message of the connectors in F5A20 SM
	if (!Remark_message1.empty())
	{
		for (int i = 0; i < Remark_message1.size(); i++)
		{
			popmsg = popmsg.append(to_string(i + 1) + ". " + Remark_message1[i].owner + ".ASM -> " +
				Remark_message1[i].elbow + ".PRT with " + Remark_message1[i].straight + ".PRT\n");
		}
	}
	// For writing the remark message of the connectors in F5A20 SM
	if (!Remark_message2.empty())
	{
		for (int i = 0; i < Remark_message2.size(); i++)
		{
			popmsg2 = popmsg2.append(to_string(i + 1) + ". " + Remark_message2[i].owner + ".ASM -> " +
				Remark_message2[i].elbow + ".PRT with " + Remark_message2[i].straight + ".PRT\n");
		}
	}
	ruleLog.Write(popmsg + popmsg2);

	// DECLARE RESULT
	if (_connectors_in_assembly.size() > 0)
	{
		final_res.result = "FAIL";
		final_res.remark = popmsg + popmsg2;
		/*FILE* fpf5a20 = NULL;
		ProPath ftc;
		char* ft = "c:\\tmp\\demof5a20.log";
		fpf5a20 = fopen(ft, "w");
		ProStringToWstring(ftc, ft);
		char* c1 = new char[popmsg.length() + 1];
		c1[popmsg.length()] = '\0';
		for (int i = 0; i < popmsg.length(); i++)
		{
			c1[i] = popmsg[i];
		}

		ProTKFprintf(fpf5a20, c1);
		status = ProInfoWindowDisplay(ftc, NULL, NULL);
		ruleLog.Write("ProInfoWindowDisplay" + to_string(status));	*/
	}
	else
	{
		final_res.result = "PASS";
		final_res.remark = string("No Elbow connectors found.Acceptence criteria : Avoid elbow connectors to avoid flow restriction and pressure drop.");
	}
	_connectors_in_assembly.clear();
	popmsg.clear();
	popmsg2.clear();
	f5a20Names.clear();
	f5a21Names.clear();
	_connectors.clear();
	feat_id_data_Arry.clear();
	Remark_message1.clear();
    Remark_message2.clear();
	return 0;
}

ProError connectors_visit_action(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("--------------------------  connectors_visit_action  --------------------------");

	ProMdlfileType			comp_type;
	ProFamilyMdlName		comp_name;
	char					part_no[PRO_PATH_SIZE];
	ProAsmcompconstraint* constr_array;
	ProMdl					model;
	ProFeattype				ftype;
	ProAsmcompconstraint	constraint;
	ProAsmcompconstraint* constraints;
	ProMdlType				type;
	ProPatternStatus 		p_pattern_status;
	ProFeatStatus 			p_status;

	wchar_t asm_name[PRO_NAME_SIZE];
	char asm_name_str[PRO_NAME_SIZE];
	string asm_with_elb_connctr;

	ruleLog.Write("connectors_visit_action called  level_pipe = " + to_string(level_pipe));

	status = ProFeatureTypeGet(p_feature, &ftype);
	ruleLog.Write("ProFeatureTypeGet status = " + to_string(status));
	ruleLog.Write("Feature type" + to_string(ftype));

	if (ftype == PRO_FEAT_COMPONENT)
	{
		ruleLog.Write(" Component Level = " + to_string(level_pipe));
		status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
		ruleLog.Write("ProAsmcompMdlMdlnameGet status = " + to_string(status));

		ProWstringToString(part_no, comp_name);
		ruleLog.Write("ProMdlName = " + string(part_no));

		++model_count_pipe;

		status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
		ruleLog.Write("ProAsmcompMdlGet status  =  " + to_string(status));
		if(status != PRO_TK_E_NOT_FOUND) {

			status = ProMdlTypeGet(model, &type);
			ruleLog.Write("ProMdlTypeGet status  =  " + to_string(status));

			ruleLog.Write("check ifelse loop");  //checks 

			feat_id_data  _feat_id_data;
			if (level_pipe == 1) {

				_feat_id_data.feat_ids[0] = p_feature->id;
				_feat_id_data.level = level_pipe;

				feat_id_data_Arry.push_back(_feat_id_data);
			}
			else {
				for (int j = 0; j < feat_id_data_Arry.size(); ++j) {

					if (feat_id_data_Arry[j].feat_ids[level_pipe - 2] == owner_feat_id_pipe) {

						feat_id_data	owner_feat_id_data = feat_id_data_Arry[j];

						for (int i = 0; i < level_pipe - 1; ++i) {
							_feat_id_data.feat_ids[i] = owner_feat_id_data.feat_ids[i];
						}
						_feat_id_data.feat_ids[level_pipe - 1] = p_feature->id;
						_feat_id_data.level = level_pipe;
						break;
					}
				}
				feat_id_data_Arry.push_back(_feat_id_data);
			}

			ruleLog.Write("check for loop");  //checks 

			for (int k = 0; k < _connectors.size(); ++k)
			{

				if (strcmp(part_no, _connectors[k].elbo_connector) == 0) {

					ruleLog.Write("elbo connector found = " + string(part_no));

					//parentassembly name

					wchar_t name[PRO_NAME_SIZE];
					char ownername[PRO_NAME_SIZE];
					ProMdl              ownermdl;
					ownermdl = p_feature->owner;
					ProMdlMdlnameGet(ownermdl, name);
					ProWstringToString(ownername, name);
					ruleLog.Write("ownername " + string(ownername));

					connector_in_model _connector;
					strcpy(_connector.elbo_connector, _connectors[k].elbo_connector);
					strcpy(_connector.straight_connector, _connectors[k].straight_connector);
					strcpy(_connector.owner_model, ownername);
					_connector.count = 1;

					_connectors_in_assembly.push_back(_connector);

					ProIdTable			comp_id_table;
					int					table_num;
					ProAsmcomppath		p_comp_path;
					ProModelitem		p_modelitem;
					ProSelection		p_selection;

					ruleLog.Write("level_pipe =  " + to_string(level_pipe));

					table_num = level_pipe;
					
					ruleLog.Write("table_num =  " + to_string(table_num));


					for (int m = 0; m < level_pipe; ++m) {
						ruleLog.Write("insode for"); 


						ruleLog.Write("_feat_id_data.feat_ids[" + to_string(m)+ "]: " + to_string(_feat_id_data.feat_ids[m]));

						comp_id_table[m] = _feat_id_data.feat_ids[m];
						ruleLog.Write("comp_id_table[" +to_string(m) + "]: " + to_string(comp_id_table[m]));

					}

					status = ProMdlToModelitem(model, &p_modelitem);
					ruleLog.Write("ProMdlToModelitem =  " + to_string(status));

					ProMdl curMdl;
					status = ProMdlCurrentGet(&curMdl);

					status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
					ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

					status = ProSelectionAlloc(&p_comp_path, &p_modelitem, &p_selection);
					ruleLog.Write("ProSelectionAlloc: " + to_string(status));

					if(status != 0){
						return PRO_TK_NO_ERROR;
						
					}

					status = ProSelectionHighlight(p_selection, PRO_COLOR_SS_FAILED_ITEMS);
					ruleLog.Write("ProSelectionHighlight: " + to_string(status));
				}
			}

			
		}
		
		ruleLog.Write("check if loop");  //checks 
	
		if (type == PRO_MDL_ASSEMBLY)
		{
			Assy_models_pipe[Assy_models_cnt_pipe].Model = model;
			Assy_models_pipe[Assy_models_cnt_pipe].Model_feat_id = p_feature->id;
			Assy_models_cnt_pipe += 1;
		}
	}

	return PRO_TK_NO_ERROR;
}

ProError getAsmNamesOnly(ProFeature* p_feature, ProError status, vector<string>* asmNamesVec)
{
	//ruleLog.Write("======================= getAsmNamesOnly =======================");
	ProMdl visitingMdl;
	ProMdlType mdlType;
	status = ProAsmcompMdlGet(p_feature, &visitingMdl);
	//ruleLog.Write("ProAsmcompMdlGet status: " + to_string(status));

	status = ProMdlTypeGet(visitingMdl, &mdlType);
	//ruleLog.Write("ProMdlTypeGet status: " + to_string(status));

	wchar_t wMdlName[PRO_NAME_SIZE];
	char cMdlName[PRO_NAME_SIZE];

	ruleLog.Write("check ifelseif loop");  //checks 

	if (mdlType == PRO_MDL_ASSEMBLY)
	{
		status = ProMdlMdlnameGet(visitingMdl, wMdlName);
		//ruleLog.Write("ProMdlMdlnameGet status: " + to_string(status));

		ProWstringToString(cMdlName, wMdlName);
		ruleLog.Write("Name of visiting Mdl: " + string(cMdlName));
		//ruleLog.Write("Name of 1st element in vec: " + string(asmNamesVec->at(0).c_str()));

		if (/*!asmNamesVec->empty() && */((string) cMdlName).find(asmNamesVec->at(0).c_str()) != string::npos)
		{
			//asmNamesVec->clear();
			status = ProSolidFeatVisit((ProSolid)visitingMdl, (ProFeatureVisitAction)getAsmNamesOnly, compsFilter, asmNamesVec);
			ruleLog.Write("ProSolidFeatVisit in if condition status: " + to_string(status));
		}
		else if((((string)cMdlName).find("F5A21") == string::npos) && (((string)cMdlName).find("F5A20") == string::npos))
		{
			asmNamesVec->push_back(cMdlName);
			status = ProSolidFeatVisit((ProSolid)visitingMdl, (ProFeatureVisitAction)getAsmNamesOnly, compsFilter, asmNamesVec);
			ruleLog.Write("ProSolidFeatVisit in else condition status: " + to_string(status));
			//asmNamesVec->push_back(cMdlName);
		}

	}
	return PRO_TK_NO_ERROR;
}

#pragma pop