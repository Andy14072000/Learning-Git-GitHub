/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 04-01-2024	|	V1_0_0		| F2B09 - STEERING SYSTEM RULES
==================================================================================================================*/
#include "F2B09.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2B09002		| Himanshu Pachpute	| MF2B09; MF1A01	|  Ensure clearance between Steering piping+ Rubber hose & Frame >10mm in nominal conditions. Reduction to 5mm with positive clamping. Contact is allowed if pipe protection is provided.
===================================================================================================================*/

#define DLG_F2B09_002           "dlg_IR_F2B09_002" 
#define PB_RCANCEL              "rule_cancel_pb" 
#define PB_ROK                  "rule_ok_pb"
#define MEASUREBUTTON           "Measure"

#define PROMPT1                 "User_Input_Prompt_IR_F2B09_002"
#define PB_R_OK_P               "CommitOK"
#define PB_R_CANCEL_P           "CommitCancel"
#define RADIO_BUTTON_OPTIONS    "Options"
#define INPUT_PANEL_1           "InputPanel1"
#define INPUT_PANEL_2           "InputPanel2"


#define PROMPT2                 "User_Input_Prompt_IR_F2B09_002_02"
#define PB_R_OK_P2              "CommitOK1"
#define PB_R_CANCEL_P2          "CommitCancel1"
#define RADIO_BUTTON_OPTIONS2   "Options2"


struct SelectionInfo_F2B09_002 {
    ProSelection    p_selection{};
    char            Description[PRO_PATH_SIZE]{};
    char            Name[PRO_PATH_SIZE]{};
    int             id{};
    char            mdl_cext[PRO_PATH_SIZE];
};

vector<SelectionInfo_F2B09_002>     CompSelectionInfo_F2B09_002{}, Clamp_SelectionInfo_F2B09_002{};
vector<feat_id_data>                FeatIDDataArr_F2B09_002{}, Clamp_FeatIDDataArr_F2B09_002{};
Asm_model                           AsmCModel_F2B09_002[1000]{}, Clamp_AsmCModel_F2B09_002[1000]{}, 
                                    CModel_F2B09_002[1000]{}, Clamp_CModel_F2B09_002[1000]{};
int	                                AsmModelCount_F2B09_002{}, Clamp_AsmModelCount_F2B09_002{}, MdlCount_F2B09_002{}, 
                                    Clamp_MdlCount_F2B09_002{}, OwnerFeatID_F2B09_002{}, Clamp_OwnerFeatID_F2B09_002{},
                                    Levels_F2B09_002{}, Clamp_Levels_F2B09_002{}, ModelCount_F2B09_002{}, Clamp_ModelCount_F2B09_002{};

string                              String1_F2B09_002{}, String2_F2B09_002{}, String3_F2B09_002{}, 
                                    String4_F2B09_002{}, String5_F2B09_002{}, String6_F2B09_002{};
vector<string>                      CondCheck_F2B09_002{};
vector<ProSelection>                PointVect{};


int IRF2B09::IRF2B09_002(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF2B09::IRF2B09_002   ==========================");

    ProMdl Mdl{};
    status = ProMdlCurrentGet(&Mdl);
    ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

    curMdl = Mdl;
    Clamp_Levels_F2B09_002 = 1;
    Clamp_MdlCount_F2B09_002 = 0;
    Clamp_CModel_F2B09_002[0].Model = Mdl;
    Clamp_CModel_F2B09_002[0].Model_feat_id = 0;
    Clamp_ModelCount_F2B09_002 = 1;
    Clamp_AsmModelCount_F2B09_002 = 0;

    while (Clamp_ModelCount_F2B09_002 > 0) {
        for (int a = 0; a < Clamp_ModelCount_F2B09_002; ++a) {
            Clamp_OwnerFeatID_F2B09_002 = Clamp_CModel_F2B09_002[a].Model_feat_id;
            status = ProSolidFeatVisit((ProSolid)Clamp_CModel_F2B09_002[a].Model, (ProFeatureVisitAction)PartNameAndIdVisitAction_for_Clamps, compsFilter, NULL);
            //ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
        }

        if (Clamp_AsmModelCount_F2B09_002 > 0) {
            ++Clamp_Levels_F2B09_002;
            for (int b = 0; b < Clamp_AsmModelCount_F2B09_002; ++b) {
                Clamp_CModel_F2B09_002[b].Model = Clamp_AsmCModel_F2B09_002[b].Model;
                Clamp_CModel_F2B09_002[b].Model_feat_id = Clamp_AsmCModel_F2B09_002[b].Model_feat_id;
            }
            Clamp_ModelCount_F2B09_002 = Clamp_AsmModelCount_F2B09_002;
            Clamp_AsmModelCount_F2B09_002 = 0;
        }
        else {
            Clamp_ModelCount_F2B09_002 = 0;
        }
    }

    status = ProUIDialogCreate(DLG_F2B09_002, DLG_F2B09_002);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));

    status = ProUIDialogAboveactivewindowSet(DLG_F2B09_002, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));

    status = ProUIPushbuttonActivateActionSet(DLG_F2B09_002, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIPushbuttonActivateActionSet(DLG_F2B09_002, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIPushbuttonActivateActionSet(DLG_F2B09_002, MEASUREBUTTON, (ProUIAction)Measure_Action, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIDialogHide(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogHide: " + to_string(status));

    status = ProUIDialogActivate(DLG_F2B09_002, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));

    status = ProUIDialogDestroy(DLG_F2B09_002);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

    status = ProUIDialogShow(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogShow: " + to_string(status));

    if (isUserQuits)
        return -1;

    bool CondCheckBool = false;
    for (int m = 0; m < CondCheck_F2B09_002.size(); m++) {
        ruleLog.Write("CondCheck_F2B09_002: " + CondCheck_F2B09_002[m]);
        if (CondCheck_F2B09_002[m].compare("Yes") != 0) {
            CondCheckBool = true;
            break;
        }
    }

    string RemarkString{};
    RemarkString += String1_F2B09_002 + String3_F2B09_002;
    RemarkString += "\n\nAcceptance Criteria:\n\tIf the clearance between a component and the frame measures less than 10mm, users must confirm\n\tand provide the names of clamps / brackets situated within 40mm on either side of the \n\tpoint where the clearance is assessed.Additionally, if the clearance measures 0mm, users must \n\tconfirm the presence of protection on the piping at the specific measurement point.\n";

    ruleLog.Write(RemarkString);

    final_res.remark = RemarkString;

    if (CondCheckBool == false)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    RemarkString.clear();
    String1_F2B09_002.clear();
    String2_F2B09_002.clear();
    String3_F2B09_002.clear();
    String4_F2B09_002.clear();
    String5_F2B09_002.clear();
    String6_F2B09_002.clear();
    CondCheck_F2B09_002.clear();
    CompSelectionInfo_F2B09_002.clear();
    FeatIDDataArr_F2B09_002.clear();
    Clamp_SelectionInfo_F2B09_002.clear();
    Clamp_FeatIDDataArr_F2B09_002.clear();
    PointVect.clear();
    memset(&CModel_F2B09_002, 0, sizeof(CModel_F2B09_002));
    memset(&AsmCModel_F2B09_002, 0, sizeof(AsmCModel_F2B09_002));
    memset(&Clamp_CModel_F2B09_002, 0, sizeof(Clamp_CModel_F2B09_002));
    memset(&Clamp_AsmCModel_F2B09_002, 0, sizeof(Clamp_AsmCModel_F2B09_002));
    AsmModelCount_F2B09_002 = 0;
    MdlCount_F2B09_002 = 0;
    OwnerFeatID_F2B09_002 = 0;
    Levels_F2B09_002 = 0;

    return 0;
}

ProError Measure_Action(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    ruleLog.Write("----------------------------- Measure_Action -----------------------------");

    String1_F2B09_002.clear();
    String2_F2B09_002.clear();
    String3_F2B09_002.clear();
    String4_F2B09_002.clear();
    String5_F2B09_002.clear();
    String6_F2B09_002.clear();
    CondCheck_F2B09_002.clear();
    CompSelectionInfo_F2B09_002.clear();
    FeatIDDataArr_F2B09_002.clear();
    PointVect.clear();
    memset(&CModel_F2B09_002, 0, sizeof(CModel_F2B09_002));
    memset(&AsmCModel_F2B09_002, 0, sizeof(AsmCModel_F2B09_002));
    AsmModelCount_F2B09_002 = 0;
    MdlCount_F2B09_002 = 0;
    OwnerFeatID_F2B09_002 = 0;
    Levels_F2B09_002 = 0;

    ProMdl Mdl{};
    status = ProMdlCurrentGet(&Mdl);
    ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

    curMdl = Mdl;
    Levels_F2B09_002 = 1;
    MdlCount_F2B09_002 = 0;
    CModel_F2B09_002[0].Model = Mdl;
    CModel_F2B09_002[0].Model_feat_id = 0;
    int ModelsCount_F2B09_002 = 1;
    AsmModelCount_F2B09_002 = 0;

    while (ModelsCount_F2B09_002 > 0) {
        for (int a = 0; a < ModelsCount_F2B09_002; ++a) {
            OwnerFeatID_F2B09_002 = CModel_F2B09_002[a].Model_feat_id;
            status = ProSolidFeatVisit((ProSolid)CModel_F2B09_002[a].Model, (ProFeatureVisitAction)PartNameAndIdVisitAction_, compsFilter, NULL);
            ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
        }

        if (AsmModelCount_F2B09_002 > 0) {
            ++Levels_F2B09_002;
            for (int b = 0; b < AsmModelCount_F2B09_002; ++b) {
                CModel_F2B09_002[b].Model = AsmCModel_F2B09_002[b].Model;
                CModel_F2B09_002[b].Model_feat_id = AsmCModel_F2B09_002[b].Model_feat_id;
            }
            ModelsCount_F2B09_002 = AsmModelCount_F2B09_002;
            AsmModelCount_F2B09_002 = 0;
        }
        else
            ModelsCount_F2B09_002 = 0;
    }

    ComponentData _reqComps{};
    string reqCompSubMod = { "F1A01" };

    for (int i = 0; i < subModulesList.size(); ++i)
        if (subModulesList[i].name.find(reqCompSubMod) != string::npos)
            strcpy(_reqComps.name, subModulesList[i].name.c_str());

    status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps);
    ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

    ProSelection comp1Sel{};
    ProIdTable idtbl1 = { _reqComps.id };
    ProName comp1_name{};
    ProModelitem feat1{};
    ProMdl reqMdl1{};
    ProAsmcomppath path1{};

    ProStringToWstring(comp1_name, _reqComps.name);
    status = ProMdlnameInit(comp1_name, _reqComps.comp_type, &reqMdl1);
    ruleLog.Write("ProMdlnameInit: " + to_string(status));

    status = ProMdlToModelitem(reqMdl1, &feat1);
    ruleLog.Write("ProMdlToModelitem: " + to_string(status));

    int	table_num = 1;
    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, table_num, &path1);
    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

    status = ProSelectionAlloc(&path1, &feat1, &comp1Sel);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    ProMdlExtension modelExtension{};
    status = ProMdlExtensionGet(reqMdl1, modelExtension);
    ruleLog.Write("ProMdlExtensionGet: " + to_string(status));

    ProCharLine type{};
    ProWstringToString(type, modelExtension);
    ruleLog.Write("type: " + string(type));

    ProBoolean  interf{};
    Pro3dPnt    coord[2]{};
    double      distance{};

    for (int k = 0; k < CompSelectionInfo_F2B09_002.size(); k++) {

        status = ProFitClearanceCompute(comp1Sel, PRO_FIT_INCLUDE_NONE, CompSelectionInfo_F2B09_002[k].p_selection, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &distance, NULL, &interf, coord);
        ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tDistance: " + to_string(distance));
        distance = round(distance * 100.0) / 100.0;

        if (distance < 10.00 && distance != 0.00) {

            PointVect.clear();
            int curWinId1;
            status = ProWindowCurrentGet(&curWinId1);
            ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

            status = ProWindowRepaint(curWinId1);
            ruleLog.Write("ProWindowRepaint: " + to_string(status));

            createDatumPointsusingCSYS(coord, "CSYS_ASM_DEF");

            status = ProUIDialogHide(DLG_F2B09_002);
            ruleLog.Write("ProUIDialogHide: " + to_string(status));

            //status = ProSelectionHighlight(comp1Sel, PRO_COLOR_WARNING);
            //ruleLog.Write("ProSelectionHighlight: " + to_string(status));

            status = ProSelectionHighlight(CompSelectionInfo_F2B09_002[k].p_selection, PRO_COLOR_WARNING);
            ruleLog.Write("ProSelectionHighlight: " + to_string(status));

            String1_F2B09_002 += "Clearance between " + string(_reqComps.name) + "." + string(type) + " and " + CompSelectionInfo_F2B09_002[k].Name + "." + CompSelectionInfo_F2B09_002[k].mdl_cext + ": " + doubleToString(distance) + " i.e <10 mm \n";

            status = ProUIDialogCreate(PROMPT1, PROMPT1);
            ruleLog.Write("ProUIDialogCreate: " + to_string(status));

            status = ProUIDialogAboveactivewindowSet(PROMPT1, PRO_B_FALSE);
            ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));

            status = ProUIPushbuttonActivateActionSet(PROMPT1, PB_R_OK_P, (ProUIAction)ruleDlgOKactionPrompt1, NULL);
            ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

            status = ProUIPushbuttonDisable(PROMPT1, PB_R_OK_P);
            ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));

            bool Quits = false;
            status = ProUIPushbuttonActivateActionSet(PROMPT1, PB_R_CANCEL_P, (ProUIAction)ruleDlgCloseAction1, (ProAppData)&Quits);
            ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

            status = ProUIInputpanelDisable(PROMPT1, "InputPanel1");
            ruleLog.Write("ProUIInputpanelDisable: " + to_string(status));

            status = ProUIInputpanelDisable(PROMPT1, "InputPanel2");
            ruleLog.Write("ProUIInputpanelDisable: " + to_string(status));

            status = ProUIRadiogroupSelectActionSet(PROMPT1, RADIO_BUTTON_OPTIONS, (ProUIAction)Radio_Button_Action1, NULL);
            ruleLog.Write("ProUIRadiogroupSelectActionSet: " + to_string(status));

            int dlg_stat{};
            status = ProUIDialogActivate(PROMPT1, &dlg_stat);
            ruleLog.Write("ProUIDialogActivate: " + to_string(status));

            status = ProUIDialogDestroy(PROMPT1);
            ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

            status = ProUIDialogShow(DLG_F2B09_002);
            ruleLog.Write("ProUIDialogHide: " + to_string(status));

            if (Quits)
                return PRO_TK_GENERAL_ERROR;

            //status = ProSelectionUnhighlight(comp1Sel);
            //ruleLog.Write("ProSelectionUnhighlight: " + to_string(status));

            status = ProSelectionUnhighlight(CompSelectionInfo_F2B09_002[k].p_selection);
            ruleLog.Write("ProSelectionUnhighlight: " + to_string(status));

            deleteDatumPointCreatedUsingCsys("datum_PNT1");
            deleteDatumPointCreatedUsingCsys("datum_PNT2");
        }
        else if (distance == 0.00) {

            int curWinId2;
            status = ProWindowCurrentGet(&curWinId2);
            ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

            status = ProWindowRepaint(curWinId2);
            ruleLog.Write("ProWindowRepaint: " + to_string(status));

            status = ProUIDialogHide(DLG_F2B09_002);
            ruleLog.Write("ProUIDialogHide: " + to_string(status));

            //status = ProSelectionHighlight(comp1Sel, PRO_COLOR_WARNING);
            //ruleLog.Write("ProUIDialogCreate: " + to_string(status));

            status = ProSelectionHighlight(CompSelectionInfo_F2B09_002[k].p_selection, PRO_COLOR_HIGHLITE);
            ruleLog.Write("ProUIDialogCreate: " + to_string(status));

            String3_F2B09_002 += "Clearance between " + string(_reqComps.name) + "." + string(type) + " and " + CompSelectionInfo_F2B09_002[k].Name + "." + CompSelectionInfo_F2B09_002[k].mdl_cext + ": " + doubleToString(distance) + "\n";

            status = ProUIDialogCreate(PROMPT2, PROMPT2);
            ruleLog.Write("ProUIDialogCreate: " + to_string(status));

            status = ProUIDialogAboveactivewindowSet(PROMPT2, PRO_B_FALSE);
            ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));

            status = ProUIPushbuttonActivateActionSet(PROMPT2, PB_R_OK_P2, (ProUIAction)ruleDlgOKactionPrompt2, NULL);
            ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

            status = ProUIPushbuttonDisable(PROMPT2, PB_R_OK_P2);
            ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));

            bool Quits2 = false;
            status = ProUIPushbuttonActivateActionSet(PROMPT2, PB_R_CANCEL_P2, (ProUIAction)ruleDlgCloseAction1, (ProAppData)&Quits2);
            ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

            status = ProUIRadiogroupSelectActionSet(PROMPT2, RADIO_BUTTON_OPTIONS2, (ProUIAction)Radio_Button_Action2, NULL);
            ruleLog.Write("ProUIRadiogroupSelectActionSet: " + to_string(status));

            int dlg_stat2{};
            status = ProUIDialogActivate(PROMPT2, &dlg_stat2);
            ruleLog.Write("ProUIDialogActivate: " + to_string(status));

            status = ProUIDialogDestroy(PROMPT2);
            ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

            status = ProUIDialogShow(DLG_F2B09_002);
            ruleLog.Write("ProUIDialogHide: " + to_string(status));

            if (Quits2)
                return PRO_TK_GENERAL_ERROR;

            //status = ProSelectionUnhighlight(comp1Sel);
            //ruleLog.Write("ProSelectionUnhighlight: " + to_string(status));

            status = ProSelectionUnhighlight(CompSelectionInfo_F2B09_002[k].p_selection);
            ruleLog.Write("ProSelectionUnhighlight: " + to_string(status));

        }
    }

    status = ProUIPushbuttonEnable(DLG_F2B09_002, PB_ROK);
    ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));

    return PRO_TK_NO_ERROR;
}

ProError PartNameAndIdVisitAction_(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    //ruleLog.Write("----------------------------- PartNameAndIdVisitAction -----------------------------");

    SelectionInfo_F2B09_002 CompSelection{};
    //SelectionInfo_F2B09_002 ClampSelection{};
    bool                    compfound = false;
    //ruleLog.Write("Component Levels_F2B09_002: " + to_string(Levels_F2B09_002));

    ProMdlfileType    comp_type{};
    ProFamilyMdlName  comp_name{};
    status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
    //ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));

    char part_no[PRO_PATH_SIZE]{};
    ProWstringToString(part_no, comp_name);
    //ruleLog.Write("ProMdlName: " + string(part_no));

    ++MdlCount_F2B09_002;

    ProMdl model;
    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
    //ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));

    ProMdlType type;
    status = ProMdlTypeGet(model, &type);
    //ruleLog.Write("ProMdlTypeGet:" + to_string(status));

    wchar_t wFeatName[PRO_PATH_SIZE]{};
    status = ProMdlMdlnameGet(model, wFeatName);
    //ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
    char Name_1[PRO_PATH_SIZE]{};
    ProWstringToString(Name_1, wFeatName);

    ProModelitem modelItem{};
    status = ProMdlToModelitem(model, &modelItem);
    //ruleLog.Write("ProMdlToModelitem: " + to_string(status));

    ProName      pDescName = L"DESCRIPTION";
    ProParameter pDesc;
    status = ProParameterInit(&modelItem, pDescName, &pDesc);
    //ruleLog.Write("ProParameterInit: " + to_string(status));

    ProParamvalue pvDesc;
    status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
    //ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));

    char Description_1[PRO_PATH_SIZE]{};
    ProWstringToString(Description_1, pvDesc.value.s_val);
    int id_1 = p_feature->id;

    feat_id_data  _FeatIDdata;
    if (Levels_F2B09_002 == 1) {
        _FeatIDdata.feat_ids[0] = p_feature->id;
        _FeatIDdata.level = Levels_F2B09_002;
        FeatIDDataArr_F2B09_002.push_back(_FeatIDdata);
    }
    else {
        for (int j = 0; j < FeatIDDataArr_F2B09_002.size(); ++j) {
            if (FeatIDDataArr_F2B09_002[j].feat_ids[Levels_F2B09_002 - 2] == OwnerFeatID_F2B09_002) {
                feat_id_data	owner_feat_id_data = FeatIDDataArr_F2B09_002[j];
                for (int i = 0; i < Levels_F2B09_002 - 1; ++i) {
                    _FeatIDdata.feat_ids[i] = owner_feat_id_data.feat_ids[i];
                }
                _FeatIDdata.feat_ids[Levels_F2B09_002 - 1] = p_feature->id;
                _FeatIDdata.level = Levels_F2B09_002;
                break;
            }
        }
        FeatIDDataArr_F2B09_002.push_back(_FeatIDdata);
    }

    regex pattern("\\bF1A01\\b");
    if (!regex_search(Name_1, pattern)) {
        if (Name_1[6] == '8' && (Name_1[7] == '0' || Name_1[7] == '1')) {
            compfound = true;
            ruleLog.Write(to_string(Levels_F2B09_002) + "\t" + string(Name_1) + "\t" + string(Description_1) + "\t" + to_string(id_1));

            ProIdTable			comp_id_table;
            int					table_num;
            ProAsmcomppath		p_comp_path;
            ProModelitem		p_modelitem;

            table_num = Levels_F2B09_002;
            //ruleLog.Write("table_num: " + to_string(table_num));

            for (int m = 0; m < Levels_F2B09_002; ++m) {
                comp_id_table[m] = _FeatIDdata.feat_ids[m];
                //ruleLog.Write("comp_id_table[]: " + to_string(m) + " " + to_string(comp_id_table[m]));
            }

            status = ProMdlToModelitem(model, &p_modelitem);
            //ruleLog.Write("ProMdlToModelitem: " + to_string(status));

            ProMdl curMdl;
            status = ProMdlCurrentGet(&curMdl);
            //ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

            status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
            //ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

            status = ProSelectionAlloc(&p_comp_path, &p_modelitem, &CompSelection.p_selection);
            //ruleLog.Write("ProSelectionAlloc: " + to_string(status));

            ProMdlExtension modelExtension1;
            status = ProMdlExtensionGet(p_modelitem.owner, modelExtension1);
            //ruleLog.Write("ProMdlExtensionGet: " + to_string(status));

            ProWstringToString(CompSelection.mdl_cext, modelExtension1);
            //ruleLog.Write("CompSelection.Extension: " + string(CompSelection.mdl_cext));

            strcpy(CompSelection.Description, Description_1);
            strcpy(CompSelection.Name, Name_1);
            CompSelection.id = id_1;

            CompSelectionInfo_F2B09_002.push_back(CompSelection);
        }
    }

    if (type == PRO_MDL_ASSEMBLY && compfound == false)
    {
        AsmCModel_F2B09_002[AsmModelCount_F2B09_002].Model = model;
        AsmCModel_F2B09_002[AsmModelCount_F2B09_002].Model_feat_id = p_feature->id;
        AsmModelCount_F2B09_002 += 1;
    }

    return PRO_TK_NO_ERROR;
}

ProError PartNameAndIdVisitAction_for_Clamps(ProFeature* p_feature1, ProError status1, ProAppData app_data1) {

    ruleLog.Write("----------------------------- PartNameAndIdVisitAction_for_Clamps -----------------------------");

    SelectionInfo_F2B09_002 ClampSelection;
    bool                    ClampCompfound = false;
    //ruleLog.Write("Component Level: " + to_string(Clamp_Levels_F2B09_002));

    ProMdlfileType    comp_type;
    ProFamilyMdlName  comp_name;
    status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature1, &comp_type, comp_name);
    //ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));

    char part_no[PRO_PATH_SIZE]{};
    ProWstringToString(part_no, comp_name);
    //ruleLog.Write("ProMdlName: " + string(part_no));

    ++Clamp_MdlCount_F2B09_002;

    ProMdl model;
    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature1, &model);
    //ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));

    ProMdlType type;
    status = ProMdlTypeGet(model, &type);
    //ruleLog.Write("ProMdlTypeGet:" + to_string(status));

    wchar_t wFeatName[PRO_PATH_SIZE]{};
    status = ProMdlMdlnameGet(model, wFeatName);
    //ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
    char clamp_part_name[PRO_PATH_SIZE]{};
    ProWstringToString(clamp_part_name, wFeatName);

    ProModelitem modelItem;
    status = ProMdlToModelitem(model, &modelItem);
    //ruleLog.Write("ProMdlToModelitem: " + to_string(status));

    ProName      pDescName = L"DESCRIPTION";
    ProParameter pDesc;
    status = ProParameterInit(&modelItem, pDescName, &pDesc);
    //ruleLog.Write("ProParameterInit: " + to_string(status));

    ProParamvalue pvDesc;
    status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
    //ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));

    char clamp_part_description[PRO_PATH_SIZE]{};
    ProWstringToString(clamp_part_description, pvDesc.value.s_val);
    //ruleLog.Write("ProWstringToString: " + string(clamp_part_description));

    int clamp_part_Id = p_feature1->id;

    feat_id_data  _FeatIDdata;
    if (Clamp_Levels_F2B09_002 == 1) {
        _FeatIDdata.feat_ids[0] = p_feature1->id;
        _FeatIDdata.level = Clamp_Levels_F2B09_002;
        Clamp_FeatIDDataArr_F2B09_002.push_back(_FeatIDdata);
    }
    else {
        for (int j = 0; j < Clamp_FeatIDDataArr_F2B09_002.size(); ++j) {
            if (Clamp_FeatIDDataArr_F2B09_002[j].feat_ids[Clamp_Levels_F2B09_002 - 2] == Clamp_OwnerFeatID_F2B09_002) {
                feat_id_data	owner_feat_id_data = Clamp_FeatIDDataArr_F2B09_002[j];
                for (int i = 0; i < Clamp_Levels_F2B09_002 - 1; ++i) {
                    _FeatIDdata.feat_ids[i] = owner_feat_id_data.feat_ids[i];
                }
                _FeatIDdata.feat_ids[Clamp_Levels_F2B09_002 - 1] = p_feature1->id;
                _FeatIDdata.level = Clamp_Levels_F2B09_002;
                break;
            }
        }
        Clamp_FeatIDDataArr_F2B09_002.push_back(_FeatIDdata);
    }

    regex pattern1("\\bCLAMP\\b");
    if (regex_search(clamp_part_description, pattern1)) {
        ClampCompfound = true;
        
        int					table_num1;
        ProIdTable			comp_id_table1;
        table_num1 = Clamp_Levels_F2B09_002;
        //ruleLog.Write("table_num1: " + to_string(table_num1));

        for (int m = 0; m < Clamp_Levels_F2B09_002; ++m) {
            comp_id_table1[m] = _FeatIDdata.feat_ids[m];
            //ruleLog.Write("comp_id_table1[]: " + to_string(m) + " " + to_string(comp_id_table1[m]));
        }

        ProModelitem		p_modelitem1;
        status = ProMdlToModelitem(model, &p_modelitem1);
        //ruleLog.Write("ProMdlToModelitem: " + to_string(status));

        ProMdl curMdl;
        status = ProMdlCurrentGet(&curMdl);
        //ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

        ProAsmcomppath		p_comp_path1;
        status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table1, table_num1, &p_comp_path1);
        //ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

        status = ProSelectionAlloc(&p_comp_path1, &p_modelitem1, &ClampSelection.p_selection);
        //ruleLog.Write("ProSelectionAlloc: " + to_string(status));

        ProMdlExtension modelExtension2;
        status = ProMdlExtensionGet(p_modelitem1.owner, modelExtension2);
        //ruleLog.Write("ProMdlExtensionGet: " + to_string(status));
        ProWstringToString(ClampSelection.mdl_cext, modelExtension2);

        strcpy(ClampSelection.Description, clamp_part_description);
        strcpy(ClampSelection.Name, clamp_part_name);
        ClampSelection.id = clamp_part_Id;
        ruleLog.Write(string(ClampSelection.Name) + "\t" + string(ClampSelection.Description) + "\t" + to_string(ClampSelection.id));

        Clamp_SelectionInfo_F2B09_002.push_back(ClampSelection);
    }

    if (type == PRO_MDL_ASSEMBLY && ClampCompfound == false)
    {
        Clamp_AsmCModel_F2B09_002[Clamp_AsmModelCount_F2B09_002].Model = model;
        Clamp_AsmCModel_F2B09_002[Clamp_AsmModelCount_F2B09_002].Model_feat_id = p_feature1->id;
        Clamp_AsmModelCount_F2B09_002 += 1;
    }

    return PRO_TK_NO_ERROR;


}

ProError Radio_Button_Action1(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- Radio_Button_Action1 -----------------------------");

    //status = ProUIPushbuttonEnable(dialog, PB_R_OK_P);
    //ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));

    int n_names{};
    char** radio_name = nullptr;
    String6_F2B09_002.clear();

    status = ProUIRadiogroupSelectednamesGet(dialog, component, &n_names, &radio_name);
    ruleLog.Write("ProUIRadiogroupSelectednamesGet: " + to_string(status));
    ruleLog.Write("radio_name: " + string(radio_name[0]));
    String6_F2B09_002 = radio_name[0];
    ruleLog.Write("String6_F2B09_002: " + String6_F2B09_002);

    String2_F2B09_002 = "\tConfirmation supplied by the user: " + string(String6_F2B09_002.c_str()) + "\n";

    if (strcmp(String6_F2B09_002.c_str(), "Yes") == 0) {

        status = ProUIPushbuttonEnable(dialog, PB_R_OK_P);
        ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));

        status = ProUIInputpanelEnable(dialog, "InputPanel1");
        ruleLog.Write("ProUIInputpanelEnable: " + to_string(status));

        status = ProUIInputpanelEnable(dialog, "InputPanel2");
        ruleLog.Write("ProUIInputpanelEnable: " + to_string(status));
    }
    else if (strcmp(String6_F2B09_002.c_str(), "No") == 0) {

        String2_F2B09_002 += "\n";
        status = ProUIPushbuttonEnable(dialog, PB_R_OK_P);
        ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));

        status = ProUIInputpanelDisable(dialog, "InputPanel1");
        ruleLog.Write("ProUIInputpanelDisable: " + to_string(status));

        status = ProUIInputpanelDisable(dialog, "InputPanel2");
        ruleLog.Write("ProUIInputpanelDisable: " + to_string(status));
    }
    else if (strcmp(String6_F2B09_002.c_str(), "Select") == 0 || strlen(String6_F2B09_002.c_str()) == 0) {

        status = ProUIPushbuttonDisable(dialog, PB_R_OK_P);
        ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));

        status = ProUIInputpanelDisable(dialog, "InputPanel1");
        ruleLog.Write("ProUIInputpanelDisable: " + to_string(status));

        status = ProUIInputpanelDisable(dialog, "InputPanel2");
        ruleLog.Write("ProUIInputpanelDisable: " + to_string(status));

    }

    return PRO_TK_NO_ERROR;
}

ProError Radio_Button_Action2(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- Radio_Button_Action2 -----------------------------");

    //status = ProUIPushbuttonEnable(dialog, PB_R_OK_P2);
    //ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));

    int n_names2{};
    char** radio_name2;
    String5_F2B09_002.clear();

    status = ProUIRadiogroupSelectednamesGet(dialog, component, &n_names2, &radio_name2);
    ruleLog.Write("ProUIRadiogroupSelectednamesGet: " + to_string(status));
    ruleLog.Write("radio_name2: " + string(radio_name2[0]));
    String5_F2B09_002 = radio_name2[0];
    ruleLog.Write("String5_F2B09_002: " + String5_F2B09_002);

    String4_F2B09_002 = "\tConfirmation supplied by the user: " + string(String5_F2B09_002.c_str()) + "\n\n";

    if (strcmp(String5_F2B09_002.c_str(), "Yes") == 0) {
        status = ProUIPushbuttonEnable(dialog, PB_R_OK_P2);
        ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));
    }
    else if (strcmp(String5_F2B09_002.c_str(), "No") == 0) {
        status = ProUIPushbuttonEnable(dialog, PB_R_OK_P2);
        ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));
    }
    else if (strcmp(String5_F2B09_002.c_str(), "Select") == 0 || strlen(String5_F2B09_002.c_str()) == 0) {
        status = ProUIPushbuttonDisable(dialog, PB_R_OK_P);
        ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));
    }
    return PRO_TK_NO_ERROR;
}

ProError createDatumPointsusingCSYS(Pro3dPnt pnt_arr[2], char* csysName) {

    ruleLog.Write("----------------------------- createDatumPointsusingCSYS -----------------------------");

    wchar_t wCsysName[PRO_PATH_SIZE]{};
    ProStringToWstring(wCsysName, csysName);
    ProModelitem refCsysitem{};
    status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
    ruleLog.Write("ProModelitemByNameInit: " + to_string(status));

    ProSelection refCsysSel{};
    status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    ProElement	elem_tree{};
    status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    ProElement	elem_ftype{};
    status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
    ruleLog.Write("ProElementIntegerSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	elem_feature_name{};
    status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    wchar_t wDatumPointName[PRO_PATH_SIZE]{};
    char cDatumPointName[PRO_PATH_SIZE] = "Dist_highlght_pnt";
    status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, cDatumPointName));
    ruleLog.Write("ProElementWstringSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_type{};
    status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
    ruleLog.Write("ProElementIntegerSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement pro_e_dpoint_ofst_csys_type{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
    ruleLog.Write("ProElementIntegerSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_ref{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    ProReference REPDEP_ref1{};
    status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
    ruleLog.Write("ProSelectionToReference: " + to_string(status));

    status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
    ruleLog.Write("ProElementReferenceSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_with_dims{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
    ruleLog.Write("ProElementIntegerSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_pnts_array{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_pnt_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_pnt_name_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    wchar_t wide_string[PRO_NAME_SIZE]{};
    ProStringToWstring(wide_string, "datum_PNT1");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
    ruleLog.Write("ProElementWstringSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_dir1_val_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement pro_e_dpoint_ofst_csys_dir2_val_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    double d1 = -pnt_arr[0][2];
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_dir3_val_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_pnt_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement pro_e_dpoint_ofst_csys_pnt_name_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    wchar_t wide_string_2[PRO_PATH_SIZE]{};
    ProStringToWstring(wide_string_2, "datum_PNT2");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
    ruleLog.Write("ProElementWstringSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_dir1_val_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_dir2_val_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    double d2 = -pnt_arr[1][2];
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement pro_e_dpoint_ofst_csys_dir3_val_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProSelection reqMdlSel{};
    status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    ProFeatureCreateOptions* opts = 0;
    status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
    ruleLog.Write("ProArrayAlloc: " + to_string(status));

    ProFeature pnt_feat{};
    opts[0] = PRO_FEAT_CR_NO_OPTS;
    ProErrorlist errors{};
    status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
    ruleLog.Write("ProFeatureWithoptionsCreate: " + to_string(status));

    status = ProArrayFree((ProArray*)&opts);
    ruleLog.Write("ProArrayFree: " + to_string(status));

    status = ProElementFree(&elem_tree);
    ruleLog.Write("ProElementFree: " + to_string(status));

    status = ProSelectionFree(&reqMdlSel);
    ruleLog.Write("ProSelectionFree: " + to_string(status));

    ProSelection pnt_Sel{};
    status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_HIGHLITE);
    ruleLog.Write("ProSelectionHighlight: " + to_string(status));

    ProAppData app_data{};
    PointVect.clear();
    status = ProFeatureGeomitemVisit(&pnt_feat, PRO_POINT, (ProGeomitemAction)DatumPointsVisitAction, NULL, app_data);
    ruleLog.Write("ProFeatureGeomitemVisit: " + to_string(status));

    double         distance1{};
    double         distance2{};
    Pro2dPnt       param_1{}, param_2{};
    Pro3dPnt       pnt_1{}, pnt_2{};

    for (size_t i = 0; i < Clamp_SelectionInfo_F2B09_002.size(); i++) {
        status = ProSelectionWithOptionsDistanceEval(PointVect[0], PRO_B_TRUE, Clamp_SelectionInfo_F2B09_002[i].p_selection, PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance1);
        ruleLog.Write("ProSelectionWithOptionsDistanceEvalforPoint1: " + to_string(status) + "\tDistance: " + to_string(distance1));

        status = ProSelectionWithOptionsDistanceEval(PointVect[1], PRO_B_TRUE, Clamp_SelectionInfo_F2B09_002[i].p_selection, PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance2);
        ruleLog.Write("ProSelectionWithOptionsDistanceEvalforPoint2: " + to_string(status) + "\tDistance: " + to_string(distance2));

        if (distance1 <= 40.00 || distance2 <= 40.00) {
            status = ProSelectionHighlight(Clamp_SelectionInfo_F2B09_002[i].p_selection, PRO_COLOR_HIGHLITE);
            ruleLog.Write("ProSelectionHighlight: " + to_string(status));
        }
        //else {
        //    status = ProSelectionHighlight(Clamp_SelectionInfo_F2B09_002[i].p_selection, PRO_COLOR_EDGE_HIGHLIGHT);
        //    ruleLog.Write("ProSelectionHighlight: " + to_string(status));
        //}
    }

    return PRO_TK_NO_ERROR;
}

ProError DatumPointsVisitAction(ProGeomitem* geomitem, ProAppData data)
{
    ruleLog.Write("----------------------------- DatumPointsVisitAction -----------------------------");

    ruleLog.Write("geomitem->id: " + to_string(geomitem->id));
    ProSelection Pselection{};
    status = ProSelectionAlloc(NULL, geomitem, &Pselection);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));
    PointVect.push_back(Pselection);

    return PRO_TK_NO_ERROR;
}

ProError deleteDatumPointCreatedUsingCsys(char* dtmpoint_name)
{
    ruleLog.Write("----------------------------- deleteDatumPoint -----------------------------");

    ProIdTable idtbl1{};
    ProAsmcomppath path{};
    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path);
    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

    wchar_t wdatum_pt[PRO_PATH_SIZE]{};
    ProStringToWstring(wdatum_pt, dtmpoint_name);
    ProModelitem mdl_item{};
    status = ProModelitemByNameInit(curMdl, PRO_POINT, wdatum_pt, &mdl_item);
    ruleLog.Write("ProModelitemByNameInit: " + to_string(status));

    if (status == PRO_TK_NO_ERROR) {

        int* feat_ids = NULL;
        status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
        ruleLog.Write("ProArrayAlloc: " + to_string(status));

        ProFeature feat{};
        status = ProGeomitemFeatureGet((ProGeomitem*)&mdl_item, &feat);
        ruleLog.Write("ProGeomitemFeatureGet: " + to_string(status));
        feat_ids[0] = feat.id;

        ProFeatureDeleteOptions* delete_opts = 0;
        status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
        ruleLog.Write("ProArrayAlloc: " + to_string(status));

        delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;
        status = ProFeatureWithoptionsDelete((ProSolid)curMdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
        ruleLog.Write("ProFeatureWithoptionsDelete: " + to_string(status));

        status = ProArrayFree((ProArray*)&delete_opts);
        ruleLog.Write("ProArrayFree: " + to_string(status));

        status = ProArrayFree((ProArray*)&feat_ids);
        ruleLog.Write("ProArrayFree: " + to_string(status));

    }

    return PRO_TK_NO_ERROR;
}

ProError ruleDlgOKactionPrompt1(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgOKactionPrompt1 -----------------------------");

    char lable11[PRO_PATH_SIZE]{};
    char lable22[PRO_PATH_SIZE]{};

    String1_F2B09_002 += String2_F2B09_002;
    CondCheck_F2B09_002.push_back(String6_F2B09_002);

    if (strcmp(String6_F2B09_002.c_str(), "Yes") == 0) {
        wchar_t* label1{};
        status = ProUIInputpanelValueGet(dialog, "InputPanel1", &label1);
        ruleLog.Write("ProUIInputpanelValueGet: " + to_string(status));

        ProWstringToString(lable11, label1);
        ruleLog.Write("InputPanel1: " + string(lable11));

        wchar_t* label2{};
        status = ProUIInputpanelValueGet(dialog, "InputPanel2", &label2);
        ruleLog.Write("ProUIInputpanelValueGet: " + to_string(status));

        ProWstringToString(lable22, label2);
        ruleLog.Write("InputPanel2: " + string(lable22));

        if (strlen(lable11) > 0 && strlen(lable22) > 0)
            String1_F2B09_002 += "\t\tUser-provided name for first clamp/bracket in 40mm radius: " + string(lable11) + "\n\t\tUser-provided name for second clamp/bracket in 40mm radius: " + string(lable22) + "\n\n";
        else {
            CondCheck_F2B09_002.push_back("No");
            String1_F2B09_002 += "\t\tUser Didn't provide any bracket names\n\n";
            //InterfaceRule _irule{};
            //_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Bracket Names Missing!", "Selection already exists, Please provide valid inputs!. Refer help document for details.");
        }

    }

    memset(lable11, 0, sizeof(lable11));
    memset(lable22, 0, sizeof(lable22));

    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    ruleLog.Write("ProUIDialogExit: " + to_string(status));

    return PRO_TK_NO_ERROR;
}

ProError ruleDlgOKactionPrompt2(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgOKactionPrompt2 -----------------------------");

    String3_F2B09_002 += String4_F2B09_002;
    CondCheck_F2B09_002.push_back(String5_F2B09_002);

    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    ruleLog.Write("ProUIDialogExit: " + to_string(status));

    return PRO_TK_NO_ERROR;
}

ProError ruleDlgCloseAction1(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgCloseAction1 -----------------------------");

    if (data != NULL) {
        bool* quitAction = (bool*)data;
        *quitAction = true;
    }
    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    ruleLog.Write("ProUIDialogExit: " + to_string(status));

    return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2B09003		| Prajakta Bhelawe	|  MF2B09; MH1A13	|  Ensure clearance between Power steering lines & rotating parts like pulley > 25 mm (reduction to 10mm. if appropriate protection on pipe is provided)
=================================================================================================================*/

#define DLG_F2B09_003	"dlg_IR_F2B09_003" 
#define CommitCancel    "CommitCancel" 
#define CommitOK        "CommitOK"
#define select_pb       "select_pb"

vector <PartnameDescriptionPair>        reqCompsF2B09;
vector<feat_id_data>                    feat_id_data_arr1;
pathVariables                           path_Var;
ProMdl                                  MdlF2B09;
int                                     models_cnt1_F2B09, owner_feat_id1_F2B09, level1_F2B09,
Assy_models_cnt1_F2B09, model_count1_F2B09;
Asm_model                               models_steering1[1000], Assy_models_steering1[1000];
ProSelection* hydPipingPrtSels, p_selection_pulley, p_selection_Belt;
ProAsmcomppath                          p_cmp_path;
vector<string>                          PartName_PulleyVector, PartName_BeltVector, hydPiping;
vector<ProSelection>                    p_selPulley, p_selBelt, pipeSelection, pipeSelectionBelt, pipeSelectionPulley;
string                                  smallestClearanceBeltPipe, smallestClearancePulleyPipe,
part_name, PartName_Pulley{}, PartName_Belt{};

int IRF2B09::IRF2B09_003(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF2B09::IRF2B09_003   ==========================");

    deleteDatumPoint("datum_PNT1");
    deleteDatumPoint("datum_PNT2");
    deleteDatumPoint("datum_PNT3");
    deleteDatumPoint("datum_PNT4");

    double          beltPipingClearance, pulleyPipingClearance;
    ProBoolean      interf1, interf2;
    Pro3dPnt        coord1[2], coord2[2];
    InterfaceRule   _irule;

    vector<ProSelection> pulleySelection, beltSelection;

    Assy_models_cnt1_F2B09 = 0;

    double smallestBeltClearance = 0, smallestPulleyClearance = 0;
    bool first_iteration_belt = true, first_iteration_pulley = true;
    string smallestClearanceBelt, smallestClearancePulley;

    isUserQuits = false;
    status = ProUIDialogCreate(DLG_F2B09_003, DLG_F2B09_003);
    status = ProUIDialogAboveactivewindowSet(DLG_F2B09_003, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_F2B09_003, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_F2B09_003, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_F2B09_003, select_pb, (ProUIAction)select_action_IRF2B09003, NULL);

    status = ProUIPushbuttonDisable(DLG_F2B09_003, PB_RUN);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_F2B09_003, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_F2B09_003);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    status = ProMdlCurrentGet(&MdlF2B09);
    ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));

    level1_F2B09 = 1;
    models_cnt1_F2B09 = 1;
    models_steering1[0].Model = MdlF2B09;
    models_steering1[0].Model_feat_id = 0;

begin:
    for (int a = 0; a < models_cnt1_F2B09; a++)
    {
        ruleLog.Write("inside for");
        owner_feat_id1_F2B09 = models_steering1[a].Model_feat_id;
        status = ProSolidFeatVisit((ProSolid)models_steering1[a].Model, (ProFeatureVisitAction)user_action_F2B09, compsFilter, (ProAppData)&reqCompsF2B09);
        ruleLog.Write("ProSolidFeatVisit status = " + to_string(status));
    }

    if (Assy_models_cnt1_F2B09 > 0) {
        ++level1_F2B09;

        for (int b = 0; b < Assy_models_cnt1_F2B09; ++b)
        {
            models_steering1[b].Model = Assy_models_steering1[b].Model;
            models_steering1[b].Model_feat_id = Assy_models_steering1[b].Model_feat_id;
        }
        models_cnt1_F2B09 = Assy_models_cnt1_F2B09;
        Assy_models_cnt1_F2B09 = 0;
        goto begin;
    }

    bool warningDisplayed = false;

    if (!warningDisplayed) {
        if (p_selBelt.size() == 0 && p_selPulley.size() == 0) {
            // Both belt and pulley are missing, show a different warning
            _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "WARNING", "No Belt or Pulley Found.");
            warningDisplayed = true;
        }
        else if (p_selBelt.size() == 0) {
            // Belt is missing, show a warning
            _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "WARNING", "No Belt Found.");
            warningDisplayed = true;
        }
        else if (p_selPulley.size() == 0) {
            // Pulley is missing, show a warning
            _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "WARNING", "No Pulley Found.");
            warningDisplayed = true;
        }
    }

    for (int i = 0; i < pipeSelection.size(); i++) {
        if (p_selBelt.size() > 0) {
            for (int j = 0; j < p_selBelt.size(); j++) {
                status = ProFitClearanceCompute(p_selBelt[j], PRO_FIT_INCLUDE_NONE, hydPipingPrtSels[i], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &beltPipingClearance, NULL, &interf1, coord1);
                ruleLog.Write("ProFitClearanceCompute1 = " + to_string(status));
                ruleLog.Write("beltPipingClearance = " + to_string(beltPipingClearance));

                if (first_iteration_belt || beltPipingClearance < smallestBeltClearance) {
                    beltSelection.clear();
                    pipeSelectionBelt.clear();
                    smallestBeltClearance = beltPipingClearance;
                    first_iteration_belt = false;

                    smallestClearanceBelt = PartName_BeltVector[j];
                    smallestClearanceBeltPipe = hydPiping[i];
                    beltSelection.push_back(p_selBelt[j]);
                    pipeSelectionBelt.push_back(hydPipingPrtSels[i]);
                }
            }
        }
        else {
            ruleLog.Write("Belt not available for clearance calculation.");
        }

        if (p_selPulley.size() > 0) {
            for (int k = 0; k < p_selPulley.size(); k++) {
                status = ProFitClearanceCompute(p_selPulley[k], PRO_FIT_INCLUDE_NONE, hydPipingPrtSels[i], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &pulleyPipingClearance, NULL, &interf2, coord2);
                ruleLog.Write("ProFitClearanceCompute1 = " + to_string(status));
                ruleLog.Write("pulleyPipingClearance = " + to_string(pulleyPipingClearance));

                if (first_iteration_pulley || pulleyPipingClearance < smallestPulleyClearance) {
                    pulleySelection.clear();
                    pipeSelectionPulley.clear();
                    smallestPulleyClearance = pulleyPipingClearance;
                    first_iteration_pulley = false;

                    smallestClearancePulley = PartName_PulleyVector[k];
                    smallestClearancePulleyPipe = hydPiping[i];
                    pulleySelection.push_back(p_selPulley[k]);
                    pipeSelectionPulley.push_back(hydPipingPrtSels[i]);
                }
            }
        }
        else {
            ruleLog.Write("Pulley not available for clearance calculation.");
        }
    }

    ruleLog.Write("smallestBeltClearance = " + to_string(smallestBeltClearance));
    ruleLog.Write("smallestClearanceBelt = " + smallestClearanceBelt);

    ruleLog.Write("smallestPulleyClearance = " + to_string(smallestPulleyClearance));
    ruleLog.Write("smallestClearancePulley = " + smallestClearancePulley);

    if (smallestPulleyClearance > 25 && smallestBeltClearance > 25) {
        if (beltSelection.size() > 0)
            status = ProSelectionHighlight(beltSelection[0], PRO_COLOR_SHEETMETAL);
        ruleLog.Write("ProSelectionHighlight: " + to_string(status));

        if (pulleySelection.size() > 0)
            status = ProSelectionHighlight(pulleySelection[0], PRO_COLOR_SHEETMETAL);
        ruleLog.Write("ProSelectionHighlight: " + to_string(status));

        createDatumPoints(coord1, "CSYS_ASM_DEF", "distance_pnnt1");
        createDatumPoints(coord2, "CSYS_ASM_DEF", "distance_pnnt1");

        final_res.result = "PASS";
    }
    else {
        if (beltSelection.size() > 0)
            status = ProSelectionHighlight(beltSelection[0], PRO_COLOR_SS_FAILED_ITEMS);
        ruleLog.Write("ProSelectionHighlight: " + to_string(status));

        if (pulleySelection.size() > 0)
            status = ProSelectionHighlight(pulleySelection[0], PRO_COLOR_SS_FAILED_ITEMS);
        ruleLog.Write("ProSelectionHighlight: " + to_string(status));

        if (smallestPulleyClearance < 25)
            createDatumPoints(coord2, "CSYS_ASM_DEF", "distance_pnnt1");

        if (smallestBeltClearance < 25)
            createDatumPoints(coord1, "CSYS_ASM_DEF", "distance_pnnt1");

        final_res.result = "FAIL";
    }

    string remarkSteering = "";

    // Function to format a float value to two decimals
    auto formatToTwoDecimals = [](double value) {
        std::ostringstream oss;
        oss << std::fixed << std::setprecision(2) << value;
        return oss.str();
    };

    if (smallestBeltClearance == 0 && smallestPulleyClearance == 0) {
        remarkSteering = "Neither Belt nor Pulley found for clearance measurement.";
    }
    else {
        if (smallestPulleyClearance == 0 && smallestBeltClearance > 0) {
            remarkSteering += "1)Pulley not found for clearance measurement. \n";
            remarkSteering += "2)Clearance between Belt and Power steering lines: \n";
            remarkSteering += smallestClearanceBelt + ".PRT and " + smallestClearanceBeltPipe + ".PRT = " + formatToTwoDecimals(smallestBeltClearance) + "mm.\n\n";
            remarkSteering += "Acceptance Criteria: Clearance between Steering lines and rotating parts like pulley > 25mm.";
        }
        else if (smallestBeltClearance == 0 && smallestPulleyClearance > 0) {
            remarkSteering += "1)Belt not found for clearance measurement. \n";
            remarkSteering += "2)Clearance between Pulley and Power steering lines: \n";
            remarkSteering += smallestClearancePulley + ".PRT and " + smallestClearancePulleyPipe + ".PRT = " + formatToTwoDecimals(smallestPulleyClearance) + "mm.\n\n";
            remarkSteering += "Acceptance Criteria: Clearance between Steering lines and rotating parts like pulley > 25mm.";
        }
        else if (smallestBeltClearance == 0 && smallestPulleyClearance == 0) {
            remarkSteering += "Neither Belt nor Pulley found for clearance measurement.\n\n";
            remarkSteering += "Acceptance Criteria: Clearance between Steering lines and rotating parts like pulley > 25mm.";
        }
        else if (smallestBeltClearance > 0 && smallestPulleyClearance > 0) {
            remarkSteering += "Distance between 1) Pulley and Power steering lines: \n";
            remarkSteering += smallestClearancePulley + ".PRT and " + smallestClearancePulleyPipe + ".PRT = " + formatToTwoDecimals(smallestPulleyClearance) + "mm. \n\n";
            remarkSteering += "2) Belt and Power steering lines: \n";
            remarkSteering += smallestClearanceBelt + ".PRT and " + smallestClearanceBeltPipe + ".PRT = " + formatToTwoDecimals(smallestBeltClearance) + "mm. \n\n";
            remarkSteering += "Acceptance Criteria: Clearance between Steering lines and rotating parts like pulley > 25mm.";
        }
    }

    final_res.remark = remarkSteering;

    reqCompsF2B09.clear();
    feat_id_data_arr1.clear();
    p_selPulley.clear();
    p_selBelt.clear();
    pipeSelection.clear();
    beltSelection.clear();
    pulleySelection.clear();
    PartName_BeltVector.clear();
    PartName_PulleyVector.clear();
    pipeSelectionBelt.clear();
    pipeSelectionPulley.clear();
    remarkSteering.clear();

    return 0;
}

ProError select_action_IRF2B09003(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("--------------------------  select_action_IRA1A01_003  --------------------------");

    InterfaceRule _irule;

    ProModelitem mdlItem, owner_model_item;
    ProParameter pDesc;
    ProParamvalue pvDesc;
    ProName pDescName = L"DESCRIPTION";
    string                  description;
    char existingPval[PRO_LINE_SIZE]{};
    ProMdl parent_mdl;
    ProMdlName wParentMdlName;
    char cParentMdlName[PRO_MDLNAME_SIZE];
    int n_sels;

    status = ProSelect((char*)"part", -1, NULL, NULL, NULL, NULL, &hydPipingPrtSels, &n_sels);

    ruleLog.Write("n_sel size = " + to_string(n_sels));
    for (int i = 0; i < n_sels; i++) {
        status = ProSelectionAsmcomppathGet(hydPipingPrtSels[i], &p_cmp_path);
        ruleLog.Write("ProSelectionAsmcomppathGet = " + to_string(status));

        //p_cmp_path.table_num = -1;
        p_cmp_path.comp_id_table[p_cmp_path.table_num - 1] = -1;
        p_cmp_path.table_num = p_cmp_path.table_num - 1;

        status = ProAsmcomppathMdlGet(&p_cmp_path, &parent_mdl);
        ruleLog.Write("ProAsmcomppathMdlGet = " + to_string(status));

        status = ProMdlMdlnameGet(parent_mdl, wParentMdlName);
        ProWstringToString(cParentMdlName, wParentMdlName);
        ruleLog.Write("cParentMdlName = " + (string)cParentMdlName);

        status = ProMdlToModelitem(parent_mdl, &owner_model_item);
        ruleLog.Write("ProMdlToModelitem: " + to_string(status));

        status = ProParameterInit(&owner_model_item, pDescName, &pDesc);
        ruleLog.Write("ProParameterInit status = " + to_string(status));
        if (status != PRO_TK_E_NOT_FOUND)
        {
            status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
            ruleLog.Write("ProParameterValueWithUnitsGet status = " + to_string(status));
            ProWstringToString(existingPval, pvDesc.value.s_val);
        }

        description.append(existingPval);
        ruleLog.Write("description = " + description);
        const regex p("(BEND)");
        const regex q("(CONNECTOR)");

        if ((regex_search(description, p) != 0) && (regex_search(description, q) != 0))
        {
            ruleLog.Write("Inside if");
            status = ProUIPushbuttonDisable(dialog, CommitOK);
            _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "WARNING", "Do not select Bend Connectors");
        }
        else
        {
            ruleLog.Write("Inside else");
            if (n_sels > 0) {

                ruleLog.Write("cParentMdlName = " + (string)cParentMdlName);
                hydPiping.push_back(cParentMdlName);
                status = ProUIPushbuttonEnable(dialog, CommitOK);
                pipeSelection.push_back(hydPipingPrtSels[i]);
            }
        }
    }

    return status;
}

ProError user_action_F2B09(ProFeature* p_feature, ProError status, ProAppData appdata)
{
    vector<PartnameDescriptionPair>* prtname_list = (vector<PartnameDescriptionPair>*)appdata;
    ProFeattype ftype;
    ProMdlfileType comp_type;
    ProFamilyMdlName comp_name;
    char part_no[PRO_PATH_SIZE];
    ProMdl model;

    status = ProFeatureTypeGet(p_feature, &ftype);
    ruleLog.Write("ProFeatureTypeGet status = " + to_string(status));
    ruleLog.Write(to_string(ftype));

    if (ftype == PRO_FEAT_COMPONENT)
    {
        ProMdlType type;

        ruleLog.Write(" Component Level = " + to_string(level1_F2B09));
        status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
        ruleLog.Write("ProAsmcompMdlMdlnameGet status = " + to_string(status));

        ProWstringToString(part_no, comp_name);
        ruleLog.Write("ProMdlName = " + string(part_no));

        ++model_count1_F2B09;

        status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
        ruleLog.Write("ProAsmcompMdlGet status  =  " + to_string(status));
        status = ProMdlTypeGet(model, &type);
        ruleLog.Write("ProMdlTypeGet status  =  " + to_string(status));

        feat_id_data  _feat_id_data;
        if (level1_F2B09 == 1) {

            _feat_id_data.feat_ids[0] = p_feature->id;
            _feat_id_data.level = level1_F2B09;

            feat_id_data_arr1.push_back(_feat_id_data);

        }
        else {

            for (int j = 0; j < feat_id_data_arr1.size(); ++j) {

                if (feat_id_data_arr1[j].feat_ids[level1_F2B09 - 2] == owner_feat_id1_F2B09) {

                    feat_id_data	owner_feat_id_data = feat_id_data_arr1[j];

                    for (int i = 0; i < level1_F2B09 - 1; ++i) {
                        _feat_id_data.feat_ids[i] = owner_feat_id_data.feat_ids[i];
                    }
                    _feat_id_data.feat_ids[level1_F2B09 - 1] = p_feature->id;
                    _feat_id_data.level = level1_F2B09;
                    break;
                }
            }
            feat_id_data_arr1.push_back(_feat_id_data);

            wchar_t wFeatName[PRO_NAME_SIZE];
            char cFeatName[PRO_NAME_SIZE];
            ProModelitem modelItem;
            ProParameter pDesc;
            ProParamvalue pvDesc;
            ProName pDescName = L"DESCRIPTION";
            char existingPval[PRO_LINE_SIZE]{};
            string description;
            //string tokenH1A13 = "H1A13";

            status = ProMdlMdlnameGet(model, wFeatName);

            ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
            ProWstringToString(cFeatName, wFeatName);

            part_name = cFeatName;

            status = ProMdlToModelitem(model, &modelItem);
            ruleLog.Write("ProMdlToModelitem: " + to_string(status));

            status = ProParameterInit(&modelItem, pDescName, &pDesc);
            ruleLog.Write("ProParameterInit: " + to_string(status));

            if (status != PRO_TK_E_NOT_FOUND)
            {
                status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
                ruleLog.Write("ProParameterValueWithUnitsGet : " + to_string(status));

                ProWstringToString(existingPval, pvDesc.value.s_val);


                ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval + "Feature ID = " + to_string(p_feature->id));

            }

            description.append(existingPval);
            ruleLog.Write(description);
            const regex p("(PULLEY)");

            if ((regex_search(description, p) != 0) && type == PRO_MDL_PART)
            {
                ruleLog.Write("------------------------inside brakedrum if------------------------");
                ProIdTable			comp_id_table{};
                int table_num;
                ProAsmcomppath		p_comp_path;

                table_num = level1_F2B09;

                ruleLog.Write("table_num =  " + to_string(table_num));
                path_Var.table_num_Vector.push_back(table_num);

                for (int m = 0; m < level1_F2B09; ++m) {
                    comp_id_table[m] = _feat_id_data.feat_ids[m];
                    ruleLog.Write("comp_id_table[] =  " + to_string(m) + "  " + to_string(comp_id_table[m]));
                }

                ProMdl curMdl;
                status = ProMdlCurrentGet(&curMdl);

                status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
                ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

                status = ProSelectionAlloc(&p_comp_path, &modelItem, &p_selection_pulley);
                ruleLog.Write("ProSelectionAlloc: " + to_string(status));
                ruleLog.Write("Part Name  = " + string(cFeatName));
                PartName_Pulley = cFeatName;
                p_selPulley.push_back(p_selection_pulley);
                PartName_PulleyVector.push_back(PartName_Pulley);

            }

            const regex q("(BELT)");

            if ((regex_search(description, q) != 0) && type == PRO_MDL_PART)
            {
                ruleLog.Write("------------------------inside brakedrum if------------------------");
                ProIdTable			comp_id_table{};
                int table_num;
                ProAsmcomppath		p_comp_path;

                table_num = level1_F2B09;

                ruleLog.Write("table_num =  " + to_string(table_num));
                path_Var.table_num_Vector.push_back(table_num);

                for (int m = 0; m < level1_F2B09; ++m) {
                    comp_id_table[m] = _feat_id_data.feat_ids[m];
                    ruleLog.Write("comp_id_table[] =  " + to_string(m) + "  " + to_string(comp_id_table[m]));
                }

                ProMdl curMdl;
                status = ProMdlCurrentGet(&curMdl);

                status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
                ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

                status = ProSelectionAlloc(&p_comp_path, &modelItem, &p_selection_Belt);
                ruleLog.Write("ProSelectionAlloc: " + to_string(status));
                ruleLog.Write("Part Name = " + string(cFeatName));
                PartName_Belt = cFeatName;
                p_selBelt.push_back(p_selection_Belt);
                PartName_BeltVector.push_back(PartName_Belt);

            }
        }

        if (type == PRO_MDL_ASSEMBLY)
        {

            Assy_models_steering1[Assy_models_cnt1_F2B09].Model = model;
            Assy_models_steering1[Assy_models_cnt1_F2B09].Model_feat_id = p_feature->id;
            Assy_models_cnt1_F2B09 += 1;
        }
    }

    return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	    | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2B09004		| Ved Aiyar			| F2B09, H1A13, H1A02	| Ensure clearance between Power steering lines & surrounding aggregates of engine assembly > 10 mm.
===================================================================================================================*/
#define DLG_F2B09_004       "dlg_IR_F2B09_004"
#define PB_RCANCEL          "CommitCancel"
#define PB_ROK              "CommitOK"


ComponentData                           _reqCompsf2b09004[2]{};
vector<int>                             ID_mapf2b09004;
int                                     tarrayf2b09004[100] = { 0 }; // Initialize all elements to 0 (or any default value)
vector<ProSelection>                    selaf2b09_004;
double                                  distancesf2b09004[3];
string                                  remf2b09004 = "Distance from ";
vector<Model_Tree_Information>          treeInformationVectorf2b09004;
Model_Tree_Information                  filter_selectionsf2b09004[3];

int IRF2B09::IRF2B09_004(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF2B09::IRF2B09_004   ==========================");

    string reqCompSubMod[2] = { "F2B09", "H1A01" };
    string comp_names[2];
    isUserQuits = false;
    Pro3dPnt pnt_arr1[2], pnt_arr2[2], pnt_arr[2];
    deleteDatumPoint("datum_PNT1");
    deleteDatumPoint("datum_PNT2");
    deleteDatumPoint("datum_PNT3");
    deleteDatumPoint("datum_PNT4");

    for (int i = 0; i < subModulesList.size(); ++i)
    {
        for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j)
        {
            if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
            {
                strcpy(_reqCompsf2b09004[j].name, subModulesList[i].name.c_str());
                comp_names[j] = subModulesList[i].name;
            }
        }
    }

    status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqCompsf2b09004);

    for (auto elem : _reqCompsf2b09004)
    {
        ruleLog.Write("_reqComps[].name = " + string(elem.name));
        ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
    }

    remf2b09004.append(_reqCompsf2b09004[0].name);



    status = ProUIDialogCreate(DLG_F2B09_004, DLG_F2B09_004);
    status = ProUIDialogAboveactivewindowSet(DLG_F2B09_004, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_F2B09_004, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_F2B09_004, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_F2B09_004, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_F2B09_004);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    char name[PRO_MDLNAME_SIZE];
    char type[PRO_MDLEXTENSION_SIZE];
    ProError status;
    UserAppdata appdata;
    FILE* fp{};
    ProMdl p_asm;
    ProMdl reqMdlsair1hs, mdl;
    ProMdlName modelName;
    ProMdlExtension modelExtension;
    //double distance;
    ProBoolean  interf;
    Pro3dPnt coord[2];
    int count = -1;


    status = ProMdlCurrentGet(&p_asm);
    status = ProMdlMdlnameGet(p_asm, modelName);
    ProWstringToString(name, modelName);
    status = ProMdlExtensionGet(p_asm, modelExtension);
    ProWstringToString(type, modelExtension);

    appdata.fp = fp;
    appdata.level = 1;

    status = ProSolidFeatVisit((ProSolid)p_asm, user_actionf2b09004, compsFilter, &appdata);


    for (const auto& info : filter_selectionsf2b09004)
    {
        ruleLog.Write("Name of assembly = " + string(info.name) + " , ID = " + to_string(info.ID) + " , Description = " + info.description);
        for (const auto& id : info.ID_path)
        {
            ruleLog.Write(to_string(id) + " ");
        }
    }

    remf2b09004 = remf2b09004 + ".asm to " + filter_selectionsf2b09004[1].name + ".asm and " + filter_selectionsf2b09004[2].name + ".asm are\n";


    for (int i = 0; i < sizeof(filter_selectionsf2b09004) / sizeof(filter_selectionsf2b09004[0]); i++)
    {
        /*if (i == reference_idx)
        {
            continue;
        }*/
        ProIdTable id_table{};
        ProMdl reqMdlsair;
        ProName compair;
        ProModelitem featureair;
        // Create a character array with a size one larger than the string to accommodate the null terminator
        char charArray[100];

        //Copy the contents of the std::string to the character array
        strcpy(charArray, filter_selectionsf2b09004[i].name.c_str());
        ProStringToWstring(compair, charArray);
        status = ProMdlnameInit(compair, PRO_MDLFILE_ASSEMBLY, &reqMdlsair);
        ruleLog.Write("ProMdlnameInit status = " + to_string(status));

        status = ProMdlToModelitem(reqMdlsair, &featureair);
        ruleLog.Write("ProMdlToModelitem status = " + to_string(status));

        vector temp = filter_selectionsf2b09004[i].ID_path;
        int vectorSize = filter_selectionsf2b09004[i].ID_path.size();
        //tbl1_sizef5a27006 = vectorSize;

        for (int j = 0; j < vectorSize; ++j)
        {
            tarrayf2b09004[j] = temp[j];
        }

        // Print the elements in the array
        //std::cout << "Array elements:";

        for (int j = 0; j < vectorSize; ++j)
        {
            id_table[j] = tarrayf2b09004[j];
        }

        ProAsmcomppath pathair;
        ProSelection sel;
        status = ProAsmcomppathInit((ProSolid)curMdl, id_table, vectorSize, &pathair);
        ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));

        status = ProSelectionAlloc(&pathair, &featureair, &sel);
        ruleLog.Write("ProSelectionAlloc status = " + to_string(status));

        selaf2b09_004.push_back(sel);


    }

    double distance1, distance2;
    ProBoolean is_interference_found;
    status = ProFitClearanceCompute(selaf2b09_004[0], PRO_FIT_INCLUDE_NONE, selaf2b09_004[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, selaf2b09_004[0], PRO_B_FALSE, &distance1, NULL, &is_interference_found, pnt_arr1);
    ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance1));
    createDatumPoints(pnt_arr1, "CSYS_ASM_DEF","CLEARANCE_HIGHLITE_PNT1");

    status = ProFitClearanceCompute(selaf2b09_004[0], PRO_FIT_INCLUDE_NONE, selaf2b09_004[2], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, selaf2b09_004[0], PRO_B_FALSE, &distance2, NULL, &is_interference_found, pnt_arr2);
    ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance2));
    createDatumPoints(pnt_arr2, "CSYS_ASM_DEF", "CLEARANCE_HIGHLITE_PNT2");


    remf2b09004 = remf2b09004 + doubleToString(distance1) + " mm and " + doubleToString(distance2) + "mm respectively.\nAcceptance criteria : >= 10.00 mm";

    if (distance1 >= 10.00 && distance2 >= 10.00)
    {
        isRightValue = TRUE;
    }
    else
    {
        isRightValue = FALSE;
    }

    final_res.remark = remf2b09004;

    // DECLARE RESULT
    if (isRightValue)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    remf2b09004.clear();
    selaf2b09_004.clear();
    ID_mapf2b09004.clear();
    treeInformationVectorf2b09004.clear();



    return 0;
}

ProError user_actionf2b09004(ProFeature* feature, ProError status, ProAppData appdata)
{
    FILE* fp;
    int level;
    ProMdl mdl27;
    char name27[PRO_MDLNAME_SIZE];
    char type[PRO_MDLEXTENSION_SIZE];
    UserAppdata* appd, appd1;
    ProMdlName modelName;
    ProMdlExtension modelExtension;
    ProAsmcomppath comppath;
    ProModelitem modelItem;
    char existingPval[PRO_NAME_SIZE]{};

    //ProModelitem p_item27;
    ProIdTable table;
    //table[0] = -1;
    //int ID;

    appd = (UserAppdata*)appdata;
    fp = appd->fp;
    level = appd->level;

    status = ProAsmcompMdlGet(feature, &mdl27);
    status = ProMdlMdlnameGet(mdl27, modelName);
    status = ProMdlExtensionGet(mdl27, modelExtension);

    ProWstringToString(name27, modelName);
    ProWstringToString(type, modelExtension);

    //if (strncmp(type, "ASM", 3) == 0 || strncmp(type, "PRT", 3))
    //{
    ID_mapf2b09004.push_back(feature->id);
    //component_path.push_back(ID_mapf2c01004);

    appd1.fp = appd->fp;
    appd1.level = appd->level + 1;

    //numberofasm++;

    status = ProMdlToModelitem(mdl27, &modelItem);
    //ruleLog.Write("ProMdlToModelitem: " + to_string(status));
    ProParameter pDesc;
    ProParamvalue pvDesc;
    ProName pDescName = L"DESCRIPTION";
    status = ProParameterInit(&modelItem, pDescName, &pDesc);
    //ruleLog.Write("ProParameterInit: " + to_string(status));

    if (status == PRO_TK_NO_ERROR)
    {
        status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
        ProWstringToString(existingPval, pvDesc.value.s_val);
        Model_Tree_Information tree1;
        tree1.name = string(name27);
        tree1.ID = feature->id;
        tree1.description = existingPval;
        tree1.ID_path = ID_mapf2b09004;
        tree1.ID_table_size = ID_mapf2b09004.size();

        treeInformationVectorf2b09004.push_back(tree1);

        if (tree1.name.find("F2B09") != std::string::npos)
        {
            /*ruleLog.Write("Name of assembly = " + string(name27) + " , ID = " + to_string(feature->id) + " , Description = " + existingPval);
            for (int id : tree1.ID_path)
            {
                ruleLog.Write(to_string(id) + " ");
            }*/
            filter_selectionsf2b09004[0].name = tree1.name;
            filter_selectionsf2b09004[0].ID = tree1.ID;
            filter_selectionsf2b09004[0].description = tree1.description;
            filter_selectionsf2b09004[0].ID_path = tree1.ID_path;
            filter_selectionsf2b09004[0].ID_table_size = tree1.ID_table_size;


        }

        if (tree1.name.find("H1A02") != std::string::npos)
        {
            /*ruleLog.Write("Name of assembly = " + string(name27) + " , ID = " + to_string(feature->id) + " , Description = " + existingPval);
            for (int id : tree1.ID_path)
            {
                ruleLog.Write(to_string(id) + " ");
            }*/
            filter_selectionsf2b09004[1].name = tree1.name;
            filter_selectionsf2b09004[1].ID = tree1.ID;
            filter_selectionsf2b09004[1].description = tree1.description;
            filter_selectionsf2b09004[1].ID_path = tree1.ID_path;
            filter_selectionsf2b09004[1].ID_table_size = tree1.ID_table_size;
        }

        if (tree1.name.find("H1A13") != std::string::npos)
        {
            /*ruleLog.Write("Name of assembly = " + string(name27) + " , ID = " + to_string(feature->id) + " , Description = " + existingPval);
            for (int id : tree1.ID_path)
            {
                ruleLog.Write(to_string(id) + " ");
            }*/
            filter_selectionsf2b09004[2].name = tree1.name;
            filter_selectionsf2b09004[2].ID = tree1.ID;
            filter_selectionsf2b09004[2].description = tree1.description;
            filter_selectionsf2b09004[2].ID_path = tree1.ID_path;
            filter_selectionsf2b09004[2].ID_table_size = tree1.ID_table_size;
        }

        /*ruleLog.Write("Name of assembly = " + string(name27) + " , ID = " + to_string(feature->id) + " , Description = " + existingPval);
        for (int id : tree1.ID_path)
        {
            ruleLog.Write(to_string(id) + " ");
        }*/


    }

    status = ProSolidFeatVisit((ProSolid)mdl27, user_actionf2b09004, compsFilter, &appd1);
    ID_mapf2b09004.pop_back();
    //}
    return(PRO_TK_CONTINUE);
}

