/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| H1A01 - ENGINE ASSY
==================================================================================================================*/
#include "H1A01.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-H1A01-014	| Pallavi Garodi	| MH1A01	| For HCV Application-Minimum clearance behind engine mounted fan to any obstructions should be 18 mm.
===================================================================================================================*/
#define DLG_H1A01_014	  "dlg_IR_H1A01_014"
#define SELECT_PARTS_PB   "select_pb"
#define PB_ROK			"CommitOK"
#define PB_RCANCEL      "CommitCancel"
ProSelection* partSel;
vector<int>id;
vector<string>name;

int IRH1A01::IRH1A01_014(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRH1A01::IRH1A01_014   ==========================");

	final_res.remark.clear();
	final_res.result.clear();

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_H1A01_014, DLG_H1A01_014);
	status = ProUIDialogAboveactivewindowSet(DLG_H1A01_014, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_H1A01_014, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_H1A01_014, PB_ROK, (ProUIAction)ruleDlgOKaction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_H1A01_014, SELECT_PARTS_PB, (ProUIAction)select_action_IRH1A01_014, (ProAppData)&isUserQuits);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_H1A01_014, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_H1A01_014);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;
	double Output;
	rule_sts = measureDistanceBetweenSurfaces(partSel[0], partSel[1], Output);

	// Remove trailing zeros from the second decimal place
	char				t[20];
	sprintf(t, "%.2f", Output);
	int length = strlen(t);
	while (length > 0 && t[length + 1] == '0') {
		t[length + 1] = '\0';
		length--;
	}
	ruleLog.Write(t);
	int intValue = std::atoi(t);

	/*if (int(t) > 18) {
		isRightValue = true;
	}*/
	string rem_message;
	rem_message += "Clearance between selected engine mounted fan and nearer surface is " + string(t) + "mm.\n\n";
	rem_message += "Used reference part :-" + name[0] + ".prt(Surface id:- " + to_string(id[0]) + "), " + name[1] + ".prt(Surface id:- " + to_string(id[1]) + ")\n";

	// DECLARE RESULT
	if (intValue > 18) {
		final_res.result = "PASS";
		rem_message += "Measured clearance is as per Acceptance criteria\n\n";
	}
	else {
		final_res.result = "FAIL";
		rem_message += "Measured clearance is not as per Acceptance criteria\n\n";
	}
	rem_message += "Acceptance criteria: Minimum clearance behind engine mounted fan to any obstructions should be 18mm.";
	final_res.remark = rem_message;
	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	id.clear();
	name.clear();
	return 0;
}

ProError select_action_IRH1A01_014(char* dialog, char* component, ProAppData data)
{

	int	                      n_sel;
	int               curWinId;
	InterfaceRule     _irule;
	int				  rule_sts;
	ProAsmcomppath	  part_asmcomp_path;
	ProMdl	          parent_mdl;
	wchar_t           wParentMdlName[PRO_NAME_SIZE];
	char              cParentMdlName[PRO_NAME_SIZE];
	char              existingPval[PRO_NAME_SIZE]{};
	ProAsmcomppath    path;
	ProModelitem      modelItem;
	ProParameter      pDesc;
	ProParamvalue     pvDesc;
	ProName pDescName = L"DESCRIPTION";
	ProAnnotationElem annotelem;

	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);
	//status = ProUIDialogHide(DLG_F5A17_003);

	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &partSel, &n_sel);
	ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sel));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_H1A01_014, PB_ROK);
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide inputs again!. Refer help document for details.");
		status = ProUIDialogShow(DLG_H1A01_014);
		return status;
	}

	if (n_sel < 1 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIDialogShow(DLG_H1A01_014);
		status = ProUIPushbuttonDisable(DLG_H1A01_014, PB_ROK);
		return status;
	}

	for (int i = 0; i < n_sel; ++i)
	{
		status = ProSelectionAsmcomppathGet(partSel[i], &part_asmcomp_path);
		ruleLog.Write("ProSelectionAsmcomppathGet = " + to_string(status));

		//	// to find the parent component
		//	path.comp_id_table[path.table_num - 1] = -1;
		//	path.table_num = path.table_num - 1;

		status = ProAsmcomppathMdlGet(&part_asmcomp_path, &parent_mdl);
		ruleLog.Write("ProAsmcomppathMdlGet = " + to_string(status));

		status = ProMdlMdlnameGet(parent_mdl, wParentMdlName);
		ProWstringToString(cParentMdlName, wParentMdlName);
		ruleLog.Write("cParentMdlName = " + (string)cParentMdlName);
		name.push_back(cParentMdlName);
		//status = ProMdlToModelitem(parent_mdl, &modelItem);
		//ruleLog.Write("ProMdlToModelitem: " + to_string(status));
		//
		//status = ProParameterInit(&modelItem, pDescName, &pDesc);
		//ruleLog.Write("ProParameterInit: " + to_string(status));
		//
		//if (status == PRO_TK_NO_ERROR)
		//{
		//	status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc);
		//	ProWstringToString(existingPval, pvDesc.value.s_val);
		//	ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);
		//	//Des.push_back(existingPval);
		//}

		status = ProSelectionModelitemGet(partSel[i], &annotelem);
		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status) + "\tSurface Id: " + to_string(annotelem.id));
		id.push_back(annotelem.id);


	}

	//status = ProUIDialogShow(DLG_F5A17_003);
	status = ProUIPushbuttonEnable(DLG_H1A01_014, PB_ROK);

	return PRO_TK_NO_ERROR;
}
//
///*==================================================================================================================
//RULE ID			| DEVELOPER			| DEPENDENT MODULES					| DESCRIPTION
//-------------------------------------------------------------------------------------------------------------------
//IR-H1A01-001	| Prajakta Bhelawe	| MH1A14;H1A01	| For HCV Application-For the Jet Ring fan ,Radial & axial clearance between Fan blade tip & Shroud should be minimum 18 mm
//===================================================================================================================*/
//#define dlg_IR_H1A01_001  "dlg_IR_H1A01_001"
//#define PB_ROK			  "CommitOK"
//#define PB_RCANCEL		  "CommitCancel"
//#define PB_RSELECT_EDGE    "pb_select_edge"
//#define PB_RSELECT_SURFACE "pb_select_surface"
//
//ProSelection* surf_sel_H1A01;
//ProSelection* edge_sel_H1A01;
//
//int n_sels_surface, n_sels_edge;
//double clearance_Copy1, clearance_Copy2, clearance_Copy3;
//
//ProSelection sel_edge;
//ProSelection sel_surface1, sel_surface2, sel_surface3;
//
//vector<string> name_surf, name_edge;
//
//
//int IRH1A01::IRH1A01_001(ruleResult& final_res)
//{
//	ruleLog.Write("==========================   IRH1A01::IRH1A01_001   ==========================");
//
//	isUserQuits = false;
//	string remarkFanSh;
//
//	status = ProUIDialogCreate(dlg_IR_H1A01_001, dlg_IR_H1A01_001);
//	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
//	status = ProUIDialogAboveactivewindowSet(dlg_IR_H1A01_001, PRO_B_FALSE);
//	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
//	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A01_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
//	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
//
//	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A01_001, PB_RSELECT_EDGE, (ProUIAction)select_action_edge, NULL);
//	ruleLog.Write("ProUIPushbuttonActivateActionSet = " + to_string(status));
//	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A01_001, PB_RSELECT_SURFACE, (ProUIAction)select_action_surface, NULL);
//	ruleLog.Write("ProUIPushbuttonActivateActionSet = " + to_string(status));
//	status = ProUIPushbuttonActivateActionSet(dlg_IR_H1A01_001, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
//	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
//
//
//	status = ProUIDialogHide(DLG_IRC_MAIN);
//	status = ProUIDialogActivate(dlg_IR_H1A01_001, &dlg_sts);
//	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
//	status = ProUIDialogDestroy(dlg_IR_H1A01_001);
//	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
//	status = ProUIDialogShow(DLG_IRC_MAIN);
//
//	if (isUserQuits)
//		return -1;
//
//	double clearance_value1, clearance_value2, clearance_value3;
//
//	ruleLog.Write("n_sels_edge = " + to_string(n_sels_edge));
//	ruleLog.Write("n_sels_surface = " + to_string(n_sels_surface));
//
//	Pro2dPnt param_1, param_2;
//	//Pro3dPnt pnt_1, pnt_2;
//	Pro3dPnt pnt_arr1[2];
//	Pro3dPnt pnt_arr2[2];
//	Pro3dPnt pnt_arr3[2];
//
//	for (int i = 0; i < name_surf.size(); i++)
//	{
//		ruleLog.Write("name_surf = " + name_surf[i]);
//		ruleLog.Write("name_edge = " + name_edge[0]);
//
//	}
//
//	string str = name_edge[0];
//
//
//	status = ProSelectionWithOptionsDistanceEval(sel_edge, PRO_B_FALSE, sel_surface1, PRO_B_FALSE, param_1, param_2, pnt_arr1[0], pnt_arr1[1], &clearance_value1);
//	ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));
//
//	status = ProSelectionWithOptionsDistanceEval(sel_edge, PRO_B_FALSE, sel_surface2, PRO_B_FALSE, param_1, param_2, pnt_arr2[0], pnt_arr2[1], &clearance_value2);
//	ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));
//
//	status = ProSelectionWithOptionsDistanceEval(sel_edge, PRO_B_FALSE, sel_surface3, PRO_B_FALSE, param_1, param_2, pnt_arr3[0], pnt_arr3[1], &clearance_value3);
//	ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));
//
//	ruleLog.Write("clearance_value1 = " + to_string(clearance_value1));
//	ruleLog.Write("clearance_value2 = " + to_string(clearance_value2));
//	ruleLog.Write("clearance_value3 = " + to_string(clearance_value3));
//
//	//1st
//	string strClearance1;
//	strClearance1 = to_string(clearance_value1);
//
//	string result1;
//	size_t dotPos1 = strClearance1.find('.');
//
//	if (dotPos1 != std::string::npos) {
//		// Check if there are at least two characters after the decimal point
//		if (dotPos1 + 3 <= strClearance1.size()) {
//			result1 = strClearance1.substr(0, dotPos1 + 3);  // Include the dot and two characters after
//		}
//		else {
//			// Less than two characters after the decimal point
//			result1 = strClearance1.substr(0, dotPos1 + 1);  // Include only up to the decimal point
//		}
//	}
//	else {
//		// No decimal point found
//		result1 = strClearance1;
//	}
//
//
//	//2nd
//	string strClearance2;
//	strClearance2 = to_string(clearance_value2);
//
//	string result2;
//	size_t dotPos2 = strClearance2.find('.');
//
//	if (dotPos2 != std::string::npos) {
//		// Check if there are at least two characters after the decimal point
//		if (dotPos2 + 3 <= strClearance2.size()) {
//			result2 = strClearance2.substr(0, dotPos2 + 3);  // Include the dot and two characters after
//		}
//		else {
//			// Less than two characters after the decimal point
//			result2 = strClearance2.substr(0, dotPos2 + 1);  // Include only up to the decimal point
//		}
//	}
//	else {
//		// No decimal point found
//		result2 = strClearance2;
//	}
//
//	//3rd
//	string strClearance3;
//	strClearance3 = to_string(clearance_value3);
//
//	string result3;
//	size_t dotPos3 = strClearance3.find('.');
//
//	if (dotPos3 != std::string::npos) {
//		// Check if there are at least two characters after the decimal point
//		if (dotPos3 + 3 <= strClearance3.size()) {
//			result3 = strClearance3.substr(0, dotPos3 + 3);  // Include the dot and two characters after
//		}
//		else {
//			// Less than two characters after the decimal point
//			result3 = strClearance3.substr(0, dotPos3 + 1);  // Include only up to the decimal point
//		}
//	}
//	else {
//		// No decimal point found
//		result3 = strClearance3;
//	}
//
//
//	status = ProWindowRepaint(PRO_VALUE_UNUSED);
//
//	if (clearance_value1 >= 18 && clearance_value2 >= 18 && clearance_value3 >= 18)
//	{
//		final_res.result = "PASS";
//		status = ProSelectionHighlight(sel_edge, PRO_COLOR_SS_REPLACED_COMPS);
//		ruleLog.Write("ProSelectionHighlight: " + to_string(status));
//
//		status = ProSelectionHighlight(sel_surface1, PRO_COLOR_SHEETMETAL);
//		ruleLog.Write("ProSelectionHighlight: " + to_string(status));
//
//		status = ProSelectionHighlight(sel_surface2, PRO_COLOR_SHEETMETAL);
//		ruleLog.Write("ProSelectionHighlight: " + to_string(status));
//
//		status = ProSelectionHighlight(sel_surface3, PRO_COLOR_SHEETMETAL);
//		ruleLog.Write("ProSelectionHighlight: " + to_string(status));
//	}
//
//
//	else
//	{
//		final_res.result = "FAIL";
//
//		if (clearance_value1 < 18)
//		{
//			status = ProSelectionHighlight(sel_edge, PRO_COLOR_SS_FAILED_ITEMS);
//			ruleLog.Write("ProSelectionHighlight: " + to_string(status));
//
//			status = ProSelectionHighlight(sel_surface1, PRO_COLOR_SS_FAILED_ITEMS);
//			ruleLog.Write("ProSelectionHighlight: " + to_string(status));
//		}
//
//		if (clearance_value2 < 18)
//		{
//			status = ProSelectionHighlight(sel_edge, PRO_COLOR_SS_FAILED_ITEMS);
//			ruleLog.Write("ProSelectionHighlight: " + to_string(status));
//
//			status = ProSelectionHighlight(sel_surface2, PRO_COLOR_SS_FAILED_ITEMS);
//			ruleLog.Write("ProSelectionHighlight: " + to_string(status));
//		}
//
//		if (clearance_value3 < 18)
//		{
//			status = ProSelectionHighlight(sel_edge, PRO_COLOR_SS_FAILED_ITEMS);
//			ruleLog.Write("ProSelectionHighlight: " + to_string(status));
//
//			status = ProSelectionHighlight(sel_surface3, PRO_COLOR_SS_FAILED_ITEMS);
//			ruleLog.Write("ProSelectionHighlight: " + to_string(status));
//		}
//	}
//
//	remarkFanSh += "Clearance between Shroud " + name_surf[0] + ".PRT and Fan " + name_edge[0] + ".PRT = " + result1 + "mm, " + result2 + "mm, " + result3 + "mm.";
//	remarkFanSh += "\nAcceptance Criteria : Clearance between Fan and Shroud should be minimum 18mm.";
//
//	//sprintf(remark, "Clearance between Shroud(%s.PRT) and Fan(%s.PRT) = %.2fmm, %.2fmm, %.2fmm. \nAcceptance Criteria: Clearance between Fan and Shroud should be minimum 18mm", name_surf[0], "573701000308_FN9429_210921", clearance_value1, clearance_value2, clearance_value3);
//	final_res.remark = string(remarkFanSh);
//
//
//	name_surf.clear();
//	name_edge.clear();
//
//	remarkFanSh.clear();
//
//
//	return 0;
//}
//
//ProError select_action_edge(char* dialog, char* component, ProAppData data)
//{
//	ProModelitem egde_model_item;
//	ProName name;
//	ProMdl owner;
//	ProModelitem part_model_item;
//	char str_name[PRO_NAME_SIZE];
//
//
//	status = ProSelect("edge", 1, NULL, NULL, NULL, NULL, &edge_sel_H1A01, &n_sels_edge);
//	ruleLog.Write("ProSelect = " + to_string(status));
//
//	if (status == PRO_TK_NO_ERROR && n_sels_edge > 0 && n_sels_surface > 2) {
//		status = ProUIPushbuttonEnable(dialog, PB_ROK);
//	}
//
//	status = ProSelectionModelitemGet(edge_sel_H1A01[0], &egde_model_item);
//	ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));
//
//	status = ProMdlMdlnameGet(egde_model_item.owner, name);
//	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
//
//	ruleLog.Write("ProWstringToString: " + string(ProWstringToString(str_name, name)));
//	name_edge.push_back(str_name);
//
//	status = ProSelectionCopy(edge_sel_H1A01[0], &sel_edge);
//	ruleLog.Write("ProSelectionCopy edge = " + to_string(status));
//
//
//	return status;
//}
//
//ProError select_action_surface(char* dialog, char* component, ProAppData data)
//{
//	ProModelitem surf_model_item;
//	ProName name;
//	ProMdl owner;
//	ProModelitem part_model_item;
//	char str_name[PRO_NAME_SIZE];
//
//	status = ProSelect((char*)"surface", 3, NULL, NULL, NULL, NULL, &surf_sel_H1A01, &n_sels_surface);
//	ruleLog.Write("ProSelect = " + to_string(status));
//
//	if (status == PRO_TK_NO_ERROR && n_sels_edge > 0 && n_sels_surface > 2) {
//		status = ProUIPushbuttonEnable(dialog, PB_ROK);
//	}
//
//	for (int i = 0; i < n_sels_surface; i++)
//	{
//		status = ProSelectionModelitemGet(surf_sel_H1A01[i], &surf_model_item);
//		ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));
//
//		status = ProMdlMdlnameGet(surf_model_item.owner, name);
//		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
//
//		ruleLog.Write("ProWstringToString: " + string(ProWstringToString(str_name, name)));
//		name_surf.push_back(str_name);
//
//	}
//
//
//	status = ProSelectionCopy(surf_sel_H1A01[0], &sel_surface1);
//	ruleLog.Write("ProSelectionCopy surface = " + to_string(status));
//	status = ProSelectionCopy(surf_sel_H1A01[1], &sel_surface2);
//	ruleLog.Write("ProSelectionCopy surface = " + to_string(status));
//	status = ProSelectionCopy(surf_sel_H1A01[2], &sel_surface3);
//	ruleLog.Write("ProSelectionCopy surface = " + to_string(status));
//
//	return status;
//}
//
//ProError run_action_IRH1A01001(char* dialog, char* component, ProAppData data)
//{
//	ruleLog.Write("----------------------------- run_action_IRH1A01001 -----------------------------");
//
//	double clearance_value1, clearance_value2, clearance_value3;
//
//	ruleLog.Write("n_sels_edge = " + to_string(n_sels_edge));
//	ruleLog.Write("n_sels_surface = " + to_string(n_sels_surface));
//
//	Pro2dPnt param_1, param_2;
//	Pro3dPnt pnt_1, pnt_2;
//
//	status = ProSelectionWithOptionsDistanceEval(sel_edge, PRO_B_FALSE, sel_surface1, PRO_B_FALSE, param_1, param_2, pnt_1, pnt_2, &clearance_value1);
//	ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));
//
//	status = ProSelectionWithOptionsDistanceEval(sel_edge, PRO_B_FALSE, sel_surface2, PRO_B_FALSE, param_1, param_2, pnt_1, pnt_2, &clearance_value2);
//	ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));
//
//	status = ProSelectionWithOptionsDistanceEval(sel_edge, PRO_B_FALSE, sel_surface3, PRO_B_FALSE, param_1, param_2, pnt_1, pnt_2, &clearance_value3);
//	ruleLog.Write("ProSelectionWithOptionsDistanceEval = " + to_string(status));
//
//	clearance_Copy1 = clearance_value1;
//	clearance_Copy2 = clearance_value2;
//	clearance_Copy3 = clearance_value3;
//
//	return status;
//}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRH1A01007		| Prajakta Bhelawe			| MH1A17			| EAS architecture should be selected based on Vehicle application (PV/SCV/ILMCV/HCV), vehicle and  fuel type (Gasoline/CNG/LNG/Diesel/H2 ICE).
===================================================================================================================*/
#define DLG_H1A01_007		"dlg_IR_H1A01_007"
#define PB_RCANCEL			"Commit_Cancel"
#define PB_ROK				"Commit_Ok"

string part_nameH1A01, part_nameH1A17;

struct pnEngineEAS_Map
{
    string pnEngine;
    string pnEAS;
};

int IRH1A01::IRH1A01_007(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRH1A01::IRH1A01_007   ==========================");

    vector<PartnameDescriptionPair> reqComps;
    vector<pnEngineEAS_Map> CSVMap;
    boolean enginePNFound = FALSE, EASPNFound = FALSE, dataFound = FALSE;
    string pnEAS, pnEngine;

    status = ProSolidFeatVisit((ProSolid)curMdl, getasmnameH1A01007, compsFilter, (ProAppData)&reqComps);
    ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

    for (int i = 0; i < CSVMap.size(); i++)
    {
        ruleLog.Write("CSVMap[i].pnEAS = " + CSVMap[i].pnEAS);
        ruleLog.Write("CSVMap[i].pnEngine = " + CSVMap[i].pnEngine);
    }

    isUserQuits = false;
    status = ProUIDialogCreate(DLG_H1A01_007, DLG_H1A01_007);
    status = ProUIDialogAboveactivewindowSet(DLG_H1A01_007, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_H1A01_007, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_H1A01_007, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

    status = ProUIPushbuttonDisable(DLG_H1A01_007, PB_RUN);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_H1A01_007, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_H1A01_007);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    vector<vector<string>> dbList2D = getData2D("IRH1A01007.csv");
    for (int i = 1; i < dbList2D.size(); ++i)	// i = 1 for skipping the headers
    {
        pnEngineEAS_Map _temp;
        pnEngine = dbList2D[i][0];

        ruleLog.Write("DB VALUES = " + pnEngine);
        if (pnEngine == part_nameH1A01)
        {


            ruleLog.Write("pnEngine = " + pnEngine);
            _temp.pnEngine = stoi(pnEngine);
            enginePNFound = TRUE;
            dataFound = TRUE;

            pnEAS = dbList2D[i][1];

            ruleLog.Write("pnEAS CSV = " + pnEAS);
            if (pnEAS == part_nameH1A17)
            {
                ruleLog.Write("pnEAS = " + pnEAS);
                _temp.pnEAS = stoi(pnEAS);
                EASPNFound = TRUE;
                break;
            }
            break;
        }

        CSVMap.push_back(_temp);
    }

    if (EASPNFound == FALSE && dataFound == FALSE)
    {
        UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention", "NO DATA FOUND.");
        dataFound = FALSE;
    }

    ruleLog.Write("Data Found = " + to_string(dataFound));

    if (EASPNFound && enginePNFound && dataFound)
    {
        ruleLog.Write("PASS");
        final_res.result = "PASS";

        sprintf(remark, "EAS architecture is selected based on Vehicle application \nEngine Part Number: %s.ASM\nEAS: %s.ASM \n\nAcceptance Criteria: \nFor Engine Part Number:%s.ASM, use EAS Part Number:%s.ASM.", pnEngine, pnEAS, pnEngine, pnEAS);

    }

    if (dataFound == FALSE)
    {
        final_res.result = "FAIL";

        sprintf(remark, "NO DATA FOUND, \nPlease update the database.");
    }

    if (EASPNFound == FALSE && enginePNFound && dataFound)
    {
        ruleLog.Write("FAIL");
        final_res.result = "FAIL";

        sprintf(remark, "EAS architecture is not selected based on Vehicle application\nEngine Part Number: %s.ASM\nEAS: %s.ASM \n\nAcceptance Criteria: \nFor Engine Part Number:%s.ASM, use EAS Part Number:%s.ASM.", part_nameH1A01, part_nameH1A17, pnEngine, pnEAS);

    }

    final_res.remark = string(remark);

    reqComps.clear();
    CSVMap.clear();
    pnEngine.clear();
    pnEAS.clear();
    dbList2D.clear();

    return 0;
}

ProError getasmnameH1A01007(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    ruleLog.Write("================= Utils::getasmname ==================");

    string tokenH1A01 = "H1A01", tokenH1A17 = "H1A17";
    wchar_t					wMdlName[PRO_NAME_SIZE];
    char					cMdlName[PRO_NAME_SIZE];
    ProMdl reqMdl;
    string part_name;

    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
    ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
    ruleLog.Write("ProMdlTypeGet: " + to_string(status));
    status = ProMdlMdlnameGet(reqMdl, wMdlName);
    ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
    ProWstringToString(cMdlName, wMdlName);
    ruleLog.Write("cFeatName = " + string(cMdlName));
    part_name = cMdlName;

    ruleLog.Write("part_name = " + part_name);
    if (part_name.find(tokenH1A01) != string::npos)
    {
        part_nameH1A01 = part_name;
        ruleLog.Write("part_nameH1A01 = " + part_nameH1A01);
    }

    if (part_name.find(tokenH1A17) != string::npos)
    {
        part_nameH1A17 = part_name;
        ruleLog.Write("part_nameH1A17 = " + part_nameH1A17);
    }

    return PRO_TK_NO_ERROR;
}
