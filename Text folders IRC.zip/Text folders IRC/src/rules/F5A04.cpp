/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 29-06-2023	| V1_0_0		| F5A03 - BRAKING SYSTEM RULES
==================================================================================================================*/
#include "F5A04.h"

#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			|   DEVELOPER			|   DEPENDENT MODULES                     	            | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F5A01-005	|   Himanshu Pachpute	|   MF5A03; MF5A04; MF5A05; MF5A15; MF5A16; MF2C01      | Clearance between propeller shaft module and foundation brake module should be 25 mm min.
===================================================================================================================*/

#define DLG_IRF5A03_005     "dlg_IR_F5A03_005"
#define PB_RCLOSE           "CommitClose"
#define PB_ROK              "CommitOK"
#define PB_RMEASURE         "pb_measure"

ComponentData_IR_F5A03_005   reqComps_IR_F5A03_005[6]{};
vector<double>               clearances_IR_F5A03_005{};
int                          iteration_IR_F5A03_005 = 0;
vector<ProSelection>         SelectionhighliteVector_IR_F5A03_005{};
string                       ComputedDist_IR_F5A03_005 = "Distance between ";

int IRF5A04::IRF5A04_001(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF5A03::IRF5A03_005   ==========================");

    string reqCompSubMod[6] = { "F5A03", "F5A04", "F5A05", "F5A15", "F5A16", "F2C01" };
    isUserQuits = false;

    for (int i = 0; i < subModulesList.size(); ++i) {
        for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j) {
            if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos) {
                strcpy(reqComps_IR_F5A03_005[j].name, subModulesList[i].name.c_str());
            }
        }
    }

    status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId_IR_F5A03_005, compsFilter_IR_F5A03_005, (ProAppData)&reqComps_IR_F5A03_005);
    ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

    for (size_t i = 0; i < sizeof(reqComps_IR_F5A03_005) / sizeof(reqComps_IR_F5A03_005[0]); i++)
    {
        ruleLog.Write("reqComps_IR_F5A03_005[].name = " + string(reqComps_IR_F5A03_005[i].name));
        ruleLog.Write("reqComps_IR_F5A03_005[].id = " + to_string(reqComps_IR_F5A03_005[i].id));
    }

    status = ProUIDialogCreate(DLG_IRF5A03_005, DLG_IRF5A03_005);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));

    status = ProUIDialogAboveactivewindowSet(DLG_IRF5A03_005, PRO_B_FALSE);
    ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));

    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A03_005, PB_RCLOSE, (ProUIAction)ruleDlgCloseAction_IR_F5A03_005, (ProAppData)&isUserQuits);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A03_005, PB_RMEASURE, (ProUIAction)measure_action_IR_F5A03_005, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIPushbuttonActivateActionSet(DLG_IRF5A03_005, PB_ROK, (ProUIAction)ruleDlgOKaction_IR_F5A03_005, NULL);
    ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

    status = ProUIDialogHide(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogHide: " + to_string(status));

    status = ProUIDialogActivate(DLG_IRF5A03_005, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));

    status = ProUIDialogDestroy(DLG_IRF5A03_005);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

    status = ProUIDialogShow(DLG_IRC_MAIN);
    ruleLog.Write("ProUIDialogShow: " + to_string(status));

    if (isUserQuits)
        return -1;

    if (!clearances_IR_F5A03_005.empty())
        clearances_IR_F5A03_005.pop_back();

    ComputedDist_IR_F5A03_005 += "\n\nAcceptance criteria: Distance from F2C01 to remaining dependent submodule >=25mm.";

    isRightValue = true;
    string measured_vals;
    for (auto clear_val : clearances_IR_F5A03_005) {
        if (clear_val <= 25) {
            isRightValue = false;
            break;
        }
    }

    final_res.remark = ComputedDist_IR_F5A03_005;

    if (isRightValue)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    memset(reqComps_IR_F5A03_005, 0, sizeof(reqComps_IR_F5A03_005));
    ComputedDist_IR_F5A03_005.clear();
    return 0;
}

ProError Clearance_Compute_Action_IR_F5A03_005(ComponentData_IR_F5A03_005 reqComp1, ComponentData_IR_F5A03_005 reqComp2, double& distance)
{
    ruleLog.Write("----------------------------- Clearance_Compute_Action_IR_F5A03_005 -----------------------------");

    ProSelection sels[2];
    ProIdTable idtbl1 = { reqComp1.id };
    ProIdTable idtbl2 = { reqComp2.id };

    ProName comp1_name, comp2_name;
    ProModelitem feature[2];
    ProMdl reqMdls[2];

    ProStringToWstring(comp1_name, reqComp1.name);
    status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
    ruleLog.Write("ProMdlnameInit: " + to_string(status));
    status = ProMdlToModelitem(reqMdls[0], &feature[0]);
    ruleLog.Write("ProMdlToModelitem: " + to_string(status));

    ProStringToWstring(comp2_name, reqComp2.name);
    status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
    ruleLog.Write("ProMdlnameInit: " + to_string(status));
    status = ProMdlToModelitem(reqMdls[1], &feature[1]);
    ruleLog.Write("ProMdlToModelitem: " + to_string(status));

    ProAsmcomppath path[2];
    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl2, 1, &path[1]);
    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

    status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));
    status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    ProBoolean is_interference_found;
    Pro3dPnt pnt_arr[2];
    status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_FROM_QUILTS, sels[1], PRO_FIT_INCLUDE_TO_QUILTS, PRO_FIT_WHOLE_SURFACE, sels[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
    ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));

    if (distance <= 25) {
        SelectionhighliteVector_IR_F5A03_005.push_back(sels[0]);
    }
    createDatumPointsusingCSYS_IR_F5A03_005(pnt_arr, "CSYS_ASM_DEF");

    return PRO_TK_NO_ERROR;
}

ProError measure_action_IR_F5A03_005(char* dialog, char* component)
{
    ruleLog.Write("----------------------------- measure_action_IR_F5A03_005 -----------------------------");

    _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Processing Time", "Please be patient. This process may take around 10-15 minutes to compute distances. Kindly keep the window open.");

    ComputedDist_IR_F5A03_005 += " " + string(reqComps_IR_F5A03_005[5].name) + "&\n";

    for (int i = 0; i < 6; ++i)
    {
        if (reqComps_IR_F5A03_005[i].id != reqComps_IR_F5A03_005[5].id)
        {
            double Dist{};
            status = Clearance_Compute_Action_IR_F5A03_005(reqComps_IR_F5A03_005[i], reqComps_IR_F5A03_005[5], Dist);
            ruleLog.Write(string(reqComps_IR_F5A03_005[i].name) + " & " + string(reqComps_IR_F5A03_005[5].name) + ": " + to_string(Dist));


            string formattedDistance = doubleToString(Dist);

            ComputedDist_IR_F5A03_005 += "\t" + string(reqComps_IR_F5A03_005[i].name) + ": " + formattedDistance + "mm\n";

            clearances_IR_F5A03_005.push_back(Dist);
            char ipVal[50], ipName[50];
            wchar_t wIpVal[50];
            ProTKSprintf(ipName, "ip%d", i + 1);

            if (Dist >= 25)
                ProTKSprintf(ipVal, "%dmm [Pass]", int(Dist));
            else
                ProTKSprintf(ipVal, "%dmm [Fail]", int(Dist));

            status = ProUIInputpanelEnable(dialog, ipName);
            ruleLog.Write("ProUIInputpanelEnable: " + to_string(status));

            status = ProUIInputpanelValueSet(dialog, ipName, ProStringToWstring(wIpVal, ipVal));
            ruleLog.Write("ProUIInputpanelValueSet: " + to_string(status));

            status = ProUIInputpanelReadOnly(dialog, ipName);
            ruleLog.Write("ProUIInputpanelReadOnly: " + to_string(status));

            formattedDistance.clear();
        }
    }

    status = ProUIPushbuttonEnable(dialog, PB_ROK);
    ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));

    status = ProUIPushbuttonDisable(DLG_IRF5A03_005, PB_RMEASURE);
    ruleLog.Write("ProUIPushbuttonDisable: " + to_string(status));

    for (size_t n = 0; n < SelectionhighliteVector_IR_F5A03_005.size(); n++) {
        status = ProSelectionHighlight(SelectionhighliteVector_IR_F5A03_005[n], PRO_COLOR_HIGHLITE);
        ruleLog.Write("ProSelectionHighlight: " + to_string(status));
    }

    return PRO_TK_NO_ERROR;
}

ProError compsFilter_IR_F5A03_005(ProFeature* p_feature, ProAppData app_data)
{
    ruleLog.Write("----------------------------- compsFilter_IR_F5A03_005 -----------------------------");

    ProFeattype feat_type;
    status = ProFeatureTypeGet(p_feature, &feat_type);

    return (feat_type == PRO_FEAT_COMPONENT ? PRO_TK_NO_ERROR : PRO_TK_CONTINUE);
}

ProError getReqComponentsId_IR_F5A03_005(ProFeature* pFeat, ProError status, ProAppData appD)
{
    ruleLog.Write("----------------------------- getReqComponentsId_IR_F5A03_005 -----------------------------");

    ComponentData_IR_F5A03_005* reqs = (ComponentData_IR_F5A03_005*)appD;
    int reqs_size = 6;
    ProMdl req_mdl{};
    wchar_t wMdlName[PRO_NAME_SIZE]{};
    char cMdlName[PRO_NAME_SIZE]{};

    status = ProAsmcompMdlGet((ProAsmcomp*)pFeat, &req_mdl);
    ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));

    status = ProMdlMdlnameGet(req_mdl, wMdlName);
    ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
    ProWstringToString(cMdlName, wMdlName);

    for (int i = 0; i < reqs_size; ++i) {
        if (strcmp(cMdlName, reqs[i].name) == 0) {
            reqs[i].id = pFeat->id;
            ruleLog.Write("reqs[i].name: " + string(reqs[i].name));
            ruleLog.Write("reqs[i].id: " + to_string(reqs[i].id));
        }

    }

    return PRO_TK_NO_ERROR;
}

ProError createDatumPointsusingCSYS_IR_F5A03_005(Pro3dPnt pnt_arr[2], char* csysName)
{
    ruleLog.Write("----------------------------- createDatumPointsusingCSYS_IR_F5A03_005 -----------------------------");

    iteration_IR_F5A03_005++;

    wchar_t wCsysName[PRO_PATH_SIZE]{};
    ProStringToWstring(wCsysName, csysName);
    ProModelitem refCsysitem{};
    status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
    ruleLog.Write("ProModelitemByNameInit: " + to_string(status));

    ProSelection refCsysSel{};
    status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    ProElement	elem_tree{};
    status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    ProElement	elem_ftype{};
    status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
    ruleLog.Write("ProElementIntegerSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	elem_feature_name{};
    status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    wchar_t wDatumPointName[PRO_PATH_SIZE]{};
    string iterationString = to_string(iteration_IR_F5A03_005);
    char cDatumPointName[PRO_PATH_SIZE];
    strcpy(cDatumPointName, "Dist_highlght_pnt_");
    strcat(cDatumPointName, iterationString.c_str());
    status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, cDatumPointName));
    ruleLog.Write("ProElementWstringSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_type{};
    status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
    ruleLog.Write("ProElementIntegerSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement pro_e_dpoint_ofst_csys_type{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
    ruleLog.Write("ProElementIntegerSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_ref{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    ProReference REPDEP_ref1{};
    status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
    ruleLog.Write("ProSelectionToReference: " + to_string(status));

    status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
    ruleLog.Write("ProElementReferenceSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_with_dims{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
    ruleLog.Write("ProElementIntegerSet: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_pnts_array{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_pnt_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_pnt_name_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    wchar_t wide_string[PRO_NAME_SIZE]{};
    ProStringToWstring(wide_string, "datum_PNT1");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
    ruleLog.Write("ProElementWstringSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_dir1_val_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement pro_e_dpoint_ofst_csys_dir2_val_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    double d1 = -pnt_arr[0][2];
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_dir3_val_1{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_pnt_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement pro_e_dpoint_ofst_csys_pnt_name_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    wchar_t wide_string_2[PRO_PATH_SIZE]{};
    ProStringToWstring(wide_string_2, "datum_PNT2");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
    ruleLog.Write("ProElementWstringSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_dir1_val_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement	pro_e_dpoint_ofst_csys_dir2_val_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    double d2 = -pnt_arr[1][2];
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProElement pro_e_dpoint_ofst_csys_dir3_val_2{};
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
    ruleLog.Write("ProElementAlloc: " + to_string(status));

    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
    ruleLog.Write("ProElementDecimalsSet: " + to_string(status));

    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
    ruleLog.Write("ProElementDoubleSet: " + to_string(status));

    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);
    ruleLog.Write("ProElemtreeElementAdd: " + to_string(status));

    ProSelection reqMdlSel{};
    status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    ProFeatureCreateOptions* opts = 0;
    status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
    ruleLog.Write("ProArrayAlloc: " + to_string(status));

    ProFeature pnt_feat{};
    opts[0] = PRO_FEAT_CR_NO_OPTS;
    ProErrorlist errors{};
    status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
    ruleLog.Write("ProFeatureWithoptionsCreate: " + to_string(status));

    status = ProArrayFree((ProArray*)&opts);
    ruleLog.Write("ProArrayFree: " + to_string(status));

    status = ProElementFree(&elem_tree);
    ruleLog.Write("ProElementFree: " + to_string(status));

    status = ProSelectionFree(&reqMdlSel);
    ruleLog.Write("ProSelectionFree: " + to_string(status));

    ProSelection pnt_Sel{};
    status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
    ruleLog.Write("ProSelectionAlloc: " + to_string(status));

    SelectionhighliteVector_IR_F5A03_005.push_back(pnt_Sel);
    return PRO_TK_NO_ERROR;
}

ProError ruleDlgOKaction_IR_F5A03_005(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgOKaction_IR_F5A03_005 -----------------------------");

    int curWinId1{};
    status = ProWindowCurrentGet(&curWinId1);
    ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

    status = ProWindowRepaint(curWinId1);
    ruleLog.Write("ProWindowRepaint: " + to_string(status));

    deleteDatumPointCreatedUsingCsys_IR_F5A03_005("datum_PNT1");
    deleteDatumPointCreatedUsingCsys_IR_F5A03_005("datum_PNT2");

    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return PRO_TK_NO_ERROR;
}

ProError ruleDlgCloseAction_IR_F5A03_005(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgCloseAction_IR_F5A03_005 -----------------------------");

    int curWinId2{};
    status = ProWindowCurrentGet(&curWinId2);
    ruleLog.Write("ProWindowCurrentGet: " + to_string(status));

    status = ProWindowRepaint(curWinId2);
    ruleLog.Write("ProWindowRepaint: " + to_string(status));

    deleteDatumPointCreatedUsingCsys_IR_F5A03_005("datum_PNT1");
    deleteDatumPointCreatedUsingCsys_IR_F5A03_005("datum_PNT2");

    if (data != NULL) {
        bool* quitAction = (bool*)data;
        *quitAction = true;
    }
    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return status;
}

ProError deleteDatumPointCreatedUsingCsys_IR_F5A03_005(char* dtmpoint_name)
{
    ruleLog.Write("----------------------------- deleteDatumPointCreatedUsingCsys_IR_F5A03_005 -----------------------------");

    ProIdTable idtbl1{};
    ProAsmcomppath path{};
    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path);
    ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

    wchar_t wdatum_pt[PRO_PATH_SIZE]{};
    ProStringToWstring(wdatum_pt, dtmpoint_name);
    ProModelitem mdl_item{};
    status = ProModelitemByNameInit(curMdl, PRO_POINT, wdatum_pt, &mdl_item);
    ruleLog.Write("ProModelitemByNameInit: " + to_string(status));

    if (status == PRO_TK_NO_ERROR) {

        int* feat_ids = NULL;
        status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
        ruleLog.Write("ProArrayAlloc: " + to_string(status));

        ProFeature feat{};
        status = ProGeomitemFeatureGet((ProGeomitem*)&mdl_item, &feat);
        ruleLog.Write("ProGeomitemFeatureGet: " + to_string(status));
        feat_ids[0] = feat.id;

        ProFeatureDeleteOptions* delete_opts = 0;
        status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
        ruleLog.Write("ProArrayAlloc: " + to_string(status));

        delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;
        status = ProFeatureWithoptionsDelete((ProSolid)curMdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
        ruleLog.Write("ProFeatureWithoptionsDelete: " + to_string(status));

        status = ProArrayFree((ProArray*)&delete_opts);
        ruleLog.Write("ProArrayFree: " + to_string(status));

        status = ProArrayFree((ProArray*)&feat_ids);
        ruleLog.Write("ProArrayFree: " + to_string(status));

    }

    return PRO_TK_NO_ERROR;
}