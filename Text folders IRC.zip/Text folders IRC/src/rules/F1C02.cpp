/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 07-06-2023	|	V1_0_0		| F1C02 - PNEUMATIC SYSTEMS RULE
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#include "F1C02.h"

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF1C02001      | Atharva Patil		| MF1C02			|  Use of standard hardware for clamping hoses & pipes.
===================================================================================================================*/
#define DLG_IRF1C02_001 "dlg_IR_F1C02_001"
#define PB_ROK			"CommitOK"
#define PB_RCANCEL		"CommitCancel"

int IRF1C02::IRF1C02_001(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF1C02::IRF1C02_001   ==========================");

    string                     remarkMsg{};
    double                     stdGradeBolt = 8.8;
    double                     stdGradeNut = 8.0;
    vector<HardwareInfo>       _hwInfo;
    vector<HardwareInfo>       _nonStdHwInfo;
    string                     typeOfHw;
    typeOfHw = "NUT";

    //Clearing the vectors for fresh run
    _hwInfo.clear();
    _nonStdHwInfo.clear();

    isUserQuits = false;
    status = ProUIDialogCreate(DLG_IRF1C02_001, DLG_IRF1C02_001);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF1C02_001, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF1C02_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF1C02_001, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF1C02_001, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF1C02_001);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    status = ProSolidFeatVisit((ProSolid)curMdl, (ProFeatureVisitAction)visit11DigitComponents, compsFilter, &_hwInfo);
    ruleLog.Write(to_string(_hwInfo.size()));
    ProAsmcomppath             path;
    ProSelection               selection;

    for (int i = 0; i < _hwInfo.size(); i++)
    {
        if (((_hwInfo.at(i).typeOfHw == typeOfHw) && (_hwInfo.at(i).gradeDb < stdGradeNut)) ||
            ((_hwInfo.at(i).typeOfHw != typeOfHw) && (_hwInfo.at(i).gradeDb < stdGradeBolt)))
        {
            _nonStdHwInfo.push_back(_hwInfo.at(i));
            status = ProAsmcomppathInit((ProSolid)curMdl, &_hwInfo.at(i).ID, 1, &path);
            ruleLog.Write("ProAsmcomppathInit : " + to_string(status));
            status = ProSelectionAlloc(&path, &_hwInfo.at(i).Item, &selection);
            ruleLog.Write("ProSelectionAlloc : " + to_string(status));
            status = ProSelectionHighlight(selection, PRO_COLOR_HIGHLITE);
            ruleLog.Write("ProSelectionHighlight : " + to_string(status));
        }
    }

    //Write the remarks
    if ((_nonStdHwInfo.size() == 0) && (_hwInfo.size() != 0))
    {
        remarkMsg += "All the fasteners used in the model are of standard grade.";
        ruleLog.Write("All the fasteners used in the model are of standard grade.");
    }
    if (_hwInfo.size() == 0)
    {
        remarkMsg += "There are no fasteners present in the model, hence the rule is passed.";
        ruleLog.Write("There are no fasteners present in the model\n");
        ruleLog.Write("Hence the rule is passed.");

    }
    if (_nonStdHwInfo.size() != 0)
    {
        remarkMsg += "List of hardware part numbers of non standard grade\n";
        vector<double>      uniqueGradeList;
        vector<string>      partsOfSpecificGrade;
        uniqueGradeList.clear();

        //Create a grade list with non repeating values
        for (int i = 0; i < _nonStdHwInfo.size(); i++)
        {
            uniqueGradeList.push_back(_nonStdHwInfo.at(i).gradeDb);
            sort(uniqueGradeList.begin(), uniqueGradeList.end(), [](double a, double b) {
                return a > b; // Compare in descending order
                });
            auto last = unique(uniqueGradeList.begin(), uniqueGradeList.end());
            uniqueGradeList.erase(last, uniqueGradeList.end());
        }

        //create a vector of part names having a specific grade
        for (int i = 0; i < uniqueGradeList.size(); i++)
        {
            partsOfSpecificGrade.clear();
            double target = uniqueGradeList.at(i);
            remarkMsg += "\nGrade ";
            double rounded1 = round(target * 10) / 10;
            string t = to_string(rounded1);
            t.erase(t.find_last_not_of('0') + 1, string::npos);
            remarkMsg += t;
            remarkMsg += "-\n";

            for (int j = 0; j < _nonStdHwInfo.size(); j++)
            {
                if (target == _nonStdHwInfo.at(j).gradeDb)
                {
                    partsOfSpecificGrade.push_back(_nonStdHwInfo.at(j).compName);
                }
            }
            //Count the repetitions of a part
            map<string, int> elementCount;
            for (const auto& part : partsOfSpecificGrade)
            {
                elementCount[part]++;
            }
            for (const auto& entry : elementCount)
            {
                remarkMsg += entry.first;
                remarkMsg += ".PRT(";
                remarkMsg += to_string(entry.second);
                remarkMsg += "), ";
            }
            elementCount.clear();
        }
    }
    double rounded = round(stdGradeBolt * 10) / 10;
    string outputStdGrd = to_string(rounded);
    outputStdGrd.erase(outputStdGrd.find_last_not_of('0') + 1, string::npos);
    remarkMsg += "\nAcceptance Criteria = Grade ";
    remarkMsg += outputStdGrd;
    remarkMsg += " or above";

    //Declare result
    if ((_hwInfo.size() == 0) || (_nonStdHwInfo.size() == 0))
    {
        final_res.result = "PASS";
        final_res.remark = remarkMsg;
        ruleLog.Write("Status = " + final_res.result);
    }
    else
    {
        final_res.result = "FAIL";
        final_res.remark = remarkMsg;
        ruleLog.Write("Status = " + final_res.result);
        ruleLog.Write("Reason : ");
        ruleLog.Write("Non standard hardware used in the model");
    }
    ruleLog.Write(remarkMsg);
    return 0;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES					                | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F1C02-004	| Ved Aiyar     	| MF1C02; MF3B01; MF3B06; MF3B05	| Minimum clearance of 200 mm from manifolds, exhaust pipes, silencers &  catalytic mufflers (indicated distances can be less in presence of an appropriate heat projection/shield on the pipe line.
===================================================================================================================*/
#define DLG_F1C02_004   "dlg_IR_F1C02_004"
#define PB_ROK			"CommitOK"
#define PB_RCANCEL		"CommitCancel"
#define SUB_MODULE_DIST "select_option_menu"
#define PB_RIMG		    "rule_img"
#define PB_SELECT		"select_pb" 


//string Selected_Part = "";
ComponentData _reqCompsf1c02[5]{};
ProSelection* self1c02;
ProSelection selaf1c02;
ProSelection self1c02all;
int count_sel = 0, once = 1;
vector<string> selection_partsf1c02;
int n_self1c02;
string remf1c02 = "Distance Measured from ";
double standardf1c02 = 200;

int IRF1C02::IRF1C02_004(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF1C02::IRF1C02_004   ==========================");



    //vector<string> optionMenuPartList = {"TIPPING PIPING" , "INTERAXLE AND DIFFLOCK PIPING" , "SILENCER ASSY" , "EXHAUST PIPE ASSY AND MOUNTING" , "TAIL PIPE ASSY AND MOUNTING"};
    vector<string> optionMenuPartList = { "Select" , "TIPPING PIPING" , "INTERAXLE" , "SILENCER ASSY" , "EXHAUST" , "TAIL" };

    string reqCompSubMod[5] = { "F1C02","F1C03","F3B01","F3B05","F3B06" };
    string comp_names[5];
    double clearance_vals;
    isUserQuits = false;

    for (int i = 0; i < subModulesList.size(); ++i)
    {
        for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j)
        {
            if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
            {
                strcpy(_reqCompsf1c02[j].name, subModulesList[i].name.c_str());
                comp_names[j] = subModulesList[i].name;
            }
        }
    }

    status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqCompsf1c02);

    for (auto elem : _reqCompsf1c02)
    {
        ruleLog.Write("_reqComps[].name = " + string(elem.name));
        ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
    }



    status = ProUIDialogCreate(DLG_F1C02_004, DLG_F1C02_004);
    ruleLog.Write("ProUIDialogCreate: " + to_string(status));
    status = ProUIDialogAboveactivewindowSet(DLG_F1C02_004, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_F1C02_004, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);

    status = ProUIPushbuttonDisable(DLG_F1C02_004, PB_ROK);
    status = ProUIPushbuttonHide(DLG_F1C02_004, PB_RIMG);
    status = ProUIPushbuttonDisable(DLG_F1C02_004, PB_SELECT);


    string optionMenuActionData[2] = { PB_RIMG, "IR_F1C02_004" };
    status = ProUIOptionmenuSelectActionSet(DLG_F1C02_004, SUB_MODULE_DIST, (ProUIAction)optionMenuImageChangeActionf1c02, (ProAppData)&optionMenuActionData);





    char** springtypeListNames;
    wchar_t** springtypeListLabels;
    status = ProArrayAlloc(optionMenuPartList.size(), sizeof(char*), 1, (ProArray*)&springtypeListNames);
    status = ProArrayAlloc(optionMenuPartList.size(), sizeof(wchar_t*), 1, (ProArray*)&springtypeListLabels);

    for (int i = 0; i < optionMenuPartList.size(); ++i)
    {
        springtypeListNames[i] = (char*)calloc(PRO_NAME_SIZE, sizeof(char));
        ProTKSprintf(springtypeListNames[i], "%s", optionMenuPartList[i]);

        springtypeListLabels[i] = (wchar_t*)calloc(PRO_NAME_SIZE, sizeof(wchar_t));
        ProStringToWstring(springtypeListLabels[i], springtypeListNames[i]);
    }
    status = ProUIOptionmenuNamesSet(DLG_F1C02_004, SUB_MODULE_DIST, int(optionMenuPartList.size()), springtypeListNames);
    ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
    status = ProUIOptionmenuLabelsSet(DLG_F1C02_004, SUB_MODULE_DIST, int(optionMenuPartList.size()), springtypeListLabels);
    ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

    status = ProArrayFree((ProArray*)&springtypeListNames);
    status = ProArrayFree((ProArray*)&springtypeListLabels);

    status = ProUIPushbuttonBitmapSet(DLG_F1C02_004, PB_RIMG, "IR_F1C02_004/blank.png");// default image
    ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));

    //optionMenuPartList.clear();
    status = ProUIPushbuttonActivateActionSet(DLG_F1C02_004, PB_SELECT, (ProUIAction)select_action_IR_F1C02_004, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_F1C02_004, PB_ROK, (ProUIAction)ruleDlgOKactionf1c02, NULL);




    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_F1C02_004, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_F1C02_004);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)	// check for user quits in close_action
        return -1;


    isRightValue = false;

    if (remf1c02.find("FAIL") != std::string::npos)
    {
        isRightValue = false;
    }
    else
    {
        isRightValue = true;
    }

    remf1c02.append("\nAcceptance criteria : >= 200mm");

    final_res.remark = remf1c02;

    // DECLARE RESULT
    if (isRightValue)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: \n" + final_res.remark);

    remf1c02.clear();

    return 0;
}

ProError optionMenuImageChangeActionf1c02(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- optionMenuImageChangeAction -----------------------------");

    string* reqData = (string*)data;
    int n_sel;
    char** selValue;
    string blank = "Select";
    status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
    ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
    ruleLog.Write("selValue = " + string(selValue[0]));

    if ((string(selValue[0])).compare(blank) == 0)
    {
        status = ProUIPushbuttonHide(dialog, PB_RIMG);
        status = ProUIPushbuttonDisable(dialog, PB_ROK);
        status = ProUIPushbuttonDisable(dialog, PB_SELECT);
        ruleLog.Write("Blank selected");
    }
    else
    {
        //status = ProUIPushbuttonEnable(dialog, PB_ROK);
        status = ProUIPushbuttonEnable(dialog, PB_SELECT);
        ProUIPushbuttonShow(dialog, PB_RIMG);
        char imgName[PRO_NAME_SIZE], cPbName[PRO_NAME_SIZE];
        ProTKSprintf(imgName, "%s/%s.png", reqData[1], selValue[0]);
        strcpy(cPbName, reqData[0].c_str());
        status = ProUIPushbuttonBitmapSet(dialog, cPbName, imgName);
        ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));
    }
    return PRO_TK_NO_ERROR;
}

ProError select_action_IR_F1C02_004(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("--------------------------  select_action_IR_F1C02_004  --------------------------");
    status = ProUIDialogHide(dialog);
    ruleLog.Write("ProUIDialogHide status = " + to_string(status));

    ProModelitem annotelem;
    char nameofsel[PRO_NAME_SIZE];
    ProMdl mdl;
    wchar_t model;

    status = ProSelect((char*)"part", -1, NULL, NULL, NULL, NULL, &self1c02, &n_self1c02);
    ruleLog.Write("Proselect status = " + to_string(status));
    ruleLog.Write("Number of selections = " + to_string(n_self1c02));

    for (int i = 0; i < n_self1c02; i++)
    {
        status = ProSelectionCopy(self1c02[i], &self1c02all);
        ruleLog.Write("ProSelectionCopy status = " + to_string(status));
        count_sel++;
    }

    status = ProUIDialogShow(dialog);
    ruleLog.Write("ProUIDialogShow status = " + to_string(status));


    for (int i = 0; i < n_self1c02; i++)
    {
        status = ProSelectionModelitemGet(self1c02[i], &annotelem);
        ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

        status = ProModelitemMdlGet(&annotelem, &mdl);
        ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

        status = ProMdlMdlnameGet(mdl, &model);
        ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

        ProWstringToString(nameofsel, &model);
        std::string models(nameofsel);

        selection_partsf1c02.push_back(models);
    }

    if (once == 1)
    {
        //Find air tank assembly from _reqCompsf2d03
        for (int i = 0; i < sizeof(_reqCompsf1c02) / sizeof(_reqCompsf1c02[0]); i++)
        {
            string sub = "F1C02";
            string s = _reqCompsf1c02[i].name;
            for (char& c : s)
            {
                c = std::toupper(c);
            }
            size_t found3 = s.find(sub);

            if (found3 != std::string::npos)//If air tank assembly is found, then allocate it to selection array.
            {
                ruleLog.Write(s);
                remf1c02.append(s + ".asm to:\n\n");
                ProMdl reqMdlsair;
                ProName compair;
                ProModelitem featureair;
                ProStringToWstring(compair, _reqCompsf1c02[i].name);
                status = ProMdlnameInit(compair, PRO_MDLFILE_ASSEMBLY, &reqMdlsair);
                status = ProMdlToModelitem(reqMdlsair, &featureair);

                ProAsmcomppath pathair;
                ProIdTable idtblair = { _reqCompsf1c02[i].id };
                status = ProAsmcomppathInit((ProSolid)curMdl, idtblair, 1, &pathair);
                ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));

                status = ProSelectionAlloc(&pathair, &featureair, &selaf1c02);
                ruleLog.Write("ProSelectionAlloc status = " + to_string(status));

                break;
            }
        }
        once++;
    }



    status = ProUIPushbuttonEnable(dialog, PB_ROK);

    return PRO_TK_NO_ERROR;

}

ProError ruleDlgOKactionf1c02(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgOKaction -----------------------------");

    for (int j = 0; j < count_sel; j++)
    {
        ruleLog.Write("check");
        double param[2];
        double pnt[2];
        double distance1;
        ruleLog.Write("check1");
        status = ProSelectionWithOptionsDistanceEval(selaf1c02, PRO_B_TRUE, self1c02all, PRO_B_TRUE, &param[0], &param[1], &pnt[0], &pnt[1], &distance1);
        ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));

        if (distance1 < standardf1c02)
        {
            remf1c02.append("- " + selection_partsf1c02[j] + ".prt = " + doubleToString(distance1) + "mm [FAIL]\n");
        }
        else
        {
            remf1c02.append("- " + selection_partsf1c02[j] + ".prt = " + doubleToString(distance1) + "mm [PASS]\n");
        }
    }

    selection_partsf1c02.clear();

    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES					        | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F1C02-006	| Himanshu Pachpute	| MF1C02; MF1C03; MF1C04; MF1A01; MF5A20	| Minimum one clamps to provided in distance of 1.5m to hold the pipe on frame.
===================================================================================================================*/
#define DLG_F1C02_006  "dlg_IR_F1C02_006" 
#define PB_RCANCEL     "rule_cancel_pb" 
#define PB_ROK         "rule_ok_pb"

struct SelectionInfo {
    ProSelection    p_selection{};
    string          Description{};
    char            Name[PRO_PATH_SIZE]{};
    int             id{};
};

vector<SelectionInfo>		ClampSelectionInfo{};
vector<feat_id_data>		FeatIDDataArr{};
Asm_model					AsmCModel[1000]{}, CModel[1000]{};
int							ModelsCount{}, AsmModelCount{}, NoOfAsmFixed{}, MdlCount{}, OwnerFeatID{}, Levels{};
FILE* Valuefile;

int IRF1C02::IRF1C02_006(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF1C02::IRF1C02_006   ==========================");

    status = ProUIDialogCreate(DLG_F1C02_006, DLG_F1C02_006);
    status = ProUIDialogAboveactivewindowSet(DLG_F1C02_006, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_F1C02_006, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_F1C02_006, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_F1C02_006, &dlg_sts);
    status = ProUIDialogDestroy(DLG_F1C02_006);
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    ProMdl Mdl{};
    status = ProMdlCurrentGet(&Mdl);
    ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

    ProPath modelFullPath = { 0 };
    status = ProMdlOriginGet(Mdl, modelFullPath);
    ruleLog.Write("ProMdlOriginGet: " + to_string(status));
    char PathName[PRO_PATH_SIZE]{};
    ProWstringToString(PathName, modelFullPath);
    ruleLog.Write("modelFullPath: " + string(PathName));

    string outputPath;
    for (char c : string(PathName)) {
        if (c == '\\')
            outputPath += "\\\\";
        else
            outputPath += c;
    }

    size_t lastBackslash = outputPath.rfind("\\");
    if (lastBackslash != string::npos)
        outputPath = outputPath.substr(0, lastBackslash + 1) + "Indentified_Clamps_and_Brackets.txt";

    char charArray[PRO_PATH_SIZE];
    strcpy(charArray, outputPath.c_str());
    ruleLog.Write(string(charArray));
    Valuefile = fopen(charArray, "w");

    curMdl = Mdl;
    Levels = 1;
    NoOfAsmFixed = 0;
    CModel[0].Model = Mdl;
    CModel[0].Model_feat_id = 0;
    ModelsCount = 1;
    AsmModelCount = 0;

    fprintf(Valuefile,
        "\nNote: Please be advised that the content provided is intended solely for temporary viewing purposes."
        "\n========================================================================>>"
        "\nAll Clamps and Brackets identified in the current assembly."
        "\n------------------------------------------------------------------------>>\n\n");
    fflush(Valuefile);

    while (ModelsCount > 0) {
        for (int a = 0; a < ModelsCount; ++a) {
            OwnerFeatID = CModel[a].Model_feat_id;
            status = ProSolidFeatVisit((ProSolid)CModel[a].Model, (ProFeatureVisitAction)PartNameAndIdVisitAction, compsFilter, NULL);
            ruleLog.Write("ProSolidFeatVisit: " + to_string(status));
        }

        if (AsmModelCount > 0) {
            ++Levels;
            for (int b = 0; b < AsmModelCount; ++b) {
                CModel[b].Model = AsmCModel[b].Model;
                CModel[b].Model_feat_id = AsmCModel[b].Model_feat_id;
            }
            ModelsCount = AsmModelCount;
            AsmModelCount = 0;
        }
        else
            ModelsCount = 0;
    }

    Pro2dPnt        param_1, param_2;
    Pro3dPnt        pnt_1, pnt_2;
    double          distance{};
    vector<bool>    ClampSelectionConditionVect{};

    string msg1{};
    string msg2{};
    string msg3 = "Every Clamp/Bracket has atleast one Clamp/Bracket present in the radius of 1.50m.";
    string msg4{};
    string msg5 = "No Clamps/Brackets found within the 1.50m radius of\n";

    fprintf(Valuefile,
        "\n============================================================================>>"
        "\nClamps/Brackets found in the radius of 1.50m of respective Clamps/Brackets."
        "\n---------------------------------------------------------------------------->>\n\n");
    fflush(Valuefile);

    for (int j = 0; j < ClampSelectionInfo.size(); j++) {
        string firstElement = "(" + string(ClampSelectionInfo[j].Name) + ") " + ClampSelectionInfo[j].Description + " (" + to_string(ClampSelectionInfo[j].id) + ")";
        string message = "\t" + firstElement + " and\n";
        string message2 = "\t" + firstElement + " and\n";
        bool conditioncheck1{ false };

        for (int k = 0; k < ClampSelectionInfo.size(); k++) {
            status = ProSelectionWithOptionsDistanceEval(ClampSelectionInfo[j].p_selection, PRO_B_TRUE, ClampSelectionInfo[k].p_selection, PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance);
            ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status));

            string secondElement = "(" + string(ClampSelectionInfo[k].Name) + ") " + ClampSelectionInfo[k].Description + " (" + to_string(ClampSelectionInfo[k].id) + ")";

            string formattedDistance = doubleToString(distance);
            message2 += "\t\t\t" + secondElement + ": " + formattedDistance + "\n";

            if (distance < 1500 && firstElement != secondElement) {
                conditioncheck1 = true;
                message += "\t\t\t" + secondElement + ": " + formattedDistance + "\n";
            }
        }

        ClampSelectionConditionVect.push_back(conditioncheck1);
        if (message != "\t" + firstElement + " and\n") {
            //msg1 += message + "\n";
            msg4 += message + "\n";
        }

        if (message2 != "\t" + firstElement + " and\n")
            msg2 += message2 + "\n";

        if (conditioncheck1 == false) {
            msg5 += "\t" + firstElement + "\n";
            msg1 = msg5;
            msg4 += message + "\t\tNo Clamps/Brackets found within the 1.50m radius.\n\n";
            status = ProSelectionHighlight(ClampSelectionInfo[j].p_selection, PRO_COLOR_SS_FAILED_ITEMS);
            ruleLog.Write("ProSelectionHighlight: " + to_string(status));
        }
    }

    fprintf(Valuefile, "\n%s\n", msg4.c_str());
    fflush(Valuefile);

    ClampSelectionConditionVect.pop_back();

    bool conditioncheck2{ false };
    for (int v = 0; v < ClampSelectionConditionVect.size(); v++) {
        ruleLog.Write("Identifying the point of Failure: " + to_string(ClampSelectionConditionVect[v]));
        if (ClampSelectionConditionVect[v] != ClampSelectionConditionVect[0]) {
            conditioncheck2 = true;
            break;
        }
    }

    if (msg1.empty())
        final_res.remark = msg3 + "\nAcceptance Criteria: Minimum one clamp/bracket needs to be present in the radius of 1.50m of each clamp/bracket" + "\n\nFor more details open-- > \n'" + string(charArray) + "'";
    else {
        msg1 += "Acceptance Criteria: Minimum one clamp/bracket needs to be present in the radius of 1.50m of each clamp/bracket\n\nFor more details open -->\n'" + string(charArray) + "'";
        final_res.remark = msg1;
    }

    wchar_t wname[PRO_PATH_SIZE];
    ProStringToWstring(wname, charArray);
    //status = ProInfoWindowDisplay(wname, NULL, NULL);
    //ruleLog.Write("ProInfoWindowDisplay: " + to_string(status));

    if (conditioncheck2 == false)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    ruleLog.Write("\nstatus: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    ClampSelectionInfo.clear();
    FeatIDDataArr.clear();
    ClampSelectionConditionVect.clear();
    memset(&CModel, 0, sizeof(CModel));
    memset(&AsmCModel, 0, sizeof(AsmCModel));

    fclose(Valuefile);

    return 0;
}

ProError PartNameAndIdVisitAction(ProFeature* p_feature, ProError status, ProAppData app_data)
{
    //ruleLog.Write("----------------------------- PartNameAndIdVisitAction -----------------------------");

    SelectionInfo ClampSelection;
    //ruleLog.Write("Component Levels: " + to_string(Levels));

    ProMdlfileType    comp_type;
    ProFamilyMdlName  comp_name;
    status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
    //ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));

    char part_no[PRO_PATH_SIZE]{};
    ProWstringToString(part_no, comp_name);
    //ruleLog.Write("ProMdlName: " + string(part_no));

    ++MdlCount;

    ProMdl model;
    status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
    //ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));

    ProMdlType type;
    status = ProMdlTypeGet(model, &type);
    //ruleLog.Write("ProMdlTypeGet:" + to_string(status));

    wchar_t wFeatName[PRO_NAME_SIZE]{};
    status = ProMdlMdlnameGet(model, wFeatName);
    //ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
    ProWstringToString(ClampSelection.Name, wFeatName);

    ProModelitem modelItem;
    status = ProMdlToModelitem(model, &modelItem);
    //ruleLog.Write("ProMdlToModelitem: " + to_string(status));

    ProName      pDescName = L"DESCRIPTION";
    ProParameter pDesc;
    status = ProParameterInit(&modelItem, pDescName, &pDesc);
    //ruleLog.Write("ProParameterInit: " + to_string(status));

    ProParamvalue pvDesc;
    status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
    //ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));

    char existingPval[PRO_PATH_SIZE]{};
    ProWstringToString(existingPval, pvDesc.value.s_val);

    ClampSelection.id = p_feature->id;

    feat_id_data  _FeatIDdata;
    if (Levels == 1) {
        _FeatIDdata.feat_ids[0] = p_feature->id;
        _FeatIDdata.level = Levels;
        FeatIDDataArr.push_back(_FeatIDdata);
    }
    else {
        for (int j = 0; j < FeatIDDataArr.size(); ++j) {
            if (FeatIDDataArr[j].feat_ids[Levels - 2] == OwnerFeatID) {
                feat_id_data	owner_feat_id_data = FeatIDDataArr[j];
                for (int i = 0; i < Levels - 1; ++i) {
                    _FeatIDdata.feat_ids[i] = owner_feat_id_data.feat_ids[i];
                }
                _FeatIDdata.feat_ids[Levels - 1] = p_feature->id;
                _FeatIDdata.level = Levels;
                break;
            }
        }
        FeatIDDataArr.push_back(_FeatIDdata);
    }

    string  searchStrings[] = { "CLAMP", "BRACKET", "BRKT", "BKT" };
    bool    compfound{ false };

    for (const string& searchString : searchStrings) {
        regex pattern("\\b" + searchString + "\\b");
        if (regex_search(existingPval, pattern)) {
            compfound = true;
            //ruleLog.Write("========================================================");
            //ruleLog.Write("PartNameAndIdVisitAction Level: " + to_string(Levels));
            ruleLog.Write("Clamp Found: Level " + to_string(Levels) + " (" + string(existingPval) + ") (" + ClampSelection.Name + ") " + to_string(ClampSelection.id));
            fprintf(Valuefile, "\t\t(%s) \t(%s) \t%d\n", ClampSelection.Name, existingPval, ClampSelection.id);
            fflush(Valuefile);

            ProIdTable			comp_id_table;
            int					table_num;
            ProAsmcomppath		p_comp_path;
            ProModelitem		p_modelitem;

            table_num = Levels;

            //ruleLog.Write("table_num: " + to_string(table_num));

            for (int m = 0; m < Levels; ++m) {
                comp_id_table[m] = _FeatIDdata.feat_ids[m];
                //ruleLog.Write("comp_id_table[]: " + to_string(m) + " " + to_string(comp_id_table[m]));
            }

            status = ProMdlToModelitem(model, &p_modelitem);
            //ruleLog.Write("ProMdlToModelitem: " + to_string(status));

            ProMdl curMdl;
            status = ProMdlCurrentGet(&curMdl);
            //ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

            status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
            //ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

            ProSelection p_selection;
            status = ProSelectionAlloc(&p_comp_path, &p_modelitem, &ClampSelection.p_selection);
            //ruleLog.Write("ProSelectionAlloc: " + to_string(status));

            if (status == PRO_TK_NO_ERROR) {
                ClampSelection.Description = existingPval;
                ClampSelectionInfo.push_back(ClampSelection);

                /*status = ProSelectionHighlight(p_selection, PRO_COLOR_SELECTED);
                ruleLog.Write("ProSelectionHighlight: " + to_string(status));*/
            }

        }
    }
    ruleLog.Write("========================================================");

    if (type == PRO_MDL_ASSEMBLY && compfound == false)
    {
        AsmCModel[AsmModelCount].Model = model;
        AsmCModel[AsmModelCount].Model_feat_id = p_feature->id;
        AsmModelCount += 1;
    }

    return PRO_TK_NO_ERROR;
}
#pragma pop