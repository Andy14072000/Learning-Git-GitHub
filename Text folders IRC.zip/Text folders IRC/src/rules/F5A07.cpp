/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 20-07-2023	|	V1_0_0		| F5A07 - BRAKING SYSTEM RULES
==================================================================================================================*/
#include "F5A07.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
IRF5A07002		| BRAKING SYSTEM	| output_clearance_vals of Air tank with surrounding static parts should be 25 mm minimum.
===================================================================================================================*/
#define DLG_F5A07_002	"dlg_IR_F5A07_002"
#define SELECT_PARTS_PB "select_pb"
#define MEASURE_PART_PB	"measure_pb"

// GLOBAL ENTITIES
double					output_clearance_vals[7];
ProSelection			store[3];
ComponentData			reqComps_f5a07_002[8]{};	// F5A07, F1A04, F5B03, A1B05, F5A11
int						rule_sts;
ProAsmcomppath	        part_asmcomp_path[8];


int IRF5A07::IRF5A07_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5A07::IRF5A07_002   ==========================");

	string reqCompSubModAuto[8] = { "F5A07",  "F1A04", "F5B03" , "A1B05" , "F5A11", "F1A01", "A1A01", "A1B01" };	// F1A01, A1A01, A1B01 will be selected manually
	for (int i = 0; i < subModulesList.size(); ++i) {
		for (int j = 0; j < sizeof(reqCompSubModAuto) / sizeof(reqCompSubModAuto[0]); ++j) {
			if (subModulesList[i].name.find(reqCompSubModAuto[j]) != string::npos) {
				strcpy(reqComps_f5a07_002[j].name, subModulesList[i].name.c_str());
			}
		}
	}
	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&reqComps_f5a07_002);
	for (auto elem : reqComps_f5a07_002) {
		ruleLog.Write("reqComps_f5a07_002[].name = " + string(elem.name));
		ruleLog.Write("reqComps_f5a07_002[].id = " + to_string(elem.id));
	}

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_F5A07_002, DLG_F5A07_002);
	status = ProUIDialogAboveactivewindowSet(DLG_F5A07_002, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_F5A07_002, RULE_UI_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F5A07_002, RULE_UI_OK, (ProUIAction)ruleDlgOKaction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F5A07_002, SELECT_PARTS_PB, (ProUIAction)select_action_IRF5A07_002, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F5A07_002, MEASURE_PART_PB, (ProUIAction)Measure_action_IRF5A07_002, (ProAppData)&isUserQuits);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_F5A07_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_F5A07_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	//// Clearance between components (automatic)
	//rule_sts = measureDistanceBetweenComponents(reqComps_f5a07_002[0], reqComps_f5a07_002[1], output_clearance_vals[0]); // F1A04
	//rule_sts = measureDistanceBetweenComponents(reqComps_f5a07_002[0], reqComps_f5a07_002[2], output_clearance_vals[1]); // F5B03
	//rule_sts = measureDistanceBetweenComponents(reqComps_f5a07_002[0], reqComps_f5a07_002[3], output_clearance_vals[2]); // A1B05
	//rule_sts = measureDistanceBetweenComponents(reqComps_f5a07_002[0], reqComps_f5a07_002[4], output_clearance_vals[3]); // F5A11

	// rounding the values to one decimal place
	for (int i = 0; i < sizeof(output_clearance_vals) / sizeof(output_clearance_vals[0]); ++i)
		output_clearance_vals[i] = round(output_clearance_vals[i] * 10) / 10;

	//DECLARE RESULT
	double acceptedClearance = 25.0;
	sprintf(remark, "Clearance between F5A07 and \n-F1A01: %0.1fmm \n-F1A04: %0.1fmm \n-F5B03: %0.1fmm \n-A1A01: %0.1fmm \n-A1B01: %0.1fmm \n-A1B05: %0.1fmm \n-F5A11: %0.1fmm;\n\nAcceptance criteria: > 25mm.", output_clearance_vals[4], output_clearance_vals[0], output_clearance_vals[1], output_clearance_vals[5], output_clearance_vals[6], output_clearance_vals[2], output_clearance_vals[3]);
	final_res.remark = string(remark);

	if ((output_clearance_vals[0] >= acceptedClearance) && (output_clearance_vals[1] >= acceptedClearance) && (output_clearance_vals[2] >= acceptedClearance) && (output_clearance_vals[3] >= acceptedClearance) && (output_clearance_vals[4] >= acceptedClearance) && (output_clearance_vals[5] >= acceptedClearance) && (output_clearance_vals[6] >= acceptedClearance))

		final_res.result = "PASS";

	final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	return 0;
}

ProError select_action_IRF5A07_002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRF5A07_002  --------------------------");

	int	n_sels;
	ProSelection* part_sel;
	InterfaceRule _irule;
	bool* quitAction = (bool*)data;
	string reqCompSubModManual[3] = { "F1A01", "A1A01", "A1B01" };

	int curWinId;
	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);
	status = ProSelectionFree(&store[3]);
	status = ProUIPushbuttonDisable(DLG_F5A07_002, MEASURE_PART_PB);

	for (int i = 0; i < sizeof(reqCompSubModManual) / sizeof(reqCompSubModManual[0]); ++i)
	{
		bool validInput = false;
		while (!validInput)	// looping until receiving the valid input part.
		{
			ProMdl	parent_mdl;
			char cParentMdlName[PRO_NAME_SIZE];
			wchar_t wParentMdlName[PRO_NAME_SIZE];
			bool isSelectionRight = NULL;

			status = ProSelect((char*)"prt_or_asm", 1, NULL, NULL, NULL, NULL, &part_sel, &n_sels);
			ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels));

			if (status == PRO_TK_USER_ABORT) {
				status = ProSelectionarrayFree(store);
				ProWindowCurrentGet(&curWinId);
				ProWindowRepaint(curWinId);
				status = ProUIPushbuttonDisable(DLG_F5A07_002, RULE_UI_OK);
				status = ProUIPushbuttonDisable(DLG_F5A07_002, MEASURE_PART_PB);
				//status = ProUIPushbuttonEnable(DLG_F5A07_002, SELECT_PARTS_PB);
				_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide inputs again!. Refer help document for details.");
				/*if (quitAction != NULL)
					*quitAction = true;*/
				return status;
			}

			if (n_sels < 1 || status != PRO_TK_NO_ERROR) {
				_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
				/*if (quitAction != NULL)
					*quitAction = true;*/
				status = ProUIPushbuttonDisable(DLG_F5A07_002, RULE_UI_OK);
				return status;
			}

			if (status == PRO_TK_NO_ERROR)
			{
				ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
				msg_buttons[0] = PRO_UI_MESSAGE_YES;
				msg_buttons[1] = PRO_UI_MESSAGE_NO;
				user_choice = _utils.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation", "Do you want to continue with this selection?", msg_buttons);
				mainLog.Write("userchoice: " + to_string(user_choice));
				if (user_choice == msg_buttons[0])
					isSelectionRight = true;	//user confirmed
				else if (user_choice == msg_buttons[1])
					isSelectionRight = false;	//user doesn't confirm

				ProArrayFree((ProArray*)&msg_buttons);
				if (isSelectionRight == true)
				{
					status = ProSelectionAsmcomppathGet(part_sel[0], &part_asmcomp_path[0]);
					ruleLog.Write("ProSelectionAsmcomppathGet = " + to_string(status));

					// to find the parent component
					part_asmcomp_path[0].table_num = 1;
					status = ProAsmcomppathMdlGet(&part_asmcomp_path[0], &parent_mdl);
					ruleLog.Write("ProAsmcomppathMdlGet = " + to_string(status));

					status = ProMdlMdlnameGet(parent_mdl, wParentMdlName);
					ProWstringToString(cParentMdlName, wParentMdlName);
					ruleLog.Write("cParentMdlName = " + (string)cParentMdlName);
					//strcpy(_temp.name, cParentMdlName);

					if (string(cParentMdlName).substr(4, 5) == reqCompSubModManual[i])
					{

						status = ProSelectionCopy(part_sel[0], &store[i]);
						ruleLog.Write("ProSelectionCopy = " + to_string(status));
						//rule_sts = _irule.measureDistanceBetweenAsmAndPart(reqComps_f5a07_002[0], part_sel, output_clearance_vals[i + 4]);*/
						validInput = true;
					}
					else {
						_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Input", "Selected part is not from " + reqCompSubModManual[i] + " \nPlease Select again.");
					}
				}
			}
		}
	}
	status = ProUIPushbuttonEnable(DLG_F5A07_002, MEASURE_PART_PB);
	return status;
}

ProError Measure_action_IRF5A07_002(char* dialog, char* component, ProAppData data)
{
	int curWinId;
	InterfaceRule _irule;
	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);

	//status = ProUIPushbuttonEnable(dialog, MEASURE_PART_PB);

	for (int i = 0; i < 3; i++)
	{
		//ruleLog.Write(to_string(i));
		rule_sts = _irule.measureDistanceBetweenAsmAndPart(reqComps_f5a07_002[0], &store[i], output_clearance_vals[4 + i]);
	}
	if (output_clearance_vals[4] < 25) {
		rule_sts = highlightParts(reqComps_f5a07_002[0], PRO_COLOR_LETTER);
		status = ProSelectionHighlight(store[0], PRO_COLOR_LETTER);
	}

	if (output_clearance_vals[5] < 25) {
		rule_sts = highlightParts(reqComps_f5a07_002[0], PRO_COLOR_LETTER);
		status = ProSelectionHighlight(store[1], PRO_COLOR_LETTER);
	}
	if (output_clearance_vals[6] < 25) {
		rule_sts = highlightParts(reqComps_f5a07_002[0], PRO_COLOR_LETTER);
		status = ProSelectionHighlight(store[2], PRO_COLOR_LETTER);
	}

	// Clearance between components (automatic)
	rule_sts = _irule.measureDistanceBetweenComponents(reqComps_f5a07_002[0], reqComps_f5a07_002[1], output_clearance_vals[0]); // F1A04
	if (output_clearance_vals[0] < 25) {
		rule_sts = highlightParts(reqComps_f5a07_002[0], PRO_COLOR_LETTER);
		rule_sts = highlightParts(reqComps_f5a07_002[1], PRO_COLOR_LETTER);
	}

	rule_sts = _irule.measureDistanceBetweenComponents(reqComps_f5a07_002[0], reqComps_f5a07_002[2], output_clearance_vals[1]); // F5B03
	if (output_clearance_vals[1] < 25) {
		rule_sts = highlightParts(reqComps_f5a07_002[0], PRO_COLOR_LETTER);
		rule_sts = highlightParts(reqComps_f5a07_002[2], PRO_COLOR_LETTER);
	}
	rule_sts = _irule.measureDistanceBetweenComponents(reqComps_f5a07_002[0], reqComps_f5a07_002[3], output_clearance_vals[2]); // A1B05
	if (output_clearance_vals[2] < 25) {
		rule_sts = highlightParts(reqComps_f5a07_002[0], PRO_COLOR_LETTER);
		rule_sts = highlightParts(reqComps_f5a07_002[3], PRO_COLOR_LETTER);
	}

	rule_sts = _irule.measureDistanceBetweenComponents(reqComps_f5a07_002[0], reqComps_f5a07_002[4], output_clearance_vals[3]); // F5A11
	if (output_clearance_vals[3] < 25) {
		rule_sts = highlightParts(reqComps_f5a07_002[0], PRO_COLOR_LETTER);
		rule_sts = highlightParts(reqComps_f5a07_002[4], PRO_COLOR_LETTER);
	}

	status = ProUIPushbuttonEnable(DLG_F5A07_002, RULE_UI_OK);
	return status;

}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES				  | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5A07001		| Atharva Patil		| MF5A07; MF2C01; MF5B01;		  |  Clearance of Air tank with surrounding moving
																		 parts should be 40 mm minimum.
===================================================================================================================*/

#define DLG_IRF5A07_001 "dlg_IR_F5A07_001"
#define PB_ROK			"CommitOK"
#define PB_RCANCEL		"CommitCancel"
#define PB_Select		"Pb_Select"

ProSelection* surfaceSels;
int								countSels;
//vector<clearanceData>			distance;
int								selsButton = 0;
vector<ownerInfo>				ownerdetail;
vector<clearanceData>			clearancesVector;


int IRF5A07::IRF5A07_001(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5B01::IRF5B01_001   ==========================");
	//AppFrontEnd appFend;
	InterfaceRule		iRule;
	string				rmMsgTyre;

	selsButton = 0;
	rmMsgTyre.erase();
	clearancesVector.clear();
	ProWindowRepaint(PRO_VALUE_UNUSED);
	isUserQuits = false;

	//ruleLog.Write("Submodule Selected: " + (string)appFend.airTankSMname);



	status = ProUIDialogCreate(DLG_IRF5A07_001, DLG_IRF5A07_001);
	ruleLog.Write("ProUIDialogCreate status: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRF5A07_001, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A07_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A07_001, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A07_001, PB_Select, (ProUIAction)selectActionF5A07_001, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));

	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogHide status: " + to_string(status));
	status = ProUIPushbuttonDisable(DLG_IRF5A07_001, PB_ROK);
	ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));
	status = ProUIDialogActivate(DLG_IRF5A07_001, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_IRF5A07_001);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);

		return -1;
	}

	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	ruleLog.Write("size of vector: " + to_string(clearancesVector.size()));
	sort(clearancesVector.begin(), clearancesVector.end(), [](const clearanceData& a, const clearanceData& b) {
		return a.clearance < b.clearance;
		});

	ruleLog.Write("sort check");
	rmMsgTyre += "Minimum clearance measured = " + (clearancesVector[0].clea) + " mm.\nAcceptance Criteria: >= 40.00 mm";

	rmMsgTyre += "\n\nReferences selected-\n";



	for (int i = 0; i < clearancesVector.size(); i++)
	{
		rmMsgTyre += to_string(i + 1) + ")" + (string)clearancesVector[i].nameOfSel1 + " <surf ID: " + to_string(clearancesVector[i].id1) + "> (" + clearancesVector[i].desc1 + ") & "
			+ (string)clearancesVector[i].nameOfSel2 + " <surf ID: " + to_string(clearancesVector[i].id2) + "> (" + clearancesVector[i].desc2 + ") = " + clearancesVector[i].clea + " mm.\n";

		/*char pointName[PRO_NAME_SIZE] = "CLEARANCE_HIGHLITE_PNT";
		strcat(pointName, to_string(i + 1).c_str());
		createDatumPointsF5A07_001(clearancesVector[i].pntArr, pointName, "CSYS_ASM_DEF");*/
	}


	for (int i = 0; i < clearancesVector.size(); i++)
	{
		if ((round(clearancesVector[i].clearance) < 40.00))
		{
			status = ProSelectionHighlight(clearancesVector[i].sel1, PRO_COLOR_ERROR);
			status = ProSelectionHighlight(clearancesVector[i].sel2, PRO_COLOR_ERROR);

			char pointName[PRO_NAME_SIZE] = "CLEARANCE_HIGHLITE_PNT";
			strcat(pointName, to_string(i + 1).c_str());
			createDatumPointsF5A07_001(clearancesVector[i].pntArr, pointName, "CSYS_ASM_DEF");
		}
	}

	//Declare results
	for (int i = 0; i < clearancesVector.size(); i++)
	{
		if ((round(clearancesVector[i].clearance) >= 40.00))
		{
			final_res.result = "PASS";
		}
		else
		{
			final_res.result = "FAIL";
			break;
		}
	}



	final_res.remark = rmMsgTyre;


	status = ProUIDialogDestroy(DLG_IRF5A07_001);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);


	return 0;

}

ProError selectActionF5A07_001(char* dialog, char* component, ProAppData data)
{
	InterfaceRule			_irule;
	wchar_t					wName[PRO_NAME_SIZE];
	char					cName[PRO_NAME_SIZE];
	ownerInfo				obj;
	clearanceData			item;

	_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Notice", "Select all the pair of surfaces on air tank and any moving part adjacent to it.\n(For ex. Wheels, Propeller shaft)");
	status = ProUIDialogHide(dialog);


Begin:
	{
		ownerdetail.clear();
		status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surfaceSels, &countSels);
		ruleLog.Write("ProSelect: " + to_string(status));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIPushbuttonDisable(dialog, PB_ROK);
			status = ProUIDialogShow(dialog);

			return status;
		}
		if (countSels < 2 || status != PRO_TK_NO_ERROR) {
			_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Two Surfaces should be selected");
			status = ProUIPushbuttonDisable(dialog, PB_ROK);
			ProSelectionFree(surfaceSels);

			goto Begin;
		}

		selsButton++;
		ProModelitem selItem, ownerItem;
		ProMdlExtension wExtension;
		ProParameter            pDesc;
		ProParamvalue           pvDesc;
		ProName                 pDescName = L"DESCRIPTION";
		string					description;
		char cExtension[PRO_NAME_SIZE], cDesc[PRO_NAME_SIZE];

		for (int i = 0; i < countSels; i++)
		{
			status = ProSelectionModelitemGet(surfaceSels[i], &selItem);
			ruleLog.Write("ProSelectionModelitemGet status: " + to_string(status));
			ruleLog.Write("id of selected surface: " + to_string(selItem.id));

			status = ProMdlMdlnameGet(selItem.owner, wName);
			ruleLog.Write("ProMdlMdlnameGet status: " + to_string(status));
			ProWstringToString(cName, wName);
			ruleLog.Write("Owner name: " + (string)cName);
			status = ProMdlExtensionGet(selItem.owner, wExtension);
			strcat(cName, ".");
			strcat(cName, ProWstringToString(cExtension, wExtension));


			status = ProMdlToModelitem(selItem.owner, &ownerItem);
			ruleLog.Write("ProMdlToModelitem status: " + to_string(status));

			status = ProParameterInit(&ownerItem, pDescName, &pDesc);
			ruleLog.Write("ProParameterInit : " + to_string(status));

			if (status != PRO_TK_E_NOT_FOUND)
			{
				status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
				ruleLog.Write("ProParameterValueWithUnitsGet : " + to_string(status));
				ProWstringToString(cDesc, pvDesc.value.s_val);
				//description.append(cDesc);
			}


			obj.id = selItem.id;
			ruleLog.Write("id stored: " + to_string(obj.id));
			strcpy(obj.name, cName);
			ruleLog.Write("obj.name copied: " + (string)obj.name);
			strcpy(obj.descrp, cDesc);
			ruleLog.Write("obj.description copied: " + (string)obj.descrp);
			ownerdetail.push_back(obj);
			ruleLog.Write("obj pushed back");
		}


		ProBoolean is_interference_found;
		Pro3dPnt pnt_arr[2];
		Pro3dPnt pnt_arr1[2];
		Pro2dPnt param_surfs[2];
		double clearance;
		double pntCreationClearance;

		/*status = ProSelectionWithOptionsDistanceEval(surfaceSels[0], PRO_B_TRUE, surfaceSels[1], PRO_B_TRUE, param_surfs[0], param_surfs[1], pnt_arr1[0], pnt_arr1[1], &clearance);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(clearance));
		ruleLog.Write("Coordinates from PSWODE: " + to_string(pnt_arr1[0][0]) + ", " + to_string(pnt_arr1[0][1]) + ", " + to_string(pnt_arr1[0][2]) + ", " + to_string(pnt_arr1[1][0]) + ", " + to_string(pnt_arr1[1][1]) + ", " + to_string(pnt_arr1[1][2]));*/

		status = ProFitClearanceCompute(surfaceSels[0], PRO_FIT_INCLUDE_NONE, surfaceSels[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &pntCreationClearance, NULL, &is_interference_found, pnt_arr);
		ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(pntCreationClearance));
		ruleLog.Write("Coordinates from PFCC: " + to_string(pnt_arr[0][0]) + ", " + to_string(pnt_arr[0][1]) + ", " + to_string(pnt_arr[0][2]) + ", " + to_string(pnt_arr[1][0]) + ", " + to_string(pnt_arr[1][1]) + ", " + to_string(pnt_arr[1][2]));


		item.pntArr[0][0] = pnt_arr[0][0];
		item.pntArr[0][1] = pnt_arr[0][1];
		item.pntArr[0][2] = pnt_arr[0][2];
		item.pntArr[1][0] = pnt_arr[1][0];
		item.pntArr[1][1] = pnt_arr[1][1];
		item.pntArr[1][2] = pnt_arr[1][2];

		ProSelectionCopy(surfaceSels[0], &item.sel1);
		ProSelectionCopy(surfaceSels[1], &item.sel2);
		ruleLog.Write("Selections Copied");
		item.desc1 = ownerdetail[0].descrp;
		item.desc2 = ownerdetail[1].descrp;
		ruleLog.Write("descriptions Copied");
		strcpy(item.nameOfSel1, ownerdetail[0].name);
		strcpy(item.nameOfSel2, ownerdetail[1].name);
		ruleLog.Write("Selection names Copied");
		item.id1 = ownerdetail[0].id;
		item.id2 = ownerdetail[1].id;
		ruleLog.Write("ID assigned");
		item.clea = to_string(round(pntCreationClearance));
		item.clea.erase(item.clea.find_last_not_of('0') + 3);
		item.clearance = pntCreationClearance;
		ruleLog.Write("clearances stored");
		clearancesVector.push_back(item);
		ruleLog.Write("item pushed back for: " + to_string(clearance));

	}

	ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
	msg_buttons[0] = PRO_UI_MESSAGE_YES;
	msg_buttons[1] = PRO_UI_MESSAGE_NO;

	string questionMsg;
	questionMsg += "You have selected " + to_string(selsButton) + " pair of surfaces\nDo you want to add more pairs?";
	user_choice = _irule.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation!!", questionMsg, msg_buttons);
	ruleLog.Write("UserDisplayPopupMessageUserChoice: " + to_string(user_choice));

	if (user_choice == PRO_UI_MESSAGE_NO)
	{
		ruleLog.Write("inside user_choice == PRO_UI_MESSAGE_NO");
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
		ruleLog.Write("ProUIPushbuttonEnable status: " + to_string(status));
		status = ProUIDialogShow(dialog);
	}
	else
	{
		ruleLog.Write("inside user_choice == PRO_UI_MESSAGE_YES");
		questionMsg.erase();
		goto Begin;
	}

	ownerdetail.clear();



	return PRO_TK_NO_ERROR;
}

int createDatumPointsF5A07_001(Pro3dPnt pnt_arr[2], char pointName[PRO_NAME_SIZE], char* csysName)
{
	ruleLog.Write("=================> InterfaceRule::createDatumPoints <=================");
	ProElement	elem_tree, elem_ftype, elem_feature_name,
		pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
		pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
		pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
	ProReference REPDEP_ref1;
	wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wide_string[PRO_NAME_SIZE], wide_string_2[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE];
	//CSYS_ASM_DEF
	ProModelitem refCsysitem;
	ProSelection refCsysSel, reqMdlSel;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pnt_feat;
	ProErrorlist errors;
	//converting negative values to positive
	double d1 = -pnt_arr[0][2];
	double d2 = -pnt_arr[1][2];
	//char cDatumPointName[PRO_NAME_SIZE] = "Dist_highlght_pnt";

	ProStringToWstring(wCsysName, csysName);
	status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
	status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);


	//Create Element Tree
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	//feature name
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, pointName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
	ruleLog.Write("feature name = " + to_string(status));

	//PRO_E_DPOINT_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
	ruleLog.Write("type status = " + to_string(status));

	//Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);

	//ref
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
	status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
	status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);

	//
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);

	//Populating array element
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);

	//Point1
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);

	//Point1 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
	ProStringToWstring(wide_string, "datum_PNT1");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);

	//Point2
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);

	//Point2 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
	ProStringToWstring(wide_string_2, "datum_PNT2");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);

	/* =============================================================== *\
	Create Model Selection Object
	\* =============================================================== */

	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Points
	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	status = ProElementFree(&elem_tree);
	status = ProSelectionFree(&reqMdlSel);

	/*ProSelection pnt_Sel;
	status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
	status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_HIGHLITE);*/
	//PRO_COLOR_SELECTED for green highlight
	ruleLog.Write("==================function end=================");
	return 0;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES				  | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF5A07008		|MATHANPRASATH A	| MF5A07 |  Air tank should not obstruct between Ramp over angle & departure angle of the vehicle.
===================================================================================================================*/
#define DLG_F5A07_008		"dlg_IR_F5A07_008"
#define PB_RCANCEL			"Commit_Cancel"
#define PB_ROK				"Commit_Ok"
#define PB_IMG				"pb_img_tyre"
#define PB_SELECT_TYRE      "pb_select_tyre"
#define Label_tyre			"Lable_sel_tyre"
#define PB_SELECT_FRAME     "pb_select_frame"
#define Label_frame			"Lable_sel_frame"
#define InputPanel_Rrf		"InputPanel_Rrf"
#define InputPanel_Rrr		"InputPanel_Rrr"
#define InputPanel_Rrf_2_1		"InputPanel_Rrf_2_1"
#define InputPanel_Rrr_2_2		"InputPanel_Rrr_2_2"

char re_mark[PRO_PATH_SIZE];

int IRF5A07::IRF5A07_008(ruleResult& final_res)
{
	ComponentData _reqCompsf5a07_008[1]{};
	string reqCompSubMod[1] = { "F5A07" };
	string comp_names[1];


	string tyreSurfInfo{}, frameSurfInfo{};
	vector<selectionInfo>tyreSurfSels(2);
	vector<selectionInfo>longMembSels(1);
	vector<double>frontSLRVec, rearSLRVec;
	vector<double>Ramp_angle, Dept_angle;

	tyreSurfInfo.erase();
	frameSurfInfo.erase();
	frontSLRVec.clear();
	rearSLRVec.clear();
	Ramp_angle.clear();
	Dept_angle.clear();

	for (int i = 0; i < subModulesList.size(); ++i)
	{
		for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j)
		{
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
			{
				strcpy(_reqCompsf5a07_008[j].name, subModulesList[i].name.c_str());
				comp_names[j] = subModulesList[i].name;
			}
		}

	}
	//Visiting Model tree for the Component (F5A07)
	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqCompsf5a07_008);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));


	for (auto elem : _reqCompsf5a07_008)
	{
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}


	//Delete the features created in previous run
	status = deleteDatumPoint("PROJ_PNT_R");
	ruleLog.Write("deleteDatumPoint PROJ_PNT_R: " + to_string(status));
	status = deleteDatumPoint("PROJ_PNT_F");
	ruleLog.Write("deleteDatumPoint PROJ_PNT_F: " + to_string(status));
	status = deleteDatumPoint("PROJ_PNT_M");
	ruleLog.Write("deleteDatumPoint PROJ_PNT_M: " + to_string(status));
	status = deleteDatumPoint("MY_PNT1");
	ruleLog.Write("deleteDatumPoint MY_PNT1: " + to_string(status));
	status = deleteDatumPoint("MY_PNT2");
	ruleLog.Write("deleteDatumPoint MY_PNT2: " + to_string(status));
	rule_sts = deleteDatumPlane("SIDE_PLANE2");
	ruleLog.Write("deleteDatumPlane SIDE_PLANE2: " + to_string(status));
	rule_sts = deleteDatumPlane("GROUND_PLANE");
	ruleLog.Write("deleteDatumPlane GROUND_PLANE: " + to_string(status));
	status = deleteDatumPoint("F_GND_PNT_OPP");
	ruleLog.Write("deleteDatumPoint F_GND_PNT_OPP: " + to_string(status));
	rule_sts = deleteDatumPlane("SIDE_PLANE1");
	ruleLog.Write("deleteDatumPlane SIDE_PLANE1: " + to_string(status));
	status = deleteDatumPoint("F_GND_PNT");
	ruleLog.Write("deleteDatumPoint F_GND_PNT: " + to_string(status));
	status = deleteDatumPoint("R_GND_PNT");
	ruleLog.Write("deleteDatumPoint R_GND_PNT: " + to_string(status));
	status = deleteDatumPoint("F_CENT_PNT");
	ruleLog.Write("deleteDatumPoint F_CENT_PNT: " + to_string(status));
	status = deleteDatumPoint("R_CENT_PNT");
	ruleLog.Write("deleteDatumPoint R_CENT_PNT: " + to_string(status));
	status = deleteDatumPoint("F_CENT_PNT_OPP");
	ruleLog.Write("deleteDatumPoint F_CENT_PNT_OPP: " + to_string(status));
	rule_sts = deleteDatumPlane("CENTRE_PLANE");
	ruleLog.Write("deleteDatumPlane CENTRE_PLANE: " + to_string(status));

	//Create UI dialog
	status = ProUIDialogCreate(DLG_F5A07_008, DLG_F5A07_008);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_F5A07_008, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F5A07_008, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F5A07_008, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_F5A07_008, PB_SELECT_TYRE, (ProUIAction)refSurfSelections_F5A07, &tyreSurfSels);
	status = ProUIPushbuttonActivateActionSet(DLG_F5A07_008, PB_SELECT_FRAME, (ProUIAction)refSurfSelections_frame, &longMembSels);

	status = ProUIOptionmenuInputActionSet(DLG_F5A07_008, InputPanel_Rrf_2_1, (ProUIAction)inputValue_angle, &Ramp_angle);
	status = ProUIOptionmenuInputActionSet(DLG_F5A07_008, InputPanel_Rrr_2_2, (ProUIAction)inputValue_angle, &Dept_angle);

	status = ProUIOptionmenuInputActionSet(DLG_F5A07_008, InputPanel_Rrf, (ProUIAction)inputValue, &frontSLRVec);
	status = ProUIOptionmenuInputActionSet(DLG_F5A07_008, InputPanel_Rrr, (ProUIAction)inputValue, &rearSLRVec);


	/*status = ProUIPushbuttonDisable(DLG_F5A07_008, PB_SELECT_FRAME);
	status = ProUIPushbuttonDisable(DLG_F5A07_008, InputPanel_Rrf);
	status = ProUIPushbuttonDisable(DLG_F5A07_008, InputPanel_Rrr);
	status = ProUIPushbuttonDisable(DLG_F5A07_008, InputPanel_Rrf_2_1);
	status = ProUIPushbuttonDisable(DLG_F5A07_008, InputPanel_Rrr_2_2);
	*/


	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogHide: " + to_string(status));

	status = ProUIDialogActivate(DLG_F5A07_008, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_F5A07_008);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}
	if (frontSLRVec.size() == 0 || rearSLRVec.size() == 0)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention", "SLR values are not entered,\nClick OK to return.");
		status = ProUIDialogDestroy(DLG_F5A07_008);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		tyreSurfSels.clear();
		longMembSels.clear();
		frontSLRVec.clear();
		rearSLRVec.clear();
		return -1;

	}


	ProSelection fCentPntSel{}, rCentPntSel{}, csysSel{}, gPntF{}, gPntR{};
	double rollRadFront[3] = { 0,0,(frontSLRVec[frontSLRVec.size() - 1]) };       // This is rolling radius of front tyre
	double rollRadRear[3] = { 0,0,(rearSLRVec[rearSLRVec.size() - 1]) };			// This is rolling radius of rear tyre



	//Plane Creation 
	edgeSel edgeSelection1{}, edgeSelection2{};

	/*---------------------Create F_CENT_PNT and R_CENT_PNT----------------------
	F_CENT_PNT = Front centre point at the centre of front tyre
	R_CENT_PNT = Rear centre point at the centre of rear tyre
	The points will be created at the centre of biggest edge of tyre surfaces*/

	rule_sts = findTheBiggestArcEdge(tyreSurfSels[0], &edgeSelection1);
	ruleLog.Write("findTheBiggestArcEdge 1: " + to_string(rule_sts));
	status = ProSelectionHighlight(edgeSelection1.sel, PRO_COLOR_HIGHLITE);
	ruleLog.Write("ProSelectionHighlight 1 status: " + to_string(status));
	rule_sts = createDatumPointAtCenterOfEdge(edgeSelection1.sel, "F_CENT_PNT");
	ruleLog.Write("createDatumPointAtCenterOfEdge 1: " + to_string(rule_sts));

	rule_sts = findTheBiggestArcEdge(tyreSurfSels[1], &edgeSelection2);
	ruleLog.Write("findTheBiggestArcEdge 2: " + to_string(rule_sts));
	status = ProSelectionHighlight(edgeSelection2.sel, PRO_COLOR_HIGHLITE);
	ruleLog.Write("ProSelectionHighlight 2 status: " + to_string(status));
	rule_sts = createDatumPointAtCenterOfEdge(edgeSelection2.sel, "R_CENT_PNT");
	ruleLog.Write("createDatumPointAtCenterOfEdge 2: " + to_string(rule_sts));

	/*-----------Get the selection objects of F_CENT_PNT and R_CENT_PNT and CSYS
	It will be used as references to create ground points----------------------*/
	rule_sts = selectionAllocByName("F_CENT_PNT", PRO_POINT, &fCentPntSel);
	ruleLog.Write("selectionAllocByName F_CENT_PNT: " + to_string(rule_sts));
	rule_sts = selectionAllocByName("R_CENT_PNT", PRO_POINT, &rCentPntSel);
	ruleLog.Write("selectionAllocByName R_CENT_PNT: " + to_string(rule_sts));
	rule_sts = selectionAllocByName("CSYS_ASM_DEF", PRO_CSYS, &csysSel);
	ruleLog.Write("selectionAllocByName csys: " + to_string(rule_sts));

	//create front ground point taking SLRf value

	rule_sts = createGenDPntAtOffsDist(fCentPntSel, csysSel, rollRadFront, "F_GND_PNT");
	ruleLog.Write("createGenDPntAtOffsDist F_GND_PNT: " + to_string(rule_sts));
	//Get the F_GND_PNT selection object
	rule_sts = selectionAllocByName("F_GND_PNT", PRO_POINT, &gPntF);
	ruleLog.Write("selectionAllocByName F_GND_PNT: " + to_string(rule_sts));

	//create rear ground point taking SLRr value
	rule_sts = createGenDPntAtOffsDist(rCentPntSel, csysSel, rollRadRear, "R_GND_PNT");
	ruleLog.Write("createGenDPntAtOffsDist R_GND_PNT: " + to_string(rule_sts));
	//Get the R_GND_PNT selection object
	rule_sts = selectionAllocByName("R_GND_PNT", PRO_POINT, &gPntR);
	ruleLog.Write("selectionAllocByName R_GND_PNT: " + to_string(rule_sts));

	/*=============== Create a projection plane on opposite side of the vehicle to create a ground point on that
	side as well
	Ground plane will be created as a plane passing through 3 points ===============*/

	//get the selection alloc of a plane passing through vehicle centre (ASM_XZ plane)
	ProSelection asmXZSel;
	rule_sts = selectionAllocByName("ASM_XZ", PRO_SURFACE, &asmXZSel);
	ruleLog.Write("selectionAllocByName ASM_XZ: " + to_string(rule_sts));
	double oppSidePlaneOffsVal = -900;  //Using general value for commonising the offs distance for all the CAD models 
	rule_sts = createOffsetPlaneWithReference_F5A07_008(asmXZSel, oppSidePlaneOffsVal, "SIDE_PLANE1");
	ruleLog.Write("createOffsetPlaneWithReferenceG status: " + to_string(rule_sts));

	//get the selection object of side plane
	ProSelection sidePlane1Sel{};
	rule_sts = selectionAllocByName("SIDE_PLANE1", PRO_SURFACE, &sidePlane1Sel);
	ruleLog.Write("selectionAllocByName PROJ_PLANE: " + to_string(rule_sts));

	rule_sts = projectDatumPointOnPlane(gPntF, sidePlane1Sel, "F_GND_PNT_OPP");
	ruleLog.Write("projectDatumPointOnPlane1: " + to_string(rule_sts));

	//get the selection object of F_GND_PNT_OPP
	ProSelection fGndPntOpp{};
	rule_sts = selectionAllocByName("F_GND_PNT_OPP", PRO_POINT, &fGndPntOpp);
	ruleLog.Write("selectionAllocByName PROJ_PLANE: " + to_string(rule_sts));

	//Create a ground plane Normal to Long member surface and passing thr G_PNT_F and G_PNT_R 
	rule_sts = threePointPlaneCreate(gPntF, fGndPntOpp, gPntR, "GROUND_PLANE");
	ruleLog.Write("threePointPlaneCreate status: " + to_string(rule_sts));



	//remark message for tyre surface details
	tyreSurfInfo += "\n\nReferences selected from tyre - \n";
	for (int i = 0; i < tyreSurfSels.size(); i++)
	{
		tyreSurfInfo += to_string(i + 1) + ")surf ID- " + to_string(tyreSurfSels[i].id) + "(Owner: " + tyreSurfSels[i].name + ".PRT\tDesc: " + tyreSurfSels[i].descrp + ")\n";
	}

	//remark message for tyre surface details
	frameSurfInfo += "\nReferences selected from frame - \n";
	for (int i = 0; i < longMembSels.size(); i++)
	{
		frameSurfInfo += to_string(i + 1) + ")surf ID- " + to_string(longMembSels[i].id) + " (Owner: " + longMembSels[i].name + ".PRT\tDesc: " + longMembSels[i].descrp + ")\n";
	}

	//Remark message for rolling radii provided by user
	string rollingRadMsg, rollRadFrnStr, rollRadRearStr;
	rollRadFrnStr = to_string(abs(frontSLRVec[frontSLRVec.size() - 1]));
	rollRadFrnStr.erase(rollRadFrnStr.find_last_not_of('0') + 3);      //for keeping only 2 zeroes post descimal
	rollRadRearStr = to_string(abs(rearSLRVec[rearSLRVec.size() - 1]));
	rollRadRearStr.erase(rollRadRearStr.find_last_not_of('0') + 3);
	rollingRadMsg += "Rolling radius values provided by user -\nFront tyre(Rrf): " + rollRadFrnStr + " mm.\t\tRear tyre(Rrr): " + rollRadRearStr + " mm.";

	//destroy the UI dialog for smooth transition 
	status = ProUIDialogDestroy(DLG_F5A07_008);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

	//Create a side plane for projecting all the points on a same line
	double sidePlaneOffsVal = 1200;  //Using general value for commonising the offs distance for all the CAD models 
	rule_sts = createOffsetPlaneWithReference_F5A07_008(asmXZSel, sidePlaneOffsVal, "SIDE_PLANE2");
	ruleLog.Write("createOffsetPlaneWithReferenceG status: " + to_string(rule_sts));
	//get the selection object of side plane
	ProSelection projPlaneSel{};
	rule_sts = selectionAllocByName("SIDE_PLANE2", PRO_SURFACE, &projPlaneSel);
	ruleLog.Write("selectionAllocByName PROJ_PLANE: " + to_string(rule_sts));

	//measure distance between rear plane and rear centre point
	double rearEndDist;
	status = measureDistanceBetweenSurfaces_F5A07_008(longMembSels[0].selection, PRO_B_TRUE, rCentPntSel, PRO_B_TRUE, rearEndDist);
	ruleLog.Write("measureDistanceBetweenSurfaces status: " + to_string(status));

	//Get selection object of ground plane
	ProSelection grndPlaneSel{};
	rule_sts = selectionAllocByName("GROUND_PLANE", PRO_SURFACE, &grndPlaneSel);
	ruleLog.Write("selectionAllocByName ground plane: " + to_string(rule_sts));

	//Measure distance between component and ground plane (groundClearance)
	double groundClearance;
	Pro3dPnt pntArr[2];
	rule_sts = measureDistanceBetweenPlaneAndComp_F5A07_008(grndPlaneSel, _reqCompsf5a07_008[0], groundClearance, pntArr);
	ruleLog.Write("measureDistanceBetweenPlaneAndCompG status: " + to_string(rule_sts));
	//two_decimal
	string act_clrnce;
	act_clrnce.append(doubleToString(groundClearance));

	/*===================== create points for highlighting the distance =====================
	  NOTE :- coords (pntArr) returned by API ProSelectionWithOptionsDistanceEval===========*/
	rule_sts = createCsysOffsDatumPoint(csysSel, pntArr, "GROUND_CLEARANCE_PNT");
	ruleLog.Write("createCsysOffsDatumPoint status: " + to_string(rule_sts));

	/*=================get the selection object of middle point===================
	NOTE -: It will be used to create a point projected on PROJ_PLANE ===========*/
	ProSelection middlePntSel{};
	rule_sts = selectionAllocByName("MY_PNT2", PRO_POINT, &middlePntSel);
	ruleLog.Write("selectionAllocByName middle proj point: " + to_string(rule_sts));
	//Project middle point on side PROJ_PLANE
	rule_sts = projectDatumPointOnPlane(middlePntSel, projPlaneSel, "PROJ_PNT_M");
	ruleLog.Write("projectDatumPointOnPlane1: " + to_string(rule_sts));
	//Get selection object of PROJ_PNT_M
	ProSelection middleProjPntSel{};
	rule_sts = selectionAllocByName("PROJ_PNT_M", PRO_POINT, &middleProjPntSel);
	ruleLog.Write("selectionAllocByName PROJ_PNT_M: " + to_string(rule_sts));

	//project front ground point on a side plane
	rule_sts = projectDatumPointOnPlane(gPntF, projPlaneSel, "PROJ_PNT_F");
	ruleLog.Write("projectDatumPointOnPlane1: " + to_string(rule_sts));
	//Get selection object of PROJ_PNT_F
	ProSelection frontProjPntSel{};
	rule_sts = selectionAllocByName("PROJ_PNT_F", PRO_POINT, &frontProjPntSel);
	ruleLog.Write("selectionAllocByName PROJ_PNT_F: " + to_string(rule_sts));

	//project rear ground point on a side plane
	rule_sts = projectDatumPointOnPlane(gPntR, projPlaneSel, "PROJ_PNT_R");
	ruleLog.Write("projectDatumPointOnPlane2: " + to_string(rule_sts));
	//Get selection object of PROJ_PNT_R
	ProSelection rearProjPntSel{};
	rule_sts = selectionAllocByName("PROJ_PNT_R", PRO_POINT, &rearProjPntSel);
	ruleLog.Write("selectionAllocByName PROJ_PNT_R: " + to_string(rule_sts));

	//measure distance between front project point to middle project point
	double frontPntDist;
	status = measureDistanceBetweenSurfaces_F5A07_008(frontProjPntSel, PRO_B_TRUE, middleProjPntSel, PRO_B_TRUE, frontPntDist);
	ruleLog.Write("measureDistanceBetweenSurfaces status: " + to_string(status) +
		"\ndistance between front and middle point: " + to_string(frontPntDist));

	//measure distance between rear project point to middle project point
	double rearPntDist;
	status = measureDistanceBetweenSurfaces_F5A07_008(rearProjPntSel, PRO_B_TRUE, middleProjPntSel, PRO_B_TRUE, rearPntDist);
	ruleLog.Write("measureDistanceBetweenSurfaces status: " + to_string(status) +
		"\ndistance between rear and middle point: " + to_string(rearPntDist));

	//measure height of frame from ground plane
	double frameHeight;
	status = measureDistanceBetweenSurfaces_F5A07_008(longMembSels[0].selection, PRO_B_FALSE, grndPlaneSel, PRO_B_FALSE, frameHeight);
	ruleLog.Write("measureDistanceBetweenSurfaces status: " + to_string(status) +
		"\nheight of frame from ground plane: " + to_string(frameHeight));

	//calculate departure angle
	double depAngleMeas;
	depAngleMeas = depatureAngleCalc(rearEndDist, frameHeight, abs(rollRadRear[2]));
	ruleLog.Write("depatureAngle status: " + to_string(status) +
		"\nDeparture angle calculated: " + to_string(depAngleMeas));

	//calculate Ramp Over angle
	double rampOvAngMeas;
	rampOvAngMeas = rampOverAngleCalc(frontPntDist, groundClearance, abs(rollRadFront[2]), abs(rollRadRear[2]), rearPntDist);
	ruleLog.Write("rampOverAngle status: " + to_string(status) +
		"\Ramp over angle calculated: " + to_string(rampOvAngMeas));

	//Rule Validation and Results 
	double stdDeprtureAng = Dept_angle.at(1), stdRampOvAngl = Ramp_angle.at(1);
	ruleLog.Write("stdDeprtureAng =" + to_string(stdDeprtureAng));
	ruleLog.Write("stdRampOvAngl  =" + to_string(stdRampOvAngl));
	if ((depAngleMeas >= stdDeprtureAng) && (rampOvAngMeas >= stdRampOvAngl))
	{
		final_res.result = "PASS";
	}
	else
		final_res.result = "FAIL";


	//remarks
	string gt_clearance;
	gt_clearance += "\nGround Clearance of Airtank = " + act_clrnce + " mm";
	sprintf(remark, "Departure Angle: %0.2lf deg\nRampOver Angle: %0.2lf deg", depAngleMeas, rampOvAngMeas);
	sprintf(re_mark, "\n\nAcceptance Criteria:\nDeparture angle: minimum %0.2lf deg\t\tRamp Over angle: minimum %0.2lf deg\n\n", stdDeprtureAng, stdRampOvAngl);
	final_res.remark = remark + gt_clearance + re_mark + rollingRadMsg + tyreSurfInfo + frameSurfInfo;
	status = ProUIDialogShow(DLG_IRC_MAIN);

	tyreSurfSels.clear();
	longMembSels.clear();

	ruleLog.Write("rearEndDist: " + to_string(rearEndDist) + "\nframeHeight: " + to_string(frameHeight) + "\nRolling Radius rear: " + to_string(abs(rollRadRear[2])));
	ruleLog.Write("frontPntDist: " + to_string(frontPntDist) + "\ngroundClearance: " + to_string(groundClearance) + "\nRolling Radius front: " + to_string(abs(rollRadFront[2])) + "\nrearPntDist: " + to_string(rearPntDist));

	return 0;
}

ProError inputValue_angle(char* dialog, char* component, vector<double>* offsetValVec)
{
	ruleLog.Write("----------------------------- inputValue_Angle -----------------------------");
	//cValue.clear();
	wchar_t* wOffsetValue[PRO_NAME_SIZE];
	char cOffSetVal[PRO_NAME_SIZE];
	double userInput, offSetValue;
	//status = ProUIPushbuttonDisable(dialog, PB_ROK);
	status = ProUIInputpanelValueGet(dialog, component, wOffsetValue);
	ruleLog.Write("PoUIInputpanelValueGet  status = " + to_string(status));
	if (status == 0)
	{
		status = ProUIInputpanelEnable(dialog, "InputPanel_Rrf");
		status = ProUIInputpanelEnable(dialog, "InputPanel_Rrr");
		status = ProUIPushbuttonEnable(DLG_F5A07_008, PB_ROK);
	}
	ProWstringToString(cOffSetVal, wOffsetValue[0]);

	double angle = wideStringToDouble(wOffsetValue[0]);
	ruleLog.Write("angle = " + to_string(angle));
	offsetValVec->push_back(angle);
	//ruleLog.Write("check 1");
	////double A = stod(c_offsetValue);
	//ruleLog.Write("check 2");
	//string str(cOffSetVal);
	//ruleLog.Write("Offset value in string: " + str);
	//ruleLog.Write("Offset value in char: " + string(cOffSetVal));
	//if (isDouble(str))
	//{
	//	ruleLog.Write("Valid");
	//	userInput = abs(stod(cOffSetVal));
	//	ruleLog.Write("userInput: " + to_string(userInput));
	//	ruleLog.Write("check 3");
	//	offSetValue = userInput;

	//	ruleLog.Write("offsetValue in double: " + to_string(offSetValue));
	//	offsetValVec->push_back(offSetValue);
	//}

	return PRO_TK_NO_ERROR;
}

ProError refSurfSelections_F5A07(char* dialog, char* component, vector<selectionInfo>* ownerDetails)
{
	ruleLog.Write("=================== referenceSelectionForPlane ==================");

	InterfaceRule  iRule;
	int            selNumber;
	ProWindowRepaint(PRO_VALUE_UNUSED);
	vector<string>frontVec, rearVec;
	ProSelection* refSurfSel;

	status = ProSelect((char*)"surface", ownerDetails->size(), NULL, NULL, NULL, NULL, &refSurfSel, &selNumber);
	ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(selNumber));

	if (status == PRO_TK_USER_ABORT)
	{
		iRule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please select inputs again!. Refer help document for details.");
		status = ProUIDialogShow(dialog);
		//status = ProUIPushbuttonDisable(dialog, PB_ROK);
		return status;
	}
	if ((selNumber < 2) || (status != PRO_TK_NO_ERROR)) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Invalid Selection. Refer help document for details.");
		status = ProUIDialogShow(dialog);
		//status = ProUIPushbuttonDisable(dialog, PB_ROK);
		return status;
	}

	char              cParentMdlName[PRO_NAME_SIZE], desc[PRO_NAME_SIZE];
	wchar_t           wParentMdlName[PRO_NAME_SIZE];

	ProModelitem      modelItem;
	string            description;
	ProParameter      pDesc;
	ProParamvalue     pvDesc;
	ProName			  pDescName = L"DESCRIPTION";
	ProAsmcomppath	  path;
	for (int i = 0; i < selNumber; i++)
	{
		description.erase();
		status = ProSelectionAsmcomppathGet(refSurfSel[i], &path);
		ruleLog.Write("ProSelectionAsmcomppathGet status: " + to_string(status));

		status = ProSelectionModelitemGet(refSurfSel[i], &modelItem);
		ruleLog.Write("ProSelectionModelitemGet status: " + to_string(status));

		status = ProMdlMdlnameGet(modelItem.owner, wParentMdlName);
		ProWstringToString(cParentMdlName, wParentMdlName);
		ruleLog.Write("cParentMdlName = " + (string)cParentMdlName);

		ProModelitem partItem;
		status = ProMdlToModelitem(modelItem.owner, &partItem);
		ruleLog.Write("ProMdlToModelitem status: " + to_string(status));

		status = ProParameterInit(&partItem, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit: " + to_string(status));

		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			description.append(ProWstringToString(desc, pvDesc.value.s_val));
			ruleLog.Write("ProParameterValueWithUnitsGet status: " + to_string(status) + "\tdescription: " + description);
		}
		status = ProSelectionCopy(refSurfSel[i], &ownerDetails->at(i).selection);
		ruleLog.Write("ProSelectionCopy status: " + to_string(status));
		ownerDetails->at(i).id = modelItem.id;
		ruleLog.Write("id copied " + to_string(modelItem.id));
		strcpy(ownerDetails->at(i).name, cParentMdlName);
		ruleLog.Write("parent name copied " + string(cParentMdlName));
		strcpy(ownerDetails->at(i).descrp, description.c_str());
		ruleLog.Write("parent description copied " + description);
		ownerDetails->at(i).modelItem = modelItem;
		ownerDetails->at(i).asmCompPath = path;
		ruleLog.Write("modelitem and asmcomppath stored");
	}
	if (ownerDetails->size() == 2)
	{
		//
		if (status == 0)
		{
			status = ProUIInputpanelEnable(dialog, "pb_select_frame");
			//status = ProUIPushbuttonEnable(dialog, "Commit_Ok");
		}

	}

	int windowID;
	status = ProWindowCurrentGet(&windowID);
	status = ProWindowRefit(windowID);

	return PRO_TK_NO_ERROR;
}

double wideStringToDouble(const std::wstring& wideStr)
{
	const wchar_t* start = wideStr.c_str();
	wchar_t* end = nullptr;
	errno = 0;  // Reset errno before the call
	double result = std::wcstod(start, &end);


	return result;
}

int measureDistanceBetweenPlaneAndComp_F5A07_008(ProSelection planeSel, ComponentData reqComp1, double& distance, Pro3dPnt pntArr[2])
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenPlaneAndComp <=================");

	//ProSelection planeSel;
	ProMdl reqMdl;
	char cReqMdlPath[PRO_PATH_SIZE];
	ProPath wReqMdlPath;
	ProModelitem planeMdlitem;
	wchar_t wPlaneName[PRO_NAME_SIZE];
	Utils util;


	ProSelection sels[1];
	ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected

	ProName comp1_name;
	ProModelitem feature[1];
	ProMdl reqMdls[1];

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);

	ProAsmcomppath path[1];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));


	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	Pro2dPnt param_1, param_2;

	status = ProSelectionWithOptionsDistanceEval(planeSel, PRO_B_FALSE, sels[0], PRO_B_FALSE, param_1, param_2, pntArr[0], pntArr[1], &distance);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(distance));
	if (status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT) {
		util.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selections.");
		return -1;
	}

	ruleLog.Write("Coordinates of point 1: \nX-Coord - " + to_string(pntArr[0][0]) + "\tY-Coord - " +
		to_string(pntArr[0][1]) + "\tZ-Coord - " + to_string(pntArr[0][2]));
	ruleLog.Write("Coordinates of point 2: \nX-Coord - " + to_string(pntArr[1][0]) + "\tY-Coord - " +
		to_string(pntArr[1][1]) + "\tZ-Coord - " + to_string(pntArr[1][2]));

	return 0;
}

ProError measureDistanceBetweenSurfaces_F5A07_008(ProSelection& sel_surf1, ProBoolean option1, ProSelection& sel_surf2, ProBoolean option2, double& distance_bw_surfs)
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenSurfaces <=================");

	Pro2dPnt param_surfs1, param_surfs2;
	Pro3dPnt pnt_surfs1, pnt_surfs2;

	status = ProSelectionWithOptionsDistanceEval(sel_surf1, option1, sel_surf2, option2, param_surfs1, param_surfs2, pnt_surfs1, pnt_surfs2, &distance_bw_surfs);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance_bw_surfs: " + to_string(distance_bw_surfs));

	return status;
}

int createOffsetPlaneWithReference_F5A07_008(ProSelection refSelection, double offsetValue, char* outputPlaneName)
{
	/*ProModelitem refPlaneitem;
	ProSelection refPlaneSel;*/
	wchar_t wRefPlaneName[PRO_NAME_SIZE], wOutputPlaneName[PRO_NAME_SIZE];
	ProElement	elem_tree, elem_ftype, elem_consts, elem_prl, elem_const_type1, elem_const_type2, elem_along, elem_offset, elem_offset_ref, elem_feature_name, elem_offset_create;
	ProReference REPDEP_ref1, REPDEP_ref2;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pln_feat;
	ProErrorlist errors;
	ruleLog.Write("Offset value = " + to_string(offsetValue));

	/* =============================================================== *\
	Create Element Tree
	\* =============================================================== */
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	// FEATURE NAME
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wOutputPlaneName, outputPlaneName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);

	// CONSTRAINTS ALLOCATION
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINTS, &elem_consts);
	ProElemtreeElementAdd(elem_tree, NULL, elem_consts);
	ruleLog.Write("constraints status = " + to_string(status));

	// Constraint 1
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_offset);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_offset);
	ruleLog.Write("1st constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type1);
	ProElementIntegerSet(elem_const_type1, PRO_DTMPLN_OFFS);
	status = ProElemtreeElementAdd(elem_offset, NULL, elem_const_type1);
	ruleLog.Write("1st constraint type status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_offset_ref);
	status = ProSelectionToReference(refSelection, &REPDEP_ref1);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	status = ProElementReferenceSet(elem_offset_ref, REPDEP_ref1);
	ruleLog.Write("ProElementReferenceSet = " + to_string(status));
	status = ProElemtreeElementAdd(elem_offset, NULL, elem_offset_ref);
	ruleLog.Write("1st constraint reference status = " + to_string(status));



	/* =============================================================== *\
		Allocate ref offset value element; add under constraint element.
	\* =============================================================== */
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF_OFFSET, &elem_offset_create);
	ProElementDecimalsSet(elem_offset_create, 4);
	ProElementDoubleSet(elem_offset_create, offsetValue);

	status = ProElemtreeElementAdd(elem_offset, NULL, elem_offset_create);


	/*---------------------------------------------------------------*\
	Create the feature in the current model.
	\*---------------------------------------------------------------*/

	ProSelection curMdlSel;
	status = ProSelectionAlloc(NULL, &curMdlitem, &curMdlSel);
	ruleLog.Write("ProSelectionAlloc status featCreate: " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Plane
	status = ProFeatureWithoptionsCreate(curMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pln_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	ruleLog.Write("ProArrayFree status = " + to_string(status));
	status = ProElementFree(&elem_tree);
	ruleLog.Write("ProElementFree status = " + to_string(status));


	return 0;
}

ProError Datumplanebypoint(ProSelection& sel_1, char* outputPlaneName)
{
	ProModelitem refPlaneitem;
	ProSelection reqMdlSel, refPlaneSel;
	wchar_t wRefPlaneName[PRO_NAME_SIZE], wOutputPlaneName[PRO_NAME_SIZE];
	ProElement	elem_tree, elem_ftype, elem_consts, elem_const_type1, elem_thru, elem_const_type2, elem_thru_ref, elem_feature_name;
	ProReference REPDEP_ref1, REPDEP_ref2;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pln_feat;
	ProErrorlist errors;

	//ProStringToWstring(wRefPlaneName, refPlaneName);
	//status = ProModelitemByNameInit(refPlaneOwner, PRO_SURFACE, wRefPlaneName, &refPlaneitem);
	//status = ProSelectionAlloc(NULL, &refPlaneitem, &refPlaneSel);


	/* =============================================================== *\
	Create Element Tree
	\* =============================================================== */
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));



	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));



	// FEATURE NAME
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wOutputPlaneName, outputPlaneName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);



	// CONSTRAINTS ALLOCATION
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINTS, &elem_consts);
	ProElemtreeElementAdd(elem_tree, NULL, elem_consts);
	ruleLog.Write("constraints status = " + to_string(status));

	// Constraint 1
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_thru);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_thru);
	ruleLog.Write("1st constraint status = " + to_string(status));



	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type1);
	ProElementIntegerSet(elem_const_type1, PRO_DTMPLN_THRU);
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_const_type1);
	ruleLog.Write("1st constraint type status = " + to_string(status));



	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_thru_ref);
	status = ProSelectionToReference(sel_1, &REPDEP_ref1);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	status = ProElementReferenceSet(elem_thru_ref, REPDEP_ref1);
	ruleLog.Write("ProElementReferenceSet = " + to_string(status));
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_thru_ref);
	ruleLog.Write("1st constraint reference status = " + to_string(status));

	/* =============================================================== *\
	Create Model Selection Object
	\* =============================================================== */
	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
	ruleLog.Write("ProArrayAlloc status = " + to_string(status));


	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Plane
	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pln_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	if (status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Refer help document for details.");
	}

	status = ProArrayFree((ProArray*)&opts);
	ruleLog.Write("ProArrayFree status = " + to_string(status));
	status = ProElementFree(&elem_tree);
	ruleLog.Write("ProElementFree status = " + to_string(status));
	status = ProSelectionFree(&reqMdlSel);
	ruleLog.Write("ProSelectionFree status = " + to_string(status));

	return PRO_TK_NO_ERROR;
}

ProError f5a07_measureDistanceBetweenPlaneAndComp(const char* parentMdlName, const char* plane_name, ComponentData reqComp1, double& distance)
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenPlaneAndSurface <=================");

	ProSelection planeSel;
	ProMdl reqMdl;
	char cReqMdlPath[PRO_PATH_SIZE];
	ProPath wReqMdlPath;
	ProModelitem planeMdlitem;
	wchar_t wPlaneName[PRO_NAME_SIZE];

	strcpy(cReqMdlPath, cCurMdlPath);
	strcat(cReqMdlPath, parentMdlName);
	strcat(cReqMdlPath, ".asm");
	ruleLog.Write("cReqMdlPath: " + string(cReqMdlPath));

	ProStringToWstring(wReqMdlPath, cReqMdlPath);

	status = ProMdlnameRetrieve(wReqMdlPath, PRO_MDLFILE_ASSEMBLY, &reqMdl);
	ruleLog.Write("ProMdlnameRetrieve: " + to_string(status));

	ruleLog.Write("plane1_name: " + string(plane_name));
	ProStringToWstring(wPlaneName, const_cast<char*> (plane_name));

	status = ProModelitemByNameInit(reqMdl, PRO_SURFACE, wPlaneName, &planeMdlitem);
	ruleLog.Write("ProModelitemByNameInit: " + to_string(status));


	status = ProSelectionAlloc(NULL, &planeMdlitem, &planeSel);

	ProSelection sels[1];
	ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected

	ProName comp1_name;
	ProModelitem feature[1];
	ProMdl reqMdls[1];

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);

	ProAsmcomppath path[1];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));


	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	Pro2dPnt param_1, param_2;
	Pro3dPnt pnt_arr[2];
	double platformWidth;

	status = ProSelectionWithOptionsDistanceEval(planeSel, PRO_B_TRUE, sels[0], PRO_B_TRUE, param_1, param_2, pnt_arr[0], pnt_arr[1], &distance);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(distance));


	return PRO_TK_NO_ERROR;
}

ProError refSurfSelections_frame(char* dialog, char* component, vector<selectionInfo>* ownerDetails)
{
	ruleLog.Write("=================== referenceSelectionForPlane ==================");

	InterfaceRule  iRule;
	int            selNumber;
	ProWindowRepaint(PRO_VALUE_UNUSED);
	vector<string>frontVec, rearVec;
	ProSelection* refSurfSel;

	status = ProSelect((char*)"edge", ownerDetails->size(), NULL, NULL, NULL, NULL, &refSurfSel, &selNumber);
	ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(selNumber));

	if (status == PRO_TK_USER_ABORT)
	{
		iRule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please select inputs again!. Refer help document for details.");
		status = ProUIDialogShow(dialog);
		//status = ProUIPushbuttonDisable(dialog, PB_ROK);
		return status;
	}
	if ((selNumber < 1) || (status != PRO_TK_NO_ERROR)) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Invalid Selection. Refer help document for details.");
		status = ProUIDialogShow(dialog);
		//status = ProUIPushbuttonDisable(dialog, PB_ROK);
		return status;
	}

	char              cParentMdlName[PRO_NAME_SIZE], desc[PRO_NAME_SIZE];
	wchar_t           wParentMdlName[PRO_NAME_SIZE];

	ProModelitem      modelItem;
	string            description;
	ProParameter      pDesc;
	ProParamvalue     pvDesc;
	ProName			  pDescName = L"DESCRIPTION";
	ProAsmcomppath	  path;
	for (int i = 0; i < selNumber; i++)
	{
		description.erase();
		status = ProSelectionAsmcomppathGet(refSurfSel[i], &path);
		ruleLog.Write("ProSelectionAsmcomppathGet status: " + to_string(status));

		status = ProSelectionModelitemGet(refSurfSel[i], &modelItem);
		ruleLog.Write("ProSelectionModelitemGet status: " + to_string(status));

		status = ProMdlMdlnameGet(modelItem.owner, wParentMdlName);
		ProWstringToString(cParentMdlName, wParentMdlName);
		ruleLog.Write("cParentMdlName = " + (string)cParentMdlName);

		ProModelitem partItem;
		status = ProMdlToModelitem(modelItem.owner, &partItem);
		ruleLog.Write("ProMdlToModelitem status: " + to_string(status));

		status = ProParameterInit(&partItem, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit: " + to_string(status));

		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			description.append(ProWstringToString(desc, pvDesc.value.s_val));
			ruleLog.Write("ProParameterValueWithUnitsGet status: " + to_string(status) + "\tdescription: " + description);
		}
		status = ProSelectionCopy(refSurfSel[i], &ownerDetails->at(i).selection);
		ruleLog.Write("ProSelectionCopy status: " + to_string(status));
		ownerDetails->at(i).id = modelItem.id;
		ruleLog.Write("id copied " + to_string(modelItem.id));
		strcpy(ownerDetails->at(i).name, cParentMdlName);
		ruleLog.Write("parent name copied " + string(cParentMdlName));
		strcpy(ownerDetails->at(i).descrp, description.c_str());
		ruleLog.Write("parent description copied " + description);
		ownerDetails->at(i).modelItem = modelItem;
		ownerDetails->at(i).asmCompPath = path;
		ruleLog.Write("modelitem and asmcomppath stored");
	}
	if (ownerDetails->size() == 1)
	{
		if (status == 0)
		{

			status = ProUIInputpanelEnable(dialog, "InputPanel_Rrf_2_1");
			status = ProUIInputpanelEnable(dialog, "InputPanel_Rrr_2_2");

			//status = ProUIPushbuttonEnable(dialog, "Commit_Ok");
		}

	}

	int windowID;
	status = ProWindowCurrentGet(&windowID);
	status = ProWindowRefit(windowID);

	return PRO_TK_NO_ERROR;
}