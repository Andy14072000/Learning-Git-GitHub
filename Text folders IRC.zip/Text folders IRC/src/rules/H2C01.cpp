/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2024	|	V1_0_0		| H2C01 - Gear Box & Shifting
==================================================================================================================*/
#include "H2C01.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-H2C01-001	| MATHANPRASATH A	| MH2C01	        | Single coupling flange for each GB family in accordance with SAE standards.
===================================================================================================================*/
#define DLG_IRH2C01_001 	"dlg_IR_H2C01_001"
#define PB_RCANCEL			"CommitCancel"
#define CommitOk			"CommitOk"
#define PB_IMG				"rule_img"

#define Label_SNs			"Label_SNs"
#define OptionMenu_SNs		"OptionMenu_SNs"

#define Label_SNs_Prop			"Label_SNs_Prop"
#define OptionMenu_SNs_Prop		"OptionMenu_SNs_Prop"

#define Label_Sel			"Label_Sel"
#define pb_Select			"pb_Select"

#define Label_bolt			"Label_bolt"
#define OptionMenu_bolt		"OptionMenu_bolt"

#define Label_Sel_Bolt		"Label_Sel_Bolt"
#define pb_Select_Bolt		"pb_Select_Bolt"

struct Asm_model_H2C01_001
{
	ProMdl		Model;
	int			Model_feat_id;
};



vector<surfaceData>surfaceCollect_H2C01_001;
vector<surfaceData>surfaceCollect_F2C01;
vector<surfaceData>smallerHoles;
vector<surfaceData>smallerHoles_f2c01;
ProSelection* surf_Selection;
vector<int>idTable_H2C01_001;

//Declare the variables for visiting and creatinng ID table of each comp
Asm_model_H2C01_001					models[1000];
int							models_cnt_H2C01_001;
Asm_model_H2C01_001					Assy_models[1000];
int							Assy_models_cnt_H2C01_001;
int							num_of_assy_fixed_H2C01_001 = 0;
int							model_count_H2C01_001;
vector<feat_id_data>		feat_id_data_arr_H2C01_001;
int							level_H2C01_001;
int							owner_feat_id_H2C01_001;
ProMdl						curr_model_H2C01_001;


//Declare the variables for switch cases
double						OD_H2C01_001, hole_dia_GB, dim_1, dim_2, distance_PCD, distanceOD, diam1, dist1_H2C01_001, dist2_H2C01_001, measured_PCD, diameter1;
int							noOf_Holes, GB_Family{}, Sel_Count, holes_Count, holesCount_f2c01;
Pro2dPnt					param_1, param_2;
Pro3dPnt					pnt_1, pnt_2;
ProSelection				edge_Selection, small_Edge;
string						dimen1, dimen2, diaa, platform, rmMsgH2D01, msg1, msg, msg_F2C01, sel_bolt, pcdGB, pcdPS, smHoleDiaGB, smHoleDiaPS, accptCrit;
vector<double>				distances;
const regex					raPattern("(\\d+)");
smatch						numberFound;
bool						method_1 = NULL, is_Passed{}, is_Serrated, is_SerratedModel, is_True{};
ProMdl						flangeMdl_H2C01_001;
//double						measurements1[9];


ProModelitem mdl_f2c01;
char mdl_name[PRO_NAME_SIZE];
ProAsmcomppath* sel_path_f2c01{};
double distancePCD_F2C01;
double hole_dia_PS;
ProMdl* model;
double dia_bolt;
string Dia_bol;
int IRH2C01::IRH2C01_001(ruleResult& final_res)
{
	//clear the data from previous run
	rmMsgH2D01.clear();
	accptCrit.clear();
	distances.clear();
	smallerHoles.clear();
	surfaceCollect_H2C01_001.clear();
	surfaceCollect_F2C01.clear();
	smallerHoles_f2c01.clear();
	ProWindowRepaint(PRO_VALUE_UNUSED);


	//Call the UI
	isUserQuits = false;
	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogCreate(DLG_IRH2C01_001, DLG_IRH2C01_001);
	ruleLog.Write("ProUIDialogCreate status: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRH2C01_001, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2C01_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2C01_001, CommitOk, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2C01_001, pb_Select, (ProUIAction)selectAction__H2C01_001, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2C01_001, pb_Select_Bolt, (ProUIAction)Bolt_selectAction__H2C01_001, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));
	status = ProUIOptionmenuSelectActionSet(DLG_IRH2C01_001, OptionMenu_SNs, (ProUIAction)optionMenuSelectAction1__H2C01_001, NULL);
	ruleLog.Write("ProUIOptionmenuSelectActionSet :  " + to_string(status));
	status = ProUIOptionmenuSelectActionSet(DLG_IRH2C01_001, OptionMenu_SNs_Prop, (ProUIAction)optionMenuSelectAction1__F2C01_001, NULL);
	ruleLog.Write("ProUIOptionmenuSelectActionSet :  " + to_string(status));
	status = ProUIOptionmenuSelectActionSet(DLG_IRH2C01_001, OptionMenu_bolt, (ProUIAction)optionMenuSelectAction__bolt, NULL);
	ruleLog.Write("ProUIOptionmenuSelectActionSet :  " + to_string(status));


	status = ProUIDialogActivate(DLG_IRH2C01_001, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	
	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_IRH2C01_001);
		ruleLog.Write("ProUIDialogDestroy close action: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	/*This is a function where actual rule execution happens.
	The function is created to avoid replicating the same code*/
	method_1 == true;
	ruleVerificationFunction_H2C01();

	//Close after rule run
	status = ProUIDialogDestroy(DLG_IRH2C01_001);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogShow: " + to_string(status));

	//Declare Results
	if (is_Passed == true)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	final_res.remark = rmMsgH2D01;



	return 0;
}

ProError optionMenuSelectAction1__H2C01_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("---------------optionMenuSelectAction1__H2C01_001------------");

	//Get the user input regarding serrated or non serrated flange
	int			n_sel;
	string		target;
	char** selValue_Ser_NserOptMenu;

	msg.erase();
	status = ProUIPushbuttonDisable(dialog, CommitOk);

	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue_Ser_NserOptMenu);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet cb fn: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue_Ser_NserOptMenu[0]));
	msg.append(selValue_Ser_NserOptMenu[0]);   // msg will be used to declare result about the texture of the flange surface

	if (strcmp(selValue_Ser_NserOptMenu[0], "Select") != 0)
	{

	}


	return PRO_TK_NO_ERROR;
}

ProError optionMenuSelectAction1__F2C01_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("---------------optionMenuSelectAction1__H2C01_001------------");

	//Get the user input regarding serrated or non serrated flange
	int			n_sel;
	string		target;
	char** selValue_Ser_NserOptMenu;

	msg_F2C01.erase();
	status = ProUIPushbuttonDisable(dialog, CommitOk);

	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue_Ser_NserOptMenu);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet cb fn: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue_Ser_NserOptMenu[0]));
	msg_F2C01.append(selValue_Ser_NserOptMenu[0]);   // msg will be used to declare result about the texture of the flange surface

	if (strcmp(selValue_Ser_NserOptMenu[0], "Select") != 0)
	{

	}


	return PRO_TK_NO_ERROR;
}

ProError optionMenuSelectAction__bolt(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("---------------optionMenuSelectAction1__H2C01_001------------");

	//Get the user input regarding serrated or non serrated flange
	int			n_sel;
	string		target;
	char** selValue_Ser_NserOptMenu;

	sel_bolt.erase();
	status = ProUIPushbuttonDisable(dialog, CommitOk);

	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue_Ser_NserOptMenu);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet cb fn: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue_Ser_NserOptMenu[0]));
	sel_bolt.append(selValue_Ser_NserOptMenu[0]);   // msg will be used to declare result about the texture of the flange surface

	if (strcmp(selValue_Ser_NserOptMenu[0], "Select") != 0)
	{

	}


	return PRO_TK_NO_ERROR;
}

void ruleVerificationFunction_H2C01()
{
	ruleLog.Write("---------------ruleVerificationFunction_H2C01------------");

	InterfaceRule irule;
	FILE* fp{};
	
		//Visit the features of opened submodule

		level_H2C01_001 = 1;

		num_of_assy_fixed_H2C01_001 = 0;

		models[0].Model = curMdl;
		models[0].Model_feat_id = 0;
		models_cnt_H2C01_001 = 1;
		Assy_models_cnt_H2C01_001 = 0;

	begin:

		for (int a = 0; a < models_cnt_H2C01_001; ++a)
		{
			owner_feat_id_H2C01_001 = models[a].Model_feat_id;
			status = ProSolidFeatVisit((ProSolid)models[a].Model, (ProFeatureVisitAction)visitAction_H2C01_001, compsFilter, fp);
			ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
		}

		if (Assy_models_cnt_H2C01_001 > 0)
		{
			++level_H2C01_001;
			for (int b = 0; b < Assy_models_cnt_H2C01_001; ++b)
			{
				models[b].Model = Assy_models[b].Model;
				models[b].Model_feat_id = Assy_models[b].Model_feat_id;
			}
			models_cnt_H2C01_001 = Assy_models_cnt_H2C01_001;
			Assy_models_cnt_H2C01_001 = 0;
			goto begin;
		}


		//Evaluate the diameter of surfaces to create a vector of surfaces containing surfaces of smaller hole
		ruleLog.Write("Size of vector is: " + to_string(surfaceCollect_H2C01_001.size()));

		vector<surfaceData>alternateDiaVec;
		ruleLog.Write("Check_GB Hole dia: " + to_string(hole_dia_GB));
		ruleLog.Write("Check_PS Hole dia: " + to_string(hole_dia_PS));
		for (int i = 0; i < surfaceCollect_H2C01_001.size(); i++)
		{
			status = ProSurfaceDiameterEval(surfaceCollect_H2C01_001.at(i).surface, NULL, &diameter1);
			ruleLog.Write("ProSurfaceDiameterEval status: " + to_string(status) + "\nDiameter: " + to_string(diameter1));
			surfaceCollect_H2C01_001.at(i).diameter = diameter1;

			/*if diameter of holes in the CAD matches with the standard dia of hole, mentioned in the characteristics of flange,
			then it will be directly stored in a vector .
			if diameter of holes in the CAD does not match with the standard dia of hole, mentioned in the characteristics of flange,
			then the closest dia which will have a value between 10-14 will be stored in another vector .
			This method is incorporated to count the no. of holes without any user interference*/

			if (diameter1 == hole_dia_PS)
			{
				ruleLog.Write("Dia == hole_dia_PS");
				smallerHoles.push_back(surfaceCollect_H2C01_001.at(i));
			}
			else if (diameter1 > 10 && diameter1 < 14)
			{
				ruleLog.Write("Dia != hole_dia_PS");
				alternateDiaVec.push_back(surfaceCollect_H2C01_001[i]);
			}
		}


		if (smallerHoles.size() != 0)
		{
			//Case of measured dia matching with the standard dia 
			smHoleDiaGB = to_string(round(smallerHoles.at(0).diameter));
			smHoleDiaGB.erase(smHoleDiaGB.find_last_not_of('0') + 3, string::npos);

			//Count the number of holes 
			holes_Count = smallerHoles.size() / 2;
			ruleLog.Write("The number of holes: " + to_string(smallerHoles.size() / 2));
			
		}
		else if ((smallerHoles.size() == 0) && (alternateDiaVec.size() != 0))
		{
			//Case of measured dia differing with the standard dia 
			smHoleDiaGB = to_string(round(alternateDiaVec.at(0).diameter));
			smHoleDiaGB.erase(smHoleDiaGB.find_last_not_of('0') + 3, string::npos);

			//Count the number of holes 
			double target = alternateDiaVec[0].diameter;
			int holesC = 0;
			for (int i = 0; i < alternateDiaVec.size(); i++)
			{
				/*There is a possibility that measured diameters having value betweeen 5-20 can be mulitple
				For ex dia = 11mm , dia = 13 mm.
				This can create confusion while counting the no. of holes
				To avoid this we will count only those holes that are having same dia as of first found smallest dia*/

				if (target == alternateDiaVec[i].diameter)
				{
					holesC++;
				}

			}
			holes_Count = holesC / 2;
			ruleLog.Write("The number of holes: " + to_string(holes_Count));
		}


		/*measuring the pitch circle diameter with the help of biggest edge of the flange ( it will be outermost) and the edge of a hole*/
		status = ProSelectionWithOptionsDistanceEval(edge_Selection, PRO_B_TRUE, small_Edge, PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance_PCD);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval status: " + to_string(status));
		ruleLog.Write("Pitch Circle radius: " + to_string(distance_PCD));
		measured_PCD = distance_PCD * 2;

		status = ProGeomitemDiameterEval(small_Edge, &hole_dia_GB);
		ruleLog.Write("GB Hole dia: " + to_string(hole_dia_GB));
		ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status));
		pcdGB = to_string(round(measured_PCD));
		pcdGB.erase(pcdGB.find_last_not_of('0') + 3, string::npos);
		ruleLog.Write("Pitch circle diameter: " + to_string(measured_PCD));

		//writing the remarks
		rmMsgH2D01 += "\nDetails of flange used in H2C01: \n";

		if (pcdGB == pcdPS)
			rmMsgH2D01 += "Pitch Circle Diameter : " + pcdGB + " mm (PASS)\n";
		else
			rmMsgH2D01 += "Pitch Circle Diameter : " + pcdGB + " mm (FAIL)\n";

		//smHoleDiaGB == smHoleDiaPS
		if (hole_dia_GB == hole_dia_PS)
			rmMsgH2D01 += "Diameter of Holes : " + to_string(hole_dia_GB) + " mm (PASS)\n";
		else
			rmMsgH2D01 += "Diameter of Holes : " + to_string(hole_dia_GB) + " mm (FAIL)\n";

		if (holes_Count == holesCount_f2c01)
			rmMsgH2D01 += "Holes Count : " + to_string(holes_Count) + " (PASS)\n";
		else
			rmMsgH2D01 += "Holes Count : " + to_string(holes_Count) + " (FAIL)\n";


		if (strcmp(msg.c_str(), msg_F2C01.c_str()) == 0)
			rmMsgH2D01 += msg + " (PASS)\n";
		else
			rmMsgH2D01 += msg + " (FAIL)\n";
		
		if (strcmp(sel_bolt.c_str(), "PR Coupling") == 0)
		{
			if (hole_dia_PS > dia_bolt)
			{
				rmMsgH2D01 += "\nDiameter of the Bolt = " + to_string(dia_bolt) + " mm\n";
				rmMsgH2D01 += "Diameter of the Hole = " + to_string (hole_dia_PS) + " mm (PASS)\n";
			}
			else
			{
				rmMsgH2D01 += "\nDiameter of the Bolt = " + to_string(dia_bolt) + " mm\n";
				rmMsgH2D01 += "Diameter of the Hole = " + to_string(hole_dia_PS) + " mm (FAIL)\n";
			}
		}
		else
		{
			if (hole_dia_GB > dia_bolt)
			{
				rmMsgH2D01 += "\nDiameter of the Bolt = " + to_string(dia_bolt) + " mm\n";
				rmMsgH2D01 += "Diameter of the Hole = " + to_string(hole_dia_GB) + " mm (PASS)\n";
			}
			else
			{
				rmMsgH2D01 += "\nDiameter of the Bolt = " + to_string(dia_bolt) + " mm\n";
				rmMsgH2D01 += "Diameter of the Hole = " + to_string(hole_dia_GB) + " mm (FAIL)\n";
			}


		}

		

		accptCrit += "\nAcceptance Criteria:\n Standard Single coupling flange for each Gear Box and Propeller shaft should be used.";
		rmMsgH2D01 += accptCrit;    //Acceptance criteria is defined in the switch cases

		ruleLog.Write("rmmsg check1");

		ruleLog.Write(rmMsgH2D01);

		ruleLog.Write("msg valu: " + msg);
		ruleLog.Write("msg1 value: " + msg_F2C01);

		/*Comparing whether the flange is serrated by using user selection from drop down and property defined in the switch cases
		If both matches then we will allow the rule to pass (Only for serrated or non serrated)
		Rest of the properties will be verified in the next step*/

		/*if ()
		{
			isTrue = true;
		}
		else
			isTrue = false;*/
		Utils util;

		//Comparing the mesured PCD , no. of holes and dia of holes (Measured vs defined)
		if (pcdGB == pcdPS && holes_Count == holesCount_f2c01 && hole_dia_GB == hole_dia_PS && (strcmp(msg.c_str(), msg_F2C01.c_str()) == 0))
		{
			is_Passed = true;
			ruleLog.Write("isPassed true");
		}
		else
		{
			is_Passed = false;
			ruleLog.Write("isPassed false");
		}
	
}

ProError visitAction_H2C01_001(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("====== visitAction_H2C01_001 =====");
	ProMdlfileType			comp_type;
	ProFamilyMdlName		comp_name;
	char					part_no[PRO_PATH_SIZE];
	ProAsmcompconstraint* constr_array;
	ProMdl					model;
	ProFeattype				ftype;
	ProAsmcompconstraint	constraint;
	ProAsmcompconstraint* constraints;
	ProPatternStatus 		p_pattern_status;
	ProFeatStatus 			p_status;
	FILE* fp = (FILE*)app_data;



	status = ProFeatureTypeGet(p_feature, &ftype);
	ruleLog.Write("ProFeatureTypeGet status: " + to_string(status));

	if (ftype == PRO_FEAT_COMPONENT)
	{
		ruleLog.Write("Component Level = " + to_string(level_H2C01_001));
		status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
		ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));
		ProWstringToString(part_no, comp_name);
		ruleLog.Write("Part name: " + (string)part_no);
		++model_count_H2C01_001;

		feat_id_data  _feat_id_data;

		if (level_H2C01_001 == 1)
		{
			ruleLog.Write("inside if loop level ==1 ");
			_feat_id_data.feat_ids[0] = p_feature->id;
			_feat_id_data.level = level_H2C01_001;

			feat_id_data_arr_H2C01_001.push_back(_feat_id_data);

		}
		else
		{
			for (int j = 0; j < feat_id_data_arr_H2C01_001.size(); ++j)
			{
				if (feat_id_data_arr_H2C01_001[j].feat_ids[level_H2C01_001 - 2] == owner_feat_id_H2C01_001)
				{
					feat_id_data owner_feat_id_data = feat_id_data_arr_H2C01_001[j];
					for (int i = 0; i < level_H2C01_001 - 1; ++i)
					{
						_feat_id_data.feat_ids[i] = owner_feat_id_data.feat_ids[i];
					}

					_feat_id_data.feat_ids[level_H2C01_001 - 1] = p_feature->id;
					_feat_id_data.level = level_H2C01_001;

					break;
				}

			}

			feat_id_data_arr_H2C01_001.push_back(_feat_id_data);
		}

		ProMdlType				subModuleMdlType;
		ProModelitem			subMdlModelItem;
		ProParameter            pDesc;
		ProParamvalue           pvDesc;
		ProName                 pDescName = L"DESCRIPTION";
		char                    descriptionVal[PRO_NAME_SIZE];
		wchar_t					wFeatName[PRO_NAME_SIZE];
		char					cFeatname[PRO_NAME_SIZE];
		const regex				cfpattern("COUPLING FLANGE"), pattern2("PINION"), /*pattern3("COVER"),*/pattern4("NUT"), pattern5("INPUT");
		smatch					matchFound1, matchFound2, matchFound3;
		string					description;
		ProFeature				featHandle;



		status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
		ruleLog.Write("ProAsmcompMdlGet status: " + to_string(status));
		flangeMdl_H2C01_001 = model; // storing the MDL handle of flange to use it later in the surface visit action

		status = ProMdlTypeGet(model, &subModuleMdlType);
		ruleLog.Write("ProMdlTypeGet status: " + to_string(status));
		if (subModuleMdlType == PRO_MDL_PART)
		{
			status = ProMdlToModelitem(model, &subMdlModelItem);
			ruleLog.Write("ProMdlToModelitem VAS: " + to_string(status));
			status = ProParameterInit(&subMdlModelItem, pDescName, &pDesc);
			ruleLog.Write("ProParameterInit VAS: " + to_string(status));
			if (status != PRO_TK_E_NOT_FOUND)
			{
				status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
				ruleLog.Write("ProParameterValueWithUnitsGet VAS: " + to_string(status));
				ProWstringToString(descriptionVal, pvDesc.value.s_val);
				ruleLog.Write("Description VAS: " + (string)descriptionVal);
				description.erase();
				description.append(descriptionVal);
				ruleLog.Write("Check for regex statement");

				//Checking in the description if it is flange part. 
				if (regex_search(description, matchFound1, cfpattern) && (regex_search(description, matchFound2, pattern2) == 0)
					&& (regex_search(description, matchFound3, pattern4) == 0) && (regex_search(description, matchFound1, pattern5) == 0))
				{
					ruleLog.Write("Size of IdTable found flange: " + to_string(idTable_H2C01_001.size()));
					ruleLog.Write("Check for inside regex search");

					vector<surfaceData>cylSurfaces;
					status = ProSolidSurfaceVisit((ProSolid)model, (ProSurfaceVisitAction)surfVisitAction_H2C01_001, NULL, &cylSurfaces);
					ruleLog.Write("ProSolidSurfaceVisit VAS: " + to_string(status));

					sort(cylSurfaces.begin(), cylSurfaces.end(), [](const surfaceData& a, const surfaceData& b) {
						return a.diameter > b.diameter;
						});
					ruleLog.Write("Dia of first element: " + to_string(cylSurfaces.at(0).diameter));

					//Creating ID table for coupling flange
					ProIdTable			comp_id_table;
					int					table_num;
					ProAsmcomppath		p_comp_path;
					table_num = level_H2C01_001;
					ruleLog.Write("the table num is: " + to_string(table_num));

					for (int m = 0; m < level_H2C01_001; ++m) {
						comp_id_table[m] = _feat_id_data.feat_ids[m];
						ruleLog.Write("comp_ID-Table " + to_string(m) + ": " + to_string(comp_id_table[m]));
					}

					//Initiating Asm Comp path for coupling flange
					status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
					ruleLog.Write("ProAsmcomppathInit status: " + to_string(status));

					//Selecting the biggest edge using its model item and asm comp path of flange
					status = ProSelectionAlloc(&p_comp_path, &cylSurfaces.at(0).modelItem, &edge_Selection);
					ruleLog.Write("ProSelectionAlloc big edge status: " + to_string(status));

					//selecting the smallest edge ( Edge of a hole)
					for (int i = 0; i < cylSurfaces.size(); i++)
					{
						if (cylSurfaces.at(i).diameter == hole_dia_GB)
						{
							ruleLog.Write("diameter == diaOfHoles- H2C01");
							status = ProSelectionAlloc(&p_comp_path, &cylSurfaces.at(i).modelItem, &small_Edge);
							ruleLog.Write("ProSelectionAlloc small edge status: " + to_string(status));
							break;
						}
						else if ((cylSurfaces.at(i).diameter > 10) && (cylSurfaces.at(i).diameter < 14))
						{
							ruleLog.Write("diameter != diaOfHoles- H2C01");
							status = ProSelectionAlloc(&p_comp_path, &cylSurfaces.at(i).modelItem, &small_Edge);
							ruleLog.Write("ProSelectionAlloc small edge status: " + to_string(status));
							break;
						}
					}

					status = ProSelectionHighlight(edge_Selection, PRO_COLOR_HIGHLITE);
					status = ProSelectionHighlight(small_Edge, PRO_COLOR_HIGHLITE);

				}
			}
		}

		if (subModuleMdlType == PRO_MDL_ASSEMBLY)
		{
			Assy_models[Assy_models_cnt_H2C01_001].Model = model;
			Assy_models[Assy_models_cnt_H2C01_001].Model_feat_id = p_feature->id;
			Assy_models_cnt_H2C01_001 += 1;
		}
	}

	return PRO_TK_NO_ERROR;
}

ProError surfVisitAction_H2C01_001(ProSurface surface, ProError status, vector<surfaceData>* cylSurfaces)
{
	ProSrftype surfType;
	surfaceData surfObject;
	int id;
	ProModelitem modelIt;

	status = ProSurfaceTypeGet(surface, &surfType);
	ruleLog.Write("ProSurfaceTypeGet status: " + to_string(status) + "\nSurface type is: " + to_string(surfType));
	if (status == PRO_TK_NO_ERROR)
	{
		//Visit only cylindrical surfaces
		if (surfType == PRO_SRF_CYL)
		{
			surfObject.surface = surface;
			ruleLog.Write("Before push back");
			surfaceCollect_H2C01_001.push_back(surfObject);

			ruleLog.Write("After push back");
			double					diameter;
			status = ProSurfaceDiameterEval(surface, NULL, &diameter);
			ruleLog.Write("ProSurfaceDiameterEval status: " + to_string(status) + "\nDiameter: " + to_string(diameter));
			surfObject.diameter = diameter;

			status = ProSurfaceIdGet(surface, &id);
			ruleLog.Write("ProSurfaceIdGet status: " + to_string(status) + "\n identifier: " + to_string(id));

			status = ProModelitemInit(flangeMdl_H2C01_001, id, PRO_SURFACE, &modelIt);
			ruleLog.Write("ProModelitemInit status: " + to_string(status));
			surfObject.modelItem = modelIt;
			cylSurfaces->push_back(surfObject); // store all the cylindrical surfaces
		}
	}
	return PRO_TK_NO_ERROR;
}

ProError selectAction__H2C01_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("---------------selectAction__H2C01_001------------");
	Utils _util;
	InterfaceRule irule;
	ProError status;
	bool* quitAction = (bool*)data;

	status = ProSelect((char*)"surface,axis", 2, NULL, NULL, NULL, NULL, &surf_Selection, &Sel_Count);
	ruleLog.Write("ProSelect status: " + to_string(status));
	if (status == 0) 
	{
		status = ProUIPushbuttonDisable(dialog, pb_Select);
	}
	if (status == PRO_TK_USER_ABORT)
	{
		status = ProUIDialogShow(dialog);
		return status;
	}
	status = ProUIPushbuttonEnable(dialog, CommitOk);
	status = ProGeomitemDiameterEval(surf_Selection[0], &hole_dia_PS);
	ruleLog.Write("ProGeomitemDiameterEval status :" + to_string(status));

	/*int stat = createDatumPointAtCenterOfEdge(surfSelection[1],"PCD_Center");
	ruleLog.Write("createDatumPointAtCenterOfEdge status: " + to_string(stat));*/

	/*ProSelection CentPnt_F2C01;
	int _sts = selectionAllocByName("PCD_Center", PRO_POINT, &CentPnt_F2C01);
	ruleLog.Write("selectionAllocByName PROJ_PLANE: " + to_string(_sts));*/

	status = ProSelectionWithOptionsDistanceEval(surf_Selection[0], PRO_B_TRUE, surf_Selection[1], PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distancePCD_F2C01);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval status: " + to_string(status));
	ruleLog.Write("Pitch Circle radius_F2C01: " + to_string(distancePCD_F2C01));
	pcdPS = to_string(round(distancePCD_F2C01)*2);
	pcdPS.erase(pcdPS.find_last_not_of('0') + 3, string::npos);
	smHoleDiaPS =to_string(hole_dia_PS);
	smHoleDiaPS.erase(smHoleDiaPS.find_last_not_of('0') + 3, string::npos);
	ruleLog.Write("Diameter of Holes_F2C01: " + smHoleDiaPS);
	//rmMsgH2D01 +=
	// writing the remarks
	rmMsgH2D01 += "Details of flange used in F2C01: \nPitch Circle Diameter: " + pcdPS +
		" mm , Diameter of Holes : " + smHoleDiaPS + " mm";

		status = ProSelectionModelitemGet(surf_Selection[0], &mdl_f2c01);
		ruleLog.Write("ProSelectionModelitemGet status :" + to_string(status));

		status = ProSelectionAsmcomppathGet(surf_Selection[0], sel_path_f2c01);
		ruleLog.Write("ProSelectionAsmcomppathGet status :" + to_string(status));

		ProMdl mdl;
		status = ProModelitemMdlGet(&mdl_f2c01, &mdl);
		ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

		wchar_t model_1[PRO_NAME_SIZE], model_2;

		status = ProMdlMdlnameGet(mdl_f2c01.owner, model_1);
		ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

		ProWstringToString(mdl_name, model_1);

		ruleLog.Write("Selection_Name =" + string(mdl_name));

		status = ProSelectionHighlight(surf_Selection[0], PRO_COLOR_HIGHLITE);
		status = ProSelectionHighlight(surf_Selection[1], PRO_COLOR_HIGHLITE);

	status = PCD_F2C01(surf_Selection[0]);
	return PRO_TK_NO_ERROR;
}

ProError Bolt_selectAction__H2C01_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("---------------Bolt_selectAction__H2C01_001------------");
	ProSelection *Bolt_Selection;
	ProAsmcomppath asm_comp_path;
	int Bolt_Count;
	ProModelitem Bolt_item;
	ProModelitem  mdl_bolt_hide{};
	
	status = ProSelect((char*)"surface",1, NULL, NULL, NULL, NULL, &Bolt_Selection, &Bolt_Count);
	ruleLog.Write("ProSelect status: " + to_string(status));
	if (status == 0) 
	{
		status = ProUIPushbuttonDisable(dialog, pb_Select_Bolt);
		status = ProUIPushbuttonEnable(dialog, pb_Select);
	}
	if (status == PRO_TK_USER_ABORT)
	{
		status = ProUIDialogShow(dialog);
		return status;
	}
	/*status = ProSelectionModelitemGet(Bolt_Selection[0], &Bolt_item);
	ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));
	status = ProSelectionAsmcomppathGet(Bolt_Selection[0], &asm_comp_path);
	ruleLog.Write("ProSelectionAsmcomppathGet: " + to_string(status));
	status = ProModelitemInit(asm_comp_path.owner, asm_comp_path.table_num, PRO_FEATURE, &mdl_bolt_hide);
	ruleLog.Write("ProModelitemInit: " + to_string(status));
	status = ProModelitemHide(&mdl_bolt_hide);
	ruleLog.Write("ProModelitemHide: " + to_string(status));*/

	status = ProGeomitemDiameterEval(Bolt_Selection[0], &dia_bolt);
	ruleLog.Write("ProGeomitemDiameterEval: " + to_string(status) + "\nDiameter :" + to_string(dia_bolt));
	
	Dia_bol = to_string(dia_bolt);
	Dia_bol.erase(Dia_bol.find_last_not_of('0') + 3, string::npos);
	

	return status;
}

ProError PCD_F2C01(ProSelection& sel_part)
{
	ruleLog.Write("=================> PCD_F2C01 <=================");

	ProSelection edgeSelection_f2c01, smallEdge_f2c01{};
	status = ProSelectionModelitemGet(sel_part, &mdl_f2c01);
	ruleLog.Write("ProSelectionModelitemGet status :" + to_string(status));

	vector<surfaceData>cylSurfaces_f2c01;

	ruleLog.Write("Check_1 Dia of Hole =" + to_string(hole_dia_PS));
	status = ProSolidSurfaceVisit((ProSolid)mdl_f2c01.owner, (ProSurfaceVisitAction)surfVisitAction_F2C01, NULL, &cylSurfaces_f2c01);
	ruleLog.Write("ProSolidSurfaceVisit VAS: " + to_string(status));
	ruleLog.Write("Check_2 Dia of Hole =" + to_string(hole_dia_PS));
	sort(cylSurfaces_f2c01.begin(), cylSurfaces_f2c01.end(), [](const surfaceData& a, const surfaceData& b)
		{
			return a.diameter > b.diameter;
		});
	ruleLog.Write("Check_3 Dia of Hole =" + to_string(hole_dia_PS));
	for (int i = 0; i < cylSurfaces_f2c01.size(); ++i)
	{
		ruleLog.Write("Dia of first element: " + to_string(cylSurfaces_f2c01.at(i).diameter));
	}

	////Creating ID table for coupling flange
	//ProIdTable			comp_id_table;
	//int					table_num;
	//ProAsmcomppath		p_comp_path;
	//table_num = level_H2C01_001;
	//ruleLog.Write("the table num is: " + to_string(table_num));

	//for (int m = 0; m < level_H2C01_001; ++m) {
	//	comp_id_table[m] = _feat_id_data.feat_ids[m];
	//	ruleLog.Write("comp_ID-Table " + to_string(m) + ": " + to_string(comp_id_table[m]));
	//}

	////Initiating Asm Comp path for coupling flange
	//status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
	//ruleLog.Write("ProAsmcomppathInit status: " + to_string(status));

	////Selecting the biggest edge using its model item and asm comp path of flange
	//status = ProSelectionAlloc(sel_path_f2c01, &cylSurfaces_f2c01.at(0).modelItem, &edgeSelection_f2c01);
	//ruleLog.Write("ProSelectionAlloc big edge status: " + to_string(status));

	//selecting the smallest edge ( Edge of a hole)
	ruleLog.Write("Check_4 Dia of Hole =" + to_string(hole_dia_PS));
	for (int i = 0; i < cylSurfaces_f2c01.size(); i++)
	{
		if (cylSurfaces_f2c01.at(i).diameter == hole_dia_PS)
		{
			ruleLog.Write("diameter == diaOfHoles- F2C01");
			status = ProSelectionAlloc(sel_path_f2c01, &cylSurfaces_f2c01.at(i).modelItem, &smallEdge_f2c01);
			ruleLog.Write("ProSelectionAlloc small edge status: " + to_string(status));
			break;
		}
		/*else if ((cylSurfaces_f2c01.at(i).diameter > 10) && (cylSurfaces_f2c01.at(i).diameter <= 13))
		{
			ruleLog.Write("diameter != diaOfHoles- F2C01");
			status = ProSelectionAlloc(sel_path_f2c01, &cylSurfaces_f2c01.at(i).modelItem, &smallEdge_f2c01);
			ruleLog.Write("ProSelectionAlloc small edge status: " + to_string(status));
			break;
		}*/
	}

	vector<surfaceData>alternateDiaVec_f2c01;
	for (int i = 0; i < surfaceCollect_F2C01.size(); i++)
	{
		status = ProSurfaceDiameterEval(surfaceCollect_F2C01.at(i).surface, NULL, &diameter1);
		ruleLog.Write("ProSurfaceDiameterEval status: " + to_string(status) + "\nDiameter: " + to_string(diameter1));
		surfaceCollect_F2C01.at(i).diameter = diameter1;

		/*if diameter of holes in the CAD matches with the standard dia of hole, mentioned in the characteristics of flange,
		then it will be directly stored in a vector .
		if diameter of holes in the CAD does not match with the standard dia of hole, mentioned in the characteristics of flange,
		then the closest dia which will have a value between 10-14 will be stored in another vector .
		This method is incorporated to count the no. of holes without any user interference*/

		if (diameter1 == hole_dia_PS)
		{
			smallerHoles_f2c01.push_back(surfaceCollect_F2C01.at(i));
		}
		/*else if (diameter > 10 && diameter <= 13)
		{
			alternateDiaVec_f2c01.push_back(surfaceCollect_H2C01_001[i]);
		}*/
	}


	if (smallerHoles_f2c01.size() != 0)
	{
		//Case of measured dia matching with the standard dia 
		smHoleDiaPS = to_string(round(smallerHoles_f2c01.at(0).diameter));
		smHoleDiaPS.erase(smHoleDiaPS.find_last_not_of('0') + 3, string::npos);

		//Count the number of holes 
		holesCount_f2c01 = smallerHoles_f2c01.size() / 2;
		ruleLog.Write("The number of holes: " + to_string(smallerHoles_f2c01.size() / 2));
		rmMsgH2D01 += ", Holes Count :"+to_string(holesCount_f2c01) + " , " + msg_F2C01+"\n";
	}
	else if ((smallerHoles_f2c01.size() == 0) && (alternateDiaVec_f2c01.size() != 0))
	{
		//Case of measured dia differing with the standard dia 
		smHoleDiaPS = to_string(round(alternateDiaVec_f2c01.at(0).diameter));
		smHoleDiaPS.erase(smHoleDiaPS.find_last_not_of('0') + 3, string::npos);

		//Count the number of holes 
		double target = alternateDiaVec_f2c01[0].diameter;
		int holesC = 0;
		for (int i = 0; i < alternateDiaVec_f2c01.size(); i++)
		{
			/*There is a possibility that measured diameters having value betweeen 5-20 can be mulitple
			For ex dia = 11mm , dia = 13 mm.
			This can create confusion while counting the no. of holes
			To avoid this we will count only those holes that are having same dia as of first found smallest dia*/

			if (target == alternateDiaVec_f2c01[i].diameter)
			{
				holesC++;
			}

		}
		holes_Count = holesC / 2;
		ruleLog.Write("The number of holes: " + to_string(holes_Count));
		rmMsgH2D01 += ", Holes Count :" + to_string(holesCount_f2c01) + " , " + msg + "\n";
	}


	ruleLog.Write("====================================================================");
	return status;
}

ProError surfVisitAction_F2C01(ProSurface surface, ProError status, vector<surfaceData>* cylSurfaces)
{
	ruleLog.Write("=================> surfVisitAction_F2C01 <=================");
	ProSrftype surfType;
	surfaceData surfObject;
	int id;
	ProModelitem modelIt;

	status = ProSurfaceTypeGet(surface, &surfType);
	ruleLog.Write("ProSurfaceTypeGet status: " + to_string(status) + "\nSurface type is: " + to_string(surfType));
	if (status == PRO_TK_NO_ERROR)
	{
		//Visit only cylindrical surfaces
		if (surfType == PRO_SRF_CYL)
		{
			surfObject.surface = surface;
			ruleLog.Write("Before push back");
			surfaceCollect_F2C01.push_back(surfObject);

			ruleLog.Write("After push back");
			double					diameter;
			status = ProSurfaceDiameterEval(surface, NULL, &diameter);
			ruleLog.Write("ProSurfaceDiameterEval status: " + to_string(status) + "\nDiameter: " + to_string(diameter));
			surfObject.diameter = diameter;

			status = ProSurfaceIdGet(surface, &id);
			ruleLog.Write("ProSurfaceIdGet status: " + to_string(status) + "\n identifier: " + to_string(id));

			status = ProModelitemInit(mdl_f2c01.owner, id, PRO_SURFACE, &modelIt);
			ruleLog.Write("ProModelitemInit status: " + to_string(status));
			surfObject.modelItem = modelIt;
			cylSurfaces->push_back(surfObject); // store all the cylindrical surfaces
		}
	}
	return PRO_TK_NO_ERROR;
}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-H2C01-002	| Surendra Sarode	| MH2C01; MH2A01	| Single clutch housing to serve a GB family. A single front housing for each GB family.
===================================================================================================================*/

#define DLG_IRH2C01_002 "dlg_IR_H2C01_002"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"

vector<string> mdlPartnumbers;
struct PartnameDescription 
{   // Surendra
	char part_name[PRO_NAME_SIZE];
	char description[PRO_NAME_SIZE];
};
int IRH2C01::IRH2C01_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRH2C01::IRH2C01_002   ==========================");

	mdlPartnumbers.clear();

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRH2C01_002, DLG_IRH2C01_002);
	status = ProUIDialogAboveactivewindowSet(DLG_IRH2C01_002, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2C01_002, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2C01_002, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRH2C01_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRH2C01_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	SubModuleInfo _reqSFHSMinfo, _reqSCHSMinfo;
	vector<PartnameDescription> reqComps;

	status = ProMdlCurrentGet(&curMdl);
	ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

	status = ProSolidFeatVisit((ProSolid)curMdl, getPartnameAction, UserAsmCompFilter, (ProAppData*)&reqComps);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

	ruleLog.Write("subModulesList.size(): " + to_string(subModulesList.size()));

	for (int i = 0; i < subModulesList.size(); ++i) {
		ruleLog.Write("subModulesList.name: " + string(subModulesList[i].name));
		if (subModulesList[i].name.find("H2C01") != std::string::npos) {
			_reqSFHSMinfo = subModulesList[i];
			ruleLog.Write("reqSFHSMinfo.name: " + string(_reqSFHSMinfo.name));
			break;
		}
	}


	for (int i = 0; i < subModulesList.size(); ++i) 
	{
		ruleLog.Write("subModulesList.name: " + string(subModulesList[i].name));
		if (subModulesList[i].name.find("H2A02") != std::string::npos) 
		{
			_reqSCHSMinfo = subModulesList[i];
			ruleLog.Write("reqSCHSMinfo.name: " + string(_reqSCHSMinfo.name));
			break;
		}
	}

	char cReqMdlPath[PRO_PATH_SIZE];
	ProPath wReqMdlPath;
	ProModelitem reqMdlitem;
	ProParameter GBFamilyDesc;
	ProParamvalue GBFamilyDescget;
	ProUnititem pGBDescUnit;
	ProName pDescreption = L"DESCRIPTION";
	char FrontParaName[PRO_NAME_SIZE];
	char ClutchParaName[PRO_NAME_SIZE];
	ProMdl reqMdl;

	// GB family desc get for single front housing
	sprintf(cReqMdlPath, "%s%s.asm", cCurMdlPath, _reqSFHSMinfo.name.c_str());
	ruleLog.Write("cReqMdlPath: " + string(cReqMdlPath));
	ProStringToWstring(wReqMdlPath, cReqMdlPath);
	status = ProMdlnameRetrieve(wReqMdlPath, PRO_MDLFILE_ASSEMBLY, &reqMdl);
	ruleLog.Write("ProMdlnameRetrieve: " + to_string(status));
	if (status != PRO_TK_NO_ERROR) return -1;

	status = ProMdlToModelitem(reqMdl, &reqMdlitem);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	status = ProParameterInit(&reqMdlitem, pDescreption, &GBFamilyDesc);
	ruleLog.Write("ProParameterInit: " + to_string(status));

	status = ProParameterValueWithUnitsGet(&GBFamilyDesc, &GBFamilyDescget, &pGBDescUnit);
	ProWstringToString(FrontParaName, GBFamilyDescget.value.s_val);
	ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\texisting desc: " + string(FrontParaName));

	string sfhStringName, schStringName;
	sfhStringName += FrontParaName;

	// GB family desc get for single front housing
	sprintf(cReqMdlPath, "%s%s.asm", cCurMdlPath, _reqSCHSMinfo.name.c_str());
	ruleLog.Write("cReqMdlPath: " + string(cReqMdlPath));
	ProStringToWstring(wReqMdlPath, cReqMdlPath);
	status = ProMdlnameRetrieve(wReqMdlPath, PRO_MDLFILE_ASSEMBLY, &reqMdl);
	ruleLog.Write("ProMdlnameRetrieve: " + to_string(status));
	if (status != PRO_TK_NO_ERROR) return -1;

	status = ProMdlToModelitem(reqMdl, &reqMdlitem);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	status = ProParameterInit(&reqMdlitem, pDescreption, &GBFamilyDesc);
	ruleLog.Write("ProParameterInit: " + to_string(status));

	status = ProParameterValueWithUnitsGet(&GBFamilyDesc, &GBFamilyDescget, &pGBDescUnit);
	ProWstringToString(ClutchParaName, GBFamilyDescget.value.s_val);
	ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\texisting desc: " + string(ClutchParaName));

	schStringName += ClutchParaName;

	ruleLog.Write("\n front string para " + sfhStringName);
	ruleLog.Write("\n clutch string para  " + schStringName);

	string frontHsgPartNumber, clutchHsgPartNumber;
	vector<vector<string>> dbList2D = getData2D("IRH2C01002.csv");

	ruleLog.Write("\ndbList2D.size(): " + to_string(dbList2D.size()));

	string sfh, sch;
	vector<string> sfhparts, schparts;

	for (int i = 1; i < dbList2D.size(); i++)	// i = 1 for skipping the headers
	{
		size_t position = sfhStringName.find(dbList2D[i][5]);
		size_t position2 = schStringName.find(dbList2D[i][5]);

		if (position != std::string::npos) {
			ruleLog.Write("front Part number: " + string(dbList2D[i][2]));
			frontHsgPartNumber = string(dbList2D[i][2]);
			sfh.append(frontHsgPartNumber).append(" ");
			sfhparts.push_back(frontHsgPartNumber);
		}
		if (position2 != std::string::npos) {
			ruleLog.Write("Clutch Part number: " + string(dbList2D[i][1]));
			clutchHsgPartNumber = string(dbList2D[i][1]);
			sch.append(clutchHsgPartNumber).append(" ");
			schparts.push_back(clutchHsgPartNumber);
		}
	}

	ruleLog.Write("sfh: " + sfh);
	ruleLog.Write("sch: " + sch);

	ruleLog.Write("mdlPartnumbers.size(): " + to_string(mdlPartnumbers.size()));
	boolean isfrontHPartNumberFound = false;
	boolean isclutchHPartNumberFound = false;
	string presentFrontPart, presentClutchPart;

	for (int j = 0; j < mdlPartnumbers.size(); j++) {

		ruleLog.Write("mdlPartnumbers: " + string(mdlPartnumbers[j]));

		for (int p = 0; p < sfhparts.size(); p++) {

			if (find(mdlPartnumbers.begin(), mdlPartnumbers.end(), sfhparts[p]) != mdlPartnumbers.end()) {
				isfrontHPartNumberFound = true;
				ruleLog.Write("\nfront Find Part number: " + frontHsgPartNumber);
				presentFrontPart = sfhparts[p];
				break;
			}
		}
		for (int c = 0; c < schparts.size(); c++) {

			if (find(mdlPartnumbers.begin(), mdlPartnumbers.end(), schparts[c]) != mdlPartnumbers.end()) {
				isclutchHPartNumberFound = true;
				ruleLog.Write(" clutch Find Part number: " + clutchHsgPartNumber);
				presentClutchPart = schparts[c];
				break;
			}
		}
	}

	string remarkfail = "";
	string remarkpass = "";
	remarkfail += " Front housing GearBox family Description : " + sfhStringName + ",\n Clutch housing GearBox family Description :" + string(schStringName).c_str() + "\n\n Standard Single Front housing as per GB family is not available in " + _reqSFHSMinfo.name.c_str() + ",\nStandard Single Clutch housing as per GB family is not available in " + _reqSCHSMinfo.name.c_str() + "\n\nAcceptance Criteria : \n1.Single Front Housing any of the below Part should be present in respective sub - module.\n " + sfh.c_str() + "\n2.Single Clutch housing: \n"+ +sch.c_str();
	remarkpass += " Front housing GearBox family Description : " + sfhStringName + ",\n Clutch housing GearBox family Description :" + string(schStringName).c_str() + "\n\n For " + _reqSFHSMinfo.name.c_str() + ", Found Single Front housing part no.as per GB family is = " + presentFrontPart.c_str() + "\n For " + _reqSCHSMinfo.name.c_str() + ", Found Single Clutch housing part no.as per GB family is = " + presentClutchPart.c_str() + "\n\nAcceptance Criteria : \n1.Single Front Housing any of the below Part should be present in respective sub - module.\n " + sfh.c_str() + "\n2.Single Clutch housing: \n" + +sch.c_str();
	//DECLARE RESULT
	if ((isfrontHPartNumberFound == false) || (isclutchHPartNumberFound == false)) {
		final_res.result = "FAIL";
		final_res.remark = string(remarkfail);
	}
	else {
		final_res.result = "PASS";
		final_res.remark = string(remarkpass);
	}
	ruleLog.Write("status: " + string(final_res.result));
	ruleLog.Write("remark: " + string(final_res.remark));

	remarkfail.clear();
	remarkpass.clear();

	status = ProUIDialogDestroy(DLG_IRH2C01_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));

	return 0;
}

ProError getPartnameAction(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("----------------------------- getParameterDescAndPartname -----------------------------");

	vector<PartnameDescriptionPair>* prtname_desc_list = (vector<PartnameDescriptionPair>*)app_data;
	ProMdlType subModuleMdlType;
	ProModelitem modelItem;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ProMdl reqMdl;
	char existingPval[PRO_NAME_SIZE]{};
	PartnameDescriptionPair compd{};

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
	if (status == PRO_TK_NO_ERROR)
	{
		status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
		ruleLog.Write("ProMdlTypeGet: " + to_string(status));
		status = ProMdlMdlnameGet(reqMdl, wFeatName);
		ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
		ProWstringToString(cFeatName, wFeatName);

		if (subModuleMdlType == PRO_MDL_ASSEMBLY)
		{
			ProSolidFeatVisit((ProSolid)reqMdl, getPartnameAction, UserAsmCompFilter, (ProAppData)app_data);
		}
		else if (subModuleMdlType == PRO_MDL_PART)
		{
			status = ProMdlToModelitem(reqMdl, &modelItem);
			ruleLog.Write("ProMdlToModelitem: " + to_string(status));
			strcpy(compd.part_name, cFeatName);
			mdlPartnumbers.push_back(compd.part_name);
			//ProSolidFeatVisit((ProSolid)reqMdl, getPartnameAction, UserAsmCompFilter, (ProAppData)app_data);
		}
	}
	return status;
}

ProError UserAsmCompFilter(ProFeature* p_feature, ProAppData app_data)
{
	ProFeattype feat_type;
	status = ProFeatureTypeGet(p_feature, &feat_type);

	return (feat_type == PRO_FEAT_COMPONENT ? PRO_TK_NO_ERROR : PRO_TK_CONTINUE);
}