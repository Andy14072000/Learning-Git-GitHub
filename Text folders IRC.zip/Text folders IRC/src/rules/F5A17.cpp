/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 18-04-2023	| V1_0_0		| F5A17 - BRAKING SYSTEM RULES
==================================================================================================================*/
#include "F5A17.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES					| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F5A17-001	| Mathanprasath A	| MF5A17; MF3B05; MF3B06; MF3B01	| Air processing unit clearance with the Exhaust System to be defined.
===================================================================================================================*/
// UI DEFINITIONS
#define DLG_IRF5A17_001	"dlg_IR_F5A17_001" 
#define PB_RCLOSE		"CommitClose"
#define PB_ROK			"CommitOK"
#define PB_RMEASURE		"pb_measure"
// GLOBAL
ComponentData _reqComps1[4]{};
double STD_CLEARANCE_F5A17001 = 120.0;
string remark_msg;
int IRF5A17::IRF5A17_001(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5A17::IRF5A17_001   ==========================");
	final_res.remark.clear();
	string reqCompSubMod[4] = { "F5A17", "F3B01", "F3B05", "F3B06" };
	string comp_names[4];
	double clearance_vals[3];
	remark_msg.clear();
	isUserQuits = false;

	for (int i = 0; i < subModulesList.size(); ++i) {
		for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j) {
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos) {
				strcpy(_reqComps1[j].name, subModulesList[i].name.c_str());
				comp_names[j] = subModulesList[i].name;
			}
		}
	}

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps1);

	for (auto elem : _reqComps1)
	{
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}

	/*ProUIMessageButton btn_choice = UserDisplayPopupMessage_OK_CANCEL(PROUIMESSAGE_INFO, "Confirmation", "Click OK to run the rule.\n\nThis may take a moment to compute distances between the components.");
	if(btn_choice == PRO_UI_MESSAGE_CANCEL)
		return -1;
	for(int i =1; i < sizeof(_reqComps)/sizeof(_reqComps[0]); ++i)
		rule_sts = measureDistanceBetweenComponents(_reqComps[0], _reqComps[i], clearance_vals[i-1]);*/

		// DISPLAY RESULTS IN DIALOG
	status = ProUIDialogCreate(DLG_IRF5A17_001, DLG_IRF5A17_001);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF5A17_001, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A17_001, PB_RCLOSE, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A17_001, PB_RMEASURE, (ProUIAction)measure_action_IR_F5A17_001, (ProAppData)&clearance_vals);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A17_001, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

	//ProUIColor uiColor;
	//if(int(clearance[i-1] >= 120))
	//{
	//	uiColor = PRO_UI_COLOR_RGB(210, 255, 210);	//green
	//	ruleLog.Write("ProUIInputpanelBackgroundcolorSet: green");
	//}
	//else
	//{
	//	uiColor = PRO_UI_COLOR_RGB(255, 210, 210);	//red
	//	ruleLog.Write("ProUIInputpanelBackgroundcolorSet: red");
	//}
	//status = ProUIInputpanelBackgroundcolorSet(DLG_IRF5A17_001, cIpName, PRO_UI_COLOR_RED);
	//ruleLog.Write("ProUIInputpanelBackgroundcolorSet: "+to_string(status));

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF5A17_001, &dlg_sts);
	status = ProUIDialogDestroy(DLG_IRF5A17_001);
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	isRightValue = true;
	string measured_vals;
	for (auto clear_val : clearance_vals)
	{
		string sClearance = to_string(clear_val);
		size_t dotPos = sClearance.find_first_of('.');
		measured_vals.append(sClearance.substr(0, dotPos + 3));	// truncate to two decimal places
		measured_vals.append("mm, ");
		if (clear_val < STD_CLEARANCE_F5A17001)
			isRightValue = false;
	}
	sprintf(remark, "Acceptance criteria: The minimum standard clearance of %0.2lfmm to be maintained.", STD_CLEARANCE_F5A17001);
	final_res.remark = remark_msg + string(remark);

	// DECLARE RESULT
	if (isRightValue)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	return 0;
	//return -1;


}

ProError measure_action_IR_F5A17_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  measure_action_IR_F5A17_001  --------------------------");
	int rule_sts;
	InterfaceRule iRule;
	double* clearances = (double*)data;

	remark_msg += "Measured values:\n";
	remark_msg += "Clearance between " + string(_reqComps1[0].name);
	for (int i = 1; i < 4; ++i)
	{
		string m_value;
		rule_sts = iRule.measureDistanceBetweenComponents(_reqComps1[0], _reqComps1[i], clearances[i - 1]);
		clearances[i - 1] = round(clearances[i - 1] * 100) / 100;	// rounding to two decimal
		;

		remark_msg += " and " + string(_reqComps1[i].name) + " is " + string(doubleToString(clearances[i - 1])) + "mm\n";
		char ipVal[50], ipName[50];
		wchar_t wIpVal[50];
		ProTKSprintf(ipName, "ip%d", i);
		if (clearances[i - 1] >= STD_CLEARANCE_F5A17001)
			ProTKSprintf(ipVal, "%0.2lfmm [Pass]", clearances[i - 1]);
		else
			ProTKSprintf(ipVal, "%0.2lfmm [Fail]", clearances[i - 1]);

		status = ProUIInputpanelEnable(dialog, ipName);
		status = ProUIInputpanelValueSet(dialog, ipName, ProStringToWstring(wIpVal, ipVal));
		status = ProUIInputpanelReadOnly(dialog, ipName);
	}
	status = ProUIPushbuttonEnable(dialog, PB_ROK);

	return PRO_TK_NO_ERROR;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES					| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F5A17-003	| Pallavi Garodi	| MF5A17; MF1A01	| Clearance of APU with Chassis static parts to be maintained like Chassis cross member, brackets etc.
===================================================================================================================*/
 //UI DEFINITIONS

#define DLG_F5A17_003	  "dlg_IR_F5A17_003"
#define SELECT_PARTS_PB   "select_pb"
#define MEASURE_PART_PB	  "measure_pb"


ComponentData			  reqComps_f5a17_003[1];
ProSelection* part_sel;
int	                      n_sel_1;
vector<output_vals>       VALUES;
output_vals               _temp;
double			          Output;

int IRF5A17::IRF5A17_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5A07::IRF5A07_002   ==========================");

	char				formattedNumber[20];
	string				rem_message;
	//output = 0;

	string reqCompSubModAuto[1] = { "F5A17" };	// F5A17 will be selected Automatically.
	for (int i = 0; i < subModulesList.size(); ++i) {
		for (int j = 0; j < sizeof(reqCompSubModAuto) / sizeof(reqCompSubModAuto[0]); ++j) {
			if (subModulesList[i].name.find(reqCompSubModAuto[j]) != string::npos) {
				strcpy(reqComps_f5a17_003[j].name, subModulesList[i].name.c_str());
			}
		}
	}
	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&reqComps_f5a17_003);
	for (auto elem : reqComps_f5a17_003) {
		ruleLog.Write("reqComps_f5a07_002[].name = " + string(elem.name));
		ruleLog.Write("reqComps_f5a07_002[].id = " + to_string(elem.id));
	}

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_F5A17_003, DLG_F5A17_003);
	status = ProUIDialogAboveactivewindowSet(DLG_F5A17_003, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_F5A17_003, RULE_UI_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F5A17_003, RULE_UI_OK, (ProUIAction)ruleDlgOKaction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F5A17_003, SELECT_PARTS_PB, (ProUIAction)select_action_IRF5A17_003, (ProAppData)&isUserQuits);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_F5A17_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_F5A17_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	//DECLARE RESULT
	for (auto elem : reqComps_f5a17_003)
		rem_message += "Clearance between " + string(elem.name) + ".ASM and\n";

	for (int i = 0; i < n_sel_1; ++i)
	{		// rounding the values to two decimal place
		VALUES.at(i).Distance = round(VALUES.at(i).Distance * 100) / 100;

		// Remove trailing zeros from the second decimal place
		sprintf(formattedNumber, "%.2f", VALUES.at(i).Distance);
		int length = strlen(formattedNumber);
		while (length > 0 && formattedNumber[length - 1] == '0') {
			formattedNumber[length - 1] = '\0';
			length--;
		}
		ruleLog.Write(formattedNumber);
		//DECLARE RESULT
		rem_message += string(VALUES.at(i).name) + ".PRT = " + string(formattedNumber) + "mm\n";
	}

	rem_message += "\nAcceptance criteria : > 20.00 mm.";

	double acceptedClearance = 20.0;
	final_res.remark = rem_message;

	//DECLARE RESULT
	for (int i = 0; i < n_sel_1; ++i)
	{
		ruleLog.Write(to_string(VALUES.at(i).Distance));
		if (VALUES.at(i).Distance < 20.0)
		{
			final_res.result = "FAIL";
			break;
		}
		else
		{
			final_res.result = "PASS";
		}
	}

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	//final_res.result.clear();
	VALUES.clear();
	return 0;

}

ProError select_action_IRF5A17_003(char* dialog, char* component, ProAppData data)
{
	int               curWinId;
	InterfaceRule     _irule;
	int				  rule_sts;
	ProAsmcomppath	  part_asmcomp_path;
	ProMdl	          parent_mdl;
	wchar_t           wParentMdlName[PRO_NAME_SIZE];
	char              cParentMdlName[PRO_NAME_SIZE];
	ProAsmcomppath    path;

	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);
	//status = ProUIDialogHide(DLG_F5A17_003);

	status = ProSelect((char*)"prt_or_asm", -1, NULL, NULL, NULL, NULL, &part_sel, &n_sel_1);
	ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sel_1));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_F5A17_003, PB_ROK);
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide inputs again!. Refer help document for details.");
		status = ProUIDialogShow(DLG_F5A17_003);
		return status;
	}

	if (n_sel_1 < 1 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIDialogShow(DLG_F5A17_003);
		status = ProUIPushbuttonDisable(DLG_F5A17_003, PB_ROK);
		return status;
	}

	for (int i = 0; i < n_sel_1; ++i)
	{
		status = ProSelectionAsmcomppathGet(part_sel[i], &part_asmcomp_path);
		ruleLog.Write("ProSelectionAsmcomppathGet = " + to_string(status));

		// to find the parent component
		path.comp_id_table[path.table_num - 1] = -1;
		path.table_num = path.table_num - 1;

		status = ProAsmcomppathMdlGet(&part_asmcomp_path, &parent_mdl);
		ruleLog.Write("ProAsmcomppathMdlGet = " + to_string(status));

		status = ProMdlMdlnameGet(parent_mdl, wParentMdlName);
		ProWstringToString(cParentMdlName, wParentMdlName);
		ruleLog.Write("cParentMdlName = " + (string)cParentMdlName);

		//  Compute distances
		rule_sts = _irule.measureDistanceBetweenAsmAndPart(reqComps_f5a17_003[0], &part_sel[i], Output);
		if (Output < 20) {
			ProWindowRepaint(curWinId);
			status = ProSelectionHighlight(part_sel[i], PRO_COLOR_HIGHLITE);
			ruleLog.Write("ProSelectionHighlight = " + to_string(status));
		}

		_temp.Distance = Output;

		strcpy(_temp.name, cParentMdlName);
		ruleLog.Write(_temp.name);
		VALUES.push_back(_temp);

	}

	status = ProUIDialogShow(DLG_F5A17_003);
	status = ProUIPushbuttonEnable(DLG_F5A17_003, RULE_UI_OK);

	return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES		| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F5A17-004	| Vinay Neel    	| MF5A17; MF2C01	    | Clearance of APU with Chassis dynamic parts to be maintained as 40 mm..
===================================================================================================================*/

#define DLG_IRF5A17_004 "dlg_IR_F5A17_004"
#define PB_ROK			"rule_ok_pb"
#define PB_RCANCEL		"rule_cancel_pb"

int IRF5A17::IRF5A17_004(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF5A27::IRFA27_004   ==========================");

	ComponentData _reqComps[4]{};
	string reqCompSubMod[4] = { "F5A17","F2C01","F5A04","F5A16" };//proplellar shaft(F2C01) , rear forward Axle brake(F5A04), spring brake actuator(F5A16)
	double clearance_value[3], std_clearance = 40.0;
	Pro3dPnt pnt_arr1[2], pnt_arr2[2], pnt_arr3[2];

	for (int i = 0; i < subModulesList.size(); ++i)
		for (int j = 0; j < 4; ++j)
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
				strcpy(_reqComps[j].name, subModulesList[i].name.c_str());

	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqComps);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));

	for (auto elem : _reqComps) {
		ruleLog.Write("_reqComps[].name = " + string(elem.name));
		ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
	}

	isUserQuits = false;

	status = ProUIDialogCreate(DLG_IRF5A17_004, DLG_IRF5A17_004);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF5A17_004, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A17_004, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF5A17_004, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF5A17_004, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF5A17_004);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	for (int i = 0; i < 3; ++i) {
		deleteDatumPoint("datum_PNT1");
		deleteDatumPoint("datum_PNT2");
	}

	if (isUserQuits)
		return -1;


	rule_sts = measureDistanceBetweenComponentsF5A17(_reqComps[0], _reqComps[1], clearance_value[0], pnt_arr1);
	createDatumPoints(pnt_arr1, "CSYS_ASM_DEF", "Dist_highlght_pnt_1");
	rule_sts = measureDistanceBetweenComponentsF5A17(_reqComps[0], _reqComps[2], clearance_value[1], pnt_arr2);
	createDatumPoints(pnt_arr2, "CSYS_ASM_DEF", "Dist_highlght_pnt_2");
	rule_sts = measureDistanceBetweenComponentsF5A17(_reqComps[0], _reqComps[3], clearance_value[2], pnt_arr3);
	createDatumPoints(pnt_arr3, "CSYS_ASM_DEF", "Dist_highlght_pnt_3");


	for (int i = 0; i < 3; ++i) {
		clearance_value[i] = round(clearance_value[i] * 100) / 100;
	}

	isRightValue = true;
	for (auto vals : clearance_value) {
		if (vals < std_clearance && vals != std_clearance) {
			isRightValue = false;
			break;
		}
	}



	// DECLARE RESULT
	sprintf(remark, "Measured values :\nClearance between %s.ASM (APU) and \n -%s.ASM (Propeller shaft)           : %.2lfmm, \n -%s.ASM (Rear forward Axle brake)   : %.2lfmm,\n -%s.ASM (Spring brake actuator)     : %.2lfmm;\nAcceptance criteria: Clearance of APU with Chassis dynamic parts to be maintained as 40.00mm;", _reqComps[0].name, _reqComps[1].name, clearance_value[0], _reqComps[2].name, clearance_value[1], _reqComps[3].name, clearance_value[2]);
	final_res.remark = string(remark);

	if (isRightValue)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	return 0;
}

int measureDistanceBetweenComponentsF5A17(ComponentData reqComp1, ComponentData reqComp2, double& distance, Pro3dPnt(&pnt_arr)[2])
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenComponents <=================");

	ProSelection sels[2];
	ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected
	ProIdTable idtbl2 = { reqComp2.id };		// component id of the component 2 to be selected

	ProName comp1_name, comp2_name;
	ProModelitem feature[2];
	ProMdl reqMdls[2];

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);

	ProStringToWstring(comp2_name, reqComp2.name);
	status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
	status = ProMdlToModelitem(reqMdls[1], &feature[1]);

	ProAsmcomppath path[2];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl2, 1, &path[1]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));
	status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	ProBoolean is_interference_found;
	//Pro3dPnt pnt_arr[2];
	status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_FROM_QUILTS, sels[1], PRO_FIT_INCLUDE_TO_QUILTS, PRO_FIT_WHOLE_SURFACE, sels[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));

	return 0;
}

#pragma pop