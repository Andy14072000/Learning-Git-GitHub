/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| H2D01 - REAR AXLE RULES
==================================================================================================================*/
#include "H2D01.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-H2D01-001	| Prajakta Bhelawe	| MH2D01; MF1A01	| One track width RA family per product line- should be in accordance with frame architecture.
===================================================================================================================*/
#define DLG_IRH2D01_001 "dlg_IR_H2D01_001"
#define PB_RCANCEL      "CommitCancel"
#define PB_RSELECT		"pb_select"
#define PB_ROK			"pb_ok"
#define PB_IMG			"pb_img"

ProSelection* selection1 = nullptr;
int n_selectionH2D01;
double track_width;
double track_width_CSV;
boolean isRightVal1;
string strExistingValue;
string numericPart;
string remarkH2D01;
double track_width_match;

vector<string> TrackWidthList;
vector<string> AddDistanceList;
string RA_family;
double distanceMeasured;
double track_width_not_match;
boolean trackWidthMathFound;
boolean RA_familyFound = false;

int IRH2D01::IRH2D01_001(ruleResult& final_res)
{

	ruleLog.Write("==========================   IRH2D01::IRH2D01_001   ==========================");

	vector<vector<string>> dbList2D = getData2D("IRH2D01001.csv");
	ruleLog.Write("dbList2D.size(): " + to_string(dbList2D.size()));

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRH2D01_001, DLG_IRH2D01_001);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRH2D01_001, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2D01_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2D01_001, PB_ROK, (ProUIAction)run_action_IRH2D01001, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2D01_001, PB_RSELECT, (ProUIAction)select_action_IRH2D01001, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUIPushbuttonDisable(DLG_IRH2D01_001, PB_ROK);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRH2D01_001, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRH2D01_001);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	for (int i = 1; i < dbList2D.size(); ++i)	// i = 1 for skipping the headers
	{
		if (strExistingValue == dbList2D[i][1]) {
			RA_family = (dbList2D[i][1]);
			RA_familyFound = true;

			ruleLog.Write("RA Family = " + dbList2D[i][1]);
			ruleLog.Write("RA Family added");

			TrackWidthList.push_back(dbList2D[i][2]);
			string tok1;
			std::istringstream ss1(dbList2D[i][2]);
			while (std::getline(ss1, tok1, ';'))
			{
				ruleLog.Write("tok1 = " + tok1);
				TrackWidthList.push_back(tok1);
			}

			AddDistanceList.push_back(dbList2D[i][4]);
			string tok2;
			std::istringstream ss2(dbList2D[i][4]);
			while (std::getline(ss2, tok2, ';'))
			{
				ruleLog.Write("tok2 = " + tok2);
				AddDistanceList.push_back(tok2);
			}
		}
	}

	if (RA_familyFound == false)
	{
		remarkH2D01 += "RA FAMILY NOT FOUND. PLEASE UPDATE THE DATABASE. ";
		final_res.remark = remarkH2D01;
		return 0;
	}

	for (int i = 1; i < AddDistanceList.size(); i++)
	{
		ruleLog.Write("AddDistanceList[i] = " + (AddDistanceList[i]));
		track_width = distanceMeasured + stod((AddDistanceList[i]));
		ruleLog.Write("Total Distance = " + to_string(round(track_width)));

		for (int j = 0; j < TrackWidthList.size(); j++)
		{
			ruleLog.Write("TrackWidthList = " + TrackWidthList[j]);
			if (round(track_width) == stod(TrackWidthList[j]))
			{
				track_width_match = track_width;
				ruleLog.Write("track_width = " + to_string(track_width));
				trackWidthMathFound = true;
				break;
			}

			else
			{
				int nearest = stod(TrackWidthList[0]);
				int minDifference = abs(track_width - nearest);

				for (int k = 0; k < TrackWidthList.size(); k++)
				{
					int difference = abs(track_width - stod(TrackWidthList[k])); // Calculate the absolute difference
					if (difference < minDifference) {
						minDifference = difference; // Update the minimum difference
						nearest = stod(TrackWidthList[k]);
					}


					track_width_not_match = (track_width);
					trackWidthMathFound = false;
				}
			}
		}
	}

	remarkH2D01 += "RA_family = " + RA_family + "\n";
	if (trackWidthMathFound == true)
	{
		ruleLog.Write("inside true");
		final_res.result = "PASS";

		string strTrack_width_match;
		strTrack_width_match = to_string(track_width_match);

		string result;
		size_t dotPos = strTrack_width_match.find('.');

		if (dotPos != std::string::npos) {
			// Check if there are at least two characters after the decimal point
			if (dotPos + 3 <= strTrack_width_match.size()) {
				result = strTrack_width_match.substr(0, dotPos + 3);  // Include the dot and two characters after
			}
			else {
				// Less than two characters after the decimal point
				result = strTrack_width_match.substr(0, dotPos + 1);  // Include only up to the decimal point
			}
		}
		else {
			// No decimal point found
			result = strTrack_width_match;
		}

		ruleLog.Write("result " + (result));
		remarkH2D01 += "Measured Track Width = " + (result)+"mm.";
	}

	else
	{
		ruleLog.Write("inside false");
		final_res.result = "FAIL";
		remarkH2D01 += "Measured Track Width = ";

		string strTrack_width_not_match;
		strTrack_width_not_match = to_string(track_width_not_match);

		string result;
		size_t dotPos = strTrack_width_not_match.find('.');

		if (dotPos != std::string::npos) {
			// Check if there are at least two characters after the decimal point
			if (dotPos + 3 <= strTrack_width_not_match.size()) {
				result = strTrack_width_not_match.substr(0, dotPos + 3);  // Include the dot and two characters after
			}
			else {
				// Less than two characters after the decimal point
				result = strTrack_width_not_match.substr(0, dotPos + 1);  // Include only up to the decimal point
			}
		}
		else {
			// No decimal point found
			result = strTrack_width_not_match;
		}

		remarkH2D01 += (result)+"mm, ";
	}


	remarkH2D01 += "\nAccepted Track Width = ";
	for (int i = 1; i < TrackWidthList.size(); i++)
	{
		remarkH2D01 += TrackWidthList[i] + ".00mm, ";
	}
	final_res.remark = string(remarkH2D01);

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	track_width = 0;
	track_width_CSV = 0;
	TrackWidthList.clear();
	AddDistanceList.clear();
	track_width_not_match = 0;
	trackWidthMathFound = false;
	RA_familyFound = false;
	remarkH2D01.clear();

	return 0;
}

ProError select_action_IRH2D01001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRH2D01001 -----------------------------");

	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &selection1, &n_selectionH2D01);
	ruleLog.Write("Proselect status= " + to_string(status) + "\nNo.of Selection " + to_string(n_selectionH2D01));

	if (status == PRO_TK_NO_ERROR && n_selectionH2D01 == 2) {
		status = ProUIPushbuttonEnable(dialog, PB_ROK);
	}

	return status;
}

ProError run_action_IRH2D01001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- run_action_IRH2D01001 -----------------------------");



	ProModelitem sel_model_item;
	ProName name;
	char str_name[PRO_NAME_SIZE];
	ProMdl owner;
	ProModelitem asm_model_item;
	ProName pEnvName = L"PRODUCT";
	ProParameter pEnv;
	ProParamvalue pvEnv;
	char existingValue[PRO_NAME_SIZE];
	//string str;
	ProMdl reqMdl;

	Pro2dPnt param_surfs1, param_surfs2;
	Pro3dPnt pnt_surfs1, pnt_surfs2;

	status = ProSelectionWithOptionsDistanceEval(selection1[0], PRO_B_TRUE, selection1[1], PRO_B_TRUE, param_surfs1, param_surfs2, pnt_surfs1, pnt_surfs2, &distanceMeasured);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance_bw_surfs: " + to_string(distanceMeasured));

	status = ProMdlCurrentGet(&reqMdl);

	/*status = ProSolidFeatVisit((ProSolid)reqMdl, getVisitedCompAsmNamesAction, NULL, NULL);
	ruleLog.Write("ProSolidFeatVisit: " + to_string(status));*/

	status = ProMdlToModelitem(reqMdl, &asm_model_item);
	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));

	status = ProParameterInit(&asm_model_item, pEnvName, &pEnv);
	ruleLog.Write("ProParameterInit: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)
	{
		//to fetch envelope parameters
		status = ProParameterValueWithUnitsGet(&pEnv, &pvEnv, NULL);
		ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + string(ProWstringToString(existingValue, pvEnv.value.s_val)));
		strExistingValue = string(existingValue);
		ruleLog.Write("existingValue = " + strExistingValue);

		regex pattern("\\d+");
		smatch match;
		if (regex_search(strExistingValue, match, pattern)) {
			numericPart = match.str();
			ruleLog.Write("numericPart = " + numericPart);
		}
	}


	//for (int i = 0; i < MapCSVList.size(); i++)
	//{
	//	for (int j = 0; j < MapCSVList[i].RA_family.size(); j++)
	//	{

	//		if (MapCSVList[i].RA_family[j] == numericPart)
	//		{

	//			ruleLog.Write("MapCSVList[i].RA_Family = " + MapCSVList[i].RA_family[j] + " Str =" + strExistingValue);
	//			for (int k = 0; k < AddDistanceList.size(); k++)
	//			{
	//				ruleLog.Write("AddDistanceList = " + AddDistanceList[k]);
	//				ruleLog.Write("inside calculating track width manually");
	//				track_width = distance + stod((AddDistanceList[k]));
	//				ruleLog.Write("Total Distance = " + to_string(round(track_width)));

	//				for (int l = 0; l < TrackWidthList.size(); l++)
	//				{
	//					ruleLog.Write("TrackWidthList = " + (TrackWidthList[l]));
	//					ruleLog.Write("track_width = " + to_string((track_width)));
	//					ruleLog.Write("track match found");
	//					if (track_width == stod(TrackWidthList[l]))
	//					{ 
	//					   ruleLog.Write("track_width_CSV = " + to_string(track_width));
	//					   track_width_match.push_back(track_width);

	//					   if ((track_width_match[0]) == stod(TrackWidthList[l]))
	//					   {
	//						ruleLog.Write("Inside true(run_action)");
	//						isRightVal1 = true;
	//						break;
	//					   }
	//					   else
	//					   {
	//						ruleLog.Write("Inside false");
	//						isRightVal1 = false;
	//					   }

	//					  break;
	//					  break;
	//					}
	//				}

	//			}

	//			/*for (int m = 0; m < TrackWidthList.size(); m++) {
	//				ruleLog.Write("track_width_match = " +to_string(track_width_match[0]));
	//				ruleLog.Write("TrackWidthList = " +(TrackWidthList[m]));
	//				if ((track_width_match[0]) == stod(TrackWidthList[m]))
	//				{
	//					ruleLog.Write("Inside true(run_action)");
	//					isRightVal1 = true;
	//					break;
	//				}
	//				else
	//				{
	//					ruleLog.Write("Inside false");
	//					isRightVal1 = false;
	//				}
	//			}*/
	//			break;
	//		}
	//	}
	//}

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-H2D01-002	| ATHARVA PATIL		| MH2D01			| Single Coupling Flange for RA Family.
===================================================================================================================*/

#define DLG_IRH2D01_002		"dlg_IR_H2D01_002"
#define PB_RCANCEL			"CommitCancel"
#define CommitOk			"CommitOk"
#define PB_IMG				"rule_img"

#define Label_PF			"Label_PF"
#define OptionMenu_PF		"OptionMenu_PF"

#define Label_RAF			"Label_RAF"
#define OptionMenu_RAF		"OptionMenu_RAF"

#define Label_SNs			"Label_SNs"
#define OptionMenu_SNs		"OptionMenu_SNs"

#define Label_Sel			"Label_Sel"
#define pb_Select			"pb_Select"


vector<surfaceData>surface_Collect;
vector<surfaceData>smaller_Holes;
ProSelection* surfSelection;
vector<int>id_Table;

//Declare the variables for visiting and creatinng ID table of each comp
Asm_model					models_RA[1000];
int							models_cnt;
Asm_model					Assy_models_RA[1000];
int							Assy_models_cnt;
int							num_of_assy_fixed = 0;
int							model_count;
vector<feat_id_data>		feat_id_data_arr_RE;
int							level;
int							owner_feat_id;
//ProMdl						curr_model_RA;

//Declare the variables for switch cases
double						PCD, diaOfHoles, dim1, dim2, distancePCD, diam, dist11, dist22, measuredPCD, diameter;
int							noOfHoles, raFamily{}, SelCount, holesCount;
Pro2dPnt					param1, param2;
Pro3dPnt					pnt1, pnt2;
ProSelection				edgeSelection, smallEdge;
string						dimen_1, dimen_2, diaa1, platform1, rm_MsgH2D01, msg_1, msgg, pcdRm, smHoleDiaRm, accpt_Crit;
vector<double>				distancess;
const regex					raPattern("(\\d+)");
smatch						number_Found;
bool						method1 = NULL, isPassed{}, isSerrated, isSerratedModel, isTrue{};
ProMdl						flangeMdl;
double						measurements[9];


//Declare strings for writing remarks

string omSel_PF, omSel_RAF;

int IRH2D01::IRH2D01_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRH2D01::IRH2D01_002   ==========================");

	InterfaceRule			iRule;
	ProParameter            pDesc;
	ProParamvalue           pvDesc;
	ProName                 pDescName = L"PRODUCT";
	char                    descriptionValMain[PRO_NAME_SIZE];
	vector<string>			axleFamily;
	int						selCountOm;
	string					rearAxleFamily, msgLine;
	ProUIMessageButton		userChoice;
	bool					omRequired = NULL;

	method1 = NULL;
	//clear the data from previous run
	rm_MsgH2D01.clear();
	distancess.clear();
	smaller_Holes.clear();
	surface_Collect.clear();
	ProWindowRepaint(PRO_VALUE_UNUSED);


	//Call the UI
	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRH2D01_002, DLG_IRH2D01_002);
	status = ProUIDialogAboveactivewindowSet(DLG_IRH2D01_002, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2D01_002, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2D01_002, CommitOk, (ProUIAction)ruleDlgOKaction, NULL);

	status = ProUIPushbuttonActivateActionSet(DLG_IRH2D01_002, pb_Select, (ProUIAction)selectAction_H2D01, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status: " + to_string(status));

	status = ProUIOptionmenuSelectActionSet(DLG_IRH2D01_002, OptionMenu_SNs, (ProUIAction)optionMenuSelectAction1_H2D01, NULL);
	ruleLog.Write("ProUIOptionmenuSelectActionSet :  " + to_string(status));

	status = ProUIOptionmenuSelectActionSet(DLG_IRH2D01_002, OptionMenu_PF, (ProUIAction)optionMenuSelectAction_PF_H2D01, NULL);
	ruleLog.Write("ProUIOptionmenuSelectActionSet :  " + to_string(status));

	status = ProUIOptionmenuSelectActionSet(DLG_IRH2D01_002, OptionMenu_RAF, (ProUIAction)optionMenuSelectAction_RAF_H2D01, NULL);
	ruleLog.Write("ProUIOptionmenuSelectActionSet :  " + to_string(status));

	//hide select button and label
	status = ProUILabelHide(DLG_IRH2D01_002, Label_Sel);
	ruleLog.Write("ProUILabelHide status: " + to_string(status));
	status = ProUIPushbuttonHide(DLG_IRH2D01_002, pb_Select);
	ruleLog.Write("ProUIPushbuttonHide status: " + to_string(status));

	//hide drop down for serrated and its label
	status = ProUILabelHide(DLG_IRH2D01_002, Label_SNs);
	ruleLog.Write("ProUILabelHide status: " + to_string(status));
	status = ProUIOptionmenuHide(DLG_IRH2D01_002, OptionMenu_SNs);
	ruleLog.Write("ProUIOptionmenuHide status: " + to_string(status));

	//hide drop down for PF and its label
	status = ProUILabelHide(DLG_IRH2D01_002, Label_PF);
	ruleLog.Write("ProUILabelHide status: " + to_string(status));
	status = ProUIOptionmenuHide(DLG_IRH2D01_002, OptionMenu_PF);
	ruleLog.Write("ProUIOptionmenuHide status: " + to_string(status));

	//hide drop down for RAF and its label
	status = ProUILabelHide(DLG_IRH2D01_002, Label_RAF);
	ruleLog.Write("ProUILabelHide status: " + to_string(status));
	status = ProUIOptionmenuHide(DLG_IRH2D01_002, OptionMenu_RAF);
	ruleLog.Write("ProUIOptionmenuHide status: " + to_string(status));

	//Disable the Ok button 
	status = ProUIPushbuttonDisable(DLG_IRH2D01_002, CommitOk);
	ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));
	status = ProUIDialogHide(DLG_IRC_MAIN);



	//check if the RA family is mentined in the parameters
	status = ProParameterInit(&curMdlitem, pDescName, &pDesc);
	ruleLog.Write("ProParameterInit main : " + to_string(status));

	status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
	ruleLog.Write("ProParameterValueWithUnitsGet main : " + to_string(status));
	ProWstringToString(descriptionValMain, pvDesc.value.s_val);
	ruleLog.Write("Product : " + (string)descriptionValMain);

	rearAxleFamily.append(descriptionValMain);
	ruleLog.Write("string appended");
	ruleLog.Write("rearAxleFamily: " + rearAxleFamily);

	ruleLog.Write("rearAxleFamily.empty() : " + to_string(rearAxleFamily.empty()));

	if (rearAxleFamily.empty() == false)
	{
		ruleLog.Write("Entered not empty loop");
		//There is some string value available in rearAxleFamily variable
		//To take users concurence that the string available at *rearAxleFamily* represents a RA family and not some random string


		msgLine += "RA family found in the parameters: " + rearAxleFamily + "\nClick YES to proceed.\nClick No to select it from options ";
		ruleLog.Write("check 1");

		ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
		msg_buttons[0] = PRO_UI_MESSAGE_YES;
		msg_buttons[1] = PRO_UI_MESSAGE_NO;

		userChoice = iRule.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation", msgLine, msg_buttons);
		ruleLog.Write("check 2");

		if (userChoice == PRO_UI_MESSAGE_YES)
		{
			omRequired = false;
			ruleLog.Write("Entered 1 yes loop");
			//get the number out of RA family for assigning it to switch cases
			if (regex_search(rearAxleFamily, number_Found, raPattern))
			{
				raFamily = stoi(number_Found.str());
				ruleLog.Write("Number found in the RA family: " + to_string(raFamily));

				//status = ProUIPushbuttonEnable(DLG_IRH2D01_002, CommitOk);
			}

			//Create the image name 
			char imgName[PRO_NAME_SIZE];
			ProTKSprintf(imgName, "%s/%s.png", "IR_H2D01_002", descriptionValMain);
			ruleLog.Write("image name: " + (string)imgName);
			status = ProUIPushbuttonBitmapSet(DLG_IRH2D01_002, PB_IMG, imgName);
			ruleLog.Write("ProUIPushbuttonBitmapSet status: " + to_string(status));

		}
		else if (userChoice == PRO_UI_MESSAGE_NO)
		{
			ruleLog.Write("Entered 1 no loop");

			//User will select the RA family from drop down
			//Show drop down for PF and its label 
			status = ProUILabelShow(DLG_IRH2D01_002, Label_PF);
			ruleLog.Write("ProUILabelHide status: " + to_string(status));
			status = ProUIOptionmenuShow(DLG_IRH2D01_002, OptionMenu_PF);
			ruleLog.Write("ProUIOptionmenuHide status: " + to_string(status));


			//Show drop down for RAF and its label
			status = ProUILabelShow(DLG_IRH2D01_002, Label_RAF);
			ruleLog.Write("ProUILabelHide status: " + to_string(status));
			status = ProUIOptionmenuShow(DLG_IRH2D01_002, OptionMenu_RAF);
			ruleLog.Write("ProUIOptionmenuHide status: " + to_string(status));
			status = ProUIOptionmenuDisable(DLG_IRH2D01_002, OptionMenu_RAF);
			status = ProUIOptionmenuDisable(DLG_IRH2D01_002, OptionMenu_SNs);
			omRequired = true;

		}
	}
	else if (rearAxleFamily.empty() == true)
	{
		ruleLog.Write("Entered empty loop");

		//RA family is not mentioned in the parameters 
		//Ask user to select it from the drop down
		userChoice = iRule.UserDisplayPopupMessage_OK_CANCEL(PROUIMESSAGE_WARNING, "Attention!!", "RA family not found in the description.\nClick OK to select it from options\nClick Cancel to return to main UI.");
		if (userChoice == PRO_UI_MESSAGE_OK)
		{
			ruleLog.Write("Entered yes loop");

			//Show drop down for PF and its label
			status = ProUILabelShow(DLG_IRH2D01_002, Label_PF);
			ruleLog.Write("ProUILabelHide status: " + to_string(status));
			status = ProUIOptionmenuShow(DLG_IRH2D01_002, OptionMenu_PF);
			ruleLog.Write("ProUIOptionmenuHide status: " + to_string(status));

			//Show drop down for RAF and its label
			status = ProUILabelShow(DLG_IRH2D01_002, Label_RAF);
			ruleLog.Write("ProUILabelHide status: " + to_string(status));
			status = ProUIOptionmenuShow(DLG_IRH2D01_002, OptionMenu_RAF);
			ruleLog.Write("ProUIOptionmenuHide status: " + to_string(status));
			status = ProUIOptionmenuDisable(DLG_IRH2D01_002, OptionMenu_RAF);
			status = ProUIOptionmenuDisable(DLG_IRH2D01_002, OptionMenu_SNs);

			omRequired = true;
		}
		else if (userChoice == PRO_UI_MESSAGE_CANCEL)
		{
			//If user wants to terminate the rule execution
			ruleLog.Write("Entered no loop");
			ProUIDialogDestroy(DLG_IRH2D01_002);
			ProUIDialogShow(DLG_IRC_MAIN);
			return -1;
		}
	}

	//Assign values to variables bsaed on RA family
	switch (raFamily)
	{
		//defining the chracteristics of Different RA families
		case 44: //M-44
		{
			dim1 = 73;
			dim2 = 40;
			diaOfHoles = 4.5;
			method1 = false;
			accpt_Crit = "\nAcceptance Criteria - \ndimensions: 73.00 mm x 40.00 mm , diameter of Hole: 4.50 mm.";
			break;
		}
		case 1055: //RA-1055
		{
			PCD = 100;
			diaOfHoles = 11;
			noOfHoles = 4;
			isSerrated = true;
			method1 = true;
			msg_1 = "Serrated";
			accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 100.00 mm\t,\tDiameter of Holes : 11.00 mm \t,\t Holes Count : 4\t,\t Serrated";
			break;
		}
		case 1068: //RA-1068
		{
			PCD = 112;
			diaOfHoles = 10.3;
			noOfHoles = 8;
			isSerrated = false;
			msg_1 = "Non Serrated";
			method1 = true;
			accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 112.00 mm\t,\tDiameter of Holes : 10.30 mm \t,\t Holes Count : 8\t,\tNon serrated";
			break;
		}
		case 114: //RA-114
		{
			PCD = 150;
			diaOfHoles = 15;
			noOfHoles = 4;
			isSerrated = true;
			msg_1 = "Serrated";
			method1 = true;
			accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 150.00 mm\t,\tDiameter of Holes : 15.00 mm \t,\t Holes Count : 4\t,\tSerrated";
			break;
		}
		case 1085: //RA-1085
		{
			PCD = 112;
			diaOfHoles = 10;
			noOfHoles = 8;
			isSerrated = false;
			msg_1 = "Non Serrated";
			method1 = true;
			accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 112.00 mm\t,\tDiameter of Holes : 10.00 mm \t,\t Holes Count : 8\t,\tNon Serrated";
			break;
		}
		case 109: //RA-109
		{
			PCD = 112;
			diaOfHoles = 10;
			noOfHoles = 8;
			isSerrated = false;
			msg_1 = "Non Serrated";
			method1 = true;
			accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 112.00 mm\t,\tDiameter of Holes : 10.00 mm \t,\t Holes Count : 8\t,\tNon Serrated";
			break;
		}
		case 110: //RA-110
		{
			PCD = 130;
			diaOfHoles = 13;
			noOfHoles = 4;
			isSerrated = true;
			msg_1 = "Serrated";
			method1 = true;
			accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 130.00 mm\t,\tDiameter of Holes : 13.00 mm \t,\t Holes Count : 4\t,\tSerrated";
			break;
		}
		case 210: //RA-210
		{
			PCD = 130;
			diaOfHoles = 13;
			noOfHoles = 4;
			isSerrated = true;
			msg_1 = "Serrated";
			method1 = true;
			accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 130.00 mm\t,\tDiameter of Holes : 13.00 mm \t,\t Holes Count : 4\t,\tSerrated";
			break;
		}
		case 104: //RAS-104
		{
			PCD = 101.6;
			diaOfHoles = 10.5;
			noOfHoles = 6;
			isSerrated = false;
			msg_1 = "Non Serrated";
			method1 = true;
			accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 101.60 mm\t,\tDiameter of Holes : 10.50 mm \t,\t Holes Count : 6\t,\tNon serrated";
			break;
		}
	}


	if (method1 == true)
	{
		/*Method 1 is a boolean set for deciding if it is a special case or not. There is only one special case for now (M-44)
			if method1 is true that means it is not a special case and the regular method can be followed*/

		ruleLog.Write("inside method 1 label show");
		status = ProUILabelShow(DLG_IRH2D01_002, Label_SNs);
		ruleLog.Write("ProUILabelShow : " + to_string(status));
		status = ProUIOptionmenuShow(DLG_IRH2D01_002, OptionMenu_SNs);
		ruleLog.Write("ProUIOptionmenuShow : " + to_string(status));
		ruleLog.Write("Inside method 1 == true");

		ruleLog.Write("before rmmsg 0");
	}
	else if (method1 == false)
	{
		status = ProUILabelShow(DLG_IRH2D01_002, Label_Sel);
		ruleLog.Write("ProUILabelShow status: " + to_string(status));
		status = ProUIPushbuttonShow(DLG_IRH2D01_002, pb_Select);
		ruleLog.Write("ProUIPushbuttonShow status: " + to_string(status));

	}


	status = ProUIDialogActivate(DLG_IRH2D01_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	if (isUserQuits) {
		status = ProUIDialogDestroy(DLG_IRH2D01_002);
		ruleLog.Write("ProUIDialogDestroy close action: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}


	//Close after rule run
	status = ProUIDialogDestroy(DLG_IRH2D01_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogShow: " + to_string(status));

	/*This is a function where actual rule execution happens.
	The function is created to avoid replicating the same code*/

	ruleVerificationFunction(method1);

	//Declare Results
	if (isPassed == true)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	if (omRequired == true)
	{
		rm_MsgH2D01 += "\n\nSelected Platform: " + omSel_PF + "\nSelected RA Family: " + omSel_RAF;
	}
	final_res.remark = rm_MsgH2D01;

	return 0;
}

void ruleVerificationFunction(bool method1)
{
	InterfaceRule irule;

	if (method1 == true)
	{
		//Visit the features of opened submodule
		FILE* fp{};
		level = 1;

		num_of_assy_fixed = 0;

		models_RA[0].Model = curMdl;
		models_RA[0].Model_feat_id = 0;
		models_cnt = 1;
		Assy_models_cnt = 0;

	begin:

		for (int a = 0; a < models_cnt; ++a)
		{
			owner_feat_id = models_RA[a].Model_feat_id;
			status = ProSolidFeatVisit((ProSolid)models_RA[a].Model, (ProFeatureVisitAction)visitActionH2D01, compsFilter, fp);
			ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
		}

		if (Assy_models_cnt > 0)
		{
			++level;
			for (int b = 0; b < Assy_models_cnt; ++b)
			{
				models_RA[b].Model = Assy_models_RA[b].Model;
				models_RA[b].Model_feat_id = Assy_models_RA[b].Model_feat_id;
			}
			models_cnt = Assy_models_cnt;
			Assy_models_cnt = 0;
			goto begin;
		}


		//Evaluate the diameter of surfaces to create a vector of surfaces containing surfaces of smaller hole
		ruleLog.Write("Size of vector is: " + to_string(surface_Collect.size()));

		vector<surfaceData>alternateDiaVec;
		for (int i = 0; i < surface_Collect.size(); i++)
		{
			status = ProSurfaceDiameterEval(surface_Collect.at(i).surface, NULL, &diameter);
			ruleLog.Write("ProSurfaceDiameterEval status: " + to_string(status) + "\nDiameter: " + to_string(diameter));
			surface_Collect.at(i).diameter = diameter;

			/*if diameter of holes in the CAD matches with the standard dia of hole, mentioned in the characteristics of flange,
			then it will be directly stored in a vector .
			if diameter of holes in the CAD does not match with the standard dia of hole, mentioned in the characteristics of flange,
			then the closest dia which will have a value between 5-15 will be stored in another vector .
			This method is incorporated to count the no. of holes without any user interference*/

			if (diameter == diaOfHoles)
			{
				smaller_Holes.push_back(surface_Collect.at(i));
			}
			else if (diameter > 5 && diameter < 15)
			{
				alternateDiaVec.push_back(surface_Collect[i]);
			}
		}


		if (smaller_Holes.size() != 0)
		{
			//Case of measured dia matching with the standard dia 
			smHoleDiaRm = to_string(round(smaller_Holes.at(0).diameter));
			smHoleDiaRm.erase(smHoleDiaRm.find_last_not_of('0') + 3, string::npos);

			//Count the number of holes 
			holesCount = smaller_Holes.size() / 2;
			ruleLog.Write("The number of holes: " + to_string(smaller_Holes.size() / 2));
		}
		else if ((smaller_Holes.size() == 0) && (alternateDiaVec.size() != 0))
		{
			//Case of measured dia differing with the standard dia 
			smHoleDiaRm = to_string(round(alternateDiaVec.at(0).diameter));
			smHoleDiaRm.erase(smHoleDiaRm.find_last_not_of('0') + 3, string::npos);

			//Count the number of holes 
			double target = alternateDiaVec[0].diameter;
			int holesC = 0;
			for (int i = 0; i < alternateDiaVec.size(); i++)
			{
				/*There is a possibility that measured diameters having value betweeen 5-20 can be mulitple
				For ex dia = 11mm , dia = 13 mm.
				This can create confusion while counting the no. of holes
				To avoid this we will count only those holes that are having same dia as of first found smallest dia*/

				if (target == alternateDiaVec[i].diameter)
				{
					holesC++;
				}

			}
			holesCount = holesC / 2;
			ruleLog.Write("The number of holes: " + to_string(holesCount));
		}


		/*measuring the pitch circle diameter with the help of biggest edge of the flange ( it will be outermost) and the edge of a hole*/
		status = ProSelectionWithOptionsDistanceEval(edgeSelection, PRO_B_TRUE, smallEdge, PRO_B_TRUE, param1, param2, pnt1, pnt2, &distancePCD);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval status: " + to_string(status));
		ruleLog.Write("Pitch Circle radius: " + to_string(distancePCD));
		measuredPCD = distancePCD * 2;
		pcdRm = to_string(round(measuredPCD));
		pcdRm.erase(pcdRm.find_last_not_of('0') + 3, string::npos);
		ruleLog.Write("Pitch circle diameter: " + to_string(measuredPCD));

		//writing the remarks
		rm_MsgH2D01 += "\nDetails of flange used: \nPitch Circle Diameter: " + pcdRm +
			" mm , Diameter of Holes : " + smHoleDiaRm + " mm , Holes Count : " +
			to_string(holesCount) + " , " + msgg;

		rm_MsgH2D01 += accpt_Crit;    //Acceptance criteria is defined in the switch cases

		ruleLog.Write("rmmsg check1");

		ruleLog.Write(rm_MsgH2D01);

		ruleLog.Write("msg valu: " + msgg);
		ruleLog.Write("msg1 value: " + msg_1);

		/*Comparing whether the flange is serrated by using user selection from drop down and property defined in the switch cases
		If both matches then we will allow the rule to pass (Only for serrated or non serrated)
		Rest of the properties will be verified in the next step*/

		if (strcmp(msgg.c_str(), msg_1.c_str()) == 0)
		{
			isTrue = true;
		}
		else
			isTrue = false;
		Utils util;

		//Comparing the mesured PCD , no. of holes and dia of holes (Measured vs defined)
		if (util.compareFloat(measuredPCD, PCD) && holesCount == noOfHoles && isTrue == true) {
			isPassed = true;
			ruleLog.Write("isPassed true");
		}
		else
		{
			isPassed = false;
			ruleLog.Write("isPassed false");
		}
	}
	if (method1 == false)
	{
		ruleLog.Write("inside if loop for measurements");

		/*for verifying the rule for M44*/

		int count1 = 0;
		int count2 = 0;

		//For measuring the distnace between randomly selected hole surfaces on M44 nested for loop is incorported
		for (int i = 0; i < SelCount; i++)
		{
			ruleLog.Write("inside first for loop for " + to_string(i) + "^th time");
			for (int j = 0; j < SelCount; j++)
			{
				ruleLog.Write("inside second for loop for " + to_string(j) + "^th time");
				status = irule.measureDistanceBetweenSurfaces(surfSelection[i], surfSelection[j], measurements[count2]);
				ruleLog.Write("measureDistanceBetweenSurfaces status: " + to_string(status));
				if (measurements[count2] > 0)
				{
					ruleLog.Write("inside for loop measurements: ");
					distancess.push_back(measurements[count2]);
					ruleLog.Write("vector pushback");
					count1++;
					ruleLog.Write("count1 = " + to_string(count1));
				}
				count2++;
				ruleLog.Write("count2 = " + to_string(count2));
			}
		}
		ruleLog.Write("out of for loops");

		ruleLog.Write("----------------Measured distances are----------------");
		for (int k = 0; k < distancess.size(); k++)
		{
			ruleLog.Write(to_string(distancess[k]) + "\n");
		}
		ruleLog.Write("------------ sort the vector-------------");
		sort(distancess.begin(), distancess.end(), greater<double>()); //sort the vector containing measurements in descending order
		
		distancess.erase(distancess.begin(), distancess.begin() + 2);  // remove diagonally measured values
		for (int k = 0; k < distancess.size(); k++)
		{
			ruleLog.Write(to_string(distancess[k]) + "\n");
		}


		dimen_1 = to_string(round(distancess.at(0))); // assign the bigger value to dimen1 
		ruleLog.Write("dimen1 without removing zeroes : " + dimen_1);
		dimen_1.erase(dimen_1.find_last_not_of('0') + 3, string::npos);
		ruleLog.Write("dimen1 after removing zeroes : " + dimen_1);

		dimen_2 = to_string(round(distancess.at(2))); // and smaller value to dimen2
		ruleLog.Write("dimen2 without removing zeroes : " + dimen_2);
		dimen_2.erase(dimen_2.find_last_not_of('0') + 3, string::npos);
		ruleLog.Write("dimen2 after removing zeroes : " + dimen_2);


		status = ProGeomitemDiameterEval(surfSelection[0], &diam); // dia of holes on M44
		ruleLog.Write("ProGeomitemDiameterEval status: " + to_string(status) + "\nDiameter: " + to_string(diam));
		diaa1 = to_string(round(diam));
		diaa1.erase(diaa1.find_last_not_of('0') + 3, string::npos);
		Utils util;

		//writing remarks
		rm_MsgH2D01 += "\nDetails of flange - \ndimensions: " + dimen_1 + "mm x " + dimen_2 + "mm , diameter of hole: " + diaa1 + "mm.";
		rm_MsgH2D01 += accpt_Crit;

		//comparing measured vs defined values for declaring the result
		if ((util.compareFloat(dim1, dist11)) && (util.compareFloat(dim2, dist22)) && (util.compareFloat(diam, diaOfHoles)))
			isPassed = true;
		else
			isPassed = false;
	}

}

ProError optionMenuSelectAction1_H2D01(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("---------------optionMenuSelectAction1_H2D01------------");

	//Get the user input regarding serrated or non serrated flange
	int			n_sel;
	string		target;
	char** selValue_Ser_NserOptMenu;

	msgg.erase();
	status = ProUIPushbuttonDisable(dialog, CommitOk);

	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue_Ser_NserOptMenu);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet cb fn: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue_Ser_NserOptMenu[0]));
	msgg.append(selValue_Ser_NserOptMenu[0]);   // msg will be used to declare result about the texture of the flange surface

	if (strcmp(selValue_Ser_NserOptMenu[0], "Select") != 0)
	{
		status = ProUIPushbuttonEnable(dialog, CommitOk);
	}


	return PRO_TK_NO_ERROR;
}

ProError optionMenuSelectAction_PF_H2D01(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("---------------optionMenuSelectAction2_H2D01------------");

	//Get the user input for platform
	int				n_sel;
	string			target;
	char** selValue;

	msgg.erase();
	status = ProUIOptionmenuDisable(dialog, OptionMenu_RAF);
	status = ProUIOptionmenuDisable(dialog, OptionMenu_SNs);
	status = ProUIPushbuttonDisable(dialog, CommitOk);

	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet cb fn: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue[0]));

	vector<string>MHCV = { "Select","RA-1085","RA-109","RA-110","RA-210" };
	vector<string>ILCV = { "Select","RA-1068","RA-1055","RAS-104" };
	vector<string>SCV = { "Select","M-44","M-170","M-180","M-149" };

	char** raFamilyNames;
	wchar_t** raFamilyLabels;
	int sizeOptMenu{};

	//following if loops will create the RA family drop down based on the platform
	if (strcmp(selValue[0], "MHCV") == 0)
	{
		ruleLog.Write("check for MHCV");
		sizeOptMenu = MHCV.size();

		status = ProArrayAlloc(MHCV.size(), sizeof(char*), MHCV.size(), (ProArray*)&raFamilyNames);
		ruleLog.Write("ProArrayAlloc names " + to_string(status));
		status = ProArrayAlloc(MHCV.size(), sizeof(wchar_t*), MHCV.size(), (ProArray*)&raFamilyLabels);
		ruleLog.Write("ProArrayAlloc lables" + to_string(status));

		for (int i = 0; i < MHCV.size(); ++i)
		{
			raFamilyNames[i] = (char*)calloc(5, sizeof(char));
			ProTKSprintf(raFamilyNames[i], "%s", MHCV[i]);

			raFamilyLabels[i] = (wchar_t*)calloc(5, sizeof(wchar_t));
			ProStringToWstring(raFamilyLabels[i], raFamilyNames[i]);
		}

		status = ProUIOptionmenuNamesSet(DLG_IRH2D01_002, OptionMenu_RAF, int(MHCV.size()), raFamilyNames);
		ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
		status = ProUIOptionmenuLabelsSet(DLG_IRH2D01_002, OptionMenu_RAF, int(MHCV.size()), raFamilyLabels);
		ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));
	}
	if (strcmp(selValue[0], "ILCV") == 0)
	{
		ruleLog.Write("check for ILCV");
		sizeOptMenu = ILCV.size();

		status = ProArrayAlloc(ILCV.size(), sizeof(char*), ILCV.size(), (ProArray*)&raFamilyNames);
		ruleLog.Write("ProArrayAlloc names " + to_string(status));
		status = ProArrayAlloc(ILCV.size(), sizeof(wchar_t*), ILCV.size(), (ProArray*)&raFamilyLabels);
		ruleLog.Write("ProArrayAlloc lables" + to_string(status));

		for (int i = 0; i < ILCV.size(); ++i)
		{
			raFamilyNames[i] = (char*)calloc(5, sizeof(char));
			ProTKSprintf(raFamilyNames[i], "%s", ILCV[i]);

			raFamilyLabels[i] = (wchar_t*)calloc(5, sizeof(wchar_t));
			ProStringToWstring(raFamilyLabels[i], raFamilyNames[i]);
		}

		status = ProUIOptionmenuNamesSet(DLG_IRH2D01_002, OptionMenu_RAF, int(ILCV.size()), raFamilyNames);
		ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
		status = ProUIOptionmenuLabelsSet(DLG_IRH2D01_002, OptionMenu_RAF, int(ILCV.size()), raFamilyLabels);
		ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));
	}
	if (strcmp(selValue[0], "SCV") == 0)
	{
		ruleLog.Write("check for SCV");
		sizeOptMenu = SCV.size();

		status = ProArrayAlloc(SCV.size(), sizeof(char*), SCV.size(), (ProArray*)&raFamilyNames);
		ruleLog.Write("ProArrayAlloc names " + to_string(status));
		status = ProArrayAlloc(SCV.size(), sizeof(wchar_t*), SCV.size(), (ProArray*)&raFamilyLabels);
		ruleLog.Write("ProArrayAlloc lables" + to_string(status));

		for (int i = 0; i < SCV.size(); ++i)
		{
			raFamilyNames[i] = (char*)calloc(5, sizeof(char));
			ProTKSprintf(raFamilyNames[i], "%s", SCV[i]);

			raFamilyLabels[i] = (wchar_t*)calloc(5, sizeof(wchar_t));
			ProStringToWstring(raFamilyLabels[i], raFamilyNames[i]);
		}

		status = ProUIOptionmenuNamesSet(DLG_IRH2D01_002, OptionMenu_RAF, int(SCV.size()), raFamilyNames);
		ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
		status = ProUIOptionmenuLabelsSet(DLG_IRH2D01_002, OptionMenu_RAF, int(SCV.size()), raFamilyLabels);
		ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));
	}
	if (strcmp(selValue[0], "Select") != 0)
	{
		status = ProUIOptionmenuEnable(dialog, OptionMenu_RAF);
	}
	omSel_PF = selValue[0];

	return PRO_TK_NO_ERROR;
	//status = ProUIOptionmenuEnable(dialog, OptionMenu_RAF);

}

ProError optionMenuSelectAction_RAF_H2D01(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("---------------optionMenuSelectAction2_H2D01------------");

	//Get the user input for platform
	int				n_sel;
	string			userSel;
	char** selValue;
	char** selValueSNs;
	userSel.clear();
	status = ProUIOptionmenuDisable(dialog, OptionMenu_SNs);
	status = ProUIPushbuttonDisable(dialog, CommitOk);


	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet cb fn: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue[0]));
	userSel.append(selValue[0]);

	if (regex_search(userSel, number_Found, raPattern))
	{
		raFamily = stoi(number_Found.str());
		ruleLog.Write("Number found in the RA family: " + to_string(raFamily));
	}

	//Create the image name 
	char imgName[PRO_NAME_SIZE];
	ProTKSprintf(imgName, "%s/%s.png", "IR_H2D01_002", selValue[0]);
	ruleLog.Write("image name: " + (string)imgName);
	status = ProUIPushbuttonBitmapSet(DLG_IRH2D01_002, PB_IMG, imgName);
	ruleLog.Write("ProUIPushbuttonBitmapSet status: " + to_string(status));

	string					pcdMsg{}, diaOfHole{}, dm1Rm{}, dm2Rm{}, diamm{};
	bool					isTrue{};
	double					measuredPCD, diameter;
	int						holesCount;
	string					pcdRm, smHoleDiaRm;

	//Assign values to variables bsaed on RA family
	switch (raFamily)
	{
	case 44: //M-44
	{
		dim1 = 73;
		dim2 = 40;
		diaOfHoles = 4.5;
		platform1 = "SCV";
		method1 = false;

		accpt_Crit = "\nAcceptance Criteria - \ndimensions: 73.00 mm x 40.00 mm , diameter of Hole: 4.50 mm.";

		status = ProUILabelShow(DLG_IRH2D01_002, Label_Sel);
		ruleLog.Write("ProUILabelShow status: " + to_string(status));
		status = ProUIPushbuttonShow(DLG_IRH2D01_002, pb_Select);
		ruleLog.Write("ProUIPushbuttonShow status: " + to_string(status));

		status = ProUILabelHide(DLG_IRH2D01_002, Label_SNs);
		ruleLog.Write("ProUILabelShow status: " + to_string(status));
		status = ProUIOptionmenuHide(DLG_IRH2D01_002, OptionMenu_SNs);
		ruleLog.Write("ProUIPushbuttonShow status: " + to_string(status));
		break;
	}
	case 1055: //RA-1055
	{
		PCD = 100;
		diaOfHoles = 11;
		noOfHoles = 4;
		isSerrated = true;
		method1 = true;
		msg_1 = "Serrated";
		accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 100.00 mm\t,\tDiameter of Holes : 11.00 mm \t,\t Holes Count : 4\t,\t serrated";
		break;
	}
	case 1068: //RA-1068
	{
		PCD = 112;
		diaOfHoles = 10.3;
		noOfHoles = 8;
		isSerrated = false;
		msg_1 = "Non Serrated";
		method1 = true;
		accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 112.00 mm\t,\tDiameter of Holes : 10.30 mm \t,\t Holes Count : 8\t,\tNon serrated";
		break;
	}
	case 114: //RA-114
	{
		PCD = 150;
		diaOfHoles = 15;
		noOfHoles = 4;
		isSerrated = true;
		msg_1 = "Serrated";
		method1 = true;
		accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 150.00 mm\t,\tDiameter of Holes : 15.00 mm \t,\t Holes Count : 4\t,\tSerrated";
		break;
	}
	case 1085: //RA-1085
	{
		PCD = 112;
		diaOfHoles = 10;
		noOfHoles = 8;
		isSerrated = false;
		msg_1 = "Non Serrated";
		method1 = true;
		accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 112.00 mm\t,\tDiameter of Holes : 10.00 mm \t,\t Holes Count : 8\t,\tNon Serrated";
		break;
	}
	case 109: //RA-109
	{
		PCD = 112;
		diaOfHoles = 10;
		noOfHoles = 8;
		isSerrated = false;
		msg_1 = "Non Serrated";
		method1 = true;
		accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 112.00 mm\t,\tDiameter of Holes : 10.00 mm \t,\t Holes Count : 8\t,\tNon Serrated";
		break;
	}
	case 110: //RA-110
	{
		PCD = 130;
		diaOfHoles = 13;
		noOfHoles = 4;
		isSerrated = true;
		msg_1 = "Serrated";
		method1 = true;
		accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 130.00 mm\t,\tDiameter of Holes : 13.00 mm \t,\t Holes Count : 4\t,\tSerrated";
		break;
	}
	case 210: //RA-210
	{
		PCD = 130;
		diaOfHoles = 13;
		noOfHoles = 4;
		isSerrated = true;
		msg_1 = "Serrated";
		method1 = true;
		accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 130.00 mm\t,\tDiameter of Holes : 13.00 mm \t,\t Holes Count : 4\t,\tSerrated";
		break;
	}
	case 104: //RAS-104
	{
		PCD = 101.6;
		diaOfHoles = 10.5;
		noOfHoles = 6;
		isSerrated = false;
		msg_1 = "Non Serrated";
		method1 = true;
		accpt_Crit = "\nAcceptance Criteria - \nPitch Circle Diameter : 101.60 mm\t,\tDiameter of Holes : 10.50 mm \t,\t Holes Count : 6\t,\tNon serrated";
		break;
	}
	}

	if (method1 == true)
	{
		ruleLog.Write("inside method 1 label show");
		status = ProUILabelShow(DLG_IRH2D01_002, Label_SNs);
		ruleLog.Write("ProUILabelShow : " + to_string(status));
		status = ProUIOptionmenuShow(DLG_IRH2D01_002, OptionMenu_SNs);
		ruleLog.Write("ProUIOptionmenuShow : " + to_string(status));

		status = ProUILabelHide(DLG_IRH2D01_002, Label_Sel);
		ruleLog.Write("ProUILabelShow : " + to_string(status));
		status = ProUIPushbuttonHide(DLG_IRH2D01_002, pb_Select);
		ruleLog.Write("ProUIOptionmenuShow : " + to_string(status));

	}
	else
	{
		ruleLog.Write("Inside method 1 == false");

		status = ProUILabelShow(DLG_IRH2D01_002, Label_Sel);
		ruleLog.Write("ProUILabelShow status: " + to_string(status));
		status = ProUIPushbuttonShow(DLG_IRH2D01_002, pb_Select);
		ruleLog.Write("ProUIPushbuttonShow status: " + to_string(status));

	}

	if (strcmp(selValue[0], "Select") != 0)
	{
		status = ProUIOptionmenuEnable(dialog, OptionMenu_SNs);
	}
	omSel_RAF = selValue[0];

	return PRO_TK_NO_ERROR;
}

ProError visitActionH2D01(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("====== visitActionH2D01 =====");
	ProMdlfileType			comp_type;
	ProFamilyMdlName		comp_name;
	char					part_no[PRO_PATH_SIZE];
	ProAsmcompconstraint* constr_array;
	ProMdl					model;
	ProFeattype				ftype;
	ProAsmcompconstraint	constraint;
	ProAsmcompconstraint* constraints;
	ProPatternStatus 		p_pattern_status;
	ProFeatStatus 			p_status;
	FILE* fp = (FILE*)app_data;



	status = ProFeatureTypeGet(p_feature, &ftype);
	ruleLog.Write("ProFeatureTypeGet status: " + to_string(status));

	if (ftype == PRO_FEAT_COMPONENT)
	{
		ruleLog.Write("Component Level = " + to_string(level));
		status = ProAsmcompMdlMdlnameGet((ProAsmcomp*)p_feature, &comp_type, comp_name);
		ruleLog.Write("ProAsmcompMdlMdlnameGet: " + to_string(status));
		ProWstringToString(part_no, comp_name);
		ruleLog.Write("Part name: " + (string)part_no);
		++model_count;

		feat_id_data  _feat_id_data;

		if (level == 1) {
			ruleLog.Write("inside if loop level ==1 ");
			_feat_id_data.feat_ids[0] = p_feature->id;
			_feat_id_data.level = level;

			feat_id_data_arr_RE.push_back(_feat_id_data);

		}
		else
		{
			for (int j = 0; j < feat_id_data_arr_RE.size(); ++j)
			{
				if (feat_id_data_arr_RE[j].feat_ids[level - 2] == owner_feat_id)
				{
					feat_id_data owner_feat_id_data = feat_id_data_arr_RE[j];
					for (int i = 0; i < level - 1; ++i)
					{
						_feat_id_data.feat_ids[i] = owner_feat_id_data.feat_ids[i];
					}

					_feat_id_data.feat_ids[level - 1] = p_feature->id;
					_feat_id_data.level = level;

					break;
				}

			}

			feat_id_data_arr_RE.push_back(_feat_id_data);
		}

		ProMdlType				subModuleMdlType;
		ProModelitem			subMdlModelItem;
		ProParameter            pDesc;
		ProParamvalue           pvDesc;
		ProName                 pDescName = L"DESCRIPTION";
		char                    descriptionVal[PRO_NAME_SIZE];
		wchar_t					wFeatName[PRO_NAME_SIZE];
		char					cFeatname[PRO_NAME_SIZE];
		const regex				cfpattern("COUPLING FLANGE"), pattern2("PINION"), /*pattern3("COVER"),*/pattern4("NUT"), pattern5("INPUT");
		smatch					matchFound1, matchFound2, matchFound3;
		string					description;
		ProFeature				featHandle;



		status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &model);
		ruleLog.Write("ProAsmcompMdlGet status: " + to_string(status));
		flangeMdl = model; // storing the MDL handle of flange to use it later in the surface visit action

		status = ProMdlTypeGet(model, &subModuleMdlType);
		ruleLog.Write("ProMdlTypeGet status: " + to_string(status));
		if (subModuleMdlType == PRO_MDL_PART)
		{
			status = ProMdlToModelitem(model, &subMdlModelItem);
			ruleLog.Write("ProMdlToModelitem VAS: " + to_string(status));
			status = ProParameterInit(&subMdlModelItem, pDescName, &pDesc);
			ruleLog.Write("ProParameterInit VAS: " + to_string(status));
			if (status != PRO_TK_E_NOT_FOUND)
			{
				status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
				ruleLog.Write("ProParameterValueWithUnitsGet VAS: " + to_string(status));
				ProWstringToString(descriptionVal, pvDesc.value.s_val);
				ruleLog.Write("Description VAS: " + (string)descriptionVal);
				description.erase();
				description.append(descriptionVal);
				ruleLog.Write("Check for regex statement");

				//Checking in the description if it is flange part. 
				if (regex_search(description, matchFound1, cfpattern) && (regex_search(description, matchFound2, pattern2) == 0)
					&& (regex_search(description, matchFound3, pattern4) == 0) && (regex_search(description, matchFound1, pattern5) == 0))
				{
					ruleLog.Write("Size of IdTable found flange: " + to_string(id_Table.size()));
					ruleLog.Write("Check for inside regex search");

					vector<surfaceData>cylSurfaces;
					status = ProSolidSurfaceVisit((ProSolid)model, (ProSurfaceVisitAction)surfVisitAction, NULL, &cylSurfaces);
					ruleLog.Write("ProSolidSurfaceVisit VAS: " + to_string(status));

					sort(cylSurfaces.begin(), cylSurfaces.end(), [](const surfaceData& a, const surfaceData& b) {
						return a.diameter > b.diameter;
						});
					ruleLog.Write("Dia of first element: " + to_string(cylSurfaces.at(0).diameter));

					//Creating ID table for coupling flange
					ProIdTable			comp_id_table;
					int					table_num;
					ProAsmcomppath		p_comp_path;
					table_num = level;
					ruleLog.Write("the table num is: " + to_string(table_num));

					for (int m = 0; m < level; ++m) {
						comp_id_table[m] = _feat_id_data.feat_ids[m];
						ruleLog.Write("comp_ID-Table " + to_string(m) + ": " + to_string(comp_id_table[m]));
					}

					//Initiating Asm Comp path for coupling flange
					status = ProAsmcomppathInit((ProSolid)curMdl, comp_id_table, table_num, &p_comp_path);
					ruleLog.Write("ProAsmcomppathInit status: " + to_string(status));

					//Selecting the biggest edge using its model item and asm comp path of flange
					status = ProSelectionAlloc(&p_comp_path, &cylSurfaces.at(0).modelItem, &edgeSelection);
					ruleLog.Write("ProSelectionAlloc big edge status: " + to_string(status));

					//selecting the smallest edge ( Edge of a hole)
					for (int i = 0; i < cylSurfaces.size(); i++)
					{
						if (cylSurfaces.at(i).diameter == diaOfHoles)
						{
							status = ProSelectionAlloc(&p_comp_path, &cylSurfaces.at(i).modelItem, &smallEdge);
							ruleLog.Write("ProSelectionAlloc small edge status: " + to_string(status));
							break;
						}
						else if ((cylSurfaces.at(i).diameter > 5) && (cylSurfaces.at(i).diameter < 15))
						{
							status = ProSelectionAlloc(&p_comp_path, &cylSurfaces.at(i).modelItem, &smallEdge);
							ruleLog.Write("ProSelectionAlloc small edge status: " + to_string(status));
							break;
						}
					}

					status = ProSelectionHighlight(edgeSelection, PRO_COLOR_HIGHLITE);
					status = ProSelectionHighlight(smallEdge, PRO_COLOR_HIGHLITE);
				}
			}
		}

		if (subModuleMdlType == PRO_MDL_ASSEMBLY)
		{
			Assy_models_RA[Assy_models_cnt].Model = model;
			Assy_models_RA[Assy_models_cnt].Model_feat_id = p_feature->id;
			Assy_models_cnt += 1;
		}
	}

	return PRO_TK_NO_ERROR;
}

ProError surfVisitAction(ProSurface surface, ProError status, vector<surfaceData>* cylSurfaces)
{
	ProSrftype surfType;
	surfaceData surfObject;
	int id;
	ProModelitem modelIt;

	status = ProSurfaceTypeGet(surface, &surfType);
	ruleLog.Write("ProSurfaceTypeGet status: " + to_string(status) + "\nSurface type is: " + to_string(surfType));
	if (status == PRO_TK_NO_ERROR)
	{
		//Visit only cylindrical surfaces
		if (surfType == PRO_SRF_CYL)
		{
			surfObject.surface = surface;
			ruleLog.Write("Before push back");
			surface_Collect.push_back(surfObject);

			ruleLog.Write("After push back");
			double					diameter;
			status = ProSurfaceDiameterEval(surface, NULL, &diameter);
			ruleLog.Write("ProSurfaceDiameterEval status: " + to_string(status) + "\nDiameter: " + to_string(diameter));
			surfObject.diameter = diameter;

			status = ProSurfaceIdGet(surface, &id);
			ruleLog.Write("ProSurfaceIdGet status: " + to_string(status) + "\n identifier: " + to_string(id));

			status = ProModelitemInit(flangeMdl, id, PRO_SURFACE, &modelIt);
			ruleLog.Write("ProModelitemInit status: " + to_string(status));
			surfObject.modelItem = modelIt;
			cylSurfaces->push_back(surfObject); // store all the cylindrical surfaces
		}
	}
	return PRO_TK_NO_ERROR;
}

ProError selectAction_H2D01(char* dialog, char* component, ProAppData data)
{
	Utils _util;
	InterfaceRule irule;
	ProError status;
	bool* quitAction = (bool*)data;


	status = ProSelect((char*)"surface", 3, NULL, NULL, NULL, NULL, &surfSelection, &SelCount);
	ruleLog.Write("ProSelect status: " + to_string(status));
	if (status == PRO_TK_USER_ABORT)
	{
		status = ProUIDialogShow(dialog);
		return status;
	}
	if (SelCount < 3)
	{
		_util.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Attention!", "Incorrect selection. Please refer help document and UI image");
		status = ProUIDialogShow(dialog);
		ProSelectionFree(surfSelection);
		return status;
	}

	status = ProUIPushbuttonEnable(dialog, CommitOk);
	return PRO_TK_NO_ERROR;
}

/*======================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-H2D01-003	| Vinay Neel	    | MH2D01; MF4B03	| No variation in SPCD for similar suspension type for a RA family
========================================================================================================================*/
#define DLG_IRH2D01_003 "dlg_IR_H2D01_003"
#define PB_RSELECT		"pb_select"
#define PB_RCANCEL       "CommitCancel"
#define PB_RUN           "pb_run"
#define Input_Panel    "input_spcd"
ProSelection* surf_selh2d01_003;
double input_spcd_1st;
double input_spcd;
string rem_mes;
vector<vector<string>> dbList2D_H2D01;
struct partData {
	string part_name;
	int id;
};
string raFamilyH2D01_003 = "";
int IRH2D01::IRH2D01_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRH2D01::IRH2D01_003   ==========================");

	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	vector<partData> part_data;
	partData data;
	rem_mes = "";
	raFamilyH2D01_003 = "";
	dbList2D_H2D01.clear();
	double distance;

	ComponentData _reqComps[1]{};
	string reqCompSubMod[] = { "H2D01" };

	for (int i = 0; i < subModulesList.size(); ++i)
		for (int j = 0; j < 1; ++j)
			if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
				strcpy(_reqComps[j].name, subModulesList[j].name.c_str());

	int project_code = stoi(string(_reqComps[0].name).substr(0, 4));
	ruleLog.Write("Project Code:" + to_string(project_code));

	vector<string> reqvalfromcsv;
	getReqValsFrom2DCsvData("IRH2D01003.csv", 2, 3, project_code, reqvalfromcsv);

	if (reqvalfromcsv.size() == 0) {
		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "The project code is not available in the database.");
		return 0;
	}
	else {
		raFamilyH2D01_003 = reqvalfromcsv.at(0);
		ruleLog.Write("raFamilyH2D01_003: " + raFamilyH2D01_003);
	}


	//dbList2D_H2D01 = getData2D("IRH2D01003.csv");
	//ruleLog.Write("dbList2D_F3B03.size(): " + to_string(dbList2D_H2D01.size()));

	//vector<string> platformValFrmCSV;
	//for (int i = 1; i < dbList2D_H2D01.size(); ++i)	// i = 1 for skipping the headers
	//{
	//	string tok1, tok2;

	//	std::istringstream ss2(dbList2D_H2D01[i][0]);
	//	while (std::getline(ss2, tok2, ';'))
	//	{
	//		trimString(tok2);
	//		//storing list of Platforms from db
	//		if (find(platformValFrmCSV.begin(), platformValFrmCSV.end(), tok2) == platformValFrmCSV.end()) {
	//			platformValFrmCSV.push_back(tok2);
	//		}
	//	}
	//}

	//for (auto str : platformValFrmCSV) {
	//	ruleLog.Write("platformValFrmCSV: " + str);
	//}

	//get the REVISION & SEQUENCE from description
	ProMdl reqMdl;
	ProModelitem asm_model_item;
	ProName pEnvName = L"REVISION", pEnvName2 = L"SEQUENCE";
	ProParameter pEnv, pEnv2;
	ProParamvalue pvEnv, pvEnv2;
	char existingValue[PRO_NAME_SIZE], existingValue2[PRO_NAME_SIZE];
	//InterfaceRule irc;
	//vector<string> reqValsFromCsv;
	string sequence, revision;

	status = ProMdlCurrentGet(&reqMdl);
	ruleLog.Write("ProMdlCurrentGet: " + to_string(status));

	status = ProMdlToModelitem(reqMdl, &asm_model_item);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	status = ProParameterInit(&asm_model_item, pEnvName, &pEnv);
	ruleLog.Write("ProParameterInit: " + to_string(status));

	status = ProParameterInit(&asm_model_item, pEnvName2, &pEnv2);
	ruleLog.Write("ProParameterInit: " + to_string(status));


	if (status == PRO_TK_NO_ERROR)
	{
		//to fetch envelope parameters
		status = ProParameterValueWithUnitsGet(&pEnv, &pvEnv, NULL);
		ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tRevision: " + string(ProWstringToString(existingValue, pvEnv.value.s_val)));
		status = ProParameterValueWithUnitsGet(&pEnv2, &pvEnv2, NULL);
		revision = string(existingValue);
		ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tSequence: " + string(ProWstringToString(existingValue2, pvEnv2.value.s_val)));
		sequence = string(existingValue2);
		//raFamilyH2D01_003 = string(existingValue);
		ruleLog.Write("raFamily : " + raFamilyH2D01_003);
	}

	//check if the RA-family is available in the description
	//if (raFamilyH2D01_003 == "") {
	//	isRAfamilyfound = false;
	//}

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRH2D01_003, DLG_IRH2D01_003);
	status = ProUIDialogAboveactivewindowSet(DLG_IRH2D01_003, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2D01_003, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2D01_003, PB_RUN, (ProUIAction)run_action_IRH2D01003, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRH2D01_003, PB_RSELECT, (ProUIAction)select_action_IRH2D01003, NULL);

	status = ProUIPushbuttonDisable(DLG_IRH2D01_003, PB_RUN);
	//status = ProUIPushbuttonDisable(DLG_IRH2D01_003, PB_RSELECT);

	//status = ProUIOptionmenuSelectActionSet(DLG_IRH2D01_003, PB_SELECT_PLATFORM, (ProUIAction)PlatFValH2D01, NULL);
	//ruleLog.Write("ProUIPushbuttonActivateActionSet status:" + to_string(status));
	//status = ProUIOptionmenuSelectActionSet(DLG_IRH2D01_003, PB_SELECT_RAFAMILY, (ProUIAction)raFamilyH2D01, NULL);


	//if (isRAfamilyfound == true) {
	//	//hide the dropdowns
	//	ProUIOptionmenuHide(DLG_IRH2D01_003, PB_SELECT_PLATFORM);
	//	ProUIOptionmenuHide(DLG_IRH2D01_003, PB_SELECT_RAFAMILY);
	//	ProUILabelHide(DLG_IRH2D01_003, LABEL5);
	//	ProUILabelHide(DLG_IRH2D01_003, LABEL3);
	//}
	//else {
	//	//Set platform values in PB_SELECT_PLATFORM drop down
	//	UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", "The RA_Family is not found in the description.\n\nPlease select Platform and RA-Family.");
	//	platformValFrmCSV.insert(platformValFrmCSV.begin(), "Select");
	//	option_menu_H2D01(platformValFrmCSV, PB_SELECT_PLATFORM);
	//}

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRH2D01_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRH2D01_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	status = measureDistanceBetweenSurfaces(surf_selh2d01_003[0], surf_selh2d01_003[1], distance);
	ruleLog.Write("measureDistanceBetweenSurfaces: " + to_string(status));
	if (status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selected surfaces.");
		return -1;
	}


	//Get the id of selected planes
	for (int i = 0; i < 2; i++) {
		ProMdlName		wname;
		char            cname[PRO_MDLNAME_SIZE];
		ProFeature feature;

		status = ProSelectionModelitemGet(surf_selh2d01_003[i], &feature);
		status = ProMdlMdlnameGet(feature.owner, wname);
		ProWstringToString(cname, wname);
		data.part_name = cname;
		data.id = feature.id;
		part_data.push_back(data);
		ruleLog.Write("part_names: " + to_string(data.id));
	}

	ruleLog.Write("raFamilyH2D01_003: " + raFamilyH2D01_003);

	sprintf(remark, "Measured SPCD = %0.2lf mm.;Acceptance criteria: SPCD for %s = %0.2lf mm.;\nSPCD provided by user: %0.2lf mm.", distance, raFamilyH2D01_003.c_str(), input_spcd, input_spcd);

	rem_mes += remark;
	rem_mes += "\nRevision & Sequence: " + revision + " , " + sequence;
	rem_mes += "\nUsed Reference part : " + string(part_data[0].part_name) + ".PRT(Surface Id :" + (to_string(part_data[0].id)) + ")";
	rem_mes += "\nUsed Reference part : " + string(part_data[0].part_name) + ".PRT(Surface Id :" + (to_string(part_data[0].id)) + ")";

	final_res.remark = string(rem_mes);


	// DECLARE RESULT
	if (compareFloat(distance, input_spcd)) {
		final_res.result = "PASS";
	}
	else {
		final_res.result = "FAIL";
	}

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	dbList2D_H2D01.clear();
	part_data.clear();
	rem_mes.clear();
	return 0;
}

ProError select_action_IRH2D01003(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRH2D01003 -----------------------------");
	status = ProWindowRepaint(PRO_VALUE_UNUSED);

	int n_sels;
	wchar_t* wstr;
	char   cstr[PRO_NAME_SIZE]{};
	status = ProUIInputpanelValueGet(DLG_IRH2D01_003, Input_Panel, &wstr);
	ruleLog.Write("ProUIInputpanelValueGet: " + to_string(status));
	ProWstringToString(cstr, wstr);
	ruleLog.Write("Frame width User input: " + string(cstr));

	try {
		input_spcd = stod(string(cstr));
	}
	catch (const exception& e) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please provide a valid SPCD.");
		status = ProUIPushbuttonDisable(DLG_IRH2D01_003, PB_RUN);
		ruleLog.Write("Exception occurred");
		return status;
	}

	if (string(cstr) != "") {

		input_spcd = stod(string(cstr));
		ruleLog.Write("input_spcd: " + to_string(input_spcd));

		status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surf_selh2d01_003, &n_sels);
		ruleLog.Write("ProSelect: " + to_string(status));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIPushbuttonDisable(DLG_IRH2D01_003, PB_RUN);
			return status;
		}
		if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
			status = ProUIPushbuttonDisable(DLG_IRH2D01_003, PB_RUN);
			return status;
		}

	}
	else
	{
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please provide SPCD.");
		status = ProUIPushbuttonDisable(DLG_IRH2D01_003, PB_RUN);
		return status;
	}

	if (status == PRO_TK_NO_ERROR && n_sels == 2) {
		status = ProUIPushbuttonEnable(dialog, PB_RUN);
	}

	return status;
}

ProError run_action_IRH2D01003(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- run_action_IRH2D01003 -----------------------------");

	wchar_t* wstr;
	char   cstr[PRO_NAME_SIZE]{};
	status = ProUIInputpanelValueGet(DLG_IRH2D01_003, Input_Panel, &wstr);
	ruleLog.Write("ProUIInputpanelValueGet: " + to_string(status));
	ProWstringToString(cstr, wstr);
	ruleLog.Write("Frame width changed User input: " + string(cstr));
	ruleLog.Write("input_spcd: " + to_string(input_spcd));

	try {
		double input_val = stod(string(cstr));
	}
	catch (const exception& e) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please provide a valid SPCD.");
		status = ProUIPushbuttonDisable(DLG_IRH2D01_003, PB_RUN);
		ruleLog.Write("Exception occurred");
		return status;
	}


	if (string(cstr) == "" || input_spcd != stod(string(cstr))) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please provide a valid SPCD.");
		status = ProUIPushbuttonDisable(DLG_IRH2D01_003, PB_RUN);
		return status;
	}


	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}