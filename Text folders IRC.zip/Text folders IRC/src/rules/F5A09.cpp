/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 20-06-2023	|	V1_0_0		| F2D01 - LIFT SUSPENSION RULES
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#include "F5A09.h"

/*==================================================================================================================
RULE ID			| DEVELOPER		| DEPENDENT MODULES		| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F5A09-003	| Ved Aiyar		| MF5A09; MD2C01		| Parking brake handle in off condition & operated condition should not be behind driver �H� point.
===================================================================================================================*/
#define DLG_F5A09_003 "dlg_IR_F5A09_003"
#define PB_RCANCEL "CommitClose"
#define PB_ROK "CommitOK"
#define PB_RSELECT		"pb_select"

ProVector xyz_point_HB1, xyz_point_Hpoint, xyz_point_HB2;
ProSelection* sel_hpoint;
ProSelection HPOINT, HBRAKE;
vector<string> parent_namesf5A09_003;
vector<int>ID_mapf5A09_003;
ComponentData _reqCompsf5A09003[2]{};
string remf5a09003;
bool rulestatf5a09003 = false;

vector<Model_Tree_Information> treeInformationVectorf5A09_003, matchingElements;


int IRF5A09::IRF5A09_003(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF5A09::IRF5A09_003   ==========================");
    deleteDatumPointf5a09("HANDBRAKE");
    deleteDatumPointf5a09("HB1");
    deleteDatumPointf5a09("HB2");
    deleteDatumPointf5a09("HPOINT");
    deleteDatumPointf5a09("PNT0");
    deleteDatumPointf5a09("PNT1");



    string reqCompSubMod[2] = { "F5A09" , "D2C01" };
    string comp_names[2];
    double clearance_vals;
    isUserQuits = false;

    //ProMdlCurrentGet(&mdlf5a27006);

    for (int i = 0; i < subModulesList.size(); ++i)
    {
        for (int j = 0; j < sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]); ++j)
        {
            if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
            {
                strcpy(_reqCompsf5A09003[j].name, subModulesList[i].name.c_str());
                comp_names[j] = subModulesList[i].name;
                //ruleLog.Write(comp_names[j]+"---------------------------------------");
            }
        }
    }

    status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsId, compsFilter, (ProAppData)&_reqCompsf5A09003);


    for (auto elem : _reqCompsf5A09003)
    {
        ruleLog.Write("_reqComps[].name = " + string(elem.name));
        ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
    }



    ProMdl comp;
    char name[PRO_MDLNAME_SIZE];
    char type[PRO_MDLEXTENSION_SIZE];
    ProError status;
    UserAppdata appdata;
    FILE* fp{};
    ProMdlName modelName;
    ProMdlExtension modelExtension;


    status = ProMdlCurrentGet(&comp);
    ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));
    status = ProMdlMdlnameGet(comp, modelName);
    ProWstringToString(name, modelName);
    status = ProMdlExtensionGet(comp, modelExtension);
    ProWstringToString(type, modelExtension);

    appdata.fp = fp;
    appdata.level = 1;

    status = ProSolidFeatVisit((ProSolid)comp, user_actionf5A09_003, compsFilter, &appdata);



    for (int i = 0; i < treeInformationVectorf5A09_003.size(); i++)
    {
        ruleLog.Write("Name: " + treeInformationVectorf5A09_003[i].name + " Parent Name: " + treeInformationVectorf5A09_003[i].Parent_name + " ID: " + to_string(treeInformationVectorf5A09_003[i].ID));
        for (int id : treeInformationVectorf5A09_003[i].ID_path)
        {
            ruleLog.Write(to_string(id));
        }
    }


    status = ProUIDialogCreate(DLG_F5A09_003, DLG_F5A09_003);
    status = ProUIDialogAboveactivewindowSet(DLG_F5A09_003, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_F5A09_003, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_F5A09_003, PB_ROK, (ProUIAction)ruleDlgOKaction_IRF5A09_003, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_F5A09_003, PB_RSELECT, (ProUIAction)select_action_IRF5A09_003, NULL);


    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_F5A09_003, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_F5A09_003);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    if (rulestatf5a09003 == true)
    {
        isRightValue = TRUE;
    }
    else
    {
        isRightValue = FALSE;
    }

    remf5a09003 = remf5a09003 + "\nAcceptance criteria: Handbrake position should be in front of Hip-Point.";

    if (isRightValue)
        final_res.result = "PASS";
    else
        final_res.result = "FAIL";

    final_res.remark = remf5a09003;

    ruleLog.Write("final_res.status: " + string(final_res.result));
    ruleLog.Write("final_res.remark: " + string(final_res.remark));

    ID_mapf5A09_003.clear();
    remf5a09003.clear();
    matchingElements.clear();
    treeInformationVectorf5A09_003.clear();

    return 0;
}

ProError user_actionf5A09_003(ProFeature* feature, ProError status, ProAppData appdata)
{
    FILE* fp;
    int level;
    ProMdl mdl27;
    char name27[PRO_MDLNAME_SIZE];
    char type[PRO_MDLEXTENSION_SIZE];
    UserAppdata* appd, appd1;
    ProMdlName modelName;
    ProMdlExtension modelExtension;
    ProAsmcomppath comppath;
    ProModelitem modelItem;
    char existingPval[PRO_NAME_SIZE]{};

    //ProModelitem p_item27;
    ProIdTable table;
    //table[0] = -1;
    //int ID;

    appd = (UserAppdata*)appdata;
    fp = appd->fp;
    level = appd->level;

    status = ProAsmcompMdlGet(feature, &mdl27);
    status = ProMdlMdlnameGet(mdl27, modelName);
    status = ProMdlExtensionGet(mdl27, modelExtension);

    ProWstringToString(name27, modelName);
    ProWstringToString(type, modelExtension);


    //if (strncmp(type, "ASM", 3) == 0 || strncmp(type, "PRT", 3))
    //{
    ID_mapf5A09_003.push_back(feature->id);
    //component_path.push_back(ID_mapf2c01004);

    appd1.fp = appd->fp;
    appd1.level = appd->level + 1;

    //numberofasm++;

    status = ProMdlToModelitem(mdl27, &modelItem);

    if (status == PRO_TK_NO_ERROR)
    {
        //ruleLog.Write("CHECK");

        //status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc);
        //ProWstringToString(existingPval, pvDesc.value.s_val);
        Model_Tree_Information tree1;

        tree1.name = string(name27);
        tree1.ID = feature->id;
        tree1.description = existingPval;
        tree1.ID_path = ID_mapf5A09_003;
        if (tree1.ID_path[0] == _reqCompsf5A09003[0].id)
        {
            tree1.Parent_name = _reqCompsf5A09003[0].name;
        }
        else if (tree1.ID_path[0] == _reqCompsf5A09003[1].id)
        {
            tree1.Parent_name = _reqCompsf5A09003[1].name;
        }
        tree1.ID_table_size = ID_mapf5A09_003.size();

        treeInformationVectorf5A09_003.push_back(tree1);
        /*ruleLog.Write("Name of assembly = " + string(name27) + " , ID = " + to_string(feature->id));
        for (int id : tree1.ID_path)
        {
            ruleLog.Write(to_string(id) + " ");
        }*/
    }

    status = ProSolidFeatVisit((ProSolid)mdl27, user_actionf5A09_003, compsFilter, &appd1);
    ID_mapf5A09_003.pop_back();

    return(PRO_TK_CONTINUE);
}

// Function to find point C given points A and B and a distance
int findPointC(double Ax, double Ay, double Az, double Bx, double By, double Bz, double dist, double C[])
{
    // Calculate the direction vector AB
    double AB[3] = { Bx - Ax, By - Ay, Bz - Az };

    // Calculate the magnitude of vector AB
    double AB_magnitude = sqrt(pow(AB[0], 2) + pow(AB[1], 2) + pow(AB[2], 2));

    // Normalize the direction vector
    double u[3] = { AB[0] / AB_magnitude, AB[1] / AB_magnitude, AB[2] / AB_magnitude };

    // Calculate the coordinates of point C
    C[0] = Ax + (dist * u[0]);
    C[1] = Ay + (dist * u[1]);
    C[2] = Az + (dist * u[2]);

    return 0;
}

int createDatumPoint(ProSelection edgeSelection, char cPointName[PRO_NAME_SIZE])
{
    ruleLog.Write("========= createDatumPointAtCenterOfEdge =============");

    ProElement elem_tree, elem_ftype, pro_e_dpoint_type, pro_e_std_feature_name, pro_e_dpoint_points_array,
        pro_e_dpoint_point, pro_e_dpoint_point_name, pro_e_dpoint_pla_constraints, pro_e_dpoint_pla_constraint,
        pro_e_dpoint_pla_constr_ref, pro_e_dpoint_pla_constr_type;
    ProName arrayName;
    ProReference REPDEP_ref1;
    ProModelitem item1;
    ProSelection edgeSel{}, model_selection;
    ProFeatureCreateOptions* opts = 0;
    ProFeature              feature;
    ProErrorlist            errors;

    ruleLog.Write("Element tree started");
    /*status = ProModelitemInit(element.parentMdl, element.id, PRO_EDGE, &item1);
    ruleLog.Write("ProModelitemInit status: " + to_string(status));
    status = ProSelectionAlloc(&element.path, &item1, &edgeSel);
    ruleLog.Write("ProSelectionAlloc status: " + to_string(status));
    status = ProSelectionHighlight(edgeSel, PRO_COLOR_HIGHLITE);
    ruleLog.Write("ProSelectionHighlight status: " + to_string(status));*/
    status = ProSelectionToReference(edgeSelection, &REPDEP_ref1);
    ruleLog.Write("ProSelectionToReference status: " + to_string(status));

    //Allocate tree 
    status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
    ruleLog.Write("Tree root status = " + to_string(status));

    //Allocate feature type
    status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
    ruleLog.Write("ProElementAlloc status feature: = " + to_string(status));
    ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
    ruleLog.Write("ProElementIntegerSet status feature: = " + to_string(status));
    ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
    ruleLog.Write("ProElemtreeElementAdd status feature: = " + to_string(status));
    ruleLog.Write("feature type allocation status = " + to_string(status));

    //PRO_E_DPOINT_TYPE (general)
    status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
    ruleLog.Write("ProElementAlloc status feature type: = " + to_string(status));
    status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_GENERAL);
    ruleLog.Write("ProElementIntegerSet status feature type: = " + to_string(status));
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
    ruleLog.Write("ProElemtreeElementAdd status feature type: = " + to_string(status));
    ruleLog.Write("datum point type allocation type status = " + to_string(status));

    //Allocating element for feature name
    status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &pro_e_std_feature_name);
    ruleLog.Write("ProElementAlloc status feature name: = " + to_string(status));
    ProStringToWstring(arrayName, "MY_PNT0");
    status = ProElementWstringSet(pro_e_std_feature_name, arrayName);
    ruleLog.Write("ProElementWstringSet status feature name: = " + to_string(status));
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_std_feature_name);
    ruleLog.Write("ProElemtreeElementAdd status feature name: = " + to_string(status));

    //Allocate points array
    status = ProElementAlloc(PRO_E_DPOINT_POINTS_ARRAY, &pro_e_dpoint_points_array);
    ruleLog.Write("ProElementAlloc status array: = " + to_string(status));
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_points_array);
    ruleLog.Write("ProElemtreeElementAdd status array: = " + to_string(status));

    //Allocating point in the array
    status = ProElementAlloc(PRO_E_DPOINT_POINT, &pro_e_dpoint_point);
    ruleLog.Write("ProElementAlloc status point: = " + to_string(status));
    status = ProElemtreeElementAdd(pro_e_dpoint_points_array, NULL, pro_e_dpoint_point);
    ruleLog.Write("ProElemtreeElementAdd status point: = " + to_string(status));

    //Allocating name of the point
    status = ProElementAlloc(PRO_E_DPOINT_POINT_NAME, &pro_e_dpoint_point_name);
    ruleLog.Write("ProElementAlloc status point name: = " + to_string(status));
    wchar_t wPointName[PRO_NAME_SIZE];
    ProStringToWstring(wPointName, cPointName);
    status = ProElementWstringSet(pro_e_dpoint_point_name, wPointName);
    ruleLog.Write("ProElementWstringSet status point name: = " + to_string(status));
    status = ProElemtreeElementAdd(pro_e_dpoint_point, NULL, pro_e_dpoint_point_name);
    ruleLog.Write("ProElemtreeElementAdd status point name: = " + to_string(status));

    //Allocating placement constraints
    status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTRAINTS, &pro_e_dpoint_pla_constraints);
    ruleLog.Write("ProElementAlloc status constraints: = " + to_string(status));
    status = ProElemtreeElementAdd(pro_e_dpoint_point, NULL, pro_e_dpoint_pla_constraints);
    ruleLog.Write("ProElemtreeElementAdd status constratints: = " + to_string(status));

    //Allocating an element for a constraint
    status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTRAINT, &pro_e_dpoint_pla_constraint);
    ruleLog.Write("ProElementAlloc status constraint: = " + to_string(status));
    status = ProElemtreeElementAdd(pro_e_dpoint_pla_constraints, NULL, pro_e_dpoint_pla_constraint);
    ruleLog.Write("ProElemtreeElementAdd status constratint: = " + to_string(status));

    //Allocating a reference
    status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_REF, &pro_e_dpoint_pla_constr_ref);
    ruleLog.Write("ProElementAlloc status reference: = " + to_string(status));
    status = ProElementReferenceSet(pro_e_dpoint_pla_constr_ref, REPDEP_ref1);
    ruleLog.Write("ProElementReferenceSet status: = " + to_string(status));
    status = ProElemtreeElementAdd(pro_e_dpoint_pla_constraint, NULL, pro_e_dpoint_pla_constr_ref);
    ruleLog.Write("ProElemtreeElementAdd status reference: = " + to_string(status));

    //Allocating constraint type
    status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_TYPE, &pro_e_dpoint_pla_constr_type);
    ruleLog.Write("ProElementAlloc status reference type: = " + to_string(status));
    status = ProElementIntegerSet(pro_e_dpoint_pla_constr_type, PRO_DTMPNT_CONSTR_TYPE_CENTER);
    ruleLog.Write("ProElementIntegerSet status reference type: = " + to_string(status));
    status = ProElemtreeElementAdd(pro_e_dpoint_pla_constraint, NULL, pro_e_dpoint_pla_constr_type);
    ruleLog.Write("ProElemtreeElementAdd status reference type: = " + to_string(status));

    /*---------------------------------------------------------------*\
    Create the feature in the current model.
    \*---------------------------------------------------------------*/
    /*status = ProMdlCurrentGet(&model);
    if (status != PRO_TK_NO_ERROR) return (status);
    status = ProMdlToModelitem(model, &model_item);*/
    status = ProSelectionAlloc(NULL, &curMdlitem, &model_selection);
    ruleLog.Write("ProSelectionAlloc status featCreate: " + to_string(status));

    status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
    ruleLog.Write("ProArrayAlloc status featCreate: " + to_string(status));

    opts[0] = PRO_FEAT_CR_DEFINE_MISS_ELEMS;

    status = ProFeatureWithoptionsCreate(model_selection, elem_tree, opts, PRO_REGEN_NO_FLAGS, &feature, &errors);
    ruleLog.Write("ProFeatureWithoptionsCreate status featCreate: " + to_string(status));
    status = ProArrayFree((ProArray*)&opts);
    ruleLog.Write("ProArrayFree status featCreate: " + to_string(status));
    status = ProElementFree(&elem_tree);
    ruleLog.Write("ProElementFree status featCreate: " + to_string(status));
    return 0;
}

ProError select_action_IRF5A09_003(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("--------------------------  select_action_IRF5A10_007  --------------------------");
    int n_sels;
    int stat;
    ProModelitem annotelem;
    char nameofsel[PRO_NAME_SIZE];
    ProMdl mdl;
    wchar_t model;
    parent_namesf5A09_003.clear();

    status = ProSelect((char*)"edge,surface", 3, NULL, NULL, NULL, NULL, &sel_hpoint, &n_sels);
    ruleLog.Write("Proselect status = " + to_string(status) + " Number of selections = " + to_string(n_sels));


    status = ProUIPushbuttonEnable(DLG_F5A09_003, PB_ROK);
    ruleLog.Write("ProUIPushbuttonEnable status = " + to_string(status));


    for (int i = 0; i < n_sels; i++)
    {
        status = ProSelectionModelitemGet(sel_hpoint[i], &annotelem);
        ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));

        status = ProModelitemMdlGet(&annotelem, &mdl);
        ruleLog.Write("ProModelitemMdlGet status = " + to_string(status));

        status = ProMdlMdlnameGet(mdl, &model);
        ruleLog.Write("ProMdlMdlnameGet status = " + to_string(status));

        ProWstringToString(nameofsel, &model);
        string m(nameofsel);

        parent_namesf5A09_003.push_back(m);
        //ruleLog.Write("Owner name = " + m);
        if (i == 2)
        {
            break;
        }
    }


    return status;
}

ProError ruleDlgOKaction_IRF5A09_003(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- ruleDlgOKaction -----------------------------");

    ProPoint point1, point2, point3;
    ProModelitem p_item1, p_item2, p_item3, p_item4;
    ProName name1;
    ProName name2;
    ProName name3;
    ProName name4;
    ProMdl pm;
    ProEdge PE;
    ProVector local_point;
    double t;
    ProVector xyz_point1, xyz_point2;
    ProVector deriv1;
    ProVector deriv2;


    for (int j = 0; j < parent_namesf5A09_003.size(); j++)
    {
        for (int i = 0; i < treeInformationVectorf5A09_003.size(); i++)
        {
            if (treeInformationVectorf5A09_003[i].name == parent_namesf5A09_003[j])
            {
                parent_namesf5A09_003[j] = treeInformationVectorf5A09_003[i].Parent_name;
            }
        }
    }

    for (int i = 0; i < parent_namesf5A09_003.size(); i++)
    {
        ruleLog.Write("Owner name = " + parent_namesf5A09_003[i]);
    }

    createDatumPoint(sel_hpoint[0], "HB1");
    createDatumPoint(sel_hpoint[1], "HB2");
    createDatumPoint(sel_hpoint[2], "HPOINT");
    //int track = 0;
    //for (std::size_t i = 0; i < parent_namesf5A09_003.size(); ++i) 
    //{
    //    const std::string& name = parent_namesf5A09_003[i];
    //    if (name.find("D2C01") != std::string::npos)
    //    {
    //        // Do something if the element contains "D2C01"
    //        createDatumPoint(sel_hpoint[i], "HPOINT");
    //    }
    //    else if (name.find("F5A09") != std::string::npos) 
    //    {
    //        
    //        if (track == 0)
    //        {
    //            createDatumPoint(sel_hpoint[i], "HB1");
    //            track++;
    //        }
    //        else if(track == 1)
    //        {
    //            createDatumPoint(sel_hpoint[i], "HB2");
    //        }
    //        // Do something else if the element contains "F5A09"
    //    }
    //}




    status = ProMdlCurrentGet(&pm);


    ProStringToWstring(name1, "HPOINT");
    status = ProModelitemByNameInit(pm, PRO_POINT, name1, &p_item1);
    ruleLog.Write("ProModelitemByNameInit = " + to_string(status));
    status = ProPointInit((ProSolid)pm, p_item1.id, &point1);
    ruleLog.Write("ProPointInit status = " + to_string(status));
    status = ProPointCoordGet(point1, xyz_point_Hpoint);
    ruleLog.Write("ProPointCoordGet = " + to_string(status));

    ProStringToWstring(name2, "HB1");
    status = ProModelitemByNameInit(pm, PRO_POINT, name2, &p_item2);
    ruleLog.Write("ProModelitemByNameInit = " + to_string(status));
    status = ProPointInit((ProSolid)pm, p_item2.id, &point2);
    ruleLog.Write("ProPointInit status = " + to_string(status));
    status = ProPointCoordGet(point2, xyz_point_HB1);
    ruleLog.Write("ProPointCoordGet = " + to_string(status));

    ProStringToWstring(name3, "HB2");
    status = ProModelitemByNameInit(pm, PRO_POINT, name3, &p_item3);
    ruleLog.Write("ProModelitemByNameInit = " + to_string(status));
    status = ProPointInit((ProSolid)pm, p_item3.id, &point3);
    ruleLog.Write("ProPointInit status = " + to_string(status));
    status = ProPointCoordGet(point3, xyz_point_HB2);
    ruleLog.Write("ProPointCoordGet = " + to_string(status));

    //ruleLog.Write("\n\n\nHandbrake handle : " + to_string(xyz_point_handbrake[0]) + ", " + to_string(xyz_point_handbrake[1]) + ", " + to_string(xyz_point_handbrake[2]));
    ruleLog.Write("H-Point 1: " + to_string(xyz_point_Hpoint[0]) + ", " + to_string(xyz_point_Hpoint[1]) + ", " + to_string(xyz_point_Hpoint[2]));

    ruleLog.Write("Handbrake-Point 1: " + to_string(xyz_point_HB1[0]) + ", " + to_string(xyz_point_HB1[1]) + ", " + to_string(xyz_point_HB1[2]));
    ruleLog.Write("Handbrake-Point 2: " + to_string(xyz_point_HB2[0]) + ", " + to_string(xyz_point_HB2[1]) + ", " + to_string(xyz_point_HB2[2]));

    Point3D p1 = { xyz_point_HB1[0], xyz_point_HB1[1], xyz_point_HB1[2] }; // Example point 1
    Point3D p2 = { xyz_point_HB2[0], xyz_point_HB2[1], xyz_point_HB2[2] }; // Example point 2

    // Calculate the coordinates of the midpoint
    Point3D mid;
    mid.x = (p1.x + p2.x) / 2;
    mid.y = (p1.y + p2.y) / 2;
    mid.z = (p1.z + p2.z) / 2;


    //After performing Axis rotation
    ruleLog.Write("Coordinates of the point on the Handbrake are: (" + to_string(mid.x) + " , " + to_string(mid.y) + " , " + to_string(mid.z) + ")");

    //createDatumPoints_1(xyz_handbrake , "HANDBRAKE");

    ProElement featElemTree = nullptr;
    status = ProElementAlloc(PRO_E_FEATURE_TREE, &featElemTree);

    //PRO_E_FEATURE_TYPE
    ProElement featureTypeElem = nullptr;
    status = ProElementAlloc(PRO_E_FEATURE_TYPE, &featureTypeElem);
    status = ProElementIntegerSet(featureTypeElem, PRO_FEAT_DATUM_POINT);
    status = ProElemtreeElementAdd(featElemTree, NULL, featureTypeElem);

    //PRO_E_DPOINT_TYPE
    ProElement dpointTypeElem = nullptr;
    status = ProElementAlloc(PRO_E_DPOINT_TYPE, &dpointTypeElem);
    status = ProElementIntegerSet(dpointTypeElem, PRO_DPOINT_TYPE_OFFSET_CSYS);
    status = ProElemtreeElementAdd(featElemTree, NULL, dpointTypeElem);

    //PRO_E_STD_FEATURE_NAME
    ProElement stdFeatureNameElem = nullptr;
    status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &stdFeatureNameElem);
    status = ProElementWstringSet(stdFeatureNameElem, L"HANDBRAKE_POINT");
    status = ProElemtreeElementAdd(featElemTree, NULL, stdFeatureNameElem);

    //PRO_E_DPOINT_OFST_CSYS_REF
    ProElement dpointOfstCsysRefElem = nullptr;
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &dpointOfstCsysRefElem);

    ProMdl curMdl = nullptr;
    status = ProMdlCurrentGet(&curMdl);

    ProModelitem csysMdlItem{};
    ProName wname;
    char str[100] = { 'C','S','Y','S','_','A','S','M','_','D','E','F' };
    ProStringToWstring(wname, str);
    status = ProModelitemByNameInit(curMdl, PRO_CSYS, wname, &csysMdlItem);
    ruleLog.Write("ProModelitemByNameInit status = " + to_string(status));


    ProSelection csysSelection = nullptr;
    status = ProSelectionAlloc(NULL, &csysMdlItem, &csysSelection);

    ProReference dpointOfstCsysRefRef = nullptr;
    status = ProSelectionToReference(csysSelection, &dpointOfstCsysRefRef);

    status = ProElementReferenceSet(dpointOfstCsysRefElem, dpointOfstCsysRefRef);
    status = ProElemtreeElementAdd(featElemTree, NULL, dpointOfstCsysRefElem);

    //PRO_E_DPOINT_OFST_CSYS_WITH_DIMS
    ProElement dpointOfstCsysWithDimsElem = nullptr;
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &dpointOfstCsysWithDimsElem);
    status = ProElementIntegerSet(dpointOfstCsysWithDimsElem, 1);
    status = ProElemtreeElementAdd(featElemTree, NULL, dpointOfstCsysWithDimsElem);

    //PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY
    ProElement dpointOfstCsysPntsArrayElem = nullptr;
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &dpointOfstCsysPntsArrayElem);
    status = ProElemtreeElementAdd(featElemTree, NULL, dpointOfstCsysPntsArrayElem);

    //PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY
    //  |--PRO_E_DPOINT_OFST_CSYS_PNT
    ProElement dpointOfstCsysPntElem = nullptr;
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &dpointOfstCsysPntElem);
    status = ProElemtreeElementAdd(dpointOfstCsysPntsArrayElem, NULL, dpointOfstCsysPntElem);

    //PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY
    //  |--PRO_E_DPOINT_OFST_CSYS_PNT
    //    |--PRO_E_DPOINT_OFST_CSYS_PNT_NAME
    ProElement dpointOfstCsysPntNameElem = nullptr;
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &dpointOfstCsysPntNameElem);
    status = ProElementWstringSet(dpointOfstCsysPntNameElem, L"ORIGIN");
    status = ProElemtreeElementAdd(dpointOfstCsysPntElem, NULL, dpointOfstCsysPntNameElem);

    //PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY
    //  |--PRO_E_DPOINT_OFST_CSYS_PNT
    //    |--PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
    ProElement dpointOfstCsysDir1ValElem = nullptr;
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &dpointOfstCsysDir1ValElem);
    status = ProElementDoubleSet(dpointOfstCsysDir1ValElem, 0);
    status = ProElemtreeElementAdd(dpointOfstCsysPntElem, NULL, dpointOfstCsysDir1ValElem);

    //PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY
    //  |--PRO_E_DPOINT_OFST_CSYS_PNT
    //    |--PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
    ProElement dpointOfstCsysDir2ValElem = nullptr;
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &dpointOfstCsysDir2ValElem);
    status = ProElementDoubleSet(dpointOfstCsysDir2ValElem, 0);
    status = ProElemtreeElementAdd(dpointOfstCsysPntElem, NULL, dpointOfstCsysDir2ValElem);

    //PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY
    //  |--PRO_E_DPOINT_OFST_CSYS_PNT
    //    |--PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
    ProElement dpointOfstCsysDir3ValElem = nullptr;
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &dpointOfstCsysDir3ValElem);
    status = ProElementDoubleSet(dpointOfstCsysDir3ValElem, 0);
    status = ProElemtreeElementAdd(dpointOfstCsysPntElem, NULL, dpointOfstCsysDir3ValElem);

    //PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY
    //  |--PRO_E_DPOINT_OFST_CSYS_PNT
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &dpointOfstCsysPntElem);
    status = ProElemtreeElementAdd(dpointOfstCsysPntsArrayElem, NULL, dpointOfstCsysPntElem);

    //PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY
    //  |--PRO_E_DPOINT_OFST_CSYS_PNT
    //    |--PRO_E_DPOINT_OFST_CSYS_PNT_NAME
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &dpointOfstCsysPntNameElem);
    status = ProElementWstringSet(dpointOfstCsysPntNameElem, L"HANDBRAKE");
    status = ProElemtreeElementAdd(dpointOfstCsysPntElem, NULL, dpointOfstCsysPntNameElem);

    //-183.529 , -212.344 , -0.000009

    //PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY
    //  |--PRO_E_DPOINT_OFST_CSYS_PNT
    //    |--PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &dpointOfstCsysDir1ValElem);
    status = ProElementDoubleSet(dpointOfstCsysDir1ValElem, mid.x);
    status = ProElemtreeElementAdd(dpointOfstCsysPntElem, NULL, dpointOfstCsysDir1ValElem);

    //PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY
    //  |--PRO_E_DPOINT_OFST_CSYS_PNT
    //    |--PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &dpointOfstCsysDir2ValElem);
    status = ProElementDoubleSet(dpointOfstCsysDir2ValElem, -mid.z);
    status = ProElemtreeElementAdd(dpointOfstCsysPntElem, NULL, dpointOfstCsysDir2ValElem);

    //PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY
    //  |--PRO_E_DPOINT_OFST_CSYS_PNT
    //    |--PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &dpointOfstCsysDir3ValElem);
    status = ProElementDoubleSet(dpointOfstCsysDir3ValElem, mid.y);
    status = ProElemtreeElementAdd(dpointOfstCsysPntElem, NULL, dpointOfstCsysDir3ValElem);

    ProModelitem featOwnerModelItem{};
    status = ProMdlToModelitem(curMdl, &featOwnerModelItem);

    ProSelection featOwnerSelection = nullptr;
    status = ProSelectionAlloc(NULL, &featOwnerModelItem, &featOwnerSelection);

    ProFeatureCreateOptions* featCreationOpts = nullptr;
    status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, reinterpret_cast<ProArray*>(&featCreationOpts));
    featCreationOpts[0] = PRO_FEAT_CR_NO_OPTS;

    ProFeature createdFeature{};
    ProErrorlist errorList{};
    status = ProFeatureWithoptionsCreate(
        featOwnerSelection,
        featElemTree,
        featCreationOpts,
        PRO_REGEN_NO_FLAGS,
        &createdFeature,
        &errorList);



    status = ProSelectionFree(&featOwnerSelection);
    featOwnerSelection = nullptr;

    status = ProFeatureElemtreeFree(&createdFeature, featElemTree);
    featElemTree = nullptr;

    status = ProElementFree(&featElemTree);
    featElemTree = nullptr;

    /*ProStringToWstring(name4, "PNT1");
    status = ProModelitemByNameInit(pm, PRO_POINT, name4, &p_item4);
    ruleLog.Write("ProModelitemByNameInit = " + to_string(status));
    status = ProSelectionAlloc(NULL , &p_item4 , &point_sel);
    Main_points.push_back(point_sel);*/



    if (xyz_point_Hpoint[0] > mid.x)
    {
        //ruleLog.Write("Pass");
        rulestatf5a09003 = TRUE;
        remf5a09003 = "Handbrake position is in front of Hip-Point.";
    }
    else
    {
        //ruleLog.Write("FAIL");
        rulestatf5a09003 = FALSE;
        remf5a09003 = "Handbrake position is behind Hip-Point.";
    }

    parent_namesf5A09_003.clear();
    deleteDatumPointf5a09("HB1");
    deleteDatumPointf5a09("HB2");



    status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
    return PRO_TK_NO_ERROR;
}

ProError deleteDatumPointf5a09(char* dtmpoint_name)
{
    ruleLog.Write("=================> InterfaceRule::deleteDatumPoints <=================");
    ProError status;
    int* feat_ids = NULL;
    ProMdl mdl;
    ProModelitem mdl_item;
    ProFeature feat;
    ProFeatureDeleteOptions* delete_opts = 0;
    ProIdTable idtbl1;
    ProAsmcomppath path;
    wchar_t wdatum_pt[PRO_NAME_SIZE];

    status = ProMdlCurrentGet(&mdl);
    ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));

    status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path);
    ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));


    ProStringToWstring(wdatum_pt, dtmpoint_name);
    status = ProModelitemByNameInit(mdl, PRO_POINT, wdatum_pt, &mdl_item);
    ruleLog.Write("ProModelitemByNameInit status = " + to_string(status));

    /*status = ProSelectionAlloc(&path, &mdl_item, &selections[0]);
    ruleLog.Write("ProSelectionAlloc 1 status = " + to_string(status));*/

    /*ProStringToWstring(name2, "datum_PNT2");
    status = ProModelitemByNameInit(mdl, PRO_POINT, name2, &mdl_item);
    ruleLog.Write("ProModelitemByNameInit 2 status = " + to_string(status));
    */

    if (status == PRO_TK_NO_ERROR) {
        /*status = ProSelectionAlloc(&path, &mdl_item, &selections[1]);
        ruleLog.Write("ProSelectionAlloc 2 status = " + to_string(status));*/

        /*status = ProSelectionModelitemGet(selections[i], &mdl_item);
        ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));*/

        status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
        ruleLog.Write("ProArrayAlloc status = " + to_string(status));

        status = ProGeomitemFeatureGet((ProGeomitem*)&mdl_item, &feat);
        ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status));
        feat_ids[0] = feat.id;

        status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
        delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;
        status = ProFeatureWithoptionsDelete((ProSolid)mdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
        ruleLog.Write("ProFeatureWithoptionsDelete status = " + to_string(status));

        status = ProArrayFree((ProArray*)&delete_opts);
        status = ProArrayFree((ProArray*)&feat_ids);


    }
    return PRO_TK_NO_ERROR;
};

ProError createDatumPointsf5a09(Pro3dPnt pnt_arr, char* csysName)
{

    ruleLog.Write("=================> InterfaceRule::createDatumPoints <=================");
    ProElement  elem_tree, elem_ftype, elem_feature_name,
        pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
        pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
        pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
    ProReference REPDEP_ref1;
    wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wide_string[PRO_NAME_SIZE], wide_string_2[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE];
    //CSYS_ASM_DEF
    ProModelitem refCsysitem;
    ProSelection refCsysSel, reqMdlSel;
    ProFeatureCreateOptions* opts = 0;
    ProFeature pnt_feat;
    ProErrorlist errors;

    char cDatumPointName[PRO_NAME_SIZE] = "Dist_highlght_pnt";

    ProStringToWstring(wCsysName, csysName);
    status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
    status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);


    //Create Element Tree
    status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
    ruleLog.Write("Tree root status = " + to_string(status));

    // TREE ALLOCATION
    status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
    ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
    ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
    ruleLog.Write("type status = " + to_string(status));

    //feature name
    status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
    status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, cDatumPointName));
    status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
    ruleLog.Write("feature name = " + to_string(status));

    //PRO_E_DPOINT_TYPE
    status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
    status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
    ruleLog.Write("type status = " + to_string(status));

    //Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);
    ruleLog.Write("PRO_E_DPOINT_OFST_CSYS_TYPE status = " + to_string(status));


    //ref
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
    status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
    status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);

    //
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);

    //Populating array element
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);

    //Point1
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);

    //Point1 Name
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
    ProStringToWstring(wide_string, "datum_PNT1");
    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);

    //PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);

    //PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, pnt_arr[1]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);

    //PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[2]);
    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);


    /* =============================================================== *\
    Create Model Selection Object
    \* =============================================================== */

    //status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
    //ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
    //status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

    //opts[0] = PRO_FEAT_CR_NO_OPTS;

    //// Create Points
    //status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
    //ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

    //status = ProArrayFree((ProArray*)&opts);
    //status = ProElementFree(&elem_tree);
    //status = ProSelectionFree(&reqMdlSel);

    /*ProSelection pnt_Sel;
    status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
    status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_ERROR);*/
    //PRO_COLOR_SELECTED for green highlight
    return PRO_TK_NO_ERROR;
}



//int createDatumPoints_1(Pro3dPnt pnt_arr[2], char* csysName) {
//
//    ruleLog.Write("=================> InterfaceRule::createDatumPoints <=================");
//    ProElement	elem_tree, elem_ftype, elem_feature_name,
//        pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
//        pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
//        pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
//    ProReference REPDEP_ref1;
//    wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wide_string[PRO_NAME_SIZE], wide_string_2[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE];
//    //CSYS_ASM_DEF
//    ProModelitem refCsysitem;
//    ProSelection refCsysSel, reqMdlSel;
//    ProFeatureCreateOptions* opts = 0;
//    ProFeature pnt_feat;
//    ProErrorlist errors;
//    //converting negative values to positive
//    double d1 = pnt_arr[0][2];
//    double d2 = pnt_arr[1][2];
//    char cDatumPointName[PRO_NAME_SIZE] = "Dist_highlght_pnt";
//
//    ProStringToWstring(wCsysName, csysName);
//    status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
//    status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);
//
//
//    //Create Element Tree
//    status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
//    ruleLog.Write("Tree root status = " + to_string(status));
//
//    // TREE ALLOCATION
//    status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
//    ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
//    ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
//    ruleLog.Write("type status = " + to_string(status));
//
//    //feature name
//    status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
//    status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, cDatumPointName));
//    status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
//    ruleLog.Write("feature name = " + to_string(status));
//
//    //PRO_E_DPOINT_TYPE
//    status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
//    status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
//    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
//    ruleLog.Write("type status = " + to_string(status));
//
//    //Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
//    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
//    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);
//
//    //ref
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
//    status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
//    status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
//    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);
//
//    //
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
//    status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
//    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);
//
//    //Populating array element
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
//    status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);
//
//    //Point1
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);
//
//    //Point1 Name
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
//    ProStringToWstring(wide_string, "datum_PNT1");
//    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);
//
//    //PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
//    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
//    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);
//
//    //PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
//    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
//    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);
//
//    //PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
//    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
//    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);
//
//    //Point2
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);
//
//    //Point2 Name
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
//    ProStringToWstring(wide_string_2, "datum_PNT2");
//    status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);
//
//    ////PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
//    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
//    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);
//
//    ////PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
//    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
//    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);
//
//    ////PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
//    status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
//    status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
//    status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
//    status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);
//
//    /* =============================================================== *\
//    Create Model Selection Object
//    \* =============================================================== */
//
//    status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
//    ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
//    status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
//
//    opts[0] = PRO_FEAT_CR_NO_OPTS;
//
//    // Create Points
//    status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
//    ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));
//
//    status = ProArrayFree((ProArray*)&opts);
//    status = ProElementFree(&elem_tree);
//    status = ProSelectionFree(&reqMdlSel);
//
//    ProSelection pnt_Sel;
//    status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
//    status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_ERROR);
//    //PRO_COLOR_SELECTED for green highlight
//    return 0;
//}


