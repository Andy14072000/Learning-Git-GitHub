/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 18-04-2023	| V1_0_0		| F3B03 - EXHAUST SYSTEM RULES
==================================================================================================================*/
#include "F1E05.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES					| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F1E05-001	| Pallavi Garodi	| MF1E05; MF1E02; MH2A02                 	| Clutch booster or clutch slave cylinder should be selected as per actuation system & release load
===================================================================================================================*/
#define DLG_IRF1E05_001 "dlg_IR_F1E05_001"
#define PB_RCANCEL      "CommitCancel"
#define PB_ROK			"CommitOK"
#define PB_IMG			"pb_image"
#define PB_RBUTTON      "pb_rbutton"
#define Radio           "RadioGroup_1"
#define optionMenu      "optionMenu"
#define optionMenu1     "optionMenu1"
#define optionMenu2     "optionMenu2"
#define optionMenu3     "optionMenu3"
string boosterEval;
string clutchEval;
string relsLoadEval;

bool isPnumaticActuation ;
vector<vector<string>> dbList2D_F1E05;
vector<string> boosterDia, slaveCylinderDia, clutchDia1, clutchDia2, releaseLoad1, releaseLoad2;
int dia1, dia2 = 0;
string releasedLoadSelVal;
string clutchDiaSelVal;
string slaveCylinderDiaSelVal;
string boosterDiaSelVal;
ComponentData			reqComps_F1E05_001[3]{};

int IRF1E05::IRF1E05_001(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF3B02::IRF3B06_003   ==========================");

	isPnumaticActuation = false;
	boosterDia.clear();
	slaveCylinderDia.clear();
	clutchDia1.clear();
	clutchDia2.clear();
	releaseLoad1.clear();
	releaseLoad2.clear();
	dia1, dia2 = 0;
	int hydraulicActu = 0;
	vector<string> reqValsFromCsvClutch1;
	vector<string> reqValsFromCsvBooster1;
	vector<string> reqValsFromCsvReleasedLoad1;
	vector<string> reqValsFromCsvSlaveCylinder;
	vector<string> reqValsFromCsvClutch2;
	vector<string> reqValsFromCsvReleasedLoad2;

	string reqCompSubModAuto[3] = { "F1E05", "F1E02", "H2A02"};	// F5A17 will be selected Automatically.
	for (int i = 0; i < subModulesList.size(); ++i) {
		for (int j = 0; j < sizeof(reqCompSubModAuto) / sizeof(reqCompSubModAuto[0]); ++j) {
			if (subModulesList[i].name.find(reqCompSubModAuto[j]) != string::npos) {
				strcpy(reqComps_F1E05_001[j].name, subModulesList[i].name.c_str());
			}
		}
	}
	/*for (int i = 0; i < subModulesList.size(); ++i)
	{
		ruleLog.Write(reqComps_F1E05_001[i].name);
	}*/
	
	// get the description of the components
	vector<PartnameDescriptionPair> name_desc_list;
	status = ProSolidFeatVisit((ProSolid)curMdl, getSubModuleDes, compsFilter, (ProAppData)&name_desc_list);
	
	for (int i = 0; i < name_desc_list.size(); ++i)
	{
		ruleLog.Write("item.name : " + string(name_desc_list.at(i).part_name));
		ruleLog.Write("item.description : " + string(name_desc_list.at(i).description));
	}

	dbList2D_F1E05 = getData2D("IRF1E05001.csv");
	ruleLog.Write("dbList2D.size():" + to_string(dbList2D_F1E05.size()));

	for (int i = 1; i < dbList2D_F1E05.size(); ++i)	// i = 1 for skipping the headers
	{
		string tok1;
		std::istringstream ss1(dbList2D_F1E05[i][0]);
		while (std::getline(ss1, tok1, ';'))
		{
			trimString(tok1);
			//ruleLog.Write("Clutch Booster Dia(mm):" + tok1);
			if (find(boosterDia.begin(), boosterDia.end(), tok1) == boosterDia.end()) {
				boosterDia.push_back(tok1);
			}
		}

		string tok2;
		std::istringstream ss2(dbList2D_F1E05[i][5]);
		while (std::getline(ss2, tok2, ';'))
		{
			trimString(tok2);
			//ruleLog.Write("clutch slave cylinder dia. (mm):" + tok2);
			//storing list of Slave Cylinder Dia from db
			if (find(slaveCylinderDia.begin(), slaveCylinderDia.end(), tok2) == slaveCylinderDia.end()) {
				slaveCylinderDia.push_back(tok2);
			}
		}

		string tok3;
		std::istringstream ss3(dbList2D_F1E05[i][1]);
		while (std::getline(ss3, tok3, ';'))
		{
			trimString(tok3);
			//ruleLog.Write("Clutch dia.1(mm):" + tok3);
			//storing list of Slave Cylinder Dia from db
			if (find(clutchDia1.begin(), clutchDia1.end(), tok3) == clutchDia1.end()) {
				clutchDia1.push_back(tok3);
			}
		}

		string tok4;
		std::istringstream ss4(dbList2D_F1E05[i][6]);
		while (std::getline(ss4, tok4, ';'))
		{
			trimString(tok4);
			//ruleLog.Write("Clutch dia.2(mm):" + tok4);
			//storing list of Slave Cylinder Dia from db
			if (find(clutchDia2.begin(), clutchDia2.end(), tok4) == clutchDia2.end()) {
				clutchDia2.push_back(tok4);
			}
		}

		string tok5;
		std::istringstream ss5(dbList2D_F1E05[i][2]);
		while (std::getline(ss5, tok5, ';'))
		{
			trimString(tok5);
			//ruleLog.Write("release load1:" + tok5);
			//storing list of release Load1 Dia from db
			if (find(releaseLoad1.begin(), releaseLoad1.end(), tok5) == releaseLoad1.end()) {
				releaseLoad1.push_back(tok5);
			}
		}

		string tok6;
		std::istringstream ss6(dbList2D_F1E05[i][7]);
		while (std::getline(ss6, tok6, ';'))
		{
			trimString(tok6);
			//ruleLog.Write("release load2:" + tok6);
			//storing list of release Load2 Dia from db
			if (find(releaseLoad2.begin(), releaseLoad2.end(), tok6) == releaseLoad2.end()) {
				releaseLoad2.push_back(tok6);
			}
		}
	}
	
	status = ProUIDialogCreate(DLG_IRF1E05_001, DLG_IRF1E05_001);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRF1E05_001, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF1E05_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_IRF1E05_001, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIOptionmenuSelectActionSet(DLG_IRF1E05_001, optionMenu, (ProUIAction)boosterDiaVal, NULL);
	status = ProUIOptionmenuSelectActionSet(DLG_IRF1E05_001, optionMenu1, (ProUIAction)slaveCylinderDiaVal, NULL);
	status = ProUIOptionmenuSelectActionSet(DLG_IRF1E05_001, optionMenu2, (ProUIAction)clutchDiaVal, NULL);
	status = ProUIOptionmenuSelectActionSet(DLG_IRF1E05_001, optionMenu3, (ProUIAction)releasedLoadVal, NULL);
	
	status = ProUIRadiogroupSelectActionSet(DLG_IRF1E05_001, Radio, (ProUIAction)rg_select_action_IRF1E05_001, NULL);
	ruleLog.Write("ProUIRadiogroupSelectActionSet status: " + to_string(status));
	status = ProUIDialogHide(DLG_IRC_MAIN);
	int radioGrpNames[2];
	char** buttonNames;

	//Radio button, selected for first button (default)
	status = ProUIRadiogroupSelectednamesGet(DLG_IRF1E05_001, Radio, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status main: " + to_string(status));
	ruleLog.Write("selected button name: " + (string)buttonNames[0]);

	//boosterDia.insert(boosterDia.begin(), "Select");
	//Set Clutch Booster Dia values in optionMenu drop down
	//option_menuF1E05001(boosterDia, optionMenu);
	option_menuF1E05001(slaveCylinderDia, optionMenu1);
	status = ProUIPushbuttonEnable(DLG_IRF1E05_001, optionMenu2);
	

	status = ProUIDialogActivate(DLG_IRF1E05_001, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));


	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_IRF1E05_001);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	status = ProUIDialogDestroy(DLG_IRF1E05_001);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (slaveCylinderDiaSelVal != "") {
		++ hydraulicActu;
		ruleLog.Write(slaveCylinderDiaSelVal);
		ruleLog.Write(clutchDiaSelVal);
		ruleLog.Write(releasedLoadSelVal);

		_getReqValsFrom2DCsvData_F3A01("IRF1E05001.csv", 7, 5, releasedLoadSelVal, reqValsFromCsvSlaveCylinder);
		/*for (auto values : reqValsFromCsvBooster1)
		{
			ruleLog.Write("reqValsFromCsvBooster1 = " + values);
		}*/
		_getReqValsFrom2DCsvData_F3A01("IRF1E05001.csv", 7, 6, releasedLoadSelVal, reqValsFromCsvClutch1);
		for (auto values : reqValsFromCsvClutch1)
		/*{
			ruleLog.Write("reqValsFromCsvClutch1 = " + values);
		}*/
		_getReqValsFrom2DCsvData_F3A01("IRF1E05001.csv", 7, 7, releasedLoadSelVal, reqValsFromCsvReleasedLoad1);
		for (auto values : reqValsFromCsvReleasedLoad1)
		/*{
			ruleLog.Write("reqValsFromCsvReleasedLoad1 = " + values);
		}*/

			if ((reqValsFromCsvSlaveCylinder[0] == slaveCylinderDiaSelVal) || (reqValsFromCsvSlaveCylinder[1] == slaveCylinderDiaSelVal))
				boosterEval = "PASS";
			else
				boosterEval = "FAIL";
			
			if ((reqValsFromCsvClutch1[0] == clutchDiaSelVal) || (reqValsFromCsvClutch1[1] == clutchDiaSelVal))
				clutchEval = "PASS";
			else
				clutchEval = "FAIL";
			if (reqValsFromCsvReleasedLoad1[0] == releasedLoadSelVal)
				relsLoadEval = "PASS";
			else
				relsLoadEval = "FAIL";


			if (((reqValsFromCsvSlaveCylinder[0] == slaveCylinderDiaSelVal) || (reqValsFromCsvSlaveCylinder[1] == slaveCylinderDiaSelVal)) && ((reqValsFromCsvClutch1[0] == clutchDiaSelVal) || (reqValsFromCsvClutch1[1] == clutchDiaSelVal)) && (reqValsFromCsvReleasedLoad1[0] == releasedLoadSelVal))
				isRightValue = true;
				
	}
	else {

		ruleLog.Write(boosterDiaSelVal);
		ruleLog.Write(clutchDiaSelVal);
		ruleLog.Write(releasedLoadSelVal);

		_getReqValsFrom2DCsvData_F3A01("IRF1E05001.csv", 2, 0, releasedLoadSelVal, reqValsFromCsvBooster1);
		/*for (auto values : reqValsFromCsvSlaveCylinder)
		{
			ruleLog.Write("reqValsFromCsvSlaveCylinder = " + values);
		}*/
		_getReqValsFrom2DCsvData_F3A01("IRF1E05001.csv", 2, 1, releasedLoadSelVal, reqValsFromCsvClutch2);
		/*for (auto values : reqValsFromCsvClutch2)
		{
			ruleLog.Write("reqValsFromCsvClutch2 = " + values);
		}*/
		_getReqValsFrom2DCsvData_F3A01("IRF1E05001.csv", 2, 2, releasedLoadSelVal, reqValsFromCsvReleasedLoad2);
		/*for (auto values : reqValsFromCsvReleasedLoad2)
		{
			ruleLog.Write("reqValsFromCsvReleasedLoad2 = " + values);
		}*/
		if ((reqValsFromCsvBooster1[0] == boosterDiaSelVal) || (reqValsFromCsvBooster1[1] == boosterDiaSelVal))
			boosterEval = "PASS";
		else
			boosterEval = "FAIL";

		if ((reqValsFromCsvClutch2[0] == clutchDiaSelVal) || (reqValsFromCsvClutch2[1] == clutchDiaSelVal))
			clutchEval = "PASS";
		else
			clutchEval = "FAIL";

		if (reqValsFromCsvReleasedLoad2[0] == releasedLoadSelVal)
			relsLoadEval = "PASS";
		else
			relsLoadEval = "FAIL";

		if (((reqValsFromCsvBooster1[0] == boosterDiaSelVal) || (reqValsFromCsvBooster1[1] == boosterDiaSelVal)) && ((reqValsFromCsvClutch2[0] == clutchDiaSelVal) || (reqValsFromCsvClutch2[1] == clutchDiaSelVal)) && (reqValsFromCsvReleasedLoad2[0] == releasedLoadSelVal))
			isRightValue = true;
			
	}

	ruleLog.Write("reqValsFromCsvClutch1.size() = " + to_string(reqValsFromCsvClutch1.size()));

	// DECLARE RESULT
	if (isRightValue) 
		final_res.result = "PASS";

	else
		final_res.result = "FAIL";

	string rem_message;
	if (hydraulicActu != 0) {
		rem_message += "Selected actuation system is hydraulic.\n";
		rem_message += "Provided values for clutch slave cylinder dia:- " + slaveCylinderDiaSelVal + " mm[" + boosterEval + "],\n";
		rem_message += "clutch dia:- " + clutchDiaSelVal + " mm[" + clutchEval + "],\n";
		rem_message += "released load:- " + releasedLoadSelVal + " Kg[" + relsLoadEval + "].\n\n";
		//rem_message += "Provided values for clutch slave cylinder dia, clutch dia and released load is " + slaveCylinderDiaSelVal + " mm,["+ boosterEval +"]" + clutchDiaSelVal + " mm["+ clutchEval +"] and " + releasedLoadSelVal + " Kg["+ relsLoadEval +"] respectively.\n\n";
		rem_message += "Rule perform on following sub-module:-\n";
		for (int i = 0; i < name_desc_list.size(); ++i)
		{
			rem_message += string(name_desc_list.at(i).part_name) + "[" + string(name_desc_list.at(i).description) +"]\n";
		}
		
		rem_message += "\nAcceptance Criteria: \nclutch slave cylinder dia,:- ";
		for (int i = 0; i < reqValsFromCsvSlaveCylinder.size(); i++) {
			if (i != 0)
				rem_message += " or ";
			rem_message += reqValsFromCsvSlaveCylinder[i];

		}

		rem_message += " mm";
		rem_message += "\nClutch dia:- ";
		for (int i = 0; i < reqValsFromCsvClutch1.size(); i++) {
			if (i != 0)
				rem_message += " or ";
			rem_message += reqValsFromCsvClutch1[i];
		}
		rem_message += " mm";
		rem_message += "\nRelease load:- " + reqValsFromCsvReleasedLoad1[0] + " Kg";
	}
	else {
		rem_message += "Selected actuation system is pneumatic.\n";
		rem_message += "Provided values for clutch Booster Dia:- " + boosterDiaSelVal + " mm[" + boosterEval + "],\n";
		rem_message += "clutch dia:- " + clutchDiaSelVal + " mm[" + clutchEval + "],\n";
		rem_message += "released load:- " + releasedLoadSelVal + " Kg[" + relsLoadEval + "].\n\n";
		//rem_message += "Provided values for clutch Booster Dia, clutch dia. and released load is " + boosterDiaSelVal + " mm, " + clutchDiaSelVal + " mm and " + releasedLoadSelVal + " Kg respectively.\n\n";
		rem_message += "Rule perform on following sub-module:-\n";
		for (int i = 0; i < name_desc_list.size(); ++i)
		{
			rem_message += string(name_desc_list.at(i).part_name) + "[" + string(name_desc_list.at(i).description) + "]\n";
		}
		rem_message += "\nAcceptance Criteria: \nClutch Booster Dia:- ";
		for (int i = 0; i < reqValsFromCsvBooster1.size(); i++) {
			if (i != 0)
				rem_message += " or ";
			rem_message += reqValsFromCsvBooster1[i];
		}
		rem_message += " mm";
		rem_message += "\nClutch dia:- ";
		for (int i = 0; i < reqValsFromCsvClutch2.size(); i++) {
			if (i != 0)
				rem_message += " or ";
			rem_message += reqValsFromCsvClutch2[i];
		}
		rem_message += " mm";
		rem_message += "\nRelease load:- " + reqValsFromCsvReleasedLoad2[0] + " Kg";
	}

	final_res.remark = rem_message;

	boosterDia.clear();
	slaveCylinderDia.clear();
	clutchDia1.clear();
	clutchDia2.clear();
	releaseLoad1.clear();
	releaseLoad2.clear();
	dbList2D_F1E05.clear();
	reqValsFromCsvBooster1.clear();
	reqValsFromCsvClutch1.clear();
	reqValsFromCsvReleasedLoad1.clear();
	return 0;
}

ProError getSubModuleDes(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("----------------------------- getParameterDescAndPartname -----------------------------");

	vector<PartnameDescriptionPair>* prtname_desc_list = (vector<PartnameDescriptionPair>*)app_data;

	ProMdlType subModuleMdlType;
	ProModelitem modelItem;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ProMdl reqMdl;
	char existingPval[PRO_NAME_SIZE]{};
	PartnameDescriptionPair compd{};

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	//ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
	status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
	//ruleLog.Write("ProMdlTypeGet: " + to_string(status));
	status = ProMdlMdlnameGet(reqMdl, wFeatName);
	//ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(cFeatName, wFeatName);

	status = ProMdlToModelitem(reqMdl, &modelItem);
	//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProParameter pDesc;
	ProParamvalue pvDesc;
	ProName pDescName = L"DESCRIPTION";

	status = ProParameterInit(&modelItem, pDescName, &pDesc);
	//ruleLog.Write("ProParameterInit: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)
	{
		status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
		ProWstringToString(existingPval, pvDesc.value.s_val);
		//ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);

		strcpy(compd.description, existingPval);
		//ruleLog.Write("compd.description" + string(compd.description));
	}
	strcpy(compd.part_name, cFeatName);
	//ruleLog.Write("compd.part_name: " + string(compd.part_name));

	prtname_desc_list->push_back(compd);
	//memset(compd.description, 0, sizeof(compd.description));

	return PRO_TK_NO_ERROR;
}

ProError rg_select_action_IRF1E05_001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("============== radioGrpSelectAction ==============");
	int radioGrpNames[2];
	char** buttonNames;
	char selectedButton[PRO_NAME_SIZE];
	InterfaceRule iRule;
	boosterDiaSelVal.clear();
	slaveCylinderDiaSelVal.clear();
	clutchDiaSelVal.clear();
	releasedLoadSelVal.clear();
	ProUIPushbuttonDisable(dialog, PB_ROK);
	/*ruleLog.Write(" 1 " + boosterDiaSelVal);
	ruleLog.Write(" 2 " + slaveCylinderDiaSelVal);
	ruleLog.Write(" 3 " + clutchDiaSelVal);
	ruleLog.Write(" 4 " + releasedLoadSelVal);*/
	status = ProUIRadiogroupSelectednamesGet(dialog, component, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status: " + to_string(status));
	ruleLog.Write("selected button name: " + (string)buttonNames[0]);

	if (strcmp(buttonNames[0], "rb1") == 0)
	{
		status = ProUIPushbuttonDisable(dialog, optionMenu);
		status = ProUIPushbuttonEnable(dialog, optionMenu1);
		status = ProUIPushbuttonDisable(dialog, optionMenu2);
		status = ProUIPushbuttonDisable(dialog, optionMenu3);
		//Set clutch slave cylinder dia. values in optionMenu1 drop down
		option_menuF1E05001(slaveCylinderDia, optionMenu1);
	}
	else
	{
		status = ProUIPushbuttonEnable(dialog, optionMenu);
		status = ProUIPushbuttonDisable(dialog, optionMenu1);
		status = ProUIPushbuttonDisable(dialog, optionMenu2);
		status = ProUIPushbuttonDisable(dialog, optionMenu3);
		option_menuF1E05001(boosterDia, optionMenu);			
	}
	return status;
}

ProError boosterDiaVal(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- boosterDiaSelVal -----------------------------");
	string* _data = (string*)data;
	int n_sel;
	char** selValue;
	ProUIPushbuttonDisable(dialog, PB_ROK);
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("boosterDia = " + string(selValue[0]));
	boosterDiaSelVal = string(selValue[0]);

	if (boosterDiaSelVal == "Select")
	{
		ProUIPushbuttonDisable(dialog, optionMenu2);
	}
	else {
		//clutchDia1.insert(clutchDia1.begin(), "Select");
		status = ProUIPushbuttonEnable(dialog, optionMenu2);
		option_menuF1E05001(clutchDia1, optionMenu2);
		++dia1;
		/*for (auto values : clutchDia1) {
			ruleLog.Write("clutchDia1 = " + values);
		}*/
		//status = ProUIPushbuttonEnable(dialog, optionMenu3);
	}
	return PRO_TK_NO_ERROR;
}

ProError slaveCylinderDiaVal(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- platformList -----------------------------");
	string* _data = (string*)data;
	int n_sel;
	char** selValue;
	ProUIPushbuttonDisable(dialog, PB_ROK);
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("slaveCylinderDiaSelVal = " + string(selValue[0]));
    slaveCylinderDiaSelVal = string(selValue[0]);

	if (slaveCylinderDiaSelVal == "Select")
	{
		ProUIPushbuttonDisable(dialog, optionMenu2);
	}
	else {
		//clutchDia2.insert(clutchDia2.begin(), "Select");
		status = ProUIPushbuttonEnable(dialog, optionMenu2);
		option_menuF1E05001(clutchDia2, optionMenu2);
		++dia2;
		/*for (auto values : clutchDia2) {
			ruleLog.Write("clutchDia2 = " + values);
		}*/
	}
	return PRO_TK_NO_ERROR;
}

ProError clutchDiaVal(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- platformList -----------------------------");
	string* _data = (string*)data;
	int n_sel;
	char** selValue;
	ProUIPushbuttonDisable(dialog, PB_ROK);
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("clutchDia = " + string(selValue[0]));
	clutchDiaSelVal = string(selValue[0]);
	if (clutchDiaSelVal == "Select")
	{
		ProUIPushbuttonDisable(dialog, optionMenu3);
	}
	else {
		if (dia1 != 0)
		{
			status = ProUIPushbuttonEnable(dialog, optionMenu3);
			option_menuF1E05001(releaseLoad1, optionMenu3);
			/*for (auto values : releaseLoad1) {
				ruleLog.Write("releaseLoad1 = " + values);
			}*/
		}
		if (dia2 != 0)
		{
			status = ProUIPushbuttonEnable(dialog, optionMenu3);
			option_menuF1E05001(releaseLoad2, optionMenu3);
			/*for (auto values : releaseLoad2) {
				ruleLog.Write("releaseLoad2 = " + values);
			}*/
		}
	}
	return PRO_TK_NO_ERROR;
}

ProError releasedLoadVal(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- releasedLoadKg -----------------------------");
	string* _data = (string*)data;
	int n_sel;
	char** selValue;
	InterfaceRule irc;
	ProUIPushbuttonDisable(dialog, PB_ROK);
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("releasedLoadKg = " + string(selValue[0]));
	releasedLoadSelVal = string(selValue[0]);

	if (releasedLoadSelVal != "Select")
	{
		ProUIPushbuttonEnable(dialog, PB_ROK);
	}	
	return PRO_TK_NO_ERROR;
}

void option_menuF1E05001(vector<string> option_menulist, char* optionmenu) 
{

	ruleLog.Write("----------------------------- option_menuF1E05001 -----------------------------");

	char** loadCapListNames;
	wchar_t** loadCapListLabels;

	option_menulist.insert(option_menulist.begin(), "Select");

	status = ProArrayAlloc(option_menulist.size(), sizeof(char*), 50, (ProArray*)&loadCapListNames);
	status = ProArrayAlloc(option_menulist.size(), sizeof(wchar_t*), 50, (ProArray*)&loadCapListLabels);

	for (int i = 0; i < option_menulist.size(); ++i)
	{
		loadCapListNames[i] = (char*)calloc(50, sizeof(char));
		ProTKSprintf(loadCapListNames[i], "%s", option_menulist[i]);

		loadCapListLabels[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
		ProStringToWstring(loadCapListLabels[i], loadCapListNames[i]);
	}
	status = ProUIOptionmenuNamesSet(DLG_IRF1E05_001, optionmenu, int(option_menulist.size()), loadCapListNames);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(DLG_IRF1E05_001, optionmenu, int(option_menulist.size()), loadCapListLabels);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

	status = ProArrayFree((ProArray*)&loadCapListNames);
	status = ProArrayFree((ProArray*)&loadCapListLabels);
}

void getengineCapdatafromcsvF1E05001(vector<vector<string>> dbList2D_F3A01, string platformName, vector<string>& values) {

	ruleLog.Write("----------------------------- getengineCapdatafromcsv -----------------------------");

	for (int i = 1; i < dbList2D_F3A01.size(); ++i) {
		while (dbList2D_F3A01[i][0].compare(platformName) == 0) {
			string str = dbList2D_F3A01[i][1];
			if (find(values.begin(), values.end(), str) == values.end()) {
				values.push_back(str);
			}
			break;
		}
	}
	ruleLog.Write("platform.size:" + to_string(values.size()));
}




