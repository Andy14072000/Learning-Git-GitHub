/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 05-07-2023	|	V1_0_0		| F1D02 - WINCH SYSTEM RULES
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#include "F1D02.h"
/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF1D02_001 	| Mathanprasath A	| MF1D02            | Winch should be mounted near the center of Vehicle Front (Width) in lateral direction
===================================================================================================================*/
#define DLG_IRF1D02_001     "dlg_IR_F1D02_001"
#define CommitOK            "CommitOK"
#define CommitCancel		"CommitCancel"
#define RB_WINCH_TYPE       "rb_winch_type"
#define PB_SELECT           "select_pb"

ProSelection*       SurfSels;
char**              sel_names;
string              remf1d02_001;

int IRF1D02::IRF1D02_001(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF1D02::IRF1D02_001   ==========================");
    remf1d02_001.clear();
    double distance1, distance2;
    const char rightPlaneName[PRO_NAME_SIZE] = "ASM_XZ";
    /*ComponentData _reqComps[6]{};
    string reqCompSubMod[6] = { "F1D02","D1A05","D1A06","G1C01","G1A05","G1A06" };
    for (int i = 0; i < subModulesList.size(); ++i)
    for (int j = 0; j < 2; ++j)
    if (subModulesList[j].name.find(reqCompSubMod[j]) != string::npos)
    strcpy(_reqComps[j].name, subModulesList[j].name.c_str());*/

    for (int i = 0; i < subModulesList.size(); ++i) {
        if (subModulesList[i].name.find("F1D02") != std::string::npos) {
            _reqSMinfo = subModulesList[i];
            break;
        }
    }

    isUserQuits = false;
    status = ProUIDialogCreate(DLG_IRF1D02_001, DLG_IRF1D02_001);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF1D02_001, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF1D02_001, CommitOK, (ProUIAction)ruleDlgOKaction, NULL);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF1D02_001, CommitCancel, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF1D02_001, PB_SELECT, (ProUIAction)select_action_IRF1D02_001, (ProAppData)&isUserQuits);
    status = ProUIRadiogroupSelectActionSet(DLG_IRF1D02_001, RB_WINCH_TYPE, (ProUIAction)rg_select_action_IRF1D02_001, NULL);
    ruleLog.Write("ProUIRadiogroupSelectActionSet: " + to_string(status));

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF1D02_001, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF1D02_001);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    Pro2dPnt param_1, param_2;
    Pro3dPnt pnt_1, pnt_2;
    status = ProSelectionWithOptionsDistanceEval(SurfSels[0], PRO_B_TRUE, SurfSels[2], PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance1);
    ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(distance1));
    if (rule_sts != 0)
        return -1;

    status = ProSelectionWithOptionsDistanceEval(SurfSels[1], PRO_B_TRUE, SurfSels[2], PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance2);
    ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(distance2));
    if (rule_sts != 0)
        return -1;

    compareFloat(distance1, distance2);
    ruleLog.Write("compare_float: " + to_string(status));
    float Deviated, final_val;
    Deviated = distance1 - distance2;
    if (Deviated < 0) {
        final_val = std::abs(Deviated);
        ruleLog.Write("abs Deviated: " + to_string(Deviated));
    }
    else
    {
        final_val = Deviated;
        ruleLog.Write("Deviated: " + to_string(Deviated));
    }

    if (final_val <= 1000)
    {
        final_res.result = "PASS";
        sprintf(remark, "Winch is mounted %0.1fmm from the center of vehicle.\n Acceptance criteria: Winch should be mounted near the center of vehicle.", final_val);
        final_res.remark = string(remark) + remf1d02_001;
    }
    else
    {
        final_res.result = "FAIL";
        sprintf(remark, "Winch is %0.1fmm deviated from the center of vehicle.\nAcceptance criteria: Winch should be mounted near the center of vehicle.", final_val);
        final_res.remark = string(remark) + remf1d02_001;
    }
    ruleLog.Write("status: " + final_res.result);
    ruleLog.Write("remark: " + final_res.remark);

    return 0;
}

ProError select_action_IRF1D02_001(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- select_action_IRF1D02001 -----------------------------");
    InterfaceRule _irule;
    int n_sel;
    bool* quitAction = (bool*)data;

    status = ProSelect((char*)"surface,datum", 3, NULL, NULL, NULL, NULL, &SurfSels, &n_sel);
    ruleLog.Write("ProSelect: " + to_string(status));

    InterfaceRule _irrule;

    if (status == PRO_TK_USER_ABORT)
    {
        //_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
        status = ProUIPushbuttonDisable(dialog, CommitOK);
        ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
        return status;
    }
    else if (n_sel < 3 || status != PRO_TK_NO_ERROR)
    {
        _irrule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
        status = ProUIPushbuttonDisable(dialog, CommitOK);
        ruleLog.Write("ProUIPushbuttonDisable status = " + to_string(status));
        return status;
    }
  

    /*double D;
    status = ProGeomitemDiameterEval(*SurfSels, &D);
    ruleLog.Write("ProGeomitemDiameterEval = " + to_string(status));

    if ((status) == 0)
    {
    _irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Selected surface is curved, Please select flat surface");
    }*/
    ProMdlName		wname;
    char            cname[PRO_MDLNAME_SIZE];
    ProFeature feature;
    remf1d02_001.clear();
    remf1d02_001 += "\nSelection Info: \n";
    for (int i = 0; i < 3; ++i)
    {
        status = ProSelectionModelitemGet(SurfSels[i], &feature);
        status = ProMdlMdlnameGet(feature.owner, wname);
        ProWstringToString(cname, wname);
        ruleLog.Write("part_names: " + to_string(feature.id));
        remf1d02_001.append(string(cname) + ".prt[Surface ID: " + to_string(feature.id) + "] " + "\n");
        ruleLog.Write("Selection Surf Id = " + to_string(feature.id));
    }
    if (status == PRO_TK_USER_ABORT) {
        status = ProUIPushbuttonDisable(DLG_IRF1D02_001, CommitOK);
        if (quitAction != NULL)
            *quitAction = true;
        return status;
    }
    if (n_sel < 2 || status != PRO_TK_NO_ERROR) {
        _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
        if (quitAction != NULL)
            *quitAction = true;
        status = ProUIPushbuttonDisable(DLG_IRF1D02_001, CommitOK);
        return status;
    }

    status = ProUIPushbuttonEnable(DLG_IRF1D02_001, CommitOK);
    ruleLog.Write("ProUIPushbuttonEnable: " + to_string(status));

    return status;
}

ProError rg_select_action_IRF1D02_001(char* dialog, char* component, ProAppData data)
{
    ruleLog.Write("----------------------------- rg_select_action_IRF1D02_001 -----------------------------");

    int	n_names;
    char** r_names;
    status = ProUIRadiogroupSelectednamesGet(DLG_IRF1D02_001, RB_WINCH_TYPE, &n_names, &r_names);
    ruleLog.Write("ProUIRadiogroupSelectednamesGet: " + to_string(status));


    if (strcmp(r_names[0], "rb2") == 0) {
        // SIDE MOUNTED WINCH SYSTEM
        _utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Not Applicable", "This Rule is only applicable for Front Mounted Winch System");

        char cRB1[PRO_NAME_SIZE] = "rb1";
        char* ptrRB1 = cRB1;
        status = ProUIRadiogroupSelectednamesSet(DLG_IRF1D02_001, RB_WINCH_TYPE, 1, &ptrRB1);
        ruleLog.Write("ProUIRadiogroupSelectednamesSet: " + to_string(status));
    }
    return status;
}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF1D02_004     | Pallavi Garodi	| MF1D02			|  Standard fasteners of 10.9 grade or above should be used for mounting arrangements
===================================================================================================================*/
#define DLG_IRF1D02_004 "dlg_IR_F1D02_004"
#define PB_ROK			"CommitOK"
#define PB_RCANCEL		"CommitCancel"

int IRF1D02::IRF1D02_004(ruleResult& final_res)
{
    ruleLog.Write("==========================   IRF1D02::IRF1D02_004   ==========================");
    ruleLog.Write("\nStandard fasteners of 10.9 grade or above should be used for mounting arrangements");

    string                     remarkMsg{};
    double                     stdGradeBolt = 10.9;
    double                     stdGradeNut = 10.0;
    vector<HardwareInfo>      _hwInfo;
    vector<HardwareInfo>      _nonStdHwInfo;
    string                     typeOfHw;
    typeOfHw = "NUT";
    ProSelection               selection;
    ProAsmcomppath             path;
    int                        curWinId;

    //Clearing the vectors for fresh run
    _hwInfo.clear();
    _nonStdHwInfo.clear();
    ProWindowCurrentGet(&curWinId);
    ProWindowRepaint(curWinId);

    isUserQuits = false;
    status = ProUIDialogCreate(DLG_IRF1D02_004, DLG_IRF1D02_004);
    status = ProUIDialogAboveactivewindowSet(DLG_IRF1D02_004, PRO_B_FALSE);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF1D02_004, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
    status = ProUIPushbuttonActivateActionSet(DLG_IRF1D02_004, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);

    status = ProUIDialogHide(DLG_IRC_MAIN);
    status = ProUIDialogActivate(DLG_IRF1D02_004, &dlg_sts);
    ruleLog.Write("ProUIDialogActivate: " + to_string(status));
    status = ProUIDialogDestroy(DLG_IRF1D02_004);
    ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
    status = ProUIDialogShow(DLG_IRC_MAIN);

    if (isUserQuits)
        return -1;

    status = ProSolidFeatVisit((ProSolid)curMdl, (ProFeatureVisitAction)visit11DigitComponents, compsFilter, &_hwInfo);
    ruleLog.Write(to_string(_hwInfo.size()));

    for (int i = 0; i < _hwInfo.size(); i++)
    {
        if (((_hwInfo.at(i).typeOfHw == typeOfHw) && (_hwInfo.at(i).gradeDb < stdGradeNut)) ||
            ((_hwInfo.at(i).typeOfHw != typeOfHw) && (_hwInfo.at(i).gradeDb < stdGradeBolt)))
        {
            _nonStdHwInfo.push_back(_hwInfo.at(i));
            status = ProAsmcomppathInit((ProSolid)curMdl, &_hwInfo.at(i).ID, 1, &path);
            ruleLog.Write("ProAsmcomppathInit : " + to_string(status));
            status = ProSelectionAlloc(&path, &_hwInfo.at(i).Item, &selection);
            ruleLog.Write("ProSelectionAlloc : " + to_string(status));
            status = ProSelectionHighlight(selection, PRO_COLOR_HIGHLITE);
            ruleLog.Write("ProSelectionHighlight : " + to_string(status));
        }
    }

    //Write the remarks
    if ((_nonStdHwInfo.size() == 0) && (_hwInfo.size() != 0))
    {
        remarkMsg += "All the fasteners used in the model are of standard grade.";
        ruleLog.Write("All the fasteners used in the model are of standard grade.");
    }
    if (_hwInfo.size() == 0)
    {
        remarkMsg += "There are no fasteners present in the model, hence the rule is passed.";
        ruleLog.Write("There are no fasteners present in the model\n");
        ruleLog.Write("Hence the rule is passed.");
    }
    if (_nonStdHwInfo.size() != 0)
    {
        remarkMsg += "List of hardware part numbers of non standard grade\n";
        vector<double>      uniqueGradeList;
        vector<string>      partsOfSpecificGrade;
        uniqueGradeList.clear();



        //Create a grade list with non repeating values
        for (int i = 0; i < _nonStdHwInfo.size(); i++)
        {
            uniqueGradeList.push_back(_nonStdHwInfo.at(i).gradeDb);
            sort(uniqueGradeList.begin(), uniqueGradeList.end(), [](double a, double b) {
                return a > b; // Compare in descending order
                });
            auto last = unique(uniqueGradeList.begin(), uniqueGradeList.end());
            uniqueGradeList.erase(last, uniqueGradeList.end());
        }



        //create a vector of part names having a specific grade
        for (int i = 0; i < uniqueGradeList.size(); i++)
        {
            partsOfSpecificGrade.clear();
            double target = uniqueGradeList.at(i);
            remarkMsg += "\nGrade ";
            double rounded1 = round(target * 10) / 10;
            string t = to_string(rounded1);
            t.erase(t.find_last_not_of('0') + 1, string::npos);
            remarkMsg += t;
            remarkMsg += "-\n";



            for (int j = 0; j < _nonStdHwInfo.size(); j++)
            {
                if (target == _nonStdHwInfo.at(j).gradeDb)
                {
                    partsOfSpecificGrade.push_back(_nonStdHwInfo.at(j).compName);
                }
            }
            //Count the repetitions of a part
            map<string, int> elementCount;
            for (const auto& part : partsOfSpecificGrade)
            {
                elementCount[part]++;
            }
            for (const auto& entry : elementCount)
            {
                remarkMsg += entry.first;
                remarkMsg += ".PRT(";
                remarkMsg += to_string(entry.second);
                remarkMsg += "), ";
            }
            elementCount.clear();
        }
        double rounded = round(stdGradeBolt * 10) / 10;
        string outputStdGrd = to_string(rounded);
        outputStdGrd.erase(outputStdGrd.find_last_not_of('0') + 1, string::npos);
        remarkMsg += "\n\nAcceptance Criteria = Grade ";
        remarkMsg += outputStdGrd;
        remarkMsg += " or above";
    }
    ruleLog.Write("----- Remark msg ----- \n" + remarkMsg);



    //Declare result
    if ((_hwInfo.size() == 0) || (_nonStdHwInfo.size() == 0))
    {
        final_res.result = "PASS";
        final_res.remark = remarkMsg;
        ruleLog.Write("Status = " + final_res.result);
    }
    else
    {
        final_res.result = "FAIL";
        final_res.remark = remarkMsg;
        ruleLog.Write("Status = " + final_res.result);
        ruleLog.Write("Reason : ");
        ruleLog.Write("Non standard hardware used in the model");
    }
    ruleLog.Write(remarkMsg);
    return 0;
}
#pragma pop