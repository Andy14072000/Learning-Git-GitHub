/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F3A01 - CHASIS CONTROLS RULES
==================================================================================================================*/
#include "F3A01.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F3A01-001	| Pallavi Garodi	| MF3A01			| Define fixed zone for fuel tank packaging across all models within platform.
===================================================================================================================*/
#define DLG_F3A01_001   "dlg_IR_F3A01_001"
#define PB_RCANCEL      "rule_cancel_pb"
#define PB_ROK          "rule_ok_pb"
#define PB_RSELECT      "rule_select_pb"
#define PB_RIMG		    "PB_RIMG"
#define PushButton1	    "fuleTank_img2"
#define OptionMenu1	    "OptionMenu1"
#define platform	    "platform"
#define vehicalType	    "vehicalType"

char tempPln1[PRO_NAME_SIZE] = "TEM_PLN1", tempPln2[PRO_NAME_SIZE] = "TEM_PLN2";
string subPlatFVal = "", PlatFVal = "";
vector<vector<string>> dbList2D_F3A01;
vector<string> reqValsFromCsv_F3A01;
boolean isProjectCodeFound = false;
ProSelection* fuel_tank_surf;
int                         Case = 0;
double                      dist1, dist2;

int IRF3A01::IRF3A01_001(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF3A01::IRF3A01_012   ==========================");

	isProjectCodeFound = false;
	InterfaceRule     _irule;
	int               curWinId;
	vector<IntAndStringlistMap> distanceList;
	final_res.remark.clear();
	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);
	reqValsFromCsv_F3A01.clear();

	vector<string> platformValFrmCSV, subPlatform, projectCodes, platformVal;;

	// find the sub-module info
	for (int i = 0; i < subModulesList.size(); ++i) {
		if (subModulesList[i].name.find("F3A01") != string::npos) {
			_reqSMinfo = subModulesList[i];
			break;
		}
	}

	// extracting the project code of opened model
	project_code = stoi(string(_reqSMinfo.name).substr(0, 4));
	ruleLog.Write("Project Code: " + to_string(project_code));
	string projectC_str = to_string(project_code);

	dbList2D_F3A01 = getData2D("IRF3A01001.csv");
	ruleLog.Write("dbList2D.size():" + to_string(dbList2D_F3A01.size()));

	for (int i = 1; i < dbList2D_F3A01.size(); ++i)	// i = 1 for skipping the headers
	{
		string tok1;
		std::istringstream ss1(dbList2D_F3A01[i][2]);
		while (std::getline(ss1, tok1, ';'))
		{
			ruleLog.Write("project code from CSV:" + tok1);
			//storing list of project codes from db
			projectCodes.push_back(tok1);
		}

		string tok2;
		std::istringstream ss2(dbList2D_F3A01[i][0]);
		while (std::getline(ss2, tok2, ';'))
		{
			trimString(tok2);
			ruleLog.Write("Platform: " + tok2);
			//storing list of Platforms from db
			if (find(platformValFrmCSV.begin(), platformValFrmCSV.end(), tok2) == platformValFrmCSV.end()) {
				platformValFrmCSV.push_back(tok2);
			}
		}
	}

	ruleLog.Write("projectCodes.size(): " + to_string(projectCodes.size()));

	for (auto str : platformValFrmCSV) {
		ruleLog.Write("platformValFrmCSV: " + str);
	}
	ruleLog.Write("platformValFrmCSV.size(): " + to_string(platformValFrmCSV.size()));

	isUserQuits = false;

	//check whether the project code is available or not in db
	for (int i = 0; i < projectCodes.size(); i++) {
		if ((projectC_str.compare(projectCodes.at(i))) == 0) {
			isProjectCodeFound = true;
			break;
		}
	}

	if (isProjectCodeFound == true) {
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Input Found", "Project Code present in CSV file.");
		getReqValsFrom2DCsvData("IRF3A01001.csv", 2, 3, project_code, reqValsFromCsv_F3A01);
		getReqValsFrom2DCsvData("IRF3A01001.csv", 2, 0, project_code, platformVal);
		getReqValsFrom2DCsvData("IRF3A01001.csv", 2, 1, project_code, subPlatform);
		ruleLog.Write("platformVal = " + platformVal.at(0));
		ruleLog.Write("engineCap = " + subPlatform.at(0));
		PlatFVal = platformVal.at(0);
		subPlatFVal = subPlatform.at(0);
		ruleLog.Write("Values = " + reqValsFromCsv_F3A01.at(0));
		ruleLog.Write("Values = " + reqValsFromCsv_F3A01.at(1));
	}
	else
	{
		ProUIPushbuttonEnable(DLG_F3A01_001, platform);
	}

	//if project code found in db assign default platform value in PB_SELECT_PLATFORM dropdown
	if (PlatFVal != "")
	{
		// Bring the PlatformVal to the start of the vector
		auto it = std::find(platformValFrmCSV.begin(), platformValFrmCSV.end(), PlatFVal);
		if (it != platformValFrmCSV.end()) {
			std::rotate(platformValFrmCSV.begin(), it, it + 1);
		}
	}
	else
	{
		platformValFrmCSV.insert(platformValFrmCSV.begin(), "Select");
	}

	status = ProUIDialogCreate(DLG_F3A01_001, DLG_F3A01_001);
	status = ProUIDialogAboveactivewindowSet(DLG_F3A01_001, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_F3A01_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F3A01_001, PB_ROK, (ProUIAction)ruleDlgOKaction, (ProAppData)&isUserQuits);

	// For Image
	string optionMenuActionData[3] = { PB_RIMG, "IR_F3A01_001", PB_RSELECT };
	status = ProUIOptionmenuSelectActionSet(DLG_F3A01_001, OptionMenu1, (ProUIAction)_optionMenuImageChangeAction, (ProAppData)&optionMenuActionData);
	status = ProUIPushbuttonActivateActionSet(DLG_F3A01_001, PB_ROK, (ProUIAction)run_action_IRF3A01001, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_F3A01_001, PB_RSELECT, (ProUIAction)select_action_IRF3A01001, (ProAppData)&isUserQuits);

	status = ProUIOptionmenuSelectActionSet(DLG_F3A01_001, platform, (ProUIAction)platformListF3A01001, NULL);
	status = ProUIOptionmenuSelectActionSet(DLG_F3A01_001, vehicalType, (ProUIAction)subplatformListF3A01001, NULL);

	//Set platform values in PB_SELECT_PLATFORM drop down
	option_menuF3A01001(platformValFrmCSV, platform);

	//if project code is found
	if (subPlatform.size() != 0) {
		option_menuF3A01001(subPlatform, vehicalType);
	}


	char** shapeNames;
	wchar_t** shapeLabels;
	vector<string> Type;
	Type = { "SELECT", "RECTANGLE", "ROUND" };

	status = ProArrayAlloc(Type.size(), sizeof(char*), 50, (ProArray*)&shapeNames);
	status = ProArrayAlloc(Type.size(), sizeof(wchar_t*), 50, (ProArray*)&shapeLabels);

	for (int i = 0; i < Type.size(); ++i)
	{
		shapeNames[i] = (char*)calloc(50, sizeof(char));
		ProTKSprintf(shapeNames[i], "%s", Type[i]);

		shapeLabels[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
		ProStringToWstring(shapeLabels[i], shapeNames[i]);
	}

	status = ProUIOptionmenuNamesSet(DLG_F3A01_001, OptionMenu1, int(Type.size()), shapeNames);
	//ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(DLG_F3A01_001, OptionMenu1, int(Type.size()), shapeLabels);
	//ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

	status = ProUIPushbuttonBitmapSet(DLG_F3A01_001, PB_RIMG, "IR_F3A01_001/Rectangle.png");	// default image
	//ruleLog.Write("ProUIPushbuttonBitmapSet rule: " + to_string(status));

	status = ProArrayFree((ProArray*)&shapeNames);
	//ruleLog.Write("ProArrayFree N" + to_string(status));
	status = ProArrayFree((ProArray*)&shapeLabels);
	//ruleLog.Write("ProArrayFree L" + to_string(status));

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_F3A01_001, &dlg_sts);
	//uleLog.Write("ProUIDialogActivate: " + to_string(status));

	// check for user quits in close_action
	if (isUserQuits) {
		status = ProUIDialogDestroy(DLG_F3A01_001);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}

	status = ProUIDialogDestroy(DLG_F3A01_001);
	//ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	if (compareFloat(stod(reqValsFromCsv_F3A01[0]), dist1) && compareFloat(stod(reqValsFromCsv_F3A01[1]), dist2)) {
		isRightValue = true;
	}

	// DECLARE RESULT
	if (isRightValue) {
		final_res.result = "PASS";
		sprintf(remark, "Platform     : %s;Sub Platform : %s ;\nResult:\nMeasured Value = Distance between StartPoint_FuleTank-FACL : %0.2lfmm and EndPoint_FuleTank-FACL: %0.2lfmm \nAcceptance criteria: %0.2lfmm and %0.2lfmm.", PlatFVal.c_str(), subPlatFVal.c_str(), dist1, dist2, stod(reqValsFromCsv_F3A01[0]), stod(reqValsFromCsv_F3A01[1]));
		final_res.remark = string(remark);
	}
	else {
		final_res.result = "FAIL";
		sprintf(remark, "Platform     : %s;Sub Platform : %s ;\nResult:\nMeasured Value = Distance between StartPoint_FuleTank-FACL : %0.2lfmm and EndPoint_FuleTank-FACL: %0.2lfmm \nAcceptance criteria: %0.2lfmm and %0.2lfmm.", PlatFVal.c_str(), subPlatFVal.c_str(), dist1, dist2, stod(reqValsFromCsv_F3A01[0]), stod(reqValsFromCsv_F3A01[1]));
		final_res.remark = string(remark);
	}
	int del = deleteDatumPlane(tempPln1);
	int del2 = deleteDatumPlane(tempPln2);
	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	return 0;
}

ProError _optionMenuImageChangeAction(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- optionMenuImageChangeAction -----------------------------");

	string* reqData = (string*)data;
	int n_sel;
	char** selValue;
	char sel_PB[PRO_NAME_SIZE];
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue[0]));

	char imgName[PRO_NAME_SIZE], cPbName[PRO_NAME_SIZE];
	ProTKSprintf(imgName, "%s/%s.png", reqData[1], selValue[0]);
	strcpy(cPbName, reqData[0].c_str());
	status = ProUIPushbuttonBitmapSet(dialog, cPbName, imgName);
	ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));
	strcpy(sel_PB, reqData[2].c_str());

	if (isProjectCodeFound == true) {
		ProUIPushbuttonEnable(DLG_F3A01_001, PB_RSELECT);
	}
	else {
		ProUIPushbuttonEnable(DLG_F3A01_001, platform);
	}

	return PRO_TK_NO_ERROR;
}

ProError platformListF3A01001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- platformList -----------------------------");
	string* _data = (string*)data;
	int n_sel;
	char** selValue;
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("Platform = " + string(selValue[0]));
	string storePlatVal = string(selValue[0]);

	vector<string> SelPlatform;

	if (storePlatVal == "Select")
	{
		ProUIPushbuttonDisable(DLG_F3A01_001, PB_ROK);
		ProUIPushbuttonDisable(DLG_F3A01_001, vehicalType);
	}

	getengineCapdatafromcsv(dbList2D_F3A01, storePlatVal, SelPlatform);
	ProUIPushbuttonDisable(DLG_F3A01_001, PB_ROK);

	for (auto str : SelPlatform) {
		ruleLog.Write("SelPlatform = " + str);
	}

	//Assign to global
	PlatFVal = storePlatVal;

	ProUIPushbuttonEnable(DLG_F3A01_001, vehicalType);

	option_menuF3A01001(SelPlatform, vehicalType);

	return PRO_TK_NO_ERROR;
}

ProError subplatformListF3A01001(char* dialog, char* component, ProAppData data)
{

	ruleLog.Write("----------------------------- subplatformList -----------------------------");

	vector<string> reqValsFromCsv;
	InterfaceRule irc;
	string* reqData = (string*)data;
	int n_sel;
	char** selValue;
	boolean isUserQuits = false;
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("Sub Platform = " + string(selValue[0]));
	string str = string(selValue[0]);

	//Assign to global
	subPlatFVal = selValue[0];

	_getReqValsFrom2DCsvData_F3A01("IRF3A01001.csv", 1, 3, str, reqValsFromCsv);
	for (auto values : reqValsFromCsv) {
		ruleLog.Write("Distances = " + values);
	}
	reqValsFromCsv_F3A01 = reqValsFromCsv;
	ruleLog.Write("Size = " + reqValsFromCsv.size());

	ProUIPushbuttonEnable(DLG_F3A01_001, PB_RSELECT);

	if (isUserQuits) {
		status = ProUIDialogDestroy(DLG_F3A01_001);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
	}
	return PRO_TK_NO_ERROR;
}

void _getReqValsFrom2DCsvData_F3A01(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv) 
{
	mainLog.Write("================= _getReqValsFrom2DCsvData ==================");
	Utils util;

	vector<vector<string>> csvData2D = util.getData2D(csvFilename);
	for (int i = 1; i < csvData2D.size(); i++) {
		if (csvData2D[i][partNoIdx].compare(partNo) == 0)
		{
			string tok1;
			std::istringstream ss1(csvData2D[i][reqValIdx]);
			while (std::getline(ss1, tok1, ';')) {
				reqValsFromCsv.push_back(tok1);
			}
			break;
		}
	}
	csvData2D.clear();
}

ProError select_action_IRF3A01001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- select_action_IRF3A01001 -----------------------------");
	fuel_tank_surf = nullptr;
	int n_sels;
	InterfaceRule _irule;
	int rule_sts;
	bool* quitAction = (bool*)data;
	free(fuel_tank_surf);
	int curWinId;
	ProWindowCurrentGet(&curWinId);
	ProWindowRepaint(curWinId);

	status = ProUIPushbuttonDisable(DLG_F3A01_001, PB_ROK);
	status = ProUIDialogHide(DLG_F3A01_001);

	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &fuel_tank_surf, &n_sels);
	ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_F3A01_001, PB_ROK);
		_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide inputs again!. Refer help document for details.");
		status = ProUIDialogShow(DLG_F3A01_001);
		return status;
	}

	if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(DLG_F3A01_001, PB_ROK);
		status = ProUIDialogShow(DLG_F3A01_001);
		return status;
	}

	for (int i = 0; i < n_sels; i++) {
		double D;
		status = ProGeomitemDiameterEval(fuel_tank_surf[i], &D);
		ruleLog.Write("ProGeomitemDiameterEval = " + to_string(status));
		ruleLog.Write(to_string(D));

		if (status == PRO_TK_NO_ERROR)
		{
			Case = 1;
		}
		if (status != PRO_TK_NO_ERROR) {
			Case = 2;
			ruleLog.Write("Case 2");
		}
	}

	ProUIPushbuttonEnable(dialog, PB_ROK);
	status = ProUIDialogShow(DLG_F3A01_001);

	return status;
}

ProError run_action_IRF3A01001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- run_action_IRF3A01012 -----------------------------");
	int rule_sts;
	InterfaceRule _irule;
	char FACLplnName[PRO_NAME_SIZE] = "ASM_YZ";
	bool* quitAction = (bool*)data;
	if (Case == 1)
	{
		rule_sts = IRcreateTangentDatumPlaneWithReference(fuel_tank_surf[0], curMdl, "ASM_YZ", tempPln1);
		rule_sts = IRcreateTangentDatumPlaneWithReference(fuel_tank_surf[1], curMdl, "ASM_YZ", tempPln2);
		ruleLog.Write("createTangentDatumPlaneWithReference: " + to_string(rule_sts));

		rule_sts = _irule.measureDistanceBetweenPlanes(cCurMdlName, FACLplnName, tempPln1, dist1);
		dist1 = round(dist1 * 100) / 100;	// rounding the value to two decimal places
		if (rule_sts != 0)
			if (quitAction != NULL) {
				_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", " Refer help document for details.");
				*quitAction = true;
				status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
				return status;
			}

		rule_sts = _irule.measureDistanceBetweenPlanes(cCurMdlName, FACLplnName, tempPln2, dist2);
		dist2 = round(dist2 * 100) / 100;	// rounding the value to two decimal places
		if (rule_sts != 0)
			if (quitAction != NULL) {
				_irule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", " Refer help document for details.");
				*quitAction = true;
				status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
				return status;
			}
	}

	if (Case == 2)
	{
		rule_sts = _irule.measureDistanceBetweenPlaneAndSurface(cCurMdlName, FACLplnName, fuel_tank_surf[0], dist1);
		dist1 = round(dist1 * 100) / 100;	// rounding the value to two decimal places
		if (rule_sts != 0)
		{
			status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
			return status;
		}
		rule_sts = _irule.measureDistanceBetweenPlaneAndSurface(cCurMdlName, FACLplnName, fuel_tank_surf[1], dist2);
		dist2 = round(dist2 * 100) / 100;	// rounding the value to two decimal places
		if (rule_sts != 0)
		{
			status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
			return status;
		}
	}
	ruleLog.Write("distances[0] = " + to_string(dist1) + "\tdistances[1] = " + to_string(dist2));
	if (dist2 < dist1)
		swap(dist1, dist2);
	ruleLog.Write("distances[0] = " + to_string(dist1) + "\tdistances[1] = " + to_string(dist2));
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}

void getengineCapdatafromcsv(vector<vector<string>> dbList2D_F3A01, string platformName, vector<string>& values) {

	ruleLog.Write("----------------------------- getengineCapdatafromcsv -----------------------------");

	for (int i = 1; i < dbList2D_F3A01.size(); ++i) {
		while (dbList2D_F3A01[i][0].compare(platformName) == 0) {
			string str = dbList2D_F3A01[i][1];
			if (find(values.begin(), values.end(), str) == values.end()) {
				values.push_back(str);
			}
			break;
		}
	}
	ruleLog.Write("platform.size:" + to_string(values.size()));
}

void option_menuF3A01001(vector<string> option_menulist, char* optionmenu) {

	ruleLog.Write("----------------------------- option_menuF3A01001 -----------------------------");

	char** loadCapListNames;
	wchar_t** loadCapListLabels;
	status = ProArrayAlloc(option_menulist.size(), sizeof(char*), 50, (ProArray*)&loadCapListNames);
	status = ProArrayAlloc(option_menulist.size(), sizeof(wchar_t*), 50, (ProArray*)&loadCapListLabels);

	for (int i = 0; i < option_menulist.size(); ++i)
	{
		loadCapListNames[i] = (char*)calloc(50, sizeof(char));
		ProTKSprintf(loadCapListNames[i], "%s", option_menulist[i]);

		loadCapListLabels[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
		ProStringToWstring(loadCapListLabels[i], loadCapListNames[i]);
	}
	status = ProUIOptionmenuNamesSet(DLG_F3A01_001, optionmenu, int(option_menulist.size()), loadCapListNames);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(DLG_F3A01_001, optionmenu, int(option_menulist.size()), loadCapListLabels);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

	status = ProArrayFree((ProArray*)&loadCapListNames);
	status = ProArrayFree((ProArray*)&loadCapListLabels);
}

int IRcreateTangentDatumPlaneWithReference(ProSelection& sel_surf, ProMdl& refPlaneOwner, char* refPlaneName, char* outputPlaneName)
{
	ProModelitem refPlaneitem;
	ProSelection reqMdlSel, refPlaneSel;
	wchar_t wRefPlaneName[PRO_NAME_SIZE], wOutputPlaneName[PRO_NAME_SIZE];
	ProElement	elem_tree, elem_ftype, elem_consts, elem_prl, elem_const_type1, elem_prl_ref, elem_tan, elem_const_type2, elem_tan_ref, elem_feature_name;
	ProReference REPDEP_ref1, REPDEP_ref2;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pln_feat;
	ProErrorlist errors;

	ProStringToWstring(wRefPlaneName, refPlaneName);
	status = ProModelitemByNameInit(refPlaneOwner, PRO_SURFACE, wRefPlaneName, &refPlaneitem);
	status = ProSelectionAlloc(NULL, &refPlaneitem, &refPlaneSel);

	/* =============================================================== *\
	Create Element Tree
	\* =============================================================== */
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	// FEATURE NAME
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wOutputPlaneName, outputPlaneName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);

	// CONSTRAINTS ALLOCATION
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINTS, &elem_consts);
	ProElemtreeElementAdd(elem_tree, NULL, elem_consts);
	ruleLog.Write("constraints status = " + to_string(status));

	// Constraint 1
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_tan);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_tan);
	ruleLog.Write("1st constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type1);
	ProElementIntegerSet(elem_const_type1, PRO_DTMPLN_TANG);
	status = ProElemtreeElementAdd(elem_tan, NULL, elem_const_type1);
	ruleLog.Write("1st constraint type status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_tan_ref);
	status = ProSelectionToReference(sel_surf, &REPDEP_ref1);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	status = ProElementReferenceSet(elem_tan_ref, REPDEP_ref1);
	ruleLog.Write("ProElementReferenceSet = " + to_string(status));
	status = ProElemtreeElementAdd(elem_tan, NULL, elem_tan_ref);
	ruleLog.Write("1st constraint reference status = " + to_string(status));

	// Constraint 2
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_prl);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_prl);
	ruleLog.Write("2nd constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type2);
	ProElementIntegerSet(elem_const_type2, PRO_DTMPLN_PRL);
	status = ProElemtreeElementAdd(elem_prl, NULL, elem_const_type2);
	ruleLog.Write("2nd constraint type status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_prl_ref);
	status = ProSelectionToReference(refPlaneSel, &REPDEP_ref2);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	ProElementReferenceSet(elem_prl_ref, REPDEP_ref2);
	status = ProElemtreeElementAdd(elem_prl, NULL, elem_prl_ref);
	ruleLog.Write("2nd constraint reference status = " + to_string(status));

	/* =============================================================== *\
	Create Model Selection Object
	\* =============================================================== */
	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Plane
	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pln_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	ruleLog.Write("ProArrayFree status = " + to_string(status));
	status = ProElementFree(&elem_tree);
	ruleLog.Write("ProElementFree status = " + to_string(status));
	status = ProSelectionFree(&reqMdlSel);
	ruleLog.Write("ProSelectionFree status = " + to_string(status));

	return 0;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F3A01-003	| Pallavi Garodi	| MF3A01			| 
===================================================================================================================*/
#define DLG_F3A01_003		"dlg_IR_F3A01_003"
#define PB_RCANCEL			"Commit_Cancel"
#define PB_ROK				"Commit_Ok"
#define PB_SELECT_TYRE      "pb_select_tyre"
#define Label_tyre			"Lable_sel_tyre"
#define PB_SELECT_FRAME     "pb_select_frame"
#define Label_frame			"Lable_sel_frame"
#define Label_plat			"Label_plat"
#define platform			"platform"
#define Label_subPlat		"Label_subPlat"
#define vehicalType			"vehicalType"
#define Label_SLR			"Label_SLR"
#define InputPanel_SLR		"InputPanel_SLR"

vector<vector<string>>dbList2D_FT;
string PlatFVal_FT, subPlatFVal_FT;
vector<string>reqValsFromCsv_FT;
double stdGrndCleVal_FT{};

int IRF3A01::IRF3A01_003(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF3A01 :: F3A01_003   ==========================");
	string tyreSurfInfo{};
	vector<selectionInfo>tyreSurfSels(2);
	//vector<selectionInfo>longMembSels(1);
	vector<double>slrValVec;

	tyreSurfInfo.erase();
	slrValVec.clear();

	string				reqCompSubMod[3] = { "F3A01" };
	string target;
	//Search in the main assembly if submodule, that is to be selected Programmatically, is available
	vector<ComponentData>_reqComps(sizeof(reqCompSubMod) / sizeof(reqCompSubMod[0]));
	ruleLog.Write("_reqComps size: " + to_string(_reqComps.size()));

	for (int i = 0; i < _reqComps.size(); ++i)
	{
		target = reqCompSubMod[i];
		ruleLog.Write("target comp: " + target);
		for (int j = 0; j < subModulesList.size(); ++j)
		{
			ruleLog.Write("submodule name being visited: " + subModulesList[j].name);
			if (subModulesList[j].name.find(target) != string::npos)
			{
				ruleLog.Write("match found for: " + subModulesList[j].name);
				strcpy(_reqComps[i].name, subModulesList[j].name.c_str());
			}
		}
	}

	for (int i = 0; i < _reqComps.size(); i++)
	{
		ruleLog.Write("_reqComps[" + to_string(i) + "].name: " + string(_reqComps[i].name));
	}

	//Visiting the model tree for getting feature id of F3B01 SM which will be used to select it
	status = ProSolidFeatVisit((ProSolid)curMdl, (ProFeatureVisitAction)getReqComponentsIdVec, compsFilter, &_reqComps);
	ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
	for (int i = 0; i < _reqComps.size(); i++)
	{
		ruleLog.Write("_reqComps[" + to_string(i) + "].name: " + string(_reqComps[i].name));
		ruleLog.Write("_reqComps[" + to_string(i) + "].id: " + to_string(_reqComps[i].id));
	}


	vector<string> platformValFrmCSV, subPlatform, platformVal;
	dbList2D_FT = getData2D("IRF3A01003.csv");
	ruleLog.Write("dbList2D.size():" + to_string(dbList2D_FT.size()));

	for (int i = 1; i < dbList2D_FT.size(); ++i)	// i = 1 for skipping the headers
	{
		string tok2;
		std::istringstream ss2(dbList2D_FT[i][0]);
		while (std::getline(ss2, tok2, ';'))
		{
			trimString(tok2);
			ruleLog.Write("Platform: " + tok2);
			//storing list of Platforms from db
			if (find(platformValFrmCSV.begin(), platformValFrmCSV.end(), tok2) == platformValFrmCSV.end()) {
				platformValFrmCSV.push_back(tok2);
			}
		}
	}

	//Delete the features created in previous run
	status = deleteDatumPoint("PROJ_PNT_R");
	ruleLog.Write("deleteDatumPoint PROJ_PNT_R: " + to_string(status));
	status = deleteDatumPoint("PROJ_PNT_F");
	ruleLog.Write("deleteDatumPoint PROJ_PNT_F: " + to_string(status));
	status = deleteDatumPoint("PROJ_PNT_M");
	ruleLog.Write("deleteDatumPoint PROJ_PNT_M: " + to_string(status));
	status = deleteDatumPoint("MY_PNT1");
	ruleLog.Write("deleteDatumPoint MY_PNT1: " + to_string(status));
	status = deleteDatumPoint("MY_PNT2");
	ruleLog.Write("deleteDatumPoint MY_PNT2: " + to_string(status));
	rule_sts = deleteDatumPlane("SIDE_PLANE2");
	ruleLog.Write("deleteDatumPlane SIDE_PLANE2: " + to_string(status));
	rule_sts = deleteDatumPlane("GROUND_PLANE");
	ruleLog.Write("deleteDatumPlane GROUND_PLANE: " + to_string(status));
	status = deleteDatumPoint("F_GND_PNT_OPP");
	ruleLog.Write("deleteDatumPoint F_GND_PNT_OPP: " + to_string(status));
	rule_sts = deleteDatumPlane("SIDE_PLANE1");
	ruleLog.Write("deleteDatumPlane SIDE_PLANE1: " + to_string(status));
	status = deleteDatumPoint("F_GND_PNT");
	ruleLog.Write("deleteDatumPoint F_GND_PNT: " + to_string(status));
	status = deleteDatumPoint("R_GND_PNT");
	ruleLog.Write("deleteDatumPoint R_GND_PNT: " + to_string(status));
	status = deleteDatumPoint("F_CENT_PNT");
	ruleLog.Write("deleteDatumPoint F_CENT_PNT: " + to_string(status));
	status = deleteDatumPoint("R_CENT_PNT");
	ruleLog.Write("deleteDatumPoint R_CENT_PNT: " + to_string(status));
	status = deleteDatumPoint("F_CENT_PNT_OPP");
	ruleLog.Write("deleteDatumPoint R_CENT_PNT: " + to_string(status));
	rule_sts = deleteDatumPlane("CENTRE_PLANE");
	ruleLog.Write("deleteDatumPlane CENTRE_PLANE: " + to_string(status));

	//Create UI dialog
	status = ProUIDialogCreate(DLG_F3A01_003, DLG_F3A01_003);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_F3A01_003, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F3A01_003, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(DLG_F3A01_003, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUIPushbuttonActivateActionSet(DLG_F3A01_003, PB_SELECT_TYRE, (ProUIAction)refSurfSelections, &tyreSurfSels);
	//status = ProUIPushbuttonActivateActionSet(DLG_F3B06_003, PB_SELECT_FRAME, (ProUIAction)refSurfSelections, &longMembSels);
	status = ProUIOptionmenuInputActionSet(DLG_F3A01_003, InputPanel_SLR, (ProUIAction)inputValue, &slrValVec);
	status = ProUIOptionmenuSelectActionSet(DLG_F3A01_003, platform, (ProUIAction)platformList_FT, NULL);

	status = ProUIOptionmenuSelectActionSet(DLG_F3A01_003, vehicalType, (ProUIAction)subplatformList_FT, NULL);

	platformValFrmCSV.insert(platformValFrmCSV.begin(), "Select");
	//Set platform values in platform drop down
	option_menu_FT(platformValFrmCSV, platform);

	status = ProUIPushbuttonDisable(DLG_F3A01_003, PB_ROK);
	ruleLog.Write("ProUIPushbuttonDisable status: " + to_string(status));

	status = ProUIOptionmenuDisable(DLG_F3A01_003, platform);
	status = ProUIOptionmenuDisable(DLG_F3A01_003, vehicalType);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	ruleLog.Write("ProUIDialogHide: " + to_string(status));

	status = ProUIDialogActivate(DLG_F3A01_003, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));

	if (isUserQuits)
	{
		status = ProUIDialogDestroy(DLG_F3A01_003);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		return -1;
	}
	if (slrValVec.size() == 0)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention", "SLR value are not entered,\nClick OK to return.");
		status = ProUIDialogDestroy(DLG_F3A01_003);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
		tyreSurfSels.clear();
		//longMembSels.clear();
		slrValVec.clear();

		return -1;
	}

	//Plane Creation 
	edgeSel edgeSelection1{}, edgeSelection2{};
	ProSelection fCentPntSel{}, rCentPntSel{}, csysSel{};
	/*---------------------Create F_CENT_PNT and R_CENT_PNT----------------------
	F_CENT_PNT = Front centre point at the centre of front tyre
	R_CENT_PNT = Rear centre point at the centre of rear tyre
	The points will be created at the centre of biggest edge of tyre surfaces*/

	rule_sts = findTheBiggestArcEdge(tyreSurfSels[0], &edgeSelection1);
	ruleLog.Write("findTheBiggestArcEdge 1: " + to_string(rule_sts));
	status = ProSelectionHighlight(edgeSelection1.sel, PRO_COLOR_HIGHLITE);
	ruleLog.Write("ProSelectionHighlight 1 status: " + to_string(status));
	rule_sts = createDatumPointAtCenterOfEdge(edgeSelection1.sel, "F_CENT_PNT");
	ruleLog.Write("createDatumPointAtCenterOfEdge 1: " + to_string(rule_sts));

	rule_sts = findTheBiggestArcEdge(tyreSurfSels[1], &edgeSelection2);
	ruleLog.Write("findTheBiggestArcEdge 2: " + to_string(rule_sts));
	status = ProSelectionHighlight(edgeSelection2.sel, PRO_COLOR_HIGHLITE);
	ruleLog.Write("ProSelectionHighlight 2 status: " + to_string(status));
	rule_sts = createDatumPointAtCenterOfEdge(edgeSelection2.sel, "R_CENT_PNT");
	ruleLog.Write("createDatumPointAtCenterOfEdge 2: " + to_string(rule_sts));

	/*-----------Get the selection objects of F_CENT_PNT and R_CENT_PNT and CSYS
	It will be used as references to create ground points----------------------*/
	rule_sts = selectionAllocByName("F_CENT_PNT", PRO_POINT, &fCentPntSel);
	ruleLog.Write("selectionAllocByName F_CENT_PNT: " + to_string(rule_sts));
	rule_sts = selectionAllocByName("R_CENT_PNT", PRO_POINT, &rCentPntSel);
	ruleLog.Write("selectionAllocByName R_CENT_PNT: " + to_string(rule_sts));
	rule_sts = selectionAllocByName("CSYS_ASM_DEF", PRO_CSYS, &csysSel);
	ruleLog.Write("selectionAllocByName R_CENT_PNT: " + to_string(rule_sts));

	/*=============== Create a projection plane on opposite side of the vehicle to create a cetre point on that
	side as well
	centre plane will be created as a plane passing through 3 points ===============*/

	//get the selection alloc of a plane passing through vehicle centre (ASM_XZ plane)
	ProSelection asmXZSel;
	rule_sts = selectionAllocByName("ASM_XZ", PRO_SURFACE, &asmXZSel);
	ruleLog.Write("selectionAllocByName ASM_XZ: " + to_string(rule_sts));
	double oppSidePlaneOffsVal = -1200;  //Using general value for commonising the offs distance for all the CAD models 
	rule_sts = createOffsetPlaneWithReference(asmXZSel, oppSidePlaneOffsVal, "SIDE_PLANE1");
	ruleLog.Write("createOffsetPlaneWithReferenceG status: " + to_string(rule_sts));

	//get the selection object of side plane
	ProSelection sidePlane1Sel{};
	rule_sts = selectionAllocByName("SIDE_PLANE1", PRO_SURFACE, &sidePlane1Sel);
	ruleLog.Write("selectionAllocByName PROJ_PLANE: " + to_string(rule_sts));

	rule_sts = projectDatumPointOnPlane(fCentPntSel, sidePlane1Sel, "F_CENT_PNT_OPP");
	ruleLog.Write("projectDatumPointOnPlane1: " + to_string(rule_sts));

	//get the selection object of F_GND_PNT_OPP
	ProSelection fCentPntOpp{};
	rule_sts = selectionAllocByName("F_CENT_PNT_OPP", PRO_POINT, &fCentPntOpp);
	ruleLog.Write("selectionAllocByName PROJ_PLANE: " + to_string(rule_sts));

	//Create a ground plane Normal to Long member surface and passing thr G_PNT_F and G_PNT_R 
	rule_sts = threePointPlaneCreate(fCentPntSel, fCentPntOpp, rCentPntSel, "CENTRE_PLANE");
	ruleLog.Write("threePointPlaneCreate status: " + to_string(rule_sts));

	ProSelection centrePlaneSel{};
	rule_sts = selectionAllocByName("CENTRE_PLANE", PRO_SURFACE, &centrePlaneSel);
	ruleLog.Write("selectionAllocByName CENTRE_PLANE: " + to_string(rule_sts));

	//Create a Ground plane paralle to centre plane at an offset distance of SLR 
	ruleLog.Write("slrValVec[slrValVec.size() - 1]: " + to_string(slrValVec[slrValVec.size() - 1]));
	rule_sts = createOffsetPlaneWithReference(centrePlaneSel, -(slrValVec[slrValVec.size() - 1]), "GROUND_PLANE");
	ruleLog.Write("createOffsetPlaneWithReferenceG status: " + to_string(rule_sts));

	ProSelection groundPlaneSel{};
	rule_sts = selectionAllocByName("GROUND_PLANE", PRO_SURFACE, &groundPlaneSel);
	ruleLog.Write("selectionAllocByName GROUND_PLANE: " + to_string(rule_sts));

	//Measure distance between component and ground plane (groundClearance)
	double groundClearance;
	Pro3dPnt pntArr[2];
	rule_sts = measureDistanceBetweenPlaneAndComp(groundPlaneSel, _reqComps[0], groundClearance, pntArr);
	ruleLog.Write("measureDistanceBetweenPlaneAndCompG status: " + to_string(rule_sts));

	/*===================== create points for highlighting the distance =====================
	  NOTE :- coords (pntArr) returned by API ProSelectionWithOptionsDistanceEval===========*/
	rule_sts = createCsysOffsDatumPoint(csysSel, pntArr, "GROUND_CLEARANCE_PNT");
	ruleLog.Write("createCsysOffsDatumPoint status: " + to_string(rule_sts));


	//Rule Validation and Results 
	if (groundClearance >= stdGrndCleVal_FT)
	{
		final_res.result = "PASS";
	}
	else
		final_res.result = "FAIL";

	/*========================== remarks ==============================*/
		//remark message for tyre surface details
	tyreSurfInfo += "\n\nReferences selected from tyre - \n";
	for (int i = 0; i < tyreSurfSels.size(); i++)
	{
		tyreSurfInfo += to_string(i + 1) + ")surf ID- " + to_string(tyreSurfSels[i].id) + "(Owner: " + tyreSurfSels[i].name + ".PRT\tDesc: " + tyreSurfSels[i].descrp + ")\n";
	}

	string userSelsRec, slrValStr;
	slrValStr = to_string(abs(slrValVec[slrValVec.size() - 1]));
	slrValStr.erase(slrValStr.find_last_not_of('0') + 3);          //Removing trailing zeroes to keep only 2 zeroes post decimal point

	userSelsRec += "\n\nPlatform and Sub-platform Selected: " + PlatFVal_FT + "\t(" + subPlatFVal_FT + ")\n";
	userSelsRec += "SLR value provided: " + slrValStr + " mm.";
	sprintf(remark, "Ground Clearance of Exhaust pipe Routing: %0.2lf mm\nAcceptance Criteria: min %0.2lf mm", groundClearance, stdGrndCleVal_FT);
	final_res.remark = remark + userSelsRec + tyreSurfInfo;
	//destroy the UI dialog for smooth transition 
	status = ProUIDialogDestroy(DLG_F3A01_003);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	tyreSurfSels.clear();
	//longMembSels.clear();

	return 0;
}

ProError platformList_FT(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- platformList -----------------------------");
	status = ProUIPushbuttonDisable(dialog, PB_ROK);
	status = ProUIOptionmenuDisable(dialog, vehicalType);
	string* _data = (string*)data;
	int n_sel;
	char** selValue;

	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("Platform = " + string(selValue[0]));
	string storePlatVal = string(selValue[0]);

	vector<string> SelPlatform;

	if (storePlatVal == "Select")
	{
		ProUIPushbuttonDisable(dialog, PB_ROK);
		ProUIPushbuttonDisable(dialog, vehicalType);
	}

	getPlatval_FT(dbList2D_FT, storePlatVal, SelPlatform);
	//ProUIPushbuttonDisable(DLG_F3A01_003, PB_ROK);

	for (auto str : SelPlatform) {
		ruleLog.Write("SelPlatform = " + str);
	}

	//Assign to global
	PlatFVal_FT = storePlatVal;


	option_menu_FT(SelPlatform, vehicalType);
	status = ProUIPushbuttonEnable(dialog, vehicalType);

	return PRO_TK_NO_ERROR;
}

ProError subplatformList_FT(char* dialog, char* component, ProAppData data) {

	ruleLog.Write("----------------------------- subplatformList -----------------------------");
	status = ProUIPushbuttonDisable(dialog, PB_ROK);
	//vector<string> reqValsFromCsv;
	InterfaceRule irc;
	string* reqData = (string*)data;
	int n_sel;
	char** selValue;
	boolean isUserQuits = false;
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("Sub Platform = " + string(selValue[0]));
	string str = string(selValue[0]);

	//Assign to global
	subPlatFVal_FT = selValue[0];

	getGroundClearanceValsFromCsv_FT("IRF3A01003.csv", 1, 2, str, reqValsFromCsv_FT);
	for (auto values : reqValsFromCsv_FT) {
		ruleLog.Write("Distances = " + values);
		stdGrndCleVal_FT = stod(values);
	}
	//reqValsFromCsv = reqValsFromCsv;
	ruleLog.Write(" Size = " + to_string(reqValsFromCsv_FT.size()));

	status = ProUIPushbuttonEnable(dialog, PB_ROK);
	return PRO_TK_NO_ERROR;
}

void getPlatval_FT(vector<vector<string>> dbList2D_FT_F3A01, string platformName, vector<string>& values) {

	ruleLog.Write("----------------------------- getengineCapdatafromcsv -----------------------------");

	for (int i = 1; i < dbList2D_FT_F3A01.size(); ++i) {
		while (dbList2D_FT_F3A01[i][0].compare(platformName) == 0) {
			string str = dbList2D_FT_F3A01[i][1];
			if (find(values.begin(), values.end(), str) == values.end()) {
				values.push_back(str);
			}
			break;
		}
	}
	ruleLog.Write("platform.size:" + to_string(values.size()));
}

void option_menu_FT(vector<string> option_menulist, char* optionmenu) {

	ruleLog.Write("----------------------------- option_menu -----------------------------");

	char** loadCapListNames;
	wchar_t** loadCapListLabels;
	status = ProArrayAlloc(option_menulist.size(), sizeof(char*), 50, (ProArray*)&loadCapListNames);
	status = ProArrayAlloc(option_menulist.size(), sizeof(wchar_t*), 50, (ProArray*)&loadCapListLabels);

	for (int i = 0; i < option_menulist.size(); ++i)
	{
		loadCapListNames[i] = (char*)calloc(50, sizeof(char));
		ProTKSprintf(loadCapListNames[i], "%s", option_menulist[i]);

		loadCapListLabels[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
		ProStringToWstring(loadCapListLabels[i], loadCapListNames[i]);
	}
	status = ProUIOptionmenuNamesSet(DLG_F3A01_003, optionmenu, int(option_menulist.size()), loadCapListNames);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(DLG_F3A01_003, optionmenu, int(option_menulist.size()), loadCapListLabels);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

	status = ProArrayFree((ProArray*)&loadCapListNames);
	status = ProArrayFree((ProArray*)&loadCapListLabels);
}

void getGroundClearanceValsFromCsv_FT(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv) {
	mainLog.Write("================= getGroundClearanceValsFromCsv ==================");

	InterfaceRule iRule;
	vector<vector<string>> csvData2D = iRule.getData2D(csvFilename);
	for (int i = 1; i < csvData2D.size(); i++) {
		if (csvData2D[i][partNoIdx].compare(partNo) == 0) {
			string tok1;
			std::istringstream ss1(csvData2D[i][reqValIdx]);
			while (std::getline(ss1, tok1, ';')) {
				reqValsFromCsv.push_back(tok1);
			}
			break;
		}

	}
	csvData2D.clear();
}



/*==================================================================================================================
RULE ID		| DEVELOPER		| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F3A01-004| Vinay Neel	| MF3A01;			| Standardize Fuel tank capacity as per Engine size, Gross Vehicle Weight & Vehicle duty cycle requirement.(Applicable for Fuel tanks, CNG tanks & LNG tanks)
===================================================================================================================*/


#define DLG_IRF3A01_004					"dlg_IR_F3A01_004"
#define PB_ROK							"CommitOK"
#define PB_RCANCEL						"CommitCancel"
#define PB_SELECT_PLATFORM_F3A01		"select_platform_option_menu"
#define PB_SELECT_FUELCAPACITY_F3A01	"select_fuel-capacity_option_menu"

string rem_message;
string subPlatFVal_F3A01 = "", PlatFVal_F3A01 = "";
vector<string> reqValsFromCsv_F3A01004;
vector<vector<string>> dbList2D_F3A01004;
string final_Acceptance_criteriaF3A01 = "";

int IRF3A01::IRF3A01_004(ruleResult &final_res)
{
	ruleLog.Write("==========================   IRF3A01::IRF3A01_004   ==========================");
	/* your code goes here */
	rem_message = "";
	subPlatFVal_F3A01 = "", PlatFVal_F3A01 = "";
	reqValsFromCsv_F3A01004.clear();
	dbList2D_F3A01004.clear();
	final_Acceptance_criteriaF3A01 = "";

	bool isProjectCodeFound = false;
	vector<string> platformValFrmCSV, projectCodes;

	ComponentData _reqComps[1]{};
	string reqCompSubMod[] = { "F3A01" };//MF3A01; MF3A09; MF3A02; MF3A10

	for (int i = 0; i < subModulesList.size(); ++i)
	      for (int j = 0; j < 1; ++j)
	        if (subModulesList[i].name.find(reqCompSubMod[j]) != string::npos)
	             strcpy(_reqComps[j].name, subModulesList[j].name.c_str());
	
    project_code = stoi(string(_reqComps[0].name).substr(0,4));
	ruleLog.Write("Project Code:" + to_string(project_code));
	string projectC_str = to_string(project_code);

	dbList2D_F3A01004 = getData2D("IRF3A01004.csv");
	ruleLog.Write("dbList2D_F3B03.size(): " + to_string(dbList2D_F3A01004.size()));

	for (int i = 1; i < dbList2D_F3A01004.size(); ++i)	// i = 1 for skipping the headers
	{
		string tok1, tok2;
		std::istringstream ss1(dbList2D_F3A01004[i][2]);
		while (std::getline(ss1, tok1, ';'))
		{
			ruleLog.Write("project code from CSV:" + tok1);
			//storing list of project codes from db
			projectCodes.push_back(tok1);
		}


		std::istringstream ss2(dbList2D_F3A01004[i][0]);
		while (std::getline(ss2, tok2, ';'))
		{
			trimString(tok2);
			ruleLog.Write("Platform: " + tok2);
			//storing list of Platforms from db
			if (find(platformValFrmCSV.begin(), platformValFrmCSV.end(), tok2) == platformValFrmCSV.end()) {
				platformValFrmCSV.push_back(tok2);
			}
		}
	}
	ruleLog.Write("projectCodes.size(): " + to_string(projectCodes.size()));
	
	for (auto str : platformValFrmCSV) {
		ruleLog.Write("platformValFrmCSV: " + str);
	}
	ruleLog.Write("platformValFrmCSV.size(): " + to_string(platformValFrmCSV.size()));

	
	status = ProSolidFeatVisit((ProSolid)curMdl, visit_action_F3A01004, compsFilter, (ProAppData)&asm_name);
	ruleLog.Write("ProSolidFeatVisit status:"+to_string(status));

	isUserQuits = false;

	//check whether the project code is available or not in db
	for (int i = 0; i < projectCodes.size(); i++) {
		if ((projectC_str.compare(projectCodes.at(i))) == 0) {
			isProjectCodeFound = true;
			break;
		}
	}



	status = ProUIDialogCreate(DLG_IRF3A01_004, DLG_IRF3A01_004);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF3A01_004, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF3A01_004, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF3A01_004, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	//ProUIPushbuttonDisable(DLG_IRF3A01_004, PB_ROK);

	status = ProUIOptionmenuSelectActionSet(DLG_IRF3A01_004, PB_SELECT_PLATFORM_F3A01, (ProUIAction)platformList_F3A01004, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet status:" + to_string(status));
	status = ProUIOptionmenuSelectActionSet(DLG_IRF3A01_004, PB_SELECT_FUELCAPACITY_F3A01, (ProUIAction)subplatformList_F3A01004, NULL);

	if (isProjectCodeFound == true) {
		ProUIPushbuttonEnable(DLG_IRF3A01_004, PB_ROK);
		ProUIPushbuttonDisable(DLG_IRF3A01_004, PB_SELECT_PLATFORM_F3A01);
		ProUIPushbuttonDisable(DLG_IRF3A01_004, PB_SELECT_FUELCAPACITY_F3A01);
		getReqValsFrom2DCsvData("IRF3A01004.csv", 2, 3, project_code, reqValsFromCsv_F3A01004);

		for (auto Vals : reqValsFromCsv_F3A01004) {
			ruleLog.Write("Part Number = " + Vals);
		}
	}
	else
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "The Project code is not found", "Please select Platform and Fuel Capacity.");
		platformValFrmCSV.insert(platformValFrmCSV.begin(), "Select");
		ProUIPushbuttonEnable(DLG_IRF3A01_004, PB_SELECT_PLATFORM_F3A01);
		ProUIPushbuttonDisable(DLG_IRF3A01_004, PB_ROK);
		//Set platform values in PB_SELECT_PLATFORM drop down
		option_menuF3A01004(DLG_IRF3A01_004,platformValFrmCSV, PB_SELECT_PLATFORM_F3A01);
	}
	


	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF3A01_004, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF3A01_004);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	vector<string> part_nos, fuelCap, reqCapcityValsFromCsv , finalpartNo , platformVal;
	bool ispartfound = false;

	ruleLog.Write("asm_name.size(): " + to_string(asm_name.size()));
// check if the part is present in the model or not.
	if (reqValsFromCsv_F3A01004.size() != 0) {
		if(subPlatFVal_F3A01 == "365L+200L"){		
			for (const auto& value1 : reqValsFromCsv_F3A01004) {
				bool found = false;
				for (int i = 0; i < asm_name.size(); i++) {
					if (value1 == asm_name[i].AsmName) {
						found = true;
						ispartfound = true;
						break;
					}
				}
				if (!found) {
					ruleLog.Write("part not found: " + value1);
					string str1 = value1;
					string partNo1 = str1.append(".ASM");
					finalpartNo.push_back(partNo1);
					ispartfound = false;
				}
			}
			
			
		}
		else {
			for (int j = 0; j < reqValsFromCsv_F3A01004.size(); j++) {
				string str1 = reqValsFromCsv_F3A01004.at(j);
				string partNo1 = str1.append(".ASM");
				finalpartNo.push_back(partNo1);
				const regex p((reqValsFromCsv_F3A01004.at(j)));
				for (int i = 0; i < asm_name.size(); ++i) {
					/*if ((reqValsFromCsv_F3A01004.at(j)).compare(asm_name[i].AsmName) == 0) {*/
					if (std::regex_search(asm_name[i].AsmName, p)) {
						string str = reqValsFromCsv_F3A01004.at(j);
						string partNo = str.append(".ASM");
						part_nos.push_back(partNo);
						//part_nos.push_back(reqValsFromCsv.at(j));
						ruleLog.Write("Part No :" + reqValsFromCsv_F3A01004.at(j));
						//get the fuel tank capacity
						if (subPlatFVal_F3A01 == "") {
							getReqValsFrom2DCsvData("IRF3A01004.csv", 2, 4, project_code, reqCapcityValsFromCsv);
							fuelCap.push_back(reqCapcityValsFromCsv.at(j));
						}
						else
						{
							fuelCap.push_back(subPlatFVal_F3A01);
						}
					}
				}
			}
		}
	}
	
	if (ispartfound) {
		for (int j = 0; j < reqValsFromCsv_F3A01004.size(); j++) {
			string str = reqValsFromCsv_F3A01004.at(j);
			string partNo = str.append(".ASM");
			part_nos.push_back(partNo);
		}
		fuelCap.push_back("365L & 200L");
	}

	


	//if more than one fuel tank used
	string part_no = "";
	if (part_nos.size() > 0) {
		//Append fuel tank part numbers
		bool first = true;
		for (const std::string& option : part_nos)
		{		
			
			if (!first)
			{
				
				part_no.append(" & ");
				
			}
			part_no.append(option);
			first = false;
		}

		//Append fuel tank capacity
		bool second = true;
		for (const std::string& option : fuelCap)
		{
			//ruleLog.Write(option);		
			if (!second)
			{
				acceptance_criteria.append(" & ");
			}
			acceptance_criteria.append(option);
			second = false;
		}

		isRightValue = true;
	}

	//Append all the part numbers on final_Acceptance_criteria string, if parts not found
	
	bool first = true;
	if (isRightValue == false) 
	{
		for (const std::string& option : finalpartNo)
		{
			if (!first)
			{
				final_Acceptance_criteriaF3A01.append(" , ");
			}
			final_Acceptance_criteriaF3A01.append(option);
			first = false;
		}
	}

	
	//if (PlatFVal_F3A01 == "" && subPlatFVal_F3A01 == "") {
	//	PlatFVal_F3A01 = "Not Selected";
	//	subPlatFVal_F3A01 = "Not Selected";
	//}
	

	//DECLARE RESULT
	if (isRightValue)
	{
		final_res.result = "PASS";

		if (PlatFVal_F3A01 != "" && subPlatFVal_F3A01 != "") {
			rem_message += "Selected Platform        :- " + PlatFVal_F3A01;
			rem_message += "\nSelected Fuel Capacity :- " + subPlatFVal_F3A01;
		}

		rem_message += "\n\nResult: \nUsed Fuel tank capacity = " + acceptance_criteria + " and it's Part Number = " + part_no;
		
		rem_message += " \n Acceptance criteria :\nFuel tank capacity should be = " + acceptance_criteria + " and it's Part Number = " + part_no;
		final_res.remark = rem_message;
		
	}
	else
	{
		final_res.result = "FAIL";

		if (PlatFVal_F3A01 != "" && subPlatFVal_F3A01 != "") {
			rem_message += "Selected Platform        :- " + PlatFVal_F3A01;
			rem_message += "\nSelected Fuel Capacity :- " + subPlatFVal_F3A01;
		}

		rem_message += "\n\nResult: Part Number : "+ final_Acceptance_criteriaF3A01 +" Not found \nAcceptance criteria : Part Number should be = "+ final_Acceptance_criteriaF3A01;

		final_res.remark = rem_message;
	}

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	//reqValsFromCsv_F3A01.clear();
	
	platformValFrmCSV.clear();
	projectCodes.clear();
	dbList2D_F3A01004.clear();
	reqValsFromCsv_F3A01004.clear();
	reqCapcityValsFromCsv.clear();
	acceptance_criteria.clear();
	final_Acceptance_criteriaF3A01.clear();
	part_no.clear();
	part_nos.clear();
	fuelCap.clear();
	subPlatFVal_F3A01.clear();
	PlatFVal_F3A01.clear();
	rem_message.clear();
	return 0;
}

ProError visit_action_F3A01004(ProFeature* p_feature, ProError status, ProAppData app_data) {
	ruleLog.Write("==========================   IRF3A01::visit_action  ==========================");
	vector<AsmName>* asmname_list = (vector<AsmName>*)app_data;

	ProMdlType subModuleMdlType;
	ProModelitem modelItem;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ProMdl reqMdl;
	AsmName asm_nm{};

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
	status = ProMdlMdlnameGet(reqMdl, wFeatName);
	ProWstringToString(cFeatName, wFeatName);

	if (subModuleMdlType == PRO_MDL_ASSEMBLY)
	{
		ruleLog.Write("Assembly Name: ");
		ruleLog.Write(cFeatName);

		strcpy(asm_nm.AsmName, cFeatName);
		asmname_list->push_back(asm_nm);
		ProSolidFeatVisit((ProSolid)reqMdl, visit_action_F3A01004, compsFilter, (ProAppData)app_data);
	}

	return status;
}

ProError platformList_F3A01004(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- platformList -----------------------------");
	string* _data = (string*)data;
	int n_sel;
	char** selValue;
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("Platform = " + string(selValue[0]));
	string storePlatVal = string(selValue[0]);

	vector<string> SelPlatform;

	if (storePlatVal == "Select")
	{
		ProUIPushbuttonDisable(DLG_IRF3A01_004, PB_ROK);
		ProUIPushbuttonDisable(DLG_IRF3A01_004, PB_SELECT_FUELCAPACITY_F3A01);
	}

	getengineCapdatafromcsvF3A01004(dbList2D_F3A01004,storePlatVal, SelPlatform);
	ProUIPushbuttonDisable(DLG_IRF3A01_004, PB_ROK);

	for (auto str : SelPlatform) {
		ruleLog.Write("SelPlatform = " + str);
	}

	//Assign to global
	PlatFVal_F3A01 = storePlatVal;

	ProUIPushbuttonEnable(DLG_IRF3A01_004, PB_SELECT_FUELCAPACITY_F3A01);

	option_menuF3A01004(DLG_IRF3A01_004,SelPlatform, PB_SELECT_FUELCAPACITY_F3A01);

	return PRO_TK_NO_ERROR;
}

ProError subplatformList_F3A01004(char* dialog, char* component, ProAppData data) {

	ruleLog.Write("----------------------------- subplatformList -----------------------------");

	vector<string> reqValsFromCsv;
	InterfaceRule irc;
	string* reqData = (string*)data;
	int n_sel;
	char** selValue;
	boolean isUserQuits = false;
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("Fuel Capacity = " + string(selValue[0]));
	string str = string(selValue[0]);
	
	_getReqValsFrom2DCsvData("IRF3A01004.csv", 7, 8, str, reqValsFromCsv);

	//ruleLog.Write("Part No = " + reqValsFromCsv.);
	ruleLog.Write("Part No = " + to_string(reqValsFromCsv.size()));
	for (auto vals : reqValsFromCsv) {
		ruleLog.Write("Part No[i] = " + vals);
	}

	reqValsFromCsv_F3A01004 = reqValsFromCsv;
	
	ProUIPushbuttonEnable(DLG_IRF3A01_004, PB_ROK);
	//Assign to global
	subPlatFVal_F3A01 = selValue[0];
	
	if (isUserQuits) {
		status = ProUIDialogDestroy(DLG_IRF3A01_004);
		ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
		status = ProUIDialogShow(DLG_IRC_MAIN);
	}


	return PRO_TK_NO_ERROR;
}

void getengineCapdatafromcsvF3A01004(vector<vector<string>> dbList2D_F3A01, string platformName, vector<string>& values) {

	ruleLog.Write("----------------------------- getengineCapdatafromcsv -----------------------------");

	for (int i = 1; i < dbList2D_F3A01.size(); ++i) {
		while (dbList2D_F3A01[i][6].compare(platformName) == 0) {
			string str = dbList2D_F3A01[i][7];
			if (find(values.begin(), values.end(), str) == values.end()) {
				values.push_back(str);
			}
			break;
		}
	}
	ruleLog.Write("platform.size:" + to_string(values.size()));
}

void option_menuF3A01004(char* dialog, vector<string> option_menulist, char* optionmenu) {

	ruleLog.Write("----------------------------- option_menu -----------------------------");

	char** loadCapListNames;
	wchar_t** loadCapListLabels;
	status = ProArrayAlloc(option_menulist.size(), sizeof(char*), 100, (ProArray*)&loadCapListNames);
	status = ProArrayAlloc(option_menulist.size(), sizeof(wchar_t*), 100, (ProArray*)&loadCapListLabels);

	for (int i = 0; i < option_menulist.size(); ++i)
	{
		loadCapListNames[i] = (char*)calloc(50, sizeof(char));
		ProTKSprintf(loadCapListNames[i], "%s", option_menulist[i]);

		loadCapListLabels[i] = (wchar_t*)calloc(50, sizeof(wchar_t));
		ProStringToWstring(loadCapListLabels[i], loadCapListNames[i]);
	}
	status = ProUIOptionmenuNamesSet(dialog, optionmenu, int(option_menulist.size()), loadCapListNames);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(dialog, optionmenu, int(option_menulist.size()), loadCapListLabels);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

	status = ProArrayFree((ProArray*)&loadCapListNames);
	status = ProArrayFree((ProArray*)&loadCapListLabels);
}

void _getReqValsFrom2DCsvData(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv) 
{
	mainLog.Write("================= Utils::_getReqValsFrom2DCsvData ==================");
	
	Utils util;
	vector<vector<string>> csvData2D = util.getData2D(csvFilename);
	for (int i = 1; i < csvData2D.size(); i++) {
		if (csvData2D[i][partNoIdx].compare(partNo) == 0) {
			string tok1;
			std::istringstream ss1(csvData2D[i][reqValIdx]);
			while (std::getline(ss1, tok1, ';')) {
				reqValsFromCsv.push_back(tok1);
			}
			break;
		}

	}
	csvData2D.clear();
}

/*==================================================================================================================
RULE ID			| DEVELOPER			    | DEPENDENT MODULES	  | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F3A01-007	| MATHANPRASATH A		| MF3A01; MF3A09	  | Standardized gap between Fuel tank and other dynamic and hot aggregates.
===================================================================================================================*/

#define dlg_IR_F3A01_007     "dlg_IR_F3A01_007" 
#define PB_CANCEL		     "CommitCancel" 
#define PB_OK			     "CommitOK"

struct f3A01_007_modelInfo
{
	string sub_mod_name;
	string name;
	string extension;
	int ID;
	string description;
	vector<int> ID_path;
	int ID_table_size;
	double distances;

};
vector<int>ID_mapf3A01_007;
vector<f3A01_007_modelInfo> treeInformationVectorf3a01_007;
vector<f3A01_007_modelInfo> treeInformationVectorf3a01_subm;
vector<f3A01_007_modelInfo> Selection_item1f3a01_007;
vector<f3A01_007_modelInfo> Selection_item2f3a01_007;
ProSelection sels[2];

int IRF3A01::IRF3A01_007(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF3A01::IRF3A01_007   ==========================");

	isUserQuits = false;
	status = ProUIDialogCreate(dlg_IR_F3A01_007, dlg_IR_F3A01_007);
	ruleLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(dlg_IR_F3A01_007, PRO_B_FALSE);
	ruleLog.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(dlg_IR_F3A01_007, PB_CANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));
	status = ProUIPushbuttonActivateActionSet(dlg_IR_F3A01_007, PB_OK, (ProUIAction)ruleDlgOKaction, NULL);
	ruleLog.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(dlg_IR_F3A01_007, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(dlg_IR_F3A01_007);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));


	deleteDatumPoint("datum_PNT1");
	deleteDatumPoint("datum_PNT2");

	UserAppdata appdata;
	FILE* fp{};
	appdata.fp = fp;
	appdata.level = 1;
	vector<string>non_prsnt_components;
	vector<string>prsnt_components;
	ComponentData _reqComps[12]{};
	ComponentData present_comps[13]{};
	vector<ComponentData>f3a01_comp;
	vector<string>elements;
	vector<string>list_comp;
	vector<string>missing_elements;
	non_prsnt_components.clear();
	prsnt_components.clear();
	f3a01_comp.clear();
	elements.clear();
	list_comp.clear();
	missing_elements.clear();
	string comp_names[13];

	//List of submodules to verify the clearance.
	string reqCompSubMod[13] = { "F3A01","F3B01","F3B02","F3B03","F3B06","G1C01","H2D02","F2C01","F4B02","F4A02","F5A24","F5B03","F5A25" };
	double clearance_value;
	string tar;

	//Segregate the modules present in the cad from the above list.
	for (int i = 0; i < 13; ++i)
	{
		for (int j = 0; j < subModulesList.size(); ++j)
		{
			tar = reqCompSubMod[i];
			if (subModulesList[j].name.find(tar) != string::npos)
			{
				strcpy(present_comps[i].name, subModulesList[j].name.c_str());
				comp_names[i] = subModulesList[j].name;
				prsnt_components.push_back(subModulesList[j].name);
				ruleLog.Write("present_component = " + subModulesList[j].name);
				break;
			}

		}
	}

	for (int j = 0; j < 13; ++j)
	{
		ruleLog.Write(reqCompSubMod[j]);
		list_comp.push_back(reqCompSubMod[j]);
	}

	//Getiing the component data for presented submodules.
	status = ProSolidFeatVisit((ProSolid)curMdl, getReqComponentsID_F3A01, compsFilter, (ProAppData)&present_comps);
	ruleLog.Write("ProSolidFeatVisit status :" + to_string(status));

	UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", "Please wait it will take some time to fetch the clearance.");

	for (auto elem : present_comps)
	{
		if ((strlen(elem.name)) != 0)
		{
			string p_names = elem.name;
			string p_substr;
			p_substr = p_names.substr(4, 5);
			ruleLog.Write("_reqComps[].name = " + string(elem.name));
			ruleLog.Write("_reqComps[].id = " + to_string(elem.id));
			f3a01_comp.push_back(elem);
			elements.push_back(p_substr);
		}
	}

	//Missing submodules info from the above list.
	for (const auto& str : list_comp)
	{
		// Check if current element exists in vec2
		if (std::find(elements.begin(), elements.end(), str) == elements.end())
		{
			// Element not found in vec2, so print it
			ruleLog.Write("Non found :" + str);
			missing_elements.push_back(str);
		}
	}


	//Measuring the distance and clearance check for the present modules.
	string asm_nme;
	string asmnme_substr;
	string Remark_msg;
	Remark_msg += "Measured Value :";
	bool tar_result{};
	bool loop = true;
	bool loop1 = false;
	for (int i = 0; i < 1; ++i)
	{
		Remark_msg += "\nDistance between " + string(f3a01_comp[i].name) + ".ASM ";
		if (loop == false)
		{
			break;
		}
		for (int j = 1; j < f3a01_comp.size(); j++)
		{

			ruleLog.Write("2nd for loop");
			Pro3dPnt pnt_ar[2];
			ruleLog.Write("Part1_name :" + string(f3a01_comp[i].name));
			ruleLog.Write("Part2_name :" + string(f3a01_comp[j].name));
			rule_sts = IR_F3A01_007_measureDistanceBetweenComponents(f3a01_comp[i], f3a01_comp[j], clearance_value, pnt_ar);
			ruleLog.Write("measureDistanceBetweenComponents: " + to_string(status));

			char pointName[PRO_NAME_SIZE] = "CLEARANCE_HIGHLITE_PNT";
			strcat(pointName, to_string(i + 1).c_str());
			createDatumPoints(pnt_ar, "CSYS_ASM_DEF", pointName);

			ruleLog.Write("createDatumPoints: " + to_string(status));
			string act_clrnce;
			act_clrnce = to_string(round(clearance_value));
			act_clrnce.erase(act_clrnce.find_last_not_of('0') + 3);
			asm_nme.erase();
			asm_nme.append(string(f3a01_comp[j].name));
			asmnme_substr = asm_nme.substr(4, 5);
			string status;
			if (((asmnme_substr == "F3B01") || (asmnme_substr == "F3B02") || (asmnme_substr == "F3B03")
				||
				(asmnme_substr == "G1C01") || (asmnme_substr == "F4B02") || (asmnme_substr == "F4A02"))
				&& (clearance_value >= 80))
			{
				status = "PASS";
				Remark_msg += "and " + string(f3a01_comp[j].name) + ".ASM" + " =" + " " + (act_clrnce)+" mm" + " (" + status + ")" + "\n";
				tar_result = true;

			}
			else if ((asmnme_substr == "F3B06") && (clearance_value >= 100))
			{
				status = "PASS";
				Remark_msg += " and " + string(f3a01_comp[j].name) + ".ASM" + " =" + " " + (act_clrnce)+" mm" + " (" + status + ")" + "\n";
				tar_result = true;

			}
			else if (((asmnme_substr == "F2C01") || (asmnme_substr == "H2D02")) && (clearance_value >= 90))
			{
				status = "PASS";
				Remark_msg += "and " + string(f3a01_comp[j].name) + ".ASM" + " =" + " " + (act_clrnce)+" mm" + " (" + status + ")" + "\n";
				tar_result = true;
			}

			else if ((asmnme_substr == "F5A25") && (clearance_value >= 40))
			{
				status = "PASS";
				Remark_msg += "and " + string(f3a01_comp[j].name) + ".ASM" + " =" + " " + (act_clrnce)+" mm" + " (" + status + ")" + "\n";
				tar_result = true;
			}
			else if ((asmnme_substr == "F5A24") || (asmnme_substr == "F5B03") && (clearance_value >= 50))
			{
				status = "PASS";
				Remark_msg += "and " + string(f3a01_comp[j].name) + ".ASM" + " =" + " " + (act_clrnce)+" mm" + " (" + status + ")" + "\n";
				tar_result = true;

			}
			else
			{
				ruleLog.Write("Fail Condition");
				ruleLog.Write("Part1_name :" + string(f3a01_comp[i].name));
				ruleLog.Write("Part2_name :" + string(f3a01_comp[j].name));
				status = ProSelectionHighlight(sels[0], PRO_COLOR_HIGHLITE);
				ruleLog.Write("ProSelectionHighlight1: " + (status));
				status = ProSelectionHighlight(sels[1], PRO_COLOR_HIGHLITE);
				ruleLog.Write("ProSelectionHighlight2: " + (status));
				status = "FAIL";
				Remark_msg += "and " + string(f3a01_comp[j].name) + ".ASM" + " =" + " " + (act_clrnce)+" mm" + " (" + status + ")";
				tar_result = false;
				loop == false;
				break;
			}
		}

	}

	status = ProUIDialogShow(DLG_IRC_MAIN);
	if (isUserQuits)
		return -1;


	//Printing the results of present submodules results and missing submodules name.
	string accep;
	string remark_1;
	string miss;
	if (missing_elements.size() > 0)
	{
		remark_1 += "\nNot present submodules :";
		for (auto abs : missing_elements)
		{
			remark_1 += abs + ", ";
		}
		remark_1 += "\n\nAcceptance Criteria : Standard Gap between Fuel tank and other dynamic and hot aggregates has to be maintained.";
		if (tar_result == true)
		{
			final_res.result = "PASS";
			final_res.remark = Remark_msg + remark_1;
			ruleLog.Write("Remark :" + Remark_msg + remark_1);
		}
		else
		{
			final_res.result = "FAIL";
			final_res.remark = Remark_msg + remark_1;
			ruleLog.Write("Remark :" + Remark_msg);
		}
	}
	else
	{
		remark_1 += "\n\nAcceptance Criteria : Standard Gap between Fuel tank and other dynamic and hot aggregates has to be maintained.";
		if (tar_result == true)
		{

			final_res.result = "PASS";
			final_res.remark = Remark_msg + remark_1;
			ruleLog.Write("Remark :" + Remark_msg);
		}
		else
		{
			final_res.result = "FAIL";
			final_res.remark = Remark_msg + remark_1;
			ruleLog.Write("Remark :" + Remark_msg);
		}

	}



	return 0;
}

ProError IR_F3A01_007_measureDistanceBetweenComponents(ComponentData reqComp1, ComponentData reqComp2, double& distance, Pro3dPnt(&pnt_arr)[2])
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenComponents <=================");


	ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected
	ProIdTable idtbl2 = { reqComp2.id };		// component id of the component 2 to be selected

	ProName comp1_name, comp2_name;
	ProModelitem feature[2];
	ProMdl reqMdls[2];

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);

	ProStringToWstring(comp2_name, reqComp2.name);
	status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
	status = ProMdlToModelitem(reqMdls[1], &feature[1]);

	ProAsmcomppath path[2];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl2, 1, &path[1]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));
	status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	ProBoolean is_interference_found;
	//Pro3dPnt pnt_arr[2];
	status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_NONE, sels[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, sels[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));

	return PRO_TK_NO_ERROR;
}

ProError getReqComponentsID_F3A01(ProFeature* pFeat, ProError status, ProAppData present_comps)
{
	ruleLog.Write("----------------------------- getReqComponents_IF3A01 -----------------------------");

	ComponentData* reqs = (ComponentData*)present_comps;
	int reqs_size = 13;
	ProMdl req_mdl;
	wchar_t wMdlName[PRO_NAME_SIZE];
	char cMdlName[PRO_NAME_SIZE];

	status = ProAsmcompMdlGet((ProAsmcomp*)pFeat, &req_mdl);
	ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
	status = ProMdlMdlnameGet(req_mdl, wMdlName);
	ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(cMdlName, wMdlName);
	for (int i = 0; i < reqs_size; ++i)
	{
		ruleLog.Write("1");
		ruleLog.Write("Name_1 : " + string(cMdlName));
		ruleLog.Write("Name_2 : " + string(reqs[i].name));
		if (strcmp(cMdlName, reqs[i].name) == 0)
		{
			reqs[i].id = pFeat->id;
			break;
		}
	}


	return PRO_TK_NO_ERROR;
}

#pragma pop
