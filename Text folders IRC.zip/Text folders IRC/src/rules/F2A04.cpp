/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	|	V1_0_0		| F2A04 - FRONT AXLE/LIFT AXLE
==================================================================================================================*/
#include "F2A04.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	                 | DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IRF2A04_001		| Vinay Neel		| MF2A04; MF5B01; MF5A01; MF5A02	 | Ensure Hub Bolt PCD as per Wheel rim specification & Drum/Adapter Locating diameter on hub inline with Drum/Adapter specifications
===================================================================================================================*/
#define DLG_IR2A04_001 "dlg_IR_F2A04_001"
#define PB_RSELECT1		"pb_select1"
#define PB_RSELECT2		"pb_select2"
#define PB_RSELECT3		"pb_select3"
#define PB_RCANCEL       "CommitCancel"
#define PB_RUN           "pb_run"
#define PB_MEASURE       "pb_measure"
#define INP_PANNEL1       "Input_Panel1"
#define INP_PANNEL2       "Input_Panel2"
#define INP_PANNEL3       "Input_Panel3"

double bolt_pcd, wrim_pcd, drum_pcd;
int IRF2A04::IRF2A04_001(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2A04::IRF2A04_001   ==========================");

	/* your code goes here */
	bolt_pcd = 0, wrim_pcd = 0, drum_pcd = 0;

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IR2A04_001, DLG_IR2A04_001);
	status = ProUIDialogAboveactivewindowSet(DLG_IR2A04_001, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IR2A04_001, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IR2A04_001, PB_RUN, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IR2A04_001, PB_RSELECT1, (ProUIAction)select_action1_IRF2A04001, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IR2A04_001, PB_RSELECT2, (ProUIAction)select_action2_IRF2A04001, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IR2A04_001, PB_RSELECT3, (ProUIAction)select_action3_IRF2A04001, NULL);

	status = ProUIPushbuttonActivateActionSet(DLG_IR2A04_001, PB_MEASURE, (ProUIAction)measure_action_IRF2A04001, NULL);

	status = ProUIPushbuttonDisable(DLG_IR2A04_001, PB_RUN);
	status = ProUIPushbuttonDisable(DLG_IR2A04_001, PB_RSELECT2);
	status = ProUIPushbuttonDisable(DLG_IR2A04_001, PB_RSELECT3);
	status = ProUIPushbuttonDisable(DLG_IR2A04_001, PB_MEASURE);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IR2A04_001, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IR2A04_001);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;


	sprintf(remark, "Measured value :\nHub Bolt PCD = %0.2lf mm, \nWheel rim specification (PCD) = %0.2lf mm, \nDrum/Adapter Locating diameter (PCD) = %0.2lf mm; \nAcceptance criteria:\nHub Bolt PCD, wheel rim specification (PCD) and drum/adapter locating diameter should be matched.", bolt_pcd, wrim_pcd, drum_pcd);
	final_res.remark = string(remark);

	//double std_pcd_min = (bolt_pcd - 0.2), std_pcd_max = (bolt_pcd + 0.2);

	// DECLARE RESULT
	//if ((wrim_pcd >= std_pcd_min && wrim_pcd <= std_pcd_max) && (drum_pcd >= std_pcd_min && drum_pcd <= std_pcd_max)) {
	//	final_res.result = "PASS";
	//}
	//else {
	//	final_res.result = "FAIL";
	//}


	if (compareFloat(wrim_pcd, bolt_pcd) && compareFloat(drum_pcd, bolt_pcd))
	{
		final_res.result = "PASS";
	}
	else {
		final_res.result = "FAIL";
	}

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);


	return 0;
}

ProError select_action1_IRF2A04001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action1_IRF2A04001  --------------------------");

	ProSelection* surf_Sel;
	int n_sels;
	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surf_Sel, &n_sels);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(dialog, PB_RSELECT2);
		return status;
	}
	if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_RSELECT2);
		return status;
	}

	if (n_sels > 0 && n_sels == 2) {

		double distance;
		Pro2dPnt param_surfs1, param_surfs2;
		Pro3dPnt pnt_surfs1, pnt_surfs2;

		status = ProSelectionWithOptionsDistanceEval(surf_Sel[0], PRO_B_TRUE, surf_Sel[1], PRO_B_TRUE, param_surfs1, param_surfs2, pnt_surfs1, pnt_surfs2, &distance);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\twrim_pcd: " + to_string(distance));

		bolt_pcd = distance;
		status = ProUIPushbuttonEnable(dialog, PB_RSELECT2);
		return status;
	}

	return status;
}
ProError select_action2_IRF2A04001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action2_IRF2A04001  --------------------------");

	ProSelection* surf_Sel;
	int n_sels;
	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surf_Sel, &n_sels);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(dialog, PB_RSELECT3);
		return status;
	}
	if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_RSELECT3);
		return status;
	}

	if (n_sels > 0 && n_sels == 2) {

		double distance;
		Pro2dPnt param_surfs1, param_surfs2;
		Pro3dPnt pnt_surfs1, pnt_surfs2;

		status = ProSelectionWithOptionsDistanceEval(surf_Sel[0], PRO_B_TRUE, surf_Sel[1], PRO_B_TRUE, param_surfs1, param_surfs2, pnt_surfs1, pnt_surfs2, &distance);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\twrim_pcd: " + to_string(distance));

		status = ProUIPushbuttonEnable(dialog, PB_RSELECT3);

		wrim_pcd = distance;

		return status;
	}

	return status;
}
ProError select_action3_IRF2A04001(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action3_IRF2A04001  --------------------------");

	ProSelection* surf_Sel;
	int n_sels;
	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surf_Sel, &n_sels);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(dialog, PB_MEASURE);
		return status;
	}
	if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_MEASURE);
		return status;
	}

	if (n_sels > 0 && n_sels == 2) {

		double distance;
		Pro2dPnt param_surfs1, param_surfs2;
		Pro3dPnt pnt_surfs1, pnt_surfs2;

		status = ProSelectionWithOptionsDistanceEval(surf_Sel[0], PRO_B_TRUE, surf_Sel[1], PRO_B_TRUE, param_surfs1, param_surfs2, pnt_surfs1, pnt_surfs2, &distance);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdrum_pcd: " + to_string(distance));

		status = ProUIPushbuttonEnable(dialog, PB_MEASURE);

		drum_pcd = distance;

		return status;
	}

	return status;
}
ProError measure_action_IRF2A04001(char* dialog, char* component, ProAppData data) {

	ruleLog.Write("--------------------------  measure_action_IRF2A04001  --------------------------");

	wchar_t label1[50], label2[50], label3[50];
	char cname1[50], cname2[50], cname3[50];

	stringstream ss1, ss2, ss3;
	ss1 << fixed << setprecision(2) << bolt_pcd << "mm";
	ss2 << fixed << setprecision(2) << wrim_pcd << "mm";
	ss3 << fixed << setprecision(2) << drum_pcd << "mm";

	string str1 = ss1.str();
	strcpy(cname1, str1.c_str());

	string str2 = ss2.str();
	strcpy(cname2, str2.c_str());

	string str3 = ss3.str();
	strcpy(cname3, str3.c_str());

	ruleLog.Write("bolt_pcd: " + string(cname1));
	ProUIInputpanelValueSet(dialog, INP_PANNEL1, ProStringToWstring(label1, cname1));

	ruleLog.Write("wrim_pcd: " + string(cname2));
	ProUIInputpanelValueSet(dialog, INP_PANNEL2, ProStringToWstring(label2, cname2));

	ruleLog.Write("drum_pcd: " + string(cname3));
	ProUIInputpanelValueSet(dialog, INP_PANNEL3, ProStringToWstring(label3, cname3));

	status = ProUIPushbuttonDisable(DLG_IR2A04_001, PB_RSELECT1);
	status = ProUIPushbuttonDisable(DLG_IR2A04_001, PB_RSELECT2);
	status = ProUIPushbuttonDisable(DLG_IR2A04_001, PB_RSELECT3);
	status = ProUIPushbuttonEnable(dialog, PB_RUN);
	return status;
}

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	     		| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F2A04-002	| Prajakta Bhelawe	| MF2A04; MF5B01             	| Ensure Hub Bolt PCD & Wheel rim Locating diameter on hub inline with rim  specifications.
===================================================================================================================*/
#define DLG_IRF2A04_002     "dlg_IR_F2A04_002"
#define PB_RSELECT_WHEELRIM "pb_select_wheelrim"
#define PB_RSELECT_HUBBOLT  "pb_select_hubbolt"
#define PB_RCANCEL          "rule_cancel_pb"
#define PB_ROK			    "rule_ok_pb"
#define PB_MEASURE          "pb_measure" 
#define INP_PANNEL1         "Input_Panel1"
#define INP_PANNEL2         "Input_Panel2"

double bolt_pcd1, wrim_pcd1;
int IRF2A04::IRF2A04_002(ruleResult& final_res)
{
	ruleLog.Write("==========================   IRF2A04::IRF2A04_002   ==========================");

	bolt_pcd1 = 0, wrim_pcd1 = 0;

	isUserQuits = false;
	status = ProUIDialogCreate(DLG_IRF2A04_002, DLG_IRF2A04_002);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF2A04_002, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A04_002, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A04_002, PB_ROK, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A04_002, PB_RSELECT_WHEELRIM, (ProUIAction)select_action1_IRF2A04002, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A04_002, PB_RSELECT_HUBBOLT, (ProUIAction)select_action2_IRF2A04002, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF2A04_002, PB_MEASURE, (ProUIAction)measure_action_IRF2A04002, NULL);

	status = ProUIPushbuttonDisable(DLG_IRF2A04_002, PB_ROK);
	status = ProUIPushbuttonDisable(DLG_IRF2A04_002, PB_RSELECT_WHEELRIM);
	status = ProUIPushbuttonDisable(DLG_IRF2A04_002, PB_MEASURE);

	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF2A04_002, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF2A04_002);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	if (isUserQuits)
		return -1;

	sprintf(remark, "Measured value :\nHub Bolt PCD = %0.2lfmm, \nWheel rim specification (PCD) = %0.2lfmm; \nAcceptance criteria:\nHub Bolt PCD, wheel rim specification (PCD) should be matched \n within a tolerance of \u00B10.2mm.", bolt_pcd1, wrim_pcd1);
	final_res.remark = string(remark);
	ruleLog.Write("remark = " + string(remark));

	double std_pcd_min = (bolt_pcd1 - 0.2), std_pcd_max = (bolt_pcd1 + 0.2);

	// DECLARE RESULT
	if ((wrim_pcd1 >= std_pcd_min && wrim_pcd1 <= std_pcd_max) && (bolt_pcd1 != 0 && wrim_pcd1 != 0)) {
		final_res.result = "PASS";
	}
	else {
		final_res.result = "FAIL";
	}

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);


	return 0;
}

ProError select_action1_IRF2A04002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action1_IRF2A04001  --------------------------");

	ProSelection* surf_Sel;
	int n_sels;
	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surf_Sel, &n_sels);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(dialog, PB_MEASURE);
		return status;
	}
	if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_MEASURE);
		return status;
	}

	if (n_sels > 0 && n_sels == 2) {

		double distance;
		Pro2dPnt param_surfs1, param_surfs2;
		Pro3dPnt pnt_surfs1, pnt_surfs2;

		status = ProSelectionWithOptionsDistanceEval(surf_Sel[0], PRO_B_TRUE, surf_Sel[1], PRO_B_TRUE, param_surfs1, param_surfs2, pnt_surfs1, pnt_surfs2, &distance);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\twrim_pcd: " + to_string(distance));

		wrim_pcd1 = distance;
		status = ProUIPushbuttonEnable(dialog, PB_MEASURE);
		return status;
	}

	return status;
}

ProError select_action2_IRF2A04002(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action3_IRF2A04001  --------------------------");

	ProSelection* surf_Sel;
	int n_sels;
	status = ProSelect((char*)"surface", 2, NULL, NULL, NULL, NULL, &surf_Sel, &n_sels);
	ruleLog.Write("ProSelect: " + to_string(status));

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(dialog, PB_RSELECT_WHEELRIM);
		return status;
	}
	if (n_sels < 2 || status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please provide valid inputs!. Refer help document for details.");
		status = ProUIPushbuttonDisable(dialog, PB_RSELECT_WHEELRIM);
		return status;
	}

	if (n_sels > 0 && n_sels == 2) {

		double distance;
		Pro2dPnt param_surfs1, param_surfs2;
		Pro3dPnt pnt_surfs1, pnt_surfs2;

		status = ProSelectionWithOptionsDistanceEval(surf_Sel[0], PRO_B_TRUE, surf_Sel[1], PRO_B_TRUE, param_surfs1, param_surfs2, pnt_surfs1, pnt_surfs2, &distance);
		ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdrum_pcd: " + to_string(distance));

		status = ProUIPushbuttonEnable(dialog, PB_RSELECT_WHEELRIM);

		bolt_pcd1 = distance;

		return status;
	}

	return status;
}
ProError measure_action_IRF2A04002(char* dialog, char* component, ProAppData data) {

	ruleLog.Write("--------------------------  measure_action_IRF2A04001  --------------------------");

	wchar_t label1[50], label2[50], label3[50];
	char cname1[50], cname2[50], cname3[50];

	stringstream ss1, ss2, ss3;
	ss1 << fixed << setprecision(2) << wrim_pcd1 << "mm";
	ss2 << fixed << setprecision(2) << bolt_pcd1 << "mm";


	string str1 = ss1.str();
	strcpy(cname1, str1.c_str());

	string str2 = ss2.str();
	strcpy(cname2, str2.c_str());

	ruleLog.Write("bolt_pcd: " + string(cname1));
	ProUIInputpanelValueSet(dialog, INP_PANNEL1, ProStringToWstring(label1, cname1));

	ruleLog.Write("wrim_pcd: " + string(cname2));
	ProUIInputpanelValueSet(dialog, INP_PANNEL2, ProStringToWstring(label2, cname2));

	status = ProUIPushbuttonEnable(dialog, PB_ROK);
	return status;
}

#pragma pop
