/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F1E01 - CHASIS CONTROLS RULES
==================================================================================================================*/
#include "F1E01.h"
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES	| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F1E01-001	| Pallavi Garodi	| MF1E01; MF1E04	| DBV or vacuum booster to be packaged based on type of brake (Air/Hydraulic).
===================================================================================================================*/

//int IRF1E01::IRF1E01_001(ruleResult &final_res)
//{
//	ruleLog.Write("==========================   IRF1E01::IRF1E01_001   ==========================");
//
//	/* your code goes here */
//
//	return 0;
//}


/*==================================================================================================================
RULE ID			| DEVELOPER			| DEPENDENT MODULES					| DESCRIPTION
-------------------------------------------------------------------------------------------------------------------
IR-F1E01-007	| Vinay Neel		| MF1E01; MF1E08; MF2B03; MF2B01	| Brake pedal clearance of 50-70 mm on either side in Y direction, with surrounding aggregates  should be ensured.
===================================================================================================================*/
#define DLG_IRF1E01_007 "dlg_IR_F1E01_007"
#define PB_RSELECT	"pb_select"
#define PB_RCANCEL       "CommitCancel"
#define PB_RUN           "pb_run"
#define RB_GRP           "RadioGroup1"

vector<SelPartData> sel_part_data;
double clearance_value;

int IRF1E01::IRF1E01_007(ruleResult &final_res)
{
	ruleLog.Write("==========================   IRF1E01::IRF1E01_007   ==========================");
	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	/* your code goes here */
	sel_part_data.clear();
	double stdClearance = 20.00;
	isUserQuits = false;

	status = ProUIDialogCreate(DLG_IRF1E01_007, DLG_IRF1E01_007);
	status = ProUIDialogAboveactivewindowSet(DLG_IRF1E01_007, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF1E01_007, PB_RCANCEL, (ProUIAction)ruleDlgCloseAction, (ProAppData)&isUserQuits);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF1E01_007, PB_RUN, (ProUIAction)ruleDlgOKaction, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRF1E01_007, PB_RSELECT, (ProUIAction)select_action_IRF1E01_007, NULL);
	status = ProUIRadiogroupSelectActionSet(DLG_IRF1E01_007, RB_GRP, NULL, NULL);

	status = ProUIPushbuttonDisable(DLG_IRF1E01_007, PB_RUN);
	
	status = ProUIDialogHide(DLG_IRC_MAIN);
	status = ProUIDialogActivate(DLG_IRF1E01_007, &dlg_sts);
	ruleLog.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRF1E01_007);
	ruleLog.Write("ProUIDialogDestroy: " + to_string(status));
	status = ProUIDialogShow(DLG_IRC_MAIN);

	
	if (isUserQuits)
		return -1;


	// DECLARE RESULT
	sprintf(remark, "\nClearance between Brake pedal and Rubber bellow = %.2lfmm; Acceptance criteria: Clearance greater than %.2lfmm; \nUsed Reference part : %s.PRT (Id : %s),\nUsed Reference part : %s.PRT (Id : %s)",clearance_value, stdClearance,sel_part_data[0].name,(to_string(sel_part_data[0].id)).c_str(),sel_part_data[1].name, (to_string(sel_part_data[1].id)).c_str());
	final_res.remark = string(remark);

	if (clearance_value > stdClearance)
		final_res.result = "PASS";
	else
		final_res.result = "FAIL";

	ruleLog.Write("status: " + final_res.result);
	ruleLog.Write("remark: " + final_res.remark);

	sel_part_data.clear();
	clearance_value = 0;

	return 0;
}

ProError select_action_IRF1E01_007(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("--------------------------  select_action_IRF1E01_007  --------------------------");
	int n_sels, n_sels1;
	ProMdl         model;
	ProSolid parent_asm;
	InterfaceRule _irule;
	ProSelection Sel1;
	ProSelection Sel2;
	ProSelection* Part_Sel;
	ProSelection* Quit_Sel;
	SelPartData seldata{};
	vector<ProSelection> part_sel;

	int radioGrpNames[3];
	char** buttonNames;
	char selectedButton[PRO_NAME_SIZE];

	status = ProUIRadiogroupSelectednamesGet(DLG_IRF1E01_007, RB_GRP, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status: " + to_string(status));

	ruleLog.Write("selected button name: " + (string)buttonNames[0]);

	if (strcmp(buttonNames[0], "Select") == 0)
	{
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Warning", "Please select Quilt or Part for the selection of Brake pedal.");
		status = ProUIPushbuttonDisable(dialog, PB_RUN);
		return status;
	}


	if (strcmp(buttonNames[0], "Quilt") == 0)
	{
		status = ProSelect((char*)"dtmqlt", 1, NULL, NULL, NULL, NULL, &Quit_Sel, &n_sels);
		ruleLog.Write("ProSelect: " + to_string(status));

		status = ProSelectionCopy(Quit_Sel[0], &Sel1);
		ruleLog.Write("ProSelectionCopy: " + to_string(status));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIPushbuttonDisable(DLG_IRF1E01_007, PB_RUN);
			return status;
		}

	}
	else
	{
		status = ProSelect((char*)"part", 1, NULL, NULL, NULL, NULL, &Quit_Sel, &n_sels);
		ruleLog.Write("ProSelect: " + to_string(status));

		status = ProSelectionCopy(Quit_Sel[0], &Sel1);
		ruleLog.Write("ProSelectionCopy: " + to_string(status));

		if (status == PRO_TK_USER_ABORT) {
			status = ProUIPushbuttonDisable(DLG_IRF1E01_007, PB_RUN);
			return status;
		}
	}

	part_sel.push_back(Sel1);


	status = ProSelect((char*)"part", 1, NULL, NULL, NULL, NULL, &Part_Sel, &n_sels1);
	ruleLog.Write("ProSelect: " + to_string(status));

	status = ProSelectionCopy(Part_Sel[0], &Sel2);
	ruleLog.Write("ProSelectionCopy: " + to_string(status));

	part_sel.push_back(Sel2);

	if (status == PRO_TK_USER_ABORT) {
		status = ProUIPushbuttonDisable(DLG_IRF1E01_007, PB_RUN);
		return status;
	}

	ProBoolean  interf;
	Pro3dPnt coord[2];
	double param[2];
	double pnt[2];

	status = ProSelectionWithOptionsDistanceEval(Sel2, PRO_B_TRUE, Sel1, PRO_B_TRUE, &param[0], &param[1], &pnt[0], &pnt[1], &clearance_value);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval status = " + to_string(status));
	ruleLog.Write("clearance_value = " + to_string(clearance_value));

	if (n_sels > 0 && n_sels1 > 0) {
		status = ProUIPushbuttonEnable(DLG_IRF1E01_007, PB_RUN);
	}

	for (int i = 0; i < 2; ++i) {
		ProMdlName		wname;
		char            cname[PRO_MDLNAME_SIZE];
		ProModelitem   modelitem;
		ProAsmcomppath comppath;
		ProMdl Mdl;

		status = ProSelectionModelitemGet(part_sel[i], &modelitem);
		status = ProModelitemMdlGet(&modelitem, &Mdl);
		status = ProMdlMdlnameGet(Mdl, wname);

		status = ProSelectionAsmcomppathGet(part_sel[i], &comppath);

		ProWstringToString(cname, wname);
		strcpy(seldata.name, cname);
		seldata.id = comppath.comp_id_table[comppath.table_num - 1];
		ruleLog.Write("model_names1: " + string(cname));
		ruleLog.Write("Id1: " + to_string(seldata.id));
		sel_part_data.push_back(seldata);
	}

	status = ProUIPushbuttonDisable(DLG_IRF1E01_007, PB_RSELECT);
	return status;
}
#pragma pop
