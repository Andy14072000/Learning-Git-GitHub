/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 31-05-2023	| V1_0_0		| ASSEMBLY TOOL FOR MISSING SUB-MODULES
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#define CURL_STATICLIB  

#include "DPDSCreoIRCapplication.h"
#include "AssemblyTool.h"

//#define DLG_ASM_TOOL		"dlg_asm_tool"
//#define TBL_ASM_TOOL		"tool_tbl"
//#define TBL_LBL_ASM_TOOL	"tbl_lbl"
//#define TBL_ASMNAME_IP		"tbl_asmname_ip"
//#define TBL_PB_ASM_TOOL		"tbl_pb"
//#define RG_ASM_MODE			"rg_asm_mode"
//#define IP_NEW_ASM_NAME		"ip_new_asm"
//#define IP_ASMLOC			"asmloc_ip"
//#define PB_BROWSE_ASMLOC	"browse_asmloc_pb"
//#define CANCEL_PB_ASM_TOOL	"CommitCancel"
//#define OK_PB_ASM_TOOL		"CommitOK"

#define DLG_ASM_TOOL		"asm_tool_login_ui"
#define CANCEL_PB_ASM_TOOL	"CommitCancel"
#define OK_PB_ASM_TOOL		"CommitOK"
#define IP_USERNAME			"username_ip"
#define IP_PWD				"pwd_ip"

// GLOBAL ENTITIES
vector<AsmPosition> asmPosList;
char cRowname[15], cNewAsmName[PRO_NAME_SIZE], cCwd[PRO_PATH_SIZE], cSrcDir[PRO_PATH_SIZE];
int noOfMissingSubModls;
wchar_t wNewAsmName[PRO_NAME_SIZE], wCwd[PRO_PATH_SIZE], wSrcDir[PRO_PATH_SIZE];
ModelCategory mdlCategory;
int returnSystemCode;

int assemblyToolMain(vector<string> missingModules, string rule_id, ModelCategory category)
{
	mainLog.Write("================================== assemblyToolMain ==================================");

	asmPosList.clear();

	// empty values
	strcpy(cNewAsmName,"");	
	strcpy(cCwd,"");	
	strcpy(cSrcDir,"");	
	strcpy(cRowname,"");

	wcscpy(wNewAsmName, L"");
	wcscpy(wCwd, L"");
	wcscpy(wSrcDir, L"");

	status = ProUIDialogCreate(DLG_ASM_TOOL, DLG_ASM_TOOL);
	mainLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_ASM_TOOL, PRO_B_FALSE);
	bool userCancels = false;
	status = ProUIPushbuttonActivateActionSet(DLG_ASM_TOOL, CANCEL_PB_ASM_TOOL, (ProUIAction)asmToolDlgCloseAction,  (ProAppData)&userCancels);
	status = ProUIPushbuttonActivateActionSet(DLG_ASM_TOOL, OK_PB_ASM_TOOL, (ProUIAction)asmToolDlgOKAction, NULL);

	int asmToolDlgSts;
	status = ProUIDialogActivate(DLG_ASM_TOOL, &asmToolDlgSts);
	mainLog.Write("ProUIDialogActivate(DLG_ASM_TOOL): " + to_string(status));
	char cUserName[PRO_NAME_SIZE]{}, cPwd[PRO_NAME_SIZE]{};
	wchar_t *wUserName, *wPwd;

	status = ProUIInputpanelValueGet(DLG_ASM_TOOL, IP_USERNAME, &wUserName);
	mainLog.Write("ProUIInputpanelValueGet: " + to_string(status));
	status = ProUIInputpanelValueGet(DLG_ASM_TOOL, IP_PWD, &wPwd);
	mainLog.Write("ProUIInputpanelValueGet: " + to_string(status));

	ProWstringToString(cUserName, wUserName);
	ProWstringToString(cPwd, wPwd);
	mainLog.Write("cUserName: " + string(cUserName));
	//mainLog.Write("cPwd: " + string(cPwd));

	status = ProUIDialogDestroy(DLG_ASM_TOOL);
	mainLog.Write("ProUIDialogDestroy(DLG_ASM_TOOL): " + to_string(status));

	if (userCancels)
		return -1;
	
	status = ProMdlEraseNotDisplayed();	// removes the dummy model if any are present in session in order for proper assembling process

#pragma region CURL OPERATIONS

	_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", "Please note that it may take some time to download the required items.");

	CURL* curl;
	CURLcode res;
	curl_global_init(CURL_GLOBAL_DEFAULT);
	curl = curl_easy_init();
	std::string responseBuffer{};

	if(curl)
	{
		wchar_t *wVCnumber;
		char cVCnumber[PRO_NAME_SIZE];
		status = ProUIInputpanelValueGet(DLG_IRC_MAIN, "vc_number_ip", &wVCnumber);
		mainLog.Write("ProUIInputpanelValueGet: "+to_string(status));
		ProWstringToString(cVCnumber, wVCnumber);
		mainLog.Write("cVCnumber: "+string(cVCnumber));

		const regex VCnumberPat(R"(\d{8}[A-Za-z])");

		if(!regex_match(string(cVCnumber), VCnumberPat))
		{
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "Please enter a proper VC number.");
			return -1;
		}

		std::string soapXml = R"(
		<soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
						   xmlns:xsd="http://www.w3.org/2001/XMLSchema"
						   xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
						   xmlns:urn="urn:TMatrixDownload">
			<soapenv:Header/>
			<soapenv:Body>
				<urn:getItemData soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
					<Item xsi:type="xsd:string">VC_NUMBER</Item>
				</urn:getItemData>
			</soapenv:Body>
		</soapenv:Envelope>)";	//55506135R - sub-mdl //51840168R - cp

		// replace the VC_NUMBER with entered value
		size_t cVCnumberPos = soapXml.find("VC_NUMBER");
		if (cVCnumberPos != std::string::npos){
			soapXml.replace(cVCnumberPos,strlen("VC_NUMBER"), string(cVCnumber));
		}
		mainLog.Write("soapXml: "+soapXml);

		struct curl_slist* headers = nullptr;
		headers = curl_slist_append(headers, "Content-Type: text/xml");

		curl_easy_setopt(curl, CURLOPT_URL, "http://172.22.99.106:9080/cgi/TMatrixDownload.cgi");
		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
		curl_easy_setopt(curl, CURLOPT_POSTFIELDS, soapXml.c_str());
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBuffer);

		res = curl_easy_perform(curl);

		if (res != CURLE_OK){
			mainLog.Write("curl_easy_perform() failed: "+to_string(res));
			return -1;
		}
		/*else{*/
		mainLog.Write("--- Response ---");
		mainLog.Write(responseBuffer);
		//}

		curl_slist_free_all(headers);
		curl_easy_cleanup(curl);
		curl_global_cleanup();
	}

#pragma endregion CURL OPERATIONS

	// the upcoming lines of code executes if res is CURLE_OK
	///*status = ProDirectoryCurrentGet(wCwd);
	//ProWstringToString(cCwd, wCwd);
	//mainLog.Write("cCwd: "+string(cCwd));*/

	mdlCategory = category;

	vector<string> prtDetailsValues = extractPLMvalues(responseBuffer, "PartDetails");	// extract <PartDetails> tag from string
	mainLog.Write("size of prtDetailsValues: "+to_string(prtDetailsValues.size()));
	for(auto elem : prtDetailsValues)
		mainLog.Write("elem: "+elem);

	vector<PLM_POS_DATA> PrtPosMatrices;
	getPartNumberAndPosMatrix(prtDetailsValues, PrtPosMatrices);
	mainLog.Write("PrtPosMatrices.size(): "+to_string(PrtPosMatrices.size()));
	prtDetailsValues.clear();

	if(mdlCategory == SUB_MODULE){
		mainLog.Write("entered mdlCategory == SUB_MODULE");

		ProTKSprintf(cNewAsmName, "DUMMY_%s", cCurMdlName);	// cCurMdlName = sub-module name
		ProStringToWstring(wNewAsmName, cNewAsmName);

		missingModules.push_back(string(cCurMdlName).substr(4,5));	// appending the current model name for fetching the position matrix
	}
	else if(mdlCategory == CP_ITEM)
	{
		mainLog.Write("entered mdlCategory == CP_ITEM");

		for (auto subModl : subModulesList)
		{
			if(subModl.name.find(rule_id.substr(3,5))!=string::npos)	// finding the sub-module that belongs to rule
			{
				ProTKSprintf(cNewAsmName, "DUMMY_%s", subModl.name);
				ProStringToWstring(wNewAsmName, cNewAsmName);
				break;
			}
		}
		//mainLog.Write("New Dummy assembly name: "+string(cNewAsmName)); 

		AsmPosition _tempAsmPos;
		bool cpItemFound = false;

		strcpy(_tempAsmPos.name, cCurMdlName);	// CP item name 
		for (auto elem : PrtPosMatrices)
		{
			// check if the pos matrix for CP item is present in the PLM
			if(elem.prtNo.find(cCurMdlName) != string::npos){
				mainLog.Write("CP item in the PLM under the VC");
				_utils.copyProMatrices(elem.posMatrix, _tempAsmPos.pos);
				cpItemFound = true;
				break;
			}
		}
		if(!cpItemFound){
			_utils.copyProMatrices(identity_matrix, _tempAsmPos.pos);
		}
		asmPosList.push_back(_tempAsmPos);
	}

	for (int i = 0; i < missingModules.size(); ++i)	// mdlCategory == SUB_MODULE or DUMMY or CP_ITEM
	{
		bool subModuleFound = false;
		AsmPosition _tempAsmPos;

		mainLog.Write("missingModules["+to_string(i)+"]: " +missingModules[i]);
		for (auto elem : PrtPosMatrices)
		{
			if(elem.prtNo.find(missingModules[i].c_str()) != string::npos){
				mainLog.Write("subModuleFound in the PLM under the VC");
				mainLog.Write("Found part no: "+ elem.prtNo);
				strcpy(_tempAsmPos.modAddrs, missingModules[i].c_str());
				strcpy(_tempAsmPos.name, elem.prtNo.substr(0,14).c_str());	// stripping off the revision from name
				strcpy(_tempAsmPos.rev, elem.prtNo.substr(15).c_str());	// revision
				_utils.copyProMatrices(elem.posMatrix, _tempAsmPos.pos);
				subModuleFound = true;
				//break;
			}
		}
		if(!subModuleFound){
			mainLog.Write("subModule not Found");
			strcpy(_tempAsmPos.modAddrs, missingModules[i].c_str());
			_utils.copyProMatrices(identity_matrix, _tempAsmPos.pos);
		}
		asmPosList.push_back(_tempAsmPos);
	}
	mainLog.Write("asmPosList.size(): "+to_string(asmPosList.size()));

	for(auto elem : asmPosList){
		mainLog.Write("Module address: "+string(elem.modAddrs));
		mainLog.Write("Sub-Module name: "+string(elem.name));
		for(int i=0; i<4; ++i){
			for(int j=0; j<4; ++j){
				mainLog.Write(_utils.doubleToString(elem.pos[i][j]));
			}
		}
	}
	PrtPosMatrices.clear();

	// ================================== assemble_action ==================================
	mainLog.Write("================================== assemble_action ==================================");
	ProAsmcomp asmFeat;
	ProMdl topLevelMdl{}, childMdl{};
	bool isMissingPosMatrix = false;

	// set constraints
	ProAsmcompconstraint* constraints;
	ProAsmcompconstraint constraint;
	status = ProArrayAlloc(0, sizeof(ProAsmcompconstraint), 1, (ProArray*)&constraints);
	status = ProAsmcompconstraintAlloc(&constraint);
	status = ProAsmcompconstraintTypeSet(constraint, PRO_ASM_FIX);
	status = ProArrayObjectAdd((ProArray*)&constraints, -1, 1, &constraint);

	// check if position matrix file is missing
	string missingPosModelNames;
	vector<string> missingPosMatModName;
	for(auto item : asmPosList)
	{
		if(_utils.compareProMatrices(item.pos, identity_matrix) == true){
			missingPosModelNames += string(item.modAddrs) + ", ";
			missingPosMatModName.push_back(missingPosModelNames);
			isMissingPosMatrix = true;
			mainLog.Write("missingPosModelNames:"+ missingPosModelNames);
		}
	}

	char cMissingModeladd[PRO_PATH_SIZE];

	// prompt user for confirmation
	if(isMissingPosMatrix)
	{
		strcpy(cMissingModeladd, "\t");
		strcat(cMissingModeladd, "Position matrix is not available for below sub modules,\n\n");
		for (auto name : missingPosMatModName)
		{
			strcat(cMissingModeladd, name.c_str());
			strcat(cMissingModeladd, "\n\t");
		}

		ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
		msg_buttons[0] = PRO_UI_MESSAGE_YES;
		msg_buttons[1] = PRO_UI_MESSAGE_NO;
		//_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Missing", cMissingModl);

		strcat(cMissingModeladd, "\nDo you have corresponding CP item ?\nIf Yes, Please open the CP item and run the tool again.");

		user_choice = _utils.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation", cMissingModeladd, msg_buttons);
		if(user_choice == PRO_UI_MESSAGE_NO)
			return PRO_TK_NO_ERROR;	// return if NO clicked
	}

	// get the topLevelMdl handle
	if(mdlCategory == DUMMY)
	{
		mainLog.Write("exist_asm");
		status = ProMdlCurrentGet(&topLevelMdl);
	}
	else if(mdlCategory == SUB_MODULE || mdlCategory == CP_ITEM)
	{
		mainLog.Write("new_asm");
		ProPath wDummyMdlPath, wTemplatePath;
		ProMdl templateMdl;
		char cDummyMdlPath[PRO_PATH_SIZE], cTemplatePath[PRO_PATH_SIZE];

		// get the topLevelMdl handle
		ProTKSprintf(cTemplatePath, "%s%s", PROE_TML_STD_PATH, "\\templates\\start_assembly_plm_creo3.asm");
		mainLog.Write("cTemplatePath: "+ string(cTemplatePath));
		ProStringToWstring(wTemplatePath, cTemplatePath);

		status = ProMdlnameRetrieve(wTemplatePath, PRO_MDLFILE_ASSEMBLY, &templateMdl);
		mainLog.Write("ProMdlnameRetrieve: "+to_string(status));
		/*ProWstringToString(cCwd, wCwd);
		ProTKSprintf(cDummyMdlPath, "%s%s.asm", cCwd, cNewAsmName);
		ProTKSprintf(cDummyMdlPath, "D:\\PLMDocs\\myuadata\\%s.asm", cNewAsmName);
		ProStringToWstring(wDummyMdlPath, cDummyMdlPath);
		mainLog.Write("cDummyMdlPath: "+ string(cDummyMdlPath));*/

		status = ProDirectoryCurrentGet(wCwd);
		status = ProDirectoryChange(L"D:\\PLMDocs\\myuadata\\");
		status = ProMdlnameCopy(templateMdl, wNewAsmName, &topLevelMdl);
		mainLog.Write("ProMdlnameCopy: "+to_string(status));
		status = ProDirectoryChange(wCwd);

		//status = ProAsmcompAssemble((ProAssembly)topLevelMdl, (ProSolid)curMdl, identity_matrix, &asmFeat);  //source_comp_path
		//mainLog.Write("ProAsmcompAssemble: " + to_string(status));
		//if (status == PRO_TK_NO_ERROR){
		//	status = ProAsmcompConstraintsSet(NULL, &asmFeat, constraints);
		//	mainLog.Write("ProAsmcompConstraintsSet: " + to_string(status));
		//}
	}

	// create temp dir inside /myuadata
	filesystem::path sourceDir = "D:\\PLMDocs\\myuadata\\temp";
	filesystem::path destDir = "D:\\PLMDocs\\myuadata";

	const char* source_directory = "D:\\PLMDocs\\myuadata\\temp";
	const char* destination_directory = "D:\\PLMDocs\\myuadata";

	// download CAD models from PLM
	for(auto elem : asmPosList)
	{
		/*if (RemoveDirectory(source_directory)) {
			mainLog.Write("RemoveDirectory success.");
		} else {
			mainLog.Write("RemoveDirectory failed with error code");
		}*/

		string removeDirCmd = "rmdir /s /q "+string(source_directory)+" > NUL 2>&1";
		mainLog.Write("removeDirCmd: "+removeDirCmd);
		returnSystemCode = system(removeDirCmd.c_str());
		//if(returnSystemCode != 0)
		//	return -1;

		// Check if the source directory exists
		if (filesystem::is_directory(destDir)) {
			// Create the destination directory if it doesn't exist
			if (!filesystem::is_directory(sourceDir)) {
				if (!filesystem::create_directory(sourceDir)) {
					mainLog.Write("Error: Unable to create destination directory.");
					return 1;
				}
			}
		}

		// add the system command
		//string downloadCADcmd = "C:\\ipem1303_cvprod\\ipemExport.bat \"-u=sagard1.ttl\" \"-p=Creo@2023\" \"-export=true\" \"-export_related=true\" \"-export_dir=D:\\PLMDocs\\myuadata\\temp\" \"-item_id=" + string(elem.name) +"\" > NUL 2>&1";
		// PENDING! - add revision to the command
		string downloadCADcmd = "C:\\ipem2406_cvprod\\ipemexport.bat \"-u="+string(cUserName)+"\" \"-p="+string(cPwd)+"\" \"-export=true\" \"-export_related=true\" \"-export_dir="+ string(source_directory) + "\" \"-item_id=" + string(elem.name) +"\" > NUL 2>&1";
		//mainLog.Write("downloadCADcmd: " + downloadCADcmd);
		returnSystemCode = system(downloadCADcmd.c_str());
		mainLog.Write("returnSystemCode: " + to_string(returnSystemCode));

		int file_count = 0;
		for (const auto& entry : filesystem::directory_iterator(sourceDir)) {
			if (filesystem::is_regular_file(entry.path())) {
				file_count++;
			}
		}

		if(returnSystemCode == 0 && file_count > 0)
		{
			// move files from temp to myuadata
			WIN32_FIND_DATA findFileData;
			HANDLE hFind = FindFirstFile((std::string(source_directory) + "\\*").c_str(), &findFileData);
			if (hFind == INVALID_HANDLE_VALUE) {
				mainLog.Write("Error finding files in the source directory.");
				return 1;
			}
			do {
				if (!(findFileData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
				{
					std::string source_file = string(source_directory) + "\\" + findFileData.cFileName;
					std::string destination_file = string(destination_directory) + "\\" + findFileData.cFileName;

					if (MoveFileEx(source_file.c_str(), destination_file.c_str(), MOVEFILE_REPLACE_EXISTING)) {
						mainLog.Write("File moved successfully.");
					} else {
						mainLog.Write("MoveFile failed with error code");
					}
				}
			} while (FindNextFile(hFind, &findFileData) != 0);
			FindClose(hFind);
		}
		else{
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error!", "Error occured while downloading the models. PLease connect with the support team.");
		}
	}

	vector<string> notFoundModules;

	for(int i=0; i< asmPosList.size(); ++i)
	{
		wchar_t wSrcPath[PRO_PATH_SIZE];
		char cSrcPath[PRO_PATH_SIZE];
		ProTKSprintf(cSrcPath, "%s\\%s.asm", destination_directory, asmPosList[i].name);
		mainLog.Write("cSrcPath: " + string(cSrcPath));
		ProStringToWstring(wSrcPath, cSrcPath);
		status = ProMdlnameRetrieve(wSrcPath, PRO_MDLFILE_ASSEMBLY, &childMdl);
		mainLog.Write("ProMdlnameRetrieve [PRO_MDLFILE_ASSEMBLY]: " + to_string(status));
		if(status == PRO_TK_E_NOT_FOUND)
		{
			ProTKSprintf(cSrcPath, "%s\\%s.prt", destination_directory, asmPosList[i].name);
			mainLog.Write("cSrcPath: " + string(cSrcPath));
			ProStringToWstring(wSrcPath, cSrcPath);
			status = ProMdlnameRetrieve(wSrcPath, PRO_MDLFILE_PART, &childMdl);
			mainLog.Write("ProMdlnameRetrieve [PRO_MDLFILE_PART]: " + to_string(status));
		}
		if(status != PRO_TK_NO_ERROR){
			notFoundModules.push_back(asmPosList[i].modAddrs);
			//return status;
			continue;
		}
		status = ProAsmcompAssemble((ProAssembly)topLevelMdl, (ProSolid)childMdl, asmPosList[i].pos, &asmFeat);  //source_comp_path
		mainLog.Write("ProAsmcompAssemble: " + to_string(status));
		if (status == PRO_TK_NO_ERROR){
			status = ProAsmcompConstraintsSet(NULL, &asmFeat, constraints);
			mainLog.Write("ProAsmcompConstraintsSet: " + to_string(status));
		}
	}
	status = ProSolidRegenerate((ProSolid)topLevelMdl, PRO_REGEN_NO_FLAGS);
	mainLog.Write("ProSolidRegenerate: " + to_string(status));

	if(mdlCategory == SUB_MODULE || mdlCategory == CP_ITEM)
	{
		// CREATE A NEW WINDOW FOR DRAWING
		int asm_win_id;
		status = ProObjectwindowMdlnameCreate(wNewAsmName, PRO_ASSEMBLY, &asm_win_id);
		mainLog.Write("ProObjectwindowMdlnameCreate: "+to_string(status) +"asm_win_id: " +to_string(asm_win_id));
		status = ProWindowCurrentSet(asm_win_id);
		mainLog.Write("ProWindowCurrentSet: "+to_string(status));
		status = ProWindowActivate(asm_win_id);
		mainLog.Write("ProWindowActivate: "+to_string(status));

		status = ProMdlDisplay(topLevelMdl);
		mainLog.Write("ProMdlDisplay: " + to_string(status));
	}

	if(notFoundModules.size()>0){
		string errMsg = "Unable to retrieve the sub-module for";
		for(auto mod : notFoundModules){
			errMsg += " "+mod+";";
		}
		errMsg += "\nPlease check if the models are available in D:\\PLMDocs\\myuadata\\";
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error!", errMsg);
	}
	notFoundModules.clear();

	if(isMissingPosMatrix)
	{
		static ProFileName msgFile;
		string txtPath = string(cTextPath)+"\\text\\usascii\\";
		mainLog.Write("txtPath: " + txtPath);

		string msgContent = "The position matrix is not available for " + missingPosModelNames +"module address(es).";
		char cMsgContent[PRO_PATH_SIZE];
		strcpy(cMsgContent, msgContent.c_str());
		msgContent += "\n"+msgContent;

		mainLog.Write(msgContent);

		_utils.createFile("creo_msg_area.txt", txtPath, msgContent);
		ProStringToWstring(msgFile, (char*)"creo_msg_area.txt");

		status = ProMessageDisplay(msgFile, cMsgContent);
	}

	asmPosList.clear();

	return 0;
}

//ProError asmname_ip_action(char* dialog, char* component, ProAppData data)
//{
//	mainLog.Write("================================== asmname_ip_action ==================================");
//	wchar_t *wIpVal, *wModlAddrs;
//	char cIpVal[PRO_NAME_SIZE], cPbName[PRO_NAME_SIZE], cModlAddrs[PRO_NAME_SIZE];
//
//	status = ProUIInputpanelValueGet(dialog, component, &wIpVal);
//	ProWstringToString(cIpVal, wIpVal);
//	getRowNameFromComponent(component, cRowname);
//	mainLog.Write("cRowname: "+ string(cRowname));
//	ProTKSprintf(cPbName, "browsepb_%s", cRowname);	// get the pb name
//	int missingSubModIdx = stoi(string(cRowname).substr(1))-1;
//	mainLog.Write("missingSubModIdx: "+ to_string(missingSubModIdx));
//	strcpy(asmPosList[missingSubModIdx].name, cIpVal);
//
//	// ENABLE/DISABLE BROWSE PB
//	if(isAsmNameValid(asmPosList[missingSubModIdx].name) && toUpperCase(string(asmPosList[missingSubModIdx].name).substr(4,5)).compare(string(asmPosList[missingSubModIdx].modAddrs).substr(1)) == 0)
//		status = ProUIPushbuttonEnable(dialog, cPbName);
//	else
//		status = ProUIPushbuttonDisable(dialog, cPbName);
//
//	// ENABLE/DISABLE ASSEMBLY PB
//	status = ProUIPushbuttonDisable(dialog, OK_PB_ASM_TOOL);	// disable by default
//	bool enableAsmBtn = true; // to toggle if any invalid names found while iterating the loop.
//	for(int i = 0; i< noOfMissingSubModls; ++i){
//		if(string(asmPosList[i].name).compare("") != 0)	// check only if name not empty
//		{
//			if(isAsmNameValid(asmPosList[i].name)){		// if valid asm name
//				if(toUpperCase(string(asmPosList[i].name).substr(4,5)).compare(string(asmPosList[i].modAddrs).substr(1)) == 0)
//					status = ProUIPushbuttonEnable(dialog, OK_PB_ASM_TOOL);	// enable only if all entered names are VALID.
//				else
//					enableAsmBtn = false;
//			}
//			else
//				enableAsmBtn = false;
//		}
//	}
//	if(!enableAsmBtn)
//		status = ProUIPushbuttonDisable(dialog, OK_PB_ASM_TOOL);
//
//	return status;
//}
//ProError browse_pb_action(char* dialog, char* component, ProAppData data)
//{
//	mainLog.Write("================================== browse_pb_action ==================================");
//
//	wchar_t *wIpValue, *wModAddrs;
//	char cIpname[PRO_NAME_SIZE], cIpValue[PRO_NAME_SIZE], cModAddrs[PRO_NAME_SIZE];
//
//	getRowNameFromComponent(component, cRowname);
//	ProTKSprintf(cIpname, "asmip_%s", cRowname);
//
//	status = ProUIInputpanelValueGet(dialog, cIpname, &wIpValue);
//	ProWstringToString(cIpValue, wIpValue);
//
//	status = ProUITableCellLabelGet(dialog, TBL_ASM_TOOL, cRowname,  "module_lbl", &wModAddrs);
//	ProWstringToString(cModAddrs,wModAddrs);
//
//	for(int i=0; i< noOfMissingSubModls; ++i)
//	{
//		if(string(cModAddrs).compare(asmPosList[i].modAddrs) == 0)
//		{
//			/*strcpy(asmPosList[i].name, cIpValue);
//			mainLog.Write("asmPosList["+to_string(i)+"].name: " + string(asmPosList[i].name));*/
//			
//			/*// ASSIGN TYPE
//			size_t _pos = string(cIpValue).find_first_of('.');
//			string type = string(cIpValue).substr(_pos+1);
//			if(type.compare("prt") == 0)
//				asmPosList[i].type = PRO_MDLFILE_PART;
//			else if(type.compare("asm") == 0)
//				asmPosList[i].type = PRO_MDLFILE_ASSEMBLY;*/
//
//			// ASSIGN POSITION
//			ProPath wPosFilePath;
//			ProCharPath cPosFilePath;
//			status = ProFileMdlnameOpen(L"Open Position Matrix file", L"*.txt", NULL, NULL, NULL, NULL, wPosFilePath);
//			if (status != PRO_TK_NO_ERROR)
//				return status;
//			ProWstringToString(cPosFilePath, wPosFilePath);
//			mainLog.Write("cPosFilePath: " + string(cPosFilePath));
//
//			double posMatrix[4][4];
//			if(isValidPositionMatrixFile(cPosFilePath, posMatrix))
//			{
//				for (int row = 0; row < 4; ++row)
//					for (int col = 0; col < 4; ++col)
//						asmPosList[i].pos[row][col] = posMatrix[row][col];	// copy it to actual vector
//			}
//			else{
//				_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error!", "Please provide a valid Position Matrix file.");
//				return PRO_TK_GENERAL_ERROR;
//			}
//			/*mainLog.Write("item.modAddrs: " + string(asmPosList[0].modAddrs));
//			mainLog.Write("item.name: " + string(asmPosList[0].name));
//			for (int i = 0; i < 4; ++i) {
//			for (int j = 0; j < 4; ++j) {
//			mainLog.Write("\tpos["+to_string(i)+"]["+to_string(j)+"]=" + to_string(asmPosList[0].pos[i][j]));
//			}
//			}*/
//			status = ProUITableCellLabelSet(DLG_ASM_TOOL, TBL_ASM_TOOL, cRowname, "pos_filepath", wPosFilePath);
//			//mainLog.Write("ProUITableCellLabelSet: " + to_string(status));
//			status = ProUITableCellHelpTextSet(DLG_ASM_TOOL, TBL_ASM_TOOL, cRowname, "pos_filepath", wPosFilePath);
//			//mainLog.Write("ProUITableCellHelpTextSet: " + to_string(status));
//		}
//	}
//	return status;
//}
//ProError browse_asmloc_action(char* dialog, char* component, ProAppData data)
//{
//	mainLog.Write("================================== browse_asmloc_action ==================================");
//
//	status = ProDirectoryChoose(L"Select the source directory", NULL, NULL, NULL, wSrcDir);
//	mainLog.Write("ProDirectoryChoose: " + to_string(status));
//	status = ProUIInputpanelValueSet(dialog, IP_ASMLOC, wSrcDir);
//
//	return PRO_TK_NO_ERROR;
//}

ProError asmToolDlgOKAction(char* dialog, char* component, ProAppData data)
{
	mainLog.Write("================================== asmToolDlgOKAction ==================================");
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}

ProError asmToolDlgCloseAction(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- asmToolDlgCloseAction -----------------------------");

	if(data != NULL){
		bool *quitAction = (bool*)data;
		*quitAction = true;
	}
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}

// SUPPORTING FUNCTIONS
size_t WriteCallback(void* contents, size_t size, size_t nmemb, std::string* output) {
	size_t totalSize = size * nmemb;
	output->append((char*)contents, totalSize);
	return totalSize;
}

std::vector<std::string> extractPLMvalues(const std::string& xml, const std::string& tag) 
{
	mainLog.Write("================================ extractPLMvalues ================================");
	vector<string> prtDetailsValues;
	string startTag = "<" + tag + ">";
	string endTag = "</" + tag + ">";

	size_t startPos = 0;

	while (true) {
		size_t start = xml.find(startTag, startPos);
		size_t end = xml.find(endTag, start);	// it begins the search from where the "start" ends.

		if (start != std::string::npos && end != std::string::npos) {
			start += startTag.length();
			prtDetailsValues.push_back(xml.substr(start, end - start));
			startPos = end + endTag.length(); // Move to the next occurrence
		} else {
			break; // No more occurrences found
		}
	}
	return prtDetailsValues;
}

void getPartNumberAndPosMatrix(vector<string> dataVec, vector<PLM_POS_DATA> &outputData)
{
	mainLog.Write("================================ getPartNumberAndPosMatrix ================================");

	for(int i = 1; i<dataVec.size(); i+=2)
	{
		if(dataVec[i].find("CHILDPARTNUMBER=") != std::string::npos)
		{
			PLM_POS_DATA prtNoMatrixPair;
			prtNoMatrixPair.prtNo = dataVec[i].substr(16);

			string sPosMatrix = dataVec[i+1].substr(11);
			mainLog.Write("prtNo: "+prtNoMatrixPair.prtNo);
			mainLog.Write("sPosMatrix: "+sPosMatrix);

			istringstream issPosMatrix(sPosMatrix);
			string matrixElem;
			//double matrix[4][4];
			int iRow{0}, iCol{0};
			while(getline(issPosMatrix, matrixElem, ' '))
			{
				istringstream issMatrixElem(matrixElem);
				size_t decimalPos = matrixElem.find('.');
				if (decimalPos != string::npos)
				{
					// Calculate the number of characters after the decimal point
					size_t noOfCharsAfterDecimal = matrixElem.length() - decimalPos - 1;
					issMatrixElem >> setprecision(noOfCharsAfterDecimal) >> prtNoMatrixPair.posMatrix[iRow][iCol];
					//mainLog.Write("noOfCharsAfterDecimal = "+to_string(noOfCharsAfterDecimal)+"\tmatrix["+to_string(iRow)+"]["+to_string(iCol)+"]=" );
					//mainLog.WriteDouble(prtNoMatrixPair.posMatrix[iRow][iCol], noOfCharsAfterDecimal);	
				}
				else{
					//mainLog.Write("----------");
					prtNoMatrixPair.posMatrix[iRow][iCol] = atof(matrixElem.c_str());
					//mainLog.Write("matrix["+to_string(iRow)+"]["+to_string(iCol)+"]= " +to_string(prtNoMatrixPair.posMatrix[iRow][iCol]));
				}
				if(iCol==3){
					iCol=0;
					iRow+=1;
				}
				else
					iCol++;
			}
			outputData.push_back(prtNoMatrixPair);
		}
	}
}

void getRowNameFromComponent(char *compName, char *rowName)
{
	mainLog.Write("================================== getRowNameFromComponent ==================================");
	size_t _pos;
	string sCompname = string(compName);
	_pos = sCompname.find_first_of('_');
	string sRowName = sCompname.substr(_pos+1);
	strcpy(rowName, sRowName.c_str());
}

bool isValidPositionMatrixFile(char *filePath, double (&positionMatrix)[4][4])
{
	ifstream posFile(filePath);  // Replace "data.txt" with your file path
	if (!posFile) {
		mainLog.Write("Failed to open position file!");
		return false;
	}
	string fLine;
	int count = 0;
	while (getline(posFile, fLine))
	{
		stringstream ss(fLine);
		string value;
		while(getline(ss, value, ','))
		{
			int iRow=0, iCol=0;
			istringstream iss(value);
			const regex positionValuePattern("[-+]?[0-9]*\\.?[0-9]+");
			if(regex_match(value, positionValuePattern))
			{
				size_t decimalPos = value.find('.');
				if (decimalPos != string::npos) {
					//mainLog.Write("++++++++++");
					// Calculate the number of characters after the decimal point
					size_t noOfCharsAfterDecimal = value.length() - decimalPos - 1;
					iss >> setprecision(noOfCharsAfterDecimal) >> positionMatrix[iRow][iCol];
					mainLog.Write("noOfCharsAfterDecimal = "+to_string(noOfCharsAfterDecimal)+"\tpositionMatrix["+to_string(iRow)+"]["+to_string(iCol)+"]=" );
					mainLog.WriteDouble(positionMatrix[iRow][iCol], noOfCharsAfterDecimal);
				}
				else{
					//mainLog.Write("----------");
					positionMatrix[iRow][iCol] = atof(value.c_str());
					mainLog.Write("positionMatrix["+to_string(iRow)+"]["+to_string(iCol)+"]= " +to_string(positionMatrix[iRow][iCol]));
				}
				iCol++;
				if(iCol==4){
					iCol=0;
					iRow+=1;
				}
				count++;
			}
			else
				return false;
			
		}
	}
	posFile.close();
	return count == 16;  // Return true only if exactly 16 decimal prtDetailsValues found
}

bool isAsmNameValid(string asmname)
{
	const regex subModulePatrn("^[0-9]{4}[a-zA-Z][0-9][a-zA-Z][0-9]{7}$");;
	return (regex_match(asmname, subModulePatrn));
}

bool isMatrixValid(const double matrix[4][4])
{
	for (int row = 0; row < 4; ++row) {
		for (int col = 0; col < 4; ++col) {
			// Check if any element is NaN or infinite
			if (isnan(matrix[row][col]) || isinf(matrix[row][col])) {
				return false;
			}
		}
	}
}

string toUpperCase(string str)
{
	for (auto & c: str) c = toupper(c);
	return str;
}

//ProError asm_mode_rg_action(char* dialog, char* component, ProAppData data)
//{
//	mainLog.Write("================================== asm_mode_rg_action ==================================");
//
//	int n_name;
//	char **rg_names;
//	status = ProUIRadiogroupSelectednamesGet(dialog, RG_ASM_MODE, &n_name, &rg_names);
//	//mainLog.Write("ProUIRadiogroupSelectednamesGet: " + to_string(status));
//
//	if(strcmp(rg_names[0], "new_asm") == 0){
//		_appMode = NEW_ASM;
//		status = ProUIInputpanelEnable(dialog, IP_NEW_ASM_NAME);
//
//		status = ProUIInputpanelValueSet(dialog, IP_NEW_ASM_NAME, wNewAsmName);
//		mainLog.Write("ProUIInputpanelValueSet  : " + to_string(status));
//
//		status = ProUIInputpanelReadOnly(dialog, IP_NEW_ASM_NAME);
//	}
//	else if(strcmp(rg_names[0], "exist_asm") == 0){
//		_appMode = EXIST_ASM;
//		status = ProUIInputpanelValueSet(dialog, IP_NEW_ASM_NAME, L"");
//		status = ProUIInputpanelDisable(dialog, IP_NEW_ASM_NAME);
//	}
//	return status;
//}
//void setOptionMenu(char *optMenuName, vector<pair<int, string>> &reqAsmNames)
//{
//	char** optMenuMdlNames;
//	wchar_t** optMenuMdlLabels;
//	status = ProArrayAlloc(reqAsmNames.size()+1, sizeof(char*), 1, (ProArray*)&optMenuMdlNames);
//	status = ProArrayAlloc(reqAsmNames.size()+1, sizeof(wchar_t*), 1, (ProArray*)&optMenuMdlLabels);
//
//	optMenuMdlNames[0] = (char*)calloc(PRO_NAME_SIZE, sizeof(char));
//	optMenuMdlLabels[0] = (wchar_t*)calloc(PRO_NAME_SIZE, sizeof(wchar_t));
//	strcpy(optMenuMdlNames[0], "empty");
//	wcscpy(optMenuMdlLabels[0], L"");
//	for (int i = 0; i < reqAsmNames.size(); ++i){
//		optMenuMdlNames[i+1] = (char*)calloc(PRO_NAME_SIZE, sizeof(char));
//		optMenuMdlLabels[i+1] = (wchar_t*)calloc(PRO_NAME_SIZE, sizeof(wchar_t));
//
//		ProTKSprintf(optMenuMdlNames[i+1], "%s", reqAsmNames[i].second);
//		ProStringToWstring(optMenuMdlLabels[i+1], optMenuMdlNames[i+1]);
//	}
//	status = ProUIOptionmenuNamesSet(DLG_ASM_TOOL, optMenuName, int(reqAsmNames.size()+1), optMenuMdlNames);
//	mainLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
//	status = ProUIOptionmenuLabelsSet(DLG_ASM_TOOL, optMenuName, int(reqAsmNames.size()+1), optMenuMdlLabels);
//	mainLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));
//
//	status = ProArrayFree((ProArray*)&optMenuMdlNames);
//	status = ProArrayFree((ProArray*)&optMenuMdlLabels);
//}
//ProError missingModlOptMenuSelectAction(char* dialog, char* component, ProAppData data)
//{
//	mainLog.Write("================================== missingModlOptMenuSelectAction ==================================");
//	size_t _pos;
//	string sCompname = string(component);
//	_pos = sCompname.find_first_of('_');
//	string sRowName = sCompname.substr(_pos+1);
//	char cPbName[PRO_NAME_SIZE];
//	ProTKSprintf(cPbName, "browsepb_%s", sRowName.c_str());
//
//	int nSels;
//	char **sels;
//	status = ProUIOptionmenuSelectednamesGet(dialog, component, &nSels, &sels);
//	if(strcmp(sels[0], "empty") != 0)
//		status = ProUIPushbuttonEnable(dialog, cPbName);
//	else
//		status = ProUIPushbuttonDisable(dialog, cPbName);
//
//	return status;
//}

#pragma pop