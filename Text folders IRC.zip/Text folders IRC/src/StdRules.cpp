/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-03-2023	|	V1_0_0		| PHASE 1 RULES VALIDATION
==================================================================================================================*/

#include "StdRules.h"

//============================================== CONSTRUCTOR ==============================================
//StdRules::StdRules()
//{
//	status = ProMdlCurrentGet(&curMdl);
//	status = ProMdlNameGet(curMdl, wCurMdlName);
//	ProWstringToString(cCurMdlName, wCurMdlName);
//
//	// DB FILES FOLDER LOCATION
//	strcpy(cRuleDbPath, "C:\\PTC\\Creo7.0.2.0\\telco_standards\\InterfaceRulesCheck\\rules_db\\");
//}
//
///*==================================================================================================================
//IRF1B01001		| 5TH WHEEL COUPLING	| The coupling should be chosen wrt load requirements of the vehicle
//===================================================================================================================*/
//int StdRules::IRF1B01001(ruleResult &final_res)
//{
//	ruleLog.Write("==========================   IRF1B01001   ==========================");
//
//	IRF1B01 IRF1B01_001;
//	int loadCapacity; // in TONS
//	vector<string> compNamesList;
//
//	//parse the text db file and extract the values
//	vector<CouplingsForLoadCapacity> CouplingsList;
//	vector<vector<string>> dbList2D;
//	sprintf(db_path, "%s%s",cRuleDbPath, "IRF1B01001.txt");
//	FileParser _csvReader(db_path, "\t");
//	_csvReader.getData2D(dbList2D, '\t');
//
//	for(int i = 1; i< dbList2D.size(); ++i)	// i = 1 for skipping the headers
//	{
//		string tok1;
//		std::istringstream ss1(dbList2D[i][0]);
//		while (std::getline(ss1, tok1, ',')) 
//		{
//			CouplingsForLoadCapacity _temp;
//
//			// load capacity
//			_temp.loadCapacity = stoi(tok1);		
//		
//			// assigned part numbers
//			std::istringstream ss2(dbList2D[i][1]);
//			string tok2;
//			while (std::getline(ss2, tok2, ',')) {
//				_temp.couplingPartNos.push_back(tok2);
//			}
//			CouplingsList.push_back(_temp);
//		}
//	}
//
//	// get the req. values from CAD
//	int sts = IRF1B01_001.IRF1B01001_getCouplingType(CouplingsList, loadCapacity, compNamesList);
//	if(sts != 0 || loadCapacity == -1)
//		return sts;
//
//	for(auto item : CouplingsList)
//	{
//		if(item.loadCapacity == loadCapacity)
//		{
//			string coupling_name;
//			bool couplingFound = false;
//
//			ruleLog.Write("Std. Couplings:");
//			for (auto comp_name : item.couplingPartNos)
//			{
//				ruleLog.Write("\t"+comp_name);
//
//				// remarks (acceptance criteria)
//				acceptance_criteria.append(comp_name + ".asm, ");
//
//				// check if the coupling is present in the model or not.
//				for (int i = 0; i< compNamesList.size(); ++i){
//					if(compNamesList[i].compare(comp_name) == 0){
//						couplingFound = true;
//						coupling_name += comp_name + ".asm ";
//						//break;
//					}
//				}
//			}
//
//			// DECLARE RESULT
//			if(!couplingFound){
//				final_res.result = "FAIL";
//				sprintf(remark, "The Std. Couplings are not present; Acceptance criteria: %s", acceptance_criteria.c_str());
//			}
//			else{
//				final_res.result = "PASS";
//				sprintf(remark, "Found Coupling no. = %s; Acceptance criteria: %s", coupling_name.c_str(), acceptance_criteria.c_str());
//			}
//			final_res.remark = string(remark);
//
//			ruleLog.Write("final_res.status: "+string(final_res.result));
//			ruleLog.Write("final_res.remark: "+string(final_res.remark));
//
//			break;
//		}
//	}
//	return 0;
//}
//
///*==================================================================================================================
// IRA1B01005		| CARGO BODY	| Optimize the overall width of loadbodies to control the variants 
//===================================================================================================================*/
//int StdRules:: IRA1B01005(ruleResult &final_res)
//{
//	ruleLog.Write("==========================  IRA1B01005  ==========================");
//	IRA1B01 IRA1B01_005;
//	double cargobodyWidth;
//	vector<int> clearanceVals;	
//	enum Cols {VEHICLE_CATEGORY, TYPE, PROJECT_CODE, CLEARANCE_VALS};
//
//	// get req. data from CAD
//	IRA1B01_005.IRA1B01005_getCargobodyWidth(cargobodyWidth, subModuleName);
//	ruleLog.Write("cargobodyWidth: "+to_string(cargobodyWidth));
//	
//	int projectCode = stoi(string(subModuleName).substr(0,4));
//	ruleLog.Write("Project Code: "+ to_string(projectCode));
//
//	vector<string> csvData;
//	sprintf(db_path, "%s%s",cRuleDbPath,"IRA1B01005.csv");
//	FileParser _csvReader(db_path, ",");
//	csvData = _csvReader.getData(',');
//	int colIndex = 0;
//
//	// fetch the clearance values for opened asm
//	for(int i = 9; i< csvData.size(); ++i)	//i =4 to skip the columns
//	{
//		switch(colIndex)
//		{
//		case PROJECT_CODE:
//			if(projectCode == stoi(csvData[i]))
//			{
//				//ruleLog.Write(" csvData["+to_string(i)+"] = "+ csvData[i]);
//				i+=1;
//				while(strcmp(csvData[i].c_str(), "#end") != 0){
//					if(strcmp(csvData[i].c_str(), "") != 0)
//						clearanceVals.push_back(stoi(csvData[i]));
//					i++;
//				}
//				break;	// break out of for loop
//			}
//			break;
//		default:
//			break;
//		}
//		colIndex++;
//
//		if (strcmp(csvData[i].c_str(), "#end") == 0) 
//			colIndex = 0;
//	}
//
//	bool isRightClearance = false;
//	string acceptance_criteria;
//	for (auto val: clearanceVals)
//	{
//		acceptance_criteria.append(to_string(val) + "mm, ");
//		if(int(cargobodyWidth) == val){
//			isRightClearance = true;
//		}
//	}
//
//	sprintf(remark, "Measured value = %dmm; Acceptance criteria = %s.", int(cargobodyWidth), acceptance_criteria.c_str());
//
//	// DECLARE RESULT
//	if(isRightClearance)
//		final_res.result = "PASS";
//	else
//		final_res.result = "FAIL";
//	
//	final_res.remark = string(remark);
//
//	ruleLog.Write("final_res.status: "+string(final_res.result));
//	ruleLog.Write("final_res.remark: "+string(final_res.remark));
//
//	return 0;
//}
//
///*==================================================================================================================
//IR-A1A01-006		| TIPPER BODY	| Platform wise common frame width to be ensured. 
//===================================================================================================================*/
//int StdRules:: IRA1A01006(ruleResult &final_res){
//	ruleLog.Write("==========================   IRA1A01006   ==========================");
//	double platformWidth;
//	IRA1A01 IRA1A01_006;
//	IRA1A01_006.IRA1A01006_getPlatformWidth(platformWidth, subModuleName);
//	ruleLog.Write("platformWidth: "+to_string(platformWidth));
//
//	vector<string> csvData;
//	strcpy(db_path, cRuleDbPath);
//	strcat(db_path, "IRA1A01006.csv");
//	FileParser _csvReader(db_path, ",");
//	csvData = _csvReader.getData(',');
//	int colIndex = 0;
//
//	enum Cols {VEHICLE_CATEGORY, TYPE, PROJECT_CODE, CLEARANCE_VALS};
//
//	int projectCode = stoi(string(subModuleName).substr(0,4));
//	ruleLog.Write("projectCode: "+ to_string(projectCode));
//
//	vector<int> clearanceVals;
//
//	for(int i = 9; i< csvData.size(); ++i)	//i =4 to skip the columns
//	{
//		switch(colIndex)
//		{
//		case PROJECT_CODE:
//			if(projectCode == stoi(csvData[i]))
//			{
//				ruleLog.Write(" csvData["+to_string(i)+"] = "+ csvData[i]);
//				i+=1;
//				while(strcmp(csvData[i].c_str(), "#end") != 0){
//					if(strcmp(csvData[i].c_str(), "") != 0)
//						clearanceVals.push_back(stoi(csvData[i]));
//					i++;
//				}
//				break;	// break out of for loop
//			}
//			break;
//		default:
//			break;
//		}
//		colIndex++;
//
//		if (strcmp(csvData[i].c_str(), "#end") == 0) 
//			colIndex = 0;
//	}
//	bool isRightClearance = false;
//
//	string acceptance_criteria;
//	for (auto val: clearanceVals)
//	{
//		acceptance_criteria.append(to_string(val));
//		acceptance_criteria.append("mm, ");
//
//		if(val == int(platformWidth)){
//			ruleLog.Write("PASS");
//			isRightClearance = true;
//		}
//	}
//
//	sprintf(remark, "Measured value = %dmm; Acceptance criteria = %s.", int(platformWidth), acceptance_criteria.c_str());
//	ruleLog.Write("remark: "+string(remark));
//	final_res.remark = string(remark);
//
//	// DECLARE RESULT
//	if(isRightClearance){
//		final_res.result = "PASS";
//	}
//	else{
//		final_res.result = "FAIL";
//	}
//
//	return 0;
//}
//
///*==================================================================================================================
//IR-A1A01-007		| TIPPER BODY	| Common ROH across tipper platform to be ensured.
//===================================================================================================================*/
//int StdRules:: IRA1A01007(ruleResult &final_res)
//{
//	ruleLog.Write("==========================   IRA1A01007   ==========================");
//	double ROHvalue;
//	IRA1A01 IRA1A01_007;
//	IRA1A01_007.IRA1A01007_getROH(ROHvalue, subModuleName);
//	ruleLog.Write("ROHvalue: "+to_string(ROHvalue));
//
//	vector<string> csvData;
//	strcpy(db_path, cRuleDbPath);
//	strcat(db_path, "IRA1A01007.csv");
//	FileParser _csvReader(db_path, ",");
//	csvData = _csvReader.getData(',');
//	int colIndex = 0;
//
//	enum Cols {VEHICLE_CATEGORY, TYPE, PROJECT_CODE, CLEARANCE_VALS};
//
//	int projectCode = stoi(string(subModuleName).substr(0,4));
//	ruleLog.Write("projectCode: "+ to_string(projectCode));
//
//	vector<int> clearanceVals;
//
//	for(int i = 9; i< csvData.size(); ++i)	//i =4 to skip the columns
//	{
//		switch(colIndex)
//		{
//		case PROJECT_CODE:
//			if(projectCode == stoi(csvData[i]))
//			{
//				ruleLog.Write(" csvData["+to_string(i)+"] = "+ csvData[i]);
//				i+=1;
//				while(strcmp(csvData[i].c_str(), "#end") != 0){
//					if(strcmp(csvData[i].c_str(), "") != 0)
//						clearanceVals.push_back(stoi(csvData[i]));
//					i++;
//				}
//				break;	// break out of for loop
//			}
//			break;
//		default:
//			break;
//		}
//		colIndex++;
//
//		if (strcmp(csvData[i].c_str(), "#end") == 0) 
//			colIndex = 0;
//	}
//	bool isRightClearance = false;
//
//	string acceptance_criteria;
//	for (auto val: clearanceVals)
//	{
//		acceptance_criteria.append(to_string(val));
//		acceptance_criteria.append("mm, ");
//
//		if(val == int(ROHvalue)){
//			ruleLog.Write("PASS");
//			isRightClearance = true;
//		}
//	}
//
//	sprintf(remark, "Measured value = %dmm; Acceptance criteria = 80mm.", int(ROHvalue));
//	ruleLog.Write("remark: "+string(remark));
//	final_res.remark = string(remark);
//
//	// DECLARE RESULT
//	if(isRightClearance){
//		final_res.result = "PASS";
//	}
//	else{
//		final_res.result = "FAIL";
//	}
//
//	return 0;
//}
//
///*==================================================================================================================
//IR-F5A17-001		| BRAKING SYSTEM	| Air processing unit clearance with the Exhaust System to be defined.
//===================================================================================================================*/
//int StdRules:: IRF5A17001(ruleResult &final_res)
//{
//	string compNames[4]{};
//	IRF5A17 IRF5A17_001;
//	double clearance_vals[3]{};
//	IRF5A17_001.IRF5A17001_getClearance(clearance_vals, compNames);
//
//	bool clearanceCheck = true;
//	for(auto clear_val : clearance_vals)
//	{
//		acceptance_criteria.append(to_string((int(clear_val))));
//		acceptance_criteria.append("mm, ");
//		if(clear_val < 120)
//			clearanceCheck = false;
//	}
//
//	sprintf(remark, "Measured values = %s; Acceptance criteria: >=120mm.", acceptance_criteria.c_str());
//	ruleLog.Write("remark: "+string(remark));
//	final_res.remark = string(remark);
//
//	// DECLARE RESULT
//	if(clearanceCheck){
//		final_res.result = "PASS";
//	}
//	else{
//		final_res.result = "FAIL";
//	}
//
//	return 0;
//}
//
///*==================================================================================================================
//IRF5A20001		| BRAKING SYSTEM	| Pipe connector selection to be done to avoid flow restriction and pressure drop.
//===================================================================================================================*/
//int StdRules::IRF5A20001(ruleResult &final_res)
//{
//	ruleLog.Write("==========================   IRF5A20001   ==========================");
//	vector<connector_in_model> connectorsList;
//	IRF5A20001_checkPipeConnector(connectorsList);
//
//	// DECLARE RESULT
//	if(connectorsList.size()>0)
//	{
//		final_res.result = "FAIL";
//		ProCharPath errMsg;
//		strcpy(errMsg, "Replace ");
//		for(auto connector : connectorsList)
//		{
//			strcat(errMsg, connector.elbo_connector);
//			strcat(errMsg, " with ");
//			strcat(errMsg, connector.straight_connector);
//			strcat(errMsg, ", ");
//		}
//		ruleLog.Write("errMsg: "+string(errMsg));
//		final_res.remark = string(errMsg);
//	}
//	else
//	{
//		final_res.result = "PASS";
//		ProCharPath errMsg;
//		strcpy(errMsg, "No Elbow connectors found. Acceptence criteria: Avoid elbow connectors to avoid flow restriction and pressure drop.");
//		ruleLog.Write("errMsg: "+string(errMsg));
//		final_res.remark = string(errMsg);
//	}
//	return 0;
//}
//
///*==================================================================================================================
//IRF5A08005		| BRAKING SYSTEM	| Clearance of brake valve & steering system to be defined.
//===================================================================================================================*/
//int StdRules:: IRF5A08005(ruleResult &final_res){
//	ruleLog.Write("==========================   IRF5A08005   ==========================");
//	IRF5A08 IRF5A08_005;
//	double clearance;
//	string compNames[2];
//	IRF5A08_005.IRF5A08005_getClearance(clearance, compNames);
//
//	sprintf(remark, "Measured value = %dmm; Acceptance criteria: >50mm.", int(clearance));
//	ruleLog.Write("remark: "+string(remark));
//	final_res.remark = string(remark);
//
//	// DECLARE RESULT
//	if(clearance > 50.0){
//		final_res.result = "PASS";
//	}
//	else{
//		final_res.result = "FAIL";
//	}
//
//	return 0;
//}
//
///*==================================================================================================================
//IRF5A27004		| BRAKING SYSTEM	| Vacuum tank mounting bracket holes and pitch (vertical & horizontal) to be defined.
//===================================================================================================================*/
//int StdRules:: IRF5A27004(ruleResult &final_res)
//{
//	ruleLog.Write("==========================   IRF5A27004   ==========================");
//	vector<double> pitches;
//	double diameter;
//	bool is_pitch_n_dia_eql = false;
//	IRF5A27 IRF5A27_004;
//	int sts = IRF5A27_004.IRF5A27004_getVacuumtankHolesData(diameter, pitches);
//
//	pitches.erase(std::unique(pitches.begin(), pitches.end()), pitches.end());
//	ruleLog.Write("diameter = "+to_string(diameter));
//	for(auto pitch : pitches)
//		acceptance_criteria.append(to_string(int(pitch)) + "mm; ");
//
//	if(sts == -1)	// USER ABORTS
//		return sts;
//
//	if(sts == -2)	// INVALID INPUTS
//	{
//		final_res.result = "FAIL";
//		sprintf(remark, "Pease enter valid inputs. Refer help document for details.");
//		final_res.remark = string(remark);
//
//		ruleLog.Write("final_res.status: "+string(final_res.result));
//		ruleLog.Write("final_res.remark: "+string(final_res.remark));
//
//		return sts;
//	}
//	if(sts == -2)	// INVALID DIAMETERS
//	{
//		final_res.result = "FAIL";
//		sprintf(remark, "The diameter of the holes are mismatching. Refer help document for details.");
//		final_res.remark = string(remark);
//
//		ruleLog.Write("final_res.status: "+string(final_res.result));
//		ruleLog.Write("final_res.remark: "+string(final_res.remark));
//
//		return 0;
//	}
//
//	vector<vector<string>> csvData2D;
//	strcpy(db_path, cRuleDbPath);
//	strcat(db_path, "IRF5A27004.csv");
//	FileParser ruleDbReader(db_path, ",");
//	ruleDbReader.getData2D(csvData2D, ',');
//	string accptnce_criteria;
//
//	for(int i = 1; i< csvData2D.size(); ++i)	// i = 1 for skipping the headers
//	{
//		string NoOfHoles, HoleDia, xVal, yVal;
//		/*std::istringstream ss1(csvData2D[i][0]);
//		while (std::getline(ss1, NoOfHoles, ',')) 
//		{
//			ruleLog.Write("NoOfHoles "+NoOfHoles);
//		}*/
//
//		accptnce_criteria.append("[" +csvData2D[i][1]+ "; "+ csvData2D[i][2]+"x"+csvData2D[i][3]+"], ");
//
//		std::istringstream ss2(csvData2D[i][1]);
//		while (std::getline(ss2, HoleDia, ',')) {
//			ruleLog.Write("HoleDia "+HoleDia);
//			if(int(diameter) == stoi(HoleDia.substr(1)))
//			{
//				std::istringstream ss3(csvData2D[i][2]);
//				while (std::getline(ss3, xVal, ','))
//				{
//					for(int j = 0; j<pitches.size(); ++j)
//					{
//						if(int(pitches[j]) == stoi(xVal))
//						{
//							ruleLog.Write("i: "+ to_string(i) + "\txVal :"+xVal);
//							std::istringstream ss4(csvData2D[i][3]);
//							while (std::getline(ss4, yVal, ',')) {
//								for(int k = 0; k<pitches.size(); ++k)
//								{
//									if(int(pitches[k]) == stoi(yVal))
//									{
//										ruleLog.Write("yVal "+yVal);
//										is_pitch_n_dia_eql = true;
//									}
//								}
//							}
//						}
//					
//					}
//				}
//			}
//		}
//		//ruleLog.Write("xxxxxxxx for loop ends");
//	}
//
//	ruleLog.Write("Acceptance Criteria: "+ accptnce_criteria);
//
//	// DECLARE RESULT
//	if(sts == -3)	// INVALID PITCHES
//	{
//		final_res.result = "FAIL";
//		sprintf(remark, "The pitch values %s are mismatching. Acceptance criteria: %s", acceptance_criteria.c_str(), accptnce_criteria.c_str());
//		final_res.remark = string(remark);
//
//		ruleLog.Write("final_res.status: "+string(final_res.result));
//		ruleLog.Write("final_res.remark: "+string(final_res.remark));
//
//		return 0;
//	}
//
//	if(!is_pitch_n_dia_eql){
//		final_res.result = "FAIL";
//		sprintf(remark, "The pitch values %s and diameter %dmm are not according to standards. Acceptance criteria: %s", acceptance_criteria.c_str(), int(diameter), accptnce_criteria.c_str());
//	}
//	else{
//		final_res.result = "PASS";
//		sprintf(remark, "The pitch values %s and diameter %dmm are according to standards. Acceptance criteria: %s", acceptance_criteria.c_str(), int(diameter), accptnce_criteria.c_str());
//	}
//	final_res.remark = string(remark);
//
//	ruleLog.Write("final_res.status: "+string(final_res.result));
//	ruleLog.Write("final_res.remark: "+string(final_res.remark));
//
//	return 0;
//}
//
///*==================================================================================================================
//IRF1E08007		| CHASSIS CONTROLS	| Clearance of 50-70mm should be maintained between brake pedal and accelerator pedal assembly 
//===================================================================================================================*/
//int StdRules:: IRF1E08007(ruleResult &final_res){
//
//	IRF1E08 IRF1E08_007;
//	double clearance;
//	string compNames[2];
//	IRF1E08_007.IRF1E08007_getClearance(clearance, compNames);
//
//	sprintf(remark, "Measured value = %dmm; Acceptance criteria: 50-70mm.", int(clearance));
//	ruleLog.Write("remark: "+string(remark));
//	final_res.remark = string(remark);
//
//	// DECLARE RESULT
//	if(clearance > 50.0){
//		final_res.result = "PASS";
//	}
//	else{
//		final_res.result = "FAIL";
//	}
//	return 0;
//}
//
///*==================================================================================================================
//IRF5B01002		| WHEELS AND TYRES		| Clearance between of grown tire/wheel rim and brake chamber should be minimum 20**mm. 
//===================================================================================================================*/
//int StdRules:: IRF5B01002(ruleResult &final_res){
//	return 0;
//}
//
///*==================================================================================================================
//IRF2A02003		| FRONT AXLE/LIFT AXLE		| Ensure clearance between Stub Axle and Brake disc. 
//===================================================================================================================*/
//int StdRules:: IRF2A02003(ruleResult &final_res){
//	return 0;
//}
//
///*==================================================================================================================
//IRF2A02004		| FRONT AXLE/LIFT AXLE		| Ensure clearance between Stub Axle and Brake Caliper.
//===================================================================================================================*/
//int StdRules:: IRF2A02004(ruleResult &final_res){
//	return 0;
//}
//
///*================================================================================================================================
//IRF3B01002		| EXHAUST SYSTEM	| Commonise Position of Silencer from FACL across platforms to reduce number of Exhaust Pipes.
//=================================================================================================================================*/
//int StdRules:: IRF3B01002(ruleResult &final_res){
//	return 0;
//}
//
///*=======================================================================================================================================
//IRF4A02001		| FRONT SUSPENSION	| Standard leaf spring type across platform based on application.  E.g.parabolic, semielliptical etc. 
//========================================================================================================================================*/
//int StdRules:: IRF4A02001(ruleResult &final_res){
//	return 0;
//}
//
///*==================================================================================================================
//IRF4B02003		| REAR SUSPENSION	| Standard leaf width across platform based on application. 
//===================================================================================================================*/
//
//ProError UserDisplayPopupError()
//{
//	ProUIMessageButton* buttons;
//	ProUIMessageButton user_choice;
//
//	/*--------------------------------------------------------------------*\
//	Setup array of choices to display in the popup dialog.
//	\*--------------------------------------------------------------------*/
//	ProArrayAlloc(1, sizeof(ProUIMessageButton),
//		1, (ProArray*)&buttons);
//
//	buttons[0] = PRO_UI_MESSAGE_OK;
//
//	ProUIMessageDialogDisplay(PROUIMESSAGE_QUESTION, L"ERROR", L"Please Select 2 Curved Surfaces",buttons,PRO_UI_MESSAGE_OK,&user_choice);
//
//	ProArrayFree((ProArray*)&buttons);
//
//	return PRO_TK_NO_ERROR;
//}
//
//int StdRules:: IRF4B02003(ruleResult &final_res)
//{
//	IRF4B02 IRF4B02_003;
//	double leaf_width;
//	status = ProUIDialogHide(DLG_IRC_MAIN);
//	int sts = IRF4B02_003.IRF4B02003_getLeafWidth(leaf_width);
//	status = ProUIDialogShow(DLG_IRC_MAIN);
//
//
//	//if(sts == -1)	// USER ABORTS
//	//	return sts;
//
//	//if(sts == -2)	// INVALID INPUTS
//	//{
//	//	final_res.result = "FAIL";
//	//	sprintf(remark, "Pease enter valid inputs. Refer help document for details.");
//	//	final_res.remark = string(remark);
//
//	//	ruleLog.Write("final_res.status: "+string(final_res.result));
//	//	ruleLog.Write("final_res.remark: "+string(final_res.remark));
//
//	//	return sts;
//	//}
//
//	sprintf(remark, "Measured value = %dmm; Acceptance criteria: 80mm.", int(leaf_width));
//	ruleLog.Write("remark: "+string(remark));
//	final_res.remark = string(remark);
//
//	// DECLARE RESULT
//	if(leaf_width >= 80.0){
//		final_res.result = "PASS";
//	}
//	else{
//		final_res.result = "FAIL";
//	}
//
//	return 0;
//}

#pragma (pop)