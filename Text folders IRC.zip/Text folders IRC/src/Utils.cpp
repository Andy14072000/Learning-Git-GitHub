/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 15-06-2023	|	V1_0_0		| UTILITY LIBRARY
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

#include "DPDSCreoIRCApplication.h"
#include "Utils.h"

// UTILITY VARIABLES FOR GLOBAL ACCESS
ProMdl curMdl;
ProModelitem curMdlitem;
ProCharName cCurMdlName;
ProName wCurMdlName;
ProCharPath cCurMdlPath{}, cRulesDbPath{}, databasePath{};
ProPath wCurMdlPath;
ProAsmcomppath curAsmCompPath;
int	dialog_sts;
ProPath message;
ProUIMessageButton* msg_buttons;
ProUIMessageButton 	user_choice;
char cTextPath[PRO_PATH_SIZE];
wchar_t wTextPath[PRO_NAME_SIZE];
char cCurDirPath[PRO_PATH_SIZE];
wchar_t wCurDirPath[PRO_PATH_SIZE];
ProMatrix identity_matrix = {{ 1.0, 0.0, 0.0, 0.0 }, 
	{0.0, 1.0, 0.0, 0.0}, 
	{0.0, 0.0, 1.0, 0.0}, 
	{0.0, 0.0, 0.0, 1.0}};

namespace fs = std::filesystem;

void Utils::UserDisplayPopupMessageOK(ProUIMessageType msg_type, string title, string message)
{
	mainLog.Write("================= Utils::UserDisplayPopupMessageOK ==================");
	ProUIMessageButton* button;
	ProUIMessageButton user_choice;

	ProArrayAlloc(1, sizeof(ProUIMessageButton),1, (ProArray*)&button);
	button[0] = PRO_UI_MESSAGE_OK;

	wchar_t wTitle[PRO_NAME_SIZE], wMsg[PRO_PATH_SIZE];
	char cTitle[PRO_NAME_SIZE], cMsg[PRO_PATH_SIZE];
	strcpy(cTitle, title.c_str());
	strcpy(cMsg, message.c_str());
	ProStringToWstring(wTitle, cTitle);
	ProStringToWstring(wMsg, cMsg);

	status = ProUIMessageDialogDisplay(msg_type,wTitle, wMsg, button ,PRO_UI_MESSAGE_OK, &user_choice);
	mainLog.Write("ProUIMessageDialogDisplay: "+to_string(status));

	ProArrayFree((ProArray*)&button);
}

ProUIMessageButton Utils::UserDisplayPopupMessage_OK_CANCEL(ProUIMessageType msg_type, string title, string message)
{
	mainLog.Write("================= Utils::UserDisplayPopupMessageUserChoice ==================");
	ProUIMessageButton* buttons;
	ProUIMessageButton user_choice;

	ProArrayAlloc(2, sizeof(ProUIMessageButton),1, (ProArray*)&buttons);
	buttons[0] = PRO_UI_MESSAGE_OK;
	buttons[1] = PRO_UI_MESSAGE_CANCEL;

	wchar_t wTitle[PRO_NAME_SIZE], wMsg[PRO_PATH_SIZE];
	char cTitle[PRO_NAME_SIZE], cMsg[PRO_PATH_SIZE];
	strcpy(cTitle, title.c_str());
	strcpy(cMsg, message.c_str());
	ProStringToWstring(wTitle, cTitle);
	ProStringToWstring(wMsg, cMsg);

	status = ProUIMessageDialogDisplay(msg_type, wTitle, wMsg, buttons, buttons[0], &user_choice);
	mainLog.Write("ProUIMessageDialogDisplay: "+to_string(status));

	ProArrayFree((ProArray*)&buttons);

	return user_choice;
}

ProUIMessageButton Utils::UserDisplayPopupMessageUserChoice(ProUIMessageType msg_type, string title, string message, ProUIMessageButton* buttons)
{
	mainLog.Write("================= Utils::UserDisplayPopupMessageUserChoice ==================");
	ProUIMessageButton user_choice;
	wchar_t wTitle[PRO_NAME_SIZE], wMsg[PRO_PATH_SIZE];
	char cTitle[PRO_NAME_SIZE], cMsg[PRO_PATH_SIZE];
	strcpy(cTitle, title.c_str());
	strcpy(cMsg, message.c_str());
	ProStringToWstring(wTitle, cTitle);
	ProStringToWstring(wMsg, cMsg);

	status = ProUIMessageDialogDisplay(msg_type, wTitle, wMsg, buttons, buttons[0], &user_choice);
	mainLog.Write("ProUIMessageDialogDisplay: "+to_string(status));

	return user_choice;
}

bool Utils::compareFloat(double x, double y) 
{
	mainLog.Write("================= Utils::compareFloat ==================");
	double epsilon = 0.0000001;
	if (fabs(x - y) < epsilon)
		return true; //they are same
	return false; //they are not same
}

vector<string> Utils::getData1D(char *file_name)
{
	mainLog.Write("================= Utils::getData1D ==================");
	sprintf(databasePath, "%s%s",cRulesDbPath, file_name);
	mainLog.Write("databasePath: "+string(databasePath));
	vector<string> vec1D;
	FileParser _csvReader(databasePath, ',');
	_csvReader.getData(vec1D);

	return vec1D;
}

vector<vector<string>> Utils::getData2D(char *file_name)
{
	mainLog.Write("================= Utils::getData2D ==================");
	sprintf(databasePath, "%s%s",cRulesDbPath, file_name);
	vector<vector<string>> vec2D;
	FileParser _csvReader(databasePath, ',');
	_csvReader.getData2D(vec2D);

	return vec2D;
}

//void Utils::getReqValsFrom2DCsvData(char *csvFileName, int projCodeIdx, int reqValIdx, int projCode, vector<int> &reqValsFromCsv)
//{
//	mainLog.Write("================= Utils::getReqValsFrom2DCsvData ==================");
//	vector<vector<string>> csvData2D = getData2D(csvFileName);
//	for(int i = 1; i< csvData2D.size(); ++i)	// i = 1 for skipping the headers
//	{
//		if(stoi(csvData2D[i][projCodeIdx]) == projCode)
//		{
//			string tok1;
//			std::istringstream ss1(csvData2D[i][reqValIdx]);
//			while (std::getline(ss1, tok1, ';')) {
//				reqValsFromCsv.push_back(stoi(tok1));
//			}
//			break;
//		}
//	}
//	csvData2D.clear();
//}
void Utils::getReqValsFrom2DCsvData(char *csvFileName, int projCodeIdx, int reqValIdx, int projCode, vector<string> &reqValsFromCsv)
{
	mainLog.Write("================= Utils::getReqValsFrom2DCsvData ==================");
	vector<vector<string>> csvData2D = getData2D(csvFileName);
	for(int i = 1; i< csvData2D.size(); ++i)	// i = 1 for skipping the headers
	{
		if(stoi(csvData2D[i][projCodeIdx]) == projCode)
		{
			string tok1;
			std::istringstream ss1(csvData2D[i][reqValIdx]);
			while (std::getline(ss1, tok1, ';')) {
				reqValsFromCsv.push_back(tok1);
			}
			break;
		}
	}
	csvData2D.clear();
}

void Utils::_getReqValsFrom2DCsvData_F3A01(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv) {
	mainLog.Write("================= Utils::_getReqValsFrom2DCsvData ==================");
	vector<vector<string>> csvData2D = getData2D(csvFilename);
	for (int i = 1; i < csvData2D.size(); i++) {
		if (csvData2D[i][partNoIdx].compare(partNo) == 0)
		{
			string tok1;
			std::istringstream ss1(csvData2D[i][reqValIdx]);
			while (std::getline(ss1, tok1, ';')) {
				reqValsFromCsv.push_back(tok1);
			}
			break;
		}
	}
	csvData2D.clear();
}

int Utils::getParamValue(ProModelitem mdl_item, char* paramName)
{
	mainLog.Write("================= Utils::getParamValue ==================");
	ProParameter paramDesc;
	status = ProParameterInit(&mdl_item, L"PRO_MP_VOLUME", &paramDesc);
	mainLog.Write("ProParameterInit: " + to_string(status));
	ProParamvalue paramvalDesc;
	ProUnititem paramunitDesc;
	status = ProParameterValueWithUnitsGet(&paramDesc, &paramvalDesc, &paramunitDesc);
	mainLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));
	mainLog.Write("paramvalDesc: " + to_string(paramvalDesc.value.d_val));

	return 0;
}

void Utils::copyDirectory(const char* source, const char* destination)
{
	mainLog.Write("================================ Utils::copyDirectory ================================");
	const fs::path& source_path(source);
	const fs::path& destination_path(destination);
	mainLog.Write("source: "+string(source) + "\tdestination: "+ string(destination));

	// Create the destination directory if it does not exist
	if (!fs::exists(destination))
		fs::create_directory(destination);

	// Iterate through the files in the source directory
	for (const auto& entry : fs::directory_iterator(source_path))
	{
		const auto& _path = entry.path();
		const auto& filename = _path.filename();
		const auto& destination_file = destination_path / filename;
		fs::copy_file(_path, destination_file, fs::copy_options::skip_existing);

		//// If the file is a directory, recursively copy it
		//if (fs::is_directory(path))
		//{
		//	copyDirectory(path, destination_file);
		//}
		//// Otherwise, copy the file
		//else if (fs::is_regular_file(path))
		//{
		//	fs::copy_file(path, destination_file, fs::copy_options::overwrite_existing);
		//}
	}
}

void Utils::copyToClipboard(const std::string& text)
{
	mainLog.Write("================= Utils::copyToClipboard ==================");
	if (OpenClipboard(NULL)) {
		EmptyClipboard();

		HGLOBAL hClipboardData = GlobalAlloc(GMEM_DDESHARE, (text.size() + 1) * sizeof(char));
		if (hClipboardData != NULL) {
			char* pszData = static_cast<char*>(GlobalLock(hClipboardData));
			if (pszData != NULL) {
				strcpy_s(pszData, text.size() + 1, text.c_str());
				GlobalUnlock(hClipboardData);
				SetClipboardData(CF_TEXT, hClipboardData);
			}
		}

		CloseClipboard();
	}
}

bool Utils::isWhitespaceString(const string& str) {
	mainLog.Write("================= Utils::isWhitespaceString ==================");
	// Check if the string is empty
	if (str.empty()) {
		return true;
	}
	// Check if the string contains only whitespaces
	for (char c : str) {
		if (!isspace(c)) {
			return false;
		}
	}
	return true;
}

bool Utils::compareProMatrices(ProMatrix matrix1, ProMatrix matrix2) {
	mainLog.Write("================= Utils::compareProMatrices ==================");
	for (int i = 0; i < 4; ++i) {
		for (int j = 0; j < 4; ++j) {
			if (matrix1[i][j] != matrix2[i][j]) {
				return false;  // Return false if any elements are not equal
			}
		}
	}
	return true;  // All elements are equal
}

void Utils::copyProMatrices(ProMatrix source, ProMatrix destination) {
	mainLog.Write("================= Utils::copyProMatrices ==================");
	for (int i = 0; i < 4; ++i) {
		for (int j = 0; j < 4; ++j) {
			destination[i][j] = source[i][j];
		}
	}
}

bool Utils::isSubModulePresent(const std::string& element) {
	mainLog.Write("================= Utils::isSubModulePresent ==================");
	for (const auto& item : subModulesList) {
		if (item.name.find(element) != string::npos)
			return true;
	}
	return false;
}

string Utils::doubleToString(double value){
	mainLog.Write("================= Utils::doubleToString ==================");
	std::stringstream stream;
	stream << std::fixed << std::setprecision(1) << value;
	return stream.str();
}

string Utils::remSpacesAtBothEnds(const string& str) {
	mainLog.Write("================= Utils::remSpacesAtBothEnds ==================");
	string strVal = str;
	if (str.empty())
		strVal;
	size_t start = strVal.find_first_not_of(" \t\n");
	if (start !=string::npos) {
		strVal = strVal.substr(start);
	}
	size_t end = strVal.find_last_not_of(" \t\n");
	if (end != string::npos) {
		strVal = strVal.substr(0, end + 1);
	}
	return strVal;
}

bool Utils::createFile(const string& fileName, const string& path, const string& content) {
	mainLog.Write("================= Utils::createFile ==================");

	// Combine path, filename, and extension to create the full file path
	std::string fullPath = path + "/" + fileName;

	// Create and write to the file
	std::ofstream outputFile(fullPath, std::ios::trunc);
	if (outputFile.is_open()) {
		outputFile << content;
		outputFile.close();
		return true; // File creation was successful
	} else {
		return false; // File creation failed
	}
}
#pragma pop