/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-12-2021	|	V1_0_0		| BACKEND OPERATIONS UPDATED
==================================================================================================================*/
#include "AppBackEnd.h"
#include "StdRules.h"

int AppBackEnd::CallSelectedRule(string RuleName, ruleResult &res)
{
	mainLog.Write("================================ AppBackEnd::CallSelectedRule() ================================");
	
	std::unordered_map <std::string, int> RuleMap;

	for(int i =0; i<rulesMapData.size(); ++i){
		RuleMap[rulesMapData[i][1]] = stoi(rulesMapData[i][2]);
	}

	int map_value = 0;
	//mainLog.Write("RuleMap.count(RuleName): " + to_string(RuleMap.count(RuleName)));

	if (RuleMap.count(RuleName) != 0){
		map_value = RuleMap.find(RuleName)->second;
		mainLog.Write(RuleName + " found" + "\tmapped serial number: "+to_string(map_value));
	}
	else {
		mainLog.Write(RuleName + " not found");
	}

	int stdRulesRes {};
	switch (map_value)
	{
#pragma region phase1
		case 1:
		{
			IRF1B01 rule_obj;
			stdRulesRes = rule_obj.IRF1B01_001(res);
			break;
		}
		case 2:
		{
			IRA1B01 rule_obj;
			stdRulesRes = rule_obj.IRA1B01_005(res);
			break;
		}
		case 3:
		{
			IRA1A01 rule_obj;
			stdRulesRes = rule_obj.IRA1A01_006(res);
			break;
		}
		case 4:
		{
			IRA1A01 rule_obj;
			stdRulesRes = rule_obj.IRA1A01_007(res);
			break;
		}
		case 5:
		{
			IRF5A17 rule_obj;
			stdRulesRes = rule_obj.IRF5A17_001(res);
			break;
		}
		case 6:
		{
			IRF5A20 rule_obj;
			stdRulesRes = rule_obj.IRF5A20_001(res);
			break;
		}
		case 7:
		{
			IRF5A08 rule_obj;
			stdRulesRes = rule_obj.IRF5A08_005(res);
			break;
		}
		case 8:
		{
			IRF5A27 rule_obj;
			stdRulesRes = rule_obj.IRF5A27_004(res);
			break;
		}
		case 9:
		{
			IRF1E08 rule_obj;
			stdRulesRes = rule_obj.IRF1E08_007(res);
			break;
		}
		case 10:
		{
			IRF5B01 rule_obj;
			stdRulesRes = rule_obj.IRF5B01_002(res);
			break;
		}
		case 11:
		{
			IRF2A02 rule_obj;
			stdRulesRes = rule_obj.IRF2A02_003(res);
			break;
		}
		case 12:
		{
			IRF2A02 rule_obj;
			stdRulesRes = rule_obj.IRF2A02_004(res);
			break;
		}
		case 13:
		{
			/*IRF3B01 rule_obj;
			stdRulesRes = rule_obj.IRF3B01_002(res);*/
			break;
		}
		case 14:
		{
			IRF4A02 rule_obj;
			stdRulesRes = rule_obj.IRF4A02_001(res);
			break;
		}
		case 15:
		{
			IRF4B02 rule_obj;
			stdRulesRes = rule_obj.IRF4B02_003(res);
			break;
		}
		case 113:
		{
			IRF5A07 rule_obj;
			stdRulesRes = rule_obj.IRF5A07_002(res);
			break;
		}
#pragma endregion phase1

#pragma region phase2
		case 16:
		{
			IRF2D01 rule_obj;
			stdRulesRes = rule_obj.IRF2D01_002(res);
			break;
		}
		case 17:
		{
			IRF5A01 rule_obj;
			stdRulesRes = rule_obj.IRF5A01_004(res);
			break;
		}
		case 18:
		{
			IRF5B01 rule_obj;
			stdRulesRes = rule_obj.IRF5B01_001(res);
			break;
		}
		case 19:
		{
			IRF2A01 rule_obj;
			stdRulesRes = rule_obj.IRF2A01_006(res);
			break;
		}
		case 20:
		{
			IRF2D03 rule_obj;
			stdRulesRes = rule_obj.IRF2D03_003(res);
			break;
		}
		case 21:
		{
			IRF1C02 rule_obj;
			stdRulesRes = rule_obj.IRF1C02_001(res);
			break;
		}
		case 22:
		{
			/*------ Deleted rule --------*/
			/*IRF1E02 rule_obj;
			stdRulesRes = rule_obj.IRF1E02_006(res);*/
			break;
		}
		case 23:
		{
			IRF2B04 rule_obj;
			stdRulesRes = rule_obj.IRF2B04_005(res);
			break;
		}
		case 24:
		{
			IRF2B04 rule_obj;
			stdRulesRes = rule_obj.IRF2B04_009(res);
			break;
		}
		case 25:
		{
			IRF1D01 rule_obj;
			stdRulesRes = rule_obj.IRF1D01_007(res);
			break;
		}
		case 26:
		{
			IRF1D02 rule_obj;
			stdRulesRes = rule_obj.IRF1D02_001(res);
			break;
		}
		case 27:
		{
			IRF1D02 rule_obj;
			stdRulesRes = rule_obj.IRF1D02_004(res);
			break;
		}
		case 28:
		{
			IRF5A10 rule_obj;
			stdRulesRes = rule_obj.IRF5A10_007(res);
			break;
		}
		case 29:
		{
			IRF5A27 rule_obj;
			stdRulesRes = rule_obj.IRF5A27_003(res);
			break;
		}
		case 30:
		{
			/*IR-F5A11-006 replaced with IR-F5A24-001*/
			IRF5A24 rule_obj;
			stdRulesRes = rule_obj.IRF5A24_001(res);
			break;
		}
		case 31:
		{
			IRF2B01 rule_obj;
			stdRulesRes = rule_obj.IRF2B01_001(res);
			break;
		}
		case 32:
		{
			IRF4B02 rule_obj;
			stdRulesRes = rule_obj.IRF4B02_001(res);
			break;
		}
		case 33:
		{
			IRF4A02 rule_obj;
			stdRulesRes = rule_obj.IRF4A02_003(res);
			break;
		}
		case 116:
		{
			IRF3B03 rule_obj;
			stdRulesRes = rule_obj.IRF3B03_002(res);
			break;
		}
#pragma endregion phase2

#pragma region phase3
		case 34:
		{
			IRF2D01 rule_obj;
			stdRulesRes = rule_obj.IRF2D01_010(res);
			break;
		}
		case 35:
		{
			IRF1D01 rule_obj;
			stdRulesRes = rule_obj.IRF1D01_003(res);
			break;
		}
		case 36:
		{
			IRF5A27 rule_obj;
			stdRulesRes = rule_obj.IRF5A27_006(res);
			break;
		}
		case 37:
		{
			IRF5A09 rule_obj;
			stdRulesRes = rule_obj.IRF5A09_003(res);
			break;
		}
		case 38:
		{
			IRF5A01 rule_obj;
			stdRulesRes = rule_obj.IRF5A01_007(res);
			break;
		}
		case 39:
		{
			IRF3B04 rule_obj;
			stdRulesRes = rule_obj.IRF3B04_001(res);
			break;
		}
		case 40:
		{
			/*-------- Deleted rule ---------*/
			/*IRF3B04 rule_obj;
			stdRulesRes = rule_obj.IRF3B04_002(res);*/
			break;
		}
		case 41:
		{
			IRF2C02 rule_obj;
			stdRulesRes = rule_obj.IRF2C02_003(res);
			break;
		}
		case 42:
		{
			IRF1C02 rule_obj;
			stdRulesRes = rule_obj.IRF1C02_004(res);
			break;
		}
		case 43:
		{
			IRF1C02 rule_obj;
			stdRulesRes = rule_obj.IRF1C02_006(res);
			break;
		}
		case 44:
		{
			IRF1C01 rule_obj;
			stdRulesRes = rule_obj.IRF1C01_006(res);
			break;
		}
		case 45:
		{
			/*-------- Deleted rule ---------*/
			/*IRF1E01 rule_obj;
			stdRulesRes = rule_obj.IRF1E01_001(res);*/
			break;
		}
		case 46:
		{
			IRF1E01 rule_obj;
			stdRulesRes = rule_obj.IRF1E01_007(res);
			break;
		}
		case 47:
		{
			IRF2B04 rule_obj;
			stdRulesRes = rule_obj.IRF2B04_006(res);
			break;
		}
		case 48:
		{
			IRF3A01 rule_obj;
			stdRulesRes = rule_obj.IRF3A01_004(res);
			break;
		}
		case 49:
		{
			/*IRF3A04 rule_obj;
			stdRulesRes = rule_obj.IRF3A04_001(res);*/
			break;
		}
		case 50:
		{
			IRF1D01 rule_obj;
			stdRulesRes = rule_obj.IRF1D01_001(res);
			break;
		}
		case 51:
		{
			IRH2D01 rule_obj;
			stdRulesRes = rule_obj.IRH2D01_001(res);
			break;
		}
		case 52:
		{
			/*Rule ID is changed*/
			//IRF5A01 rule_obj;			//old
			//stdRulesRes = rule_obj.IRF5A01_005(res);
			
			IRF5A04 rule_obj;			// new
			stdRulesRes = rule_obj.IRF5A04_001(res);
			break;
		}
		case 53:
		{
			IRF4A01 rule_obj;
			stdRulesRes = rule_obj.IRF4A01_002(res);
			break;
		}
		case 54:
		{
			IRF4A02 rule_obj;
			stdRulesRes = rule_obj.IRF4A02_002(res);
			break;
		}
		case 55:
		{
			IRF2D01 rule_obj;
			stdRulesRes = rule_obj.IRF2D01_014(res);
			break;
		}
		case 56:
		{
			IRF1D01 rule_obj;
			stdRulesRes = rule_obj.IRF1D01_006(res);
			break;
		}
		
#pragma endregion phase3

#pragma region phase4
		case 57:
		{
			IRF4B05 rule_obj;
			stdRulesRes = rule_obj.IRF4B05_003(res);
			break;
		}
		case 58:
		{
			IRF5A17 rule_obj;
			stdRulesRes = rule_obj.IRF5A17_003(res);
			break;
		}
		case 59:
		{
			IRF5A08 rule_obj;
			stdRulesRes = rule_obj.IRF5A08_007(res);
			break;
		}
		case 60:
		{
			IRF5A01 rule_obj;
			stdRulesRes = rule_obj.IRF5A01_001(res);
			break;
		}
		case 61:
		{

			break;
		}
		case 62:
		{

			break;
		}
		case 63:
		{
			IRF5B01 rule_obj;
			stdRulesRes = rule_obj.IRF5B01_006(res);
			break;
		}
		case 64:
		{
			IRF5B01 rule_obj;
			stdRulesRes = rule_obj.IRF5B01_008(res);
			break;
		}
		case 65:
		{
			IRF2A01 rule_obj;
			stdRulesRes = rule_obj.IRF2A01_002(res);
			break;
		}
		case 66:
		{
			IRF2C01 rule_obj;
			stdRulesRes = rule_obj.IRF2C01_011(res);
			break;
		}
		case 67:
		{
			IRF2C01 rule_obj;
			stdRulesRes = rule_obj.IRF2C01_013(res);
			break;
		}
		case 68:
		{
			IRF2B09 rule_obj;
			stdRulesRes = rule_obj.IRF2B09_004(res);
			break;
		}
		case 69:
		{
			IRF2B01 rule_obj;
			stdRulesRes = rule_obj.IRF2B01_003(res);
			break;
		}
		case 70:
		{
			IRH2C01 rule_obj;
			stdRulesRes = rule_obj.IRH2C01_002(res);
			break;
		}
		case 71:
		{
			IRH2D01 rule_obj;
			stdRulesRes = rule_obj.IRH2D01_002(res);
			break;
		}
		case 72:
		{
			/*-------- Deleted rule --------*/
			/*IRF3B01 rule_obj;
			stdRulesRes = rule_obj.IRF3B01_003(res);*/
			break;
		}
		case 73:
		{
			IRF3B02 rule_obj;
			stdRulesRes = rule_obj.IRF3B02_002(res);
			break;
		}
		case 74:
		{
			break;
		}
		case 75:
		{
			/*-------- Deleted rule --------*/
			/*IRH1A01 rule_obj;
			stdRulesRes = rule_obj.IRH1A01_017(res);*/
			break;
		}
		case 76:
		{
			// old rule IR-H1A11-001
			IRH1A14 rule_obj;
			stdRulesRes = rule_obj.IRH1A14_003(res);
			break;
		}
		case 77:
		{
			IRH1A15 rule_obj;
			stdRulesRes = rule_obj.IRH1A15_001(res);
			break;
		}
		case 78:
		{
			IRH1A14 rule_obj;
			stdRulesRes = rule_obj.IRH1A14_001(res);
			break;
		}
		case 79:
		{
			IRF2D01 rule_obj;
			stdRulesRes = rule_obj.IRF2D01_017(res);
			break;
		}
		case 80:
		{
			IRF4A05 rule_obj;
			stdRulesRes = rule_obj.IRF4A05_003(res);
			break;
		}
#pragma endregion phase4
#pragma region phase5
		case 81:
		{
			IRF5A01 rule_obj;
			stdRulesRes = rule_obj.IRF5A01_006(res);
			break;
		}
		case 82:
		{
			IRF5A01 rule_obj;
			stdRulesRes = rule_obj.IRF5A01_011(res);
			break;
		}
		case 83:
		{
			IRF3B02 rule_obj;
			stdRulesRes = rule_obj.IRF3B02_003(res);
			break;
		}
		case 84:
		{
			IRF2A02 rule_obj;
			stdRulesRes = rule_obj.IRF2A02_007(res);
			break;
		}
		case 85:
		{
			IRF2A02 rule_obj;
			stdRulesRes = rule_obj.IRF2A02_008(res);
			break;
		}
		case 86:
		{
			IRF2A02 rule_obj;
			stdRulesRes = rule_obj.IRF2A02_009(res);
			break;
		}
		case 87:
		{
			IRF2C01 rule_obj;
			stdRulesRes = rule_obj.IRF2C01_003(res);
			break;
		}
		case 88:
		{
			IRF2C01 rule_obj;
			stdRulesRes = rule_obj.IRF2C01_012(res);
			break;
		}
		case 89:
		{
			IRF1E06 rule_obj;
			stdRulesRes = rule_obj.IRF1E06_005(res);
			break;
		}
		case 90:
		{
			IRF2B09 rule_obj;
			stdRulesRes = rule_obj.IRF2B09_002(res);
			break;
		}
		case 91:
		{
			IRF2B09 rule_obj;
			stdRulesRes = rule_obj.IRF2B09_003(res);
			break;
		}
		case 93:
		{
			IRH2D01 rule_obj;
			stdRulesRes = rule_obj.IRH2D01_003(res);
			break;
		}
		case 94:
		{
			IRH1A14 rule_obj;
			stdRulesRes = rule_obj.IRH1A14_002(res);
			break;
		}
		case 95:
		{
			IRH1A01 rule_obj;
			stdRulesRes = rule_obj.IRH1A01_014(res);
			break;
		}
		case 99:
		{
			IRF3C03 rule_obj;
			stdRulesRes = rule_obj.IRF3C03_004(res);
			break;
		}
		case 101:
		{
			/*IRH1A01 rule_obj;
			stdRulesRes = rule_obj.IRH1A01_001(res);*/
			IRH1A14 rule_obj;
			stdRulesRes = rule_obj.IRH1A14_004(res);
			break;
		}
		case 102:
		{
			IRF4A02 rule_obj;
			stdRulesRes = rule_obj.IRF4A02_005(res);
			break;
		}
		case 104:
		{
			IRF2C01 rule_obj;
			stdRulesRes = rule_obj.IRF2C01_020(res);
			break;
		}
		case 105:
		{
			IRF5A07 rule_obj;
			stdRulesRes = rule_obj.IRF5A07_008(res);
			break;
		}
		case 106:
		{
			IRF2C01 rule_obj;
			stdRulesRes = rule_obj.IRF2C01_008(res);
			break;
		}
		case 107:
		{
			IRF2C01 rule_obj;
			stdRulesRes = rule_obj.IRF2C01_019(res);
			break;
		}
		case 109:
		{
			IRF3A01 rule_obj;
			stdRulesRes = rule_obj.IRF3A01_001(res);
			break;
		}
		case 112:
		{
			IRF5A10 rule_obj;
			stdRulesRes = rule_obj.IRF5A10_001(res);
			break;
		}
		case 114:
		{
			IRF3B01 rule_obj;
			stdRulesRes = rule_obj.IRF3B01_005(res);
			break;
		}
		case 118:
		{
			IRF3B06 rule_obj;
			stdRulesRes = rule_obj.IRF3B06_003(res);
			break;
		}
		case 119:
		{
			IRF2B06 rule_obj;
			stdRulesRes = rule_obj.IRF2B06_003(res);
			break;
		}
		case 123:
		{
			IRH1A01 rule_obj;
			stdRulesRes = rule_obj.IRH1A01_007(res);
			break;
		}
		case 130:
		{
			/*IRF4B04 rule_obj;
			stdRulesRes = rule_obj.IRF4B04_003(res);*/
			IRF4B02 rule_obj;
			stdRulesRes = rule_obj.IRF4B02_005(res);
			break;
		}
		case 131:
		{
			IRF4B05 rule_obj;
			stdRulesRes = rule_obj.IRF4B05_002(res);
			break;
		}
		case 132:
		{
			IRF4A05 rule_obj;
			stdRulesRes = rule_obj.IRF4A05_002(res);
			break;
		}
		case 133:
		{
			IRF4A04 rule_obj;
			stdRulesRes = rule_obj.IRF4A04_002(res);
			break;
		}
		case 134:
		{
			IRF4B04 rule_obj;
			stdRulesRes = rule_obj.IRF4B04_002(res);
			break;
		}
		case 135:
		{
			IRF2A01 rule_obj;
			stdRulesRes = rule_obj.IRF2A01_001(res);
			break;
		}
		case 136:
		{
			IRF5A07 rule_obj;
			stdRulesRes = rule_obj.IRF5A07_001(res);
			break;
		}
		case 137:
		{
			IRA1B01 rule_obj;
			stdRulesRes = rule_obj.IRA1B01_007(res);
			break;
		}
		case 138:
		{
			IRA1A01 rule_obj;
			stdRulesRes = rule_obj.IRA1A01_002(res);
			break;
		}
		case 139:
		{
			IRF5A27 rule_obj;
			stdRulesRes = rule_obj.IRF5A27_005(res);
			break;
		}
		case 140:
		{
			IRF3B01 rule_obj;
			stdRulesRes = rule_obj.IRF3B01_004(res);
			break;
		}
		case 141:
		{
			IRF3B02 rule_obj;
			stdRulesRes = rule_obj.IRF3B02_004(res);
			break;
		}
		case 142:
		{
			IRF3B03 rule_obj;
			stdRulesRes = rule_obj.IRF3B03_005(res);
			break;
		}
		case 145:
		{
			IRF2A01 rule_obj;
			stdRulesRes = rule_obj.IRF2A01_005(res);
			break;
		}
		case 146:
		{
			IRF2B01 rule_obj;
			stdRulesRes = rule_obj.IRF2B01_002(res);
			break;
		}
		case 147:
		{
			IRF3A01 rule_obj;
			stdRulesRes = rule_obj.IRF3A01_003(res);
			break;
		}
		case 148:
		{
			IRF3A01 rule_obj;
			stdRulesRes = rule_obj.IRF3A01_007(res);
			break;
		}
		case 149:
		{
			IRF1D01 rule_obj;
			stdRulesRes = rule_obj.IRF1D01_009(res);
			break;
		}
		case 155:
		{
			IRF3C03 rule_obj;
			stdRulesRes = rule_obj.IRF3C03_010(res);
			break;
		}
		case 158:
		{
			IRF2D01 rule_obj;
			stdRulesRes = rule_obj.IRF2D01_015(res);
			break;
		}
		case 159:
		{
			/*IRF2D04 rule_obj;
			stdRulesRes = rule_obj.IRF2D04_002(res);*/
			IRF2D01 rule_obj;
			stdRulesRes = rule_obj.IRF2D01_018(res);
			break;
		}
		case 160:
		{
			IRF5A17 rule_obj;
			stdRulesRes = rule_obj.IRF5A17_004(res);
			break;
		}
		case 161:
		{
			IRF5A11 rule_obj;
			stdRulesRes = rule_obj.IRF5A11_002(res);
			break;
		}
		case 162:
		{
			IRF2C01 rule_obj;
			stdRulesRes = rule_obj.IRF2C01_016(res);
			break;
		}
		case 163:
		{
			IRF2C01 rule_obj;
			stdRulesRes = rule_obj.IRF2C01_017(res);
			break;
		}
		case 164:
		{
			IRF4B02 rule_obj;
			stdRulesRes = rule_obj.IRF4B02_002(res);
			break;
		}
		case 166:
		{
			IRH2B01 rule_obj;
			stdRulesRes = rule_obj.IRH2B01_001(res);
			break;
		}
		case 167:
		{
			IRH2B01 rule_obj;
			stdRulesRes = rule_obj.IRH2B01_002(res);
			break;
		}
		case 168:
		{
			IRH2B01 rule_obj;
			stdRulesRes = rule_obj.IRH2B01_003(res);
			break;
		}
		case 169:
		{
			IRH2C01 rule_obj;
			stdRulesRes = rule_obj.IRH2C01_001(res);
			break;
		}
		case 171:
		{
			IRF3B03 rule_obj;
			stdRulesRes = rule_obj.IRF3B03_006(res);
			break;
		}
		case 174:
		{
			IRF2A04 rule_obj;
			stdRulesRes = rule_obj.IRF2A04_001(res);
			break;
		}
		case 175:
		{
			IRF2A04 rule_obj;
			stdRulesRes = rule_obj.IRF2A04_002(res);
			break;
		}
		case 177:
		{
			IRF1E05 rule_obj;
			stdRulesRes = rule_obj.IRF1E05_001(res);
			break;
		}
		case 178:
		{
			IRF2B07 rule_obj;
			stdRulesRes = rule_obj.IRF2B07_006(res);
			break;
		}
		case 179:
		{
			IRF2B07 rule_obj;
			stdRulesRes = rule_obj.IRF2B07_008(res);
			break;
		}
		default:
		{
			mainLog.Write("Test not found!");
			stdRulesRes = -1;
			break;
		}
	}
	mainLog.Write("stdRulesRes: " + to_string(stdRulesRes));
	return stdRulesRes;		
}