/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 31-05-2023	| V1_0_0		| ASSEMBLY TOOL FOR MISSING SUB-MODULES
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

#include "DPDSCreoIRCapplication.h"
#include "AssemblyTool.h"

#define DLG_ASM_TOOL		"dlg_asm_tool"
#define TBL_ASM_TOOL		"tool_tbl"
#define TBL_LBL_ASM_TOOL	"tbl_lbl"
#define TBL_ASMNAME_IP		"tbl_asmname_ip"
#define TBL_PB_ASM_TOOL		"tbl_pb"
#define RG_ASM_MODE			"rg_asm_mode"
#define IP_NEW_ASM_NAME		"ip_new_asm"
#define IP_ASMLOC			"asmloc_ip"
#define PB_BROWSE_ASMLOC	"browse_asmloc_pb"
#define CANCEL_PB_ASM_TOOL	"CommitCancel"
#define OK_PB_ASM_TOOL		"CommitOK"
//#define TBL_OPTMENU_ASM_TOOL	"tbl_optionmenu"

// GLOBAL ENTITIES
vector<AsmPosition> asmPosList;
char cRowname[15], cNewAsmName[PRO_NAME_SIZE], cCwd[PRO_PATH_SIZE], cSrcDir[PRO_PATH_SIZE];
int noOfMissingSubModls;
wchar_t wNewAsmName[PRO_NAME_SIZE], wCwd[PRO_PATH_SIZE], wSrcDir[PRO_PATH_SIZE];
ModelCategory mdlCategory;;

int createAsmToolDialog(vector<string> missingModules, ModelCategory category)
{
	mainLog.Write("================================== createAsmToolDialog ==================================");

	mdlCategory = category;
	
	status = ProUIDialogCreate(DLG_ASM_TOOL, DLG_ASM_TOOL);
	status = ProUIDialogAboveactivewindowSet(DLG_ASM_TOOL, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_ASM_TOOL, OK_PB_ASM_TOOL, (ProUIAction)assemble_action, NULL);
	status = ProUIPushbuttonDisable(DLG_ASM_TOOL, OK_PB_ASM_TOOL);

	status = ProUIPushbuttonActivateActionSet(DLG_ASM_TOOL, CANCEL_PB_ASM_TOOL, (ProUIAction)asmToolDlgCloseAction, NULL);
	//status = ProUIRadiogroupSelectActionSet(DLG_ASM_TOOL, RG_ASM_MODE, (ProUIAction)asm_mode_rg_action, NULL);

	ProTKSprintf(cNewAsmName, "DUMMY_%s", cCurMdlName);
	ProStringToWstring(wNewAsmName, cNewAsmName);

	if(mdlCategory == SUB_MODULE)
		missingModules.push_back("M"+string(cCurMdlName).substr(4,5));	// adding the current model name for position matrix

	noOfMissingSubModls = missingModules.size();
	mainLog.Write("noOfMissingSubModls: " + to_string(noOfMissingSubModls));
	asmPosList.reserve(missingModules.size());
	char** asmToolTblsRows = new char* [noOfMissingSubModls];
	for (int i = 0; i < noOfMissingSubModls; ++i)
	{
		asmToolTblsRows[i] = new char[PRO_PATH_SIZE];
		ProTKSprintf(asmToolTblsRows[i], "r%d", i+1);
	}

	status = ProDirectoryCurrentGet(wCwd);
	wcscpy(wSrcDir, wCwd);
	status = ProUIInputpanelValueSet(DLG_ASM_TOOL, IP_ASMLOC, wSrcDir);
	status = ProUIPushbuttonActivateActionSet(DLG_ASM_TOOL, PB_BROWSE_ASMLOC, (ProUIAction)browse_asmloc_action, NULL);

	status = ProUITableRowsInsert(DLG_ASM_TOOL, TBL_ASM_TOOL, NULL, noOfMissingSubModls, asmToolTblsRows);
	mainLog.Write("ProUITableRowsInsert: " + to_string(status));
	if(status != PRO_TK_NO_ERROR)
		return -1;

	status = status = ProUITablePushbuttonAdd(DLG_ASM_TOOL, TBL_ASM_TOOL, TBL_PB_ASM_TOOL);
	status = ProUIPushbuttonTextSet(DLG_ASM_TOOL, TBL_PB_ASM_TOOL, L"Browse");
	//status = ProUIPushbuttonBitmapSet(DLG_ASM_TOOL, TBL_PB_ASM_TOOL, "search.png");
	status = ProUITableInputpanelAdd(DLG_ASM_TOOL, TBL_ASM_TOOL, TBL_ASMNAME_IP);
	status = ProUIInputpanelColumnsSet(DLG_ASM_TOOL, TBL_ASMNAME_IP, 9);	// length of input panel
	/*status = ProUITableOptionmenuAdd(DLG_ASM_TOOL, TBL_ASM_TOOL, TBL_OPTMENU_ASM_TOOL);
	mainLog.Write("ProUITableOptionmenuAdd: " + to_string(status));
	status = ProUIOptionmenuColumnsSet(DLG_ASM_TOOL, TBL_OPTMENU_ASM_TOOL, 10);
	mainLog.Write("ProUIOptionmenuColumnsSet: " + to_string(status));*/

	for (int i = 0; i < noOfMissingSubModls; ++i)
	{
		char cCellLbl[PRO_NAME_SIZE];
		wchar_t wCellLbl[PRO_NAME_SIZE];
		AsmPosition _tempAsmPos;

		// S NO
		ProTKSprintf(cCellLbl, " %d.",i+1);
		ProStringToWstring(wCellLbl, cCellLbl);
		status = ProUITableCellLabelSet(DLG_ASM_TOOL, TBL_ASM_TOOL, asmToolTblsRows[i], "s_no", wCellLbl);
		mainLog.Write("ProUITableCellLabelSet: " + to_string(status)+ "\ts_no: "+to_string(i));

		// MODULE ADDRESS
		ProTKSprintf(cCellLbl, "%s", missingModules[i]);
		ProStringToWstring(wCellLbl, cCellLbl);
		status = ProUITableCellLabelSet(DLG_ASM_TOOL, TBL_ASM_TOOL, asmToolTblsRows[i], "module_lbl", wCellLbl);
		mainLog.Write("ProUITableCellLabelSet: " + to_string(status)+ "\tmodule_lbl: "+missingModules[i]);
		strcpy(_tempAsmPos.modAddrs, missingModules[i].c_str());

		// ASM NAME INPUT PANEL
		char tblAsmIpName[PRO_NAME_SIZE]{};
		ProTKSprintf(tblAsmIpName, "asmip_%s", asmToolTblsRows[i]);
		status = ProUITableCellComponentCopy(DLG_ASM_TOOL, TBL_ASM_TOOL, asmToolTblsRows[i], "module_ip", DLG_ASM_TOOL, TBL_ASMNAME_IP, tblAsmIpName);
		mainLog.Write("tblAsmIpName: " + string(tblAsmIpName) + "\tProUITableCellComponentCopy: " + to_string(status));
		if(i == (noOfMissingSubModls-1) && mdlCategory == SUB_MODULE){	// default asm name
			status = ProUIInputpanelValueSet(DLG_ASM_TOOL, tblAsmIpName, wCurMdlName);
			strcpy(_tempAsmPos.name, cCurMdlName);
			status = ProUIInputpanelDisable(DLG_ASM_TOOL, tblAsmIpName);
		}
		else
			status = ProUIInputpanelInputActionSet(DLG_ASM_TOOL, tblAsmIpName, (ProUIAction)asmname_ip_action, NULL);
		
		// OPTION MENU
		/*char tblOptMenuName[PRO_NAME_SIZE]{};
		ProTKSprintf(tblOptMenuName, "optMenu_%s", asmToolTblsRows[i]);
		status = ProUITableCellComponentCopy(DLG_ASM_TOOL, TBL_ASM_TOOL, asmToolTblsRows[i], "module_ip", DLG_ASM_TOOL, TBL_OPTMENU_ASM_TOOL, tblOptMenuName);
		mainLog.Write("tblOptMenuName: " + string(tblOptMenuName) + "\tProUITableCellComponentCopy: " + to_string(status));//DEVIATION CB
		status = ProUIOptionmenuSelectActionSet(DLG_ASM_TOOL, tblOptMenuName, (ProUIAction)missingModlOptMenuSelectAction, NULL);
		mainLog.Write("ProUIOptionmenuSelectActionSet: " + to_string(status));

		ProMdl *sessionAsms;
		int sessionAsmCount;
		vector<pair<int, string>> reqAsmNames;
		status = ProSessionMdlList(PRO_MDL_ASSEMBLY, &sessionAsms, &sessionAsmCount);
		mainLog.Write("ProSessionMdlList: " + to_string(status) + "\tsessionAsmCount: "+to_string(sessionAsmCount));

		for(int j=0; j < sessionAsmCount; ++j){
			ProMdlName wSesAsmName;
			ProCharName cSesAsmName;
			status = ProMdlMdlnameGet(sessionAsms[j], wSesAsmName);
			ProWstringToString(cSesAsmName, wSesAsmName);
			if (missingModules[i].compare(1, missingModules[i].length(), cSesAsmName + 4, missingModules[i].length()-1) == 0){
				reqAsmNames.push_back(make_pair(i, cSesAsmName));
				mainLog.Write("cSesAsmName: " + string(cSesAsmName));
			}
		}
		setOptionMenu(tblOptMenuName, reqAsmNames);*/

		// BROWSE PB
		char tblPbName[PRO_NAME_SIZE]{};
		ProTKSprintf(tblPbName, "browsepb_%s", asmToolTblsRows[i]);
		status = ProUITableCellComponentCopy(DLG_ASM_TOOL, TBL_ASM_TOOL, asmToolTblsRows[i], "browse_pos", DLG_ASM_TOOL, TBL_PB_ASM_TOOL, tblPbName);
		mainLog.Write("tblPbName: " + string(tblPbName) + "\tProUITableCellComponentCopy: " + to_string(status));
		if(i != (noOfMissingSubModls-1) && mdlCategory == SUB_MODULE)	// skipping the parent model
			status = ProUIPushbuttonDisable(DLG_ASM_TOOL, tblPbName);
		status = ProUIPushbuttonActivateActionSet(DLG_ASM_TOOL, tblPbName, (ProUIAction)browse_pb_action, NULL);

		// POSITION TEXT FILEPATH
		//status = ProUITableCellLabelSet(DLG_ASM_TOOL, TBL_ASM_TOOL, asmToolTblsRows[i], "pos_filepath",L"loc");

		_utils.copyProMatrices(identity_matrix, _tempAsmPos.pos);
		asmPosList.push_back(_tempAsmPos);
	}

	//DISABLE CELL SELECTION
	status = ProUITableSelectionpolicySet(DLG_ASM_TOOL, TBL_ASM_TOOL, PROUISELPOLICY_NONE);
	mainLog.Write("ProUITableSelectionpolicySet  : " + to_string(status));

	int asmToolDlgSts;
	status = ProUIDialogActivate(DLG_ASM_TOOL, &asmToolDlgSts);
	mainLog.Write("ProUIDialogActivate(DLG_ASM_TOOL): " + to_string(status));
	status = ProUIDialogDestroy(DLG_ASM_TOOL);
	mainLog.Write("ProUIDialogDestroy(DLG_ASM_TOOL): " + to_string(status));

	asmPosList.clear();

	return 0;
}

ProError asmname_ip_action(char* dialog, char* component, ProAppData data)
{
	mainLog.Write("================================== asmname_ip_action ==================================");
	wchar_t *wIpVal, *wModlAddrs;
	char cIpVal[PRO_NAME_SIZE], cPbName[PRO_NAME_SIZE], cModlAddrs[PRO_NAME_SIZE];

	status = ProUIInputpanelValueGet(dialog, component, &wIpVal);
	ProWstringToString(cIpVal, wIpVal);
	getRowNameFromComponent(component, cRowname);
	mainLog.Write("cRowname: "+ string(cRowname));
	ProTKSprintf(cPbName, "browsepb_%s", cRowname);	// get the pb name
	int missingSubModIdx = stoi(string(cRowname).substr(1))-1;
	mainLog.Write("missingSubModIdx: "+ to_string(missingSubModIdx));
	strcpy(asmPosList[missingSubModIdx].name, cIpVal);

	// ENABLE/DISABLE BROWSE PB
	if(isAsmNameValid(asmPosList[missingSubModIdx].name) && toUpperCase(string(asmPosList[missingSubModIdx].name).substr(4,5)).compare(string(asmPosList[missingSubModIdx].modAddrs).substr(1)) == 0)
		status = ProUIPushbuttonEnable(dialog, cPbName);
	else
		status = ProUIPushbuttonDisable(dialog, cPbName);

	// ENABLE/DISABLE ASSEMBLY PB
	status = ProUIPushbuttonDisable(dialog, OK_PB_ASM_TOOL);	// disable by default
	bool enableAsmBtn = true; // to toggle if any invalid names found while iterating the loop.
	for(int i = 0; i< noOfMissingSubModls; ++i){
		if(string(asmPosList[i].name).compare("") != 0)	// check only if name not empty
		{
			if(isAsmNameValid(asmPosList[i].name)){		// if valid asm name
				if(toUpperCase(string(asmPosList[i].name).substr(4,5)).compare(string(asmPosList[i].modAddrs).substr(1)) == 0)
					status = ProUIPushbuttonEnable(dialog, OK_PB_ASM_TOOL);	// enable only if all entered names are VALID.
				else
					enableAsmBtn = false;
			}
			else
				enableAsmBtn = false;
		}
	}
	if(!enableAsmBtn)
		status = ProUIPushbuttonDisable(dialog, OK_PB_ASM_TOOL);

	return status;
}

ProError browse_pb_action(char* dialog, char* component, ProAppData data)
{
	mainLog.Write("================================== browse_pb_action ==================================");

	wchar_t *wIpValue, *wModAddrs;
	char cIpname[PRO_NAME_SIZE], cIpValue[PRO_NAME_SIZE], cModAddrs[PRO_NAME_SIZE];

	getRowNameFromComponent(component, cRowname);
	ProTKSprintf(cIpname, "asmip_%s", cRowname);

	status = ProUIInputpanelValueGet(dialog, cIpname, &wIpValue);
	ProWstringToString(cIpValue, wIpValue);

	status = ProUITableCellLabelGet(dialog, TBL_ASM_TOOL, cRowname,  "module_lbl", &wModAddrs);
	ProWstringToString(cModAddrs,wModAddrs);

	for(int i=0; i< noOfMissingSubModls; ++i)
	{
		if(string(cModAddrs).compare(asmPosList[i].modAddrs) == 0)
		{
			/*strcpy(asmPosList[i].name, cIpValue);
			mainLog.Write("asmPosList["+to_string(i)+"].name: " + string(asmPosList[i].name));*/
			
			/*// ASSIGN TYPE
			size_t _pos = string(cIpValue).find_first_of('.');
			string type = string(cIpValue).substr(_pos+1);
			if(type.compare("prt") == 0)
				asmPosList[i].type = PRO_MDLFILE_PART;
			else if(type.compare("asm") == 0)
				asmPosList[i].type = PRO_MDLFILE_ASSEMBLY;*/

			// ASSIGN POSITION
			ProPath wPosFilePath;
			ProCharPath cPosFilePath;
			status = ProFileOpen(L"Open Position Matrix file", L"*.txt", NULL, NULL, NULL, NULL, wPosFilePath);
			if (status != PRO_TK_NO_ERROR)
				return status;
			ProWstringToString(cPosFilePath, wPosFilePath);
			mainLog.Write("cPosFilePath: " + string(cPosFilePath));

			double posMatrix[4][4];
			if(isValidPositionMatrixFile(cPosFilePath, posMatrix))
			{
				for (int row = 0; row < 4; ++row)
					for (int col = 0; col < 4; ++col)
						asmPosList[i].pos[row][col] = posMatrix[row][col];	// copy it to actual vector
			}
			else{
				_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error!", "Please provide a valid Position Matrix file.");
				return PRO_TK_GENERAL_ERROR;
			}
			/*mainLog.Write("item.modAddrs: " + string(asmPosList[0].modAddrs));
			mainLog.Write("item.name: " + string(asmPosList[0].name));
			for (int i = 0; i < 4; ++i) {
			for (int j = 0; j < 4; ++j) {
			mainLog.Write("\tpos["+to_string(i)+"]["+to_string(j)+"]=" + to_string(asmPosList[0].pos[i][j]));
			}
			}*/
			status = ProUITableCellLabelSet(DLG_ASM_TOOL, TBL_ASM_TOOL, cRowname, "pos_filepath", wPosFilePath);
			//mainLog.Write("ProUITableCellLabelSet: " + to_string(status));
			status = ProUITableCellHelpTextSet(DLG_ASM_TOOL, TBL_ASM_TOOL, cRowname, "pos_filepath", wPosFilePath);
			//mainLog.Write("ProUITableCellHelpTextSet: " + to_string(status));
		}
	}
	return status;
}

ProError browse_asmloc_action(char* dialog, char* component, ProAppData data)
{
	mainLog.Write("================================== browse_asmloc_action ==================================");

	status = ProDirectoryChoose(L"Select the source directory", NULL, NULL, NULL, wSrcDir);
	mainLog.Write("ProDirectoryChoose: " + to_string(status));
	status = ProUIInputpanelValueSet(dialog, IP_ASMLOC, wSrcDir);

	return PRO_TK_NO_ERROR;
}

ProError assemble_action(char* dialog, char* component, ProAppData data)
{
	mainLog.Write("================================== assemble_action ==================================");
	ProAsmcomp asmFeat;
	ProMdl topLevelMdl{}, childMdl{};
	bool isMissingPosMatrix = false;

	// set constraints
	ProAsmcompconstraint* constraints;
	ProAsmcompconstraint constraint;
	status = ProArrayAlloc(0, sizeof(ProAsmcompconstraint), 1, (ProArray*)&constraints);
	status = ProAsmcompconstraintAlloc(&constraint);
	status = ProAsmcompconstraintTypeSet(constraint, PRO_ASM_FIX);
	status = ProArrayObjectAdd((ProArray*)&constraints, -1, 1, &constraint);

	// check if position matrix file is missing
	for(auto item : asmPosList)
		if(isAsmNameValid(item.name))
			if(_utils.compareProMatrices(item.pos, identity_matrix) == true)
				isMissingPosMatrix = true;

	// prompt user for confirmation
	if(isMissingPosMatrix){
		ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
		msg_buttons[0] = PRO_UI_MESSAGE_YES;
		msg_buttons[1] = PRO_UI_MESSAGE_NO;

		user_choice = _utils.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation", "Position Matrix is missing for some sub-modules.\n\nDo you want to fix it in default position?", msg_buttons);
		if(user_choice == PRO_UI_MESSAGE_NO)
			return PRO_TK_NO_ERROR;	// return if NO clicked
	}

	if(mdlCategory == CP_ITEM || mdlCategory == DUMMY)
	{
		mainLog.Write("exist_asm");
		status = ProMdlCurrentGet(&topLevelMdl);
	}
	else if(mdlCategory == SUB_MODULE)
	{
		mainLog.Write("new_asm");
		ProPath wDummyMdlPath, wTemplatePath;
		ProMdl templateMdl;
		char cDummyMdlPath[PRO_PATH_SIZE], cTemplatePath[PRO_PATH_SIZE];

		ProTKSprintf(cTemplatePath, "%s%s", PROE_TML_STD_PATH, "\\templates\\start_assembly_plm_creo3.asm");
		mainLog.Write("cTemplatePath: "+ string(cTemplatePath));
		ProStringToWstring(wTemplatePath, cTemplatePath);

		status = ProMdlnameRetrieve(wTemplatePath, PRO_MDLFILE_ASSEMBLY, &templateMdl);
		mainLog.Write("ProMdlnameRetrieve: "+to_string(status));
		ProWstringToString(cCwd, wCwd);
		ProTKSprintf(cDummyMdlPath, "%s%s.asm", cCwd, cNewAsmName);
		ProStringToWstring(wDummyMdlPath, cDummyMdlPath);
		mainLog.Write("cDummyMdlPath: "+ string(cDummyMdlPath));

		status = ProMdlnameCopy(templateMdl, wNewAsmName, &topLevelMdl);
		mainLog.Write("ProMdlnameCopy: "+to_string(status));

		//status = ProAsmcompAssemble((ProAssembly)topLevelMdl, (ProSolid)curMdl, identity_matrix, &asmFeat);  //source_comp_path
		//mainLog.Write("ProAsmcompAssemble: " + to_string(status));

		//if (status == PRO_TK_NO_ERROR){
		//	status = ProAsmcompConstraintsSet(NULL, &asmFeat, constraints);
		//	mainLog.Write("ProAsmcompConstraintsSet: " + to_string(status));
		//}
	}

	for(int i=0; i< noOfMissingSubModls; ++i)
	{
		if(isAsmNameValid(asmPosList[i].name))
		{
			wchar_t wSrcPath[PRO_PATH_SIZE];
			char cSrcPath[PRO_PATH_SIZE];
			ProWstringToString(cSrcDir, wSrcDir);
			ProTKSprintf(cSrcPath, "%s\\%s.asm", cSrcDir, asmPosList[i].name);
			mainLog.Write("cSrcPath: " + string(cSrcPath));
			ProStringToWstring(wSrcPath, cSrcPath);
			status = ProMdlnameRetrieve(wSrcPath, PRO_MDLFILE_ASSEMBLY, &childMdl);
			mainLog.Write("ProMdlnameRetrieve [PRO_MDLFILE_ASSEMBLY]: " + to_string(status));
			if(status == PRO_TK_E_NOT_FOUND)
			{
				ProTKSprintf(cSrcPath, "%s\\%s.prt", cSrcDir, asmPosList[i].name);
				mainLog.Write("cSrcPath: " + string(cSrcPath));
				ProStringToWstring(wSrcPath, cSrcPath);				
				status = ProMdlnameRetrieve(wSrcDir, PRO_MDLFILE_PART, &childMdl);
				mainLog.Write("ProMdlnameRetrieve [PRO_MDLFILE_PART]: " + to_string(status));
			}
			if(status != PRO_TK_NO_ERROR){
				string errMsg = "Unable to retrieve the sub-module ";
				errMsg += asmPosList[i].name;
				errMsg += " from session.";
				_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error!", errMsg);
				return status;
			}
			status = ProAsmcompAssemble((ProAssembly)topLevelMdl, (ProSolid)childMdl, asmPosList[i].pos, &asmFeat);  //source_comp_path
			mainLog.Write("ProAsmcompAssemble: " + to_string(status));
			if (status == PRO_TK_NO_ERROR){
				status = ProAsmcompConstraintsSet(NULL, &asmFeat, constraints);
				mainLog.Write("ProAsmcompConstraintsSet: " + to_string(status));
			}
		}
	}
	
	status = ProSolidRegenerate((ProSolid)topLevelMdl, PRO_REGEN_NO_FLAGS);
	mainLog.Write("ProSolidRegenerate: " + to_string(status));

	if(mdlCategory == SUB_MODULE)
	{
		//CREATE A NEW WINDOW FOR DRAWING
		int asm_win_id;
		status = ProObjectwindowMdlnameCreate(wNewAsmName, PRO_ASSEMBLY, &asm_win_id);
		mainLog.Write("ProObjectwindowMdlnameCreate: "+to_string(status) +"asm_win_id: " +to_string(asm_win_id));
		status = ProWindowCurrentSet(asm_win_id);
		mainLog.Write("ProWindowCurrentSet: "+to_string(status));
		status = ProWindowActivate(asm_win_id);
		mainLog.Write("ProWindowActivate: "+to_string(status));

		status = ProMdlDisplay(topLevelMdl);
		mainLog.Write("ProMdlDisplay: " + to_string(status));
	}
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);

	return status;
}

ProError asmToolDlgCloseAction(char* dialog, char* component, ProAppData data)
{
	mainLog.Write("================================== asmToolDlgCloseAction ==================================");
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}

// SUPPORTING FUNCTIONS
void getRowNameFromComponent(char *compName, char *rowName)
{
	mainLog.Write("================================== getRowNameFromComponent ==================================");
	size_t _pos;
	string sCompname = string(compName);
	_pos = sCompname.find_first_of('_');
	string sRowName = sCompname.substr(_pos+1);
	strcpy(rowName, sRowName.c_str());
}

bool isValidPositionMatrixFile(char *filePath, double (&positionMatrix)[4][4])
{
	ifstream posFile(filePath);  // Replace "data.txt" with your file path
	if (!posFile) {
		mainLog.Write("Failed to open position file!");
		return false;
	}
	string fLine;
	int count = 0;
	while (getline(posFile, fLine))
	{
		stringstream ss(fLine);
		string value;
		while(getline(ss, value, ','))
		{
			int iRow=0, iCol=0;
			istringstream iss(value);
			const regex positionValuePattern("[-+]?[0-9]*\\.?[0-9]+");
			if(regex_match(value, positionValuePattern))
			{
				size_t decimalPos = value.find('.');
				if (decimalPos != string::npos) {
					//mainLog.Write("++++++++++");
					// Calculate the number of characters after the decimal point
					size_t noOfCharsAfterDecimal = value.length() - decimalPos - 1;
					iss >> setprecision(noOfCharsAfterDecimal) >> positionMatrix[iRow][iCol];
					mainLog.Write("noOfCharsAfterDecimal = "+to_string(noOfCharsAfterDecimal)+"\tpositionMatrix["+to_string(iRow)+"]["+to_string(iCol)+"]=" );
					mainLog.WriteDouble(positionMatrix[iRow][iCol], noOfCharsAfterDecimal);	
				}
				else{
					//mainLog.Write("----------");
					positionMatrix[iRow][iCol] = atof(value.c_str());
					mainLog.Write("positionMatrix["+to_string(iRow)+"]["+to_string(iCol)+"]= " +to_string(positionMatrix[iRow][iCol]));
				}
				iCol++;
				if(iCol==4){
					iCol=0;
					iRow+=1;
				}
				count++;
			}
			else
				return false;
			
		}
	}
	posFile.close();
	return count == 16;  // Return true only if exactly 16 decimal values found
}

bool isAsmNameValid(string asmname)
{
	const regex subModulePatrn("^[0-9]{4}[a-zA-Z][0-9][a-zA-Z][0-9]{7}$");;
	return (regex_match(asmname, subModulePatrn));
}
bool isMatrixValid(const double matrix[4][4])
{
	for (int row = 0; row < 4; ++row) {
		for (int col = 0; col < 4; ++col) {
			// Check if any element is NaN or infinite
			if (isnan(matrix[row][col]) || isinf(matrix[row][col])) {
				return false;
			}
		}
	}
}
string toUpperCase(string str)
{
	for (auto & c: str) c = toupper(c);
	return str;
}

//ProError asm_mode_rg_action(char* dialog, char* component, ProAppData data)
//{
//	mainLog.Write("================================== asm_mode_rg_action ==================================");
//
//	int n_name;
//	char **rg_names;
//	status = ProUIRadiogroupSelectednamesGet(dialog, RG_ASM_MODE, &n_name, &rg_names);
//	//mainLog.Write("ProUIRadiogroupSelectednamesGet: " + to_string(status));
//
//	if(strcmp(rg_names[0], "new_asm") == 0){
//		_appMode = NEW_ASM;
//		status = ProUIInputpanelEnable(dialog, IP_NEW_ASM_NAME);
//
//		status = ProUIInputpanelValueSet(dialog, IP_NEW_ASM_NAME, wNewAsmName);
//		mainLog.Write("ProUIInputpanelValueSet  : " + to_string(status));
//
//		status = ProUIInputpanelReadOnly(dialog, IP_NEW_ASM_NAME);
//	}
//	else if(strcmp(rg_names[0], "exist_asm") == 0){
//		_appMode = EXIST_ASM;
//		status = ProUIInputpanelValueSet(dialog, IP_NEW_ASM_NAME, L"");
//		status = ProUIInputpanelDisable(dialog, IP_NEW_ASM_NAME);
//	}
//	return status;
//}
//void setOptionMenu(char *optMenuName, vector<pair<int, string>> &reqAsmNames)
//{
//	char** optMenuMdlNames;
//	wchar_t** optMenuMdlLabels;
//	status = ProArrayAlloc(reqAsmNames.size()+1, sizeof(char*), 1, (ProArray*)&optMenuMdlNames);
//	status = ProArrayAlloc(reqAsmNames.size()+1, sizeof(wchar_t*), 1, (ProArray*)&optMenuMdlLabels);
//
//	optMenuMdlNames[0] = (char*)calloc(PRO_NAME_SIZE, sizeof(char));
//	optMenuMdlLabels[0] = (wchar_t*)calloc(PRO_NAME_SIZE, sizeof(wchar_t));
//	strcpy(optMenuMdlNames[0], "empty");
//	wcscpy(optMenuMdlLabels[0], L"");
//	for (int i = 0; i < reqAsmNames.size(); ++i){
//		optMenuMdlNames[i+1] = (char*)calloc(PRO_NAME_SIZE, sizeof(char));
//		optMenuMdlLabels[i+1] = (wchar_t*)calloc(PRO_NAME_SIZE, sizeof(wchar_t));
//
//		ProTKSprintf(optMenuMdlNames[i+1], "%s", reqAsmNames[i].second);
//		ProStringToWstring(optMenuMdlLabels[i+1], optMenuMdlNames[i+1]);
//	}
//	status = ProUIOptionmenuNamesSet(DLG_ASM_TOOL, optMenuName, int(reqAsmNames.size()+1), optMenuMdlNames);
//	mainLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
//	status = ProUIOptionmenuLabelsSet(DLG_ASM_TOOL, optMenuName, int(reqAsmNames.size()+1), optMenuMdlLabels);
//	mainLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));
//
//	status = ProArrayFree((ProArray*)&optMenuMdlNames);
//	status = ProArrayFree((ProArray*)&optMenuMdlLabels);
//}
//ProError missingModlOptMenuSelectAction(char* dialog, char* component, ProAppData data)
//{
//	mainLog.Write("================================== missingModlOptMenuSelectAction ==================================");
//	size_t _pos;
//	string sCompname = string(component);
//	_pos = sCompname.find_first_of('_');
//	string sRowName = sCompname.substr(_pos+1);
//	char cPbName[PRO_NAME_SIZE];
//	ProTKSprintf(cPbName, "browsepb_%s", sRowName.c_str());
//
//	int nSels;
//	char **sels;
//	status = ProUIOptionmenuSelectednamesGet(dialog, component, &nSels, &sels);
//	if(strcmp(sels[0], "empty") != 0)
//		status = ProUIPushbuttonEnable(dialog, cPbName);
//	else
//		status = ProUIPushbuttonDisable(dialog, cPbName);
//
//	return status;
//}

#pragma pop