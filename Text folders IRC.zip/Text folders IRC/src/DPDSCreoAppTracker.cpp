#include<DPDSCreoAppTracker.h>

//FILE* fpp;

std::ofstream fpp;

//Name 		: Logger
//In		: Message of failure (string), Error status of failure by API (ProError)
//Out		: NIL
//Purpose	: To update log file based on result of executed command
//Author	: Ketan Lalcheta
void Logger(string strMsg, ProError status)
{
	int intStatus = (int)status;
	stringstream convert;
	convert << intStatus;
	string strStatus = convert.str();

	ofstream myfile;
	myfile.open("TrackingLog.txt", ios::app);
	myfile << strMsg << strStatus << "\n";

	
}

//Name 		: GetContactFileNames
//In		: Folder name in which to search for (string)
//Out		: All the file names in folder having desired i.e. "*.contact" extenstion (vector<string>)
//Purpose	: To get required file names (.contact) present into directory
//Author	: Ketan Lalcheta
vector<string> GetContactFileNames(string strFolderName)
{
	//Initialize vector
	vector<string> vectFileNames;
	string strFunctionName = "GetFileNamesOfHoleTolerance--->";

	try
	{
		//initialize what to serach
		string strSerachPath = strFolderName + "/*.contact";

		//Serach for first file
		WIN32_FIND_DATA objFindData;
		HANDLE hFind = ::FindFirstFile(strSerachPath.c_str(), &objFindData);

		if (hFind != INVALID_HANDLE_VALUE)
		{
			//Loop through all files
			do
			{
				if (!(objFindData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY))
				{
					string strFullName = objFindData.cFileName;
					if (strFullName.find(".contact") != std::string::npos)
					{
						size_t found = strFullName.find(".contact");
						strFullName = strFullName.substr(0, found);
						replace(strFullName.begin(), strFullName.end(), ',', ' ');

						fpp.open("C:\\tmp\\TrackingLog.txt", ios::app);
						fpp << "GetContactFileNames" << "\n";
					}
					vectFileNames.push_back(strFullName);
				}
			} while (::FindNextFile(hFind, &objFindData));

			//Close handle
			::FindClose(hFind);
		}
	}
	catch (...)
	{
		Logger(strFunctionName + "issue found in file search ", PRO_TK_NO_ERROR);
	}


	//Return vector of file names
	return vectFileNames;
}

//Name 		: GetApplicationUserName
//In		: As Ref : current user id (string) , As Ref : current user name (string)
//Out		: NIL
//Purpose	: To get current user id and current user name
//Author	: Ketan Lalcheta
bool GetApplicationUserName(string &strUserID, string &strUserName)
{
	//initialization
	string strFunctionName = "GetApplicationSystemName--->";

	strUserID = "";
	strUserName = "";

	//Get user ID
	try
	{
		TCHAR objUserID[UNLEN + 1];
		DWORD objsize = UNLEN + 1;

		if (GetUserName((TCHAR*)objUserID, &objsize))
		{
			strUserID = objUserID;

			fpp.open("C:\\tmp\\TrackingLog.txt", ios::app);
			fpp << "GetApplicationUserName" << "\n";
		}
	}
	catch (...)
	{
		Logger(strFunctionName + "issue found in getting user ID is ", PRO_TK_GENERAL_ERROR);
		return false;
	}

	//Get user name
	try
	{
		//Get directory to search for contact file (.contact)
		string strFolderPath = "C:\\Users\\" + strUserID + "\\Contacts";

		//Get file names
		vector<string> vectFileNames = GetContactFileNames(strFolderPath);

		//Get user Name
		if (vectFileNames.size()>0)
		{
			strUserName = vectFileNames[0];
		}
	}
	catch (...)
	{
		Logger(strFunctionName + "issue found in getting user name is ", PRO_TK_GENERAL_ERROR);
		return false;
	}

	return true;
}

//Name 		: GetApplicationSystemName
//In		: As Ref : current system name (string)
//Out		: True if succed for getting system details else false (bool)
//Purpose	: To get current system name
//Author	: Ketan Lalcheta
bool GetApplicationSystemName(string &strSystemName)
{
	//initialization
	string strFunctionName = "GetApplicationSystemName--->";

	strSystemName = "";
	try
	{
		TCHAR objSystemName[MAX_COMPUTERNAME_LENGTH + 2];
		DWORD objsize = MAX_COMPUTERNAME_LENGTH + 2;

		if (GetComputerName((TCHAR*)objSystemName, &objsize))
		{
			strSystemName = objSystemName;
			fpp.open("C:\\tmp\\TrackingLog.txt", ios::app);
			fpp << "GetApplicationSystemName" << "\n";
		}
	}
	catch (...)
	{
		Logger(strFunctionName + "issue found in system name is ", PRO_TK_GENERAL_ERROR);
		return false;
	}

	return true;
}

//Name 		: GetCurrentDateTime
//In		: As Ref : current Date (string), As Ref : Current time (string)
//Out		: True if succed for getting date and time details else false (bool)
//Purpose	: To get current date and time
//Author	: Ketan Lalcheta
bool GetCurrentDateTime(string &strFullDate, string &strFullTime)
{
	//initialization
	string strFunctionName = "GetCurrentDateTime--->";

	//Current time object as structure object
	time_t objTimeNow;
	struct tm  tstruct;
	try
	{
		objTimeNow = time(0);
		tstruct = *localtime(&objTimeNow);
		fpp.open("C:\\tmp\\TrackingLog.txt", ios::app);
		fpp << "GetCurrentDateTime" << "\n";

	}
	catch (...)
	{
		Logger(strFunctionName + "issue found in getting time object as structure is ", PRO_TK_GENERAL_ERROR);
		return false;
	}

	//Get details from structure of time
	int intYear = (tstruct.tm_year + 1900);
	int intMonth = (tstruct.tm_mon + 1);
	int intDay = (tstruct.tm_mday);
	int intHour = (tstruct.tm_hour);
	int intMin = (tstruct.tm_min);
	int intSec = (tstruct.tm_sec);

	//Prepare month in proper format from integer
	string strMonth = "";
	if (intMonth == 1) { strMonth = "January"; }
	else if (intMonth == 2) { strMonth = "February"; }
	else if (intMonth == 3) { strMonth = "March"; }
	else if (intMonth == 4) { strMonth = "April"; }
	else if (intMonth == 5) { strMonth = "May"; }
	else if (intMonth == 6) { strMonth = "June"; }
	else if (intMonth == 7) { strMonth = "July"; }
	else if (intMonth == 8) { strMonth = "August"; }
	else if (intMonth == 9) { strMonth = "September"; }
	else if (intMonth == 10) { strMonth = "October"; }
	else if (intMonth == 11) { strMonth = "November"; }
	else if (intMonth == 12) { strMonth = "December"; }

	//Prepare date string
	try
	{
		//strFullDate = to_string((long double)intDay) + "-" + strMonth + "-" + to_string((long double)intYear);

		stringstream ssDay;
		ssDay << intDay;
		string strDay = ssDay.str();

		stringstream ssYear;
		ssYear << intYear;
		string strYear = ssYear.str();

		strFullDate = strDay + "-" + strMonth + "-" + strYear;
	}
	catch (...)
	{
		Logger(strFunctionName + "issue found in preparation of date string is ", PRO_TK_GENERAL_ERROR);
		return false;
	}

	//Prepare time string
	try
	{
		//strFullTime = to_string((long double)intHour)+ ":" + to_string((long double)intMin) + ":"+ to_string((long double)intSec);

		stringstream ssHour;
		ssHour << intHour;
		string strHour = ssHour.str();

		stringstream ssMin;
		ssMin << intMin;
		string strMin = ssMin.str();

		stringstream ssSec;
		ssSec << intSec;
		string strSec = ssSec.str();

		strFullTime = strHour + ":" + strMin + ":" + strSec;
	}
	catch (...)
	{
		Logger(strFunctionName + "issue found in preparation of time string is ", PRO_TK_GENERAL_ERROR);
		return false;
	}

	return true;
}

//Name 		: GetTrackingInfo
//In		: Application name (_enmAppName), sub application name (_enmSubAppName), application status (_enmAppStatus)
//Out		: True if succed for writting tracking details else false (bool)
//Purpose	: To write tracking details of DPDS customized applications
//Author	: Ketan Lalcheta
bool GetTrackingInfo(_enmAppName enmAppName, _enmSubAppName enmSubAppName, _enmAppStatus enmAppStatus)
{
	//initialization
	string strFunctionName = "GetTrackingInfo--->";
	bool IsOK;

	fpp.open("C:\\tmp\\TrackingLog_01.txt", ios::app);
	fpp << "GetTrackingInfo" << endl;

#pragma region ServerInfo
	//Get toolkit exe path
	ProPath objTextPath;
	ProError status = ProToolkitApplTextPathGet(objTextPath);
	
	fpp << "ProToolkitApplTextPathGet = " << status <<endl;
	//Convert toolkit exe path to char*
	ProCharPath chrTextPath;
	try
	{
		ProWstringToString(chrTextPath, objTextPath);
		fpp << "chrTextPath" << endl;
	}
	catch (...)
	{
		Logger(strFunctionName + "issue found in conversion of text folder path from wstring to string is ", PRO_TK_GENERAL_ERROR);
		fpp << "strFunctionName = " << endl;
		return false;
	}

	string strFullFilePath = string(chrTextPath);
	if (!strFullFilePath.empty()) {
		strFullFilePath.erase(strFullFilePath.size() - 22);
	}

	//Truncate last directory and replace it with DPDCreoSPT
	fpp << "strFullFilePath = " << strFullFilePath << endl;
	strFullFilePath = strFullFilePath + "DPDSCreoSPT\\ServerLocation.txt";
	fpp << "strFullFilePath = " << strFullFilePath << endl;

	//File name with full path ******* old *******
	//string strFullFilePath = string(chrTextPath) + "\\ServerLocation.txt";

	//File for server location
	ifstream objServerLocationFile(strFullFilePath);

	//Check whether file is opened or not
	string strServerLocation = "";
	if (objServerLocationFile.is_open())
	{
		string strLine;
		string strKeyword = "::DPDS::";
		string strServerPathTemp = "";
		string strFlagForServer = "";
		while (getline(objServerLocationFile, strLine))
		{
			//Check if keyword is found
			size_t intPos = strLine.find(strKeyword);
			if (intPos != string::npos)
			{
				strFlagForServer = strLine.substr(0, intPos);
				strServerPathTemp = strLine.substr(intPos + strKeyword.length(), strLine.length() - intPos - strKeyword.length());

				//If flag in Y
				if (strFlagForServer == "Y" || strFlagForServer == "y")
				{
					strServerLocation = strServerPathTemp;
					fpp << "strServerLocation " << endl;
					break;
				}
			}
		}
		//Close file
		objServerLocationFile.close();
		fpp << "objServerLocationFile "  << endl;
	}
	else
	{
		//File is not found and hence we are not doing tracking
		return true;
	}

	//If server location is NULL or empty, return without tracking
	if (strServerLocation == "" || strServerLocation == "NULL" || strServerLocation == "null")
	{
		fpp << "server Null " << endl;
		return true;
	}

#pragma endregion
	//Remove log file to avoid overwrite
	remove("TrackingLog.txt");

	fpp << "App detail " << endl;
	//Convert application name from enum to string
	string strAppName;
	try
	{
		strAppName = AppNameStrings[enmAppName];
		fpp << "strAppName =  " << strAppName << endl;
		
	}
	catch (...)
	{
		Logger(strFunctionName + "issue found in conversion of application name from enum to string is ", PRO_TK_GENERAL_ERROR);
		fpp << "Logger " << endl; 
		return false;
	}

	//Convert sub application name from enum to string
	string strSubAppName;
	try
	{
		strSubAppName = SubAppNameStrings[enmSubAppName];
		fpp << "strSubAppName = " << strSubAppName<<endl;
	}
	catch (...)
	{
		Logger(strFunctionName + "issue found in conversion of sub application name from enum to string is ", PRO_TK_GENERAL_ERROR);
		fpp << "Logger"<< endl;
		return false;
	}

	//Convert sub application status from enum to string
	string strAppStatus;
	try
	{
		strAppStatus = AppStatusStrings[enmAppStatus];
		fpp << "strAppStatus = " << strAppStatus << endl;
	}
	catch (...)
	{
		Logger(strFunctionName + "issue found in conversion of application status from enum to string is ", PRO_TK_GENERAL_ERROR);
		fpp << "Logger" << endl; 
		return false;
	}

	//Get current date time
	string strFullDate = "";
	string strFullTime = "";
	IsOK = GetCurrentDateTime(strFullDate, strFullTime);
	if (!IsOK)
	{
		Logger(strFunctionName + "issue found in GetCurrentDateTime is ", PRO_TK_GENERAL_ERROR);
		return false;
	}

	//Get user name
	string strUserID = "";
	string strUserName = "";
	IsOK = GetApplicationUserName(strUserID, strUserName);
	if (!IsOK)
	{
		Logger(strFunctionName + "issue found in GetApplicationUserName is ", PRO_TK_GENERAL_ERROR);
		return false;
	}

	//Get system name
	string strSystemName = "";
	IsOK = GetApplicationSystemName(strSystemName);
	if (!IsOK)
	{
		Logger(strFunctionName + "issue found in GetApplicationSystemName is ", PRO_TK_GENERAL_ERROR);
		return false;
	}

	//OPen file to write details
	ofstream myfile;
	try
	{
		//string strTrackFile = "\\\\172.22.99.39\\startparttemplate\\TrackerDataCSV_" + strSystemName + ".csv"; // Location other than HNJ
		//string strTrackFile = "\\\\hnjlicsrv03.tatatechnologies.com\\WF5.0_Upgrade\\startparttemplate\\TrackerDataCSV_" + strSystemName + ".csv"; // Location HNJ
		string strTrackFile = strServerLocation + strSystemName + ".csv"; // Common code

		myfile.open(strTrackFile, std::ofstream::app);
		if (myfile.is_open())
		{
			myfile << strAppName << "," << strSubAppName << "," << strUserID << "," << strUserName << "," << strAppStatus << "," << strSystemName << "," << strFullDate << "," << strFullTime << "\n";
		}
		else
		{
			Logger(strFunctionName + "app name is " + strAppName + " ", PRO_TK_GENERAL_ERROR);//strAppName
			Logger(strFunctionName + "sub app name is " + strSubAppName + " ", PRO_TK_GENERAL_ERROR);//strSubAppName
			Logger(strFunctionName + "user id is " + strUserID + " ", PRO_TK_GENERAL_ERROR);//strUserID
			Logger(strFunctionName + "user name is " + strUserName + " ", PRO_TK_GENERAL_ERROR);//strUserName
			Logger(strFunctionName + "app status is " + strAppStatus + " ", PRO_TK_GENERAL_ERROR);//strAppStatus
			Logger(strFunctionName + "system is " + strSystemName + " ", PRO_TK_GENERAL_ERROR);//system name
			Logger(strFunctionName + "date is " + strFullDate + " ", PRO_TK_GENERAL_ERROR);//strFullDate
			Logger(strFunctionName + "time is " + strFullTime + " ", PRO_TK_GENERAL_ERROR);//strFullTime
			Logger(strFunctionName + "issue found in opening tracking file to write is ", PRO_TK_GENERAL_ERROR);
			return false;
		}
	}
	catch (...)
	{
		Logger(strFunctionName + "app name is " + strAppName + " ", PRO_TK_GENERAL_ERROR);//strAppName
		Logger(strFunctionName + "sub app name is " + strSubAppName + " ", PRO_TK_GENERAL_ERROR);//strSubAppName
		Logger(strFunctionName + "user id is " + strUserID + " ", PRO_TK_GENERAL_ERROR);//strUserID
		Logger(strFunctionName + "user name is " + strUserName + " ", PRO_TK_GENERAL_ERROR);//strUserName
		Logger(strFunctionName + "app status is " + strAppStatus + " ", PRO_TK_GENERAL_ERROR);//strAppStatus
		Logger(strFunctionName + "system is " + strSystemName + " ", PRO_TK_GENERAL_ERROR);//system name
		Logger(strFunctionName + "date is " + strFullDate + " ", PRO_TK_GENERAL_ERROR);//strFullDate
		Logger(strFunctionName + "time is " + strFullTime + " ", PRO_TK_GENERAL_ERROR);//strFullTime
		Logger(strFunctionName + "issue found in opening tracking file to write is ", PRO_TK_GENERAL_ERROR);
		return false;
	}

	//close file
	try
	{
		myfile.close();
		fpp.close();
	}
	catch (...)
	{
		Logger(strFunctionName + "app name is " + strAppName + " ", PRO_TK_GENERAL_ERROR);//strAppName
		Logger(strFunctionName + "sub app name is " + strSubAppName + " ", PRO_TK_GENERAL_ERROR);//strSubAppName
		Logger(strFunctionName + "user id is " + strUserID + " ", PRO_TK_GENERAL_ERROR);//strUserID
		Logger(strFunctionName + "user name is " + strUserName + " ", PRO_TK_GENERAL_ERROR);//strUserName
		Logger(strFunctionName + "app status is " + strAppStatus + " ", PRO_TK_GENERAL_ERROR);//strAppStatus
		Logger(strFunctionName + "system is " + strSystemName + " ", PRO_TK_GENERAL_ERROR);//system name
		Logger(strFunctionName + "date is " + strFullDate + " ", PRO_TK_GENERAL_ERROR);//strFullDate
		Logger(strFunctionName + "time is " + strFullTime + " ", PRO_TK_GENERAL_ERROR);//strFullTime
		Logger(strFunctionName + "issue found in closing tracking file after writing is ", PRO_TK_GENERAL_ERROR);
		return false;
	}

	return true;
}

//Name 		: NotifyUserForTracking
//In		: NIL
//Out		: Status of API (ProError)
//Purpose	: To notify user using UI
//Author	: Ketan Lalcheta
ProError NotifyUserForTracking()
{
	//initialization
	ProError status = PRO_TK_GENERAL_ERROR;
	string strFunctionName = "NotifyUserForTracking--->";

	//message string
	string strMessage = "Please provide """"TrackingLog.txt"""" file from working directory to DPDS KBE team and call on 2049";

	//Allocate button array
	ProUIMessageButton* objArrButtons;
	status = ProArrayAlloc(1, sizeof(ProUIMessageButton), 1, (ProArray*)&objArrButtons);
	if (status != PRO_TK_NO_ERROR)
	{
		Logger(strFunctionName + "issue in allocation of button array is ", status);
		return status;
	}
	objArrButtons[0] = PRO_UI_MESSAGE_OK;

	//Convert message from string to wstring
	ProPath objMessage;
	try
	{
		ProStringToWstring(objMessage, (char*)strMessage.c_str());
	}
	catch (...)
	{
		Logger(strFunctionName + "issue in conversion of user message from string to wstring is ", status);
		return status;
	}

	//Display message
	ProUIMessageButton objButton_UserChoice;
	wchar_t* objDialogTitle = L"DPDS Tracking";
	status = ProUIMessageDialogDisplay(PROUIMESSAGE_ERROR, objDialogTitle, objMessage, objArrButtons, PRO_UI_MESSAGE_OK, &objButton_UserChoice);
	if (status != PRO_TK_NO_ERROR)
	{
		Logger(strFunctionName + "issue in message display to user is ", status);
		return status;
	}

	//Free memory of button array
	status = ProArrayFree((ProArray*)&objArrButtons);
	if (status != PRO_TK_NO_ERROR)
	{
		Logger(strFunctionName + "issue in free of button array is ", status);
		return status;
	}

	return status;
}