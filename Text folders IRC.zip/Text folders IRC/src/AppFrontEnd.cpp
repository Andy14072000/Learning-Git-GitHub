/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-12-2021	|	V1_0_0		| FRONT END UPDATED
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)

#include "AppFrontEnd.h"

// GLOBAL DECLARATIONS
bool submitToPlmEnable;
ProParameter n_fail_parameter;
vector<string> subModuleNames; // SUB MODULES IN THE OPENED ASM
vector<SubModuleInfo> subModulesListOG /*with duplicates*/, subModulesList /*global sub-module list*/;
vector<RuleInfo> rulesList;	/*global rules list*/
vector<RuleInfo*> subModuleRulesList;	// temp rules list for CP items
vector<vector<string>> rulesMapData;
LogFile ruleLog;
size_t _pos;
ModelCategory _openedMdlCategory = DEFAULT_CAT;
const regex cpPattern("([0-9][0-9]CHA|BIW|TRI|EAE|POW|UPB|UDB)"), subModulePattern("([a-zA-Z][0-9][a-zA-Z][0-9][0-9]?)+"),
dummyPattern("DUMMY_[0-9][0-9][0-9][0-9][a-zA-Z][0-9][[a-zA-Z][0-9][0-9][0-9][0-9][0-9][0-9][0-9]");
SubModuleInfo listUIfirstSMinfo;

// UI COMPONENTS
string sPbName, sCompName, sRowName;
char cRowName[PRO_NAME_SIZE], cSubModuleName[PRO_NAME_SIZE];
wchar_t w_cellLabel[PRO_PATH_SIZE];
char c_cellLabel[PRO_PATH_SIZE];
// declared with extern in AppFrontEnd.h
char stsCellLabel[PRO_NAME_SIZE] = "        -", stsCellLabelPass[PRO_NAME_SIZE] = "  Pass", stsCellLabelFail[PRO_NAME_SIZE] = "  Fail",
stsCellLabelDeviation[PRO_NAME_SIZE] = "  Deviation", stsCellLabelManualCheck[PRO_NAME_SIZE] = "Manual-check";
ModelCategory mdlCategory1;

int AppFrontEnd::initialize()
{
	mainLog.Write("================================ AppFrontEnd::initialize() ================================");
	

	subModuleNames.clear();	// forget the list of sub-modules opened before
	mainLog.Write("PROE_TML_STD_PATH: " + string(PROE_TML_STD_PATH));

	status = ProMdlCurrentGet(&curMdl);
	if (status != PRO_TK_NO_ERROR){
		mainLog.Write("err \tProMdlCurrentGet: "+to_string(status));
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING,"Invalid File!", "Please open an Assembly model");
		return -1;
	}
	ProMdlType curMdlType;
	status = ProMdlTypeGet(curMdl, &curMdlType);
	if (curMdlType != PRO_MDL_ASSEMBLY){
		mainLog.Write("err \tmdl_type: "+to_string(curMdlType));
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING,"Invalid File!", "Please open an Assembly model");
		return -1;
	}

	status = ProMdlMdlnameGet(curMdl, wCurMdlName);
	ProWstringToString(cCurMdlName, wCurMdlName);
	mainLog.Write("cCurMdlName: " + string(cCurMdlName));

	status = ProMdlToModelitem(curMdl, &curMdlitem);
	mainLog.Write("ProMdlToModelitem: " + to_string(status));

	status = ProToolkitApplTextPathGet(wTextPath);
	ProWstringToString(cTextPath, wTextPath);
	mainLog.Write("cTextPath: " + string(cTextPath));

	// RULES MAP DATA
	char rulesMapPath[PRO_PATH_SIZE];
	ProTKSprintf(rulesMapPath, "%s%s", PROE_TML_STD_PATH, "\\irc_application\\app_db\\rules_map.csv");
	mainLog.Write("rulesMapPath: " + string(rulesMapPath));
	//ProTKSprintf(rulesMapPath, "%s%s", cTextPath, "\\text\\usascii\\resource\\db\\rules_map.csv");
	//ProTKSprintf(rulesMapPath, "%s", "K:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\app_db\\rules_map.csv");
	//ProTKSprintf(rulesMapPath, "%s", "C:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\app_db\\rules_map.csv");
	FileParser _rulesMapReader(rulesMapPath, ',');
	_rulesMapReader.getData2D(rulesMapData);
	//mainLog.Write("rulesMapData.size(): " + to_string(rulesMapData.size()));

	// ================================ CREATE RESOURCES DIRECTORY FOR REPORT ================================
	status = ProDirectoryCurrentGet(wCurDirPath);
	//mainLog.Write("ProDirectoryCurrentGet: " + to_string(status));
	ProWstringToString(cCurDirPath, wCurDirPath);
	mainLog.Write("cCurDirPath: " + string(cCurDirPath));

	char cResourcePath[PRO_PATH_SIZE];
	ProTKSprintf(cResourcePath,"%sreport_res_db", cCurDirPath);
	mainLog.Write("cResourcePath[xml res]: " + string(cResourcePath));

	ProTKSprintf(rulesMapPath, "%s%s", PROE_TML_STD_PATH, "\\irc_application\\app_db\\rules_map.csv");
	string sourcePath = string(PROE_TML_STD_PATH) + "\\irc_application\\report_res_db";
	_utils.copyDirectory(sourcePath.c_str(), cResourcePath);

	//copy to tmp
	char cResourcePath2[PRO_PATH_SIZE] = "C:\\tmp\\report_res_db";
	_utils.copyDirectory(sourcePath.c_str(), cResourcePath2);

	// ================================ CHECK THE CATEGORY OF OPENED ASM ================================
	string subModAddress = string(cCurMdlName).substr(4,5);
	int rule_sno = 0;	// top level s no

	// ================================ SUB-MODULE ================================
	if(regex_match(subModAddress, subModulePattern))
	{
		mainLog.Write("Opened asm is SUB-MODULE");
		_openedMdlCategory = SUB_MODULE;

		ProParamvalue param_value;
		//ProParameter parameter;
		param_value.type = PRO_PARAM_BOOLEAN;
		param_value.value.l_val = 1;
		status = ProParameterWithUnitsCreate(&curMdlitem, L"N_Failed_Rule", &param_value, NULL, &n_fail_parameter);
		mainLog.Write("ProParameterCreate: " + status);
		if (status != PRO_TK_NO_ERROR) {
			mainLog.Write("Error creating parameter\n");
			//return -1;
		}

		SubModuleInfo _SMinfo;
		_SMinfo.sno = 1;
		_SMinfo.name =cCurMdlName;
		extractRuleNames(cCurMdlName, _SMinfo.rule_names_list);
		_SMinfo.rules_count = _SMinfo.rule_names_list.size();
		subModulesListOG.push_back(_SMinfo);

		fetchRuleInfo(_SMinfo, rulesList);
		mainLog.Write("No. of Rules: " + to_string(rulesList.size()));

		// UPDATE S NO
		for(int k = 0; k<rulesList.size(); ++k){	// both s.nos are same incase of sub-module
			rulesList[k].sno = k+1;
			rulesList[k].lib_sno = k+1;
		}

		strcpy(cSubModuleName, _SMinfo.name.c_str());

		//Changes made by himanshu
		//-----------------------------------------------------
		mainLog.Write("SubModule: " + string(cSubModuleName));
		char con_SubMod_name[PRO_PATH_SIZE];
		revision_extraction_from_txr(cSubModuleName, con_SubMod_name);
		mainLog.Write("con_SubMod_name: " + string(con_SubMod_name));
		//-----------------------------------------------------

		sqlRes = createSQLtbl(_SMinfo.rule_names_list, con_SubMod_name);
		mainLog.Write("createSQLtbl ["+ string(con_SubMod_name) + "]= " + to_string(sqlRes));

		listUIfirstSMinfo = _SMinfo;	// set listUIfirstSMinfo to the opened sub-module's info

		// Add DR Status parameter
		status=DRStatus_creation(curMdlitem);

		createUIDialog();	// create the UI
		return 0;
	}

	// ================================ CP ITEM ================================
	if(regex_match(subModAddress, cpPattern))
	{
		mainLog.Write("Opened asm is CP-ITEM");
		_openedMdlCategory = CP_ITEM;

		// FIND THE CP ITEM CATEGORY
		/*int designGrp = stoi(subModAddress.substr(0,2));
		mainLog.Write("designGrp: " + to_string(designGrp));
		string cpItemName = "";
		char designGrpFilePath[PRO_PATH_SIZE];
		ProTKSprintf(designGrpFilePath, "%s%s", cTextPath, "\\text\\usascii\\resource\\db\\design_group.csv");
		FileParser _csvReader(designGrpFilePath, ",");
		vector<vector<string>> designGroupData;
		_csvReader.getData2D(designGroupData, ',');
		for (int i=0; i<designGroupData.size(); ++i){
			if(stoi(designGroupData[i][0]) == designGrp){
				cpItemName = designGroupData[i][1];
				break;
			}
		}
		designGroupData.clear();*/

		// EXTRACT THE SUB-MODULES
		status = ProSolidFeatVisit((ProSolid)curMdl, submodule_retrieve_callback, NULL, NULL);
		mainLog.Write("Total No. of Sub-modules: " + to_string(subModuleNames.size()));

		if(status == PRO_TK_NO_ERROR && subModuleNames.size()>0)
		{
			rule_sno = 0;
			for (int i = 0; i < subModuleNames.size(); ++i)
			{
				mainLog.Write("subModuleName: "+subModuleNames[i]);

				SubModuleInfo _SMinfo;
				_SMinfo.sno = i+1;
				_SMinfo.name = subModuleNames[i];
				extractRuleNames(subModuleNames[i], _SMinfo.rule_names_list);
				_SMinfo.rules_count = _SMinfo.rule_names_list.size();
				subModulesListOG.push_back(_SMinfo);

				vector<RuleInfo> tempRulesList;	// created for sorting purpose
				fetchRuleInfo(_SMinfo, tempRulesList);

				// UPDATE S NO
				for(int k =0; k<tempRulesList.size(); ++k){
					tempRulesList[k].sno = rule_sno+1;
					tempRulesList[k].lib_sno = k+1;
					rule_sno++;
				}
				for(auto item : tempRulesList)	// add the sorted items to main vector
					rulesList.push_back(item);
				tempRulesList.clear();

				strcpy(cSubModuleName, _SMinfo.name.c_str());

				//===============================================================
				// To get a applicable submodule and create parameter
				wchar_t wSubModuleName[PRO_NAME_SIZE];
				ProMdl cSubModuleMdl;
				ProModelitem cSubModuleMdlItem;
				ProStringToWstring(wSubModuleName, cSubModuleName);
				status = ProMdlnameInit(wSubModuleName, PRO_MDLFILE_ASSEMBLY, &cSubModuleMdl);
				mainLog.Write("ProMdlnameInit: " + to_string(status));
				if (status != PRO_TK_NO_ERROR) {
					mainLog.Write("ProMdlToModelitem get Failed: ");
					return -1;
				}
				status = ProMdlToModelitem(cSubModuleMdl, &cSubModuleMdlItem);
				mainLog.Write("ProMdlToModelitem: " + to_string(status));


				ProParamvalue param_value;
				param_value.type = PRO_PARAM_BOOLEAN;
				param_value.value.l_val = 1;
				status = ProParameterWithUnitsCreate(&cSubModuleMdlItem, L"N_Failed_Rule", &param_value, NULL, &n_fail_parameter);
				mainLog.Write("ProParameterWithUnitsCreate: " + status);
				if (status != PRO_TK_NO_ERROR) {
					mainLog.Write("Error creating parameter\n");
				}

				//=========================================================
				// Add DR Status parameter
				status = DRStatus_creation(cSubModuleMdlItem);

				//Changes made by himanshu
				//-----------------------------------------------------
				mainLog.Write("SubModule: " + string(cSubModuleName));
				char con_SubMod_name[PRO_PATH_SIZE];
				revision_extraction_from_txr(cSubModuleName, con_SubMod_name);
				mainLog.Write("con_SubMod_name: " + string(con_SubMod_name));
				//-----------------------------------------------------

				sqlRes = createSQLtbl(_SMinfo.rule_names_list, con_SubMod_name);
				mainLog.Write("createSQLtbl ["+ string(con_SubMod_name) + "]= " + to_string(sqlRes));
			}
			/*for(auto item : rulesList)
				mainLog.Write("lib_sno: " + to_string(item.lib_sno) + "\tid: " + item.id + "\tisDigitisable: "+(to_string(item.IsDigitizable)));*/
			mainLog.Write("Total No. of Rules: " + to_string(rulesList.size()));
			subModuleNames.clear();

			createUIDialog();	// create the UI
		}
		else
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING,"Warning", "Please check the sub-module(s) present under the current assembly.");
		
		return 0;
	}

	// ================================ DUMMY MDL ================================
	if(regex_match(cCurMdlName, dummyPattern))
	{
		mainLog.Write("Opened asm is Dummy model");
		_openedMdlCategory = DUMMY;
		// EXTRACT THE SUB-MODULES
		status = ProSolidFeatVisit((ProSolid)curMdl, submodule_retrieve_callback, NULL, NULL);
		mainLog.Write("Total No. of Sub-modules: " + to_string(subModuleNames.size()));

		if(status == PRO_TK_NO_ERROR && subModuleNames.size()>0)
		{

			rule_sno = 0;
			for (int i = 0; i < subModuleNames.size(); ++i)
			{
				mainLog.Write("subModuleName: "+subModuleNames[i]);
				SubModuleInfo _SMinfo;
				_SMinfo.sno = i+1;
				_SMinfo.name = subModuleNames[i];
				extractRuleNames(subModuleNames[i], _SMinfo.rule_names_list);
				_SMinfo.rules_count = _SMinfo.rule_names_list.size();
				subModulesListOG.push_back(_SMinfo);

				// get the sub-module(dummy) for creating UI
				if(string(cCurMdlName).substr(6).compare(subModuleNames[i]) == 0)
					listUIfirstSMinfo = _SMinfo;
			}
			fetchRuleInfo(listUIfirstSMinfo, rulesList);	// fetch only the rules for dummy sub-module.

			// UPDATE S NO
			for(int k =0; k<rulesList.size(); ++k){	// both are same if only sub-module/dummy asm
				rulesList[k].sno = k+1;
				rulesList[k].lib_sno = k+1;
			}
			strcpy(cSubModuleName, listUIfirstSMinfo.name.c_str());

			//===============================================================
			// To get a applicable submodule and create parameter
			wchar_t wSubModuleName[PRO_NAME_SIZE];
			ProMdl cSubModuleMdl;
			ProModelitem cSubModuleMdlItem;
			ProStringToWstring(wSubModuleName, cSubModuleName);
			status = ProMdlnameInit(wSubModuleName, PRO_MDLFILE_ASSEMBLY, &cSubModuleMdl);
			mainLog.Write("ProMdlnameInit: " + to_string(status));
			if (status != PRO_TK_NO_ERROR) {
				mainLog.Write("ProMdlToModelitem get Failed: ");
				return -1;
			}
			status = ProMdlToModelitem(cSubModuleMdl, &cSubModuleMdlItem);
			mainLog.Write("ProMdlToModelitem: " + to_string(status));

			ProParamvalue param_value;
			param_value.type = PRO_PARAM_BOOLEAN;
			param_value.value.l_val = 1;
			status = ProParameterWithUnitsCreate(&cSubModuleMdlItem, L"N_Failed_Rule", &param_value, NULL, &n_fail_parameter);
			mainLog.Write("ProParameterCreate: " + status);
			if (status != PRO_TK_NO_ERROR) {
				mainLog.Write("Error creating parameter\n");
			}
			//=========================================================

			//Changes made by himanshu
				//-----------------------------------------------------
			mainLog.Write("SubModule: " + string(cSubModuleName));
			char con_SubMod_name[PRO_PATH_SIZE];
			revision_extraction_from_txr(cSubModuleName, con_SubMod_name);
			mainLog.Write("con_SubMod_name: " + string(con_SubMod_name));
			//-----------------------------------------------------

			sqlRes = createSQLtbl(listUIfirstSMinfo.rule_names_list, con_SubMod_name);
			mainLog.Write("createSQLtbl ["+ string(con_SubMod_name) + "]= " + to_string(sqlRes));

			mainLog.Write("No. of Rules: " + to_string(rulesList.size()));
			subModuleNames.clear();


			// Add DR Status parameter
			status = DRStatus_creation(cSubModuleMdlItem);

			createUIDialog();	// create the UI
		}
		else{
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING,"Warning", "Please check the sub-module(s) present under the current assembly.");
		}
		return 0;
	}
	// IF NOT THE DESIRED CATEGORY
	_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING,"Invalid File!", "Please open a CP-item/ Sub-module/ Dummy-Assembly for verifying the Interface rules.");
	return -1;
}

void AppFrontEnd::createUIDialog()
{
	mainLog.Write("================================ AppFrontEnd::createUIDialog ================================");

	// CREATE DLG_IRC_MAIN
	status = ProUIDialogCreate(DLG_IRC_MAIN, DLG_IRC_MAIN);
	mainLog.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(DLG_IRC_MAIN, PRO_B_FALSE);
	status = ProUIPushbuttonActivateActionSet(DLG_IRC_MAIN, PB_CLOSE, (ProUIAction)main_close_pb_action, NULL);
	status = ProUIPushbuttonActivateActionSet(DLG_IRC_MAIN, PB_REPORT, (ProUIAction)report_pb_action, NULL);
	//status = ProUIPushbuttonDisable(DLG_IRC_MAIN, PB_PLM_SUBMIT);
	status = ProUIPushbuttonActivateActionSet(DLG_IRC_MAIN, PB_PLM_SUBMIT, (ProUIAction)submitPLM_pb_action, NULL);
	status = ProUITabSelectActionSet(DLG_IRC_MAIN, DLG_TAB, (ProUIAction)tab_action, NULL);

	// SET ASM NAME
	status = ProUILabelTextSet(DLG_IRC_MAIN, LBL_ASM_NAME, wCurMdlName);

	// SET DESCRIPTION
	ProParameter paramDesc;
	ProParamvalue paramvalDesc;
	ProUnititem paramunitDesc;
	char cParamVal[PRO_PATH_SIZE];
	status = ProParameterInit(&curMdlitem, L"DESCRIPTION", &paramDesc);
	//mainLog.Write("ProParameterInit: " + to_string(status));
	status = ProParameterValueWithUnitsGet(&paramDesc, &paramvalDesc, &paramunitDesc);
	//mainLog.Write("ProParameterValueWithUnitsGet: " + to_string(status));
	/*char cParamDesc[PRO_PATH_SIZE];
	ProWstringToString(cParamDesc, paramvalDesc.value.s_val);
	mainLog.Write("paramvalDesc: " + string(cParamDesc));*/
	ProWstringToString(cParamVal, paramvalDesc.value.s_val);
	if((status == PRO_TK_NO_ERROR) && (strlen(cParamVal) > 1))
		status = ProUILabelTextSet(DLG_IRC_MAIN, LBL_DESCRIPTION, paramvalDesc.value.s_val);
	else
		status = ProUILabelTextSet(DLG_IRC_MAIN, LBL_DESCRIPTION, L"N/A");

	// REMOVE DUPLICATE SUB-MODULES ENTRY
	unordered_set<string> uniqSubModuleSet;
	mainLog.Write("subModulesListOG.size() (with duplicates): " + to_string(subModulesListOG.size()));
	for (SubModuleInfo& smInfo : subModulesListOG) {
		if (uniqSubModuleSet.insert(smInfo.name).second) { /* enter the loop only if unique sub-module name found */
			if (smInfo.name.size() == 14 || (smInfo.name.size() == 18 && smInfo.name.substr(smInfo.name.size() - 4) == "_SWP")) //Edited By Himanshu to avoid SKEL Comps
				subModulesList.push_back(move(smInfo)); // Move the string to avoid unnecessary copying 
		}
	}
	mainLog.Write("subModulesList.size() (without duplicates): " + to_string(subModulesList.size()));
	subModulesListOG.clear();
	uniqSubModuleSet.clear();

	// SET SUBMODULES LIST UI
	char **subM_listnames{};
	wchar_t **subM_listlabels{};
	char cListName[PRO_NAME_SIZE];
	int noOfListitems{};

	if(_openedMdlCategory == CP_ITEM)
	{
		noOfListitems = subModulesList.size();

		status = ProArrayAlloc(noOfListitems, sizeof(char *), 1, (ProArray *)&subM_listnames);
		status = ProArrayAlloc(noOfListitems, sizeof(wchar_t *), 1, (ProArray *)&subM_listlabels);

		for (int i=0; i<subModulesList.size(); ++i)
		{
			strcpy(cListName, subModulesList[i].name.c_str());
			subM_listnames[i] = (char *)calloc(PRO_MDLNAME_SIZE, sizeof(char));
			ProTKSprintf(subM_listnames[i], "%d_%s", i, cListName);

			subM_listlabels[i] = (wchar_t *)calloc(PRO_MDLNAME_SIZE, sizeof(wchar_t));
			ProStringToWstring(subM_listlabels[i],cListName);
		}
	}
	else
	{
		noOfListitems = 1;
		status = ProArrayAlloc(noOfListitems, sizeof(char *), 1, (ProArray *)&subM_listnames);
		mainLog.Write("ProArrayAlloc: " + to_string(status));
		status = ProArrayAlloc(noOfListitems, sizeof(wchar_t *), 1, (ProArray *)&subM_listlabels);

		//if(_openedMdlCategory == SUB_MODULE)
		//	listUIfirstSMinfo = subModulesList[0];	// set listUIfirstSMinfo to the opened sub-module's info

		strcpy(cListName, listUIfirstSMinfo.name.c_str());
		subM_listnames[0] = (char *)calloc(PRO_MDLNAME_SIZE, sizeof(char));
		ProTKSprintf(subM_listnames[0], "%d_%s", (listUIfirstSMinfo.sno-1), cListName);

		subM_listlabels[0] = (wchar_t *)calloc(PRO_MDLNAME_SIZE, sizeof(wchar_t));
		ProStringToWstring(subM_listlabels[0],cListName);
	}

	status = ProUIListNamesSet(DLG_IRC_MAIN, LIST_SUB_MODULE, noOfListitems, subM_listnames);
	mainLog.Write("ProUIListNamesSet: " + to_string(status));
	status = ProUIListLabelsSet(DLG_IRC_MAIN, LIST_SUB_MODULE, noOfListitems, subM_listlabels);
	mainLog.Write("ProUIListLabelsSet: " + to_string(status));

	status = ProUIListSelectActionSet(DLG_IRC_MAIN, LIST_SUB_MODULE, (ProUIAction)submodule_list_select_action, NULL);

	status = ProArrayFree((ProArray*)&subM_listnames);
	status = ProArrayFree((ProArray*)&subM_listlabels);

	// CREATE DYNAMIC TABLES
	if(_openedMdlCategory == DUMMY || _openedMdlCategory == SUB_MODULE){
		createLibraryTable(listUIfirstSMinfo);
	}
	else if (_openedMdlCategory == CP_ITEM)
		createLibraryTable(subModulesList[0]); // 0th index bcuz, to display 1st submodule table when user launches the application
	
	createStatusTable();

	status = ProUIDialogActivate(DLG_IRC_MAIN, &dialog_sts);
	mainLog.Write("ProUIDialogActivate(DLG_IRC_MAIN): " + to_string(status));
	status = ProUIDialogDestroy(DLG_IRC_MAIN);
	mainLog.Write("ProUIDialogDestroy(DLG_IRC_MAIN): " + to_string(status));
}

int AppFrontEnd::createStatusTable()
{
	mainLog.Write("================================ AppFrontEnd::createStatusTable ================================");

	vector <RuleInfo> stsRulesList;
	for (auto item : rulesList){
		//if(item.IsDigitizable == true)
		stsRulesList.push_back(item);
	}

	int stsTblRowCount = stsRulesList.size();
	mainLog.Write("stsTblRowCount: " + to_string(stsTblRowCount));
	char** stsTblsRows = new char* [stsTblRowCount];
	for (int i = 0; i < stsTblRowCount; ++i){
		stsTblsRows[i] = new char[PRO_PATH_SIZE];
		ProTKSprintf(stsTblsRows[i], "r%d", stsRulesList[i].sno);
	}
	// DEVIATION CB
	status = ProUITableCheckbuttonAdd(DLG_IRC_MAIN, TBL_RULE_STATUS, CB_DEVIATION);
	status = ProUICheckbuttonSizeSet(DLG_IRC_MAIN, CB_DEVIATION, 80, 80);
	// COPY PB
	status = status = ProUITablePushbuttonAdd(DLG_IRC_MAIN, TBL_RULE_STATUS, PB_COPY);
	status = ProUIPushbuttonBitmapSet(DLG_IRC_MAIN, PB_COPY, "copy_icon.png");

	status = ProUITableRowsInsert(DLG_IRC_MAIN, TBL_RULE_STATUS, NULL, stsTblRowCount, stsTblsRows);
	mainLog.Write("ProUITableRowsInsert: " + to_string(status));

	if(status != PRO_TK_NO_ERROR)
		return -1;

	for (int i = 0; i < stsTblRowCount; ++i)
	{
		// S NO
		ProTKSprintf(c_cellLabel, " %d.",i+1);
		ProStringToWstring(w_cellLabel, c_cellLabel);
		status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_STATUS, stsTblsRows[i], "s_no", w_cellLabel);
		// RULE ID
		ProTKSprintf(c_cellLabel, "%s", stsRulesList[i].id.c_str());
		ProStringToWstring(w_cellLabel, c_cellLabel);
		status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_STATUS, stsTblsRows[i], "rule_id", w_cellLabel);
		// SUB MODULE
		if(stsRulesList[i].lib_sno == 1){
			ProTKSprintf(c_cellLabel, "%s", stsRulesList[i].module_name.c_str());
			ProStringToWstring(w_cellLabel, c_cellLabel);
			status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_STATUS, stsTblsRows[i], "sub_module", w_cellLabel);
		}
		//if(i==0) // 1ST SUB-MODULE
		//{
		//	ProTKSprintf(c_cellLabel, "%s", rulesList[i].module_name.c_str());
		//	ProStringToWstring(w_cellLabel, c_cellLabel);
		//	status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_STATUS, stsTblsRows[i], "sub_module", w_cellLabel);
		//}
		//else
		//{
		//	int prevIndx = i-1;
		//	if(strcmp(rulesList[i].module_name.c_str(), rulesList[prevIndx].module_name.c_str())!=0)
		//	{
		//		ProTKSprintf(c_cellLabel, "%s", rulesList[i].module_name.c_str());
		//		ProStringToWstring(w_cellLabel, c_cellLabel);
		//		status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_STATUS, stsTblsRows[i], "sub_module", w_cellLabel);
		//	}
		//}

		// STATUS
		ProTKSprintf(c_cellLabel, "%s",stsRulesList[i].status.c_str());
		ProStringToWstring(w_cellLabel, c_cellLabel);
		status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_STATUS, stsTblsRows[i], "status", w_cellLabel);
		// DEVIATION CB
		char stsTblDeviateCbName[PRO_NAME_SIZE]{};
		ProTKSprintf(stsTblDeviateCbName, "deviationcb_%s", stsTblsRows[i]);
		status = ProUITableCellComponentCopy(DLG_IRC_MAIN, TBL_RULE_STATUS, stsTblsRows[i], "deviation_cb", DLG_IRC_MAIN, CB_DEVIATION, stsTblDeviateCbName);
		//mainLog.Write("stsTblDeviateCbName: " + string(stsTblDeviateCbName) + "\tProUITableCellComponentCopy: " + to_string(status));
		status = ProUICheckbuttonActivateActionSet(DLG_IRC_MAIN, stsTblDeviateCbName, (ProUIAction)deviation_cb_action, NULL);
		status = ProUICheckbuttonDisable(DLG_IRC_MAIN, stsTblDeviateCbName);
		// COPY PB
		char stsTblCopyPbName[PRO_NAME_SIZE]{};
		ProTKSprintf(stsTblCopyPbName, "copypb_%s", stsTblsRows[i]);
		status = ProUITableCellComponentCopy(DLG_IRC_MAIN, TBL_RULE_STATUS, stsTblsRows[i], "copy_pb", DLG_IRC_MAIN, PB_COPY, stsTblCopyPbName);
		//mainLog.Write("stsTblCopyPbName: " + string(stsTblCopyPbName) + "\tProUITableCellComponentCopy: " + to_string(status));
		status = ProUICheckbuttonActivateActionSet(DLG_IRC_MAIN, stsTblCopyPbName, (ProUIAction)copy_pb_action, NULL);
		status = ProUIPushbuttonDisable(DLG_IRC_MAIN, stsTblCopyPbName);
		status= ProUIPushbuttonHelptextSet(DLG_IRC_MAIN, stsTblCopyPbName, L"Click to copy the remarks.");

		// REMARKS
		status= ProUITableCellHelpTextSet(DLG_IRC_MAIN, TBL_RULE_STATUS, stsTblsRows[i], "remarks", L"Click \"Copy\" to copy the full remarks.");
	}

	// DISABLE CELL SELECTION
	status = ProUITableSelectionpolicySet(DLG_IRC_MAIN, TBL_RULE_STATUS, PROUISELPOLICY_NONE);
	//mainLog.Write("ProUITableSelectionpolicySet  : " + to_string(status));

	// UPDATE GUI
	for (auto info : subModulesList)
		updateGUI(info.name, rulesList);

	delete[] stsTblsRows;
	return 0;
}

int AppFrontEnd::createLibraryTable(SubModuleInfo subModuleInfo)
{
	mainLog.Write("================================ AppFrontEnd::createLibraryTable ================================");

	subModuleRulesList.clear();
	//status = ProUIPushbuttonDisable(DLG_IRC_MAIN, PB_PLM_SUBMIT);

	// REMOVE THE TABLE IF EXISTS
	status = ProUILayoutTableRemove(DLG_IRC_MAIN, TBL_RULE_LAYOUT, TBL_RULE_LIBRARY);

	// ADD NEW TABLE
	ProUIGridopts ui_gopts;
	PRO_UI_GRIDOPTS_DEFAULT(ui_gopts);
	ui_gopts.row = 2;
	ui_gopts.column = 0;
	status = ProUILayoutTableAdd(DLG_IRC_MAIN, TBL_RULE_LAYOUT, TBL_RULE_LIBRARY, &ui_gopts);

	char* columnNames[] = { "s_no", "rule_id","dependent_interfacing_modls", "verify", "execute" ,"deviate", "help", "status"};
	wchar_t* columnLabels[] = { L"S. no", L"Rule ID",L"Dependent Interfacing Modules", L"Verify", L"Execute",L"Deviate", L"Help", L"Status" };
	int columnWidths[] = { 2,7,23,3,5,2,2,5 };

	status = ProUITableColumnnamesSet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, 8, columnNames);
	status = ProUITableColumnlabelsSet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, 8, columnLabels);
	status = ProUITableColumnwidthsSet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, 8, columnWidths);

	status = ProUITableShowgridSet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, PRO_B_TRUE);

	// RUN_PB
	status = ProUITablePushbuttonAdd(DLG_IRC_MAIN, TBL_RULE_LIBRARY, PB_RUN);
	//status = ProUIPushbuttonSizeSet(DLG_IRC_MAIN, PB_RUN, 120, 80);
	//status = ProUIPushbuttonTextSet(DLG_IRC_MAIN, PB_RUN, L" RUN ");
	status = ProUIPushbuttonBitmapSet(DLG_IRC_MAIN, PB_RUN, "run_icon.png");
	// HELP_PB
	status = ProUITablePushbuttonAdd(DLG_IRC_MAIN, TBL_RULE_LIBRARY, PB_HELP);
	status = ProUIPushbuttonBitmapSet(DLG_IRC_MAIN, PB_HELP, "help_icon.png");
	// CHECK_CB
	status = ProUITableCheckbuttonAdd(DLG_IRC_MAIN, TBL_RULE_LIBRARY, CB_CHECK);
	status = ProUICheckbuttonSizeSet(DLG_IRC_MAIN, CB_CHECK, 80, 80);
	// DEVIATE_CB
	status = ProUITableCheckbuttonAdd(DLG_IRC_MAIN, TBL_RULE_LIBRARY, CB_LIB_DEVIATION);
	status = ProUICheckbuttonSizeSet(DLG_IRC_MAIN, CB_LIB_DEVIATION, 80, 80);

	/*int beginPos = 0, endPos = 0;
	for (int i = 0; i < rulesList.size(); ++i){
		if(rulesList[i].module_name.compare(subModuleInfo.name) == 0){
			beginPos = rulesList[i].sno - 1;
			break;
		}
	}
	endPos = beginPos + subModuleInfo.rules_count;
	subModuleRulesList.assign(rulesList.begin() + beginPos, rulesList.begin() + endPos);*/

	for (auto it = rulesList.begin(); it != rulesList.end(); ++it) {
		if (it->module_name.compare(subModuleInfo.name) == 0) {
			subModuleRulesList.push_back(&(*it));
		}
	}
	mainLog.Write("libTblRowsCount: " + to_string(subModuleRulesList.size()));
	/*mainLog.Write("rulesList sno");
	for (auto item : subModuleRulesList)
		mainLog.Write(to_string(item.sno));
	*/

	int libTblRowsCount = subModuleRulesList.size();
	char** libTblRows = new char* [libTblRowsCount];
	for (int i = 0; i < libTblRowsCount; ++i){
		libTblRows[i] = new char[PRO_PATH_SIZE];
		ProTKSprintf(libTblRows[i], "r%d", subModuleRulesList[i]->sno);
	}
	status = ProUITableRowsInsert(DLG_IRC_MAIN, TBL_RULE_LIBRARY, NULL, libTblRowsCount, libTblRows);
	mainLog.Write("ProUITableRowsInsert: " + to_string(status));

	if(status!=PRO_TK_NO_ERROR)
		return -1;

	for (int i = 0; i < libTblRowsCount; ++i)
	{
		char pbRunName[PRO_NAME_SIZE], pbHelpName[PRO_NAME_SIZE], cbVerifyName[PRO_NAME_SIZE], cbDeviateName[PRO_NAME_SIZE];

		// S NO
		ProTKSprintf(c_cellLabel, " %d. ", i+1);
		ProStringToWstring(w_cellLabel, c_cellLabel);
		status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "s_no", w_cellLabel);
		// RULE ID
		ProTKSprintf(c_cellLabel, "  %s", subModuleRulesList[i]->id.c_str());
		ProStringToWstring(w_cellLabel, c_cellLabel);
		status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "rule_id", w_cellLabel);
		// RULE DESCRIPTION
		ProTKSprintf(c_cellLabel, "  %s", subModuleRulesList[i]->desc.c_str());
		ProStringToWstring(w_cellLabel, c_cellLabel);
		status = ProUITableCellHelptextStringSet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "rule_id", w_cellLabel);
		// INTERFERING MODULES
		ProTKSprintf(c_cellLabel, " %s",subModuleRulesList[i]->interf_modules.c_str());
		ProStringToWstring(w_cellLabel, c_cellLabel);
		status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "dependent_interfacing_modls", w_cellLabel);
		// VERIFY BUTTON
		ProTKSprintf(cbVerifyName, "verifycb_%s", libTblRows[i]);
		status = ProUITableCellComponentCopy(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "verify", DLG_IRC_MAIN, CB_CHECK, cbVerifyName);
		//mainLog.Write("cbCheckName: " + string(cbCheckName) + "\tProUITableCellComponentCopy: " + to_string(status));
		status = ProUICheckbuttonActivateActionSet(DLG_IRC_MAIN, cbVerifyName, (ProUIAction)verify_cb_action, NULL);
		// RUN BUTTON
		ProTKSprintf(pbRunName, "runpb_%s", libTblRows[i]);
		status = ProUITableCellComponentCopy(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "execute", DLG_IRC_MAIN, PB_RUN, pbRunName);
		//mainLog.Write("pbRunName: " + string(pbRunName) + "\tProUITableCellComponentCopy: " + to_string(status));
		status = ProUIPushbuttonActivateActionSet(DLG_IRC_MAIN, pbRunName, (ProUIAction)run_pb_action, NULL);
		if(subModuleRulesList[i]->IsDeveloped)
			status = ProUIPushbuttonDisable(DLG_IRC_MAIN, pbRunName);
		// DEVIATE CHECK BUTTON
		ProTKSprintf(cbDeviateName, "deviatecb_%s", libTblRows[i]);
		status = ProUITableCellComponentCopy(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "deviate", DLG_IRC_MAIN, CB_LIB_DEVIATION, cbDeviateName);
		//mainLog.Write("cbCheckName: " + string(cbCheckName) + "\tProUITableCellComponentCopy: " + to_string(status));
		status = ProUICheckbuttonActivateActionSet(DLG_IRC_MAIN, cbDeviateName, (ProUIAction)deviation_cb_action, NULL);
		status = ProUICheckbuttonDisable(DLG_IRC_MAIN, cbDeviateName);
		//HELP BUTTON
		ProTKSprintf(pbHelpName, "helppb_%s", libTblRows[i]);
		status = ProUITableCellComponentCopy(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "help", DLG_IRC_MAIN, PB_HELP, pbHelpName);
		//mainLog.Write("pbHelpName: " + string(pbHelpName) + "\tProUITableCellComponentCopy: " + to_string(status));
		status = ProUIPushbuttonActivateActionSet(DLG_IRC_MAIN, pbHelpName, (ProUIAction)help_pb_action, NULL);
		//STATUS
		ProTKSprintf(c_cellLabel, "%s",stsCellLabel);
		ProStringToWstring(w_cellLabel, c_cellLabel);
		status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "status", w_cellLabel);
		// DISABLE FOR NON-DEVELOPED RULES
		if(!subModuleRulesList[i]->IsDeveloped)
		{
			status = ProUICheckbuttonDisable(DLG_IRC_MAIN, cbVerifyName);
			//status = ProUICheckbuttonDisable(DLG_IRC_MAIN, cbDeviateName);
			status = ProUIPushbuttonDisable(DLG_IRC_MAIN, pbHelpName);
		}
		//DISABLE CELL SELECTION
		status = ProUITableSelectionpolicySet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, PROUISELPOLICY_NONE);
		//mainLog.Write("ProUITableSelectionpolicySet  : " + to_string(status));

		// DISABLE FOR NON_DIGITIZED RULES
		/*if (subModuleRulesList[i]->IsDigitizable == false)
		{
			status = ProUITableCellDisable(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "s_no");
			status = ProUITableCellDisable(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "rule_id");
			status = ProUITableCellDisable(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "dependent_interfacing_modls");
			status = ProUITableCellDisable(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "verify");
			status = ProUITableCellDisable(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "execute");
			status = ProUITableCellDisable(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "deviate");
			status = ProUITableCellDisable(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "help");
			status = ProUITableCellDisable(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "status");


			status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, libTblRows[i], "status", L"");
			status = ProUICheckbuttonDisable(DLG_IRC_MAIN, cbVerifyName);
			status = ProUICheckbuttonDisable(DLG_IRC_MAIN, cbDeviateName);
			status = ProUIPushbuttonDisable(DLG_IRC_MAIN, pbHelpName);
		}*/
	}

	status = ProUITablePushbuttonRemove(DLG_IRC_MAIN, TBL_RULE_LIBRARY, PB_RUN);
	status = ProUITablePushbuttonRemove(DLG_IRC_MAIN, TBL_RULE_LIBRARY, PB_HELP);
	status = ProUITableCheckbuttonRemove(DLG_IRC_MAIN, TBL_RULE_LIBRARY, CB_CHECK);
	status = ProUITableCheckbuttonRemove(DLG_IRC_MAIN, TBL_RULE_LIBRARY, CB_LIB_DEVIATION);

	updateGUI(subModuleInfo.name, rulesList);

	delete[] libTblRows;

	return 0;
}

ProError verify_cb_action(char* dialog, char* component, ProAppData app_data)
{
	mainLog.Write("================================ verify_cb_action ================================");

	ProBoolean verifyCbChecked; 
	status = ProUICheckbuttonGetState(dialog, component, &verifyCbChecked);

	sCompName = string(component);

	// ROW NAME
	_pos = sCompName.find_first_of('_');
	sRowName = sCompName.substr(_pos+1);
	strcpy(cRowName, sRowName.c_str());
	//mainLog.Write("cRowName: "+string(cRowName));

	// S NO
	int r_sno = stoi(sRowName.substr(1));
	mainLog.Write("rule_sno: "+to_string(r_sno));

	// RUN PB NAME
	sPbName = "runpb_"+sRowName;
	char cPbName[PRO_NAME_SIZE];
	strcpy(cPbName, sPbName.c_str());

	if(!verifyCbChecked){
		status = ProUIPushbuttonDisable(DLG_IRC_MAIN, cPbName);
		return PRO_TK_NO_ERROR;
	}

	// if verifyCbChecked
	for(int i = 0; i< subModuleRulesList.size(); ++i)
	{
		if(r_sno == subModuleRulesList[i]->sno)
		{
			if(!subModuleRulesList[i]->IsDeveloped){
				_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", "Rule Development is in progress. Stay tuned for updates.");
				return PRO_TK_NO_ERROR;
			}

			vector<string> reqInterfModules, missingModulesList;
			char cIntfModules[PRO_PATH_SIZE];
			strcpy(cIntfModules, subModuleRulesList[i]->interf_modules.c_str());

			// SPECIAL CASES
			if(subModuleRulesList[i]->id.compare("IR-F1E02-006") == 0){					//Himanshu
				IR_F1E02_006_verifyaction(reqInterfModules);
			}
			else if (subModuleRulesList[i]->id.compare("IR-F1E01-007") == 0)			//Vinay
			{
				IR_F1E01_007_verifyaction(reqInterfModules);
			}
			else if (subModuleRulesList[i]->id.compare("IR-F2B06-003") == 0) {
				IR_F2B06_003_verifyaction(reqInterfModules);
			}
			// DEFAULT
			else{
				char *token = strtok(cIntfModules, "; ");
				while (token != NULL){
					reqInterfModules.push_back(string(token));
					token = strtok(NULL, "; ");
				}
			}
			mainLog.Write("reqInterfModules.size(): "+to_string(reqInterfModules.size()));

			if (reqInterfModules.size() <= 0)
				return PRO_TK_NO_ERROR;

			// EXTRACT THE MISSING MODULES
			for (auto intfModlName : reqInterfModules)
			{
				bool moduleFound = false;
				for(auto item : subModulesList){
					if(item.name.find(intfModlName.substr(1)) != string::npos){
						moduleFound = true;
						break;
					}
				}
				if(!moduleFound){
					mainLog.Write("intfModlName.substr(1): "+intfModlName.substr(1));
					missingModulesList.push_back(intfModlName.substr(1));
				}
			}

			if(missingModulesList.size() > 0)	// MISSING = YES
			{
				status = ProUICheckbuttonUnset(dialog, component);

				char cMissingModl[PRO_PATH_SIZE];
				strcpy(cMissingModl, "\t");
				strcat(cMissingModl, "Below Sub-modules are missing.\n\n");
				for (auto name : missingModulesList)
				{
					strcat(cMissingModl, name.c_str());
					strcat(cMissingModl,"\n\t");
				}
				//_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Missing", cMissingModl);

				strcat(cMissingModl, "\nClick YES to assemble them.");
				ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
				msg_buttons[0] = PRO_UI_MESSAGE_YES;
				msg_buttons[1] = PRO_UI_MESSAGE_NO;
				user_choice = _utils.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation", cMissingModl, msg_buttons);

				if(user_choice == PRO_UI_MESSAGE_YES){
					// CALL ASSEMBLY TOOL
					status = ProUIDialogHide(DLG_IRC_MAIN);
					assemblyToolMain(missingModulesList, subModuleRulesList[i]->id, _openedMdlCategory);
					status = main_UI_close(DLG_IRC_MAIN, NULL, NULL);	// close the main app after exiting assembly tool
				}
			}
			else{	// MISSING = NO
				status = ProUIPushbuttonEnable(DLG_IRC_MAIN, cPbName);
				_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", "Required CAD data is available.\n\nPlease ensure that the sub-mudules are assembled at correct positions.\nIf not, please close the main UI, reposition the submodules at correct postion and run again. \n\nClick OK to proceed.");
			}
			ProArrayFree((ProArray*)&msg_buttons);
			missingModulesList.clear();
			reqInterfModules.clear();
			break;
		}
	}
	return PRO_TK_NO_ERROR;
}

ProError run_pb_action(char* dialog, char* component, ProAppData app_data)
{
	mainLog.Write("================================ run_pb_action ================================");

	sCompName = string(component);

	// ROW NAME
	_pos = sCompName.find_first_of('_');
	sRowName = sCompName.substr(_pos+1);
	strcpy(cRowName, sRowName.c_str());

	// S NO
	int r_sno = stoi(sRowName.substr(1));

	for(int i = 0; i< subModuleRulesList.size(); ++i)
	{
		if(subModuleRulesList[i]->sno == r_sno)
		{
			strcpy(cSubModuleName, subModuleRulesList[i]->module_name.c_str());

			//Changes made by himanshu
			//-----------------------------------------------------
			mainLog.Write("SubModule: " + string(cSubModuleName));
			char con_SubMod_name[PRO_PATH_SIZE]{};
			revision_extraction_from_txr(cSubModuleName, con_SubMod_name);
			mainLog.Write("con_SubMod_name: " + string(con_SubMod_name));
			//-----------------------------------------------------

			bool isRulePerformed = NULL;
			sqlRes = SQLcheckIfRulePerformed(con_SubMod_name, subModuleRulesList[i]->lib_sno, isRulePerformed);
			mainLog.Write("SQLcheckIfRulePerformed (sqlRes): " + to_string(sqlRes));
			mainLog.Write("isRulePerformed: " + to_string(isRulePerformed));

			if (isRulePerformed == true)
			{
				// ASK FOR CONFORMATION
				ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
				msg_buttons[0] = PRO_UI_MESSAGE_YES;
				msg_buttons[1] = PRO_UI_MESSAGE_NO;
				mainLog.Write("Rule Repeat confirmation");
				user_choice = _utils.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation", "Do you want to repeat the rule?", msg_buttons);
				mainLog.Write("userchoice: " + to_string(user_choice));
				if (user_choice == msg_buttons[0])
					isRulePerformed = false;	//user confirmed
				else if (user_choice == msg_buttons[1])
					isRulePerformed = true;		//user doesn't confirm

				ProArrayFree((ProArray*)&msg_buttons);
			}

			if (isRulePerformed == false)
			{
				ruleResult res;
				if(subModuleRulesList[i]->IsDeveloped)
				{
					AppBackEnd _pbBackEnd;
					int backend_sts;

					backend_sts = _pbBackEnd.CallSelectedRule(subModuleRulesList[i]->id, res);
					if (backend_sts != -1)	// to verify that user didn't abort while performing
					{
						res.performedSts = true;


						//Changes made by himanshu
						//-----------------------------------------------------
						mainLog.Write("SubModule: " + string(cSubModuleName));
						char con_SubMod_name[PRO_PATH_SIZE]{};
						revision_extraction_from_txr(cSubModuleName, con_SubMod_name);
						mainLog.Write("con_SubMod_name: " + string(con_SubMod_name));
						//-----------------------------------------------------

						sqlRes = SQLupdateRuleStatus(con_SubMod_name,subModuleRulesList[i]->lib_sno, &res);	// UPDATE SQL
						mainLog.Write("SQLupdateRuleStatus (sqlRes): " + to_string(sqlRes));

						subModuleRulesList[i]->status = res.result;
						subModuleRulesList[i]->remark = res.remark;
						subModuleRulesList[i]->performed_sts = res.performedSts;
						ruleStatusUIupdate(*subModuleRulesList[i]); // UPDATE FRONT END

						// DISPLAY REMARKS WINDOW
						if(!subModuleRulesList[i]->remark.empty())
						{
							char remarkFp[PRO_PATH_SIZE];
							ProTKSprintf(remarkFp, "C:\\tmp\\%s_%s.txt", subModuleRulesList[i]->module_name, subModuleRulesList[i]->id);
							writeRemarkTxtFile(remarkFp, *subModuleRulesList[i]);

							wchar_t wRemarkFp[PRO_PATH_SIZE];
							ProInfoWindowSize infoWinSize;
							infoWinSize.columns = 35;
							infoWinSize.rows = 20;
							status = ProInfoWindowDisplay(ProStringToWstring(wRemarkFp, remarkFp), NULL, &infoWinSize);
							mainLog.Write("ProInfoWindowDisplay: " + to_string(status));
						}
					}
				}
				else
				{
					// logic for manually checked rules
					ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
					msg_buttons[0] = PRO_UI_MESSAGE_YES;
					msg_buttons[1] = PRO_UI_MESSAGE_NO;
					user_choice = _utils.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation", "This rule is not automated! \nDo you want to ensure compliance and mark it as a \"Pass\"?", msg_buttons);
					mainLog.Write("userchoice: " + to_string(user_choice));
					if (user_choice == msg_buttons[0])
					{
						res.remark = "This rule is not automated. And design engineer has ensured the compliance.";
						res.performedSts = true;
						res.result = "PASS";

						subModuleRulesList[i]->status = res.result;
						subModuleRulesList[i]->remark = res.remark;
						subModuleRulesList[i]->performed_sts = res.performedSts;

						//Changes made by himanshu
						//-----------------------------------------------------
						mainLog.Write("SubModule: " + string(cSubModuleName));
						char con_SubMod_name[PRO_PATH_SIZE]{};
						revision_extraction_from_txr(cSubModuleName, con_SubMod_name);
						mainLog.Write("con_SubMod_name: " + string(con_SubMod_name));
						//-----------------------------------------------------

						sqlRes = SQLupdateRuleStatus(con_SubMod_name,subModuleRulesList[i]->lib_sno, &res);	// UPDATE SQL
						mainLog.Write("SQLupdateRuleStatus (sqlRes): " + to_string(sqlRes));
						ruleStatusUIupdate(*subModuleRulesList[i]); // UPDATE FRONT END
					}
					else if (user_choice == msg_buttons[1])
					{
						res.remark = "This rule is not automated. And design engineer has ensured the compliance.";
						res.performedSts = true;
						res.result = "FAIL";

						subModuleRulesList[i]->status = res.result;
						subModuleRulesList[i]->remark = res.remark;
						subModuleRulesList[i]->performed_sts = res.performedSts;

						//Changes made by himanshu
						//-----------------------------------------------------
						mainLog.Write("SubModule: " + string(cSubModuleName));
						char con_SubMod_name[PRO_PATH_SIZE]{};
						revision_extraction_from_txr(cSubModuleName, con_SubMod_name);
						mainLog.Write("con_SubMod_name: " + string(con_SubMod_name));
						//-----------------------------------------------------

						sqlRes = SQLupdateRuleStatus(con_SubMod_name, subModuleRulesList[i]->lib_sno, &res);	// UPDATE SQL
						mainLog.Write("SQLupdateRuleStatus (sqlRes): " + to_string(sqlRes));
						ruleStatusUIupdate(*subModuleRulesList[i]); // UPDATE FRONT END
					}
					ProArrayFree((ProArray*)&msg_buttons);
				}
			}
			break;
		}
	}
	return PRO_TK_NO_ERROR;
}

ProError help_pb_action(char* dialog, char* component, ProAppData app_data)
{
	mainLog.Write("================================ help_pb_action ================================");
	sCompName = string(component);

	// ROW NAME
	_pos = sCompName.find_first_of('_');
	sRowName = sCompName.substr(_pos+1);
	strcpy(cRowName, sRowName.c_str());

	// S NO
	int r_sno = stoi(sRowName.substr(1));

	for(int i = 0; i< subModuleRulesList.size(); ++i)
	{
		if(r_sno == subModuleRulesList[i]->sno)
		{
			if(subModuleRulesList[i]->help_doc.compare("N/A") == 0){	// Empty
				_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", "The Help document is not available for this rule yet.");
				return PRO_TK_NO_ERROR;
			}
			int curWinId;
			status = ProWindowCurrentGet(&curWinId);
			//mainLog.Write("ProWindowCurrentGet: " + to_string(status));
			char cHelpFilePath[PRO_PATH_SIZE];
			wchar_t wHelpFilePath[PRO_PATH_SIZE];
			if (status == PRO_TK_NO_ERROR)
			{
				strcpy(cHelpFilePath, subModuleRulesList[i]->help_doc.c_str());
				ProStringToWstring(wHelpFilePath, cHelpFilePath);
				status = ProWindowURLShow(curWinId, wHelpFilePath);
			}
			break;
		}
	}
	//status = main_close_pb_action(DLG_IRC_MAIN, NULL, NULL);
	return PRO_TK_NO_ERROR;
}

ProError report_pb_action(char* dialog, char* component, ProAppData app_data)
{
	mainLog.Write("================================ report_pb_action ================================");

	int count;
	char **names;
	status = ProUITabSelectednamesGet(dialog, DLG_TAB, &count, &names);
	mainLog.Write("ProUITabSelectednamesGet: "+ to_string(status));
	mainLog.Write("tabNames[0]: "+ string(names[0]));

	if(status == PRO_TK_NO_ERROR)
	{
		if(strcmp(names[0], "rule_lib") == 0)
		{
			mainLog.Write("Interface Rule Library");
			status = ProUIListSelectednamesGet(dialog, LIST_SUB_MODULE, &count, &names);

			_pos = string(names[0]).find_first_of('_');

			string reportPath = generateReport(string(names[0]).substr(_pos+1), rulesList);

			int window_id;
			status = ProWindowCurrentGet(&window_id);
			char cHTMLname[PRO_PATH_SIZE];
			ProComment HTML_URL;
			if (status == PRO_TK_NO_ERROR)
			{
				strcpy(cHTMLname, reportPath.c_str());
				ProStringToWstring(HTML_URL, cHTMLname);
				status = ProWindowURLShow(window_id, HTML_URL);
			}

			bool IsAllRulePerformed;
			for (auto res : testResult) {
				mainLog.Write("status2: " + res);

				if (res == "Not-Performed") {
					IsAllRulePerformed = false;
					break;
				}
				else { IsAllRulePerformed = true; }
			}

			if(IsAllRulePerformed){ status = main_close_pb_action(DLG_IRC_MAIN, NULL, NULL); }
			else
			{
				main_UI_close(DLG_IRC_MAIN, NULL, NULL);
			}
			
			//status = main_UI_close(DLG_IRC_MAIN, NULL, NULL);
		}
		else if(strcmp(names[0], "status") == 0)
		{
			mainLog.Write("Status Report");

			ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
			msg_buttons[0] = PRO_UI_MESSAGE_YES;
			msg_buttons[1] = PRO_UI_MESSAGE_NO;
			user_choice = _utils.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION, "Confirmation", "Do you want to generate report for all the submodules?", msg_buttons);
			if(user_choice == msg_buttons[0])
			{
				vector<string> reportPaths;
				char report_dir[PRO_PATH_SIZE];
				for (int i =0; i<subModulesList.size(); ++i)
					reportPaths.push_back(generateReport(subModulesList[i].name, rulesList));
				/*strcpy(report_dir, cTextPath);
				strcat(report_dir, "\\text\\xml_resources\\");*/
				//strcpy(report_dir, "K:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\app_db\\");
				strcpy(report_dir, cCurDirPath);
				ShellExecute(NULL, NULL, report_dir, NULL, NULL, SW_SHOWNORMAL);
				reportPaths.clear();
			}
			ProArrayFree((ProArray*)&msg_buttons);
		}
		ProStringarrayFree(names,count);
	}
	return PRO_TK_NO_ERROR;
}

ProError tab_action(char* dialog, char* component, ProAppData data)
{
	mainLog.Write("================================ tab_action ================================");

	int tabCount;
	char **tabIpVals;
	wchar_t *wTabName{};
	char cTabName[PRO_NAME_SIZE] = "";
	status = ProUITabSelectednamesGet(dialog, component, &tabCount,  &tabIpVals);
	mainLog.Write("ProUITabSelectednamesGet: " + to_string(status));

	/*if(strcmp(tabIpVals[0], "status") == 0)
		ProUIPushbuttonDisable(DLG_IRC_MAIN, PB_PLM_SUBMIT);
	else if (strcmp(tabIpVals[0], "status") == 0)
		if(submitToPlmEnable)
			ProUIPushbuttonEnable(DLG_IRC_MAIN, PB_PLM_SUBMIT);*/

	if(strcmp(tabIpVals[0], "status") == 0)
		ProUIPushbuttonDisable(DLG_IRC_MAIN, PB_REPORT);
	else if (strcmp(tabIpVals[0], "rule_lib") == 0)
		ProUIPushbuttonEnable(DLG_IRC_MAIN, PB_REPORT);

	return status;
}

ProError submodule_retrieve_callback(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	//mainLog.Write("================================ submodule_retrieve_callback ================================");

	ProFeattype feat_type;
	status = ProFeatureTypeGet(p_feature, &feat_type);
	if(feat_type == PRO_FEAT_COMPONENT)
	{
		ProMdl subModuleMdl;
		status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &subModuleMdl);

		ProMdlType subModuleMdlType;
		status = ProMdlTypeGet(subModuleMdl, &subModuleMdlType);

		wchar_t wFeatName[PRO_NAME_SIZE];
		char cFeatName[PRO_NAME_SIZE];
		status = ProMdlMdlnameGet(subModuleMdl, wFeatName);
		ProWstringToString(cFeatName, wFeatName);

		//mainLog.Write("cFeatName: "+string(cFeatName));
		if (subModuleMdlType == PRO_MDL_ASSEMBLY){
			if(regex_match(string(cFeatName).substr(4,5), subModulePattern))
				subModuleNames.push_back(cFeatName);
			status = ProSolidFeatVisit((ProSolid)subModuleMdl, submodule_retrieve_callback, NULL, NULL);	// to retreive the nested sub-modules
		}
		else if(subModuleMdlType == PRO_MDL_PART /*for parts converted from CATIA*/){
			if(regex_match(string(cFeatName).substr(4,5), subModulePattern))
				subModuleNames.push_back(cFeatName);
		}
	}

	return PRO_TK_NO_ERROR;
}

ProError submodule_list_select_action(char* dialog, char* component, ProAppData app_data)
{
	mainLog.Write("================================ submodule_list_select_action ================================");
	char** selectedNames;
	int n_sels;
	AppFrontEnd _appFrontEnd;
	status = ProUIListSelectednamesGet(dialog, component, &n_sels, &selectedNames);
	//mainLog.Write("ProUIListSelectednamesGet: " + to_string(status));
	mainLog.Write("\tSelected submodule name: "+string(selectedNames[0]));

	_pos = string(selectedNames[0]).find_first_of('_');
	int selIndex = stoi(string(selectedNames[0]).substr(0,_pos));
	mainLog.Write("selIndex: "+to_string(selIndex));
	_appFrontEnd.createLibraryTable(subModulesList[selIndex]);

	ProStringarrayFree(selectedNames,n_sels);
	return PRO_TK_NO_ERROR;
}

ProError deviation_cb_action(char* dialog, char* component, ProAppData app_data)
{
	mainLog.Write("================================ deviation_cb_action ================================");

	sCompName = string(component);

	// ROW NAME
	_pos = sCompName.find_first_of('_');
	sRowName = sCompName.substr(_pos+1);
	strcpy(cRowName, sRowName.c_str());

	// S NO
	int r_sno = stoi(sRowName.substr(1));

	//replace this with shallow copy of element
	RuleInfo *selRuleInfo = nullptr;
	for(int i = 0; i< rulesList.size(); ++i)
	{
		if(r_sno == rulesList[i].sno){
			strcpy(cSubModuleName, rulesList[i].module_name.c_str());
			selRuleInfo = &rulesList[i];
			break;
		}
	}
	if(!selRuleInfo->IsDeveloped)
	{
		status = ProUICheckbuttonUnset(dialog, component);
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", "Rule Development is in progress. Stay tuned.");
		return PRO_TK_NO_ERROR;
	}
	ProBoolean deviationCheckd; 
	status = ProUICheckbuttonGetState(dialog, component, &deviationCheckd);
	if(deviationCheckd)
	{
		//show the user input dialog
		ProFileName wMsgFile;
		wcscpy(wMsgFile, L"interface_rule_check_msg.txt");
		status = ProMessageDisplay(wMsgFile, "Enter the deviation remarks:", "Enter the deviation remarks (min. 20 chars): ");
		mainLog.Write("ProMessageDisplay: " + to_string(status));

		wchar_t wUserInput[PRO_PATH_SIZE];
		status = ProMessageStringRead(PRO_PATH_SIZE, wUserInput);
		mainLog.Write("ProMessageStringRead: " + to_string(status));
		if(status!=PRO_TK_NO_ERROR){
			status = ProUICheckbuttonUnset(dialog, component);
			return status;
		}

		char cUserInput[PRO_PATH_SIZE];
		ProWstringToString(cUserInput, wUserInput);
		mainLog.Write("cUserInput = "+string(cUserInput));
		mainLog.Write("strlen(cUserInput)<20 = "+to_string(strlen(cUserInput)<20));
		mainLog.Write("isWhitespaceString(string(cUserInput) = "+to_string(_utils.isWhitespaceString(string(cUserInput))));
		if(!_utils.isWhitespaceString(string(cUserInput)) && strlen(cUserInput)>20)
		{
			ruleResult deviationRes;
			deviationRes.remark = cUserInput;
			deviationRes.result = "DEVIATION";
			deviationRes.performedSts = true;

			//Changes made by himanshu
			//-----------------------------------------------------
			mainLog.Write("SubModule: " + string(cSubModuleName));
			char con_SubMod_name[PRO_PATH_SIZE]{};
			revision_extraction_from_txr(cSubModuleName, con_SubMod_name);
			mainLog.Write("con_SubMod_name: " + string(con_SubMod_name));
			//-----------------------------------------------------


			sqlRes = SQLupdateRuleStatus(con_SubMod_name, selRuleInfo->lib_sno, &deviationRes);	// UPDATE SQL
			mainLog.Write("SQLupdateRuleStatus (sqlRes): " + to_string(sqlRes));

			selRuleInfo->remark = deviationRes.remark;
			selRuleInfo->status = deviationRes.result;
			selRuleInfo->performed_sts = deviationRes.performedSts;
			ruleStatusUIupdate(*selRuleInfo); // UPDATE FRONT END
		}
		else{
			status = ProUICheckbuttonUnset(dialog, component);
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING,"Character limit",  "The remark should contain atleast 20 characters!");
		}
	}
	else{
		ProArrayAlloc(2, sizeof(ProUIMessageButton), 2, (ProArray*)&msg_buttons);
		msg_buttons[0] = PRO_UI_MESSAGE_YES;
		msg_buttons[1] = PRO_UI_MESSAGE_NO;
		_utils.UserDisplayPopupMessageUserChoice(PROUIMESSAGE_QUESTION,"Confirmation",  "Do you want to remove the deviation remarks?\n\nNote: If Yes, you should run the rule again!", msg_buttons);
		if(user_choice == PRO_UI_MESSAGE_YES)
		{
			// restore the UI
			ruleResult emptyRes;
			emptyRes.performedSts = false;


			//Changes made by himanshu
			//-----------------------------------------------------
			mainLog.Write("SubModule: " + string(cSubModuleName));
			char con_SubMod_name[PRO_PATH_SIZE]{};
			revision_extraction_from_txr(cSubModuleName, con_SubMod_name);
			mainLog.Write("con_SubMod_name: " + string(con_SubMod_name));
			//-----------------------------------------------------

			sqlRes = SQLupdateRuleStatus(con_SubMod_name, selRuleInfo->lib_sno, &emptyRes);	// UPDATE SQL
			mainLog.Write("SQLupdateRuleStatus (sqlRes): " + to_string(sqlRes));

			selRuleInfo->status = stsCellLabel;
			selRuleInfo->remark = emptyRes.remark;
			selRuleInfo->performed_sts = emptyRes.performedSts;
			ruleStatusUIupdate(*selRuleInfo); // UPDATE FRONT END
		}
		else if(user_choice == PRO_UI_MESSAGE_NO)
			status = ProUICheckbuttonSet(dialog, component);
		ProArrayFree((ProArray*)&msg_buttons);
	}
	return PRO_TK_NO_ERROR;
}

ProError copy_pb_action(char* dialog, char* component, ProAppData app_data)
{
	mainLog.Write("================================ copy_pb_action ================================");
	sCompName = string(component);

	mainLog.Write("sCompName: "+ sCompName);
	// ROW NAME
	_pos = sCompName.find_first_of('_');
	sRowName = sCompName.substr(_pos+1);
	strcpy(cRowName, sRowName.c_str());
	// S NO
	int r_sno = stoi(sRowName.substr(1));
	string remarkToCopy;
	for(int i = 0; i< rulesList.size(); ++i)
	{
		if(r_sno == rulesList[i].sno){
			remarkToCopy = rulesList[i].remark;
			break;
		}
	}
	_utils.copyToClipboard(remarkToCopy);
	
	return PRO_TK_NO_ERROR;
}

ProError main_close_pb_action(char* dialog, char* component, ProAppData data)
{
	mainLog.Write("================================ main_close_pb_action ================================");

	/*subModulesList.clear();
	rulesList.clear();*/
	//subModuleRulesList.clear();
	//rulesMapData.clear();

	//To get name of the selected model
	int count;
	char** names;
	string submoduleName2;
	status = ProUITabSelectednamesGet(dialog, DLG_TAB, &count, &names);
	mainLog.Write("ProUITabSelectednamesGet: " + to_string(status));
	mainLog.Write("tabNames[0]: " + string(names[0]));

	if (status == PRO_TK_NO_ERROR)
	{
		if (strcmp(names[0], "rule_lib") == 0)
		{
			mainLog.Write("Interface Rule Library");
			status = ProUIListSelectednamesGet(dialog, LIST_SUB_MODULE, &count, &names);

			_pos = string(names[0]).find_first_of('_');

			string modulename = string(names[0]);
			submoduleName2 = modulename.substr(_pos + 1);
		}
	}

	mainLog.Write("subModuleName: " + submoduleName2);
	char con_SubMod_name[PRO_PATH_SIZE];
	revision_extraction_from_txr(submoduleName2, con_SubMod_name);

	string SubMidRevSeq = string(con_SubMod_name);

	//To check performed rule//
	//vector <RuleInfo> stsRulesList;
	//for (auto item : rulesList) {
	//	stsRulesList.push_back(item);
	//}

	/*int stsTblRowCount = subModuleRulesList.size();
	mainLog.Write("stsTblRowCount: " + to_string(stsTblRowCount));
	char** stsTblsRows = new char* [stsTblRowCount];
	for (int i = 0; i < stsTblRowCount; ++i) {
		stsTblsRows[i] = new char[PRO_PATH_SIZE];
		ProTKSprintf(stsTblsRows[i], "r%d", stsRulesList[i].sno);
	}*/

	generateReport(string(names[0]).substr(_pos + 1), rulesList);
	string remXml = "C:\\tmp\\" + string(submoduleName2) + string("_report.xml");
	std::remove(remXml.c_str());
	string remhtml = "C:\\tmp\\" + string(submoduleName2) + string("_report.html");
	std::remove(remhtml.c_str());

	bool IsAllRulePerformed;
	for (auto res : testResult) {
		mainLog.Write("status2: " + res);

		if (res == "Not-Performed") {
			IsAllRulePerformed = false;
			break;
		}
		else{ IsAllRulePerformed = true; }
	}

	
	//for (int i = 0; i < subModuleRulesList.size(); ++i)
	//{
	//	// STATUS
	//	wchar_t *w_cellLabelget[PRO_PATH_SIZE];
	//	char c_cellLabelget[PRO_PATH_SIZE];
	//	
	//	status = ProUITableCellLabelGet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, stsTblsRows[i], "status", w_cellLabelget);
	//	mainLog.Write("status: " + to_string(status));
	//	ProTKSprintf(c_cellLabelget, "%s", w_cellLabelget);
	//	ProWstringToString(c_cellLabelget, *w_cellLabelget);
	//	mainLog.Write("c_cellLabelget: " + string(c_cellLabelget));

	//	string verifystring = string(c_cellLabelget);
	//	mainLog.Write("verifystring: " + string(verifystring));

	//	if(verifystring.find("-") != string::npos) {
	//		IsAllRulePerformed = false;
	//		mainLog.Write("IsAllRulePerformed: " + to_string(IsAllRulePerformed));
	//		break;
	//	}
	//	else 
	//	{ IsAllRulePerformed = true; }
	//}

	

	//Generate pdf
	if(IsAllRulePerformed) 
	{
		generateReport(string(names[0]).substr(_pos + 1), rulesList);
		string xmlname = submoduleName2 + string("_report.xml");
		string htmlName = submoduleName2 + string("_report.html");
		string pdfName = SubMidRevSeq + string("_IR_Report.pdf");
		//char pdf_path[PRO_PATH_SIZE] = "\\\\172.22.99.39\\startparttemplate\\IRC_DB\\IR_REPORTS";
		//K:\PTC\Creo7.0.2.0\telco_standards\irc_application\bin;

		const string sourcePath = "K:\\PTC\\Creo9.0.9.0\\telco_standards\\irc_application\\bin\\xml2html_report.vbs" ;
		const string DestPath = "C:\\tmp\\xml2html_report.vbs";

		if (!std::filesystem::exists(sourcePath)) {
			string infowindow = "Source file does not exist, please connect with DPDS Team";
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", infowindow);
		return PRO_TK_NO_ERROR;
		}

		// Open in binary mode
		ifstream src1(sourcePath, std::ios::binary);
		ofstream dst1(DestPath, std::ios::binary);
		// Copy the content
		dst1 << src1.rdbuf();
		dst1.close();
		
		string UnblockPath = "PowerShell -Command \"Unblock-File -Path 'C:\\tmp\\xml2html_report.vbs'\"";
		int unblock = system(UnblockPath.c_str());
		mainLog.Write("UnlockPath: " + UnblockPath);
		mainLog.Write("unblock: " + to_string(unblock));

		ofstream batchFile("C:\\tmp\\mybatch.bat");
		if (batchFile.is_open()) {
			batchFile << "@echo off" << endl;
			batchFile << "\"C:\\tmp\\xml2html_report.vbs\"" << " ";
			string xmlPath = "\"C:\\tmp\\" + string(xmlname) + "\"";
			string htmlPath = "\"C:\\tmp\\" + string(htmlName) + "\"";
			batchFile << xmlPath << " ";
			batchFile << "\"C:\\tmp\\report_res_db\\report.xsl\"" << " ";
			batchFile << htmlPath;
			batchFile.close();
		}
	
		//"start /MIN cmd.exe /c 
		//string batcmd = "\"C:\\tmp\\xml2html_report.vbs\" \"C:\\tmp\\" + xmlname +  "\" \"C:\\tmp\\report_res_db\\report.xsl\" \"C:\\tmp\\" + htmlName + "\"";
		//std::string batcmd = "cmd.exe /C \"C:\\tmp\\xml2html_report.vbs\" \"C:\\tmp\\" + xmlname + "\" \"C:\\tmp\\report_res_db\\report.xsl\" \"C:\\tmp\\" + htmlName + "\"";
		//int sss = system(batcmd.c_str());

		string batcmd = "start /MIN cmd.exe /c \"C:\\tmp\\mybatch.bat\"";
		int htmlResult = system(batcmd.c_str());
		mainLog.Write("batcmd: " + batcmd);
		mainLog.Write("batcmd: " + to_string(htmlResult));
		if (htmlResult != 0) {
			string infowindow = "Document creation failed, please connect with DPDS Team";
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", infowindow);
			return PRO_TK_NO_ERROR;
		}

		string pdfPath;
		ofstream batchFile2("C:\\tmp\\mypdfbatch.bat");
		if (batchFile2.is_open()) {
			batchFile2 << "@echo off" << endl;
			batchFile2 << "\"K:\\PTC\\Creo9.0.9.0\\telco_standards\\irc_application\\bin\\html2pdf_report.bat\"" << " ";
			string html2pdfinput = "\"C:\\tmp\\" + string(htmlName) + "\"";
			pdfPath = "\"\\\\172.22.99.39\\startparttemplate\\IRC_DB\\IR_REPORTS\\" + string(pdfName) + "\"";
			batchFile2 << html2pdfinput << " ";
			batchFile2 << pdfPath;
			batchFile2.close();
		}

		string pdfRemove = "\\\\172.22.99.39\\startparttemplate\\IRC_DB\\IR_REPORTS\\" + string(pdfName);
		int ps = remove(pdfRemove.c_str());
		mainLog.Write("remove: " + pdfRemove);
		string pdfbatcmd = "start /MIN cmd.exe /c \"C:\\tmp\\mypdfbatch.bat\"";
		int pdfResult = system(pdfbatcmd.c_str());
		mainLog.Write("pdfbatcmd: " + pdfbatcmd);
		mainLog.Write("pdfbatcmd: " + to_string(pdfResult));
		if (pdfResult != 0) {
			string infowindow = "Document creation failed, please connect with DPDS Team";
			_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", infowindow);
			return PRO_TK_NO_ERROR;
		}


		// Update N_Rule_failed parameter
		if (testResult.empty()) {
			mainLog.Write("testResult size: " + to_string(testResult.size()));

			ProParamvalue newvalue;
			newvalue.type = PRO_PARAM_BOOLEAN;
			newvalue.value.l_val = 0;
			ProParameterValueWithUnitsSet(&n_fail_parameter, &newvalue, NULL);
		}
		else {
			mainLog.Write("testResult size: " + to_string(testResult.size()));
			for (auto res : testResult) {
				mainLog.Write("status2: " + res);

				if (res == "Fail") {
					ProParamvalue newvalue;
					newvalue.type = PRO_PARAM_BOOLEAN;
					newvalue.value.l_val = 1;
					ProParameterValueWithUnitsSet(&n_fail_parameter, &newvalue, NULL);
					break;
				}
				else {
					ProParamvalue newvalue;
					newvalue.type = PRO_PARAM_BOOLEAN;
					newvalue.value.l_val = 0;
					ProParameterValueWithUnitsSet(&n_fail_parameter, &newvalue, NULL);
				}
			}

		}

		
	}
	else 
	{

		ProParamvalue newvalue;
		newvalue.type = PRO_PARAM_BOOLEAN;
		newvalue.value.l_val = 1;
		ProParameterValueWithUnitsSet(&n_fail_parameter, &newvalue, NULL);

		status = ProUIDialogHide(DLG_IRC_MAIN);
	}

	subModulesList.clear();
	rulesList.clear();
	subModuleRulesList.clear();
	rulesMapData.clear();
	submoduleName2.clear();
	SubMidRevSeq.clear();
	testResult.clear();

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	mainLog.Write("ProUIDialogExit(DLG_IRC_MAIN): " + to_string(status));

	return status;
}

// close action for assembly tool and report pb functions

ProError main_UI_close(char* dialog, char* component, ProAppData data)
{
	mainLog.Write("================================ main_UI_close ================================");

	subModulesList.clear();
	rulesList.clear();
	subModuleRulesList.clear();
	rulesMapData.clear();
	testResult.clear();

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	mainLog.Write("ProUIDialogExit(DLG_IRC_MAIN): " + to_string(status));

	return status;
}


static size_t WriteCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
	((std::string*)userp)->append((char*)contents, size * nmemb);
	return size * nmemb;
}

ProError submitPLM_pb_action(char* dialog, char* component, ProAppData app_data)
{
	mainLog.Write("================================ submitPLM_pb_action ================================");

	_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", "Submit to PLM");

	CURL* curl;
	CURLcode res;
	curl_global_init(CURL_GLOBAL_DEFAULT);
	curl = curl_easy_init();
	std::string responseBuffer{};

	//string SubModuleName1;
	//ProMdlName wFeatName1;
	//char cFeatName1[PRO_NAME_SIZE];
	//string rule_id1;

	//if (_openedMdlCategory == SUB_MODULE) {

	//	mainLog.Write("cCurMdlName: " + string(cCurMdlName));
	//	status = ProMdlMdlnameGet(curMdl, wFeatName1);
	//	ProWstringToString(cFeatName1, wFeatName1);
	//	mainLog.Write("SubModuleName1: " + string(cFeatName1));
	//	SubModuleName1 = string(cFeatName1);
	//	mainLog.Write("SubModuleName1: " + SubModuleName1);

	//}
	//else if (_openedMdlCategory == CP_ITEM) {

	//	for (auto subModl1 : subModulesList)
	//	{
	//		//if (subModl1.name.find(subModuleRulesList[0]->id.substr(3, 5)) != string::npos)	// finding the sub-module that belongs to rule
	//		//{
	//		//	ProTKSprintf(cNewAsmName, "DUMMY_%s", subModl.name);
	//		//	ProStringToWstring(wNewAsmName, cNewAsmName);
	//		//	break;
	//		//}
	//	}

	//	SubModuleName1 = string(subModuleNames[0]);
	//	mainLog.Write("SubModuleName1: " + SubModuleName1);
	//}
	
	//if (curl)
	//{		
	//	std::string soapXml = R"(
	//		<soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:DRStatus">
	//			<soapenv:Header/>
	//			<soapenv:Body>
	//				<urn:DRStatus soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
	//					<part xsi:type="xsd:string">subModPartName</part>
	//					<rev xsi:type="xsd:string">subModRevision</rev>
	//					<seq xsi:type="xsd:string">subModSequence</seq>
	//				</urn:DRStatus>
	//			</soapenv:Body>
	//		</soapenv:Envelope>)";

	////replace the Submodule with entered value
	//
	//	//Changes made by himanshu
	//	//-----------------------------------------------------
	//	mainLog.Write("SubModule: " + string(cSubModuleName));
	//	char con_SubMod_name[PRO_PATH_SIZE];
	//	revision_extraction_from_txr(cSubModuleName, con_SubMod_name);
	//	mainLog.Write("con_SubMod_name: " + string(con_SubMod_name));
	//	//-----------------------------------------------------

	//	string SbModNamewithRevSeq = string(con_SubMod_name);

	//	size_t firstUnderscore = SbModNamewithRevSeq.find('_');
	//	size_t secondUnderscore = SbModNamewithRevSeq.find('_', firstUnderscore + 1);

	//	// Extract the parts
	//	string subModname = SbModNamewithRevSeq.substr(0, firstUnderscore); // From start to first underscore
	//	string subModrev = SbModNamewithRevSeq.substr(firstUnderscore + 1, secondUnderscore - firstUnderscore - 1); // Between first and second underscore
	//	string subModSeq = SbModNamewithRevSeq.substr(secondUnderscore + 1);

	//	size_t cPartName = soapXml.find("subModPartName");
	//	if (cPartName != std::string::npos) {
	//		soapXml.replace(cPartName, strlen("subModPartName"), string(subModname));
	//	}
	//	size_t cPartRev = soapXml.find("subModRevision");
	//	if (cPartRev != std::string::npos) {
	//		soapXml.replace(cPartRev, strlen("subModRevision"), string(subModrev));
	//	}
	//	size_t cPartSeq = soapXml.find("subModSequence");
	//	if (cPartSeq != std::string::npos) {
	//		soapXml.replace(cPartSeq, strlen("subModSequence"), string(subModSeq));
	//	}

	//	mainLog.Write("soapXml: " + soapXml);

	//	struct curl_slist* headers = nullptr;
	//	headers = curl_slist_append(headers, "Content-Type: text/xml");

	//	curl_easy_setopt(curl, CURLOPT_URL, "http://172.22.99.106:9080/cgi/DRStatus.cgi");
	//	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
	//	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, soapXml.c_str());
	//	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback1);
	//	curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBuffer);

	//	res = curl_easy_perform(curl);

	//	if (res != CURLE_OK) {
	//		mainLog.Write("curl_easy_perform() failed: " + to_string(res));
	//		return PRO_TK_E_NOT_FOUND;
	//	}
	//	mainLog.Write("--- Response ---");
	//	mainLog.Write(responseBuffer);
	//	
	//	regex DRpattern(R"(DR\d+)");
	//	smatch DRmatch;

	//	if (regex_search(responseBuffer, DRmatch, DRpattern)) {
	//		mainLog.Write("DR status match: " +DRmatch.str());
	//	}
	//	else mainLog.Write("DR status match not found");

	//	ProParamvalue param_value1;
	//	ProParameter parameter;
	//	string sDRmatch = DRmatch.str();
	//	wchar_t wDRstatus[PRO_LINE_SIZE];
	//	char cDRstatus[PRO_LINE_SIZE];
	//	ProUnititem DRstatusitem;

	//	ProTKSprintf(cDRstatus, " %s", sDRmatch.c_str());
	//	ProStringToWstring(wDRstatus, cDRstatus);

	//	status = ProParameterInit(&curMdlitem, L"DR_STATUS", &parameter);
	//	mainLog.Write("ProParameterInit: " + to_string(status));

	//	if (status == PRO_TK_E_NOT_FOUND) {
	//		status = ProParamvalueSet(&param_value1, &wDRstatus, PRO_PARAM_STRING);
	//		mainLog.Write("ProParamvalueSet: " + to_string(status));
	//		status = ProParameterCreate(&curMdlitem, L"DR_STATUS", &param_value1, &parameter);
	//		mainLog.Write("ProParameterCreate: " + to_string(status));
	//		status = ProParameterLockstatusSet(&parameter, PRO_PARAMLOCKSTATUS_LOCKED);
	//		mainLog.Write("ProParameterLockstatusSet: " + status);
	//	}
	//	else {
	//		status = ProParameterLockstatusSet(&parameter, PRO_PARAMLOCKSTATUS_UNLOCKED);
	//		mainLog.Write("ProParameterLockstatusSet: " + status);
	//		status = ProParamvalueSet(&param_value1, &wDRstatus, PRO_PARAM_STRING);
	//		mainLog.Write("ProParamvalueSet: " + to_string(status));
	//		status = ProParameterValueWithUnitsSet(&parameter, &param_value1, NULL);
	//		mainLog.Write("ProParameterValueWithUnitsSet: " + status);
	//		status = ProParameterLockstatusSet(&parameter, PRO_PARAMLOCKSTATUS_LOCKED);
	//		mainLog.Write("ProParameterLockstatusSet: " + status);
	//	}

	//	curl_slist_free_all(headers);
	//	curl_easy_cleanup(curl);
	//	curl_global_cleanup();
	//}

	status = main_close_pb_action(DLG_IRC_MAIN, NULL, NULL);

	return PRO_TK_NO_ERROR;
}

// SUPPORTING FUNCTIONS
size_t WriteCallback1(void* contents, size_t size, size_t nmemb, std::string* output) {
	size_t totalSize = size * nmemb;
	output->append((char*)contents, totalSize);
	return totalSize;
}

ProError revision_extraction_from_txr(const string& mdl_name, char* Con_mdl_Name) {  // Himanshu

	mainLog.Write("================================ revision_extraction_from_txr ================================");

	string                      submodule_address = mdl_name;
	string                      SubModulename_rev_ite{};
	string                      line{};
	const char*					filePath = "D:\\PLMDocs\\myuadata\\ipem.txr";
	ifstream                    file(filePath);
	regex                       pattern(submodule_address);
	regex                       revPattern("rev=\"([A-Z]|NR);(\\d{1,2})\"");
	vector<string>              filteredLines;
	vector<string>              fileData;
	smatch                      Match1;


	if (!file.is_open()) {
		mainLog.Write("Failed to open the .txr file: " + string(filePath));
		return PRO_TK_GENERAL_ERROR;
	}

	while (getline(file, line))
		fileData.push_back(line);

	file.close();

	for (const auto& data : fileData) {
		if (regex_search(data, pattern))
			filteredLines.push_back(data);
	}

	mainLog.Write("Filtered lines :");
	for (const auto& line : filteredLines)
		mainLog.Write(line);

	SubModulename_rev_ite += submodule_address;

	for (const auto& sortedLine : filteredLines) {
		if (regex_search(sortedLine, Match1, revPattern)) {
			if (Match1.size() >= 3) {
				string output = "Found pattern: " + Match1[0].str() +
					" (Revision: " + Match1[1].str() +
					", Iteration: " + Match1[2].str() + ")";
				mainLog.Write(output);
				SubModulename_rev_ite += "_" + Match1[1].str() + "_" + Match1[2].str();
				break;
			}
			else
				mainLog.Write("Pattern match failed: insufficient groups found.");
		}
	}

	if (!SubModulename_rev_ite.empty()) {
		mainLog.Write("SubModule name with revision and iteration: " + SubModulename_rev_ite);
		strcpy(Con_mdl_Name, SubModulename_rev_ite.c_str());
	}
	else
		mainLog.Write(submodule_address + ": submodule address is not found in the .txr file.");

	SubModulename_rev_ite.clear();
	filteredLines.clear();
	line.clear();
	submodule_address.clear();
	fileData.clear();
	return PRO_TK_NO_ERROR;
}

ProError DRStatus_creation(ProModelitem cSubmdlItem)
{
	mainLog.Write("================================  DR_status ================================");

	//_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Info", "Submit to PLM");

	CURL* curl;
	CURLcode res;
	curl_global_init(CURL_GLOBAL_DEFAULT);
	curl = curl_easy_init();
	std::string responseBuffer{};

	if (curl)
	{
		std::string soapXml = R"(
			<soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:urn="urn:DRStatus">
				<soapenv:Header/>
				<soapenv:Body>
					<urn:DRStatus soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
						<part xsi:type="xsd:string">subModPartName</part>
						<rev xsi:type="xsd:string">subModRevision</rev>
						<seq xsi:type="xsd:string">subModSequence</seq>
					</urn:DRStatus>
				</soapenv:Body>
			</soapenv:Envelope>)";

		//replace the Submodule with entered value

		//Changes made by himanshu
		//-----------------------------------------------------
		mainLog.Write("SubModule: " + string(cSubModuleName));
		char con_SubMod_name[PRO_PATH_SIZE];
		revision_extraction_from_txr(cSubModuleName, con_SubMod_name);
		mainLog.Write("con_SubMod_name: " + string(con_SubMod_name));
		//-----------------------------------------------------

		string SbModNamewithRevSeq = string(con_SubMod_name);

		size_t firstUnderscore = SbModNamewithRevSeq.find('_');
		size_t secondUnderscore = SbModNamewithRevSeq.find('_', firstUnderscore + 1);

		// Extract the parts
		string subModname = SbModNamewithRevSeq.substr(0, firstUnderscore); // From start to first underscore
		string subModrev = SbModNamewithRevSeq.substr(firstUnderscore + 1, secondUnderscore - firstUnderscore - 1); // Between first and second underscore
		string subModSeq = SbModNamewithRevSeq.substr(secondUnderscore + 1);

		size_t cPartName = soapXml.find("subModPartName");
		if (cPartName != std::string::npos) {
			soapXml.replace(cPartName, strlen("subModPartName"), string(subModname));
		}
		size_t cPartRev = soapXml.find("subModRevision");
		if (cPartRev != std::string::npos) {
			soapXml.replace(cPartRev, strlen("subModRevision"), string(subModrev));
		}
		size_t cPartSeq = soapXml.find("subModSequence");
		if (cPartSeq != std::string::npos) {
			soapXml.replace(cPartSeq, strlen("subModSequence"), string(subModSeq));
		}

		mainLog.Write("soapXml: " + soapXml);

		struct curl_slist* headers = nullptr;
		headers = curl_slist_append(headers, "Content-Type: text/xml");

		curl_easy_setopt(curl, CURLOPT_URL, "http://172.22.99.106:9080/cgi/DRStatus.cgi");
		curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
		curl_easy_setopt(curl, CURLOPT_POSTFIELDS, soapXml.c_str());
		curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback1);
		curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBuffer);

		res = curl_easy_perform(curl);

		if (res != CURLE_OK) {
			mainLog.Write("curl_easy_perform() failed: " + to_string(res));
			return PRO_TK_E_NOT_FOUND;
		}
		mainLog.Write("--- Response ---");
		mainLog.Write(responseBuffer);

		regex DRpattern(R"(DR\d+)");
		smatch DRmatch;

		if (regex_search(responseBuffer, DRmatch, DRpattern)) {
			mainLog.Write("DR status match: " + DRmatch.str());
		}
		else mainLog.Write("DR status match not found");

		//ProParamvalue param_value1;
		ProParameter parameter;
		string sDRmatch = DRmatch.str();
		wchar_t wDRstatus[PRO_LINE_SIZE];
		char cDRstatus[PRO_LINE_SIZE];
		ProUnititem DRstatusitem;
		ProModelitem cSubmdlItem2 = cSubmdlItem;

		ProTKSprintf(cDRstatus, " %s", sDRmatch.c_str());
		ProStringToWstring(wDRstatus, cDRstatus);

		status = ProParameterInit(&cSubmdlItem2, L"DR_STATUS", &parameter);
		mainLog.Write("ProParameterInit: " + to_string(status));

		ProParamvalue param_value1;
		param_value1.type = PRO_PARAM_STRING;
		ProStringToWstring(param_value1.value.s_val, cDRstatus);
		//param_value1.value.s_val = wDRstatus;

		if (status == PRO_TK_E_NOT_FOUND) {

			status = ProParameterWithUnitsCreate(&cSubmdlItem2, L"DR_STATUS", &param_value1, NULL, &parameter);
			mainLog.Write("ProParameterWithUnitsCreate: " + status);
			if (status == PRO_TK_NO_ERROR) {
				status = ProParameterLockstatusSet(&parameter, PRO_PARAMLOCKSTATUS_LOCKED);
				mainLog.Write("ProParameterLockstatusSet: " + to_string(status));
			}
		}
		else {
			status = ProParameterLockstatusSet(&parameter, PRO_PARAMLOCKSTATUS_UNLOCKED);
			mainLog.Write("ProParameterLockstatusSet: " + status);
			status = ProParameterValueWithUnitsSet(&parameter, &param_value1, NULL);
			mainLog.Write("ProParameterValueWithUnitsSet: " + status);
			if (status == PRO_TK_NO_ERROR) {
				status = ProParameterLockstatusSet(&parameter, PRO_PARAMLOCKSTATUS_LOCKED);
				mainLog.Write("ProParameterLockstatusSet (Lock): " + to_string(status));
			}
		}

		curl_slist_free_all(headers);
		curl_easy_cleanup(curl);
		curl_global_cleanup();
	}

	//status = main_close_pb_action(DLG_IRC_MAIN, NULL, NULL);

	return PRO_TK_NO_ERROR;
}


#pragma warning(pop)