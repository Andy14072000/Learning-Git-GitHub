/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 07-DEC-2021	| V1_0_0		| LOG FILE OPERATIONS
==================================================================================================================*/
#include "LogFile.h"

void LogFile::Start(string filePath)
{
	strcpy(file_path, filePath.c_str());

	std::ofstream ofs;
	ofs.open(file_path, std::ofstream::out | std::ofstream::trunc);	//replace "trunc" with "app" for appemding over the same logFile

	string _line = "<<<----------------------------------------------------->>>";
	Write(_line);
	string Time = getTime();
	Write(Time);
	Write(_line);
}

void LogFile::Append(string filePath)
{
	strcpy(file_path, filePath.c_str());

	std::ofstream ofs;
	ofs.open(file_path, std::ofstream::out | std::ofstream::app);	//replace "trunc" with "app" for appemding over the same logFile

}

void LogFile::Write(const std::string& text)
{
	std::ofstream _logFile(file_path, std::ios_base::out | std::ios_base::app);
	_logFile << text << "\n";
}

void LogFile::WriteDouble(double value, int precision) {
	std::ofstream _logFile(file_path, std::ios_base::out | std::ios_base::app);
	_logFile << std::setprecision(precision) << std::fixed << value << "\n";
}

string LogFile::getTime()
{
	time_t rawtime;
	struct tm* timeinfo;
	char buffer[80];

	time(&rawtime);
	timeinfo = localtime(&rawtime);

	strftime(buffer, sizeof(buffer), "%d-%m-%Y %I:%M:%S", timeinfo);
	std::string str(buffer);

	return str;
}
