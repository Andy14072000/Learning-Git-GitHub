/*--------------------------------------------------------------------------------------------------------------
NAME			| DATE			| VERSION		| COMMENTS
----------------------------------------------------------------------------------------------------------------
BHUVAN BHARATH	| 23-12-2021	|	V1_0_0		| FRONT END UPDATED
--------------------------------------------------------------------------------------------------------------*/

#include "AppFrontEnd.h"

//UI DEFINITIONS
#define TESTS_STS_DLG					"tests_sts_dlg" 
#define MAIN_TESTS_DLG					"std_tests_dialog" 
#define TESTS_GALLERY_TBL				"gallery_tbl"
#define GALLERY_TBL_MAIN_PB				"main_pb"

#define QVT_MONITOR_APPLY_BUTTON		"run_btn"
#define QVT_MONITOR_HELP_BUTTON			"help_btn"
#define QVT_MONITOR_CANCEL_BUTTON		"cancel_btn"

#define	QVT_MONITOR_ENFORCE_BUTTON		"ActionBtn"
#define	QVT_MONITOR_REPORT_BUTTON		"ReportBtn"
#define	QVT_MONITOR_COMMENT_BUTTON		"InfoBtn"

#define	QVT_MONITOR_CHECK_LAYOUT		"checks_layout"
#define	QVT_MONITOR_CHECK_TYPE_RADIOGRP	"RadioGroup1"

#define QVT_MONITOR_OPT1				"opt_menu1"
#define QVT_MONITOR_OPT2				"opt_menu2"
#define QVT_MONITOR_OPT3				"opt_menu3"
#define QVT_MONITOR_OPT4				"opt_menu4"

#define	TESTS_STS_TBL					"rc_table1"
#define STS_TBL_ICON_PB					"tbl_icon_pb"
#define LOAD_STS_PB						"sts_btn"

//GLOBAL DECLARATIONS
LogFile log_file; // INITIALIZED WITH extern KEYWORD IN MAIN.H
ProError status; // INITIALIZED WITH extern KEYWORD IN MAIN.H
int	exit_status;
char mdl_name[PRO_NAME_SIZE], csv_path[MAX_PATH], p_pro_app_path[MAX_PATH];
//static ProFileName msgfil;

//OPTION MENU LIST
//Platform names
string pltfrm_names[] = { "[Select]","SCV", "LCV", "M&HCV" };
int pltfrm_names_size = size(pltfrm_names);
//Vehicle type names
string vehType_names[] = { "[Select]","Ace", "Zip", "Xenon", "Ultra", "Prima", "Signa" };
int vehType_names_size = size(vehType_names);
//Engine type names
string engType_names[] = { "[Select]","3L", "5L", "7L", "12L" };
int engType_names_size = size(engType_names);
//Aggregate names
string aggr_names[] = { "[Select]","Chasis", "Suspension", "Powertrain", "Differential", "Steering" };
int aggr_names_size = size(aggr_names);

//FUNTION PROTOTYPES
ProError AppGalleryActivate(char* dialog, char* component, char* CSV_filePath);
void Table1_cb_action(char* dialog, char* component, ProAppData appdata);
void Table2_cb_action(char* dialog, char* component, ProAppData appdata);
void stdTbl_cb_action(char* dialog, char* component, ProAppData appdata);
void tbl_pb_action(char* dialog, char* component, ProAppData app_data);
void tbl_cb_action(char* dialog, char* component, char* rowName);
int CountRows(vector<string> brassData);
void CharArrToLower(char charArr[PRO_PATH_SIZE]);
string TextWrap(string text, int position);
void GetAppStoreNames(vector<string>* tableData, ProBoolean WrapTxt, int* noOfRows);
//extern "C" ProError Create_Status_Table();
extern "C" ProError QVT_STDChecks_OPTIONMENU_Action(char* dialog_name, char* component, char* file_path1);
void addNamestoOptionMenu(int OpMenuIndex, string nameArr[], int names_size);
void RadioGroup1Action(char* dialog, char* component, ProAppData data);
ProError QVTCloseAction(char* dialog, char* component, ProAppData data);
ProError LoadStatus(char* dialog, char* component, ProAppData data);
ProError HoleAlignmentCheck(int test_index);
bool areEqual(double arr1[], double arr2[], int n, int m);
void UpdateStatusTable(char* dialog, int index, bool sts);
ProError DlgCloseAction(char* dialog, char* component, ProAppData data);

AppFrontEnd::AppFrontEnd()
{
}

AppFrontEnd::~AppFrontEnd()
{
}

int AppFrontEnd::initialize()
{
	log_file.Write("AppFrontEnd::initialize()");

	AppData	App_data;
	ProMdl model;
	ProName	w_mdl_name;
	char* map_File1, * req_resultFile;
	ProMdldata	mdl_data;
	ProCharLine	model_type;
	int	model_version;

	//Error Msg Output Declaration
	ProUIMessageButton* _buttons;
	ProUIMessageButton 	user_choice;
	ProArrayAlloc(1, sizeof(ProUIMessageButton), 1, (ProArray*)&_buttons);
	_buttons[0] = PRO_UI_MESSAGE_OK;
	ProPath message = L"Please Open an Assembly Model";

	status = ProMdlCurrentGet(&model);
	log_file.Write("ProMdlCurrentGet: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)
	{
		ProMdlType mdl_type;
		status = ProMdlTypeGet(model, &mdl_type);
		log_file.Write("model type: " + mdl_type);

		if (mdl_type != PRO_MDL_ASSEMBLY)
		{
			log_file.Write("xxxxx----- Aborting! -----xxxxx");
			status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Message", message, _buttons, PRO_UI_MESSAGE_OK, &user_choice);
			ProArrayFree((ProArray*)&_buttons);
		}
		else
		{
			strcpy(csv_path, "C:\\Users\\bb.ttl\\OneDrive - TATA MOTORS LTD\\2. Projects\\InterfaceRuleCheck\\DPDSCreoQVT\\DPDSCreoQVT\\text\\resource\\db\\scv_ace_3l_chasis.csv");

			status = ProUIDialogCreate(MAIN_TESTS_DLG, MAIN_TESTS_DLG);
			log_file.Write("ProUIDialogCreate: " + to_string(status));
			status = ProUIDialogCloseActionSet(MAIN_TESTS_DLG, (ProUIAction)QVTCloseAction, NULL);
			log_file.Write("ProUIDialogCloseActionSet: " + to_string(status));
			status = ProUIPushbuttonActivateActionSet(MAIN_TESTS_DLG, LOAD_STS_PB, (ProUIAction)LoadStatus, NULL);
			log_file.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

			status = ProUIDialogActivate(MAIN_TESTS_DLG, &exit_status);
			log_file.Write("ProUIDialogActivate: " + to_string(status));
			status = ProUIDialogAboveactivewindowSet(MAIN_TESTS_DLG, PRO_B_FALSE);
			log_file.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));

			vector<string> wrapped_names;
			vector<string> helpTxt_names;
			int no_of_rows;

			GetAppStoreNames(&wrapped_names, PRO_B_TRUE, &no_of_rows);
			log_file.Write("No of rows from csv table: " + to_string(no_of_rows));

			if (no_of_rows > 0)
			{
				int gal_row_nos;
				if (no_of_rows <= 5) {
					gal_row_nos = 1;
				}
				else {
					gal_row_nos = no_of_rows / 5;
				}
				log_file.Write("No. of rows in Gallery: " + to_string(gal_row_nos));

				char** galRows = new char* [gal_row_nos];
				for (int i = 0; i < gal_row_nos; i++)
				{
					galRows[i] = new char[PRO_NAME_SIZE];
					ProTKSprintf(galRows[i], "r%d", i);
				}

				status = ProUITableRowsInsert(MAIN_TESTS_DLG, TESTS_GALLERY_TBL, NULL, gal_row_nos, galRows);
				log_file.Write("ProUITableRowsInsert: " + to_string(status));

				if (status == PRO_TK_NO_ERROR)
				{
					char PBrowName[PRO_NAME_SIZE];
					char PBcolName[PRO_NAME_SIZE];
					char PB_Name[PRO_NAME_SIZE];
					int row_index = 0, col_index = 0;
					ProCharLine testName;
					ProLine w_testName;

					GetAppStoreNames(&helpTxt_names, PRO_B_FALSE, &no_of_rows);

					for (int i = 0; i < wrapped_names.size(); i++)
					{
						ProTKSprintf(PBrowName, "r%d", row_index);
						ProTKSprintf(PBcolName, "c%d", col_index);
						ProTKSprintf(PB_Name, "PB_%s_%s", PBrowName, PBcolName);

						status = ProUITableCellComponentCopy(MAIN_TESTS_DLG, TESTS_GALLERY_TBL, PBrowName, PBcolName, MAIN_TESTS_DLG, GALLERY_TBL_MAIN_PB, PB_Name);
						status = ProUIPushbuttonSizeSet(MAIN_TESTS_DLG, PB_Name, 150, 80);

						status = ProUIPushbuttonBitmapSet(MAIN_TESTS_DLG, PB_Name, "icon.bmp");

						ProTKSprintf(testName, "%d. %s", i + 1, wrapped_names[i].c_str());
						ProStringToWstring(w_testName, testName);
						status = ProUIPushbuttonTextSet(MAIN_TESTS_DLG, PB_Name, w_testName);

						ProTKSprintf(testName, "%s", helpTxt_names[i].c_str());
						ProStringToWstring(w_testName, testName);
						status = ProUIPushbuttonHelptextSet(MAIN_TESTS_DLG, PB_Name, w_testName);

						status = ProUIPushbuttonShow(MAIN_TESTS_DLG, PB_Name);
						status = ProUIPushbuttonActivateActionSet(MAIN_TESTS_DLG, PB_Name, (ProUIAction)tbl_pb_action, NULL);

						col_index++;
						if (col_index % 5 == 0)
						{
							row_index++;
							col_index = 0;
						}
					}
					delete[] galRows;
					wrapped_names.clear();
					helpTxt_names.clear();
				}
			}
			else
			{
				log_file.Write("Insufficient data from the CSV file!");
			}

			status = ProUIDialogCreate(TESTS_STS_DLG, TESTS_STS_DLG);
			log_file.Write("ProUIDialogCreate: " + to_string(status));

			vector<string> stsTblData;
			char cbName[PRO_NAME_SIZE], ipPanelName[PRO_NAME_SIZE], pbName[PRO_NAME_SIZE], icon_pbName[PRO_NAME_SIZE];

			CSVReader _CSVReader(csv_path, ",");
			stsTblData = _CSVReader.getData(',');
			int stsTblRow_nos = (CountRows(stsTblData) - 1); // -1 is to ignore the header column in csv
			log_file.Write("No of items from csv table: " + to_string(stsTblRow_nos));

			char* columnNames_1[] = { "S_NO","ICON", "TEST_NAME", "INPUTSTS" };
			wchar_t* columnLabels_1[] = { L"S.no",L"", L"Test Name", L"Input status" };
			int columnWidths_1[] = { 2,1,15,6 };

			status = ProUITableColumnnamesSet(TESTS_STS_DLG, TESTS_STS_TBL, 4, columnNames_1);
			status = ProUITableColumnlabelsSet(TESTS_STS_DLG, TESTS_STS_TBL, 4, columnLabels_1);
			status = ProUITableColumnwidthsSet(TESTS_STS_DLG, TESTS_STS_TBL, 4, columnWidths_1);

			char** stsTblRows = new char* [stsTblRow_nos];
			for (int i = 0; i < stsTblRow_nos; i++)
			{
				stsTblRows[i] = new char[PRO_NAME_SIZE];
				ProTKSprintf(stsTblRows[i], "r_%d", i);
			}

			status = ProUITableRowsInsert(TESTS_STS_DLG, TESTS_STS_TBL, NULL, stsTblRow_nos, stsTblRows);
			log_file.Write("ProUITableRowsInsert: " + to_string(status));

			status = ProUIPushbuttonBitmapSet(TESTS_STS_DLG, STS_TBL_ICON_PB, "help.gif");
			log_file.Write("ProUIPushbuttonBitmapSet: " + to_string(status));

			enum cols
			{
				TEST_NAME, INPUT_STS
			};

			int colCount = 0, rowId = 0, sNo = 0;
			size_t space_pos;

			for (int i = 3; i < stsTblData.size(); i++) //i=3 [reason: skipping the headers in csv file] 
			{
				string sts_tbl_item = stsTblData[i];
				char* sts_tbl_row_name = stsTblRows[rowId];
				sNo = rowId + 1;

				//REMOVING leading spaces in the element
				space_pos = sts_tbl_item.find_first_not_of(' ');
				if (space_pos != 0)
				{
					sts_tbl_item.erase(0, space_pos - 1);
				}
				//REMOVING trailing spaces in the element
				space_pos = sts_tbl_item.find_last_not_of(' ');
				sts_tbl_item.erase(space_pos + 1);

				ProLine w_itemName;
				ProCharLine c_itemName;

				switch (colCount)
				{
				case TEST_NAME:
					// S NO
					ProTKSprintf(c_itemName, " %d.", sNo);
					ProStringToWstring(w_itemName, c_itemName);
					status = ProUITableCellLabelSet(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "S_NO", w_itemName);
					log_file.Write("ProUITableCellLabelSet: " + to_string(status));

					// DYNAMIC ICON PUSHBUTTONS
					ProTKSprintf(icon_pbName, "tbl1_icon_pb%d", sNo);
					status = ProUITableCellComponentCopy(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "ICON", TESTS_STS_DLG, STS_TBL_ICON_PB, icon_pbName);
					log_file.Write("ProUITableCellComponentCopy: " + to_string(status) + "\ticon_pbName: " + string(icon_pbName));

					// TEST NAMES
					ProTKSprintf(c_itemName, "%s", sts_tbl_item.c_str());
					ProStringToWstring(w_itemName, c_itemName);
					status = ProUITableCellLabelSet(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "TEST_NAME", w_itemName);
					log_file.Write("ProUITableCellLabelSet: " + to_string(status));

					break;

				case INPUT_STS:
					// INPUTSTS column operation
					if (strcmp(sts_tbl_item.c_str(), "y") == 0)
					{
						ProStringToWstring(w_itemName, "     Pass/Fail");
						status = ProUITableCellLabelSet(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "INPUTSTS", w_itemName);
					}
					else
					{
						status = ProUITableCellLabelSet(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "INPUTSTS", L"     NR");
					}
					break;
				default:
					break;
				}
				colCount++;
				if (strcmp(sts_tbl_item.c_str(), "#end") == 0)
				{
					colCount = 0;
					rowId++;
				}
			}
			delete[] stsTblRows;

			log_file.Write("main function end");
			return status;
		}
	}
	else
	{
		log_file.Write("xxxxx----- Aborting! -----xxxxx");
		status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Message", message, _buttons, PRO_UI_MESSAGE_OK, &user_choice);
		ProArrayFree((ProArray*)&_buttons);
	}

}

ProError LoadStatus(char* dialog, char* component, ProAppData data)
{
	log_file.Write("----- Inside Load status function -----");

	/*status = ProUIDialogCreate(TESTS_STS_DLG, TESTS_STS_DLG);
	log_file.Write("ProUIDialogCreate: " + to_string(status));*/
	status = ProUIDialogCloseActionSet(TESTS_STS_DLG, (ProUIAction)DlgCloseAction, NULL);
	log_file.Write("ProUIDialogCloseActionSet: " + to_string(status));

	int dlgStatus;
	status = ProUIDialogShow(TESTS_STS_DLG);
	log_file.Write("ProUIDialogShow: " + to_string(status));

	status = ProUIDialogActivate(TESTS_STS_DLG, &dlgStatus);
	log_file.Write("ProUIDialogActivate: " + to_string(status));
	///*status = ProUIDialogDestroy(TESTS_STS_DLG);
	//log_file.Write("ProUIDialogDestroy: " + to_string(status));*/
	//status = ProUIDialogAboveactivewindowSet(TESTS_STS_DLG, PRO_B_FALSE);
	//log_file.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));



	//status = ProUIDialogDestroy(TESTS_STS_DLG);
	//log_file.Write("ProUIDialogDestroy: " + to_string(status));
	//vector<string> stsTblData;
	//char cbName[PRO_NAME_SIZE], ipPanelName[PRO_NAME_SIZE], pbName[PRO_NAME_SIZE], icon_pbName[PRO_NAME_SIZE];

	//CSVReader _CSVReader(csv_path, ",");
	//stsTblData = _CSVReader.getData(',');
	//int stsTblRow_nos = (CountRows(stsTblData) - 1); // -1 is to ignore the header column in csv
	//log_file.Write("No of items from csv table: " + to_string(stsTblRow_nos));

	//char* columnNames_1[] = { "S_NO","ICON", "TEST_NAME", "INPUTSTS" };
	//wchar_t* columnLabels_1[] = { L"S.no",L"", L"Test Name", L"Input status"};
	//int columnWidths_1[] = {2,1,15,6};

	//status = ProUITableColumnnamesSet(TESTS_STS_DLG, TESTS_STS_TBL, 4, columnNames_1);
	//status = ProUITableColumnlabelsSet(TESTS_STS_DLG, TESTS_STS_TBL,4, columnLabels_1);
	//status = ProUITableColumnwidthsSet(TESTS_STS_DLG, TESTS_STS_TBL, 4, columnWidths_1);

	//char** stsTblRows = new char* [stsTblRow_nos];
	//for (int i = 0; i < stsTblRow_nos; i++)
	//{
	//	stsTblRows[i] = new char[PRO_NAME_SIZE];
	//	ProTKSprintf(stsTblRows[i], "r_%d", i);
	//}

	//status = ProUITableRowsInsert(TESTS_STS_DLG, TESTS_STS_TBL, NULL, stsTblRow_nos, stsTblRows);
	//log_file.Write("ProUITableRowsInsert: " + to_string(status));

	//status = ProUIPushbuttonBitmapSet(TESTS_STS_DLG, STS_TBL_ICON_PB, "help.gif");
	//log_file.Write("ProUIPushbuttonBitmapSet: " + to_string(status));

	//enum cols
	//{
	//	TEST_NAME, INPUT_STS
	//};

	//int colCount = 0, rowId = 0, sNo = 0;
	//size_t space_pos;

	//for (int i = 3; i < stsTblData.size(); i++) //i=3 [reason: skipping the headers in csv file] 
	//{
	//	string sts_tbl_item = stsTblData[i];
	//	char* sts_tbl_row_name = stsTblRows[rowId];
	//	sNo = rowId + 1;

	//	//REMOVING leading spaces in the element
	//	space_pos = sts_tbl_item.find_first_not_of(' ');
	//	if (space_pos != 0)
	//	{
	//		sts_tbl_item.erase(0, space_pos - 1);
	//	}
	//	//REMOVING trailing spaces in the element
	//	space_pos = sts_tbl_item.find_last_not_of(' ');
	//	sts_tbl_item.erase(space_pos + 1);
	//
	//	ProLine w_itemName;
	//	ProCharLine c_itemName;

	//	switch (colCount)
	//	{
	//	case TEST_NAME:
	//		// S NO
	//		ProTKSprintf(c_itemName, " %d.", sNo);
	//		ProStringToWstring(w_itemName, c_itemName);
	//		status = ProUITableCellLabelSet(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "S_NO", w_itemName);

	//		// DYNAMIC ICON PUSHBUTTONS
	//		ProTKSprintf(icon_pbName, "tbl1_icon_pb%d", sNo);
	//		status = ProUITableCellComponentCopy(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "ICON", TESTS_STS_DLG, STS_TBL_ICON_PB, icon_pbName);
	//		//log_file.Write("ProUITableCellComponentCopy: " + to_string(status) + "\ticon_pbName: " + string(icon_pbName));
	// 
	//		// TEST NAMES
	//		ProTKSprintf(c_itemName, "%s", sts_tbl_item.c_str());
	//		ProStringToWstring(w_itemName, c_itemName);
	//		status = ProUITableCellLabelSet(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "TEST_NAME", w_itemName);

	//		break;

	//	case INPUT_STS:
	//		// INPUTSTS column operation
	//		if (strcmp(sts_tbl_item.c_str(), "y") == 0)
	//		{
	//			ProStringToWstring(w_itemName, "     Pass/Fail");
	//			status = ProUITableCellLabelSet(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "INPUTSTS", w_itemName);
	//		}
	//		else
	//		{
	//			status = ProUITableCellLabelSet(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "INPUTSTS", L"     NR");
	//		}
	//		break;
	//	default:
	//		break;
	//	}
	//	colCount++;
	//	if (strcmp(sts_tbl_item.c_str(), "#end") == 0)
	//	{
	//		colCount = 0;
	//		rowId++;
	//	}
	//}
	//delete[] stsTblRows;

	//status = ProUIDialogActivate(TESTS_STS_DLG, &exit_status);
	//log_file.Write("ProUIDialogActivate: " + to_string(status));
	//status = ProUIDialogAboveactivewindowSet(TESTS_STS_DLG, PRO_B_TRUE);
	//log_file.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));
	//status = ProUIDialogDestroy(TESTS_STS_DLG);

	return status;
}

//ProError Create_Status_Table()
//{
//	log_file.Write("--------------------------------------------- Inside Create_Status_Table function ---------------------------------------------");
//
//	vector<string> stsTblData;
//	char cbName[PRO_NAME_SIZE], ipPanelName[PRO_NAME_SIZE], pbName[PRO_NAME_SIZE], icon_pbName[PRO_NAME_SIZE];
//
//	CSVReader _CSVReader(csv_path, ",");
//	stsTblData = _CSVReader.getData(',');
//	int stsTblRow_nos = (CountRows(stsTblData) - 1); // -1 is to ignore the header column in csv
//	log_file.Write("No of items from csv table: " + to_string(stsTblRow_nos));
//
//	char* columnNames_1[] = { "S_NO","ICON", "TEST_NAME", "INPUTSTS" };
//	wchar_t* columnLabels_1[] = { L"S.no",L"", L"Test Name", L"Input status"};
//	int columnWidths_1[] = {2,1,15,6};
//
//	status = ProUITableColumnnamesSet(TESTS_STS_DLG, TESTS_STS_TBL, 4, columnNames_1);
//	status = ProUITableColumnlabelsSet(TESTS_STS_DLG, TESTS_STS_TBL,4, columnLabels_1);
//	status = ProUITableColumnwidthsSet(TESTS_STS_DLG, TESTS_STS_TBL, 4, columnWidths_1);
//
//	char** stsTblRows = new char* [stsTblRow_nos];
//	for (int i = 0; i < stsTblRow_nos; i++)
//	{
//		stsTblRows[i] = new char[PRO_NAME_SIZE];
//		ProTKSprintf(stsTblRows[i], "r_%d", i);
//	}
//
//	status = ProUITableRowsInsert(TESTS_STS_DLG, TESTS_STS_TBL, NULL, stsTblRow_nos, stsTblRows);
//	log_file.Write("ProUITableRowsInsert: " + to_string(status));
//
//	status = ProUITablePushbuttonAdd(TESTS_STS_DLG, TESTS_STS_TBL, STS_TBL_ICON_PB);
//	status = ProUIPushbuttonBitmapSet(TESTS_STS_DLG, STS_TBL_ICON_PB, "help.gif");
//
//	enum cols
//	{
//		TEST_NAME, INPUT_STS
//	};
//
//	int colCount = 0, rowId = 0, sNo = 0;
//
//	status = ProUITablePushbuttonAdd(TESTS_STS_DLG, TESTS_STS_TBL, RC_TABLE_INPUT_PB);
//	status = ProUIPushbuttonTextSet(TESTS_STS_DLG, RC_TABLE_INPUT_PB, L"Select");
//
//	for (int i = 3; i < stsTblData.size(); i++) //i=3 [reason: skipping the headers in csv file] 
//	{
//		string sts_tbl_item = stsTblData[i];
//		char* sts_tbl_row_name = stsTblRows[rowId];
//		sNo = rowId + 1;
//
//		ProLine w_itemName;
//		ProCharLine c_itemName;
//
//		switch (colCount)
//		{
//		case TEST_NAME:
//			//TEST NAMES
//			ProTKSprintf(c_itemName, "%d. %s", sNo, sts_tbl_item.c_str());
//			ProStringToWstring(w_itemName, c_itemName);
//			status = ProUITableCellLabelSet(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "TEST_NAME", w_itemName);
//			break;
//		case INPUT_STS:
//			if (strcmp(sts_tbl_item.c_str(), "y") == 0)
//			{
//				//INPUTSTS column operation
//				ProStringToWstring(w_itemName, "        Pass/Fail");
//				status = ProUITableCellLabelSet(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "INPUTSTS", w_itemName);
//			}
//			else
//			{
//				//INPUTSTS column operation
//				status = ProUITableCellDisable(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "INPUTSTS");
//				status = ProUITableCellLabelSet(TESTS_STS_DLG, TESTS_STS_TBL, sts_tbl_row_name, "INPUTSTS", L"        NR");
//			}
//			break;
//		default:
//			break;
//		}
//		colCount++;
//		if (strcmp(sts_tbl_item.c_str(), "#end") == 0)
//		{
//			colCount = 0;
//			rowId++;
//		}
//	}
//	delete[] stsTblRows;
//
//	return status;
//}
ProError QVT_STDChecks_OPTIONMENU_Action(char* dialog_name, char* component, char* file_path1)
{
	ProError status;
	FILE* fp = NULL;
	wchar_t* wopt_menu1_val = NULL, * wopt_menu2_val = NULL, * wopt_menu3_val = NULL, * wopt_menu4_val = NULL;
	char opt_menu1_val[PRO_PATH_SIZE], opt_menu2_val[PRO_PATH_SIZE], opt_menu3_val[PRO_PATH_SIZE], opt_menu4_val[PRO_PATH_SIZE], CSV_fileName[PRO_PATH_SIZE];

	log_file.Write("--------------------------------------------- Inside QVT_STDChecks_OPTIONMENU_Action Function ---------------------------------------------");

	log_file.Write("file_path1:" + string(file_path1));

	status = ProUIPushbuttonDisable(dialog_name, QVT_MONITOR_REPORT_BUTTON);
	status = ProUIPushbuttonDisable(dialog_name, QVT_MONITOR_COMMENT_BUTTON);

	status = ProUIOptionmenuValueGet(dialog_name, QVT_MONITOR_OPT1, &wopt_menu1_val);
	status = ProUIOptionmenuValueGet(dialog_name, QVT_MONITOR_OPT2, &wopt_menu2_val);
	status = ProUIOptionmenuValueGet(dialog_name, QVT_MONITOR_OPT3, &wopt_menu3_val);
	status = ProUIOptionmenuValueGet(dialog_name, QVT_MONITOR_OPT4, &wopt_menu4_val);
	ProWstringToString(opt_menu1_val, wopt_menu1_val);
	log_file.Write("option_menu_1 selection:" + string(opt_menu1_val));
	ProWstringToString(opt_menu2_val, wopt_menu2_val);
	log_file.Write("option_menu_2 selection:" + string(opt_menu2_val));
	ProWstringToString(opt_menu3_val, wopt_menu3_val);
	log_file.Write("option_menu_3 selection:" + string(opt_menu3_val));
	ProWstringToString(opt_menu4_val, wopt_menu4_val);
	log_file.Write("option_menu_4 selection:" + string(opt_menu4_val));

	if ((string)opt_menu4_val == "[Select]")
	{
		status = ProUIPushbuttonDisable(dialog_name, QVT_MONITOR_APPLY_BUTTON);
		log_file.Write("ProUIPushbuttonDisable:" + to_string(status));
	}
	else
	{
		status = ProUIPushbuttonEnable(dialog_name, QVT_MONITOR_APPLY_BUTTON);
		log_file.Write("ProUIPushbuttonEnable:" + to_string(status));
	}

	CharArrToLower(opt_menu1_val);
	CharArrToLower(opt_menu2_val);
	CharArrToLower(opt_menu3_val);
	CharArrToLower(opt_menu4_val);

	strcpy(CSV_fileName, opt_menu1_val);
	strcat(CSV_fileName, "_");
	strcat(CSV_fileName, opt_menu2_val);
	strcat(CSV_fileName, "_");
	strcat(CSV_fileName, opt_menu3_val);
	strcat(CSV_fileName, "_");
	strcat(CSV_fileName, opt_menu4_val);
	status = ProWstringFree(wopt_menu1_val);
	status = ProWstringFree(wopt_menu2_val);
	status = ProWstringFree(wopt_menu3_val);
	status = ProWstringFree(wopt_menu4_val);

	log_file.Write("CSV_fileName:" + string(CSV_fileName));

	strcpy(csv_path, file_path1);
	strcat(csv_path, "\\CVBU_STD\\");
	strcat(csv_path, CSV_fileName);
	strcat(csv_path, ".csv");
	log_file.Write("csv_path:" + string(csv_path));

	return status;
}

void RadioGroup1Action(char* dialog, char* component, ProAppData data)
{
	ProError	status;
	char** opt_sel1 = NULL, * cstr;
	int			n_sel1;
	int			n_files = 1;
	char** StdFileList;
	wchar_t** w_StdFileList;

	log_file.Write("--------------------------------------------- Inside RadioGroup1Action Function ---------------------------------------------");

	status = ProUIRadiogroupSelectednamesGet(TESTS_STS_DLG, QVT_MONITOR_CHECK_TYPE_RADIOGRP, &n_sel1, &opt_sel1);
	log_file.Write("ProUIRadiogroupSelectednamesGet: " + to_string(status));
	log_file.Write("n_sel: " + to_string(n_sel1) + "\topt_sel1: " + opt_sel1[0]);

	cstr = strtok(opt_sel1[0], " ");

	if ((!strcmp("p1", cstr)))
	{
		//Platform names
		addNamestoOptionMenu(1, pltfrm_names, pltfrm_names_size);

		//Vehicle type names
		addNamestoOptionMenu(2, vehType_names, vehType_names_size);

		//Engine type names
		addNamestoOptionMenu(3, engType_names, engType_names_size);

		//Aggregate names
		addNamestoOptionMenu(4, aggr_names, aggr_names_size);

		status = ProUIOptionmenuEnable(TESTS_STS_DLG, QVT_MONITOR_OPT1);
		status = ProUIOptionmenuEnable(TESTS_STS_DLG, QVT_MONITOR_OPT2);
		status = ProUIOptionmenuEnable(TESTS_STS_DLG, QVT_MONITOR_OPT3);
		status = ProUIOptionmenuEnable(TESTS_STS_DLG, QVT_MONITOR_OPT4);
	}
	else
	{
		string pvbu_empty_list[] = { "[Select]" };
		int pvbu_empty_list_size = size(pvbu_empty_list);

		addNamestoOptionMenu(1, pvbu_empty_list, pvbu_empty_list_size);
		addNamestoOptionMenu(2, pvbu_empty_list, pvbu_empty_list_size);
		addNamestoOptionMenu(3, pvbu_empty_list, pvbu_empty_list_size);
		addNamestoOptionMenu(4, pvbu_empty_list, pvbu_empty_list_size);

		//Option Menu Enable and disable
		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT1);
		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT2);
		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT3);
		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT4);

		status = ProUIPushbuttonDisable(TESTS_STS_DLG, QVT_MONITOR_APPLY_BUTTON);
	}

	/*
	if ((!strcmp("p1", cstr)) && modeltype == PRO_MDL_DRAWING)
	{
		StdFileList = (char**)malloc(50 * sizeof(char*));
		w_StdFileList = (wchar_t**)malloc(50 * sizeof(wchar_t*));

		int len1 = strlen("--Select--");
		StdFileList[0] = new char[len1 + 1];
		strcpy(StdFileList[0], "--Select--");

		w_StdFileList[0] = new wchar_t[len1 + 1];

		ProStringToWstring(w_StdFileList[0], StdFileList[0]);
		fprintf(fp, "Set select \n");
		fflush(fp);

		status = ProUIOptionmenuNamesSet(TESTS_STS_DLG, QVT_MONITOR_OPT2, n_files, StdFileList);
		fprintf(fp, "ProUIOptionmenuNamesSet --Select-- for opt2 Status = %d \n", status);
		fflush(fp);

		status = ProUIOptionmenuLabelsSet(TESTS_STS_DLG, QVT_MONITOR_OPT2, n_files, w_StdFileList);
		fprintf(fp, "ProUIOptionmenuLabelsSet --Select-- for opt2 Status = %d \n", status);

		status = ProUIOptionmenuNamesSet(TESTS_STS_DLG, QVT_MONITOR_OPT3, n_files, StdFileList);
		fprintf(fp, "ProUIOptionmenuNamesSet --Select-- for opt3 Status = %d \n", status);
		fflush(fp);

		status = ProUIOptionmenuLabelsSet(TESTS_STS_DLG, QVT_MONITOR_OPT3, n_files, w_StdFileList);
		fprintf(fp, "ProUIOptionmenuLabelsSet --Select-- for opt3 Status = %d \n", status);

		//Option Menu disable
		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT1);

		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT2);

		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT3);

		strcpy(selectedCheckName, "Drawing");
		status = fillStandardFilesOnLoad("Drawing", fp);
		fprintf(fp, "fillStandardFilesOnLoad Status is = %d \n", status);
		fflush(fp);
	}

	else if ((!strcmp("p2", cstr)) && modeltype != PRO_MDL_DRAWING)
	{
		ProUIPushbuttonEnable(TESTS_STS_DLG, QVT_MONITOR_APPLY_BUTTON);

		StdFileList = (char**)malloc(50 * sizeof(char*));
		w_StdFileList = (wchar_t**)malloc(50 * sizeof(wchar_t*));

		int len1 = strlen("--Select--");
		//StdFileList[0] = (char*)calloc( len1+1, sizeof(char) );
		StdFileList[0] = new char[len1 + 1];
		strcpy(StdFileList[0], "--Select--");

		//w_StdFileList[0] = (wchar_t*)calloc( len1+1, sizeof(wchar_t) );
		w_StdFileList[0] = new wchar_t[len1 + 1];
		ProStringToWstring(w_StdFileList[0], StdFileList[0]);
		fprintf(fp, "Set select \n");
		fflush(fp);

		status = ProUIOptionmenuNamesSet(TESTS_STS_DLG, QVT_MONITOR_OPT2, n_files, StdFileList);
		fprintf(fp, "ProUIOptionmenuNamesSet --Select-- for opt2 Status = %d \n", status);
		fflush(fp);

		status = ProUIOptionmenuLabelsSet(TESTS_STS_DLG, QVT_MONITOR_OPT2, n_files, w_StdFileList);
		fprintf(fp, "ProUIOptionmenuLabelsSet --Select-- for opt2 Status = %d \n", status);

		status = ProUIOptionmenuNamesSet(TESTS_STS_DLG, QVT_MONITOR_OPT3, n_files, StdFileList);
		fprintf(fp, "ProUIOptionmenuNamesSet --Select-- for opt3 Status = %d \n", status);
		fflush(fp);

		status = ProUIOptionmenuLabelsSet(TESTS_STS_DLG, QVT_MONITOR_OPT3, n_files, w_StdFileList);
		fprintf(fp, "ProUIOptionmenuLabelsSet --Select-- for opt3 Status = %d \n", status);

		//Option Menu Enable and disable

		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT1);

		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT2);

		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT3);

		status = SelectAggrAction_TPL_DMU(dialog, component, data, "TPL");

		strcpy(selectedCheckName, "TPL");
	}

	else if ((!strcmp("p3", cstr)) && modeltype != PRO_MDL_DRAWING)
	{

		ProUIPushbuttonDisable(TESTS_STS_DLG, QVT_MONITOR_APPLY_BUTTON);
		ProUIMessageButton* _buttons;
		ProUIMessageButton 	user_choice;
		ProArrayAlloc(1, sizeof(ProUIMessageButton), 1, (ProArray*)&_buttons);
		_buttons[0] = PRO_UI_MESSAGE_OK;
		ProPath message = L"Currrently only BOm and TPL checks are enable..";
		status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Message", message, _buttons, PRO_UI_MESSAGE_OK, &user_choice);
		ProArrayFree((ProArray*)&_buttons);
	}

	else if ((!strcmp("p4", cstr)) && modeltype != PRO_MDL_DRAWING)
	{
		ProUIMessageButton* _buttons;
		ProUIMessageButton 	user_choice;
		ProUIPushbuttonEnable(TESTS_STS_DLG, QVT_MONITOR_APPLY_BUTTON);
		ProArrayAlloc(1, sizeof(ProUIMessageButton), 1, (ProArray*)&_buttons);
		_buttons[0] = PRO_UI_MESSAGE_OK;
		ProPath message = L"Currrently only BOm and TPL checks are enable..";
		status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Message", message, _buttons, PRO_UI_MESSAGE_OK, &user_choice);
		ProArrayFree((ProArray*)&_buttons);
		ProUIPushbuttonEnable(TESTS_STS_DLG, QVT_MONITOR_APPLY_BUTTON);

		StdFileList = (char**)malloc(50 * sizeof(char*));
		w_StdFileList = (wchar_t**)malloc(50 * sizeof(wchar_t*));

		int len1 = strlen("--Select--");
		StdFileList[0] = (char*)calloc(len1 + 1, sizeof(char));
		strcpy(StdFileList[0], "--Select--");

		w_StdFileList[0] = (wchar_t*)calloc(len1 + 1, sizeof(wchar_t));
		ProStringToWstring(w_StdFileList[0], StdFileList[0]);
		fprintf(fp, "Set select \n");
		fflush(fp);

		status = ProUIOptionmenuNamesSet(TESTS_STS_DLG, QVT_MONITOR_OPT2, n_files, StdFileList);
		fprintf(fp, "ProUIOptionmenuNamesSet --Select-- for opt2 Status = %d \n", status);
		fflush(fp);

		status = ProUIOptionmenuLabelsSet(TESTS_STS_DLG, QVT_MONITOR_OPT2, n_files, w_StdFileList);
		fprintf(fp, "ProUIOptionmenuLabelsSet --Select-- for opt2 Status = %d \n", status);

		status = ProUIOptionmenuNamesSet(TESTS_STS_DLG, QVT_MONITOR_OPT3, n_files, StdFileList);
		fprintf(fp, "ProUIOptionmenuNamesSet --Select-- for opt3 Status = %d \n", status);
		fflush(fp);

		status = ProUIOptionmenuLabelsSet(TESTS_STS_DLG, QVT_MONITOR_OPT3, n_files, w_StdFileList);
		fprintf(fp, "ProUIOptionmenuLabelsSet --Select-- for opt3 Status = %d \n", status);

		//Option Menu disable
		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT1);

		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT2);

		status = ProUIOptionmenuDisable(TESTS_STS_DLG, QVT_MONITOR_OPT3);

		strcpy(selectedCheckName, "DFM");

		fprintf(fp, "Before File Standard On Load function in DFM \n");
		fflush(fp);

		status = fillStandardFilesOnLoad("DFM", fp);
		fprintf(fp, "fillStandardFilesOnLoad Status is = %d \n", status);
		fflush(fp);
	}
	else
	{
		ProUIPushbuttonDisable(TESTS_STS_DLG, QVT_MONITOR_APPLY_BUTTON);
		ProUIMessageButton* _buttons;
		ProUIMessageButton 	user_choice;
		ProArrayAlloc(1, sizeof(ProUIMessageButton), 1, (ProArray*)&_buttons);
		_buttons[0] = PRO_UI_MESSAGE_OK;
		ProPath message = L"BOM Checks is only applicable to drawing document and Others are applicable to PRT/ASSM only.";
		status = ProUIMessageDialogDisplay(PROUIMESSAGE_WARNING, L"Message", message, _buttons, PRO_UI_MESSAGE_OK, &user_choice);
		ProArrayFree((ProArray*)&_buttons);
	}*/
}

void addNamestoOptionMenu(int OpMenuIndex, string nameArr[], int names_size)
{
	ProError status;
	char** char_list;
	wchar_t** w_char_list;

	log_file.Write("No. of names: " + to_string(names_size));

	char_list = (char**)calloc(names_size, sizeof(char*));
	w_char_list = (wchar_t**)calloc(names_size + 1, sizeof(wchar_t*));

	for (int i = 0; i < names_size; i++)
	{
		int len1 = strlen(nameArr[i].c_str());

		char_list[i] = new char[len1 + 1];
		strcpy(char_list[i], nameArr[i].c_str());

		w_char_list[i] = new wchar_t[len1 + 1];
		ProStringToWstring(w_char_list[i], char_list[i]);
	}
	if (OpMenuIndex == 1)
	{
		status = ProUIOptionmenuNamesSet(TESTS_STS_DLG, QVT_MONITOR_OPT1, names_size, char_list);
		log_file.Write("ProUIOptionmenuNamesSet->pltfrm_names: " + to_string(status));
		status = ProUIOptionmenuLabelsSet(TESTS_STS_DLG, QVT_MONITOR_OPT1, names_size, w_char_list);
		log_file.Write("ProUIOptionmenuLabelsSet->w_pltfrm_names: " + to_string(status));
	}
	else if (OpMenuIndex == 2)
	{
		status = ProUIOptionmenuNamesSet(TESTS_STS_DLG, QVT_MONITOR_OPT2, names_size, char_list);
		log_file.Write("ProUIOptionmenuNamesSet->vehType_names: " + to_string(status));
		status = ProUIOptionmenuLabelsSet(TESTS_STS_DLG, QVT_MONITOR_OPT2, names_size, w_char_list);
		log_file.Write("ProUIOptionmenuLabelsSet->w_vehType_names: " + to_string(status));
	}
	else if (OpMenuIndex == 3)
	{
		status = ProUIOptionmenuNamesSet(TESTS_STS_DLG, QVT_MONITOR_OPT3, names_size, char_list);
		log_file.Write("ProUIOptionmenuNamesSet->engType_names: " + to_string(status));
		status = ProUIOptionmenuLabelsSet(TESTS_STS_DLG, QVT_MONITOR_OPT3, names_size, w_char_list);
		log_file.Write("ProUIOptionmenuLabelsSet->w_engType_names: " + to_string(status));
	}
	else
	{
		status = ProUIOptionmenuNamesSet(TESTS_STS_DLG, QVT_MONITOR_OPT4, names_size, char_list);
		log_file.Write("ProUIOptionmenuNamesSet->aggr_names: " + to_string(status));
		status = ProUIOptionmenuLabelsSet(TESTS_STS_DLG, QVT_MONITOR_OPT4, names_size, w_char_list);
		log_file.Write("ProUIOptionmenuLabelsSet->w_aggr_names: " + to_string(status));
	}
	free(char_list);
	free(w_char_list);
}

void GetAppStoreNames(vector<string>* tableData, ProBoolean WrapTxt, int* noOfRows)
{
	log_file.Write("--------------------------------------------- Inside GetAppStoreNames function ---------------------------------------------");
	ProError Status;

	vector<string> csv_data;
	CSVReader _CSVReader(csv_path, ",");
	csv_data = _CSVReader.getData(',');
	*noOfRows = (CountRows(csv_data) - 1);

	enum cols
	{
		TESTNAME, INPUT_STS
	};

	int cols_count = 0;
	size_t Pos;

	for (int i = 3; i < csv_data.size(); i++) //i=3 [reason: skipping the headers and its (#end) in csv file] 
	{
		string tbl_item = csv_data[i];

		switch (cols_count)
		{
		case TESTNAME:

			//REMOVING leading spaces in the element
			Pos = tbl_item.find_first_not_of(' ');
			if (Pos != 0)
			{
				tbl_item.erase(0, Pos - 1);
			}
			//REMOVING trailing spaces in the element
			Pos = tbl_item.find_last_not_of(' ');
			tbl_item.erase(Pos + 1);

			if (WrapTxt == PRO_B_FALSE)
			{
				tableData->push_back(tbl_item);
			}
			else
			{
				//for APP GALLERY 
				string wrapdTxt = TextWrap(tbl_item, 3);
				tableData->push_back(wrapdTxt);
			}
			break;

		case INPUT_STS:

			break;

		default:

			break;
		}
		cols_count++;

		if (strcmp(tbl_item.c_str(), "#end") == 0)
		{
			cols_count = 0;
		}
	}
	csv_data.clear();
}

string TextWrap(string text, int position)
{
	int pos = text.find_first_of(" ", position);
	if (pos != 0) {
		text[pos] = '\n';
	}
	return text;
}

void CharArrToLower(char charArr[PRO_PATH_SIZE])
{
	for (int b = 0; b <= strlen(charArr); b++) {
		charArr[b] = tolower(charArr[b]);
	}
}

int CountRows(vector<string> brassData)
{
	// CALUCLATE ROWS COUNT
	int row_count = 0;
	bool row_end = false;
	for (vector<string>::iterator row = brassData.begin(); row != brassData.end(); ++row)
	{
		string item = *row;
		// END COLUMNS
		if (strcmp(item.c_str(), "#end") == 0) {
			row_end = true;
			row_count += 1;
		}
	}
	return row_count;
}

ProError AppGalleryActivate(char* dialog, char* component, char* CSV_filePath)
{
	ProError status;
	/*int exit_status;

	log_file.Write("--------------------------------------------- Inside AppGalleryActivate function ---------------------------------------------");
	log_file.Write("CSV_filePath: " + string(CSV_filePath));

	int no_of_rows;
	char** tbl_row_names;
	char* cbName;
	ProBoolean CB_is_ON;
	vector<string> SelectedStdTests;
	wchar_t* w_testName;
	char s_testName[PRO_NAME_SIZE];

	status = ProUITableRownamesGet(TESTS_STS_DLG, TESTS_STS_TBL, &no_of_rows, &tbl_row_names);
	log_file.Write("no of rows in table1: " + to_string(no_of_rows));

	for (int i = 0; i < no_of_rows; i++)
	{
		status = ProUITableCellComponentNameGet(TESTS_STS_DLG, TESTS_STS_TBL, tbl_row_names[i], "CHKBTN", &cbName);
		log_file.Write("cbName: " + string(cbName));

		status = ProUICheckbuttonGetState(TESTS_STS_DLG, cbName, &CB_is_ON);
		if (CB_is_ON == PRO_B_TRUE)
		{
			status = ProUITableCellLabelGet(TESTS_STS_DLG, TESTS_STS_TBL, tbl_row_names[i], "TEST_NAME", &w_testName);
			ProWstringToString(s_testName, w_testName);
			SelectedStdTests.push_back(string(s_testName));
		}
	}

	for (auto selName : SelectedStdTests)
	{
		log_file.Write("name: " + selName);
	}

	status = ProUIDialogCreate(MAIN_TESTS_DLG, MAIN_TESTS_DLG);
	log_file.Write("ProUIDialogCreate: " + to_string(status));
	status = ProUIDialogCloseActionSet(MAIN_TESTS_DLG, (ProUIAction)QVTCloseAction, NULL);
	log_file.Write("ProUIDialogCloseActionSet: " + to_string(status));
	status = ProUIDialogActivate(MAIN_TESTS_DLG, &exit_status);
	log_file.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogAboveactivewindowSet(MAIN_TESTS_DLG, PRO_B_TRUE);
	log_file.Write("ProUIDialogAboveactivewindowSet: " + to_string(status));

	vector<string> stdTableData;
	CSVReader _CSVReader(CSV_filePath, ",");
	stdTableData = _CSVReader.getData(',');
	int tbl1_item_nos = (SelectedStdTests.size());
	log_file.Write("tbl1_item_nos: " + to_string(tbl1_item_nos));

	int tbl1_row_nos;
	if (tbl1_item_nos <= 6)
	{
		tbl1_row_nos = 1;
	}
	else {
		tbl1_row_nos = tbl1_item_nos / 6;
	}

	log_file.Write("tbl1_row_nos: " + to_string(tbl1_row_nos));

	vector<string> wrapd_names = GetAppStoreNames(SelectedStdTests, PRO_B_TRUE);
	vector<string> helpTxt_names = GetAppStoreNames(SelectedStdTests, PRO_B_FALSE);

	log_file.Write("[\twrapd_names\t]");
	for (int i = 0; i < wrapd_names.size(); i++)
	{
		log_file.Write(wrapd_names[i].c_str());
	}

	log_file.Write("[\thelpTxt_names\t]");
	for (int i = 0; i < helpTxt_names.size(); i++)
	{
		log_file.Write(helpTxt_names[i].c_str());
	}

	char** STD_tbl1_Rows = new char* [tbl1_row_nos];
	for (int i = 0; i < tbl1_row_nos; i++)
	{
		STD_tbl1_Rows[i] = new char[PRO_NAME_SIZE];
		ProTKSprintf(STD_tbl1_Rows[i], "r%d", i);
	}

	status = ProUITableRowsInsert(MAIN_TESTS_DLG, TESTS_GALLERY_TBL, NULL, tbl1_row_nos, STD_tbl1_Rows);
	log_file.Write("ProUITableRowsInsert: " + to_string(status));

	char PBrowName[PRO_NAME_SIZE];
	char PBcolName[PRO_NAME_SIZE];
	char PB_Name[PRO_NAME_SIZE];
	int row_index = 0, col_index = 0;
	ProCharLine test_name;
	ProLine w_test_name;

	for (int i = 0; i < tbl1_item_nos; i++)
	{
		ProTKSprintf(PBrowName, "r%d", row_index);
		ProTKSprintf(PBcolName, "c%d", col_index);
		ProTKSprintf(PB_Name, "PB_%s_%s", PBrowName, PBcolName);

		status = ProUITableCellComponentCopy(MAIN_TESTS_DLG, TESTS_GALLERY_TBL, PBrowName, PBcolName, MAIN_TESTS_DLG, GALLERY_TBL_MAIN_PB, PB_Name);
		log_file.Write("ProUITableCellComponentCopy: " + to_string(status) + "\tPB_Name: " + string(PB_Name));
		status = ProUIPushbuttonSizeSet(MAIN_TESTS_DLG, PB_Name, 150, 80);
		log_file.Write("ProUIPushbuttonSizeSet: " + to_string(status));

		status = ProUIPushbuttonBitmapSet(MAIN_TESTS_DLG, PB_Name, "icon.bmp");
		log_file.Write("ProUIPushbuttonBitmapSet: " + to_string(status));

		ProTKSprintf(test_name, "%d. %s", i+1, wrapd_names[i].c_str());
		ProStringToWstring(w_test_name, test_name);
		status = ProUIPushbuttonTextSet(MAIN_TESTS_DLG, PB_Name, w_test_name);
		log_file.Write("ProUIPushbuttonTextSet: " + to_string(status));

		ProTKSprintf(test_name, "%d. %s", i+1, helpTxt_names[i].c_str());
		ProStringToWstring(w_test_name, test_name);
		log_file.Write("test_name: " + string(test_name));
		status = ProUIPushbuttonHelptextSet(MAIN_TESTS_DLG, PB_Name, w_test_name);
		log_file.Write("ProUIPushbuttonHelptextSet: " + to_string(status));

		status = ProUIPushbuttonShow(MAIN_TESTS_DLG, PB_Name);
		log_file.Write("ProUIPushbuttonShow: " + to_string(status));
		status = ProUIPushbuttonActivateActionSet(MAIN_TESTS_DLG, PB_Name, (ProUIAction)tbl_pb_action, NULL);
		log_file.Write("ProUIPushbuttonActivateActionSet: " + to_string(status));

		col_index++;

		if (col_index % 6 == 0)
		{
			row_index++;
			col_index = 0;
		}
	}
	delete[] STD_tbl1_Rows;*/
	return status;
}

void tbl_pb_action(char* dialog, char* component, ProAppData app_data)
{
	log_file.Write("----------------------------- tbl_pb_action -----------------------------");

	char c_selTestName[PRO_NAME_SIZE];
	wchar_t* w_selTestName;
	string selTestName;
	int testIndex = 0;
	StdTests _stdTests;

	status = ProUIPushbuttonTextGet(dialog, component, &w_selTestName);
	log_file.Write("ProUIPushbuttonTextGet: " + to_string(status));

	ProWstringToString(c_selTestName, w_selTestName);
	selTestName = string(c_selTestName);
	log_file.Write("selTestName: " + string(selTestName));

	//getting the INDEX for updating the status table
	testIndex = stoi(selTestName.substr(0, 1));

	size_t SpacePos = selTestName.find_first_not_of(' ', 2);
	selTestName = selTestName.substr(SpacePos);
	log_file.Write("selTestName(without index): " + string(selTestName));
	log_file.Write("Pos: " + to_string(SpacePos));

	SpacePos = selTestName.find_first_of('\n');
	selTestName[SpacePos] = ' ';
	log_file.Write("selTestName(without newline): " + string(selTestName));

	std::map <std::string, int> TestsMap;

	TestsMap["Hole Alignment Test"] = 1;
	TestsMap["Standard Test 2"] = 2;
	TestsMap["Standard Test 3"] = 3;
	TestsMap["Standard Test 4"] = 4;
	TestsMap["Standard Test 5"] = 5;
	TestsMap["Standard Test 6"] = 6;
	TestsMap["Standard Test 7"] = 7;
	TestsMap["Standard Test 8"] = 8;
	TestsMap["Standard Test 9"] = 9;
	TestsMap["Standard Test 10"] = 10;
	TestsMap["Standard Test 11"] = 11;
	TestsMap["Standard Test 12"] = 12;
	TestsMap["Standard Test 13"] = 13;
	TestsMap["Standard Test 14"] = 14;
	TestsMap["Standard Test 15"] = 15;
	TestsMap["Standard Test 16"] = 16;
	TestsMap["Standard Test 17"] = 17;
	TestsMap["Standard Test 18"] = 18;
	TestsMap["Standard Test 19"] = 19;
	TestsMap["Standard Test 20"] = 20;
	TestsMap["Standard Test 21"] = 21;
	TestsMap["Standard Test 22"] = 22;
	TestsMap["Standard Test 23"] = 23;
	TestsMap["Standard Test 24"] = 24;
	TestsMap["Standard Test 25"] = 25;

	int map_value = 0;
	log_file.Write("TestsMap.count(selTestName): " + to_string(TestsMap.count(selTestName)));

	if (TestsMap.count(selTestName) != 0)
	{
		log_file.Write("selTestName(inside map): " + string(selTestName));
		map_value = TestsMap.find(selTestName)->second;
		log_file.Write("Key found");
	}
	else {
		log_file.Write("Key not found");
	}

	switch (map_value) {

	case 1: // option 1
		status = _stdTests.HoleAlignmentTest(TESTS_STS_DLG, TESTS_STS_TBL, testIndex);
		//status = HoleAlignmentCheck(testIndex);
		break;
	case 2:
		log_file.Write("Standard Test 2");
		break;
	case 3:
		log_file.Write("Standard Test 3");
		break;
	case 4:
		log_file.Write("Standard Test 4");
		break;
	case 5:
		log_file.Write("Standard Test 5");
		break;
	default:
		log_file.Write("Invalid command");
		break;
	}
}

ProError HoleAlignmentCheck(int test_index)
{
	log_file.Write("----- Inside HoleAlignmentCheck() function -----");

	char* ch;
	int allow, p_count;
	ProSelection* p_sel_arr1 = NULL, * p_sel_arr2 = NULL;
	double dist1, dist2, dist3, dist4, diam;
	Pro2dPnt uv1, uv2;
	Pro3dPnt xyz1, xyz2;

	allow = 4;
	double arr1[4] = {}, arr2[4] = {};
	int i = 0;
	ch = (char*)"sldedge,axis";
	//ProFileName msgFile;

	//first set of holes
	status = ProSelect(ch, allow, NULL, NULL, NULL, NULL, &p_sel_arr1, &p_count);
	if (p_count > 0)
	{
		for (i = 0; i < p_count; i++)
		{
			if (i == p_count - 1)
			{
				status = ProSelectionWithOptionsDistanceEval(p_sel_arr1[i], PRO_B_TRUE, p_sel_arr1[0], PRO_B_TRUE, uv1, uv2, xyz1, xyz2, &dist1);
			}
			else
			{
				status = ProSelectionWithOptionsDistanceEval(p_sel_arr1[i], PRO_B_TRUE, p_sel_arr1[i + 1], PRO_B_TRUE, uv1, uv2, xyz1, xyz2, &dist1);
			}
			arr1[i] = round(dist1);
		}

		//ProStringToWstring(msgfil, (char*)"user_msg.txt");
		//status = ProMessageDisplay(msgfil, (char*)"Select the next set of holes");
		log_file.Write("ProMessageDisplay: " + to_string(status));
		//MessageBox(NULL, "Click OK to select the next four holes", NULL, MB_OK);
	}

	if (p_count > 0 && p_sel_arr1 != NULL)
	{
		status = ProSelect(ch, allow, NULL, NULL, NULL, NULL, &p_sel_arr2, &p_count);
		if (p_count > 0)
		{
			ProMessageClear();

			for (i = 0; i < p_count; i++)
			{
				if (i == p_count - 1)
				{
					status = ProSelectionWithOptionsDistanceEval(p_sel_arr2[i], PRO_B_TRUE, p_sel_arr2[0], PRO_B_TRUE, uv1, uv2, xyz1, xyz2, &dist2);
				}
				else
				{
					status = ProSelectionWithOptionsDistanceEval(p_sel_arr2[i], PRO_B_TRUE, p_sel_arr2[i + 1], PRO_B_TRUE, uv1, uv2, xyz1, xyz2, &dist2);
				}
				arr2[i] = round(dist2);
			}

			int arr1_size = sizeof(arr1) / sizeof(arr1[0]);
			int arr2_size = sizeof(arr2) / sizeof(arr2[0]);

			bool test_sts = areEqual(arr1, arr2, arr1_size, arr2_size);
			if (test_sts)
			{
				log_file.Write("The Pitch is same");
			}
			else
			{
				log_file.Write("The Pitch is not same");
			}
			//UpdateStatusTable(test_index, test_sts);
		}
	}
	status = ProWindowRepaint(PRO_VALUE_UNUSED);
	return PRO_TK_NO_ERROR;
}
void UpdateStatusTable(char* dialog, int index, bool sts)
{
	log_file.Write("----- Inside UpdateStatusTable fucntion -----");
	log_file.Write("Test Index: " + to_string(index));

	char update_row[PRO_NAME_SIZE];
	ProLine w_sts;

	log_file.Write("sts: " + to_string(sts));
	ProTKSprintf(update_row, "r_%d", index - 1);
	if (sts == true)
	{
		ProStringToWstring(w_sts, "     Pass");
		status = ProUITableCellBackgroundColorSet(TESTS_STS_DLG, TESTS_STS_TBL, update_row, "INPUTSTS", PRO_UI_COLOR_RGB(210, 255, 210));
		log_file.Write("ProUITableCellBackgroundColorSet: " + to_string(status));
	}
	else
	{
		ProStringToWstring(w_sts, "     Fail");
		status = ProUITableCellBackgroundColorSet(TESTS_STS_DLG, TESTS_STS_TBL, update_row, "INPUTSTS", PRO_UI_COLOR_RGB(255, 210, 210));
		log_file.Write("ProUITableCellBackgroundColorSet: " + to_string(status));
	}
	status = ProUITableCellLabelSet(TESTS_STS_DLG, TESTS_STS_TBL, update_row, "INPUTSTS", w_sts);
	log_file.Write("ProUITableCellLabelSet: " + to_string(status));



}
bool areEqual(double arr1[], double arr2[], int n, int m)
{
	// If lengths of array are not equal means
	// array are not equal
	if (n != m)
		return false;

	// Sort both arrays
	sort(arr1, arr1 + n);
	sort(arr2, arr2 + m);

	// Linearly compare elements
	for (int i = 0; i < n; i++)
		if (arr1[i] != arr2[i])
			return false;

	// If all elements were same.
	return true;
}

void tbl_cb_action(char* dialog, char* component, char* rowName)
{
	ProError status;
	ProBoolean cell_cb_state;
	char* cell_pb_name;

	log_file.Write("----------------------------- Inside tbl_cb_action function -----------------------------");

	log_file.Write("rowName: " + string(rowName));
	status = ProUITableCellComponentNameGet(dialog, TESTS_STS_TBL, rowName, "INPUTPB", &cell_pb_name);
	log_file.Write("ProUITableCellComponentNameGet: " + to_string(status));

	if (status == PRO_TK_NO_ERROR)
	{
		log_file.Write("cell_pb_name: " + string(cell_pb_name));

		status = ProUICheckbuttonGetState(dialog, component, &cell_cb_state);
		if (cell_cb_state == PRO_B_TRUE)
		{
			status = ProUIPushbuttonEnable(dialog, cell_pb_name);
		}
		else
		{
			status = ProUIPushbuttonDisable(dialog, cell_pb_name);
		}
	}
}

void Table1_cb_action(char* dialog, char* component, ProAppData appdata)
{
	ProBoolean cb_state;
	ProError status;
	int noOfRows;
	char** tbl1_row_names;
	status = ProUITableRownamesGet(dialog, TESTS_STS_TBL, &noOfRows, &tbl1_row_names);
	log_file.Write("noOfRows: " + to_string(noOfRows));

	char dyn_cb_name[PRO_NAME_SIZE];
	status = ProUICheckbuttonGetState(dialog, component, &cb_state);
	for (int i = 0; i < noOfRows; i++)
	{
		ProTKSprintf(dyn_cb_name, "tbl1_cb%d", i + 1);
		if (cb_state == PRO_B_TRUE)
		{
			status = ProUICheckbuttonSet(dialog, dyn_cb_name);
		}
		else
		{
			status = ProUICheckbuttonUnset(dialog, dyn_cb_name);
		}
	}

}

void stdTbl_cb_action(char* dialog, char* component, ProAppData appdata)
{
	/*ProBoolean cb_state;
	ProError status;
	int noOfRows;
	char** tbl2_row_names;
	char cbName[PRO_NAME_SIZE], pbName[PRO_NAME_SIZE];

	status = ProUITableRownamesGet(dialog, RC_TABLE_2, &noOfRows, &tbl2_row_names);
	log_file.Write("noOfRows: " + to_string(noOfRows));

	for (int i = 0; i < noOfRows; i++)
	{
		ProTKSprintf(cbName, "tbl1_cb%d", i);
		ProTKSprintf(pbName, "tbl1_pb%d", i);
		status = ProUICheckbuttonGetState(dialog, cbName, &cb_state);
		if (cb_state == PRO_B_TRUE)
		{
			status = ProUIPushbuttonDisable(dialog, pbName);
		}
		else
		{
			status = ProUIPushbuttonEnable(dialog, pbName);
		}
	}*/

}

void Table2_cb_action(char* dialog, char* component, ProAppData appdata)
{
	/*ProBoolean cb_state;
	ProError status;
	int noOfRows;
	char** tbl2_row_names;
	char cbName[PRO_NAME_SIZE];

	status = ProUITableRownamesGet(dialog, RC_TABLE_2, &noOfRows, &tbl2_row_names);
	log_file.Write("noOfRows: " + to_string(noOfRows));

	status = ProUICheckbuttonGetState(dialog, component, &cb_state);
	for (int i = 0; i < noOfRows; i++)
	{
		ProTKSprintf(cbName, "tbl2_cb%d", i);
		if (cb_state == PRO_B_TRUE)
		{
			status = ProUICheckbuttonSet(dialog, cbName);
		}
		else
		{
			status = ProUICheckbuttonUnset(dialog, cbName);
		}
	}*/
}

ProError QVTCloseAction(char* dialog, char* component, ProAppData data)
{
	log_file.Write("Inside QVT close action function");

	ProError	status;
	int dlgStatus;
	status = ProUIDialogActivate(dialog, &dlgStatus);
	log_file.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	log_file.Write("ProUIDialogExit: " + to_string(status));
	status = ProUIDialogDestroy(dialog);
	log_file.Write("ProUIDialogDestroy: " + to_string(status));

	status = ProUIDialogDestroy(TESTS_STS_DLG);
	log_file.Write("ProUIDialogDestroy: " + to_string(status));


	return status;
}ProError DlgCloseAction(char* dialog, char* component, ProAppData data)
{
	log_file.Write("-----Inside DlgCloseAction function------");
	ProError	status;
	int dlgStatus;
	status = ProUIDialogActivate(dialog, &dlgStatus);
	log_file.Write("ProUIDialogActivate: " + to_string(status));
	status = ProUIDialogHide(dialog);
	log_file.Write("ProUIDialogHide: " + to_string(status));
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	log_file.Write("ProUIDialogExit: " + to_string(status));

	return status;
}

