/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 08-02-2023	| V1_0_0		| XML FILE OPERATIONS
==================================================================================================================*/
#include "XmlWriter.h"

using namespace std;
FILE* fp3 = NULL;
ofstream myfile;
ofstream writeHTMLfile;

void XMLWriter::writeHTML(string xmlFileName, string htmlFileName)
{
	mainLog.Write("================= XMLWriter::writeHTML ==================");
	writeHTMLfile.open(htmlFileName);
	if (writeHTMLfile.is_open())
	{
		writeHTMLfile << "<html>\n<head>\n<title>WP_Validation report</title>\n";
		writeHTMLfile << "<META http-equiv= \"refresh\" content=\"0;URL=\'";
		writeHTMLfile << xmlFileName << "\'\"/>\n";
		writeHTMLfile << "</head>\n<body>\n</body>\n</html>";
		writeHTMLfile << endl;
		writeHTMLfile.close();
	}
}

void XMLWriter::xmlWrite(string xmlFileName, Summary sumry, vector <RuleRequirements> req, rule_results res, char *cResPath)
{
	mainLog.Write("================= XMLWriter::xmlWrite ==================");
	myfile.open(xmlFileName);
	if (myfile.is_open())
	{
		myfile << "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n";
		myfile << "<?xml-stylesheet type=\"text/xsl\" href=\"";
		//myfile << cResPath;
		//myfile << "K:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\app_db\\report.xsl\"?>\n";
		myfile << cResPath;
		myfile << "report_res_db\\report.xsl\"?>\n";
		myfile << "<report>\n";
		writeSummary(sumry);
		writeRequirements(/*sum,*/req);
		writeResults(/*sum,*/res, req);
		userComments(/*usrcom*/);
		myfile << "<\/report>";
		myfile.close();
	}
}

void XMLWriter::writeSummary(Summary sumry)
{
	mainLog.Write("================= XMLWriter::writeSummary ==================");
	myfile << "<summary>\n";
	myfile << "<document name=\"" << sumry.candidate << "\" />\n";
	myfile << "<status value=\"" << sumry.finalResult << "\" />\n";
	myfile << "<candidates type=\"" << "\"/>\n";
	myfile << "<statistics total=\"" << sumry.total << "\" failed=\"" << sumry.failed << "\" passed=\"" << sumry.passed << "\" not_performed=\"" << sumry.total - sumry.passed - sumry.failed << "\"/>\n";
	myfile << "<documentpath name=\"" << sumry.asmLoc << "\" />\n";
	myfile << "<username name=\"" << sumry.userName << "\" />\n";
	myfile << "<timestamp date=\"" << sumry.dateCreated << "\" time=\"" << sumry.timeCreated << "\" />\n";
	myfile << "</summary>\n";
}

void XMLWriter::writeRequirements(vector <RuleRequirements> req)
{
	mainLog.Write("================= XMLWriter::writeRequirements ==================");
	myfile << "<selected_requirements>\n";

	for (int i = 0; i < req.size(); i++)
	{
		for(int j =0; j<req[i].description.length(); ++j)
		{
			char a = req[i].description[j];
			switch (a)
			{
				case '&':
					mainLog.Write("req[i].description: "+ req[i].description);
					req[i].description.erase(j,1);
					req[i].description.insert(j, "&amp;");
					mainLog.Write(">>> req[i].description: "+ req[i].description);
					break;
				case '"':
					req[i].description.erase(j,1);
					req[i].description.insert(j, "&quot;");
					break;
				case '\'':
					req[i].description.erase(j,1);
					req[i].description.insert(j, "&apos;");
					break;
				case '>':
					req[i].description.erase(j,1);
					req[i].description.insert(j, "&lt;");
					break;
				case '<':
					req[i].description.erase(j,1);
					req[i].description.insert(j, "&gt;");
					break;
				default:
					break;
			}
		}

		myfile << "<requirement local_name=\"" << req[i].name << "\" application_ref=\"" << "\" type=\""<<req[i].description<<"\">\n";
		myfile << "</requirement>\n";
	}
	myfile << "</selected_requirements>\n";
}

void XMLWriter::writeResults(rule_results res, vector <RuleRequirements> req)
{
	mainLog.Write("================= XMLWriter::writeResults ==================");
	myfile << "<results>\n";

	for (int i = 0; i < req.size(); i++)
	{
		myfile << "<result status=\"" << req[i].status << "\" type=\"Check\" >\n";
		myfile << "<requirement local_name=\"" << req[i].name << "\" application_ref=\"" << req[i].testIndx << "\" type=\""<<req[i].comments << "\" />\n";
		myfile << "<candidate name=\"PRT and ASM Document\" />\n";
		myfile << "</result>\n";

		/*if (strcmp(res[i].result_status, "Fail") == 0)
		{
			myfile << "<message text=\"" << res[i].res_message_text << "\"/>\n";
			myfile << "<detail desc=\"" << res[i].elaborate_text << "\"/>\n";
		}
		myfile << "<\/result>\n";*/
	}
	myfile << "<\/results>\n";
}

void XMLWriter::userComments(/*usercomments *usrcom*/)
{
	mainLog.Write("================= XMLWriter::userComments ==================");
	myfile << "<user_comments>\n";
	/*for (int i=0; i<1; i++)
	{*/
	myfile << "<comment_line value=\"" << "No Comments" << "\"/>\n";
	/*}*/
	myfile << "</user_comments>\n";
}