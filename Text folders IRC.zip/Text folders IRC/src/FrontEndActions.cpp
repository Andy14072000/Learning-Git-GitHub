/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 09-03-2023	| V1_0_0		| FRONT END SUPPORTING FUNCTIONs
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#include "AppFrontEnd.h"

int sqlRes;
vector<string> testResult;

void updateGUI(string subModlName, vector<RuleInfo> &rules_list)
{
	mainLog.Write("================================ updateGUI ================================");

	vector<SQLruleData> ruleData;
	char cSMname[PRO_NAME_SIZE];
	strcpy(cSMname, subModlName.c_str());

	//Changes made by himanshu
	//-----------------------------------------------------
	mainLog.Write("SubModule: " + string(cSMname));
	char con_SubMod_name[PRO_PATH_SIZE]{};
	revision_extraction_from_txr(cSMname, con_SubMod_name);
	mainLog.Write("con_SubMod_name: " + string(con_SubMod_name));
	//-----------------------------------------------------

	sqlRes = retrieveSQLData(con_SubMod_name, ruleData);
	mainLog.Write("retrieveSQLData (sqlRes): " + to_string(sqlRes));

	mainLog.Write("ruleData.size(): " + to_string(ruleData.size()));
	for(int i = 0; i < rules_list.size(); ++i)
	{
		if(rules_list[i].module_name.compare(subModlName) == 0)
		{
			int dataIndex = 0;
			while(dataIndex < ruleData.size())
			{
				if(rules_list[i].lib_sno == ruleData[dataIndex].sno)
				{
					rules_list[i].remark =  ruleData[dataIndex].remark;
					rules_list[i].status =  ruleData[dataIndex].status;

					ruleStatusUIupdate(rules_list[i]);
					dataIndex++;
				}
				i++;
			}
			break;
		}
	}
	for (size_t i = 0; i < ruleData.size(); ++i) {
		delete[] ruleData[i].remark;
	}
	ruleData.clear();

}

int extractRuleNames(string subModlName, vector<string> &tableData)
{
	mainLog.Write("================================ extractRuleNames ================================");

	string mod_adrs;

	mod_adrs = subModlName.substr(4,3);
	//mainLog.Write("mod_adrs: " + mod_adrs);

	//GET DB PATH
	char dbFilePath[PRO_PATH_SIZE];

	//ProTKSprintf(dbFilePath, "%s%s", cTextPath, "\\text\\usascii\\resource\\db\\master_rules.csv");
	//ProTKSprintf(dbFilePath, "%s", "K:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\app_db\\master_rules.csv");
	ProTKSprintf(dbFilePath, "%s%s", PROE_TML_STD_PATH, "\\irc_application\\app_db\\master_rules.csv");
	//mainLog.Write("dbFilePath: " + string(dbFilePath));

	vector<vector<string>> csv_data;
	FileParser _csvReader(dbFilePath, ',');
	_csvReader.getData2D(csv_data);

	/*FILE *data_file = NULL;
	data_file = fopen("c:\\tmp\\data_file.log", "w");
	fflush(data_file);
	for (auto row : csv_data)
	{
		for (auto cell : row) {
			fprintf(data_file, "%s ", cell);
			fflush(data_file);
		}
		fprintf(data_file, "\n");
		fflush(data_file);	
	}
	fclose(data_file);*/

	for(int i=0; i<csv_data.size(); ++i)
	{
		//mainLog.Write("csv_data: "+csv_data[i][0]);
		// CHECK FIRST COLUMN
		if(mod_adrs.compare(csv_data[i][0]) == 0)
		{
			// CHECK SECOND COLUMN with mod_adrs
			while(csv_data[i][1].substr(1,3).compare(mod_adrs)==0)
			{
				string checkModAdres = csv_data[i][1];
				checkModAdres = checkModAdres.substr(1);
				string nameModAdres = subModlName.substr(4,5);

				//mainLog.Write("checkModAdres: "+checkModAdres+"\tnameModAdres: "+nameModAdres);

				//CHECK FOR CURRENT MODEL'S MODULE ADDRESS IN THE DATA
				if(checkModAdres.compare(nameModAdres)==0)
				{
					// EXTRACT THE ROW
					for(int j=2; j<csv_data[i].size(); ++j)
					{
						if(csv_data[i][j] != "")
						{
							//REMOVING leading spaces in the element
							size_t Pos;
							Pos = csv_data[i][j].find_first_not_of(' ');
							if (Pos != 0)
							{
								csv_data[i][j].erase(0, Pos);
							}
							//REMOVING trailing spaces in the element
							Pos = csv_data[i][j].find_last_not_of(' ');
							csv_data[i][j].erase(Pos + 1);
							//mainLog.Write("csv_data["+to_string(i)+"]["+to_string(j)+"]: "+csv_data[i][j]);
							tableData.push_back(csv_data[i][j]);
						}
					}
					break;
				}
				i++;
			}
			
		}
	}

	for (auto ss : tableData) {
		mainLog.Write("tableData : " + ss);
	}

	csv_data.clear();
	return 0;
}

void extractRulesData(char* descFilePath, vector<string> ruleNames, vector<string> &rulesData, bool truncate)
{
	mainLog.Write("================================ extractRulesData ================================");
	struct RuleData{
		string name;
		string data;
	};

	vector<vector<string>> data2D;
	FileParser _csvReader(descFilePath, ',');
	_csvReader.getData2D(data2D);
	vector<RuleData> dataList;

	for(int i=0; i<data2D.size(); ++i)
	{
		RuleData _ruleData;
		_ruleData.name = data2D[i][0];
		_ruleData.data = data2D[i][1];

		dataList.push_back(_ruleData);
	}

	for (int i=0; i<ruleNames.size(); ++i)
	{
		//mainLog.Write("ruleName: "+ruleNames[i]);
		string reqData = "N/A";
		for (auto rule_data : dataList)
		{
			if(rule_data.name == ruleNames[i])
			{
				if(truncate){
					if (rule_data.data.size()>200)
						rule_data.data.resize(200);	//TRUNCATING THE EXCESS DATA AT THE END
				}
				reqData = rule_data.data;
				break;
			}
		}
		//mainLog.Write("reqData: "+reqData);
		rulesData.push_back(reqData);
	}
}

void ruleStatusUIupdate(RuleInfo &rule_info)
{
	mainLog.Write("================================ ruleStatusUIupdate ================================");

	char tblRowName[PRO_NAME_SIZE];
	ProLine w_sts;

	strcpy(tblRowName, "r");
	strcat(tblRowName, to_string(rule_info.sno).c_str());
	mainLog.Write("tblRowName: " + string(tblRowName));

	mainLog.Write("Status of the rule: " + rule_info.status);
	char stsTblDeviateCbName[PRO_NAME_SIZE], libTblDeviateCbName[PRO_NAME_SIZE], stsTblCopyPbName[PRO_NAME_SIZE];
	ProTKSprintf(stsTblDeviateCbName, "deviationcb_%s", tblRowName);
	//mainLog.Write("stsTblDeviateCbName: " + string(stsTblDeviateCbName));
	ProTKSprintf(libTblDeviateCbName, "deviatecb_%s", tblRowName);
	//mainLog.Write("libTblDeviateCbName: " + string(libTblDeviateCbName));
	ProTKSprintf(stsTblCopyPbName, "copypb_%s", tblRowName);

	submitToPlmEnable = true;
	ProUIColor uiColor{};
	bool copyButtonEnable = true;
	if ((rule_info.status.compare("PASSED") == 0) || (rule_info.status.compare("PASS") == 0))	//passed
	{
		ProStringToWstring(w_sts, stsCellLabelPass);
		uiColor = PRO_UI_COLOR_RGB(210, 255, 210);
		status = ProUICheckbuttonUnset(DLG_IRC_MAIN, stsTblDeviateCbName);
		status = ProUICheckbuttonUnset(DLG_IRC_MAIN, libTblDeviateCbName);
		status = ProUICheckbuttonDisable(DLG_IRC_MAIN, stsTblDeviateCbName);
		status = ProUICheckbuttonDisable(DLG_IRC_MAIN, libTblDeviateCbName);
	}
	else if( (rule_info.status.compare("FAILED") == 0) || (rule_info.status.compare("FAIL") == 0))	//failed
	{
		submitToPlmEnable = false;
		uiColor = PRO_UI_COLOR_RGB(255, 210, 210);
		ProStringToWstring(w_sts, stsCellLabelFail);
		status = ProUICheckbuttonUnset(DLG_IRC_MAIN, stsTblDeviateCbName);
		status = ProUICheckbuttonUnset(DLG_IRC_MAIN, libTblDeviateCbName);
		status = ProUICheckbuttonEnable(DLG_IRC_MAIN, stsTblDeviateCbName);
		status = ProUICheckbuttonEnable(DLG_IRC_MAIN, libTblDeviateCbName);

	}
	else if ((rule_info.status.compare("DEVIATION") == 0) || (rule_info.status.compare("DEVIATED") == 0))
	{
		uiColor = PRO_UI_COLOR_RGB(255, 229, 204);
		ProStringToWstring(w_sts, stsCellLabelDeviation);
		status = ProUICheckbuttonSet(DLG_IRC_MAIN, stsTblDeviateCbName);
		status = ProUICheckbuttonSet(DLG_IRC_MAIN, libTblDeviateCbName);
		status = ProUICheckbuttonEnable(DLG_IRC_MAIN, stsTblDeviateCbName);
		status = ProUICheckbuttonEnable(DLG_IRC_MAIN, libTblDeviateCbName);
	}
	//else if (rule_info.status.compare("MANUAL-CHECK") == 0)
	//{
	//	uiColor = PRO_UI_COLOR_RGB(210, 255, 210);
	//	ProStringToWstring(w_sts, stsCellLabelManualCheck);
	//	status = ProUICheckbuttonUnset(DLG_IRC_MAIN, stsTblDeviateCbName);
	//	status = ProUICheckbuttonUnset(DLG_IRC_MAIN, libTblDeviateCbName);
	//	status = ProUICheckbuttonDisable(DLG_IRC_MAIN, stsTblDeviateCbName);
	//	status = ProUICheckbuttonDisable(DLG_IRC_MAIN, libTblDeviateCbName);
	//}
	else
	{
		uiColor = PRO_UI_COLOR_SUNKEN_BACKGROUND;
		ProStringToWstring(w_sts, stsCellLabel);
		status = ProUICheckbuttonUnset(DLG_IRC_MAIN, stsTblDeviateCbName);
		status = ProUICheckbuttonUnset(DLG_IRC_MAIN, libTblDeviateCbName);
		status = ProUICheckbuttonDisable(DLG_IRC_MAIN, stsTblDeviateCbName);
		status = ProUICheckbuttonDisable(DLG_IRC_MAIN, libTblDeviateCbName);
		copyButtonEnable = false;
	}

	if(copyButtonEnable)
		status = ProUIPushbuttonEnable(DLG_IRC_MAIN, stsTblCopyPbName);

	status = ProUITableCellBackgroundColorSet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, tblRowName, "status",  uiColor);
	status = ProUITableCellBackgroundColorSet(DLG_IRC_MAIN, TBL_RULE_STATUS, tblRowName, "status", uiColor);

	status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_LIBRARY, tblRowName, "status", w_sts);
	status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_STATUS, tblRowName, "status", w_sts);

	char cRemark[PRO_PATH_SIZE]{};
	wchar_t wRemark[PRO_PATH_SIZE];

	string sRemark = rule_info.remark;	// trimming to path size to show in UI
	replace(sRemark.begin(), sRemark.end(), '\n', ' ');
	sRemark = sRemark.substr(0,200);	// 200 characters limited remarks in the UI
	strcpy(cRemark, sRemark.c_str());
	//mainLog.Write("UI Remark: " + sRemark);
	ProStringToWstring(wRemark, cRemark);
	status = ProUITableCellLabelSet(DLG_IRC_MAIN, TBL_RULE_STATUS, tblRowName, "remarks", wRemark);

	/*if(submitToPlmEnable)
	{
		status = ProUIPushbuttonEnable(DLG_IRC_MAIN, PB_PLM_SUBMIT);
	}else
	{
		status = ProUIPushbuttonDisable(DLG_IRC_MAIN, PB_PLM_SUBMIT);
	}*/
}

string generateReport(string subModuleName, vector<RuleInfo> &rules_list)
{
	mainLog.Write("================================ generateReport ================================");

	vector<RuleRequirements> testReq;
	Summary resultSummary;
	rule_results ruleResult;
	string finalResult = "PASSED";

	ProPath w_curWorkDir;
	char c_curWorkDir[PRO_PATH_SIZE];
	status = ProDirectoryCurrentGet(w_curWorkDir);

	ProWstringToString(c_curWorkDir, w_curWorkDir);
	mainLog.Write("Current Working Directory: " + string(c_curWorkDir));

	ProMdl submodule_mdl;
	wchar_t w_subModlName[PRO_NAME_SIZE];
	char c_subModlName[PRO_NAME_SIZE];
	strcpy(c_subModlName, subModuleName.c_str());
	ProStringToWstring(w_subModlName, c_subModlName);
	status = ProMdlnameRetrieve(w_subModlName, PRO_MDLFILE_ASSEMBLY, &submodule_mdl);
	
	mainLog.Write("ProMdlnameRetrieve: " + to_string(status));

	mainLog.Write("subModuleName: " + subModuleName);

	char		XML_Name[PRO_PATH_SIZE], HTML_Name[PRO_PATH_SIZE], current_dir[PRO_PATH_SIZE], model_path[PRO_PATH_SIZE];
	char		mpath[PRO_LINE_SIZE], mdevice[PRO_LINE_SIZE], mtype[PRO_LINE_SIZE];
	int			mdlVersion;
	ProMdldata	m_data;

	mainLog.Write("========== Report Creation Started =============");

	//status = ProMdlDataGet(submodule_mdl, &m_data);
	//ProWstringToString(mpath, m_data.path);
	//ProWstringToString(mdevice, m_data.device);
	//ProWstringToString(mtype, m_data.type);
	//mdlVersion = m_data.version;

	//Changes made by Himanshu for Creo 9 compatibility
	ProPath wOrigin1;
	char	cOrigin1[PRO_LINE_SIZE];
	status = ProMdlOriginGet(submodule_mdl, wOrigin1);
	mainLog.Write("ProMdlOriginGet: " + to_string(status) + "\t" + string(ProWstringToString(cOrigin1, wOrigin1)));
	//---------------------------------------------------------------------------------------------------

	//mainLog.Write("mPath: " + string(mpath) + ", mdevice: " + string(mdevice) + ", mtype: " + string(mtype) + ", mdlVersion: "+to_string(mdlVersion));

	for (int i = 0; i< rules_list.size(); ++i)
	{
		/*if(!rules_list[i].IsDigitizable)
			continue;*/

		if(rules_list[i].module_name.compare(subModuleName) == 0)
		{
			RuleRequirements reqTemp;
			reqTemp.testIndx = rules_list[i].lib_sno;
			reqTemp.name = rules_list[i].id;
			reqTemp.comments = rules_list[i].remark;
			reqTemp.description = rules_list[i].desc;

			resultSummary.total++;

			if ((rules_list[i].status.compare("PASSED") == 0) || (rules_list[i].status.compare("PASS") == 0))
			{
				resultSummary.passed++;
				reqTemp.performed = 1;
				reqTemp.status = "Pass";
			}
			else if ((rules_list[i].status.compare("FAILED") == 0) || (rules_list[i].status.compare("FAIL") == 0))
			{
				finalResult = "FAILED";	//change the final result, if any one of the rule fails
				resultSummary.failed++;
				reqTemp.performed = 1;
				reqTemp.status = "Fail";
			}
			else if((rules_list[i].status.compare("DEVIATION") == 0) || (rules_list[i].status.compare("DEVIATED") == 0) )
			{
				resultSummary.passed++;
				reqTemp.performed = 1;
				reqTemp.status = "Pass";
			}
			//else if(rules_list[i].status.compare("MANUAL-CHECK") == 0)
			//{
			//	resultSummary.passed++;
			//	reqTemp.performed = 1;
			//	reqTemp.status = "Pass";
			//}
			else
			{
				finalResult = "FAILED";	//change the final result, if any one of the rules not performed
				reqTemp.performed = 0;
				reqTemp.status = "Not-Performed";
			}
			testReq.push_back(reqTemp);
		    testResult.push_back(reqTemp.status);
		}
	}

	for (auto item : testReq)
	{
		mainLog.Write("name: " + item.name);
		mainLog.Write("status: " + item.status);
	}

	if(resultSummary.passed == 0 && resultSummary.failed == 0)
	{
		finalResult = "N/A";	//change the final result, if any one of the test fails
	}

	XMLWriter _XMLWriter;
	//string xml_name = string(cTextPath) +"\\text\\xml_resources\\" + subModuleName + "_report.xml";
	//string xml_name = "C:\\tmp\\" + subModuleName + "_report.xml";
	//cCurDirPath
	string xml_name = "C:\\tmp\\" + subModuleName + "_report.xml";
	//string html_name = string(cTextPath) +"\\text\\xml_resources\\" + subModuleName + "_report.html";
	//string html_name = "C:\\tmp\\" + subModuleName + "_report.html";
	string html_name = "C:\\tmp\\" + subModuleName + "_report.html";

	resultSummary.candidate = subModuleName;
	resultSummary.finalResult = finalResult;
	//resultSummary.asmLoc = string(mdevice) + string(":") + string(mpath) + resultSummary.candidate + string(".asm.") + to_string(mdlVersion);
	resultSummary.asmLoc = cOrigin1; //Changes made by Himanshu
	resultSummary.userName = getenv("username");

	//get the creation time
	time_t     now = time(0);
	tm		   tstruct;
	char       buf1[80];

	tstruct = *localtime(&now);

	strftime(buf1, sizeof(buf1), "%Y-%m-%d", &tstruct);
	string tmp1(buf1);

	resultSummary.dateCreated = tmp1.c_str();

	strftime(buf1, sizeof(buf1), "%H:%M:%S", &tstruct);
	string tmp2(buf1);

	resultSummary.timeCreated = tmp2.c_str();

	_XMLWriter.xmlWrite(xml_name, resultSummary, testReq, ruleResult, cCurDirPath);
	_XMLWriter.writeHTML(xml_name, html_name);

	testReq.clear();


	return html_name;
}

void fetchRuleInfo(SubModuleInfo submodlInfo, vector<RuleInfo> &rulesList)
{
	mainLog.Write("================================ fetchRuleInfo ================================");

	mainLog.Write("fetchRuleInfo: "+submodlInfo.name);

	vector<string> rulesDescList, interfModulesList, helpDocList;
	char rulesDescriptionFP[PRO_PATH_SIZE], interfacingModulesFP[PRO_PATH_SIZE], helpDocFP[PRO_PATH_SIZE];	//File paths

	// RULES DATA PATH
	/*ProTKSprintf(rulesDescriptionFP, "%s%s", cTextPath, "\\text\\usascii\\resource\\db\\rules_description.csv");
	ProTKSprintf(interfacingModulesFP, "%s%s", cTextPath, "\\text\\usascii\\resource\\db\\interfering_module.csv");
	ProTKSprintf(helpDocFP, "%s%s", cTextPath, "\\text\\usascii\\resource\\db\\rules_helpdocument.csv");*/
	//ProTKSprintf(rulesDescriptionFP, "%s", "K:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\app_db\\rules_description.csv");
	//ProTKSprintf(interfacingModulesFP, "%s", "K:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\app_db\\interfering_module.csv");
	//ProTKSprintf(helpDocFP, "%s", "K:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\app_db\\rules_helpdocument.csv");
	/*ProTKSprintf(rulesDescriptionFP, "%s", "C:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\app_db\\rules_description.csv");
	ProTKSprintf(interfacingModulesFP, "%s", "C:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\app_db\\interfering_module.csv");
	ProTKSprintf(helpDocFP, "%s", "C:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\app_db\\rules_helpdocument.csv");*/
	ProTKSprintf(rulesDescriptionFP, "%s%s", PROE_TML_STD_PATH, "\\irc_application\\app_db\\rules_description.csv");
	ProTKSprintf(interfacingModulesFP, "%s%s", PROE_TML_STD_PATH, "\\irc_application\\app_db\\interfering_module.csv");
	ProTKSprintf(helpDocFP, "%s%s", PROE_TML_STD_PATH, "\\irc_application\\app_db\\rules_helpdocument.csv");

	extractRulesData(interfacingModulesFP, submodlInfo.rule_names_list, interfModulesList, true);
	extractRulesData(rulesDescriptionFP, submodlInfo.rule_names_list, rulesDescList, true);
	extractRulesData(helpDocFP, submodlInfo.rule_names_list, helpDocList, false);

	for(int j = 0; j<submodlInfo.rule_names_list.size(); ++j)
	{
		RuleInfo _ruleinfo;
		_ruleinfo.module_name = submodlInfo.name;
		_ruleinfo.id = submodlInfo.rule_names_list[j];
		_ruleinfo.interf_modules = interfModulesList[j];
		_ruleinfo.status = stsCellLabel;
		_ruleinfo.help_doc =  helpDocList[j];
		_ruleinfo.remark = "";
		_ruleinfo.desc = rulesDescList[j];

		// CHECK IF DEVELOPED OR NOT
		_ruleinfo.IsDeveloped = false;
		for (const auto& row : rulesMapData){
			//mainLog.Write("row.front() :"+row[1]);
			//mainLog.Write("submodlInfo.rule_names_list[j] :"+submodlInfo.rule_names_list[j] );
			if(row[1] ==  submodlInfo.rule_names_list[j])
				_ruleinfo.IsDeveloped = true;
		}

		if(rulesDescList[j].compare("N/A") == 0 )// if description is not availbable, then the rule cannot be digitized
			_ruleinfo.IsDigitizable = false;
		else
			_ruleinfo.IsDigitizable = true;

		rulesList.push_back(_ruleinfo);
	}
	//std::stable_partition(rulesList.begin(), rulesList.end(), [](const RuleInfo& info){ return info.IsDigitizable;}); // bring info.IsDigitizabl==true elements to the top and send false to the bottom
	//for (int k = 0; k < rulesList.size(); k++) {
	//	mainLog.Write("rulesList22: " +string(rulesList[k].module_name));
	//}

	interfModulesList.clear();
	rulesDescList.clear();
	helpDocList.clear();
}

bool sortDigitisable(const RuleInfo& info)
{
	mainLog.Write("================================ sortDigitisable ================================");
	return info.IsDigitizable;
}

void writeRemarkTxtFile(string remarkFp, RuleInfo subModuleInfo)
{
	mainLog.Write("================================ writeRemarkTxtFile ================================");

	LogFile remarkLog;

	remarkLog.Start(remarkFp);
	remarkLog.Write("\nSub Module: " + subModuleInfo.module_name);
	remarkLog.Write("Rule ID: " + subModuleInfo.id);
	remarkLog.Write("Status: " + subModuleInfo.status);

	remarkLog.Write("\nREMARKS:\n");
	istringstream iss_remark(subModuleInfo.remark);
	string token;
	while(getline(iss_remark, token, ';'))
		remarkLog.Write(token);
}

#pragma pop
//bool sortDigitisable(const RuleInfo& info1, const RuleInfo& info2)
//{
//	mainLog.Write("================================--------------");
//	mainLog.Write("1: "+info1.id+ "\tIsDigitizable: "+to_string(info1.IsDigitizable));
//	mainLog.Write("2: "+info2.id+ "\tIsDigitizable: "+to_string(info2.IsDigitizable));
//	bool rtn;
//	if(info1.IsDigitizable != info2.IsDigitizable)
//	{
//		rtn = info1.IsDigitizable > info2.IsDigitizable;
//		mainLog.Write("return: "+to_string(rtn));
//		return	rtn;
//	}
//	mainLog.Write("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
//	return true;
//}