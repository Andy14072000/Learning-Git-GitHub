/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-03-2023	| V1_0_0		| INTERFACE RULES MAIN
==================================================================================================================*/
#pragma warning(push)	//TO DISABLE THE WARNING 26812
#pragma warning(disable : 26812)
#include "InterfaceRule.h"

InterfaceRule::InterfaceRule()
{
	// CURRENT MODEL LOCATION
	status = ProMdlDirectoryPathGet(curMdl, wCurMdlPath);
	ProWstringToString(cCurMdlPath, wCurMdlPath);

	// CURRENT MODEL ASMCOMPPATH
	status = ProAsmcomppathInit((ProSolid)curMdl, NULL, 0, &curAsmCompPath);

	// DB FILES FOLDER LOCATION
	/*strcpy(cRulesDbPath, "K:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\rules_db\\");
	strcpy(cRulesDbPath, "C:\\PTC\\Creo7.0.2.0\\telco_standards\\irc_application\\rules_db\\");*/
	ProTKSprintf(cRulesDbPath, "%s%s", PROE_TML_STD_PATH,"\\irc_application\\rules_db\\");

}

InterfaceRule::~InterfaceRule()
{
}

ProError InterfaceRule::measureAngleBetweenSurfaceAndAxis(ProSelection& sel_surf, ProSelection& sel_axis, double& angle)
{
	ruleLog.Write("=================> InterfaceRule::measureAngleBetweenSurfaceAndAxis <=================");
	ProModelitem surfItem, axisItem;
	ProUvParam surfUVparam;
	ProSurface surf;
	ProAxis axis;
	ProGeomitemdata* geomData;
	ProVector surfNormalVector, axisNormalVector;
	// SURFACE
	status = ProSelectionModelitemGet(sel_surf, &surfItem);
	ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));
	status = ProSelectionUvParamGet(sel_surf, surfUVparam);
	ruleLog.Write("ProSelectionUvParamGet: " + to_string(status));
	status = ProGeomitemToSurface(&surfItem, &surf);
	ruleLog.Write("ProGeomitemToSurface: " + to_string(status));
	ProVector selPntonSurf, deriv1[2], deriv2[3];
	status = ProSurfaceXyzdataEval(surf, surfUVparam, selPntonSurf, deriv1, deriv2, surfNormalVector);
	// AXIS
	status = ProSelectionModelitemGet(sel_axis, &axisItem);
	ruleLog.Write("ProSelectionModelitemGet: " + to_string(status));
	status = ProGeomitemToAxis(&axisItem, &axis);
	ruleLog.Write("ProGeomitemToAxis: " + to_string(status));
	status = ProAxisDataGet(axis, &geomData);
	ruleLog.Write("ProAxisDataGet: " + to_string(status));
	Pro3dPnt endP1, endP2;
	status = ProLinedataGet(geomData->data.p_curve_data, endP1, endP2);
	ruleLog.Write("ProLinedataGet: " + to_string(status));
	ProVector axis_endpoints = { endP2[0] - endP1[0], endP2[1] - endP1[1], endP2[2] - endP1[2] };
	ProUtilVectorNormalize(axis_endpoints, axisNormalVector);
	ruleLog.Write("axisNormalVector[0]: " + to_string(axisNormalVector[0]));
	ruleLog.Write("axisNormalVector[1]: " + to_string(axisNormalVector[1]));
	ruleLog.Write("axisNormalVector[2]: " + to_string(axisNormalVector[2]));
	double dotResult = -1.000;
	dotResult = ProUtilVectorDot(surfNormalVector, axisNormalVector);
	ruleLog.Write("ProUtilVectorDot: " + to_string(status));
	ruleLog.Write("dotResult: " + to_string(dotResult));
	double rad_angle = -1.000;
	double deg_angle = -1.000;
	rad_angle = acos(dotResult);
	ruleLog.Write("rad_angle: " + to_string(rad_angle));
	deg_angle = 90.0 - (rad_angle * (180 / M_PI));
	angle = deg_angle;
	ruleLog.Write("angle1: " + to_string(angle));
	if (angle < 0) {
		angle = std::abs(angle);
		ruleLog.Write("abs angle: " + to_string(angle));
	}
	else {
		ruleLog.Write("angle: " + to_string(angle));
	}

	return status;
}

int InterfaceRule::createTangentDatumAxisWithReference(ProSelection& sel_axis, char* refAxisName, char* outputAxisName) {
	ruleLog.Write("=================> InterfaceRule::createTangentDatumAxisWithReference <=================");
	ProModelitem refAxisitem;
	ProSelection reqMdlSel, refAxisSel;
	wchar_t wRefAxisName[PRO_NAME_SIZE], wOutputAxisName[PRO_NAME_SIZE];
	ProElement elem_tree, elem_ftype, elem_consts, elem_prl, elem_const_type1, elem_prl_ref, elem_tan, elem_const_type2, elem_tan_ref, elem_feature_name;
	ProReference REPDEP_ref1, REPDEP_ref2;
	ProFeatureCreateOptions* opts = 0;
	ProFeature axs_feat;
	ProErrorlist errors;


	status = ProSelectionModelitemGet(sel_axis, &refAxisitem);
	ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));
	status = ProSelectionAlloc(NULL, &refAxisitem, &refAxisSel);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));

	/* =============================================================== *\
	Create Element Tree
	\* =============================================================== */
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ruleLog.Write("Tree root status = " + to_string(status));
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_AXIS);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status= " + to_string(status));

	// FEATURE NAME
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wOutputAxisName, outputAxisName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);

	// CONSTRAINTS ALLOCATION
	status = ProElementAlloc(PRO_E_DTMAXIS_CONSTRAINTS, &elem_consts);
	ProElemtreeElementAdd(elem_tree, NULL, elem_consts);
	ruleLog.Write("constraints status = " + to_string(status));

	// Constraint 1
	status = ProElementAlloc(PRO_E_DTMAXIS_CONSTRAINT, &elem_tan);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_tan);
	ruleLog.Write("1st constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMAXIS_CONSTR_TYPE, &elem_const_type1);
	ProElementIntegerSet(elem_const_type1, PRO_DTMAXIS_CONSTR_TYPE_THRU);
	status = ProElemtreeElementAdd(elem_tan, NULL, elem_const_type1);
	ruleLog.Write("1st constraint type status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMAXIS_CONSTR_REF, &elem_tan_ref);
	status = ProSelectionToReference(sel_axis, &REPDEP_ref1);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	status = ProElementReferenceSet(elem_tan_ref, REPDEP_ref1);
	ruleLog.Write("ProElementReferenceSet = " + to_string(status));
	status = ProElemtreeElementAdd(elem_tan, NULL, elem_tan_ref);
	ruleLog.Write("1st constraint reference status = " + to_string(status));

	/* =============================================================== *\
	Create Model Selection Object
	\* =============================================================== */
	status = ProSelectionAlloc(NULL, &curMdlitem, &refAxisSel);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Axis
	status = ProFeatureWithoptionsCreate(refAxisSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &axs_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	ruleLog.Write("ProArrayFree status = " + to_string(status));
	status = ProElementFree(&elem_tree);
	ruleLog.Write("ProElementFree status = " + to_string(status));
	status = ProSelectionFree(&refAxisSel);
	ruleLog.Write("ProSelectionFree status = " + to_string(status));

	return 0;
}

int InterfaceRule::measureDistanceBetweenPlanes(const char *parentMdlName,const char *plane1_name, const char *plane2_name, double &distance)
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenPlanes <=================");

	ProSelection planeSel[2];
	ProMdl reqMdl;
	char cReqMdlPath[PRO_PATH_SIZE];
	ProPath wReqMdlPath;
	ProModelitem plane1Mdlitem, plane2Mdlitem;
	wchar_t wPlane1Name[PRO_NAME_SIZE], wPlane2Name[PRO_NAME_SIZE];

	strcpy(cReqMdlPath, cCurMdlPath);
	strcat(cReqMdlPath, parentMdlName);
	strcat(cReqMdlPath, ".asm");
	ruleLog.Write("cReqMdlPath: "+string(cReqMdlPath));

	ProStringToWstring(wReqMdlPath, cReqMdlPath);

	status = ProMdlnameRetrieve(wReqMdlPath, PRO_MDLFILE_ASSEMBLY, &reqMdl);
	ruleLog.Write("ProMdlnameRetrieve: "+to_string(status));

	ruleLog.Write("plane1_name: "+ string(plane1_name) + ";\tplane2_name: "+ string(plane2_name));
	ProStringToWstring(wPlane1Name, const_cast<char*> (plane1_name));
	ProStringToWstring(wPlane2Name, const_cast<char*> (plane2_name));

	status = ProModelitemByNameInit(reqMdl, PRO_SURFACE, wPlane1Name, &plane1Mdlitem);
	ruleLog.Write("ProModelitemByNameInit: "+to_string(status));
	if (status != PRO_TK_NO_ERROR)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Missing!", "Plane missing: "+string(plane1_name)+". Refer help document for details.");
		return -1;
	}
	status = ProModelitemByNameInit(reqMdl, PRO_SURFACE, wPlane2Name, &plane2Mdlitem);
	ruleLog.Write("ProModelitemByNameInit: "+to_string(status));
	if (status != PRO_TK_NO_ERROR)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Missing!", "Plane missing: "+string(plane2_name)+". Refer help document for details.");
		return -1;
	}
	status = ProSelectionAlloc(NULL, &plane1Mdlitem, &planeSel[0]);
	status = ProSelectionAlloc(NULL, &plane2Mdlitem, &planeSel[1]);

	Pro2dPnt param_1, param_2;
	Pro3dPnt pnt_1, pnt_2;	
	double platformWidth;

	status = ProSelectionWithOptionsDistanceEval(planeSel[0], PRO_B_TRUE, planeSel[1], PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: "+to_string(status)+"\tdistance: "+to_string(distance));

	return 0;
}

int InterfaceRule::measureDistanceBetweenPlaneAndSurface(const char *parentMdlName,const char *plane_name, ProSelection &sel_surf, double &distance)
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenPlaneAndSurface <=================");
				   
	ProSelection planeSel;
	ProMdl reqMdl;
	char cReqMdlPath[PRO_PATH_SIZE];
	ProPath wReqMdlPath;
	ProModelitem planeMdlitem;
	wchar_t wPlaneName[PRO_NAME_SIZE];

	strcpy(cReqMdlPath, cCurMdlPath);
	strcat(cReqMdlPath, parentMdlName);
	strcat(cReqMdlPath, ".asm");
	ruleLog.Write("cReqMdlPath: "+string(cReqMdlPath));

	ProStringToWstring(wReqMdlPath, cReqMdlPath);

	status = ProMdlnameRetrieve(wReqMdlPath, PRO_MDLFILE_ASSEMBLY, &reqMdl);
	ruleLog.Write("ProMdlnameRetrieve: "+to_string(status));

	ruleLog.Write("plane1_name: "+ string(plane_name));
	ProStringToWstring(wPlaneName, const_cast<char*> (plane_name));

	status = ProModelitemByNameInit(reqMdl, PRO_SURFACE, wPlaneName, &planeMdlitem);
	ruleLog.Write("ProModelitemByNameInit: "+to_string(status));
	if (status != PRO_TK_NO_ERROR)
	{
		UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Missing!", "Plane missing: "+string(plane_name)+". Refer help document for details.");
		return -1;
	}

	status = ProSelectionAlloc(NULL, &planeMdlitem, &planeSel);

	Pro2dPnt param_1, param_2;
	Pro3dPnt pnt_1, pnt_2;	
	double platformWidth;

	status = ProSelectionWithOptionsDistanceEval(planeSel, PRO_B_TRUE, sel_surf, PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: "+to_string(status)+"\tdistance: "+to_string(distance));
	if(status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT){
		UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selections.");
		return -1;
	}

	return 0;
}

int InterfaceRule::measureDistanceBetweenComponents(ComponentData reqComp1, ComponentData reqComp2, double &distance, Pro3dPnt(&pnt_arr)[2])
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenComponents <=================");

	ProSelection sels[2];
	ProIdTable idtbl1 = {reqComp1.id};		// component id of the component 1 to be selected
	ProIdTable idtbl2 = {reqComp2.id};		// component id of the component 2 to be selected

	ProName comp1_name, comp2_name;
	ProModelitem feature[2];
	ProMdl reqMdls[2];

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: "+to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);

	ProStringToWstring(comp2_name, reqComp2.name);
	status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
	status = ProMdlToModelitem(reqMdls[1], &feature[1]);

	ProAsmcomppath path[2];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: "+to_string(status));
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl2, 1, &path[1]);
	ruleLog.Write("ProAsmcomppathInit: "+to_string(status));

	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: "+to_string(status));
	status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
	ruleLog.Write("ProSelectionAlloc: "+to_string(status));

	ProBoolean is_interference_found;
	
	status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_NONE, sels[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, sels[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: "+to_string(status)+"\tdistance: "+to_string(distance));

	return 0;
}

int InterfaceRule::measureDistanceBetweenComponents(ComponentData reqComp1, ComponentData reqComp2, double& distance){

	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenComponents <=================");

	ProSelection sels[2];
	ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected
	ProIdTable idtbl2 = { reqComp2.id };		// component id of the component 2 to be selected

	ProName comp1_name, comp2_name;
	ProModelitem feature[2];
	ProMdl reqMdls[2];

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);

	ProStringToWstring(comp2_name, reqComp2.name);
	status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
	status = ProMdlToModelitem(reqMdls[1], &feature[1]);

	ProAsmcomppath path[2];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl2, 1, &path[1]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));
	status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	ProBoolean is_interference_found;
	Pro3dPnt pnt_arr[2];

	status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_NONE, sels[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, sels[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));

	return 0;
}

int InterfaceRule::measureDistanceBetweenSurfaceAndComp(ComponentData reqComp1, ProSelection sel, double& distance)
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenSurfaceAndComp <=================");

	ProSelection sels[1];
	ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected

	ProName comp1_name, comp2_name;
	ProModelitem feature[1];
	ProMdl reqMdls[1];

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);

	ProAsmcomppath path[2];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));


	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	Pro2dPnt param_1, param_2;
	Pro3dPnt pnt_1, pnt_2;
	double platformWidth;

	status = ProSelectionWithOptionsDistanceEval(sel, PRO_B_TRUE, sels[0], PRO_B_TRUE, param_1, param_2, pnt_1, pnt_2, &distance);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(distance));
	if (status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT) {
		UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selections.");
		return -1;
	}

	return 0;
}

int InterfaceRule::createTangentDatumPlaneWithReference(ProSelection& sel_surf, ProMdl& refPlaneOwner, char* refPlaneName, char* outputPlaneName)
{
	ProModelitem refPlaneitem;
	ProSelection reqMdlSel, refPlaneSel;
	wchar_t wRefPlaneName[PRO_NAME_SIZE], wOutputPlaneName[PRO_NAME_SIZE];
	ProElement	elem_tree, elem_ftype, elem_consts, elem_prl, elem_const_type1, elem_prl_ref, elem_tan, elem_const_type2, elem_tan_ref, elem_feature_name;
	ProReference REPDEP_ref1, REPDEP_ref2;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pln_feat;
	ProErrorlist errors;

	ProStringToWstring(wRefPlaneName, refPlaneName);
	status = ProModelitemByNameInit(refPlaneOwner, PRO_SURFACE, wRefPlaneName, &refPlaneitem);
	status = ProSelectionAlloc(NULL, &refPlaneitem, &refPlaneSel);

	/* =============================================================== *\
	Create Element Tree
	\* =============================================================== */
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	// FEATURE NAME
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wOutputPlaneName, outputPlaneName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);

	// CONSTRAINTS ALLOCATION
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINTS, &elem_consts);
	ProElemtreeElementAdd(elem_tree, NULL, elem_consts);
	ruleLog.Write("constraints status = " + to_string(status));

	// Constraint 1
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_tan);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_tan);
	ruleLog.Write("1st constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type1);
	ProElementIntegerSet(elem_const_type1, PRO_DTMPLN_TANG);
	status = ProElemtreeElementAdd(elem_tan, NULL, elem_const_type1);
	ruleLog.Write("1st constraint type status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_tan_ref);
	status = ProSelectionToReference(sel_surf, &REPDEP_ref1);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	status = ProElementReferenceSet(elem_tan_ref, REPDEP_ref1);
	ruleLog.Write("ProElementReferenceSet = " + to_string(status));
	status = ProElemtreeElementAdd(elem_tan, NULL, elem_tan_ref);
	ruleLog.Write("1st constraint reference status = " + to_string(status));

	// Constraint 2
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_prl);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_prl);
	ruleLog.Write("2nd constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type2);
	ProElementIntegerSet(elem_const_type2, PRO_DTMPLN_PRL);
	status = ProElemtreeElementAdd(elem_prl, NULL, elem_const_type2);
	ruleLog.Write("2nd constraint type status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_prl_ref);
	status = ProSelectionToReference(refPlaneSel, &REPDEP_ref2);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	ProElementReferenceSet(elem_prl_ref, REPDEP_ref2);
	status = ProElemtreeElementAdd(elem_prl, NULL, elem_prl_ref);
	ruleLog.Write("2nd constraint reference status = " + to_string(status));

	/* =============================================================== *\
	Create Model Selection Object
	\* =============================================================== */
	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Plane
	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pln_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	ruleLog.Write("ProArrayFree status = " + to_string(status));
	status = ProElementFree(&elem_tree);
	ruleLog.Write("ProElementFree status = " + to_string(status));
	status = ProSelectionFree(&reqMdlSel);
	ruleLog.Write("ProSelectionFree status = " + to_string(status));

	return 0;
}

int InterfaceRule::deleteDatumPlane(char *plane_name)
{
	ProFeature del_feat;
	ProFeatureDeleteOptions* delete_opts = 0;
	int *feat_ids;
	ProModelitem del_plnitem;
	wchar_t wDelPlaneName[PRO_NAME_SIZE];

	status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
	delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;

	status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
	ProStringToWstring(wDelPlaneName, plane_name);
	status = ProModelitemByNameInit(curMdl, PRO_SURFACE, wDelPlaneName, &del_plnitem);

	status = ProGeomitemFeatureGet((ProGeomitem*)&del_plnitem, &del_feat);
	ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status)+ "\tdel_feat.id = "+to_string(del_feat.id));
	feat_ids[0] = del_feat.id;
	status = ProFeatureWithoptionsDelete((ProSolid)curMdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
	ruleLog.Write("ProFeatureWithoptionsDelete status = " + to_string(status));

	status = ProArrayFree((ProArray*)&feat_ids);
	status = ProArrayFree((ProArray*)&delete_opts);

	return 0;
}

ProError InterfaceRule::measureDistanceBetweenSurfaces(ProSelection &sel_surf1, ProSelection &sel_surf2, double &distance_bw_surfs)
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenSurfaces <=================");

	Pro2dPnt param_surfs1, param_surfs2;
	Pro3dPnt pnt_surfs1, pnt_surfs2;	

	status = ProSelectionWithOptionsDistanceEval(sel_surf1, PRO_B_TRUE, sel_surf2, PRO_B_TRUE, param_surfs1, param_surfs2, pnt_surfs1, pnt_surfs2, &distance_bw_surfs);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: "+to_string(status)+"\tdistance_bw_surfs: "+to_string(distance_bw_surfs));

	return status;
}

ProError InterfaceRule::computeClearanceBetweenSurfaces(ProSelection &sel_surf1, ProSelection &sel_surf2, double &clearance_bw_surfs)
{
	ruleLog.Write("=================> InterfaceRule::computeClearanceBetweenSurfaces <=================");
	ProBoolean interf;
	Pro3dPnt coord[2];
	status = ProFitClearanceCompute(sel_surf1, PRO_FIT_INCLUDE_NONE, sel_surf2, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, NULL, PRO_B_FALSE, &clearance_bw_surfs, NULL, &interf, coord);
	return status;
}

//ProError InterfaceRule::deleteDatumPoint()
//{
//	ruleLog.Write("=================> InterfaceRule::deleteDatumPoints <=================");
//	ProError status;
//	int* feat_ids = NULL;
//	ProMdl mdl;
//	ProModelitem mdl_item;
//	ProFeature feat;
//	ProFeatureDeleteOptions* delete_opts = 0;
//	ProSelection* selections;
//	ProName name1, name2;
//	ProIdTable idtbl1;
//	ProAsmcomppath path;
//
//
//	status = ProMdlCurrentGet(&mdl);
//	ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));
//
//	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path);
//	ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));
//
//	ProStringToWstring(name1, "datum_PNT1");
//	status = ProModelitemByNameInit(mdl, PRO_POINT, name1, &mdl_item);
//	ruleLog.Write("ProModelitemByNameInit 1 status = " + to_string(status));
//	/*status = ProSelectionAlloc(&path, &mdl_item, &selections[0]);
//	ruleLog.Write("ProSelectionAlloc 1 status = " + to_string(status));*/
//
//	ProStringToWstring(name2, "datum_PNT2");
//	status = ProModelitemByNameInit(mdl, PRO_POINT, name2, &mdl_item);
//	ruleLog.Write("ProModelitemByNameInit 2 status = " + to_string(status));
//
//	if (status == PRO_TK_NO_ERROR) {
//		/*status = ProSelectionAlloc(&path, &mdl_item, &selections[1]);
//		ruleLog.Write("ProSelectionAlloc 2 status = " + to_string(status));*/
//		for (int i = 0; i < 1; i++)
//		{
//			/*status = ProSelectionModelitemGet(selections[i], &mdl_item);
//			ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));*/
//
//			status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
//			ruleLog.Write("ProArrayAlloc status = " + to_string(status));
//
//			status = ProGeomitemFeatureGet((ProGeomitem*)&mdl_item, &feat);
//			ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status));
//			feat_ids[0] = feat.id;
//
//			status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
//			delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;
//			status = ProFeatureWithoptionsDelete((ProSolid)mdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
//			ruleLog.Write("ProFeatureWithoptionsDelete status = " + to_string(status));
//
//			status = ProArrayFree((ProArray*)&delete_opts);
//			status = ProArrayFree((ProArray*)&feat_ids);
//
//		}
//	}
//	return PRO_TK_NO_ERROR;
//}

//int InterfaceRule::createDatumPoints(Pro3dPnt pnt_arr[2], char* csysName) 
//{
//	ruleLog.Write("=================> InterfaceRule::createDatumPoints <=================");
//	ProElement	elem_tree, elem_ftype, elem_feature_name,
//		pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
//		pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
//		pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
//	ProReference REPDEP_ref1;
//	wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wide_string[PRO_NAME_SIZE], wide_string_2[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE];
//	//CSYS_ASM_DEF
//	ProModelitem refCsysitem;
//	ProSelection refCsysSel, reqMdlSel;
//	ProFeatureCreateOptions* opts = 0;
//	ProFeature pnt_feat;
//	ProErrorlist errors;
//	//converting negative values to positive
//	double d1 = -pnt_arr[0][2];
//	double d2 = -pnt_arr[1][2];
//	char cDatumPointName[PRO_NAME_SIZE] = "Dist_highlght_pnt";
//
//	ProStringToWstring(wCsysName, csysName);
//	status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
//	status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);
//
//
//	//Create Element Tree
//	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
//	ruleLog.Write("Tree root status = " + to_string(status));
//
//	// TREE ALLOCATION
//	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
//	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
//	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
//	ruleLog.Write("type status = " + to_string(status));
//
//	//feature name
//	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
//	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, cDatumPointName));
//	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
//	ruleLog.Write("feature name = " + to_string(status));
//
//	//PRO_E_DPOINT_TYPE
//	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
//	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
//	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
//	ruleLog.Write("type status = " + to_string(status));
//
//	//Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
//	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
//	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);
//
//	//ref
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
//	status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
//	status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
//	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);
//
//	//
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
//	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
//	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);
//
//	//Populating array element
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
//	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);
//
//	//Point1
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);
//
//	//Point1 Name
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
//	ProStringToWstring(wide_string, "datum_PNT1");
//	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);
//
//	//PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
//	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
//	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);
//
//	//PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
//	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
//	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);
//
//	//PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
//	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
//	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);
//
//	//Point2
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);
//
//	//Point2 Name
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
//	ProStringToWstring(wide_string_2, "datum_PNT2");
//	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);
//
//	////PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
//	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
//	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);
//
//	////PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
//	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
//	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);
//
//	////PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
//	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
//	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
//	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
//	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);
//
//	/* =============================================================== *\
//	Create Model Selection Object
//	\* =============================================================== */
//
//	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
//	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
//	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
//
//	opts[0] = PRO_FEAT_CR_NO_OPTS;
//
//	// Create Points
//	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
//	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));
//
//	status = ProArrayFree((ProArray*)&opts);
//	status = ProElementFree(&elem_tree);
//	status = ProSelectionFree(&reqMdlSel);
//
//	ProSelection pnt_Sel;
//	status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
//	status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_ERROR);
//	//PRO_COLOR_SELECTED for green highlight
//	return 0;
//}

ProError InterfaceRule::deleteDatumPoint(char* dtmpoint_name)
{
	ruleLog.Write("=================> InterfaceRule::deleteDatumPoints <=================");
	ProError status;
	int* feat_ids = NULL;
	ProMdl mdl;
	ProModelitem mdl_item;
	ProFeature feat;
	ProFeatureDeleteOptions* delete_opts = 0;
	ProIdTable idtbl1;
	ProAsmcomppath path;
	wchar_t wdatum_pt[PRO_NAME_SIZE];

	status = ProMdlCurrentGet(&mdl);
	ruleLog.Write("ProMdlCurrentGet status = " + to_string(status));

	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path);
	ruleLog.Write("ProAsmcomppathInit status = " + to_string(status));


	ProStringToWstring(wdatum_pt, dtmpoint_name);
	status = ProModelitemByNameInit(mdl, PRO_POINT, wdatum_pt, &mdl_item);
	ruleLog.Write("ProModelitemByNameInit status = " + to_string(status));

	/*status = ProSelectionAlloc(&path, &mdl_item, &selections[0]);
	ruleLog.Write("ProSelectionAlloc 1 status = " + to_string(status));*/

	/*ProStringToWstring(name2, "datum_PNT2");
	status = ProModelitemByNameInit(mdl, PRO_POINT, name2, &mdl_item);
	ruleLog.Write("ProModelitemByNameInit 2 status = " + to_string(status));
	*/

	if (status == PRO_TK_NO_ERROR) {
		/*status = ProSelectionAlloc(&path, &mdl_item, &selections[1]);
		ruleLog.Write("ProSelectionAlloc 2 status = " + to_string(status));*/

		/*status = ProSelectionModelitemGet(selections[i], &mdl_item);
		ruleLog.Write("ProSelectionModelitemGet status = " + to_string(status));*/

		status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
		ruleLog.Write("ProArrayAlloc status = " + to_string(status));

		status = ProGeomitemFeatureGet((ProGeomitem*)&mdl_item, &feat);
		ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status));
		feat_ids[0] = feat.id;

		status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
		delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;
		status = ProFeatureWithoptionsDelete((ProSolid)mdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
		ruleLog.Write("ProFeatureWithoptionsDelete status = " + to_string(status));

		status = ProArrayFree((ProArray*)&delete_opts);
		status = ProArrayFree((ProArray*)&feat_ids);


	}
	return PRO_TK_NO_ERROR;
}

int InterfaceRule::deleteDatumAxis(char* axis_name)
{
	ruleLog.Write("=================> InterfaceRule::deleteDatumAxis <=================");
	ProFeature del_feat;
	ProFeatureDeleteOptions* delete_opts = 0;
	int* feat_ids;
	ProModelitem del_axsitem;
	wchar_t wDelAxisName[PRO_NAME_SIZE];

	status = ProArrayAlloc(1, sizeof(ProFeatureDeleteOptions), 1, (ProArray*)&delete_opts);
	delete_opts[0] = PRO_FEAT_DELETE_NO_OPTS;

	status = ProArrayAlloc(1, sizeof(int), 1, (ProArray*)&feat_ids);
	ProStringToWstring(wDelAxisName, axis_name);
	status = ProModelitemByNameInit(curMdl, PRO_AXIS, wDelAxisName, &del_axsitem);

	status = ProGeomitemFeatureGet((ProGeomitem*)&del_axsitem, &del_feat);
	ruleLog.Write("ProGeomitemFeatureGet status = " + to_string(status) + "\tdel_feat.id = " + to_string(del_feat.id));
	feat_ids[0] = del_feat.id;
	status = ProFeatureWithoptionsDelete((ProSolid)curMdl, feat_ids, delete_opts, PRO_REGEN_NO_FLAGS);
	ruleLog.Write("ProFeatureWithoptionsDelete status = " + to_string(status));

	status = ProArrayFree((ProArray*)&feat_ids);
	status = ProArrayFree((ProArray*)&delete_opts);

	return 0;
}

int InterfaceRule::measureDistanceBetweenAsmAndPart(ComponentData reqComp1, ProSelection* Part_sel, double& distance)
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenAsmAndPart <=================");
	ProSelection sels[1];
	ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected
	ProName comp1_name;
	ProModelitem feature[1];
	ProMdl reqMdls[1];

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProAsmcomppath path[1];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	status = ProSelectionHighlight(sels[0], PRO_COLOR_HIGHLITE);

	////ProSelection* Part_sel;
	//int n_sels;
	//status = ProSelect((char*)"prt_or_asm", 1, NULL, NULL, NULL, NULL, &Part_sel, &n_sels);
	//ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(n_sels));

	ProBoolean is_interference_found;
	Pro3dPnt pnt_arr[1];
	status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_NONE, *Part_sel, PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, sels[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));

	return 0;
}

// MATHAN PRASATH
int InterfaceRule::createDatumPoints(Pro3dPnt pnt_arr[2], char* csysName, char* outputPointName)
{

	ruleLog.Write("=================> InterfaceRule::createDatumPoints <=================");
	ProElement    elem_tree, elem_ftype,
		pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
		pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
		pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2, elem_feature_name;
	ProReference REPDEP_ref1;
	wchar_t wdatum_pt[PRO_NAME_SIZE], wCsysName[PRO_NAME_SIZE], wide_string[PRO_NAME_SIZE], wide_string_2[PRO_NAME_SIZE];
	wchar_t wOutputPointName[PRO_NAME_SIZE];
	wchar_t wOutputPointName2[PRO_NAME_SIZE];
	ProModelitem refCsysitem;
	ProSelection refCsysSel, reqMdlSel;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pnt_feat;
	ProErrorlist errors;
	double d1 = -pnt_arr[0][2];
	double d2 = -pnt_arr[1][2];
	wchar_t* Dist_highlght_pnt1;
	wchar_t* Dist_highlght_pnt2;

	ProStringToWstring(wCsysName, csysName);
	status = ProModelitemByNameInit(curMdl, PRO_CSYS, wCsysName, &refCsysitem);
	status = ProSelectionAlloc(NULL, &refCsysitem, &refCsysSel);

	//Create Element Tree
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	//PRO_E_DPOINT_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
	ruleLog.Write("type status = " + to_string(status));

	//PRO_E_DPOINT_NAME
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wOutputPointName, outputPointName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);

	//Populating element PRO_E_DPOINT_OFST_CSYS_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);

	//ref
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
	status = ProSelectionToReference(refCsysSel, &REPDEP_ref1);
	status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);

	//
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);

	//Populating array element
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);

	//Point1
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);

	//Point1 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
	ProStringToWstring(wide_string, "datum_PNT1");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, wide_string);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, d1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);

	//PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[0][1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);

	//Point2
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);

	//Point2 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
	ProStringToWstring(wide_string_2, "datum_PNT2");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, wide_string_2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR1_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[1][0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR2_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, d2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);

	////PRO_E_DPOINT_OFST_CSYS_DIR3_VAL
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[1][1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);

	/* =============================================================== *\
	Create Model Selection Object
	\* =============================================================== */

	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;
	// Create Points
	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	status = ProElementFree(&elem_tree);
	status = ProSelectionFree(&reqMdlSel);

	ProSelection pnt_Sel;
	status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
	status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_SS_FAILED_ITEMS);
	return 0;
}

// MATHAN PRASATH
int InterfaceRule::f2D01_measureDistanceBetweenComponents(ComponentData reqComp1, ComponentData reqComp2, double& distance)
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenComponents <=================");

	ProSelection sels[2];
	ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected
	ProIdTable idtbl2 = { reqComp2.id };		// component id of the component 2 to be selected

	ProName comp1_name, comp2_name;
	ProModelitem feature[2];
	ProMdl reqMdls[2];

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);

	ProStringToWstring(comp2_name, reqComp2.name);
	status = ProMdlnameInit(comp2_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[1]);
	status = ProMdlToModelitem(reqMdls[1], &feature[1]);

	ProAsmcomppath path[2];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl2, 1, &path[1]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));
	status = ProSelectionAlloc(&path[1], &feature[1], &sels[1]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	ProBoolean is_interference_found;
	Pro3dPnt pnt_arr[2];


	status = ProFitClearanceCompute(sels[0], PRO_FIT_INCLUDE_NONE, sels[1], PRO_FIT_INCLUDE_NONE, PRO_FIT_WHOLE_SURFACE, sels[0], PRO_B_FALSE, &distance, NULL, &is_interference_found, pnt_arr);
	ruleLog.Write("ProFitClearanceCompute: " + to_string(status) + "\tdistance: " + to_string(distance));

	//create datum points
	char OutputPointName1[PRO_NAME_SIZE]="Dist_highlght_pnt";
	createDatumPoints(pnt_arr, "CSYS_ASM_DEF", OutputPointName1);

	return 0;
}


// CALLBACK FUNCTIONS

/*====================================================================*\
FUNCTION :  ProUtilVectorDot()
PURPOSE  :  Dot product of two vectors
\*====================================================================*/
double ProUtilVectorDot(double a[3], double b[3])
{
	double dot;
	dot = a[2] * b[2] + a[1] * b[1] + a[0] * b[0];
	return(dot);
}

/*====================================================================*\
FUNCTION :  ProUtilVectorLength()
PURPOSE  :  Length of a vector
\*====================================================================*/
double ProUtilVectorLength(double v[3])
{
	return(sqrt(v[0] * v[0] +
		v[1] * v[1] +
		v[2] * v[2]));
}

/*====================================================================*\
FUNCTION :  ProUtilVectorScale()
PURPOSE  :  Multiply a vector by a scalar
\*====================================================================*/
double* ProUtilVectorScale(double scalar, double vector[3], double result[3])
{
	result[0] = scalar * vector[0];
	result[1] = scalar * vector[1];
	result[2] = scalar * vector[2];
	return(result);
}

/*====================================================================*\
FUNCTION :  ProUtilVectorNormalize()
PURPOSE  :  Normalize a vector
\*====================================================================*/
double* ProUtilVectorNormalize(double input[3], double output[3])
{
	double len;
	len = ProUtilVectorLength(input);
	if (len < PRO_UTIL_ALMOST_ZERO)
	{
		output[0] = input[0];
		output[1] = input[1];
		output[2] = input[2];
		return output;
	}
	else
		return(ProUtilVectorScale(1.0 / len, input, output));
}

/*====================================================================*\
FUNCTION :  ProUtilVectorCopy()
PURPOSE  :  Copy a vector to another
\*====================================================================*/
double* ProUtilVectorCopy(
	double from[3],
	double to[3])
{
	if (from == NULL)
		to[0] = to[1] = to[2] = 0.0;
	else
	{
		to[0] = from[0];
		to[1] = from[1];
		to[2] = from[2];
	}
	return(to);
}

ProError optionMenuImageChangeAction(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- optionMenuImageChangeAction -----------------------------");

	string *reqData = (string *)data;
	int n_sel;
	char **selValue;
	status = ProUIOptionmenuSelectednamesGet(dialog, component, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	ruleLog.Write("selValue = " + string(selValue[0]));

	char imgName[PRO_NAME_SIZE], cPbName[PRO_NAME_SIZE];
	ProTKSprintf(imgName, "%s/%s.png", reqData[1], selValue[0]);
	strcpy(cPbName, reqData[0].c_str());
	status = ProUIPushbuttonBitmapSet(dialog, cPbName, imgName);
	ruleLog.Write("ProUIPushbuttonBitmapSet: " + to_string(status));

	return PRO_TK_NO_ERROR;
}

ProError compsFilter(ProFeature* p_feature, ProAppData app_data)
{
	ProFeattype feat_type;
	status = ProFeatureTypeGet(p_feature, &feat_type);

	return (feat_type == PRO_FEAT_COMPONENT? PRO_TK_NO_ERROR : PRO_TK_CONTINUE);
}

ProError planeFilter(ProFeature* p_feature, ProAppData app_data)
{
	ruleLog.Write("---------PlaneFilter--------");
	ProFeattype featType;
	status = ProFeatureTypeGet(p_feature, &featType);
	ruleLog.Write("ProFeatureTypeGet status: " + to_string(status));

	return (featType == PRO_FEAT_DATUM ? PRO_TK_NO_ERROR : PRO_TK_CONTINUE);
}

ProError getReqComponentsId(ProFeature *pFeat, ProError status, ProAppData appD)
{
	ruleLog.Write("----------------------------- getReqComponentsId -----------------------------");

	ComponentData *reqs = (ComponentData*)appD;
	int reqs_size = 10;
	ProMdl req_mdl;
	wchar_t wMdlName[PRO_NAME_SIZE];
	char cMdlName[PRO_NAME_SIZE];

	status = ProAsmcompMdlGet((ProAsmcomp*)pFeat, &req_mdl);
	status = ProMdlMdlnameGet(req_mdl, wMdlName);
	ProWstringToString(cMdlName, wMdlName);

	for (int i = 0; i < reqs_size; ++i)
	{
		if (strcmp(cMdlName, reqs[i].name) == 0)
		{
			reqs[i].id = pFeat->id;
		}
			
	}
		

	return PRO_TK_NO_ERROR;
}

ProError getReqComponentsIdVec(ProFeature* pFeat, ProError status, vector<ComponentData>* _reqComps)
{
	ruleLog.Write("----------------------------- getReqComponentsId -----------------------------");



	ruleLog.Write("reqs_size: " + to_string(_reqComps->size()));
	ProMdl req_mdl;

	wchar_t wMdlName[PRO_NAME_SIZE];
	char cMdlName[PRO_NAME_SIZE];

	status = ProAsmcompMdlGet((ProAsmcomp*)pFeat, &req_mdl);
	ruleLog.Write("ProAsmcompMdlGet status: " + to_string(status));
	if (status == PRO_TK_NO_ERROR)
	{
		status = ProMdlMdlnameGet(req_mdl, wMdlName);
		ruleLog.Write("ProMdlMdlnameGet status: " + to_string(status));
		ProWstringToString(cMdlName, wMdlName);
		ruleLog.Write("cMdlName: " + (string)cMdlName);

		ruleLog.Write("reqs_size: " + to_string(_reqComps->size()));
		for (int i = 0; i < _reqComps->size(); ++i)
		{
			/*ruleLog.Write("running for: " + to_string(i) + "th time");*/
			ruleLog.Write("reqs[" + to_string(i) + "].name: " + _reqComps->at(i).name);
			if (strcmp(cMdlName, _reqComps->at(i).name) == 0)
			{
				_reqComps->at(i).id = pFeat->id;

			}
		}
		ProMdlType mdlType;
		status = ProMdlTypeGet(req_mdl, &mdlType);
		ruleLog.Write("ProMdlTypeGet status: " + to_string(status));

		if (mdlType == PRO_MDL_ASSEMBLY)
		{
			ruleLog.Write("visiting " + (string)cMdlName);
			status = ProSolidFeatVisit((ProSolid)req_mdl, (ProFeatureVisitAction)getReqComponentsIdVec, compsFilter, _reqComps);
			ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));
		}
	}

	return PRO_TK_NO_ERROR;
}

ProError getVisitedCompAsmNamesAction(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("----------------------------- getVisitedCompAsmNamesAction -----------------------------");

	vector<ComponentData> *namesList = (vector<ComponentData>*)app_data;
	ProMdl subModuleMdl;
	ProMdlType subModuleMdlType;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ComponentData cd;

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &subModuleMdl);
	status = ProMdlTypeGet(subModuleMdl, &subModuleMdlType);
	status = ProMdlMdlnameGet(subModuleMdl, wFeatName);
	ProWstringToString(cFeatName, wFeatName);

	strcpy(cd.name, cFeatName);
	cd.id = p_feature->id;
	namesList->push_back(cd);
	//ruleLog.Write("cFeatName: " + string(cFeatName));

	if (subModuleMdlType == PRO_MDL_ASSEMBLY)
		ProSolidFeatVisit((ProSolid)subModuleMdl, getVisitedCompAsmNamesAction, compsFilter, (ProAppData)namesList);

	return PRO_TK_NO_ERROR;
}

ProError getParameterDescAndPartname(ProFeature* p_feature, ProError status, ProAppData app_data)
{
	ruleLog.Write("----------------------------- getParameterDescAndPartname -----------------------------");

	vector<PartnameDescriptionPair>* prtname_desc_list = (vector<PartnameDescriptionPair>*)app_data;
	ProMdlType subModuleMdlType;
	ProModelitem modelItem;
	wchar_t wFeatName[PRO_NAME_SIZE];
	char cFeatName[PRO_NAME_SIZE];
	ProMdl reqMdl;
	char existingPval[PRO_NAME_SIZE]{};
	PartnameDescriptionPair compd{};

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	//ruleLog.Write("ProAsmcompMdlGet: " + to_string(status));
	status = ProMdlTypeGet(reqMdl, &subModuleMdlType);
	//ruleLog.Write("ProMdlTypeGet: " + to_string(status));
	status = ProMdlMdlnameGet(reqMdl, wFeatName);
	//ruleLog.Write("ProMdlMdlnameGet: " + to_string(status));
	ProWstringToString(cFeatName, wFeatName);

	if (subModuleMdlType == PRO_MDL_ASSEMBLY)
	{
		//ruleLog.Write("Assembly Name: ");
		//ruleLog.Write(cFeatName);
		ProSolidFeatVisit((ProSolid)reqMdl, getParameterDescAndPartname, compsFilter, (ProAppData)app_data);
	}

	else if (subModuleMdlType == PRO_MDL_PART)
	{
		status = ProMdlToModelitem(reqMdl, &modelItem);
		//ruleLog.Write("ProMdlToModelitem: " + to_string(status));

		ProParameter pDesc;
		ProParamvalue pvDesc;
		ProName pDescName = L"DESCRIPTION";

		status = ProParameterInit(&modelItem, pDescName, &pDesc);
		//ruleLog.Write("ProParameterInit: " + to_string(status));

		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ProWstringToString(existingPval, pvDesc.value.s_val);
			//ruleLog.Write("ProParameterValueWithUnitsGet: " + to_string(status) + "\tExisting val: " + existingPval);
			
			strcpy(compd.description, existingPval);
			//ruleLog.Write("compd.description" + string(compd.description));
		}
		strcpy(compd.part_name, cFeatName);
		//ruleLog.Write("compd.part_name: " + string(compd.part_name));

		prtname_desc_list->push_back(compd);
		//memset(compd.description, 0, sizeof(compd.description));
	}
	return PRO_TK_NO_ERROR;
}

ProError getSelectedTypeOpMenu(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- getSelectedTypeOpMenu -----------------------------");

	string* _data = (string*)data;
	int n_sel;
	char** selValue;
	char opMenuName[PRO_NAME_SIZE]{};
	strcpy(opMenuName, _data[0].c_str());
	status = ProUIOptionmenuSelectednamesGet(dialog, opMenuName, &n_sel, &selValue);
	ruleLog.Write("ProUIOptionmenuSelectednamesGet: " + to_string(status));
	*_data = selValue[0];
	ruleLog.Write("Selected Option Menu value = " + *_data);

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);

	return status;
}

ProError ruleDlgOKaction(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgOKaction -----------------------------");

	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return PRO_TK_NO_ERROR;
}

ProError ruleDlgCloseAction(char* dialog, char* component, ProAppData data)
{
	ruleLog.Write("----------------------------- ruleDlgCloseAction -----------------------------");

	if(data != NULL){
		bool *quitAction = (bool*)data;
		*quitAction = true;
	}
	status = ProUIDialogExit(dialog, PRO_TK_NO_ERROR);
	return status;
}

ProError visit11DigitComponents(ProFeature* p_feature, ProError status, vector<HardwareInfo>* _hwInfo)
{
	ruleLog.Write("----------------------------- visit11DigitComponents -----------------------------");

	ProMdl                  subModuleMdl;
	wchar_t                 wFeatName[PRO_NAME_SIZE];
	char                    cFeatName[PRO_NAME_SIZE];
	ProMdlType              subModuleMdlType;
	string                  description;
	ProModelitem            subModuleModelItem;
	ProParameter            pDesc;
	ProParamvalue           pvDesc;
	ProName                 pDescName = L"DESCRIPTION";
	char                    existingPval[PRO_NAME_SIZE];
	HardwareInfo            object;

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &subModuleMdl);
	ruleLog.Write("ProSolidFeatVisit : " + to_string(status));
	status = ProMdlMdlnameGet(subModuleMdl, wFeatName);
	ruleLog.Write("ProMdlMdlnameGet : " + to_string(status));
	status = ProMdlTypeGet(subModuleMdl, &subModuleMdlType);
	ruleLog.Write("ProMdlTypeGet : " + to_string(status));


	if (subModuleMdlType == PRO_MDL_PART)
	{
		//_hwInfo->clear();
		ProWstringToString(cFeatName, wFeatName);
		int         strlength{ 0 };
		strlength = strlen(cFeatName);
		if (strlength == 11)
		{
			status = ProMdlToModelitem(subModuleMdl, &subModuleModelItem);
			ruleLog.Write("ProMdlToModelitem : " + to_string(status));
			status = ProParameterInit(&subModuleModelItem, pDescName, &pDesc);
			ruleLog.Write("ProParameterInit : " + to_string(status));
			if (status != PRO_TK_E_NOT_FOUND)
			{
				status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
				ruleLog.Write("ProParameterValueWithUnitsGet : " + to_string(status));
				ProWstringToString(existingPval, pvDesc.value.s_val);
				description.append(existingPval);
				ruleLog.Write(description);

				//Keywords for fasteners
				const regex p("(SCREW)");
				const regex q("(SCR)");
				const regex r("(BOLT)");
				const regex s("(NUT)");
				const regex t("(WELD)");

				//Patterns for grade values
				regex numberRegex("-(\\d+)");
				regex decimalRegex("\\b\\d+\\.\\d");

				smatch                    matchFound;
				string                    grade;
				double                    gradeInt;
				string                    category;
				string::const_iterator searchStart(description.cbegin());
				if ((regex_search(description, matchFound, p) || regex_search(description, matchFound, q) ||
					regex_search(description, matchFound, r) || regex_search(description, matchFound, s)) && (regex_search(description, t) == 0))
				{
					category = matchFound.str();

					if (regex_search(description, matchFound, decimalRegex))
					{
						grade = matchFound.str();
						ruleLog.Write("check for decimal");
					}
					else if (regex_search(searchStart, description.cend(), matchFound, numberRegex))
					{
						grade = matchFound[1].str();
						ruleLog.Write("check for number");
					}
					object.ID = p_feature->id;
					object.Item = subModuleModelItem;
					strcpy(object.compName, cFeatName);
					ruleLog.Write(object.compName);
					object.gradeDb = stod(grade);
					ruleLog.Write(to_string(object.gradeDb));
					object.typeOfHw = string(category);
					ruleLog.Write(object.typeOfHw);
					_hwInfo->push_back(object);
				}
			}
		}
	}
	return PRO_TK_NO_ERROR;
}

string doubleToString(double value)
{
	std::stringstream stream;
	stream << std::fixed << std::setprecision(2) << value;
	return stream.str();
}

ProError getVisiblePlanes(ProFeature* pFeat, ProError status, vector<planeData>* datumPlaneNames)
{
	ruleLog.Write("----------------------------- getReqPlane -----------------------------");
	/*vector<ComponentData>* planeData = (vector<ComponentData>*)appD;*/
	planeData planeD;
	ProFeattype FeatType;
	ProMdl reqMdl, planeOwnerMdl;
	ProMdlType typeMdl;
	wchar_t wPlaneName[PRO_NAME_SIZE];
	char cPlaneName[PRO_NAME_SIZE];
	ProBoolean isVisible;
	char* cpyName;

	status = ProFeatureTypeGet(pFeat, &FeatType);
	ruleLog.Write("ProFeatureTypeGet status: " + to_string(status));

	if (FeatType == PRO_FEAT_COMPONENT)
	{
		status = ProAsmcompMdlGet((ProAsmcomp*)pFeat, &reqMdl);
		status = ProMdlTypeGet(reqMdl, &typeMdl);
		if (typeMdl == PRO_MDL_ASSEMBLY)
		{
			status = ProSolidFeatVisit((ProSolid)reqMdl, (ProFeatureVisitAction)getVisiblePlanes, planeFilter, datumPlaneNames);
			ruleLog.Write("ProSolidFeatVisit status: " + to_string(status));

		}
	}
	if (FeatType == PRO_FEAT_DATUM)
	{
		status = ProFeatureVisibilityGet(pFeat, &isVisible);
		ruleLog.Write("ProFeatureVisibilityGet" + to_string(status));

		if (isVisible == PRO_B_TRUE)
		{
			status = ProModelitemNameGet((ProModelitem*)pFeat, wPlaneName);
			ruleLog.Write("ProModelitemNameGet" + to_string(status));

			status = ProModelitemMdlGet((ProModelitem*)pFeat, &planeOwnerMdl);
			ruleLog.Write("ProModelitemMdlGet" + to_string(status));

			ProWstringToString(cPlaneName, wPlaneName);
			ruleLog.Write("Name of the Plane is: " + (string)cPlaneName);
			strcpy(planeD.name, cPlaneName);
			planeD.ownerMdl = planeOwnerMdl;
			datumPlaneNames->push_back(planeD);
		}
	}

	return PRO_TK_NO_ERROR;
}

int highlightParts(ComponentData reqComp1, ProColortype)
{
	ruleLog.Write("=================> InterfaceRule::highlightParts <=================");
	ProSelection sels[1];
	ProIdTable idtbl1 = { reqComp1.id };        // component id of the component 1 to be selected
	ProName comp1_name;
	ProModelitem feature[1];
	ProMdl reqMdls[1];

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);
	ruleLog.Write("ProMdlToModelitem: " + to_string(status));

	ProAsmcomppath path[1];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));

	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	status = ProSelectionHighlight(sels[0], PRO_COLOR_LETTER);
	return 0;
}

// Function to split a string based on a delimiter
std::vector<std::string> split(const std::string& s, char delimiter)
{
	std::vector<std::string> tokens;
	std::string token;
	std::istringstream tokenStream(s);
	while (std::getline(tokenStream, token, delimiter)) {
		tokens.push_back(token);
	}
	return tokens;
}

void option_menu_set(char* dialog, vector<string> option_menulist, char* optionmenu)
{
	ruleLog.Write("----------------------------- option_menu_set_f4a02002 -----------------------------");
	//long memore = LONG_MAX;
	char** springtypes;
	wchar_t** springtypeslabels;
	status = ProArrayAlloc(option_menulist.size(), sizeof(char*), (50), (ProArray*)&springtypes);
	status = ProArrayAlloc(option_menulist.size(), sizeof(wchar_t*), (50), (ProArray*)&springtypeslabels);

	for (int i = 0; i < option_menulist.size(); ++i)
	{
		springtypes[i] = (char*)calloc((50), sizeof(char));
		ProTKSprintf(springtypes[i], "%s", option_menulist[i]);

		springtypeslabels[i] = (wchar_t*)calloc((50), sizeof(wchar_t));
		ProStringToWstring(springtypeslabels[i], springtypes[i]);
	}
	status = ProUIOptionmenuNamesSet(dialog, optionmenu, int(option_menulist.size()), springtypes);
	ruleLog.Write("ProUIOptionmenuNamesSet: " + to_string(status));
	status = ProUIOptionmenuLabelsSet(dialog, optionmenu, int(option_menulist.size()), springtypeslabels);
	ruleLog.Write("ProUIOptionmenuLabelsSet: " + to_string(status));

	//optionMenuSpringTypes.clear();

	status = ProArrayFree((ProArray*)&springtypes);
	status = ProArrayFree((ProArray*)&springtypeslabels);
}

ProError getVisitedCompAsmNamesAndDescription(ProFeature* p_feature, ProError status, vector<PartnameDescriptionPair>* compList)
{
	ProMdl					reqMdl;
	wchar_t					wMdlName[PRO_NAME_SIZE];
	char					cMdlName[PRO_NAME_SIZE];
	PartnameDescriptionPair				comp;
	ProModelitem			modelItem;
	ProParameter            pDesc;
	ProParamvalue           pvDesc;
	ProName                 pDescName = L"DESCRIPTION";
	char                    existingPval[PRO_NAME_SIZE];
	ProMdlType				mdlType;

	status = ProAsmcompMdlGet((ProAsmcomp*)p_feature, &reqMdl);
	if (status == PRO_TK_NO_ERROR)
	{
		status = ProMdlMdlnameGet(reqMdl, wMdlName);
		ProWstringToString(cMdlName, wMdlName);
		strcpy(comp.part_name, cMdlName);

		status = ProMdlToModelitem(reqMdl, &modelItem);
		status = ProParameterInit(&modelItem, pDescName, &pDesc);
		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			ProWstringToString(existingPval, pvDesc.value.s_val);
			strcpy(comp.description, existingPval);

		}
		status = ProMdlTypeGet(reqMdl, &mdlType);
		comp.mdlType = mdlType;
		compList->push_back(comp);
		if (mdlType == PRO_MDL_ASSEMBLY)
		{
			status = ProSolidFeatVisit((ProSolid)reqMdl, (ProFeatureVisitAction)getVisitedCompAsmNamesAndDescription, compsFilter, compList);
		}

	}

	return PRO_TK_NO_ERROR;
}

/*======================================================================================================
========= Functions required for ground clearance and departure & ramp over departure angle rule =======
=======================================================================================================*/

ProError measureDistanceBetweenSurfacesWithOptions(ProSelection& sel_surf1, ProBoolean option1, ProSelection& sel_surf2, ProBoolean option2, double& distance_bw_surfs)
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenSurfaces <=================");

	Pro2dPnt param_surfs1, param_surfs2;
	Pro3dPnt pnt_surfs1, pnt_surfs2;

	status = ProSelectionWithOptionsDistanceEval(sel_surf1, option1, sel_surf2, option2, param_surfs1, param_surfs2, pnt_surfs1, pnt_surfs2, &distance_bw_surfs);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance_bw_surfs: " + to_string(distance_bw_surfs));

	return status;
}

int createDatumPointAtCenterOfEdge(ProSelection edgeSelection, char cPointName[PRO_NAME_SIZE])
{
	ruleLog.Write("========= createDatumPointAtCenterOfEdge =============");

	ProElement elem_tree, elem_ftype, pro_e_dpoint_type, pro_e_std_feature_name, pro_e_dpoint_points_array,
		pro_e_dpoint_point, pro_e_dpoint_point_name, pro_e_dpoint_pla_constraints, pro_e_dpoint_pla_constraint,
		pro_e_dpoint_pla_constr_ref, pro_e_dpoint_pla_constr_type;
	ProName arrayName;
	ProReference REPDEP_ref1;
	ProModelitem item1;
	ProSelection edgeSel{}, model_selection;
	ProFeatureCreateOptions* opts = 0;
	ProFeature              feature;
	ProErrorlist            errors;

	ruleLog.Write("Element tree started");

	status = ProSelectionToReference(edgeSelection, &REPDEP_ref1);
	ruleLog.Write("ProSelectionToReference status: " + to_string(status));

	//Allocate tree 
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	//Allocate feature type
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ruleLog.Write("ProElementAlloc status feature: = " + to_string(status));
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
	ruleLog.Write("ProElementIntegerSet status feature: = " + to_string(status));
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("ProElemtreeElementAdd status feature: = " + to_string(status));
	ruleLog.Write("feature type allocation status = " + to_string(status));

	//PRO_E_DPOINT_TYPE (general)
	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
	ruleLog.Write("ProElementAlloc status feature type: = " + to_string(status));
	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_GENERAL);
	ruleLog.Write("ProElementIntegerSet status feature type: = " + to_string(status));
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
	ruleLog.Write("ProElemtreeElementAdd status feature type: = " + to_string(status));
	ruleLog.Write("datum point type allocation type status = " + to_string(status));

	//Allocating element for feature name
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &pro_e_std_feature_name);
	ruleLog.Write("ProElementAlloc status feature name: = " + to_string(status));
	ProStringToWstring(arrayName, "MY_PNT0");
	status = ProElementWstringSet(pro_e_std_feature_name, arrayName);
	ruleLog.Write("ProElementWstringSet status feature name: = " + to_string(status));
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_std_feature_name);
	ruleLog.Write("ProElemtreeElementAdd status feature name: = " + to_string(status));

	//Allocate points array
	status = ProElementAlloc(PRO_E_DPOINT_POINTS_ARRAY, &pro_e_dpoint_points_array);
	ruleLog.Write("ProElementAlloc status array: = " + to_string(status));
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_points_array);
	ruleLog.Write("ProElemtreeElementAdd status array: = " + to_string(status));

	//Allocating point in the array
	status = ProElementAlloc(PRO_E_DPOINT_POINT, &pro_e_dpoint_point);
	ruleLog.Write("ProElementAlloc status point: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_points_array, NULL, pro_e_dpoint_point);
	ruleLog.Write("ProElemtreeElementAdd status point: = " + to_string(status));

	//Allocating name of the point
	status = ProElementAlloc(PRO_E_DPOINT_POINT_NAME, &pro_e_dpoint_point_name);
	ruleLog.Write("ProElementAlloc status point name: = " + to_string(status));
	wchar_t wPointName[PRO_NAME_SIZE];
	ProStringToWstring(wPointName, cPointName);
	status = ProElementWstringSet(pro_e_dpoint_point_name, wPointName);
	ruleLog.Write("ProElementWstringSet status point name: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_point, NULL, pro_e_dpoint_point_name);
	ruleLog.Write("ProElemtreeElementAdd status point name: = " + to_string(status));

	//Allocating placement constraints
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTRAINTS, &pro_e_dpoint_pla_constraints);
	ruleLog.Write("ProElementAlloc status constraints: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_point, NULL, pro_e_dpoint_pla_constraints);
	ruleLog.Write("ProElemtreeElementAdd status constratints: = " + to_string(status));

	//Allocating an element for a constraint
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTRAINT, &pro_e_dpoint_pla_constraint);
	ruleLog.Write("ProElementAlloc status constraint: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_pla_constraints, NULL, pro_e_dpoint_pla_constraint);
	ruleLog.Write("ProElemtreeElementAdd status constratint: = " + to_string(status));

	//Allocating a reference
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_REF, &pro_e_dpoint_pla_constr_ref);
	ruleLog.Write("ProElementAlloc status reference: = " + to_string(status));
	status = ProElementReferenceSet(pro_e_dpoint_pla_constr_ref, REPDEP_ref1);
	ruleLog.Write("ProElementReferenceSet status: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_pla_constraint, NULL, pro_e_dpoint_pla_constr_ref);
	ruleLog.Write("ProElemtreeElementAdd status reference: = " + to_string(status));

	//Allocating constraint type
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_TYPE, &pro_e_dpoint_pla_constr_type);
	ruleLog.Write("ProElementAlloc status reference type: = " + to_string(status));
	status = ProElementIntegerSet(pro_e_dpoint_pla_constr_type, PRO_DTMPNT_CONSTR_TYPE_CENTER);
	ruleLog.Write("ProElementIntegerSet status reference type: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_pla_constraint, NULL, pro_e_dpoint_pla_constr_type);
	ruleLog.Write("ProElemtreeElementAdd status reference type: = " + to_string(status));

	/*---------------------------------------------------------------*\
	Create the feature in the current model.
  \*---------------------------------------------------------------*/
  /*status = ProMdlCurrentGet(&model);
  if (status != PRO_TK_NO_ERROR) return (status);
  status = ProMdlToModelitem(model, &model_item);*/
	status = ProSelectionAlloc(NULL, &curMdlitem, &model_selection);
	ruleLog.Write("ProSelectionAlloc status featCreate: " + to_string(status));

	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
	ruleLog.Write("ProArrayAlloc status featCreate: " + to_string(status));

	opts[0] = PRO_FEAT_CR_DEFINE_MISS_ELEMS;

	status = ProFeatureWithoptionsCreate(model_selection, elem_tree, opts, PRO_REGEN_NO_FLAGS, &feature, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status featCreate: " + to_string(status));
	status = ProArrayFree((ProArray*)&opts);
	ruleLog.Write("ProArrayFree status featCreate: " + to_string(status));
	status = ProElementFree(&elem_tree);
	ruleLog.Write("ProElementFree status featCreate: " + to_string(status));
	return 0;
}

ProError refSurfSelections(char* dialog, char* component, vector<selectionInfo>* ownerDetails)
{
	ruleLog.Write("=================== referenceSelectionForPlane ==================");

	InterfaceRule  iRule;
	int            selNumber;
	ProWindowRepaint(PRO_VALUE_UNUSED);
	vector<string>frontVec, rearVec;
	ProSelection* refSurfSel;
	char selFilter[PRO_NAME_SIZE];

	if (ownerDetails->size() == 2)
	{
		iRule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention!!", "Please select highlighted surface of disc on  both the wheels, front and rear.");
		strcpy(selFilter, "surface\0");
	}
	if (ownerDetails->size() == 1)
	{
		iRule.UserDisplayPopupMessageOK(PROUIMESSAGE_INFO, "Attention!!", "Please select edge of the rearmost component.\n(ususally highlighted edge of the long member)");
		strcpy(selFilter, "edge\0");
	}
	status = ProUIDialogHide(dialog);
	ruleLog.Write("selection Filter based on number of selections: " + (string)selFilter);

	status = ProSelect(selFilter, ownerDetails->size(), NULL, NULL, NULL, NULL, &refSurfSel, &selNumber);
	ruleLog.Write("Proselect status = " + to_string(status) + "\tNo. of Selections = " + to_string(selNumber));

	if (status == PRO_TK_USER_ABORT) {
		iRule.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Please select inputs again!. Refer help document for details.");
		status = ProUIDialogShow(dialog);
		//status = ProUIPushbuttonDisable(dialog, PB_ROK);
		return status;
	}
	if ((selNumber < ownerDetails->size()) || (status != PRO_TK_NO_ERROR)) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Invalid Selection. Refer help document for details.");
		status = ProUIDialogShow(dialog);
		//status = ProUIPushbuttonDisable(dialog, PB_ROK);
		return status;
	}

	char              cParentMdlName[PRO_NAME_SIZE], desc[PRO_NAME_SIZE];
	wchar_t           wParentMdlName[PRO_NAME_SIZE];

	ProModelitem      modelItem;
	string            description;
	ProParameter      pDesc;
	ProParamvalue     pvDesc;
	ProName			  pDescName = L"DESCRIPTION";
	ProAsmcomppath	  path;
	for (int i = 0; i < selNumber; i++)
	{
		description.erase();
		status = ProSelectionAsmcomppathGet(refSurfSel[i], &path);
		ruleLog.Write("ProSelectionAsmcomppathGet status: " + to_string(status));

		status = ProSelectionModelitemGet(refSurfSel[i], &modelItem);
		ruleLog.Write("ProSelectionModelitemGet status: " + to_string(status));

		status = ProMdlMdlnameGet(modelItem.owner, wParentMdlName);
		ProWstringToString(cParentMdlName, wParentMdlName);
		ruleLog.Write("cParentMdlName = " + (string)cParentMdlName);

		ProModelitem partItem;
		status = ProMdlToModelitem(modelItem.owner, &partItem);
		ruleLog.Write("ProMdlToModelitem status: " + to_string(status));

		status = ProParameterInit(&partItem, pDescName, &pDesc);
		ruleLog.Write("ProParameterInit: " + to_string(status));

		if (status == PRO_TK_NO_ERROR)
		{
			status = ProParameterValueWithUnitsGet(&pDesc, &pvDesc, NULL);
			description.append(ProWstringToString(desc, pvDesc.value.s_val));
			ruleLog.Write("ProParameterValueWithUnitsGet status: " + to_string(status) + "\tdescription: " + description);
		}
		status = ProSelectionCopy(refSurfSel[i], &ownerDetails->at(i).selection);
		ruleLog.Write("ProSelectionCopy status: " + to_string(status));
		ownerDetails->at(i).id = modelItem.id;
		ruleLog.Write("id copied " + to_string(modelItem.id));
		strcpy(ownerDetails->at(i).name, cParentMdlName);
		ruleLog.Write("parent name copied " + string(cParentMdlName));
		strcpy(ownerDetails->at(i).descrp, description.c_str());
		ruleLog.Write("parent description copied " + description);
		ownerDetails->at(i).modelItem = modelItem;
		ownerDetails->at(i).asmCompPath = path;
		ruleLog.Write("modelitem and asmcomppath stored");
	}
	ruleLog.Write("description found: " + string(ownerDetails->at(ownerDetails->size() - 1).descrp));
	if (ownerDetails->size() == 2)
	{
		status = ProUIPushbuttonEnable(dialog, "pb_select_frame");
		status = ProUIOptionmenuEnable(dialog, "platform");
	}
	if (ownerDetails->size() == 1)
	{
		status = ProUIInputpanelEnable(dialog, "InputPanel_Rrf");
		status = ProUIInputpanelEnable(dialog, "InputPanel_Rrr");
		status = ProUIPushbuttonEnable(dialog, "Commit_Ok");
	}
	///*Using regex to verify if the selections are made from WHEEL DISC or LONG MEMBER 
	//If DISC is found then next select button will be enabled
	//If LONG is found then rest of the UI buttons will be enabled===================*/
	//const regex discKw("(DISC)");
	//const regex longKw("(LONG)");
	//smatch matchFound;
	//string tempDiscr;
	//tempDiscr.append(ownerDetails->at(ownerDetails->size() - 1).descrp);
	//if (regex_search(tempDiscr, matchFound,discKw));
	//{
	//	status = ProUIPushbuttonEnable(dialog, "pb_select_frame");
	//	status = ProUIOptionmenuEnable(dialog, "platform");
	//	
	//}
	//if (regex_search(tempDiscr, matchFound, longKw))
	//{
	//	status = ProUIInputpanelEnable(dialog, "InputPanel_Rrf");
	//	status = ProUIInputpanelEnable(dialog, "InputPanel_Rrr");
	//	status = ProUIPushbuttonEnable(dialog, "Commit_Ok");
	//}
	//tempDiscr.clear();
	int windowID;
	status = ProWindowCurrentGet(&windowID);
	status = ProWindowRefit(windowID);
	status = ProUIDialogShow(dialog);
	return PRO_TK_NO_ERROR;
}

ProError inputValue(char* dialog, char* component, vector<double>* offsetValVec)
{
	ruleLog.Write("----------------------------- inputValue -----------------------------");
	//cValue.clear();
	wchar_t* wOffsetValue[PRO_NAME_SIZE];
	char cOffSetVal[PRO_NAME_SIZE];
	double userInput, offSetValue;
	//status = ProUIPushbuttonDisable(dialog, PB_ROK);
	status = ProUIInputpanelValueGet(dialog, component, wOffsetValue);
	ruleLog.Write("PoUIInputpanelValueGet  status = " + to_string(status));
	ProWstringToString(cOffSetVal, wOffsetValue[0]);



	ruleLog.Write("check 1");
	//double A = stod(c_offsetValue);
	ruleLog.Write("check 2");
	string str(cOffSetVal);
	ruleLog.Write("Offset value in string: " + str);
	ruleLog.Write("Offset value in char: " + string(cOffSetVal));
	if (isDouble(str))
	{
		ruleLog.Write("Valid");
		userInput = abs(stod(cOffSetVal));
		ruleLog.Write("userInput: " + to_string(userInput));
		ruleLog.Write("check 3");
		offSetValue = userInput * -1;

		ruleLog.Write("offsetValue in double: " + to_string(offSetValue));
		offsetValVec->push_back(offSetValue);
	}
	status = ProUIPushbuttonEnable(dialog, "CommitOK");
	return PRO_TK_NO_ERROR;
}

bool isDouble(const string& str) {
	istringstream ss(str);
	double value;
	ss >> noskipws >> value;
	return ss.eof() && !ss.fail();
}

int findTheBiggestArcEdge(selectionInfo ownerDetails, edgeSel* edgeSelection)
{
	ruleLog.Write("============== findTheBiggestArcEdge ===============");

	ProFeature pFeat;

	status = ProGeomitemFeatureGet((ProGeomitem*)&ownerDetails.modelItem, &pFeat);
	ruleLog.Write("ProGeomitemFeatureGet status: " + to_string(status));
	vector<edgeSel> edgeDataVec;
	status = ProFeatureGeomitemVisit(&pFeat, PRO_EDGE, (ProGeomitemAction)edgeVisitAction, NULL, &edgeDataVec);
	ruleLog.Write("ProFeatureGeomitemVisit status : " + to_string(status));

	ruleLog.Write("size vectr: " + to_string(edgeDataVec.size()));

	sort(edgeDataVec.begin(), edgeDataVec.end(), [](const edgeSel& a, const edgeSel& b) {
		return a.dia > b.dia;
		});
	ruleLog.Write("sort check");

	//double dia = edgeDataVec[0].dia;
	for (int j = 0; j < edgeDataVec.size(); j++)
	{
		ruleLog.Write("Dia of edge: " + to_string(edgeDataVec[j].dia));
		ProModelitem item1;
		status = ProModelitemInit(ownerDetails.modelItem.owner, edgeDataVec[j].id, PRO_EDGE, &item1);
		ruleLog.Write("ProModelitemInit status: " + to_string(status));

		ProSelection sel1;
		status = ProSelectionAlloc(&ownerDetails.asmCompPath, &item1, &edgeDataVec[j].sel);
		ruleLog.Write("ProSelectionAlloc status: " + to_string(status));

	}

	ruleLog.Write("size of edgeDataVec: " + to_string(edgeDataVec.size()));

	status = ProSelectionCopy(edgeDataVec[2].sel, &edgeSelection->sel);
	ruleLog.Write("ProSelectionCopy status: " + to_string(status));

	edgeSelection->dia = edgeDataVec[2].dia;

	return 0;
}

ProError getVisiblePlaneNames(ProFeature* pFeat, ProError status, vector<string>* datumPlaneNames)
{
	ruleLog.Write("----------------------------- getReqPlane -----------------------------");
	/*vector<ComponentData>* planeData = (vector<ComponentData>*)appD;*/
	string planeNames;
	ProFeattype FeatType;
	ProMdl reqMdl, planeOwnerMdl;
	ProMdlType typeMdl;
	wchar_t wPlaneName[PRO_NAME_SIZE];
	char cPlaneName[PRO_NAME_SIZE];
	ProBoolean isVisible;
	char* cpyName;

	status = ProFeatureTypeGet(pFeat, &FeatType);
	ruleLog.Write("ProFeatureTypeGet status: " + to_string(status));

	if (FeatType == PRO_FEAT_DATUM)
	{
		status = ProFeatureVisibilityGet(pFeat, &isVisible);
		ruleLog.Write("ProFeatureVisibilityGet" + to_string(status));

		if (isVisible == PRO_B_TRUE)
		{
			status = ProModelitemNameGet((ProModelitem*)pFeat, wPlaneName);
			ruleLog.Write("ProModelitemNameGet" + to_string(status));

			ProWstringToString(cPlaneName, wPlaneName);
			ruleLog.Write("Name of the Plane is: " + (string)cPlaneName);
			planeNames.append(cPlaneName);
			datumPlaneNames->push_back(planeNames);

		}
	}
	planeNames.clear();

	return PRO_TK_NO_ERROR;
}

ProError edgeVisitAction(ProGeomitem* p_handle, ProError status, vector<edgeSel>* vectr)
{
	ruleLog.Write("================ edgeVisitAction ======================");
	ProEdge pEdge;
	ProEnttype typeEdge;
	int id;
	edgeSel object;
	double dia;
	ProGeomitemdata* dat1;
	ProBoolean inactive;
	object.gItem = *p_handle;
	status = ProGeomitemIsInactive(p_handle, &inactive);
	ruleLog.Write("ProGeomitemIsInactive status: " + to_string(status) + "\nIs it inactive? " + to_string(inactive));
	if (inactive != PRO_B_TRUE)
	{
		status = ProGeomitemToEdge(p_handle, &pEdge);
		ruleLog.Write("ProGeomitemToEdge status: " + to_string(status));

		status = ProEdgeTypeGet(pEdge, &typeEdge);
		ruleLog.Write("ProEdgeTypeGet status: " + to_string(status) + "\nedgetype: " + to_string(typeEdge));

		if (typeEdge == PRO_ENT_ARC)
		{
			status = ProEdgeIdGet(pEdge, &id);
			ruleLog.Write("ProEdgeIdGet status: " + to_string(status));
			object.id = id;


			//object.sel = sel1;
			//ProSelectionHighlight(sel1, PRO_COLOR_HIGHLITE);
			status = ProGeomitemdataGet(&object.gItem, &dat1);
			ruleLog.Write("ProGeomitemdataGet status: " + to_string(status));
			ruleLog.Write("dia of edge: " + to_string(dat1->data.p_curve_data->arc.radius * 2));
			object.dia = dat1->data.p_curve_data->arc.radius * 2;

			vectr->push_back(object);
			ruleLog.Write("vector check");
		}
	}
	return PRO_TK_NO_ERROR;
}

int selectionAllocByName(char cRefName[PRO_NAME_SIZE], ProType featType, ProSelection* featSel) {

	ruleLog.Write("================= selectionAllocByName ================");

	/*----------------------------------------------------------------------
	This function allocates a selection object of a point/plane/Csys
	Input Arguments -
	1)char cRefName[PRO_NAME_SIZE] = name of the point/plane to be selected
	2)ProType featType = Type of feature to be selected
		Use PRO_POINT for point
		PRO_SURFACE for Datum planes
		PRO_CSYS for Coordinate system
	Output -
	1)Selection object of the required feature
	-----------------------------------------------------------------------*/

	wchar_t wRefName[PRO_NAME_SIZE];
	ProModelitem modelItem;
	Utils util;

	//Initiate modelitem of ref pnt for selection alloc and convert that into reference
	ProStringToWstring(wRefName, cRefName);
	ruleLog.Write("cRefName: " + string(cRefName));

	status = ProModelitemByNameInit(curMdl, featType, wRefName, &modelItem);
	ruleLog.Write("ProModelitemByNameInit status: " + to_string(status));
	if (status != PRO_TK_NO_ERROR)
	{
		util.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Missing!", "required feature missing: " + string(cRefName) + ". Refer help document for details.");
		return -1;
	}

	status = ProSelectionAlloc(NULL, &modelItem, featSel);
	ruleLog.Write("ProSelectionAlloc status: " + to_string(status));
	/*status = ProSelectionHighlight(featSel, PRO_COLOR_HIGHLITE);
	ruleLog.Write("ProSelectionHighlight status: " + to_string(status));*/

	return 0;
}

int projectDatumPointOnPlane(ProSelection refPntSel, ProSelection refPlaneSel, char cPointName[PRO_NAME_SIZE])
{
	ruleLog.Write("========= projectDatumPointOnPlane =============");


	/*-------------------------------------------------------------------------------
	This function creates a point projected on a plane by taking another point as a reference

	Input arguments -
	1)ProSelection refPntSel = Selection object of the point that is to be projected.
	2)ProSelection refPlaneSel = A plane on which the selected point will be projected

	Output Argument -
	1)char cPointName[PRO_NAME_SIZE] = Name of the point created using references provided
	--------------------------------------------------------------------------------*/


	ProElement elem_tree, elem_ftype, pro_e_dpoint_type, pro_e_std_feature_name, pro_e_dpoint_points_array,
		pro_e_dpoint_point, pro_e_dpoint_point_name, pro_e_dpoint_pla_constraints, pro_e_dpoint_pla_constraint1, pro_e_dpoint_pla_constraint2,
		pro_e_dpoint_pla_constr_ref_point, pro_e_dpoint_pla_constr_ref_plane, pro_e_dpoint_pla_constr_type_proj, pro_e_dpoint_pla_constr_type_on;
	ProName arrayName;
	ProReference refPnt, refPlane;
	ProFeatureCreateOptions* opts = 0;
	ProFeature              feature;
	ProErrorlist            errors;
	wchar_t wRefPntName[PRO_NAME_SIZE], wRefPlaneName[PRO_NAME_SIZE];

	//convert point selection into a reference
	status = ProSelectionToReference(refPntSel, &refPnt);
	ruleLog.Write("ProSelectionToReference status: " + to_string(status));

	//convert plane selection into a reference
	status = ProSelectionToReference(refPlaneSel, &refPlane);
	ruleLog.Write("ProSelectionToReference status: " + to_string(status));

	//Allocate tree 
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	//Allocate feature type
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ruleLog.Write("ProElementAlloc status feature: = " + to_string(status));
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
	ruleLog.Write("ProElementIntegerSet status feature: = " + to_string(status));
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("ProElemtreeElementAdd status feature: = " + to_string(status));
	ruleLog.Write("feature allocation done");

	//PRO_E_DPOINT_TYPE (general)
	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
	ruleLog.Write("ProElementAlloc status feature type: = " + to_string(status));
	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_GENERAL);
	ruleLog.Write("ProElementIntegerSet status feature type: = " + to_string(status));
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
	ruleLog.Write("ProElemtreeElementAdd status feature type: = " + to_string(status));
	ruleLog.Write("datum point type allocation ");

	//Allocating element for feature name
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &pro_e_std_feature_name);
	ruleLog.Write("ProElementAlloc status feature name: = " + to_string(status));
	ProStringToWstring(arrayName, "MY_PNT0");
	status = ProElementWstringSet(pro_e_std_feature_name, arrayName);
	ruleLog.Write("ProElementWstringSet status feature name: = " + to_string(status));
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_std_feature_name);
	ruleLog.Write("ProElemtreeElementAdd status feature name: = " + to_string(status));

	//Allocate points array
	status = ProElementAlloc(PRO_E_DPOINT_POINTS_ARRAY, &pro_e_dpoint_points_array);
	ruleLog.Write("ProElementAlloc status array: = " + to_string(status));
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_points_array);
	ruleLog.Write("ProElemtreeElementAdd status array: = " + to_string(status));

	//Allocating point in the array
	status = ProElementAlloc(PRO_E_DPOINT_POINT, &pro_e_dpoint_point);
	ruleLog.Write("ProElementAlloc status point: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_points_array, NULL, pro_e_dpoint_point);
	ruleLog.Write("ProElemtreeElementAdd status point: = " + to_string(status));

	//Allocating name of the point
	status = ProElementAlloc(PRO_E_DPOINT_POINT_NAME, &pro_e_dpoint_point_name);
	ruleLog.Write("ProElementAlloc status point name: = " + to_string(status));
	wchar_t wPointName[PRO_NAME_SIZE];
	ProStringToWstring(wPointName, cPointName);
	status = ProElementWstringSet(pro_e_dpoint_point_name, wPointName);
	ruleLog.Write("ProElementWstringSet status point name: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_point, NULL, pro_e_dpoint_point_name);
	ruleLog.Write("ProElemtreeElementAdd status point name: = " + to_string(status));

	//Allocating placement constraints
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTRAINTS, &pro_e_dpoint_pla_constraints);
	ruleLog.Write("ProElementAlloc status constraints: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_point, NULL, pro_e_dpoint_pla_constraints);
	ruleLog.Write("ProElemtreeElementAdd status constratints: = " + to_string(status));

	//Allocating an element for a constraint 1 (PROJECT a point)
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTRAINT, &pro_e_dpoint_pla_constraint1);
	ruleLog.Write("ProElementAlloc status constraint: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_pla_constraints, NULL, pro_e_dpoint_pla_constraint1);
	ruleLog.Write("ProElemtreeElementAdd status constratint: = " + to_string(status));

	//Allocating a reference
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_REF, &pro_e_dpoint_pla_constr_ref_point);
	ruleLog.Write("ProElementAlloc status reference: = " + to_string(status));
	status = ProElementReferenceSet(pro_e_dpoint_pla_constr_ref_point, refPnt);
	ruleLog.Write("ProElementReferenceSet status: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_pla_constraint1, NULL, pro_e_dpoint_pla_constr_ref_point);
	ruleLog.Write("ProElemtreeElementAdd status reference: = " + to_string(status));

	//Allocating constraint type
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_TYPE, &pro_e_dpoint_pla_constr_type_proj);
	ruleLog.Write("ProElementAlloc status reference type: = " + to_string(status));
	status = ProElementIntegerSet(pro_e_dpoint_pla_constr_type_proj, PRO_DTMPNT_CONSTR_TYPE_PROJECT);
	ruleLog.Write("ProElementIntegerSet status reference type: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_pla_constraint1, NULL, pro_e_dpoint_pla_constr_type_proj);
	ruleLog.Write("ProElemtreeElementAdd status reference type: = " + to_string(status));

	//Allocating an element for a constraint 1 (ON a plane)
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTRAINT, &pro_e_dpoint_pla_constraint2);
	ruleLog.Write("ProElementAlloc status constraint: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_pla_constraints, NULL, pro_e_dpoint_pla_constraint2);
	ruleLog.Write("ProElemtreeElementAdd status constratint: = " + to_string(status));

	//Allocating a reference
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_REF, &pro_e_dpoint_pla_constr_ref_plane);
	ruleLog.Write("ProElementAlloc status reference: = " + to_string(status));
	status = ProElementReferenceSet(pro_e_dpoint_pla_constr_ref_plane, refPlane);
	ruleLog.Write("ProElementReferenceSet status: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_pla_constraint2, NULL, pro_e_dpoint_pla_constr_ref_plane);
	ruleLog.Write("ProElemtreeElementAdd status reference: = " + to_string(status));

	//Allocating constraint type
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_TYPE, &pro_e_dpoint_pla_constr_type_on);
	ruleLog.Write("ProElementAlloc status reference type: = " + to_string(status));
	status = ProElementIntegerSet(pro_e_dpoint_pla_constr_type_on, PRO_DTMPNT_CONSTR_TYPE_ON);
	ruleLog.Write("ProElementIntegerSet status reference type: = " + to_string(status));
	status = ProElemtreeElementAdd(pro_e_dpoint_pla_constraint2, NULL, pro_e_dpoint_pla_constr_type_on);
	ruleLog.Write("ProElemtreeElementAdd status reference type: = " + to_string(status));

	/*---------------------------------------------------------------*\
	Create the feature in the current model.
	\*---------------------------------------------------------------*/

	ProSelection curMdlSel;
	status = ProSelectionAlloc(NULL, &curMdlitem, &curMdlSel);
	ruleLog.Write("ProSelectionAlloc status featCreate: " + to_string(status));

	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
	ruleLog.Write("ProArrayAlloc status featCreate: " + to_string(status));

	opts[0] = PRO_FEAT_CR_DEFINE_MISS_ELEMS;

	status = ProFeatureWithoptionsCreate(curMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &feature, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status featCreate: " + to_string(status));
	status = ProArrayFree((ProArray*)&opts);
	ruleLog.Write("ProArrayFree status featCreate: " + to_string(status));
	status = ProElementFree(&elem_tree);
	ruleLog.Write("ProElementFree status featCreate: " + to_string(status));
	return 0;
}

int normalPlaneThru2Points(ProSelection& fCentrePnt, ProSelection& rCentrePnt, ProSelection& longMemberSurf, char outputPlaneName[PRO_NAME_SIZE])
{
	ruleLog.Write("=================== normalPlaneThru2Points =====================");

	/*--------------------------------------------------------------------------
	This function creates a plane passing through two points and normal/Perpendicular
	to a surface

	Input arguments -
	1)ProSelection& fCentrePnt  = selection Object of front centre point(Centre of front tyre)
	2)ProSelection& rCentrePnt = selection Object of rear centre point(Centre of front tyre)
	3)ProSelection& longMemberSurf = Manually selected surface from long member

	Output -
	1)char outputPlaneName[PRO_NAME_SIZE] = Name of the plane being created
	----------------------------------------------------------------------------*/
	ProModelitem refPlaneitem;
	ProSelection refPlaneSel;
	wchar_t wRefPlaneName[PRO_NAME_SIZE], wOutputPlaneName[PRO_NAME_SIZE];
	ProElement	elem_tree, elem_ftype, elem_consts, elem_const_type1, elem_thru, elem_const_type2, elem_thru_ref, elem_feature_name;
	ProReference REPDEP_ref1, REPDEP_ref2;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pln_feat;
	ProErrorlist errors;

	//ProStringToWstring(wRefPlaneName, refPlaneName);
	//status = ProModelitemByNameInit(refPlaneOwner, PRO_SURFACE, wRefPlaneName, &refPlaneitem);
	//status = ProSelectionAlloc(NULL, &refPlaneitem, &refPlaneSel);


	/* =============================================================== *\
	Create Element Tree
	\* =============================================================== */

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	// FEATURE NAME
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wOutputPlaneName, outputPlaneName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);

	// CONSTRAINTS ALLOCATION
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINTS, &elem_consts);
	ProElemtreeElementAdd(elem_tree, NULL, elem_consts);
	ruleLog.Write("constraints status = " + to_string(status));

	// Constraint 1
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_thru);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_thru);
	ruleLog.Write("1st constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type1);
	ProElementIntegerSet(elem_const_type1, PRO_DTMPLN_THRU);
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_const_type1);
	ruleLog.Write("1st constraint type status = " + to_string(status));

	//constraint reference 1
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_thru_ref);
	status = ProSelectionToReference(fCentrePnt, &REPDEP_ref1);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	status = ProElementReferenceSet(elem_thru_ref, REPDEP_ref1);
	ruleLog.Write("ProElementReferenceSet = " + to_string(status));
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_thru_ref);
	ruleLog.Write("1st constraint reference status = " + to_string(status));

	// Constraint 2
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_thru);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_thru);
	ruleLog.Write("2nd constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type2);
	ProElementIntegerSet(elem_const_type2, PRO_DTMPLN_THRU);
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_const_type2);
	ruleLog.Write("2nd constraint type status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_thru_ref);
	status = ProSelectionToReference(rCentrePnt, &REPDEP_ref2);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	ProElementReferenceSet(elem_thru_ref, REPDEP_ref2);
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_thru_ref);
	ruleLog.Write("2nd constraint reference status = " + to_string(status));

	// Constraint 3
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_thru);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_thru);
	ruleLog.Write("2nd constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type2);
	ProElementIntegerSet(elem_const_type2, PRO_DTMPLN_NORM);
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_const_type2);
	ruleLog.Write("2nd constraint type status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_thru_ref);
	status = ProSelectionToReference(longMemberSurf, &REPDEP_ref2);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	ProElementReferenceSet(elem_thru_ref, REPDEP_ref2);
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_thru_ref);
	ruleLog.Write("2nd constraint reference status = " + to_string(status));

	/*---------------------------------------------------------------*\
	Create the feature in the current model.
	\*---------------------------------------------------------------*/

	ProSelection curMdlSel;
	status = ProSelectionAlloc(NULL, &curMdlitem, &curMdlSel);
	ruleLog.Write("ProSelectionAlloc status featCreate: " + to_string(status));

	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
	ruleLog.Write("ProArrayAlloc status = " + to_string(status));
	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Plane
	status = ProFeatureWithoptionsCreate(curMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pln_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	if (status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Refer help document for details.");
	}

	status = ProArrayFree((ProArray*)&opts);
	ruleLog.Write("ProArrayFree status = " + to_string(status));
	status = ProElementFree(&elem_tree);
	ruleLog.Write("ProElementFree status = " + to_string(status));
	/*status = ProSelectionFree(&curMdlSel);
	ruleLog.Write("ProSelectionFree status = " + to_string(status));*/

	return 0;
}

int createOffsetPlaneWithReference(ProSelection refSelection, double offsetValue, char* outputPlaneName)
{
	/*ProModelitem refPlaneitem;
	ProSelection refPlaneSel;*/
	wchar_t wRefPlaneName[PRO_NAME_SIZE], wOutputPlaneName[PRO_NAME_SIZE];
	ProElement	elem_tree, elem_ftype, elem_consts, elem_prl, elem_const_type1, elem_const_type2, elem_along, elem_offset, elem_offset_ref, elem_feature_name, elem_offset_create;
	ProReference REPDEP_ref1, REPDEP_ref2;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pln_feat;
	ProErrorlist errors;
	ruleLog.Write("Offset value = " + to_string(offsetValue));

	/* =============================================================== *\
	Create Element Tree
	\* =============================================================== */
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	// FEATURE NAME
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wOutputPlaneName, outputPlaneName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);

	// CONSTRAINTS ALLOCATION
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINTS, &elem_consts);
	ProElemtreeElementAdd(elem_tree, NULL, elem_consts);
	ruleLog.Write("constraints status = " + to_string(status));

	// Constraint 1
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_offset);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_offset);
	ruleLog.Write("1st constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type1);
	ProElementIntegerSet(elem_const_type1, PRO_DTMPLN_OFFS);
	status = ProElemtreeElementAdd(elem_offset, NULL, elem_const_type1);
	ruleLog.Write("1st constraint type status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_offset_ref);
	status = ProSelectionToReference(refSelection, &REPDEP_ref1);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	status = ProElementReferenceSet(elem_offset_ref, REPDEP_ref1);
	ruleLog.Write("ProElementReferenceSet = " + to_string(status));
	status = ProElemtreeElementAdd(elem_offset, NULL, elem_offset_ref);
	ruleLog.Write("1st constraint reference status = " + to_string(status));



	/* =============================================================== *\
		Allocate ref offset value element; add under constraint element.
	\* =============================================================== */
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF_OFFSET, &elem_offset_create);
	ProElementDecimalsSet(elem_offset_create, 4);
	ProElementDoubleSet(elem_offset_create, offsetValue);

	status = ProElemtreeElementAdd(elem_offset, NULL, elem_offset_create);


	/*---------------------------------------------------------------*\
	Create the feature in the current model.
	\*---------------------------------------------------------------*/

	ProSelection curMdlSel;
	status = ProSelectionAlloc(NULL, &curMdlitem, &curMdlSel);
	ruleLog.Write("ProSelectionAlloc status featCreate: " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Plane
	status = ProFeatureWithoptionsCreate(curMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pln_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	ruleLog.Write("ProArrayFree status = " + to_string(status));
	status = ProElementFree(&elem_tree);
	ruleLog.Write("ProElementFree status = " + to_string(status));


	return 0;
}

int createCsysOffsDatumPoint(ProSelection csysSel, Pro3dPnt pnt_arr[2], char pointName[PRO_NAME_SIZE])
{
	ruleLog.Write("=================> InterfaceRule::createDatumPoints <=================");
	ProElement	elem_tree, elem_ftype, elem_feature_name,
		pro_e_dpoint_type, pro_e_dpoint_ofst_csys_type, pro_e_dpoint_ofst_csys_ref, pro_e_dpoint_ofst_csys_with_dims, pro_e_dpoint_ofst_csys_pnts_array, pro_e_dpoint_ofst_csys_pnt_1, pro_e_dpoint_ofst_csys_pnt_2,
		pro_e_dpoint_ofst_csys_pnt_name_1, pro_e_dpoint_ofst_csys_pnt_name_2, pro_e_dpoint_ofst_csys_dir1_val_1, pro_e_dpoint_ofst_csys_dir2_val_1, pro_e_dpoint_ofst_csys_dir3_val_1,
		pro_e_dpoint_ofst_csys_dir1_val_2, pro_e_dpoint_ofst_csys_dir2_val_2, pro_e_dpoint_ofst_csys_dir3_val_2;
	ProReference REPDEP_ref1;
	wchar_t myPnt1Name[PRO_NAME_SIZE], myPnt2Name[PRO_NAME_SIZE], wDatumPointName[PRO_NAME_SIZE];
	ProModelitem refCsysitem;

	ProFeatureCreateOptions* opts = 0;
	ProFeature pnt_feat;
	ProErrorlist errors;

	//converting negative values to positive
	double d1 = pnt_arr[0][1];
	double d2 = pnt_arr[1][1];


	// TREE ROOT ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	//Allocate element for feature type
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM_POINT);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	//Allocate element for defining DPOINT_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &pro_e_dpoint_type);
	status = ProElementIntegerSet(pro_e_dpoint_type, PRO_DPOINT_TYPE_OFFSET_CSYS);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_type);
	ruleLog.Write("type status = " + to_string(status));

	//Allocate an element for choosing type of point Cartesian/Cylindrical/Spherical
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_TYPE, &pro_e_dpoint_ofst_csys_type);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_type, PRO_DTMPNT_OFFCSYS_CARTESIAN);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_type);

	//Allocate an element for feature name
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wDatumPointName, pointName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);
	ruleLog.Write("feature name = " + to_string(status));

	//Allocating refernce for contraints 
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_REF, &pro_e_dpoint_ofst_csys_ref);
	status = ProSelectionToReference(csysSel, &REPDEP_ref1);
	status = ProElementReferenceSet(pro_e_dpoint_ofst_csys_ref, REPDEP_ref1);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_ref);

	//Allocate an element for checking the box as true for dimensions 
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_WITH_DIMS, &pro_e_dpoint_ofst_csys_with_dims);
	status = ProElementIntegerSet(pro_e_dpoint_ofst_csys_with_dims, PRO_B_TRUE);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_with_dims);

	//Allocate an element for points array 
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNTS_ARRAY, &pro_e_dpoint_ofst_csys_pnts_array);
	status = ProElemtreeElementAdd(elem_tree, NULL, pro_e_dpoint_ofst_csys_pnts_array);

	//Allocate an element inside points array for Point1
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_1);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_1);

	//Point1 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_1);
	ProStringToWstring(myPnt1Name, "MY_PNT1");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_1, myPnt1Name);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_pnt_name_1);

	//Point 1 X - coordinate
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_1, pnt_arr[0][0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir1_val_1);

	//Point 1 Z - coordinate
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_1, -pnt_arr[0][2]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir2_val_1);

	//Point 1 Y - coordinate
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_1);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_1, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_1, pnt_arr[1][1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_1, NULL, pro_e_dpoint_ofst_csys_dir3_val_1);

	//Allocate an element inside points array for Point2
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT, &pro_e_dpoint_ofst_csys_pnt_2);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnts_array, NULL, pro_e_dpoint_ofst_csys_pnt_2);

	//Point2 Name
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_PNT_NAME, &pro_e_dpoint_ofst_csys_pnt_name_2);
	ProStringToWstring(myPnt2Name, "MY_PNT2");
	status = ProElementWstringSet(pro_e_dpoint_ofst_csys_pnt_name_2, myPnt2Name);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_pnt_name_2);

	//Point 2 X - coordinate
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR1_VAL, &pro_e_dpoint_ofst_csys_dir1_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir1_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir1_val_2, pnt_arr[0][0]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir1_val_2);

	//Point 2 Z - coordinate
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR2_VAL, &pro_e_dpoint_ofst_csys_dir2_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir2_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir2_val_2, -pnt_arr[1][2]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir2_val_2);

	//Point 2 Y - coordinate
	status = ProElementAlloc(PRO_E_DPOINT_OFST_CSYS_DIR3_VAL, &pro_e_dpoint_ofst_csys_dir3_val_2);
	status = ProElementDecimalsSet(pro_e_dpoint_ofst_csys_dir3_val_2, 4);
	status = ProElementDoubleSet(pro_e_dpoint_ofst_csys_dir3_val_2, pnt_arr[0][1]);
	status = ProElemtreeElementAdd(pro_e_dpoint_ofst_csys_pnt_2, NULL, pro_e_dpoint_ofst_csys_dir3_val_2);

	/*Allocate selection of current MDL (TOP Assembly)*/
	ProSelection curMdlSelection;
	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &curMdlSelection);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Points
	status = ProFeatureWithoptionsCreate(curMdlSelection, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pnt_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	status = ProElementFree(&elem_tree);
	status = ProSelectionFree(&curMdlSelection);

	ProSelection pnt_Sel;
	status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
	status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_ERROR);
	//PRO_COLOR_SELECTED for green highlight
	ruleLog.Write("==================function end=================");
	return 0;
}

int measureDistanceBetweenPlaneAndComp(ProSelection planeSel, ComponentData reqComp1, double& distance, Pro3dPnt pntArr[2])
{
	ruleLog.Write("=================> InterfaceRule::measureDistanceBetweenPlaneAndComp <=================");

	//ProSelection planeSel;
	ProMdl reqMdl;
	char cReqMdlPath[PRO_PATH_SIZE];
	ProPath wReqMdlPath;
	ProModelitem planeMdlitem;
	wchar_t wPlaneName[PRO_NAME_SIZE];
	Utils util;


	ProSelection sels[1];
	ProIdTable idtbl1 = { reqComp1.id };		// component id of the component 1 to be selected

	ProName comp1_name;
	ProModelitem feature[1];
	ProMdl reqMdls[1];

	ProStringToWstring(comp1_name, reqComp1.name);
	status = ProMdlnameInit(comp1_name, PRO_MDLFILE_ASSEMBLY, &reqMdls[0]);
	ruleLog.Write("ProMdlnameInit: " + to_string(status));
	status = ProMdlToModelitem(reqMdls[0], &feature[0]);

	ProAsmcomppath path[1];
	status = ProAsmcomppathInit((ProSolid)curMdl, idtbl1, 1, &path[0]);
	ruleLog.Write("ProAsmcomppathInit: " + to_string(status));


	status = ProSelectionAlloc(&path[0], &feature[0], &sels[0]);
	ruleLog.Write("ProSelectionAlloc: " + to_string(status));

	Pro2dPnt param_1, param_2;

	status = ProSelectionWithOptionsDistanceEval(planeSel, PRO_B_FALSE, sels[0], PRO_B_FALSE, param_1, param_2, pntArr[0], pntArr[1], &distance);
	ruleLog.Write("ProSelectionWithOptionsDistanceEval: " + to_string(status) + "\tdistance: " + to_string(distance));
	if (status == PRO_TK_BAD_INPUTS || status == PRO_TK_BAD_CONTEXT) {
		util.UserDisplayPopupMessageOK(PROUIMESSAGE_ERROR, "Error", "There is a problem with measuring the distance between selections.");
		return -1;
	}

	ruleLog.Write("Coordinates of point 1: \nX-Coord - " + to_string(pntArr[0][0]) + "\tY-Coord - " +
		to_string(pntArr[0][1]) + "\tZ-Coord - " + to_string(pntArr[0][2]));
	ruleLog.Write("Coordinates of point 2: \nX-Coord - " + to_string(pntArr[1][0]) + "\tY-Coord - " +
		to_string(pntArr[1][1]) + "\tZ-Coord - " + to_string(pntArr[1][2]));

	return 0;
}

double depatureAngleCalc(double XD, double YD, double rr)
{
	//double XD, YD, rr;

	// Calculate the expression inside the square root
	double expression_inside_sqrt = XD * XD;
	ruleLog.Write("x^2 : " + to_string(expression_inside_sqrt));
	double rr_yd = std::pow(rr - YD, 2);
	ruleLog.Write("rr-yd : " + to_string(rr_yd));
	// Calculate the square root
	double sqrt_result = std::sqrt(expression_inside_sqrt + rr_yd);
	ruleLog.Write("sqrt_result(x^2 +(rr-yd): " + to_string(sqrt_result));

	// Calculate the inverse sine
	double asin_result = std::asin(rr / sqrt_result);
	ruleLog.Write("inverse sine: " + to_string(asin_result));

	// Calculate the inverse tangent
	double atan_result = std::atan((rr - YD) / XD);
	ruleLog.Write("inverse tangent: " + to_string(atan_result));

	// Calculate the final result (D)
	double D = asin_result - atan_result;
	ruleLog.Write("Depature Angle (in radians): " + to_string(D));

	// Convert D from radians to degrees
	double D_degrees = D * 180.0 / M_PI;
	double rou_deg = round(D_degrees);
	ruleLog.Write("Depature Angle (in degrees): " + to_string(rou_deg));

	return rou_deg;

}

double rampOverAngleCalc(double Xrf, double Yr, double rf, double rR, double XrR)
{
	ruleLog.Write("=============== depatureAngle ================");

	// Calculate the expression inside the first square root
	double expression1_inside_sqrt = Xrf * Xrf + std::pow(rf - Yr, 2);

	// Calculate the first square root
	double sqrt1_result = std::sqrt(expression1_inside_sqrt);

	// Calculate the inverse sine of the first term
	double asin1_result = std::asin(rf / sqrt1_result);

	// Calculate the inverse tangent of the second term
	double atan1_result = std::atan((rf - Yr) / Xrf);

	// Calculate the expression inside the second square root
	double expression2_inside_sqrt = XrR * XrR + std::pow(rR - Yr, 2);

	// Calculate the second square root
	double sqrt2_result = std::sqrt(expression2_inside_sqrt);

	// Calculate the inverse sine of the third term
	double asin2_result = std::asin(rR / sqrt2_result);

	// Calculate the inverse tangent of the fourth term
	double atan2_result = std::atan((rR - Yr) / Xrf);

	// Calculate the final result (R)
	double R = asin1_result - atan1_result + asin2_result - atan2_result;

	// Convert R from radians to degrees
	double R_degrees = R * 180.0 / M_PI;

	std::cout << "R (in degrees): " << R_degrees << std::endl;


	return round(R_degrees);
}

int createGenDPntAtOffsDist(ProSelection pntSel, ProSelection csysSel, double offsDist[3], char pointName[PRO_NAME_SIZE])
{
	ruleLog.Write("=================> createGenDPntAtOffsDist <=================");
	ProElement elemTree, featType, datPointType, featName, datPointsArray, datPoint,
		datPointName, placementConstraints, constraint1, constraint1Ref, constraint1Type,
		constraint2, constraint2Ref, constraint2Type, dimensionConstraints, dimensionConstraint1,
		dimensionConstraint1Ref, dimensionConstraint1Type, dimensionConstVal1, dimensionConstraint2,
		dimensionConstraint2Ref, dimensionConstraint2Type, dimensionConstVal2, dimensionConstraint3,
		dimensionConstraint3Ref, dimensionConstraint3Type, dimensionConstVal3;

	wchar_t wDatumPointName[PRO_NAME_SIZE], myPnt1Name[PRO_NAME_SIZE];
	ProReference ref1, ref2;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pntFeat;
	ProErrorlist errors;

	// TREE ROOT ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elemTree);
	ruleLog.Write("Tree root status = " + to_string(status));

	//Allocate element for feature type
	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &featType);
	ProElementIntegerSet(featType, PRO_FEAT_DATUM_POINT);
	ProElemtreeElementAdd(elemTree, NULL, featType);
	ruleLog.Write("feature type status = " + to_string(status));

	//Allocate element for defining DPOINT_TYPE
	status = ProElementAlloc(PRO_E_DPOINT_TYPE, &datPointType);
	status = ProElementIntegerSet(datPointType, PRO_DPOINT_TYPE_GENERAL);
	status = ProElemtreeElementAdd(elemTree, NULL, datPointType);
	ruleLog.Write("type status = " + to_string(status));

	//Allocate an element for feature name
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &featName);
	status = ProElementWstringSet(featName, ProStringToWstring(myPnt1Name, "MY_PNT1"));
	status = ProElemtreeElementAdd(elemTree, NULL, featName);
	ruleLog.Write("feature name = " + to_string(status));

	//Allocate an element for points array 
	status = ProElementAlloc(PRO_E_DPOINT_POINTS_ARRAY, &datPointsArray);
	status = ProElemtreeElementAdd(elemTree, NULL, datPointsArray);
	ruleLog.Write("Points array = " + to_string(status));

	//Allocate an element inside points array for Point
	status = ProElementAlloc(PRO_E_DPOINT_POINT, &datPoint);
	status = ProElemtreeElementAdd(datPointsArray, NULL, datPoint);
	ruleLog.Write("point inside Points array = " + to_string(status));

	//Point Name
	status = ProElementAlloc(PRO_E_DPOINT_POINT_NAME, &datPointName);
	status = ProElementWstringSet(datPointName, ProStringToWstring(wDatumPointName, pointName));
	status = ProElemtreeElementAdd(datPoint, NULL, datPointName);
	ruleLog.Write("Set point name = " + to_string(status));

	//Allocating placement contraints array  
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTRAINTS, &placementConstraints);
	status = ProElemtreeElementAdd(datPoint, NULL, placementConstraints);
	ruleLog.Write("placement contraints array = " + to_string(status));

	//Allocating contraint1  
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTRAINT, &constraint1);
	status = ProElemtreeElementAdd(placementConstraints, NULL, constraint1);
	ruleLog.Write("contraint1 inside placement contraints array = " + to_string(status));

	//Allocating contraint1 reference  
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_REF, &constraint1Ref);
	status = ProSelectionToReference(pntSel, &ref1);
	status = ProElementReferenceSet(constraint1Ref, ref1);
	ruleLog.Write("ProElementReferenceSet status: = " + to_string(status));
	status = ProElemtreeElementAdd(constraint1, NULL, constraint1Ref);
	ruleLog.Write("contraint1 reference = " + to_string(status));

	//Allocating contraint1 reference type  
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_TYPE, &constraint1Type);
	status = ProElementIntegerSet(constraint1Type, PRO_DTMPNT_CONSTR_TYPE_OFFSET);
	status = ProElemtreeElementAdd(constraint1, NULL, constraint1Type);
	ruleLog.Write("contraint1 reference type= " + to_string(status));

	//Allocating contraint2 
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTRAINT, &constraint2);
	status = ProElemtreeElementAdd(placementConstraints, NULL, constraint2);
	ruleLog.Write("contraint2 inside array= " + to_string(status));

	//Allocating contraint2 reference  
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_REF, &constraint2Ref);
	status = ProSelectionToReference(csysSel, &ref2);
	status = ProElementReferenceSet(constraint2Ref, ref2);
	ruleLog.Write("ProElementReferenceSet status: = " + to_string(status));
	status = ProElemtreeElementAdd(constraint2, NULL, constraint2Ref);
	ruleLog.Write("contraint2 reference:  " + to_string(status));

	//Allocating contraint2 reference type  
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_TYPE, &constraint2Type);
	status = ProElementIntegerSet(constraint2Type, PRO_DTMPNT_CONSTR_TYPE_CARTESIAN);
	status = ProElemtreeElementAdd(constraint2, NULL, constraint2Type);
	ruleLog.Write("contraint2 reference type:  " + to_string(status));

	//Allocating dimension contraints array  
	status = ProElementAlloc(PRO_E_DPOINT_DIM_CONSTRAINTS, &dimensionConstraints);
	status = ProElemtreeElementAdd(datPoint, NULL, dimensionConstraints);
	ruleLog.Write("dimension contraints array:  " + to_string(status));

	//Allocating dimension contraint1  
	status = ProElementAlloc(PRO_E_DPOINT_DIM_CONSTRAINT, &dimensionConstraint1);
	status = ProElemtreeElementAdd(dimensionConstraints, NULL, dimensionConstraint1);
	ruleLog.Write("dimension contraint1 inside contraints array:  " + to_string(status));

	//Allocating dimension contraint1 reference  
	status = ProElementAlloc(PRO_E_DPOINT_DIM_CONSTR_REF, &dimensionConstraint1Ref);
	//ProSelectionToReference
	status = ProElemtreeElementAdd(dimensionConstraint1, NULL, dimensionConstraint1Ref);
	ruleLog.Write("dimension contraint1 reference:  " + to_string(status));

	//Allocating dimension contraint1 reference type  
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_TYPE, &dimensionConstraint1Type);
	status = ProElementIntegerSet(dimensionConstraint1Type, PRO_DTMPNT_CONSTR_TYPE_ALONG_X);
	status = ProElemtreeElementAdd(dimensionConstraint1, NULL, dimensionConstraint1Type);
	ruleLog.Write("dimension contraint1 reference type:  " + to_string(status));

	//Allocating dimension contraint1 reference value  
	status = ProElementAlloc(PRO_E_DPOINT_DIM_CONSTR_VAL, &dimensionConstVal1);
	status = ProElementDecimalsSet(dimensionConstVal1, 4);
	status = ProElementDoubleSet(dimensionConstVal1, offsDist[0]);
	//status = ProElementIntegerSet(dimensionConstVal1, offsDist[0]);
	status = ProElemtreeElementAdd(dimensionConstraint1, NULL, dimensionConstVal1);
	ruleLog.Write("dimension contraint1 reference value:  " + to_string(status));

	//Allocating dimension contraint2 
	status = ProElementAlloc(PRO_E_DPOINT_DIM_CONSTRAINT, &dimensionConstraint2);
	status = ProElemtreeElementAdd(dimensionConstraints, NULL, dimensionConstraint2);
	ruleLog.Write("dimension contraint2 inside contraints array:  " + to_string(status));

	//Allocating dimension contraint2 reference  
	status = ProElementAlloc(PRO_E_DPOINT_DIM_CONSTR_REF, &dimensionConstraint2Ref);
	//ProSelectionToReference
	status = ProElemtreeElementAdd(dimensionConstraint2, NULL, dimensionConstraint2Ref);
	ruleLog.Write("dimension contraint2 reference:  " + to_string(status));

	//Allocating dimension contraint2 reference type  
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_TYPE, &dimensionConstraint2Type);
	status = ProElementIntegerSet(dimensionConstraint2Type, PRO_DTMPNT_CONSTR_TYPE_ALONG_Y);
	status = ProElemtreeElementAdd(dimensionConstraint2, NULL, dimensionConstraint2Type);
	ruleLog.Write("dimension contraint2 reference type:  " + to_string(status));

	//Allocating dimension contraint2 reference value  
	status = ProElementAlloc(PRO_E_DPOINT_DIM_CONSTR_VAL, &dimensionConstVal2);
	status = ProElementDecimalsSet(dimensionConstVal2, 4);
	status = ProElementDoubleSet(dimensionConstVal2, offsDist[1]);
	//status = ProElementIntegerSet(dimensionConstVal1, offsDist[0]);
	status = ProElemtreeElementAdd(dimensionConstraint2, NULL, dimensionConstVal2);
	ruleLog.Write("dimension contraint2 reference value:  " + to_string(status));

	//Allocating dimension contraint3 
	status = ProElementAlloc(PRO_E_DPOINT_DIM_CONSTRAINT, &dimensionConstraint3);
	status = ProElemtreeElementAdd(dimensionConstraints, NULL, dimensionConstraint3);
	ruleLog.Write("dimension contraint3 inside contraints array:  " + to_string(status));

	//Allocating dimension contraint3 reference  
	status = ProElementAlloc(PRO_E_DPOINT_DIM_CONSTR_REF, &dimensionConstraint3Ref);
	//ProSelectionToReference
	status = ProElemtreeElementAdd(dimensionConstraint3, NULL, dimensionConstraint3Ref);
	ruleLog.Write("dimension contraint3 reference:  " + to_string(status));

	//Allocating dimension contraint3 reference type  
	status = ProElementAlloc(PRO_E_DPOINT_PLA_CONSTR_TYPE, &dimensionConstraint3Type);
	status = ProElementIntegerSet(dimensionConstraint3Type, PRO_DTMPNT_CONSTR_TYPE_ALONG_Z);
	status = ProElemtreeElementAdd(dimensionConstraint3, NULL, dimensionConstraint3Type);
	ruleLog.Write("dimension contraint2 reference type:  " + to_string(status));

	//Allocating dimension contraint3 reference value  
	status = ProElementAlloc(PRO_E_DPOINT_DIM_CONSTR_VAL, &dimensionConstVal3);
	status = ProElementDecimalsSet(dimensionConstVal3, 4);
	status = ProElementDoubleSet(dimensionConstVal3, offsDist[2]);
	//status = ProElementIntegerSet(dimensionConstVal1, offsDist[0]);
	status = ProElemtreeElementAdd(dimensionConstraint3, NULL, dimensionConstVal3);
	ruleLog.Write("dimension contraint3 reference value:  " + to_string(status));

	/*Allocate selection of current MDL (TOP Assembly)*/
	ProSelection curMdlSelection;
	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &curMdlSelection);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);

	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Points
	status = ProFeatureWithoptionsCreate(curMdlSelection, elemTree, opts, PRO_REGEN_NO_FLAGS, &pntFeat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	status = ProArrayFree((ProArray*)&opts);
	status = ProElementFree(&elemTree);
	status = ProSelectionFree(&curMdlSelection);

	/*ProSelection pnt_Sel;
	status = ProSelectionAlloc(NULL, &pnt_feat, &pnt_Sel);
	status = ProSelectionHighlight(pnt_Sel, PRO_COLOR_HIGHLITE);*/
	//PRO_COLOR_SELECTED for green highlight
	ruleLog.Write("==================function end=================");
	return 0;
}

int threePointPlaneCreate(ProSelection& sel_1, ProSelection& sel_2, ProSelection& sel_3, char* outputPlaneName)
{
	ProModelitem refPlaneitem;
	ProSelection reqMdlSel, refPlaneSel;
	wchar_t wRefPlaneName[PRO_NAME_SIZE], wOutputPlaneName[PRO_NAME_SIZE];
	ProElement	elem_tree, elem_ftype, elem_consts, elem_const_type1, elem_thru, elem_const_type2, elem_thru_ref, elem_feature_name;
	ProReference REPDEP_ref1, REPDEP_ref2;
	ProFeatureCreateOptions* opts = 0;
	ProFeature pln_feat;
	ProErrorlist errors;

	//ProStringToWstring(wRefPlaneName, refPlaneName);
	//status = ProModelitemByNameInit(refPlaneOwner, PRO_SURFACE, wRefPlaneName, &refPlaneitem);
	//status = ProSelectionAlloc(NULL, &refPlaneitem, &refPlaneSel);


	/* =============================================================== *\
	Create Element Tree
	\* =============================================================== */

	// TREE ALLOCATION
	status = ProElementAlloc(PRO_E_FEATURE_TREE, &elem_tree);
	ruleLog.Write("Tree root status = " + to_string(status));

	status = ProElementAlloc(PRO_E_FEATURE_TYPE, &elem_ftype);
	ProElementIntegerSet(elem_ftype, PRO_FEAT_DATUM);
	ProElemtreeElementAdd(elem_tree, NULL, elem_ftype);
	ruleLog.Write("type status = " + to_string(status));

	// FEATURE NAME
	status = ProElementAlloc(PRO_E_STD_FEATURE_NAME, &elem_feature_name);
	status = ProElementWstringSet(elem_feature_name, ProStringToWstring(wOutputPlaneName, outputPlaneName));
	status = ProElemtreeElementAdd(elem_tree, NULL, elem_feature_name);

	// CONSTRAINTS ALLOCATION
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINTS, &elem_consts);
	ProElemtreeElementAdd(elem_tree, NULL, elem_consts);
	ruleLog.Write("constraints status = " + to_string(status));

	// Constraint 1
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_thru);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_thru);
	ruleLog.Write("1st constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type1);
	ProElementIntegerSet(elem_const_type1, PRO_DTMPLN_THRU);
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_const_type1);
	ruleLog.Write("1st constraint type status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_thru_ref);
	status = ProSelectionToReference(sel_1, &REPDEP_ref1);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	status = ProElementReferenceSet(elem_thru_ref, REPDEP_ref1);
	ruleLog.Write("ProElementReferenceSet = " + to_string(status));
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_thru_ref);
	ruleLog.Write("1st constraint reference status = " + to_string(status));


	// Constraint 2
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_thru);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_thru);
	ruleLog.Write("2nd constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type2);
	ProElementIntegerSet(elem_const_type2, PRO_DTMPLN_THRU);
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_const_type2);
	ruleLog.Write("2nd constraint type status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_thru_ref);
	status = ProSelectionToReference(sel_2, &REPDEP_ref2);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	ProElementReferenceSet(elem_thru_ref, REPDEP_ref2);
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_thru_ref);
	ruleLog.Write("2nd constraint reference status = " + to_string(status));

	// Constraint 3
	status = ProElementAlloc(PRO_E_DTMPLN_CONSTRAINT, &elem_thru);
	status = ProElemtreeElementAdd(elem_consts, NULL, elem_thru);
	ruleLog.Write("2nd constraint status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_TYPE, &elem_const_type2);
	ProElementIntegerSet(elem_const_type2, PRO_DTMPLN_THRU);
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_const_type2);
	ruleLog.Write("2nd constraint type status = " + to_string(status));

	status = ProElementAlloc(PRO_E_DTMPLN_CONSTR_REF, &elem_thru_ref);
	status = ProSelectionToReference(sel_3, &REPDEP_ref2);
	ruleLog.Write("ProSelectionToReference = " + to_string(status));
	ProElementReferenceSet(elem_thru_ref, REPDEP_ref2);
	status = ProElemtreeElementAdd(elem_thru, NULL, elem_thru_ref);
	ruleLog.Write("2nd constraint reference status = " + to_string(status));



	/* =============================================================== *\
	Create Model Selection Object
	\* =============================================================== */
	status = ProSelectionAlloc(&curAsmCompPath, &curMdlitem, &reqMdlSel);
	ruleLog.Write("ProSelectionAlloc status = " + to_string(status));
	status = ProArrayAlloc(1, sizeof(ProFeatureCreateOptions), 1, (ProArray*)&opts);
	ruleLog.Write("ProArrayAlloc status = " + to_string(status));


	opts[0] = PRO_FEAT_CR_NO_OPTS;

	// Create Plane
	status = ProFeatureWithoptionsCreate(reqMdlSel, elem_tree, opts, PRO_REGEN_NO_FLAGS, &pln_feat, &errors);
	ruleLog.Write("ProFeatureWithoptionsCreate status = " + to_string(status));

	if (status != PRO_TK_NO_ERROR) {
		_utils.UserDisplayPopupMessageOK(PROUIMESSAGE_WARNING, "Invalid Inputs", "Refer help document for details.");
	}

	status = ProArrayFree((ProArray*)&opts);
	ruleLog.Write("ProArrayFree status = " + to_string(status));
	status = ProElementFree(&elem_tree);
	ruleLog.Write("ProElementFree status = " + to_string(status));
	status = ProSelectionFree(&reqMdlSel);
	ruleLog.Write("ProSelectionFree status = " + to_string(status));



	return 0;
}

ProError radioGrpSelectAction(char* dialog, char* component, bool* booleanVal)
{
	ruleLog.Write("============== radioGrpSelectAction ==============");
	int radioGrpNames[2];
	char** buttonNames;
	char selectedButton[PRO_NAME_SIZE];
	InterfaceRule iRule;

	//status = ProUIPushbuttonDisable(dialog, PB_OK);
	status = ProUIRadiogroupSelectednamesGet(dialog, component, radioGrpNames, &buttonNames);
	ruleLog.Write("ProUIRadiogroupSelectednamesGet status: " + to_string(status));

	//strcpy(selectedButton, buttonNames[0]);
	ruleLog.Write("selected button name: " + (string)buttonNames[0]);
	if (strcmp(buttonNames[0], "rb1") == 0)
	{
		ruleLog.Write("inside rb 1");
		status = ProUILabelHide(dialog, "Label2");
		status = ProUIPushbuttonHide(dialog, "Select1");
		status = ProUILabelHide(dialog, "Label_STR");
		status = ProUIInputpanelHide(dialog, "InputPanel_STR");

		*booleanVal = false;

		status = ProUIPushbuttonEnable(dialog, "CommitOK");
	}
	else if (strcmp(buttonNames[0], "rb2") == 0)
	{
		ruleLog.Write("inside rb 2");
		status = ProUILabelShow(dialog, "Label2");
		status = ProUIPushbuttonShow(dialog, "Select1");
		status = ProUILabelShow(dialog, "Label_STR");
		wchar_t wOffSetVal[PRO_NAME_SIZE];
		ProStringToWstring(wOffSetVal, "0");
		status = ProUIInputpanelValueSet(dialog, "InputPanel_STR", wOffSetVal);
		status = ProUIInputpanelShow(dialog, "InputPanel_STR");
		status = ProUIPushbuttonDisable(dialog, "CommitOK");
		*booleanVal = true;

	}

	return PRO_TK_NO_ERROR;
}
#pragma pop