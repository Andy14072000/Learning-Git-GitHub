/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 04-07-2023	|	V1_0_0		| VERIFY ACTION SPECIAL CASES
==================================================================================================================*/
#include "AppFrontEnd.h"
#include "InterfaceRule.h"

void IR_F1E02_006_verifyaction(vector<string> &reqInterfModules)
{
	mainLog.Write("================================ IR_F1E02_006_verifyaction ================================");

	mainLog.Write("_utils.isSubModulePresent(\"D2B22\"): "+to_string(_utils.isSubModulePresent("D2B22")));
	mainLog.Write("_utils.isSubModulePresent(\"D1A18\"): "+to_string(_utils.isSubModulePresent("D1A18")));

	if(_utils.isSubModulePresent("D2B22") && !_utils.isSubModulePresent("D1A18"))
		reqInterfModules.insert(reqInterfModules.end(), { "MF1E02", "MF2B01", "MF2B03", "MD2B22"});
	if(!_utils.isSubModulePresent("D2B22") && _utils.isSubModulePresent("D1A18"))
		reqInterfModules.insert(reqInterfModules.end(), { "MF1E02", "MF2B01", "MF2B03", "MD1A18"});
	if(!_utils.isSubModulePresent("D2B22") && !_utils.isSubModulePresent("D1A18"))
		reqInterfModules.insert(reqInterfModules.end(), { "MF1E02", "MF2B01", "MF2B03"});
}

void IR_F1E01_007_verifyaction(vector<string>& reqInterfModules)
{

	mainLog.Write("================================ IR_F1E01_007_verifyaction ================================");

	mainLog.Write("_utils.isSubModulePresent(\"F1E01\"): " + to_string(_utils.isSubModulePresent("F1E01")));

	mainLog.Write("_utils.isSubModulePresent(\"F2B01\"): " + to_string(_utils.isSubModulePresent("F2B01")));

	mainLog.Write("_utils.isSubModulePresent(\"F2B03\"): " + to_string(_utils.isSubModulePresent("MF2B03")));

	if (_utils.isSubModulePresent("F2B01") && _utils.isSubModulePresent("F1E01"))
		reqInterfModules.insert(reqInterfModules.end(), { "MF1E01", "MF2B01" });

	if (!_utils.isSubModulePresent("F2B01") || !_utils.isSubModulePresent("F1E01"))
		reqInterfModules.insert(reqInterfModules.end(), { "MF1E01", "MF2B01", "MF2B03" });


}

void IR_F2B06_003_verifyaction(vector<string>& reqInterfModules)
{
	mainLog.Write("================================ IR_F1E02_006_verifyaction ================================");

	InterfaceRule ir;


	vector<string> subModuleList = { "F2B06", "F3B06", "F3B05", "F3B01", "F3B03", "F3B11" };


	mainLog.Write("_utils.isSubModulePresent(\"F2B06\"): " + to_string(_utils.isSubModulePresent(subModuleList[0])));
	mainLog.Write("_utils.isSubModulePresent(\"F3B06\"): " + to_string(_utils.isSubModulePresent(subModuleList[1])));
	mainLog.Write("_utils.isSubModulePresent(\"F3B05\"): " + to_string(_utils.isSubModulePresent(subModuleList[2])));
	mainLog.Write("_utils.isSubModulePresent(\"F3B01\"): " + to_string(_utils.isSubModulePresent(subModuleList[3])));
	mainLog.Write("_utils.isSubModulePresent(\"F3B03\"): " + to_string(_utils.isSubModulePresent(subModuleList[4])));
	mainLog.Write("_utils.isSubModulePresent(\"F3B11\"): " + to_string(_utils.isSubModulePresent(subModuleList[5])));


	for (int i = 0; i < subModuleList.size(); i++)
	{
		if (_utils.isSubModulePresent(subModuleList[i]))
		{
			ir.presentSubmodule.push_back(subModuleList[i]);
		}
		else
		{
			ir.missingSubmodules.push_back(subModuleList[i]);
		}
	}

	mainLog.Write("presentSubmodule = " + to_string(ir.presentSubmodule.size()));
	mainLog.Write("missingSubmodules = " + to_string(ir.missingSubmodules.size()));


	if (_utils.isSubModulePresent(subModuleList[0]) && (_utils.isSubModulePresent("F3B06") || _utils.isSubModulePresent("F3B05") || _utils.isSubModulePresent("F3B01") || _utils.isSubModulePresent("F3B03") || _utils.isSubModulePresent("F3B11")))
	{
		reqInterfModules.insert(reqInterfModules.end(), ir.presentSubmodule.begin(), ir.presentSubmodule.end());

	}

	else if (_utils.isSubModulePresent(subModuleList[0]) && (!_utils.isSubModulePresent("F3B06") && !_utils.isSubModulePresent("F3B05") && !_utils.isSubModulePresent("F3B01") && !_utils.isSubModulePresent("F3B03") && !_utils.isSubModulePresent("F3B11")))
	{
		reqInterfModules.insert(reqInterfModules.end(), subModuleList.begin(), subModuleList.end());

	}

}