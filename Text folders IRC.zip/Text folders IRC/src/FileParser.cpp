/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 20-01-2023	| V1_0_0		| FILES OPERATIONS
==================================================================================================================*/
#include "FileParser.h"

int FileParser::getData2D(vector<vector<string>> &data2D)
{
	// open the CSV file
	ifstream file(fileName);
	if (!file.is_open()) {
		return -1;
	}

	// read the CSV file line by line
	string line;
	while (getline(file, line)) 
	{
		vector<string> row;	//vector to store the contents of the current line
		string cell;	//string to store the current cell

		//loop through the line to extract the cells
		for (size_t i = 0; i < line.length(); i++) 
		{
			if (line[i] == delimeter) {
				row.push_back(cell);
				cell.clear();
			} else {
				cell += line[i];
			}
		}
		row.push_back(cell);	// add the cell to the row vector
		data2D.push_back(row);	// add the row to the _data vector
	}
	file.close();	// close the file

	//PRINT THE CONTENTS
	/*ifstream file(fileName);
	string line = "";
	size_t pos = 0;
	int nCount = getlinesCount();
	string cVal = to_string(nCount);
	int n = 0;
	vector<string> cells;
	while (getline(file, line)) {
		stringstream ss(line);
		while (ss.good()) {
			string substr;
			getline(ss, substr, delimeter);
			cells.push_back(substr);
		}
		cells.push_back("#end");
	}
	file.close();*/

	return 0;
}

int FileParser::getData(vector<string> &data1D)
{
	ifstream file(fileName);
	if (!file.is_open()) {
		return -1;
	}
	string line = "";
	size_t pos = 0;

	int nCount = getlinesCount();
	string cVal = to_string(nCount);

	int n = 0;
	while (getline(file, line)) {
		stringstream ss(line);
		while (ss.good()) {
			string substr;
			getline(ss, substr, delimeter);
			data1D.push_back(substr);
		}
		data1D.push_back("#end");
	}
	file.close();
	return 0;
}

int FileParser::getlinesCount() 
{
	int lineCount = 0;
	ifstream file(fileName);
	string line = "";
	while (getline(file, line)) {
		lineCount++;
	}
	return lineCount;
}

