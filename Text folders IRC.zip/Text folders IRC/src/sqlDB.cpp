/*=================================================================================================================
    NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
    BHUVAN BHARATH	| 30-06-2022	| V1_0_0		| SQL INTEGRATION
===================================================================================================================
    BHUVAN BHARATH	| 07-04-2023	| V2_0_0		| SQLite INTEGRATION
==================================================================================================================
===================================================================================================================
    BHUVAN BHARATH	| 24-01-2024	| V3_0_0		| SQLite DB lock issue
==================================================================================================================*/

#include "DPDSCreoIRCApplication.h"
#include "sqlDB.h"

using namespace std;

//define handles and variables
char sqlQuery[1024] = "";
sqlite3 *db;
sqlite3_stmt* stmt;
char *sqlite_err;
int sqlite_sts;
char sqlite_db_path[PRO_PATH_SIZE] = "\\\\172.22.99.39\\startparttemplate\\IRC_DB\\irc_app.db";
//char sqlite_db_path[PRO_PATH_SIZE] = "\\\\172.22.99.39\\startparttemplate\\FY_2023_24\\irc_app.db";
//char sqlite_db_path[PRO_PATH_SIZE] = "C:\\tmp\\irc_app_og.db";

int createSQLtbl(vector<string> ruleNames, char* mdlName)
{
    mainLog.Write("================================ createSQLtbl ================================");

    //sqlite_sts = setSQLiteJournalMode();

    sqlite_sts = sqlite3_open(sqlite_db_path, &db);
    if(sqlite_sts != SQLITE_OK){
        mainLog.Write("sqlite3_open err");
        sqlite3_close(db);
        return sqlite_sts;
    }
    sqlite3_busy_timeout(db, 2000); // when db lock encontered, wait for 2 secs before executing the next line

    // CHECK IF TABLE ALREADY EXISTS IN THE DB
    sprintf(sqlQuery, "SELECT CASE WHEN EXISTS (SELECT 1 FROM sqlite_master WHERE type='table' AND name = \"%s\") THEN 1 ELSE 0 END AS TableExists;", mdlName);
    //mainLog.Write("sqlQuery: "+string(sqlQuery));

    sqlite_sts = sqlite3_prepare_v2(db, sqlQuery, -1, &stmt, nullptr);
    mainLog.Write("sqlite_sts: "+to_string(sqlite_sts));
    if (sqlite_sts != SQLITE_OK) {
        mainLog.Write("ERROR (at sqlite3_prepare_v2) sqlQuery: "+string(sqlQuery));
        sqlite3_finalize(stmt);
        sqlite3_close(db);
        return sqlite_sts;
    }
    bool isTableExists = false;
    while (sqlite3_step(stmt) == SQLITE_ROW) 
    {
        int tableCount =0;
        tableCount = (sqlite3_column_int(stmt, 0));
        mainLog.Write("No. of tables present in db = "+to_string(tableCount));

        if(tableCount>0){
            isTableExists = true;
        }
    }
    sqlite3_finalize(stmt);

    // CREATE ONLY IF THE TABLE IS NOT AVAILABLE ALREADY IN THE DB
    if(!isTableExists){
        sprintf(sqlQuery, "CREATE TABLE IF NOT EXISTS \"%s\" (S_NO INT NOT NULL PRIMARY KEY, RULE_ID CHAR(12) NOT NULL, PERFORMED_STS VARCHAR(3) DEFAULT \"NO\", TEST_STS VARCHAR(10) NULL, REMARKS TEXT NULL);", mdlName);
        mainLog.Write("sqlQuery: "+string(sqlQuery));

        sqlite_sts = sqlite3_exec(db, sqlQuery, NULL, NULL, &sqlite_err);
        if(sqlite_sts != SQLITE_OK){
            mainLog.Write("sqlite3_exec err: "+string(sqlite_err));
            sqlite3_close(db);
            return sqlite_sts;
        }

        for (int i=0; i<ruleNames.size(); ++i)
        {
            sprintf(sqlQuery, "INSERT INTO \"%s\" (S_NO, RULE_ID) VALUES (%d, \"%s\") ON CONFLICT(S_NO) DO UPDATE SET S_NO=%d, RULE_ID=\"%s\";", mdlName, i+1, ruleNames[i].c_str(), i+1, ruleNames[i].c_str());

            sqlite_sts = sqlite3_exec(db, sqlQuery, NULL, NULL, &sqlite_err);
            if(sqlite_sts != SQLITE_OK){
                mainLog.Write("sqlQuery: "+string(sqlQuery));
                mainLog.Write("sqlite3_exec err: "+string(sqlite_err));
                sqlite3_close(db);
                return sqlite_sts;
            }
        }
    }

    /*strcpy(sqlQuery, "PRAGMA journal_mode=DELETE;");
    sqlite_sts = sqlite3_exec(db, sqlQuery, NULL, NULL, &sqlite_err);
    if (sqlite_sts != SQLITE_OK) {
        mainLog.Write("Failed to set journal_mode: "+string(sqlite_err));
        sqlite3_free(sqlite_err);
    }*/

    sqlite3_close(db);
    return 0;
}

int SQLupdateRuleStatus(char* mdlName, int ruleIndex, ruleResult *test_result)
{
    mainLog.Write("================================ SQLupdateRuleStatus ================================");

    //sqlite_sts = setSQLiteJournalMode();

    sqlite_sts = sqlite3_open(sqlite_db_path, &db);
    if(sqlite_sts != SQLITE_OK){
        mainLog.Write("sqlite3_open err");
        sqlite3_close(db);
        return sqlite_sts;
    }
    sqlite3_busy_timeout(db, 2000); // when db lock encontered, wait for 2 secs before executing the next line

    char cPerformedSts[10];
    if(test_result->performedSts == true)
        strcpy(cPerformedSts, "YES");
    else
        strcpy(cPerformedSts, "NO");

    // Replace newline with tab
    string dbRemark = test_result->remark;
    for (char &ch : dbRemark) {
        if (ch == '\n') {
            ch = '\t'; 
        }
    }

    mainLog.Write("Db pass/fail print" +string(test_result->result));

    string status_column;
    if (test_result->result.compare("PASS") == 0) 
    {
           status_column = "PASSED";
    }
    else if(test_result->result.compare("FAIL") == 0) 
    {
        status_column = "FAILED";
    }
    else if (test_result->result.compare("DEVIATION") == 0) {
        status_column = "DEVIATED";
    }

    mainLog.Write("status_column: "  +status_column);

    char *sqlUpdateQuery = new char[dbRemark.length()+1024];
    sprintf(sqlUpdateQuery, "UPDATE \"%s\" SET PERFORMED_STS = \"%s\", TEST_STS = \"%s\", REMARKS = \"%s\" WHERE S_NO = %d;", mdlName, cPerformedSts, status_column.c_str(), dbRemark.c_str(), ruleIndex);
    mainLog.Write("sqlUpdateQuery: "+string(sqlUpdateQuery));

    //sqlite3_busy_timeout(db, 700);
    //bool success = false;
    //do{
    //    sqlite_sts = sqlite3_exec(db, sqlUpdateQuery, NULL, NULL, &sqlite_err);
    //    if(sqlite_sts != SQLITE_OK){
    //        mainLog.Write("sqlite3_exec err: "+string(sqlite_err));
    //        //sqlite3_close(db);
    //        //delete[] sqlUpdateQuery;
    //        //return sqlite_sts;
    //    }
    //    else
    //        success = true;
    //}
    //while(success == false);
    sqlite_sts = sqlite3_exec(db, sqlUpdateQuery, NULL, NULL, &sqlite_err);
    if(sqlite_sts != SQLITE_OK){
        mainLog.Write("sqlite3_exec err: "+string(sqlite_err));
        sqlite3_close(db);
        delete[] sqlUpdateQuery;
        return sqlite_sts;
    }
  
    /*strcpy(sqlQuery, "PRAGMA journal_mode=DELETE;");
    sqlite_sts = sqlite3_exec(db, sqlQuery, NULL, NULL, &sqlite_err);
    if (sqlite_sts != SQLITE_OK) {
        mainLog.Write("Failed to set journal_mode: "+string(sqlite_err));
        sqlite3_free(sqlite_err);
    }*/

    sqlite3_close(db);
    delete[] sqlUpdateQuery;

    return 0;
}

int retrieveSQLData(char* mdlName, vector<SQLruleData> &testData)
{
    mainLog.Write("================================ retrieveSQLData ================================");

    sqlite_sts = sqlite3_open(sqlite_db_path, &db);
    mainLog.Write("sqlite_sts: "+to_string(sqlite_sts));
    if (sqlite_sts != SQLITE_OK) {
        mainLog.Write("sqlite3_open err");
        sqlite3_close(db);
        return sqlite_sts;
    }
    sqlite3_busy_timeout(db, 2000); // when db lock encontered, wait for 2 secs before executing the next line

    sprintf(sqlQuery, "SELECT S_NO, RULE_ID, TEST_STS, REMARKS FROM \"%s\" WHERE PERFORMED_STS=\"YES\";", mdlName);
    //mainLog.Write("sqlQuery: "+string(sqlQuery));

    sqlite_sts = sqlite3_prepare_v2(db, sqlQuery, -1, &stmt, nullptr);
    mainLog.Write("sqlite_sts: "+to_string(sqlite_sts));
    if (sqlite_sts != SQLITE_OK) {
        mainLog.Write("ERROR (at sqlite3_prepare_v2) sqlQuery: "+string(sqlQuery));
        sqlite3_finalize(stmt);
        sqlite3_close(db);
        return sqlite_sts;
    }
    while (sqlite3_step(stmt) == SQLITE_ROW) 
    {
        SQLruleData td;

        td.sno = (sqlite3_column_int(stmt, 0)); // s no
        strcpy(td.id, (std::string(reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1)))).c_str());  // id
        strcpy(td.status, (std::string(reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2)))).c_str());  // status

        // since remarks length is not fixed, using dbRemarks to fetch it from db and then assigning it to struct.
        const char* dbRemarks = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        td.remark = new char[strlen(dbRemarks) + 1];
        strcpy(td.remark,dbRemarks);    // remarks
        testData.push_back(td);
    }
    sqlite3_finalize(stmt);
    sqlite3_close(db);

    return 0;
}

int SQLcheckIfRulePerformed(char* mdlName, int testId, bool &isTestPerformed)
{
    mainLog.Write("================================ SQLcheckIfRulePerformed ================================");

    sqlite_sts = sqlite3_open(sqlite_db_path, &db);
    if (sqlite_sts != SQLITE_OK) {
        mainLog.Write("sqlite3_open err");
        sqlite3_close(db);
        return sqlite_sts;
    }
    sqlite3_busy_timeout(db, 2000); // when db lock encontered, wait for 2 secs before executing the next line

    sprintf(sqlQuery, "SELECT PERFORMED_STS FROM \"%s\" WHERE S_NO = %d;", mdlName, testId);
    //mainLog.Write("sql_Query: "+string(sqlQuery));

    sqlite_sts = sqlite3_prepare_v2(db, sqlQuery, -1, &stmt, nullptr);
    if (sqlite_sts != SQLITE_OK) {
        mainLog.Write("ERROR (at sqlite3_prepare_v2) sqlQuery: "+string(sqlQuery));
        sqlite3_finalize(stmt);
        sqlite3_close(db);
        return sqlite_sts;
    }

    sqlite_sts = sqlite3_step(stmt);
    char sVal[5];
    strcpy(sVal, (std::string(reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0)))).c_str());

    if (strcmp(sVal, "YES") == 0)
        isTestPerformed = true;
    else
        isTestPerformed = false;

    sqlite3_finalize(stmt);
    sqlite3_close(db);

    return SQLITE_OK;
}

// Custom busy handler function
//int custom_busy_handler(void *data, int count) {
//    // Wait for 2000 milliseconds before retrying
//    Sleep(2000000);
//    return 1;  // Retry the operation
//}

/*int setSQLiteJournalMode()
{
    mainLog.Write("================================ setSQLiteJournalMode ================================");

    sqlite_sts = sqlite3_open(sqlite_db_path, &db);
    if(sqlite_sts != SQLITE_OK){
        mainLog.Write("sqlite3_open err");
        sqlite3_close(db);
        return sqlite_sts;
    }

    // set the journal mode to WAL to prevent database locking when multiple users write simultaneously
    strcpy(sqlQuery, "PRAGMA journal_mode=WAL;");
    sqlite_sts = sqlite3_exec(db, sqlQuery, NULL, NULL, &sqlite_err);
    if (sqlite_sts != SQLITE_OK) {
        mainLog.Write("Failed to set journal_mode: "+string(sqlite_err));
        sqlite3_free(sqlite_err);
    }
    return sqlite_sts;
}*/