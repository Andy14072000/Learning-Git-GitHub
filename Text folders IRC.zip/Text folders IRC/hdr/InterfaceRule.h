/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-03-2023	|	V1_0_0		| INTERFACE RULES MAIN
==================================================================================================================*/
#pragma once
#ifndef INTERFACE_RULE_H
#define INTERFACE_RULE_H
#include "DPDSCreoIRCapplication.h"
#include <UtilMath.h>

// COMMON UI ELEMENTS
#define RULE_UI_OK		"CommitOK"
#define RULE_UI_CANCEL  "CommitCancel"
#define RULE_IMAGE_PB   "rule_img"
#define VECTOR(a) a[0], a[1], a[2]
#define M_PI   3.14159265358979323846264338327950288
#define PRO_UTIL_ALMOST_ZERO  .000000001

struct Axis_data
{
	string axis_name;
	int axis_ID;
};

struct surfaceData {
	ProSurface surface;
	ProMdl parentMdl;
	ProEdge edge;
	double diameter;
	int id;
	//int idTable;
	ProAsmcomppath path;
	ProModelitem modelItem;
	ProSelection edgeSel;
};

struct Leaf_Information
{
	string leaf_name;
	int ID;
	bool selection_done;
	double span_length;
	vector<Axis_data> Axis_info;
	bool valid_length = FALSE;
	string leaf_status = "FAIL";
};

struct Standard_span_data
{
	string project_codes;
	string span_length;
};
struct feat_id_data {
	int 		    level;
	int				feat_ids[10];
};

struct Asm_model {
	ProMdl		Model;
	int			Model_feat_id;
};

struct ComponentData{			//Prajakta
	char name[PRO_NAME_SIZE];
	int id;
	ProMdlfileType comp_type = PRO_MDLFILE_ASSEMBLY;
};

struct clearanceData {			//Atharva
	ProSelection sel1;
	ProSelection sel2;
	string clea;
	string desc1;
	string desc2;
	Pro3dPnt pntArr[2];
	double clearance;
	char nameOfSel1[PRO_NAME_SIZE];
	char nameOfSel2[PRO_NAME_SIZE];
	int id1;
	int id2;
	//char pntName[PRO_NAME_SIZE];
};

struct ComponentIdTableData {            // Atharva
	char name[PRO_NAME_SIZE];
	ProIdTable compIdTab;
	int tableNum;
	ProMdlfileType comp_type = PRO_MDLFILE_ASSEMBLY; 
};

struct edgeSel {			//Atharva
	ProGeomitem gItem;
	ProModelitem mdlItem;
	ProMdl owner;
	ProSelection sel;
	double dia;
	int id;
};

struct ownerInfo {
	char name[PRO_NAME_SIZE];
	char descrp[PRO_NAME_SIZE];
	int id;
	ProModelitem modelItem;
	ProAsmcomppath asmCompPath;
};

struct IntAndStringlistMap
{
	int intval;
	vector<string> strList;
};

struct HardwareInfo {        // Atharva
	char compName[PRO_NAME_SIZE];
	double gradeDb;
	string typeOfHw;
	ProModelitem Item;
	int ID;
};

struct planeData {
	char name[PRO_NAME_SIZE];
	ProMdl ownerMdl;
};


struct PartnameDescriptionPair {		// Prajakta
	char part_name[PRO_NAME_SIZE];
	char description[PRO_NAME_SIZE];
	ProMdlType mdlType;
};

struct PartnameDescriptionPairM { //Mathan
	char part_name[PRO_PATH_SIZE];
	char description[PRO_PATH_SIZE];
	char MatType[PRO_NAME_SIZE];
	int barrel;
};

struct pathVariables {			// Prajakta
	vector<int> table_num_Vector;
	vector<vector<int>> comp_id_table_vector;
};

typedef struct user_appdata					//Ved
{
	FILE* fp;
	int level;
} UserAppdata;

struct Model_Tree_Information					//Ved
{
	string Parent_name;
	string sub_mod_name;
	ProSelection sela;
	string name;
	string extension;
	int ID;
	string description;
	vector<int> ID_path;
	int ID_table_size;
	double distances;
};

struct selectionInfo {							//Atharva
	char name[PRO_NAME_SIZE];
	char descrp[PRO_NAME_SIZE];
	int id;
	ProModelitem modelItem;
	ProAsmcomppath asmCompPath;
	ProSelection selection;
};

struct AsmName {
	char AsmName[PRO_NAME_SIZE];
};

struct gasketData {		// Prajakta
	char part_name[PRO_NAME_SIZE];
	char description[PRO_NAME_SIZE];
	ProMdlType mdlType;
};

class InterfaceRule : public Utils
{

public:
	// CTOR
	InterfaceRule();
	//DTOR
	~InterfaceRule();
	
	// METHODS (PUBLIC)
	ProError measureAngleBetweenSurfaceAndAxis(ProSelection& sel_surf, ProSelection& sel_axis, double& angle);
	int createTangentDatumAxisWithReference(ProSelection& sel_axis, char* refAxisName, char* outputAxisName);
	int measureDistanceBetweenPlaneAndSurface(const char* parentMdlName, const char* plane_name, ProSelection& sel_surf, double& distance);
	int measureDistanceBetweenPlanes(const char* parentMdlName, const char* plane1_name, const char* plane2_name, double& distance);
	int measureDistanceBetweenComponents(ComponentData reqComp1, ComponentData reqComp2, double& distance, Pro3dPnt (&pnt_arr)[2]);
	int measureDistanceBetweenSurfaceAndComp(ComponentData reqComp1, ProSelection sel, double& distance);
	int createTangentDatumPlaneWithReference(ProSelection& sel_surf, ProMdl& refPlaneOwner, char* refPlaneName, char* outputPlaneName);
	int deleteDatumPlane(char* plane_name);
	int deleteDatumAxis(char* axis_name);
	ProError measureDistanceBetweenSurfaces(ProSelection &sel_surf1, ProSelection &sel_surf2, double &distance_bw_surfs);
	ProError computeClearanceBetweenSurfaces(ProSelection &sel_surf1, ProSelection &sel_surf2, double &clearance_bw_surfs);
	
	int measureDistanceBetweenAsmAndPart(ComponentData reqComp1, ProSelection* Part_sel, double& distance);
	ProError deleteDatumPoint(char* dtmpoint_name);
	//int createDatumPoints(Pro3dPnt pnt_arr[2], char* csysName);

	int createDatumPoints(Pro3dPnt pnt_arr[2], char* csysName, char* outputPointName);
	int f2D01_measureDistanceBetweenComponents(ComponentData reqComp1, ComponentData reqComp2, double& distance);

	int InterfaceRule::measureDistanceBetweenComponents(ComponentData reqComp1, ComponentData reqComp2, double& distance);

	// INLINE
	vector<string> presentSubmodule, missingSubmodules;
	inline void trimString(string &str);
	inline void sortVector(vector<double> &vec);

protected:
	// DATA MEMBERS
	int rule_sts{}, project_code{};
	vector<string> csvData1D;
	vector<vector<string>> csvData2D;
	string acceptance_criteria = "";
	ProUIMessageButton *rule_msg_btns = nullptr;
	bool isRightValue{};
	int dlg_sts{};
	bool isUserQuits = false;
	ProCharPath remark{};
};

// INLINE DEFINITIONS
inline void InterfaceRule::trimString(string &str)
{
	str.erase(str.find_last_not_of(' ')+1);		//suffixing spaces
	str.erase(0, str.find_first_not_of(' '));	//prefixing spaces
}
inline void InterfaceRule::sortVector(vector<double> &vec)
{
	int i, j, n = vec.size();
	for (i = 0; i < n - 1; i++)
		for (j = 0; j < n - i - 1; j++)
			if (vec[j] > vec[j+1])
				swap(vec[j], vec[j+1]);
}

// CALLBACK FUNCTIONS
double* ProUtilVectorCopy(double from[3],double to[3]);
double* ProUtilVectorNormalize(double input[3], double output[3]);
double* ProUtilVectorScale(double scalar, double vector[3], double result[3]);
double ProUtilVectorLength(double v[3]);
double ProUtilVectorDot(double a[3], double b[3]);
ProError getVisitedCompAsmNamesAction(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError compsFilter(ProFeature* p_feature, ProAppData app_data);
ProError planeFilter(ProFeature* p_feature, ProAppData app_data);
ProError ruleDlgCloseAction(char* dialog, char* component, ProAppData data);
ProError ruleDlgOKaction(char* dialog, char* component, ProAppData data);
ProError getReqComponentsId(ProFeature *pFeat, ProError status, ProAppData appD);
ProError getReqComponentsIdVec(ProFeature* pFeat, ProError status, vector<ComponentData>* _reqComps);
ProError optionMenuImageChangeAction(char* dialog, char* component, ProAppData data);
ProError getParameterDescAndPartname(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError getSelectedTypeOpMenu(char* dialog, char* component, ProAppData data);
ProError visit11DigitComponents(ProFeature* p_feature, ProError status, vector<HardwareInfo>* _hwInfo);
int createDatumPointAtCenterOfEdge(ProSelection edgeSelection, char cPointName[PRO_NAME_SIZE]);
string doubleToString(double value);
ProError getVisiblePlanes(ProFeature* pFeat, ProError status, vector<planeData>* datumPlaneNames);
int highlightParts(ComponentData reqComp1, ProColortype);
std::vector<std::string> split(const std::string& s, char delimiter);
void option_menu_set(char* dialog, vector<string> option_menulist, char* optionmenu);
ProError getVisitedCompAsmNamesAndDescription(ProFeature* p_feature, ProError status, vector<PartnameDescriptionPair>* compList);
/*======================================================================================================
========= Function prototypes for ground clearance and departure & ramp over departure angle rule =======
=======================================================================================================*/
int createDatumPointAtCenterOfEdge(ProSelection edgeSelection, char cPointName[PRO_NAME_SIZE]);
bool isDouble(const string& str);
ProError inputValue(char* dialog, char* component, vector<double>* offsetValVec);
ProError refSurfSelections(char* dialog, char* component, vector<selectionInfo>* ownerDetails);
ProError getVisiblePlaneNames(ProFeature* pFeat, ProError status, vector<string>* datumPlaneNames);
int projectDatumPointOnPlane(ProSelection refPntSel, ProSelection refPlaneSel, char cPointName[PRO_NAME_SIZE]);
int normalPlaneThru2Points(ProSelection& fCentrePnt, ProSelection& rCentrePnt, ProSelection& longMemberSurf, char outputPlaneName[PRO_NAME_SIZE]);
int createOffsetPlaneWithReference(ProSelection refSelection, double offsetValue, char* outputPlaneName);
int selectionAllocByName(char cRefName[PRO_NAME_SIZE], ProType featType, ProSelection* featSel);
int createCsysOffsDatumPoint(ProSelection csysSel, Pro3dPnt pnt_arr[2], char pointName[PRO_NAME_SIZE]);
int findTheBiggestArcEdge(selectionInfo ownerDetails, edgeSel* edgeSelection);
int measureDistanceBetweenPlaneAndComp(ProSelection planeSel, ComponentData reqComp1, double& distance, Pro3dPnt pntArr[2]);
double depatureAngleCalc(double XD, double YD, double rr);
double rampOverAngleCalc(double Xrf, double Yr, double rf, double rR, double XrR);
ProError edgeVisitAction(ProGeomitem* p_handle, ProError status, vector<edgeSel>* vectr);
int createGenDPntAtOffsDist(ProSelection pntSel, ProSelection csysSel, double offsDist[3], char pointName[PRO_NAME_SIZE]);
int threePointPlaneCreate(ProSelection& sel_1, ProSelection& sel_2, ProSelection& sel_3, char* outputPlaneName);
ProError measureDistanceBetweenSurfacesWithOptions(ProSelection& sel_surf1, ProBoolean option1, ProSelection& sel_surf2, ProBoolean option2, double& distance_bw_surfs);
/*========================================================================================================================*/


#endif

