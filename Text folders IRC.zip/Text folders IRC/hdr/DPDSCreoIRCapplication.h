/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-12-2021	| V1_0_0		| HEADER THAT MEETS ALL THE REQUIREMENTS
===================================================================================================================
BHUVAN BHARATH	| 05-01-2022	| V1_0_0		| INCLUDED <filesystem> header
===================================================================================================================
BHUVAN BHARATH	| 19-06-2023	| V1_0_0		| INCLUDED Utils class
==================================================================================================================*/
#pragma once
#ifndef DPDS_CREO_IRC_ADDIN
#define DPDS_CREO_IRC_ADDIN

/*--------------------------------------------------------------------*\
ProToolkit includes
\*--------------------------------------------------------------------*/
#include "ProHeaders.h"
/*--------------------------------------------------------------------*\
Application includes
\*--------------------------------------------------------------------*/
#include <time.h>
#include <iostream>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <map>
#include <unordered_map>
#include <Windows.h>
#include <ctime>
#include <cstdlib>
#include <comdef.h>
#include <filesystem>
#include <unordered_set>
#include <regex>
/*--------------------------------------------------------------------*\
Other includes
\*--------------------------------------------------------------------*/
#include "LogFile.h"
#include "FileParser.h"
#include "UtilMath.h"
#include "UtilMatrix.h"
#include "TestError.h"
#include "sqlDB.h"
#include "Utils.h"

class Utils;	// telling compiler that "Utils" class exists beforehand.

// STRUCTS
struct SubModuleInfo	// sub-modules and its rules
{
	int sno;
	string name;
	int rules_count;
	vector<string> rule_names_list;
};
struct RuleInfo		// rules and its details
{
	int sno;
	int lib_sno;
	string module_name;
	string id;
	string desc;
	string help_doc;
	string interf_modules;
	string status;
	string remark;
	//string long_remark;
	bool performed_sts = false;
	bool IsDigitizable;
	bool IsDeveloped;
};

enum ModelCategory {DEFAULT_CAT = -1, SUB_MODULE, CP_ITEM, DUMMY};

//GLOBAL
extern LogFile mainLog;
extern LogFile ruleLog;
extern ProError status;
extern const char *PROE_TML_STD_PATH;
extern vector<SubModuleInfo> subModulesList;
extern vector<vector<string>> rulesMapData;
extern Utils _utils;	// creating global object for accessing utilities across the project.

//FUNCTION PROTOTYPES
static uiCmdAccessState TestAccessDefault(uiCmdAccessMode access_mode);
int callApplication();
static void executeCommandSilently(const std::string& command);
ProError Map_Log_Server(FILE* fp);

// =============== MAIN DLG UI DEFINITIONS ===============
//MAIN DLG
#define DLG_IRC_MAIN			"std_rules_dialog" 
#define LBL_ASM_NAME			"asm_name_value_lbl" 
#define LBL_DESCRIPTION			"description_value_lbl" 
#define DLG_TAB					"tab1"
//LIBRARY TAB
#define TBL_RULE_LIBRARY		"lib_tbl"
#define TBL_RULE_LAYOUT			"rules_layout"
#define PB_PLM_SUBMIT			"plm_submit_btn"
#define PB_CLOSE				"close_btn"
#define LIST_SUB_MODULE			"sub_module_list"
#define PB_RUN					"run_pb"
#define CB_CHECK				"check_cb"
#define CB_LIB_DEVIATION		"deviation_lib_cb"
#define PB_HELP					"help_pb"
//STATUS TAB
#define	TBL_RULE_STATUS			"sts_tbl"
#define	PB_REPORT				"report_btn"
#define	CB_DEVIATION			"deviation_cb"
#define	PB_COPY					"copy_pb"

#endif