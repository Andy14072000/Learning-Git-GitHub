#pragma once
#ifndef ASSEMBLY_TOOL_H
#define ASSEMBLY_TOOL_H

struct AsmPosition
{
	char modAddrs[10];
	ProCharName name = "";
	//ProMdlfileType type;
	ProMatrix pos;
};

int createAsmToolDialog(vector<string> missingModules, ModelCategory category);
ProError browse_pb_action(char* dialog, char* component, ProAppData data);
ProError browse_asmloc_action(char* dialog, char* component, ProAppData data);
ProError asmname_ip_action(char* dialog, char* component, ProAppData data);
ProError assemble_action(char* dialog, char* component, ProAppData data);
//ProError asm_mode_rg_action(char* dialog, char* component, ProAppData data);
ProError asmToolDlgCloseAction(char* dialog, char* component, ProAppData data);
void getRowNameFromComponent(char *compName, char *rowName);
//void UserDisplayPopupMessageOK(ProUIMessageType msg_type, string title, string message);
bool isMatrixValid(const double matrix[4][4]);
bool isAsmNameValid(string asmname);
string toUpperCase(string str);
bool isValidPositionMatrixFile(char *filePath, double (&posMatrix)[4][4]);

//ProError missingModlOptMenuSelectAction(char* dialog, char* component, ProAppData data);
//void setOptionMenu(char *optMenuName, vector<std::pair<int, string>> &reqAsmNames);

#endif