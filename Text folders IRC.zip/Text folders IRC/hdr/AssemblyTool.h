#pragma once
#ifndef ASSEMBLY_TOOL_H
#define ASSEMBLY_TOOL_H

#include "curl.h"

struct AsmPosition
{
	char modAddrs[10];
	ProCharName name = "";
	char rev[50];
	//ProMdlfileType type;
	ProMatrix pos;
};

struct PLM_POS_DATA 
{
	string prtNo;
	double posMatrix[4][4];
};

int assemblyToolMain(vector<string> missingModules, string rule_id, ModelCategory category);
//ProError browse_pb_action(char* dialog, char* component, ProAppData data);
//ProError browse_asmloc_action(char* dialog, char* component, ProAppData data);
//ProError asmname_ip_action(char* dialog, char* component, ProAppData data);
//ProError assemble_action(char* dialog, char* component, ProAppData data);
//ProError assemble_action();
//ProError asm_mode_rg_action(char* dialog, char* component, ProAppData data);
ProError asmToolDlgOKAction(char* dialog, char* component, ProAppData data);
ProError asmToolDlgCloseAction(char* dialog, char* component, ProAppData data);

void getRowNameFromComponent(char *compName, char *rowName);
//void UserDisplayPopupMessageOK(ProUIMessageType msg_type, string title, string message);
bool isMatrixValid(const double matrix[4][4]);
bool isAsmNameValid(string asmname);
string toUpperCase(string str);
bool isValidPositionMatrixFile(char *filePath, double (&posMatrix)[4][4]);
std::vector<std::string> extractPLMvalues(const std::string& xml, const std::string& tag);
size_t WriteCallback(void* contents, size_t size, size_t nmemb, std::string* output);
void getPartNumberAndPosMatrix(vector<string> dataVec, vector<PLM_POS_DATA> &outputData);


//ProError missingModlOptMenuSelectAction(char* dialog, char* component, ProAppData data);
//void setOptionMenu(char *optMenuName, vector<std::pair<int, string>> &reqAsmNames);

#endif