/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 15-06-2023	|	V1_0_0		| COMMON UTILITIES
==================================================================================================================*/
#pragma once
#ifndef UTILS_H
#define UTILS_H

// UTILITY VARIABLES FOR GLOBAL ACCESS
extern ProMdl curMdl;
extern ProModelitem curMdlitem;
extern ProCharName cCurMdlName;
extern ProName wCurMdlName;
extern ProCharPath cCurMdlPath;
extern ProCharPath cRulesDbPath;
extern ProPath wCurMdlPath;
extern ProAsmcomppath curAsmCompPath;
extern int	dialog_sts;
extern ProPath message;
extern ProUIMessageButton* msg_buttons;
extern ProUIMessageButton 	user_choice;
extern char cTextPath[PRO_PATH_SIZE];
extern wchar_t wTextPath[PRO_NAME_SIZE];
extern char cCurDirPath[PRO_PATH_SIZE];
extern wchar_t wCurDirPath[PRO_PATH_SIZE];
extern ProMatrix identity_matrix;

class Utils 
{
public:
	// UTILITY METHODS
	bool compareFloat(double x, double y);
	vector<string> getData1D(char* file_name);
	vector<vector<string>> getData2D(char* file_name);
	void UserDisplayPopupMessageOK(ProUIMessageType msg_type, string title, string message);
	ProUIMessageButton UserDisplayPopupMessage_OK_CANCEL(ProUIMessageType msg_type, string title, string message);
	ProUIMessageButton UserDisplayPopupMessageUserChoice(ProUIMessageType msg_type, string title, string message, ProUIMessageButton* buttons);
	//void getReqValsFrom2DCsvData(char *csvFileName, int projCodeIdx, int reqValIdx, int projCode,  vector<int> &reqValsFromCsv);
	void getReqValsFrom2DCsvData(char *csvFileName, int projCodeIdx, int reqValIdx, int projCode,  vector<string> &reqValsFromCsv);
	void _getReqValsFrom2DCsvData_F3A01(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv);
	int getParamValue(ProModelitem mdl_item, char* paramName);
	void copyDirectory(const char* source, const char* destination);
	bool isWhitespaceString(const string& str);
	void copyToClipboard(const std::string& text);
	bool compareProMatrices(ProMatrix matrix1, ProMatrix matrix2);
	void copyProMatrices(ProMatrix source, ProMatrix destination);
	bool isSubModulePresent(const std::string& element);
	string doubleToString(double value);
	string remSpacesAtBothEnds(const string& str);
	bool createFile(const string& fileName, const string& path, const string& content);
};

#endif