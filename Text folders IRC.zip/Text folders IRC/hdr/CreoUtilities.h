#pragma once
#ifndef CREO_UTILITIES_H
#define CREO_UTILITIES_H
#include "DPDSCreoSRCAddIn.h"

void getCurrentMdl(ProMdl &Mdl, ProCharName mdlName);

#endif
