/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-04-2023	|	V1_0_0		| F5A11 - BRAKING SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF5A11_H
#define IRF5A11_H

#include "InterfaceRule.h"

struct PartnameDescriptionPairF5A11 {
	char part_name[PRO_NAME_SIZE];
	char description[PRO_NAME_SIZE];
};


class IRF5A11 : private InterfaceRule
{
public:
	// CTOR
	IRF5A11() = default;

	// METHODS
	int IRF5A11_002(ruleResult& final_res);

};
ProError select_action_IR_F5A11_002(char* dialog, char* component, ProAppData data);
ProError getAsmSelectionF5A11(ProFeature* p_feature, ProError status, ProAppData appdata);

#endif