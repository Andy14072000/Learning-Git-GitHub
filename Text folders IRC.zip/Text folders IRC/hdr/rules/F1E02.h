/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 19-05-2023	|	V1_0_0		| F1E02 - CHASIS CONTROLS
==================================================================================================================*/
#pragma once
#ifndef IRF1E02_H
#define IRF1E02_H

#include "InterfaceRule.h"

class IRF1E02 : private InterfaceRule
{
public:
	// CTOR
	//IRF1E02();

	// METHODS
	//int IRF1E02_006(ruleResult &final_res);
};
#endif