/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 19-05-2023	|	V1_0_0		| F1D02 - WINCH SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF1D02_H
#define IRF1D02_H

#include "InterfaceRule.h"

class IRF1D02 : private InterfaceRule
{
public:
	// CTOR
	//IRF1D02();
	SubModuleInfo _reqSMinfo;

	// METHODS
	int IRF1D02_001(ruleResult &final_res);
	int IRF1D02_004(ruleResult &final_res);
};
ProError select_action_IRF1D02_001(char* dialog, char* component, ProAppData data);
ProError rg_select_action_IRF1D02_001(char* dialog, char* component, ProAppData data);

#endif