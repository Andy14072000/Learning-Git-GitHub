/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 19-05-2023	|	V1_0_0		| F5A01 - BRAKING SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF3B02_H
#define IRF3B02_H
#include "InterfaceRule.h"

class IRF3B02 : private InterfaceRule
{
public:
	// CTOR
	//IRF5A01();


	// METHODS
	int IRF3B02_002(ruleResult& final_res);
	int IRF3B02_003(ruleResult& final_res);
	int IRF3B02_004(ruleResult& final_res);
};
/*------------------- function prototypes for IRF3B02_002 rule -------------------*/
ProError F3B02_visit(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError F3B02_descget(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError Platform_Dropdown_action_IRF3B02_002(char* dialog, char* component);
void f3B02_getReqValsFrom2DCsvData(char* csvFileName, int fuelIdx, int reqValIdx, string fuelcap, vector<string>& reqValsFromCsv);
ProError Dropdown_action_IRF3B02_002(char* dialog, char* component);

/*------------------- function prototypes for IRF3B02_003 rule -------------------*/
ProError rg_select_action_IRF3B02_003(char* dialog, char* component, ProAppData data);

//F3B02_004
ProError measureDistanceBetweenSurfaces_F3b02(ProSelection& sel_surf1, ProBoolean option1, ProSelection& sel_surf2, ProBoolean option2, double& distance_bw_surfs);
ProError platformList_Ur(char* dialog, char* component, ProAppData data);
void getPlatval_Ur(vector<vector<string>> dbList2D_EP_F3A01, string platformName, vector<string>& values);
ProError subplatformList_Ur(char* dialog, char* component, ProAppData data);
void option_menu_Ur(vector<string> option_menulist, char* optionmenu);
void getGroundClearanceValsFromCsv_Ur(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv);
int createOffsetPlaneWithReference_F3B02_004(ProSelection refSelection, double offsetValue, char* outputPlaneName);
int measureDistanceBetweenPlaneAndComp__F3B02_004(ProSelection planeSel, ComponentData reqComp1, double& distance, Pro3dPnt pntArr[2]);
ProError refSurfSelections_F3B02_004(char* dialog, char* component, vector<selectionInfo>* ownerDetails);
#endif