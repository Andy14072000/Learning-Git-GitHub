/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
Aniket Satpute 	| 18-03-2023	|	V1_0_0		| F5A20 - BRAKING SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF5A20_H
#define IRF5A20_H

#include "InterfaceRule.h"

struct connector {
	ProCharName		elbo_connector;
	ProCharName		straight_connector;
};
struct connector_in_model {
	ProCharName		elbo_connector;
	ProCharName		straight_connector;
	ProCharName		owner_model;
	int				count;
};


class IRF5A20 : private InterfaceRule
{
public:
	// CTOR
	IRF5A20() = default;

	// METHODS
	int IRF5A20_001(ruleResult& final_res);
private:
	SubModuleInfo _reqSMinfo;
};

//FUNCTION PROTOTYPES
ProError connectors_visit_action(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError getAsmNamesOnly(ProFeature* p_feature, ProError status, vector<string>* asmNamesVec);

#endif
