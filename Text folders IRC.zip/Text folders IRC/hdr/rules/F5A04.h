/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-03-2023	|	V1_0_0		| F5A03 - BRAKING SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF5A04_H
#define IRF5A04_H

#include "InterfaceRule.h"

struct ComponentData_IR_F5A03_005 {
	char name[PRO_PATH_SIZE];
	int id;
};

class IRF5A04 : private InterfaceRule
{
public:
	// CTOR
	IRF5A04() = default;

	// METHODS
	int IRF5A04_001(ruleResult& final_res);
};
ProError Clearance_Compute_Action_IR_F5A03_005(ComponentData_IR_F5A03_005 reqComp1, ComponentData_IR_F5A03_005 reqComp2, double& distance);
ProError measure_action_IR_F5A03_005(char* dialog, char* component);
ProError getReqComponentsId_IR_F5A03_005(ProFeature* pFeat, ProError status, ProAppData appD);
ProError createDatumPointsusingCSYS_IR_F5A03_005(Pro3dPnt pnt_arr[2], char* csysName);
ProError ruleDlgOKaction_IR_F5A03_005(char* dialog, char* component, ProAppData data);
ProError ruleDlgCloseAction_IR_F5A03_005(char* dialog, char* component, ProAppData data);
ProError deleteDatumPointCreatedUsingCsys_IR_F5A03_005(char* dtmpoint_name);
ProError compsFilter_IR_F5A03_005(ProFeature* p_feature, ProAppData app_data);
#endif
