/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	|	V1_0_0		| F1E08 - CHASSIS CONTROLS RULES
==================================================================================================================*/
#pragma once
#ifndef IRF1E08_H
#define IRF1E08_H

#include "InterfaceRule.h"

class IRF1E08 : private InterfaceRule
{
public:
	// CTOR
	IRF1E08() = default;

	// METHODS
	int IRF1E08_007(ruleResult &final_res);
	//int IRF1E08007_getClearance(double &clearance, string *compNames);

};
ProError csysVisitAction(ProFeature* p_feature, ProError status, char* cPlaneName[PRO_NAME_SIZE]);
ProError visitAction_F1E08(ProFeature* p_feature, ProError status, vector<ComponentIdTableData>* _reqComps);
int measureNearestDistanceBetweenComponents(ComponentIdTableData reqComp1, ComponentIdTableData reqComp2, double& distance);

#endif