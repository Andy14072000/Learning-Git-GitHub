/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F3A01 - FUEL SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF3A01_H
#define IRF3A01_H

#include "InterfaceRule.h"

class IRF3A01 : private InterfaceRule
{
public:
	// CTOR
	IRF3A01() = default;

	// METHODS
	int IRF3A01_001(ruleResult& final_res);
	int IRF3A01_003(ruleResult& final_res);
	int IRF3A01_004(ruleResult &final_res);
	int IRF3A01_007(ruleResult& final_res);
	

private:
	vector<AsmName> asm_name;
	vector<string> reqValsFromCsv;
	SubModuleInfo _reqSMinfo;
	bool breakForLoop = false;
};
/*------------------------- Prototypes for IR-F3A01-001 rule -----------------------*/
ProError _optionMenuImageChangeAction(char* dialog, char* component, ProAppData data);
ProError platformListF3A01001(char* dialog, char* component, ProAppData data);
ProError subplatformListF3A01001(char* dialog, char* component, ProAppData data);
ProError select_action_IRF3A01001(char* dialog, char* component, ProAppData data);
ProError run_action_IRF3A01001(char* dialog, char* component, ProAppData data);
void getengineCapdatafromcsv(vector<vector<string>> dbList2D_F3A01, string platformName, vector<string>& values);
void option_menuF3A01001(vector<string> option_menulist, char* optionmenu);
int IRcreateTangentDatumPlaneWithReference(ProSelection& sel_surf, ProMdl& refPlaneOwner, char* refPlaneName, char* outputPlaneName);
void _getReqValsFrom2DCsvData_F3A01(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv);

/*------------------------- Prototypes for IR-F3A01-003 rule -----------------------*/
ProError platformList_FT(char* dialog, char* component, ProAppData data);
ProError subplatformList_FT(char* dialog, char* component, ProAppData data);
void getPlatval_FT(vector<vector<string>> dbList2D_FT_F3A01, string platformName, vector<string>& values);
void option_menu_FT(vector<string> option_menulist, char* optionmenu);
void getGroundClearanceValsFromCsv_FT(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv);

/*------------------------- Prototypes for IR-F3A01-004 rule -----------------------*/
ProError visit_action_F3A01004(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError platformList_F3A01004(char* dialog, char* component, ProAppData data);
ProError subplatformList_F3A01004(char* dialog, char* component, ProAppData data);
void getengineCapdatafromcsvF3A01004(vector<vector<string>> dbList2D_F3A01, string platformName, vector<string>& platform);
void option_menuF3A01004(char* dialog, vector<string> option_menulist, char* optionmenu);
void _getReqValsFrom2DCsvData(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv);

/*------------------------- Prototypes for IR-F3A01-007 rule -----------------------*/
ProError IR_F3A01_007_measureDistanceBetweenComponents(ComponentData reqComp1, ComponentData reqComp2, double& distance, Pro3dPnt(&pnt_arr)[2]);
ProError getReqComponentsID_F3A01(ProFeature* pFeat, ProError status, ProAppData present_comps);
#endif