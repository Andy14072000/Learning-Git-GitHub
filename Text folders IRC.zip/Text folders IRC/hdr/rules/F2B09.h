/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 04-01-2024	|	V1_0_0		| F2B09 - STEERING SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF2B09_H
#define IRF2B09_H
#include "InterfaceRule.h"

struct ComponentDataF2B09 {
	char name[PRO_NAME_SIZE];
	int id;
	ProMdlfileType comp_type = PRO_MDLFILE_ASSEMBLY;
};


class IRF2B09 : private InterfaceRule
{
public:
	// CTOR
	IRF2B09() = default;
	// METHODS
	int IRF2B09_002(ruleResult& final_res);
	int IRF2B09_003(ruleResult& final_res);
	int IRF2B09_004(ruleResult& final_res);

};

/*================== function Prototypes for F2B09-002 rule =====================*/
ProError PartNameAndIdVisitAction_(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError Measure_Action(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError Radio_Button_Action1(char* dialog, char* component, ProAppData data);
ProError Radio_Button_Action2(char* dialog, char* component, ProAppData data);
ProError createDatumPointsusingCSYS(Pro3dPnt pnt_arr[2], char* csysName);
ProError ruleDlgOKactionPrompt2(char* dialog, char* component, ProAppData data);
ProError ruleDlgOKactionPrompt1(char* dialog, char* component, ProAppData data);
ProError deleteDatumPointCreatedUsingCsys(char* dtmpoint_name);
ProError ruleDlgCloseAction1(char* dialog, char* component, ProAppData data);
ProError PartNameAndIdVisitAction_for_Clamps(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError DatumPointsVisitAction(ProGeomitem* p_handle, ProAppData app_data);

/*================== function Prototypes for F2B09-003 rule =====================*/
ProError select_action_IRF2B09003(char* dialog, char* component, ProAppData data);
ProError user_action_F2B09(ProFeature* p_feature, ProError status, ProAppData appdata);

/*================== function Prototypes for F2B09-004 rule =====================*/
ProError user_actionf2b09004(ProFeature* feature, ProError status, ProAppData appdata);
#endif
