/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 19-05-2023	|	V1_0_0		| F5A01 - BRAKING SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF5A01_H
#define IRF5A01_H

#include "InterfaceRule.h"

struct BrakeDrumTonnage {
	string CapacityTon;
	int Diainmm;
};

struct remark_info
{
	char name_1[PRO_NAME_SIZE];
	char name_2[PRO_NAME_SIZE];
	string desc_1;
	string desc_2;
	string status;
	double dis_info;
	string actual_clearance;
	int re_id1;
	int re_id2;
	ProSelection sel_1;
	ProSelection sel_2;

};

struct SelectionStruct {
	ProSelection p_selection{};
	char         Description[PRO_PATH_SIZE]{};
	char         Name[PRO_PATH_SIZE]{};
	int          FeatId{};
	bool         Flag = false;
};
struct FeatureIDdataStr {
	int level{};
	int feat_ids[10]{};
};

struct f5A01_AsmModelStr {
	ProMdl  Model{};
	int	    Model_feat_id{};
};

struct Asm_model1_F5A01 {
	ProMdl		Model;
	int			Model_feat_id;
	int         Part_feat_id;
};

struct feat_id_data1_F5A01 {
	int 		    level;
	int				feat_ids[10];
};

struct pathVariables_F5A01 {
	vector<int> table_num_Vector;
	vector<vector<int>> comp_id_table_vector;
};

class IRF5A01 : private InterfaceRule
{
public:
	// CTOR
	//IRF5A01();

	// METHODS
	int IRF5A01_001(ruleResult& final_res);
	int IRF5A01_004(ruleResult &final_res);
	//int IRF5A01_005(ruleResult &final_res);
	int IRF5A01_006(ruleResult& final_res);
	int IRF5A01_007(ruleResult& final_res);
	int IRF5A01_011(ruleResult& final_res);
};
ProError user_actionf5A01006(ProFeature* feature, ProError status, ProAppData appdata);
ProError F5A01_descget(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError ruleDlgCloseActionf5a01011(char* dialog, char* component, ProAppData data);
ProError ruleDlgOKactionf5a01011(char* dialog, char* component, ProAppData data);
ProError user_action_F5A01(ProFeature* p_feature, ProError status, ProAppData appdata);
string remSpacesAtBothEnds_F5A01(const string& str);
//ProError measure_action_IR_F5A01_005(char* dialog, char* component);
ProError Dropdown_action_IRF5A01007(char* dialog, char* component);
ProError select_action_IRF5A01007(char* dialog, char* component, ProAppData data);
ProError optionMenuImageChangeActionf5A01_load(char* dialog, char* component, ProAppData data);
ProError select_action_IRF5A01_011(char* dialog, char* component, ProAppData data);
void option_menuF5a01(char* dialog, vector<string> option_menulist, char* optionmenu);
ProError UserAsmCompFilterf5a01(ProFeature* feature, ProAppData app_data);
ProError optionMenuImageChangeActionf5A01_category(char* dialog, char* component, ProAppData data);
ProError Geom_visit_action(ProGeomitem geom, ProError status, ProAppData app_data);
ProError Geom_filter_action(ProFeature feature, ProAppData app_data);
ProError surfVisitAction1(ProSurface surface, ProError status, vector<surfaceData>* cylSurfaces);
#endif