/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-03-2023	|	V1_0_0		| F5A01 - BRAKING SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF1D01_H
#define IRF1D01_H

#include "InterfaceRule.h"

struct  Surface_Info {
	int             surface_id{};
	int             Mdl_id{};
	char            Mdl_name[PRO_PATH_SIZE];
	char            Mdl_Desc[PRO_PATH_SIZE];
	ProSelection    Edge_Sel{};
};

struct ClampSelectionStruct {
	ProSelection p_selection{};
	char         Description[PRO_PATH_SIZE]{};
	char         Name[PRO_PATH_SIZE]{};
	int          FeatId{};
	bool         Flag = false;
};

class IRF1D01 : private InterfaceRule
{
public:
	// CTOR
	IRF1D01() = default;

	// METHODS
	int IRF1D01_007(ruleResult& final_res);
	int IRF1D01_003(ruleResult& final_res);
	int IRF1D01_001(ruleResult& final_res);
	int IRF1D01_006(ruleResult& final_res);
	int IRF1D01_009(ruleResult& final_res);

};
ProError ClampNameAndIdVisitAction(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError Select_cb_action(char* dialog, char* component, ProAppData app_data);
ProError ClampSelectionDlgCloseaction(char* dialog, char* component, ProAppData data);
ProError ClampSelectionDlgOKaction(char* dialog, char* component, ProAppData data);
ProError select_action_IRF5A01_004(char* dialog, char* component, ProAppData data);
ProError select_action_IRF1D01001_surf(char* dialog, char* component, ProAppData data);
ProError select_action_IRF1D01001_axis(char* dialog, char* component, ProAppData data);
ProError run_action_IRF1D01001(char* dialog, char* component, ProAppData data);

ProError select_action_IRF1D01_006(char* dialog, char* component, ProAppData data);
bool is_alphanumeric_and_space(const string& str);
ProError getParameterDescAndPartname_F1D01_007(ProFeature* p_feature, ProError status, ProAppData app_data);
#endif