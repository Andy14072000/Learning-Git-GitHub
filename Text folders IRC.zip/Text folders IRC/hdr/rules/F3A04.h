/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F3A04 - FUEL SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF3A04_H
#define IRF3A04_H

#include "InterfaceRule.h"

class IRF3A04 : private InterfaceRule
{
public:
	// CTOR
	IRF3A04() = default;

	// METHODS
	//int IRF3A04_001(ruleResult &final_res);
};

#endif