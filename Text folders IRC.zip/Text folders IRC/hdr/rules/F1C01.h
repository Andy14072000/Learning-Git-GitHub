/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F1C01 - PNEUMATIC SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF1C01_H
#define IRF1C01_H

#include "InterfaceRule.h"

class IRF1C01 : private InterfaceRule
{
public:
	// CTOR
	IRF1C01() = default;

	// METHODS
	int IRF1C01_006(ruleResult &final_res);
private:
	vector<int> reqValsFromCsv;
	SubModuleInfo _reqSMinfo;
};
ProError visit11DigitFasteners(ProFeature* p_feature, ProError status, ProAppData appD);

#endif