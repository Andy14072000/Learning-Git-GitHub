
/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
Surendra Sarode	| 27-02-2024	|	V1_0_0		| H1A11 - Engine - Cooling System
==================================================================================================================*/
#pragma once
#ifndef IRH1A11_H
#define IRH1A11_H

#include "InterfaceRule.h"

//class IRH1A11 : private InterfaceRule
//{
//public:
//	// CTOR
//	IRH1A11() = default;
//
//	// METHODS
//	int IRH1A14_003(ruleResult& final_res);
//};
//
//// Function prototypes
//ProError select_action_IRH1A11_001(char* dialog, char* component, ProAppData data);
#endif