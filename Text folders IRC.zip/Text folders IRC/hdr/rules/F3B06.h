/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F3B06 - EXHAUST SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF3B06_H
#define IRF3B06_H

#include "InterfaceRule.h"

class IRF3B06 : private InterfaceRule
{
public:
	// CTOR
	IRF3B06() = default;

	// METHODS
	int IRF3B06_003(ruleResult& final_res);
	//int IRF3B06_004(ruleResult& final_res);
private:
	SubModuleInfo _reqSMinfo;
};

//ProError inputValue(char* dialog, char* component, ProAppData data);

ProError input(char* dialog, char* component, ProAppData data);
bool foundDouble(const string& str);
#endif
