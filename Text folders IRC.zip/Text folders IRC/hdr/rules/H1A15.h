/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	|  10-03-2024	|	V1_0_0		| H1A15 - ENGINE ASSY
==================================================================================================================*/
#pragma once
#ifndef IRH1A15_H
#define IRH1A15_H

#include "InterfaceRule.h"

class IRH1A15 : private InterfaceRule
{
public:
	// CTOR
	IRH1A15() = default;

	// METHODS
	//int IRH1A15_006(ruleResult& final_res);
	int IRH1A15_001(ruleResult& final_res);
};

ProError select_action_IRH1A15_006(char* dialog, char* component, ProAppData data);
ProError user_actionIRH1A15_001(ProFeature* feature, ProError status, ProAppData appdata);
ProError UserAsmCompFilterIRH1A15_001(ProFeature* feature, ProAppData app_data);
ProError ruleDlgOKactionH1A15(char* dialog, char* component, ProAppData data);
std::string trimH1A15(const std::string& strH1A15);
ProError select_action_IRH1A15_001(char* dialog, char* component, ProAppData data);
string doubleToStringH1A15(double value);
ProError inputValue_Param(char* dialog, char* component, vector<string>* offsetValVec);
ProError ruleDlgOKaction_H1A15_001(char* dialog, char* component, ProAppData data);
ProError Dropdown_action_IRH1A15_001(char* dialog, char* component);
ProError Optionmenu_Create(vector<string>value, char* optionmenu);
ProError UILabeltextget_H1A15(char* dialog, char* component, vector<string>value);
void Create_CSV_H1A15_001(const string& file_Path, const vector<string>& vector1_name, const vector<string>& vector2_name);
int Parameter_Verfication();
int create_table(vector<string>value1, vector<string>value2);
#endif
