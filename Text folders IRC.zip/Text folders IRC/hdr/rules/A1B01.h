/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 18-04-2023	| V1_0_0		| A1B01 - CARGO BODY RULES
==================================================================================================================*/
#pragma once
#ifndef IRA1B01_H
#define IRA1B01_H 

#include "InterfaceRule.h"

class IRA1B01 : private InterfaceRule
{
public:
	// CTOR
	IRA1B01() = default;

	// METHODS
	int IRA1B01_005(ruleResult &final_res);
	int IRA1B01_007(ruleResult& final_res);

private:
	SubModuleInfo _reqSMinfo;
};

ProError select_action_IRA1B01_005(char* dialog, char* component, ProAppData data);

//manual A1B01_007
ProError selectActionA1B01_007(char* dialog, char* component, ProAppData appD);
ProError selectActionA1B01_007_2(char* dialog, char* component, ProAppData appD);
ProError asm_retrieve_callback(ProFeature* p_feature, ProError status, ProAppData app_data);
#endif