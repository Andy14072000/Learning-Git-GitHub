/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 19-05-2023	|	V1_0_0		| F5A10 - BRAKING SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF5A10_H
#define IRF5A10_H

#include "InterfaceRule.h"

class IRF5A10 : private InterfaceRule
{
public:
	// CTOR
	//IRF5A10();

	// METHODS
	int IRF5A10_001(ruleResult& final_res);
	int IRF5A10_007(ruleResult &final_res);
};

ProError select_action_IRF5A10_007(char* dialog, char* component, ProAppData data);

ProError UserAsmCompFilterf5a10001(ProFeature* feature, ProAppData app_data);
ProError user_actionf5a10001(ProFeature* feature, ProError status, ProAppData appdata);
ProError ruleDlgOKactionf5a10001(char* dialog, char* component, ProAppData data);
int createDatumPointsF5A10001(Pro3dPnt pnt_arr[2], char* csysName);
void Clear_Memory_F5A10001();
#endif