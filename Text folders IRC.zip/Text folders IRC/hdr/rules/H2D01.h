/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| H2D01 - REAR AXLE
==================================================================================================================*/
#pragma once
#ifndef IRH2D01_H
#define IRH2D01_H

#include "InterfaceRule.h"
#include <regex>

//struct surfaceData {
//	ProSurface surface;
//	ProMdl parentMdl;
//	ProEdge edge;
//	double diameter;
//	int id;
//	//int idTable;
//	ProAsmcomppath path;
//	ProModelitem modelItem;
//	ProSelection edgeSel;
//};


class IRH2D01 : private InterfaceRule
{
public:
	// CTOR
	IRH2D01() = default;

	// METHODS
	int IRH2D01_001(ruleResult& final_res);
	int IRH2D01_002(ruleResult& final_res);
	int IRH2D01_003(ruleResult& final_res);

private:
	SubModuleInfo _reqSMinfo;
};
ProError select_action_IRH2D01001(char* dialog, char* component, ProAppData data);
ProError run_action_IRH2D01001(char* dialog, char* component, ProAppData data);
ProError optionMenuSelectAction1_H2D01(char* dialog, char* component, ProAppData data);
ProError optionMenuSelectAction_PF_H2D01(char* dialog, char* component, ProAppData data);
ProError optionMenuSelectAction_RAF_H2D01(char* dialog, char* component, ProAppData data);
void ruleVerificationFunction(bool method1);
ProError visitActionH2D01(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError surfVisitAction(ProSurface surface, ProError status, vector<surfaceData>* cylSurfaces);
ProError selectAction_H2D01(char* dialog, char* component, ProAppData data);

ProError select_action_IRH2D01003(char* dialog, char* component, ProAppData data);
ProError run_action_IRH2D01003(char* dialog, char* component, ProAppData data);
#endif