/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	| V1_0_0		| F5A24 - BRAKING SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF5A24_H
#define IRF5A24_H

#include "InterfaceRule.h"

class IRF5A24 : private InterfaceRule
{
public:
	// CTOR
	IRF5A24() = default;

	// METHODS
	int IRF5A24_001(ruleResult& final_res);
private:
	//vector<int> reqValsFromCsv;
	SubModuleInfo _reqSMinfo;
};
ProError CompVisitAction_IRF5A24_006(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError MeasureAngleBetPln(ProSelection& sel_surf1, ProSelection& sel_surf2, double& angle);
ProError select_action_IRF5A24_006(char* dialog, char* component);
#endif
