/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
ATHARVA PATIL	| 07-06-2023	|	V1_0_0		| IRF1C02 - PNEUMATIC SYSTEMS RULE
==================================================================================================================*/

#pragma once
#ifndef IRF1C02_H
#define IRF1C02_H

#include "InterfaceRule.h"
#include <iostream>
#include <string>
#include <ProParameter.h>
#include <algorithm>
#include <regex>
#include <map>

struct nonStdHwComps {
	string compName;
	double gradeDb;
};

struct Model_Tree_Information_F1C02
{
	string sub_mod_name;
	string name;
	int ID;
	string description;
	vector<int> ID_path;
	int ID_table_size;
	double distance;
	bool HS_found = false;
	bool isGreaterThan200f1c02_004 = false;
};

class IRF1C02 : private InterfaceRule
{
public:
	// CTOR
	IRF1C02() = default;

	// METHODS
	int IRF1C02_001(ruleResult& final_res);
	int IRF1C02_004(ruleResult& final_res);
	int IRF1C02_006(ruleResult& final_res);

private:
	SubModuleInfo _reqSMinfo;
};
/*======================== Function prototypes for F1C02-004 rule ==========================*/
ProError optionMenuImageChangeActionf1c02(char* dialog, char* component, ProAppData data);
ProError select_action_IR_F1C02_004(char* dialog, char* component, ProAppData data);
ProError ruleDlgOKactionf1c02(char* dialog, char* component, ProAppData data);



/*======================== Function prototypes for F1C02-006 rule ==========================*/
ProError PartNameAndIdVisitAction(ProFeature* p_feature, ProError status, ProAppData app_data);
#endif