/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-03-2023	|	V1_0_0		| F5B01 - WHEELS AND TYRES RULES
==================================================================================================================*/
#pragma once
#ifndef IRF5B01_H
#define IRF5B01_H

#include "InterfaceRule.h"

class compdata_IRF5B01_008 {
public:
	ProSelection		compsel{};
	int					ID{};
	char				name[PRO_PATH_SIZE]{};
	char				Description[PRO_PATH_SIZE]{};
	ProCharLine			type{};
	int					Comp_Feat_ID{};
	ProAsmcomppath		comp_path{};
};

class Clearances_class_IR_F5B01_008 {
public:
	ProSelection		Component_selection{};
	double				clearance{};
};

//struct ThreeDPnt {
//	Pro3dPnt pnt_arr1[2]{};
//};

class IRF5B01 : private InterfaceRule
{
public:
	// CTOR
	IRF5B01() = default;

	// METHODS
	
	int IRF5B01_001(ruleResult &final_res);
	int IRF5B01_002(ruleResult& final_res);
	int IRF5B01_006(ruleResult& final_res);
	int IRF5B01_008(ruleResult& final_res);
	
};
ProError select_IRF5B01_001(char* dialog, char* component, ProAppData data);

ProError selectActionF5B01_006(char* dialog, char* component, ProAppData data);

ProError select_action_IRF5B01_008_Drum(char* dialog, char* component, ProAppData data);
ProError select_action_IRF5B01_008_Disc(char* dialog, char* component, ProAppData data);
ProError PartNameAndIdVisitAction01(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError ruleDlgOKaction_for_F5B01_008(char* dialog, char* component, ProAppData data);
#endif