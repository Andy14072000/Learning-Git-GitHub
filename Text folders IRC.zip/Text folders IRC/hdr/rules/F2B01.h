/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 19-05-2023	|	V1_0_0		| F2B01 - STEERING SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF2B01_H
#define IRF2B01_H

#include "InterfaceRule.h"

struct NumaticPipeData {
	char name[PRO_NAME_SIZE];
	char description[PRO_NAME_SIZE];
};
struct SterClmData {
	char name[PRO_NAME_SIZE];
	char description[PRO_NAME_SIZE];
};

class IRF2B01 : private InterfaceRule
{
public:
	// CTOR
	//IRF2B01();

	// METHODS
	int IRF2B01_001(ruleResult &final_res);
	int IRF2B01_002(ruleResult& final_res);
	int IRF2B01_003(ruleResult& final_res);
};
ProError select_action_IRF2B01001(char* dialog, char* component, ProAppData data);

ProError getVisitedCompAsmNamesAction_F2B01(ProFeature* p_feature, ProError status, ProAppData app_data);
int createDatumPointsF2B01005(Pro3dPnt pnt_arr[2], char* csysName);

int measureDistanceBetweenComponentsF2B01002(ComponentData reqComp1, ComponentData reqComp2, double& distance, Pro3dPnt(&pnt_arr)[2]);
ProError select_action_IRF2B01002(char* dialog, char* component, ProAppData data);
ProError rg_select_action_IRF2B01002(char* dialog, char* component, ProAppData data);
#endif