/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-04-2023	|	V1_0_0		| F4A02 - FRONT SUSPENSION RULES
==================================================================================================================*/
#pragma once
#ifndef IRF4A02_H
#define IRF4A02_H

#include "InterfaceRule.h"

class IRF4A02 : private InterfaceRule
{
public:
	// CTOR
	IRF4A02() = default;

	// METHODS
	int IRF4A02_001(ruleResult &final_res);
	int IRF4A02_003(ruleResult &final_res);
	int IRF4A02_002(ruleResult &final_res);
	int IRF4A02_005(ruleResult& final_res);

private:
	vector<int> reqValsFromCsv;
	SubModuleInfo _reqSMinfo;
};
/*--------------- function prototypes for F4A02-001 rule -------------------------*/
ProError getSelectedTypeOpMenuf4a02(char* dialog, char* component, ProAppData data);
ProError optionMenuImageChangeActionf4a02(char* dialog, char* component, ProAppData data);
ProError getParameterDescAndPartname_F4A02_001(ProFeature* p_feature, ProError status, ProAppData app_data);

/*--------------- function prototypes for F4A02-002 rule -------------------------*/
ProError user_actionF4A02002(ProFeature* feature, ProError status, ProAppData appdata);
ProError select_action_IRF4A02002(char* dialog, char* component, ProAppData data);
ProError ruleDlgCloseActionF4A02002(char* dialog, char* component, ProAppData data);
ProError ruleDlgOKactionF4A02002(char* dialog, char* component, ProAppData data);
ProError select_action_IRF4A02002(char* dialog, char* component, ProAppData data);
ProError get_selected_option_f4a02002(char* dialog, char* component, ProAppData data);
void Clear_Memory_F4A02002();


/*--------------- function prototypes for F4A02-003 rule -------------------------*/
ProError optionMenuImageChangeAction_F4A02003(char* dialog, char* component, ProAppData data);
ProError select_action_IRF4A02003(char* dialog, char* component, ProAppData data);
ProError run_action_IRF4A02003(char* dialog, char* component, ProAppData data);
ProError getVisiblePlanesF4A02(ProFeature* pFeat, ProError status, vector<planeData>* datumPlaneNames);

/*--------------- function prototypes for F4A02-005 rule -------------------------*/
ProError run_action_IRF4A02005(char* dialog, char* component, ProAppData data);
ProError optionMenuImageChangeAction_F4A02005(char* dialog, char* component, ProAppData data);
ProError select_action_IRF4A02005(char* dialog, char* component, ProAppData data);
#endif