/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 18-04-2023	| V1_0_0		| F5A17 - BRAKING SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF5A17_H
#define IRF5A17_H

#include "InterfaceRule.h"

struct output_vals {
	char name[PRO_NAME_SIZE];
	double Distance;
};

class IRF5A17 : private InterfaceRule
{
public:
	// CTOR
	IRF5A17() = default;

	// METHODS
	int IRF5A17_001(ruleResult &final_res);
	int IRF5A17_003(ruleResult& final_res);
	int IRF5A17_004(ruleResult& final_res);

};
ProError measure_action_IR_F5A17_001(char* dialog, char* component, ProAppData data);
int measureDistanceBetweenComponentsF5A17(ComponentData reqComp1, ComponentData reqComp2, double& distance, Pro3dPnt(&pnt_arr)[2]);

ProError select_action_IRF5A17_003(char* dialog, char* component, ProAppData data);
#endif