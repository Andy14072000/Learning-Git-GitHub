#pragma once
#ifndef IRH1A14_H
#define IRH1A14_H

#include "InterfaceRule.h"

class IRH1A14 : private InterfaceRule
{
public:
	// CTOR
	IRH1A14() = default;

	// METHODS
	int IRH1A14_001(ruleResult& final_res);
	int IRH1A14_002(ruleResult& final_res);
	int IRH1A14_003(ruleResult& final_res);
	int IRH1A14_004(ruleResult& final_res);

private:

	vector<string> reqValsFromCsv;
	SubModuleInfo _reqSMinfo;
	bool breakForLoop = false;


};
ProError select_action_IRH1A06_001(char* dialog, char* component, ProAppData data);
//H1A14-002
ProError select_action_IRH1A14_002(char* dialog, char* component, ProAppData data);

ProError select_action_IRH1A11_001(char* dialog, char* component, ProAppData data);

ProError select_action_surface(char* dialog, char* component, ProAppData data);
ProError select_action_edge(char* dialog, char* component, ProAppData data);
#endif
