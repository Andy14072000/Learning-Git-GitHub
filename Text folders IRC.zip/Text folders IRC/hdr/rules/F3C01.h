#pragma once
/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
Mathanprasath A	| 06-09-2024	|	V1_0_0		| F3C01 - ENGINE MOUNTS
==================================================================================================================*/
#ifndef IRF3C01_H
#define IRF3C01_H

#include "InterfaceRule.h"

class IRF3C01 : private InterfaceRule
{
public:
	// CTOR
	//IRF3C03();

	// METHODS
	int IRF3C01_008(ruleResult& final_res);
private:
	SubModuleInfo _reqSMinfo;

};

//Prototype of functions
ProError select_action_IRF3C01_008_LH(char* dialog, char* component, ProAppData data);
ProError select_action_IRF3C01_008_RH(char* dialog, char* component, ProAppData data);
ProError OKaction_IRF3C01_008(char* dialog, char* component, ProAppData data);
string doubleToStringf3c01(double value);

#endif