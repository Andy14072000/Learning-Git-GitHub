/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 19-05-2023	|	V1_0_0		| F1E02 - CHASIS CONTROLS
==================================================================================================================*/
#pragma once
#ifndef IRF1E05_H
#define IRF1E05_H

#include "InterfaceRule.h"

class IRF1E05 : private InterfaceRule
{
public:
	// CTOR
	//IRF1E05();

	// METHODS
	int IRF1E05_001(ruleResult& final_res);
};
ProError getSubModuleDes(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError rg_select_action_IRF1E05_001(char* dialog, char* component, ProAppData data);
void option_menuF1E05001(vector<string> option_menulist, char* optionmenu);
ProError boosterDiaVal(char* dialog, char* component, ProAppData data);
ProError slaveCylinderDiaVal(char* dialog, char* component, ProAppData data);
ProError clutchDiaVal(char* dialog, char* component, ProAppData data);
ProError releasedLoadVal(char* dialog, char* component, ProAppData data);
void getengineCapdatafromcsvF1E05001(vector<vector<string>> dbList2D_F3A01, string platformName, vector<string>& values);

#endif