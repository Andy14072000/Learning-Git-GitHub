#pragma once
#ifndef IRH2B01_H
#define IRH2B01_H

#include "InterfaceRule.h"
struct compdata_IRH2B01_001 {
    ProSelection		sel{};
    int					Selection_Feat_ID{};
    int					Comp_Feat_ID{};
    char				Comp_name[PRO_PATH_SIZE]{};
    char				Comp_Description[PRO_PATH_SIZE]{};
    ProCharLine			Comp_type{};
    ProAsmcomppath		comp_path{};
};


class IRH2B01 : private InterfaceRule
{
public:
	// CTOR
	IRH2B01() = default;

	// METHODS
    int IRH2B01_001(ruleResult& final_res);
	int IRH2B01_002(ruleResult& final_res);
	int IRH2B01_003(ruleResult& final_res);

};
ProError select_action_IR_H2B01_001(char* dialog, char* component, ProAppData data);

ProError select_action_IRH2B01_002(char* dialog, char* component, ProAppData data);

ProError select_action_IRH2B01003(char* dialog, char* component, ProAppData data);
ProError run_action_IRH2B01003(char* dialog, char* component, ProAppData data);
ProError measureDistanceBetweenSurfacesH2B01(ProSelection& sel_surf1, ProSelection& sel_surf2, double& distance_bw_surfs);
#endif