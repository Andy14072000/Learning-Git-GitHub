/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	|	V1_0_0		| F5A27 - BRAKING SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF5A27_H
#define IRF5A27_H

#include "InterfaceRule.h"

class IRF5A27 : private InterfaceRule
{
public:
	// CTOR
	IRF5A27() = default;

	// METHODS
	int IRF5A27_003(ruleResult& final_res);
	int IRF5A27_004(ruleResult &final_res);
	int IRF5A27_005(ruleResult& final_res);
	int IRF5A27_006(ruleResult &final_res);

private:
	SubModuleInfo _reqSMinfo;

};
ProError optionMenuImageChangeAction_F5A27_003(char* dialog, char* component, ProAppData data);
ProError getVisitedCompAsmNamesAndDescriptionTank(ProFeature* p_feature, ProError status, vector<PartnameDescriptionPair>* compList);

ProError select_action_IRF5A27004(char* dialog, char* component, ProAppData data);
ProError f5a27_004_optionMenuImageChangeAction(char* dialog, char* component, ProAppData data);

ProError select_action1_IR5A27005(char* dialog, char* component, ProAppData data);
ProError select_action2_IR5A27005(char* dialog, char* component, ProAppData data);
int measureDistanceBetweenASMandComponentIR5A27005(ProSelection& asm_sel, ComponentData reqComp2, double& distance, Pro3dPnt(&pnt_arr)[2]);
ProError getVisitedCompAsmNamesAction_F5A27005(ProFeature* p_feature, ProError status, ProAppData app_data);
int createDatumPointsIR5A27005(Pro3dPnt pnt_arr[2], char* csysName);

ProError f5a27ruleDlgOKaction(char* dialog, char* component, ProAppData data);

ProError user_actionf5a27006(ProFeature* feature, ProError status, ProAppData appdata);
ProError UserAsmCompFilterf5a27(ProFeature* feature, ProAppData app_data);
int createDatumPointsF5A27(Pro3dPnt pnt_arr[2], char* csysName);
ProError deleteDatumPointf5a27(char* dtmpoint_name);
ProError select_action_IRF5A27_006(char* dialog, char* component, ProAppData data);

#endif