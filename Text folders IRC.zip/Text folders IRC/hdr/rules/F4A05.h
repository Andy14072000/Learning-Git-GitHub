/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
Pallavi Garodi	| 14-06-2024	|	V1_0_0		| F4B05 - REAR SUSPENSION RULES
==================================================================================================================*/
#pragma once
#ifndef IRF4A05_H
#define IRF4A05_H

#include "InterfaceRule.h"

class IRF4A05 : private InterfaceRule
{
public:
	// CTOR
	IRF4A05() = default;

	// METHODS
	int IRF4A05_002(ruleResult& final_res);
	int IRF4A05_003(ruleResult& final_res);

private:
	SubModuleInfo _reqSMinfo;

};
ProError select_action_IRF4A05_003(char* dialog, char* component, ProAppData data);
ProError select_action1_IRF4A05002(char* dialog, char* component, ProAppData data);
//ProError CSV_values_fetch(char* file_name);
#endif
#pragma once
