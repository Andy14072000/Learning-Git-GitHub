/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F3B04 - EXHAUST SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF3B04_H
#define IRF3B04_H

#include "InterfaceRule.h"



class IRF3B04 : private InterfaceRule
{
public:
	// CTOR
	IRF3B04() = default;

	// METHODS
	int IRF3B04_001(ruleResult& final_res);
	

private:
	SubModuleInfo _reqSMinfo;
};

ProError getVisitedCompAsmNamesAndDescription_F3B04(ProFeature* p_feature, ProError status, vector<PartnameDescriptionPair>* compList);
ProError emissionNormsDDF3B04(char* dialog, char* component, ProAppData data);
#endif