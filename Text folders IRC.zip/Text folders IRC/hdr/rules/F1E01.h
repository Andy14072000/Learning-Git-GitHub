/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F1E01 - CHASIS CONTROLS
==================================================================================================================*/
#pragma once
#ifndef IRF1E01_H
#define IRF1E01_H

#include "InterfaceRule.h"
struct SelPartData {
	char name[PRO_NAME_SIZE];
	int id;
};

class IRF1E01 : private InterfaceRule
{
public:
	// CTOR
	IRF1E01() = default;

	// METHODS
	//int IRF1E01_001(ruleResult &final_res);
	int IRF1E01_007(ruleResult &final_res);
};
ProError select_action_IRF1E01_007(char* dialog, char* component, ProAppData data);

#endif