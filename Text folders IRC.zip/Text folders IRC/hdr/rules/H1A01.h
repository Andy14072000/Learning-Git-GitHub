#pragma once
/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| H1A01 - ENGINE ASSY
==================================================================================================================*/
#pragma once
#ifndef IRH1A01_H
#define IRH1A01_H

#include "InterfaceRule.h"

class IRH1A01 : private InterfaceRule
{
public:
	// CTOR
	IRH1A01() = default;

	// METHODS
	int IRH1A01_014(ruleResult& final_res);
	//int IRH1A01_001(ruleResult& final_res);
	int IRH1A01_007(ruleResult& final_res);

private:

	vector<string> reqValsFromCsv;
	SubModuleInfo _reqSMinfo;
	bool breakForLoop = false;
};
ProError select_action_IRH1A01_014(char* dialog, char* component, ProAppData data);
ProError getasmnameH1A01007(ProFeature* p_feature, ProError status, ProAppData app_data);

//IR-H1A01-001
ProError select_action_surface(char* dialog, char* component, ProAppData data);
ProError select_action_edge(char* dialog, char* component, ProAppData data);
#endif
#pragma once
