/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-04-2023	|	V1_0_0		| F4B02 - REAR SUSPENSION RULES
==================================================================================================================*/
#pragma once
#ifndef IRF4B02_H
#define IRF4B02_H

#include "InterfaceRule.h"



class IRF4B02 : private InterfaceRule
{
public:
	// CTOR
	IRF4B02() = default;

	// METHODS
	int IRF4B02_001(ruleResult& final_res);
	int IRF4B02_002(ruleResult& final_res);
	int IRF4B02_003(ruleResult &final_res);
	int IRF4B02_005(ruleResult& final_res);
	
private:

	SubModuleInfo _reqSMinfo;
	//vector<int> reqValsFromCsv;
	

};
/*---------------------- Function prototypes for IR-F4B02-001 -------------------------------*/
ProError getSelectedTypeOpMenuf4B02001(char* dialog, char* component, ProAppData data);
ProError optionMenuImageChangeActionf4B02001(char* dialog, char* component, ProAppData data);
ProError getParameterDescAndPartnameF4B02001(ProFeature* p_feature, ProError status, ProAppData app_data);

/*--------------- function prototypes for F4B02-002 rule -------------------------*/
ProError user_actionF4B02002(ProFeature* feature, ProError status, ProAppData appdata);
ProError select_action_IRF4B02002(char* dialog, char* component, ProAppData data);
ProError ruleDlgCloseActionF4B02002(char* dialog, char* component, ProAppData data);
ProError ruleDlgOKactionF4B02002(char* dialog, char* component, ProAppData data);
ProError select_action_IRF4B02002(char* dialog, char* component, ProAppData data);
ProError get_selected_option_f4b02002(char* dialog, char* component, ProAppData data);
void Clear_Memory_F4B02002();


/*---------------------- Function prototypes for IR-F4B02-003 -------------------------------*/
ProError optionMenuImageChangeAction_F4B02003(char* dialog, char* component, ProAppData data);
ProError run_action_IRF4B02003(char* dialog, char* component, ProAppData data);
ProError select_action_IRF4B02003(char* dialog, char* component, ProAppData data);
ProError getVisiblePlanes(ProFeature* pFeat, ProError status, vector<planeData>* datumPlaneNames);

ProError select_action_IRF4B02005(char* dialog, char* component, ProAppData data);
ProError optionMenuImageChangeAction_F4B02005(char* dialog, char* component, ProAppData data);
ProError run_action_IRF4B02005(char* dialog, char* component, ProAppData data);


#endif