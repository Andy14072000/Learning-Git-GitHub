#pragma once
/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-04-2023	|	V1_0_0		| F4A02 - REAR SUSPENSION RULES
==================================================================================================================*/
#pragma once
#ifndef IRF4A04_H
#define IRF4A04_H

#include "InterfaceRule.h"

class IRF4A04 : private InterfaceRule
{
public:
	// CTOR
	IRF4A04() = default;

	// METHODS
	int IRF4A04_002(ruleResult& final_res);
private:
	SubModuleInfo _reqSMinfo;

};
ProError select_action_IRF4A04_002(char* dialog, char* component, ProAppData data);
ProError select_action_IRF4A04_002_2(char* dialog, char* component, ProAppData data);

#endif