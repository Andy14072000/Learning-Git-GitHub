/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 19-05-2023	|	V1_0_0		| F2B04 - STEERING SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF2B04_H
#define IRF2B04_H

#include "InterfaceRule.h"

class IRF2B04 : private InterfaceRule
{
public:
	// CTOR
	//IRF2B04();

	// METHODS
	int IRF2B04_005(ruleResult &final_res);
	int IRF2B04_009(ruleResult &final_res);
	int IRF2B04_006(ruleResult &final_res);
};
#endif