#pragma once
#ifndef IRF2A04_H
#define IRF2A04_H

#include "InterfaceRule.h"

class IRF2A04 : private InterfaceRule
{
public:
	// CTOR
	IRF2A04() = default;

	// METHODS
	int IRF2A04_001(ruleResult& final_res);
	int IRF2A04_002(ruleResult& final_res);
};
ProError select_action1_IRF2A04001(char* dialog, char* component, ProAppData data);
ProError select_action2_IRF2A04001(char* dialog, char* component, ProAppData data);
ProError select_action3_IRF2A04001(char* dialog, char* component, ProAppData data);
ProError measure_action_IRF2A04001(char* dialog, char* component, ProAppData data);

ProError select_action1_IRF2A04002(char* dialog, char* component, ProAppData data);
ProError select_action2_IRF2A04002(char* dialog, char* component, ProAppData data);
ProError measure_action_IRF2A04002(char* dialog, char* component, ProAppData data);
#endif
