/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-03-2023	|	V1_0_0		| F3B01 - EXHAUST SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF3B01_H
#define IRF3B01_H

#include "InterfaceRule.h"

class IRF3B01 : private InterfaceRule
{
public:
	// CTOR
	IRF3B01() = default;

	// METHODS
	//int IRF3B01_002(ruleResult &final_res);
	int IRF3B01_005(ruleResult& final_res);
	int IRF3B01_004(ruleResult& final_res);
private:
	//vector<int> reqValsFromCsv;
	vector<string> reqValsFromCsv;
	SubModuleInfo _reqSMinfo;
	bool breakForLoop = false;

};
ProError platformList_SA(char* dialog, char* component, ProAppData data);
ProError subplatformList_SA(char* dialog, char* component, ProAppData data);
void getPlatval_SA(vector<vector<string>> dbList2D_EP_F3A01, string platformName, vector<string>& values);
void option_menu_SA(vector<string> option_menulist, char* optionmenu);
void getGroundClearanceValsFromCsv_SA(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv);

ProError select_action_IRF3B01002(char* dialog, char* component, ProAppData data);
ProError run_action_IRF3B01002(char* dialog, char* component, ProAppData data);

#endif