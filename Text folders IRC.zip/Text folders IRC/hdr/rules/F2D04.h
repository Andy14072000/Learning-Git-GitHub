/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 15-04-2024	|	V1_0_0		| F2D04 - LIFT SUSPENSION
==================================================================================================================*/
#pragma once
#ifndef IRF2D04_H
#define IRF2D04_H

#include "InterfaceRule.h"

class IRF2D04 : private InterfaceRule
{
public:
	// CTOR
	IRF2D04() = default;

	// METHODS
	//int IRF2D04_002(ruleResult& final_res);
};
//ProError select_action_IRF2D04_002(char* dialog, char* component, ProAppData data);
//ProError createDatumPointsusingCSYS_IR_F2D04_002(Pro3dPnt pnt_arr[2], char* csysName);
//ProError deleteDatumPointCreatedUsingCsys_IR_F2D04_002(char* dtmpoint_name);

#endif