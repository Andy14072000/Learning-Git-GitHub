/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 19-05-2023	|	V1_0_0		| F2D01 - LIFT SUSPENSION
==================================================================================================================*/
#pragma once
#ifndef IRF2D01_H
#define IRF2D01_H

#include "InterfaceRule.h"

struct SurfDataF2D01002 {
	string part_name;
	int id;
};

class IRF2D01 : private InterfaceRule
{
public:
	// CTOR
	//IRF2D01();

	// METHODS
	int IRF2D01_002(ruleResult &final_res);
	int IRF2D01_010(ruleResult &final_res);
	int IRF2D01_017(ruleResult& final_res);
	int IRF2D01_014(ruleResult& final_res);
	int IRF2D01_015(ruleResult& final_res);
	int IRF2D01_018(ruleResult& final_res);
};
ProError select_action_IRF2D01_002(char* dialog, char* component, ProAppData data);
ProError f2D01_deleteDatumPoint();

ProError selectActionF2D01_014(char* dialog, char* component, ProAppData data);
int createDatumPointsF2D01_014(Pro3dPnt pnt_arr[2], char pointName[PRO_NAME_SIZE], char* csysName);

ProError select_action_tire_IRF2D01_015(char* dialog, char* component, ProAppData data);
ProError select_action_hangerbracket_IRF2D01_015(char* dialog, char* component, ProAppData data);

ProError selectActionF2D01_017(char* dialog, char* component, ProAppData appD);
ProError radioGrpSelectActionF2D01(char* dialog, char* component, ProAppData data);
ProError getParameterDescAndPartnameF2D01(ProFeature* p_feature, ProError status, ProAppData app_data);

ProError select_action_IRF2D04_002(char* dialog, char* component, ProAppData data);
ProError createDatumPointsusingCSYS_IR_F2D04_002(Pro3dPnt pnt_arr[2], char* csysName);
ProError deleteDatumPointCreatedUsingCsys_IR_F2D04_002(char* dtmpoint_name);
#endif