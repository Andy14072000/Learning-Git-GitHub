#pragma once
/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-03-2023	|	V1_0_0		| F3B03 - EXHAUST SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF3B03_H
#define IRF3B03_H
#include<stdio.h>
#include<stdlib.h>

#include "InterfaceRule.h"

class IRF3B03 : private InterfaceRule
{
public:
	// CTOR
	IRF3B03() = default;
	// METHODS
	int IRF3B03_002(ruleResult& final_res);
	int IRF3B03_005(ruleResult& final_res);
	int IRF3B03_006(ruleResult& final_res);

private:
	SubModuleInfo _reqSMinfo;
};
ProError select_surface_IRF3B03002(char* dialog, char* component, ProAppData data);


ProError platformList_EGP(char* dialog, char* component, ProAppData data);
ProError subplatformList_EGP(char* dialog, char* component, ProAppData data);
void getPlatval_EGP(vector<vector<string>> dbList2D_EP_F3A01, string platformName, vector<string>& values);
void option_menu_EGP(vector<string> option_menulist, char* optionmenu);
void getGroundClearanceValsFromCsv_EGP(char* csvFilename, int partNoIdx, int reqValIdx, string partNo, vector<string>& reqValsFromCsv);

#endif
#pragma once
