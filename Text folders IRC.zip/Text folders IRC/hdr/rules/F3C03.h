/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F3B04 - EXHAUST SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF3C03_H
#define IRF3C03_H

#include "InterfaceRule.h"

class IRF3C03 : private InterfaceRule
{
public:
	// CTOR
	IRF3C03() = default;

	// METHODS
	//int IRF3C03_003(ruleResult& final_res);
	int IRF3C03_004(ruleResult& final_res);
	int IRF3C03_010(ruleResult& final_res);
private:
	SubModuleInfo _reqSMinfo;

};
//ProError r_select_action_IRF3C03_003(char* dialog, char* component, ProAppData data);
//ProError X_direction_IRF3C03003(char* dialog, char* component, ProAppData data);
//ProError Y_Direction_IRF3C03003(char* dialog, char* component, ProAppData data);
//ProError Z_direction_IRF3C03003(char* dialog, char* component, ProAppData data);

//IRF3C03_004
ProError rg_select_action_IRF3C03_004(char* dialog, char* component, ProAppData data);
ProError select_action1_IRF3C03_004(char* dialog, char* component, ProAppData data);
ProError select_action2_IRF3C03_004(char* dialog, char* component, ProAppData data);
//string doubleToStringf3c03004(double value);

//IRF3C03_010
ProError select_action_IRF3C03_010_LH(char* dialog, char* component, ProAppData data);
ProError select_action_IRF3C03_010_RH(char* dialog, char* component, ProAppData data);
string doubleToStringf3c03(double value);

#endif
#pragma once
