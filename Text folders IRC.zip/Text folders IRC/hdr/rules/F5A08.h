/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	|	V1_0_0		| F5A08 - BRAKING SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF5A08_H
#define IRF5A08_H

#include "InterfaceRule.h"

class IRF5A08 : private InterfaceRule
{
public:
	// CTOR
	IRF5A08() = default;

	// METHODS
	int IRF5A08_005(ruleResult &final_res);
	int IRF5A08_007(ruleResult& final_res);
};
/*===================== Function prototypes for IR_F5A08_007 =======================*/
ProError optionMenu1DropDownActionF5A08(char* dialog, char* component, ProAppData data);
ProError optionMenu2DropDownActionF5A08(char* dialog, char* component, ProAppData data);
ProError searchInDescF5A08(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError ruleDlgOKactionf5a08005(char* dialog, char* component, ProAppData data);
ProError UserAsmCompFilterf5a08005(ProFeature* feature, ProAppData app_data);
ProError user_actionf5a08005(ProFeature* feature, ProError status, ProAppData appdata);
void Clear_Memory_F5A08005();
#endif