/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 20-07-2023	|	V1_0_0		| F5A07 - BRAKING SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF2B07_H
#define IRF2B07_H

#include "InterfaceRule.h"
//#include "AppFrontEnd.h"
class IRF2B07 : private InterfaceRule
{
public:
	// CTOR
	IRF2B07() = default;
	// METHODS
	int IRF2B07_006(ruleResult& final_res);
	int IRF2B07_008(ruleResult& final_res);
private:
	SubModuleInfo _reqSMinfo;

};
/*---------------------- function prototypes for IR-F2B07-006 ------------------------------*/
ProError visitActionF2B07_006(ProFeature* p_feature, ProError status, vector<ComponentIdTableData>* _reqComps);
int measureDistanceBetweenComponents_F2B07_006(ComponentIdTableData reqComp1, ComponentIdTableData reqComp2, double& distance, Pro3dPnt pntArr[2]);
ProError radioGrpSelectAction_F2B07_006(char* dialog, char* component, bool* booleanVal);
ProError selectActionManualMode_F2B07_006(char* dialog, char* component, vector<clearanceData>* vectorClearance);
int createDistHighlightDatumPoints_F2B07_006(Pro3dPnt pnt_arr[2], char pointName[PRO_NAME_SIZE], char* csysName);

int measureDistanceBetweenComponentsF2B07(ComponentData reqComp1, ComponentData reqComp2, double& distance, Pro3dPnt(&pnt_arr)[2]);
ProError select_action_IRF2B07008(char* dialog, char* component, ProAppData data);
ProError rg_select_action_IRF2B07008(char* dialog, char* component, ProAppData data);
#endif