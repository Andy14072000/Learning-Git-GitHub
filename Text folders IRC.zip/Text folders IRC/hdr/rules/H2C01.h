/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2024	|	V1_0_0		| H2C01 - Gear Box & Shifting
==================================================================================================================*/
#pragma once
#ifndef IRH2C01_H
#define IRH2C01_H

#include "InterfaceRule.h"
#include "F5A01.h"
#include <regex>

class IRH2C01 : private InterfaceRule
{
public:
	// CTOR
	IRH2C01() = default;

	// METHODS
	int IRH2C01_001(ruleResult& final_res);
	int IRH2C01_002(ruleResult& final_res);
private:
	SubModuleInfo _reqSMinfo;
};

//typedef struct user_appdata
//{
//	FILE* fp;
//	int level;
//} UserAppdata;

// Function prototypes H2C01-001
ProError selectAction__H2C01_001(char* dialog, char* component, ProAppData data);
ProError optionMenuSelectAction1__H2C01_001(char* dialog, char* component, ProAppData data);
ProError visitAction_H2C01_001(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError surfVisitAction_H2C01_001(ProSurface surface, ProError status, vector<surfaceData>* cylSurfaces);
void ruleVerificationFunction_H2C01();
ProError PCD_F2C01(ProSelection& sel_part);
ProError surfVisitAction_F2C01(ProSurface surface, ProError status, vector<surfaceData>* cylSurfaces);
ProError optionMenuSelectAction1__F2C01_001(char* dialog, char* component, ProAppData data);
ProError Bolt_selectAction__H2C01_001(char* dialog, char* component, ProAppData data);
ProError optionMenuSelectAction__bolt(char* dialog, char* component, ProAppData data);

// Function prototypes H2C01-002
ProError getPartnameAction(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError UserAsmCompFilter(ProFeature* feature, ProAppData app_data);

#endif