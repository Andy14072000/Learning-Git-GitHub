/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	|	V1_0_0		| F1E06 - CHASSIS CONTROLS RULES
==================================================================================================================*/
#pragma once
#ifndef IRF1E06_H
#define IRF1E06_H

#include "InterfaceRule.h"
struct surfaceData1 {
	ProSurface surface;
	ProMdl parentMdl;
	ProEdge edge;
	double diameter;
	int id;
	//int idTable;
	ProAsmcomppath path;
	ProModelitem modelItem;
	ProSelection edgeSel;
};


struct myStruct {
	ProModelitem mdlItem;
	ProAsmcomppath path;
	ProFeature pFeat;
	ProSelection sel;
};

class IRF1E06 : private InterfaceRule
{
public:
	// CTOR
	IRF1E06() = default;

	// METHODS
	int IRF1E06_005(ruleResult& final_res);
	//int IRF1E08007_getClearance(double &clearance, string *compNames);
};
ProError selectActionF1E06(char* dialog, char* component, ProAppData data);
ProError geomItemVisit(ProGeomitem* p_handle, ProError status, vector<edgeSel>* vectr);

#endif