/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F4A01 - FRONT SUSPENSION
==================================================================================================================*/
#pragma once
#ifndef IRF4A01_H
#define IRF4A01_H

#include "InterfaceRule.h"

struct leafSpringAttachment { //Mathan
	char part_name[PRO_PATH_SIZE];
	char description[PRO_PATH_SIZE];
	char MatType[PRO_NAME_SIZE];
	int barrel;
};

class IRF4A01 : private InterfaceRule
{
public:
	// CTOR
	IRF4A01() = default;

	// METHODS
	int IRF4A01_002(ruleResult &final_res);
};
ProError f4A01_getParameterDescAndPartname(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError Typeget(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError f4A02_getParameterDescAndPartname(ProFeature* p_feature, ProError status, ProAppData app_data);
bool comparePartName(const leafSpringAttachment& a, const leafSpringAttachment& b);
#endif