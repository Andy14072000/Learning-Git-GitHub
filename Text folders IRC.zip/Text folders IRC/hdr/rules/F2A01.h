/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 19-05-2023	|	V1_0_0		| F2A01 - FRONT AXLE/LIFT AXLE
==================================================================================================================*/
#pragma once
#ifndef IRF2A01_H
#define IRF2A01_H

#include "InterfaceRule.h"

class IRF2A01 : private InterfaceRule
{
public:
	// CTOR
	//IRF2A01();

	// METHODS
	int IRF2A01_001(ruleResult& final_res);
	int IRF2A01_005(ruleResult &final_res);
	int IRF2A01_002(ruleResult& final_res);
	int IRF2A01_006(ruleResult& final_res);
};
ProError select_action_IRF2A01_002(char* dialog, char* component, ProAppData data);

/*==================== function prototypes for IR_F2A01-005 =======================*/
ProError Clearance_Compute_Action_IR_F2A01_005(ComponentData reqComp1, ComponentData reqComp2, double& distance);
ProError measure_action_IR_F2A01_005(char* dialog, char* component);
ProError createDatumPointsusingCSYS_IR_F2A01_005(Pro3dPnt pnt_arr[2], char* csysName);
ProError deleteDatumPointCreatedUsingCsys_IR_F2A01_005(char* dtmpoint_name);
ProError ruleDlgOKaction_IR_F2A01_005(char* dialog, char* component, ProAppData data);
ProError ruleDlgCloseAction_IR_F2A01_005(char* dialog, char* component, ProAppData data);

/*==================== function prototypes for IR_F2A01-006 =======================*/
ProError select_action_IRF2A01_006(char* dialog, char* component, ProAppData data);
int measureDistanceBetweenAsmAndPart_IRF2A01_006(ComponentData reqComp1, ProSelection* Part_sel, double& distance);


ProError rg_select_action_IRF2A01_001(char* dialog, char* component, ProAppData data);
ProError selectHole_action_IRF2A01_001(char* dialog, char* component, ProAppData data);
ProError select_action_IRF2A01_001(char* dialog, char* component, ProAppData data);
string formatNumber(double number);
vector<string> formatNumbers(const vector<double>& numbers);

#endif