/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-04-2023	| V1_0_0		| A1A01 - TIPPER BODY RULES
==================================================================================================================*/
#pragma once
#ifndef IRA1A01_H
#define IRA1A01_H

#include "InterfaceRule.h"

class IRA1A01 : private InterfaceRule
{
public:
	// CTOR
	IRA1A01() = default;

	// METHODS
	int IRA1A01_006(ruleResult& final_res);
	int IRA1A01_007(ruleResult& final_res);
	int IRA1A01_002(ruleResult& final_res);

private:
	vector<int> reqValsFromCsv;
	SubModuleInfo _reqSMinfo;
};
ProError select_action_IRA1A01_006(char* dialog, char* component, ProAppData data);

/*------------------------- Declarations for IR-A1A01-007 -------------------------*/
ProError PartNameAndIdVisitAction_IRA1A01_007(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError getReqValsFrom2DCsvData_IRA1A01_007(int projCode, vector<string>& reqValsFromCsv);

/*------------------------- Declarations for IR-A1A01-002 -------------------------*/
ProError RH_select_action_IRA1A01_002(char* dialog, char* component, ProAppData data);
ProError LH_select_action_IRA1A01_002(char* dialog, char* component, ProAppData data);
ProError Dropdown_Selection_LH_1(char* dialog, char* component, ProAppData data);
ProError Dropdown_Selection_LH_2(char* dialog, char* component, ProAppData data);
ProError Dropdown_Selection_RH_1(char* dialog, char* component, ProAppData data);
ProError Dropdown_Selection_RH_2(char* dialog, char* component, ProAppData data);
ProError ruleDlgOKaction_A1A01_002(char* dialog, char* component, ProAppData data);
ProError ruleDlgCloseAction_A1A01_002(char* dialog, char* component, ProAppData data);

#endif