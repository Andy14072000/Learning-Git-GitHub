/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 18-04-2023	| V1_0_0		| F5A17 - BRAKING SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF2D03_H
#define IRF2D03_H

#include "InterfaceRule.h"

class IRF2D03 : private InterfaceRule
{
public:
	// CTOR
	IRF2D03() = default;

	// METHODS
	int IRF2D03_003(ruleResult& final_res);

};
ProError select_action_IR_F2D03_003(char* dialog, char* component, ProAppData data);
ProError ruleDlgOKactionf2d03_003(char* dialog, char* component, ProAppData data);
ProError ruleDlgCloseActionf2d03_003(char* dialog, char* component, ProAppData data);



#endif