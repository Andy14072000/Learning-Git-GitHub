#pragma once
/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-04-2023	|	V1_0_0		| F4B02 - REAR SUSPENSION RULES
==================================================================================================================*/
#pragma once
#ifndef IRF4B04_H
#define IRF4B04_H

#include "InterfaceRule.h"
struct planeData2 {
	char name[PRO_NAME_SIZE];
	ProMdl ownerMdl;
};


class IRF4B04 : private InterfaceRule
{
public:
	// CTOR
	IRF4B04() = default;

	// METHODS
	int IRF4B04_002(ruleResult& final_res);
	//int IRF4B04_003(ruleResult& final_res);
private:
	SubModuleInfo _reqSMinfo;

};
ProError select_action_IRF4B04_002(char* dialog, char* component, ProAppData data);
ProError select_action_IRF4B04_002_2(char* dialog, char* component, ProAppData data);

ProError select_action_IRF4B04003(char* dialog, char* component, ProAppData data);
ProError optionMenuImageChangeAction_F4B04003(char* dialog, char* component, ProAppData data);
ProError run_action_IRF4B04003(char* dialog, char* component, ProAppData data);

#endif