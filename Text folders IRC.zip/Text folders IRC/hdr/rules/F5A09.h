/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F5A09 - BRAKING SYSTEM
==================================================================================================================*/
#pragma once
#ifndef IRF5A09_H
#define IRF5A09_H

#include "InterfaceRule.h"

struct Point3D							//IRF5A09_003
{
	double x, y, z;
};

struct Line3D							//IRF5A09_003
{
	Point3D r0;  // Known point on the line
	Point3D v;   // Direction vector of the line
};

class IRF5A09 : private InterfaceRule
{
public:
	// CTOR
	IRF5A09() = default;

	// METHODS
	int IRF5A09_003(ruleResult &final_res);
};
/*========================= Function prototypes for IR_F5A09_003 =========================*/
int createDatumPoint(ProSelection edgeSelection, char cPointName[PRO_NAME_SIZE]);
ProError user_actionf5A09_003(ProFeature* feature, ProError status, ProAppData appdata);
ProError select_action_IRF5A09_003(char* dialog, char* component, ProAppData data);
ProError ruleDlgOKaction_IRF5A09_003(char* dialog, char* component, ProAppData data);
ProError deleteDatumPointf5a09(char* dtmpoint_name);
ProError createDatumPointsf5a09(Pro3dPnt pnt_arr, char* csysName);
int findPointC(double Ax, double Ay, double Az, double Bx, double By, double Bz, double dist, double C[]);
#endif