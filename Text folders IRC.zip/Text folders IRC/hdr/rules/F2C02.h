/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-07-2023	|	V1_0_0		| F2C02 - PROPELLER SHAFT
==================================================================================================================*/
#pragma once
#ifndef IRF2C02_H
#define IRF2C02_H

#include "InterfaceRule.h"

class IRF2C02 : private InterfaceRule
{
public:
	// CTOR
	IRF2C02() = default;

	// METHODS
	int IRF2C02_003(ruleResult &final_res);
};
int measureDistanceBetweenComponents_F2C02(ComponentIdTableData reqComp1, ComponentIdTableData reqComp2, double& distance, Pro3dPnt pntArr[2]);
ProError visitActionF2C02(ProFeature* p_feature, ProError status, vector<ComponentIdTableData>* _reqComps);
ProError radioGrpSelectAction_F2C02(char* dialog, char* component, bool* booleanVal);
ProError selectActionManualMode_F2C02(char* dialog, char* component, vector<clearanceData>* vectorClearance);
int createDistHighlightDatumPoints_F2C02_SP(Pro3dPnt pnt_arr, char pointName[PRO_NAME_SIZE], char* csysName);
#endif