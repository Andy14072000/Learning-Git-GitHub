/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
MATHANPRASATH A	| 24-07-2023	|	V1_0_0		| F4B05 - REAR SUSPENSION RULES
==================================================================================================================*/
#pragma once
#ifndef IRF4B05_H
#define IRF4B05_H

#include "InterfaceRule.h"
struct CompData_F4B05_002 {
	ProSelection    ProSelection;
	char            Name[PRO_PATH_SIZE];
	char            Description[PRO_PATH_SIZE];
	int             ID;
	char			Ext[PRO_NAME_SIZE];
};

class IRF4B05 : private InterfaceRule
{
public:
	// CTOR
	IRF4B05() = default;

	// METHODS
	int IRF4B05_002(ruleResult& final_res);
	int IRF4B05_003(ruleResult& final_res);

private:
	SubModuleInfo _reqSMinfo;

};
ProError select_action_IRF4B05_003(char* dialog, char* component, ProAppData data);
ProError CSV_values_fetch(char* file_name);
ProError select_action_IRF4B05_002(char* dialog, char* component, ProAppData data);
#endif