/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 20-07-2023	|	V1_0_0		| F5A07 - BRAKING SYSTEM RULES
==================================================================================================================*/
#pragma once
#ifndef IRF5A07_H
#define IRF5A07_H

#include "InterfaceRule.h"

class IRF5A07 : private InterfaceRule
{
public:
	// CTOR
	IRF5A07() = default;
	// METHODS
	int IRF5A07_001(ruleResult& final_res);
	int IRF5A07_002(ruleResult& final_res);
	int IRF5A07_008(ruleResult& final_res);
private:
	SubModuleInfo _reqSMinfo;

};
ProError selectActionF5A07_001(char* dialog, char* component, ProAppData data);
int createDatumPointsF5A07_001(Pro3dPnt pnt_arr[2], char pointName[PRO_NAME_SIZE], char* csysName);

ProError select_action_IRF5A07_002(char* dialog, char* component, ProAppData data);
ProError Measure_action_IRF5A07_002(char* dialog, char* component, ProAppData data);

ProError Datumplanebypoint(ProSelection& sel_1, char* outputPlaneName);
ProError measureDistanceBetweenSurfaces_F5A07_008(ProSelection& sel_surf1, ProBoolean option1, ProSelection& sel_surf2, ProBoolean option2, double& distance_bw_surfs);
int createOffsetPlaneWithReference_F5A07_008(ProSelection refSelection, double offsetValue, char* outputPlaneName);
int measureDistanceBetweenPlaneAndComp_F5A07_008(ProSelection planeSel, ComponentData reqComp1, double& distance, Pro3dPnt pntArr[2]);
ProError inputValue_angle(char* dialog, char* component, vector<double>* offsetValVec);
double wideStringToDouble(const std::wstring& wideStr);
ProError refSurfSelections_frame(char* dialog, char* component, vector<selectionInfo>* ownerDetails);
ProError refSurfSelections_F5A07(char* dialog, char* component, vector<selectionInfo>* ownerDetails);
#endif
