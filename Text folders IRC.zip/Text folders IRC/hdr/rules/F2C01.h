#pragma once
#ifndef IRF2C01_H
#define IRF2C01_H
#include <cmath>
#include "InterfaceRule.h"

struct Asm_model1 {
	ProMdl		Model;
	int			Model_feat_id;
	int         Part_feat_id;
};

struct PartNames1
{
	char part_name[PRO_NAME_SIZE];
	char description[PRO_PATH_SIZE];
};

struct feat_id_data1 {
	int 		    level;
	int				feat_ids[10];
};

//struct pathVariables {
//	vector<int> table_num_Vector;
//	vector<vector<int>> comp_id_table_vector;
//};

//F1A01
struct Asm_model_F1A01 {
	ProMdl		Model;
	int			Model_feat_id;
	int         Part_feat_id;
};

struct PartNames_F1A01
{
	char part_name[PRO_NAME_SIZE];
	char description[PRO_PATH_SIZE];
};

struct feat_id_data_F1A01 {
	int 		    level;
	int				feat_ids[10];
};

//F2C01
struct Asm_model_F2C01 {
	ProMdl		Model;
	int			Model_feat_id;
	int         Part_feat_id;
};

struct PartNames_F2C01
{
	char part_name[PRO_NAME_SIZE];
	char description[PRO_PATH_SIZE];
};

struct feat_id_data_F2C01 {
	int 		    level;
	int				feat_ids[10];
};


struct PartnameDescriptionPairF2C01 {		// Prajakta
	char part_name[PRO_NAME_SIZE];
	char description[PRO_NAME_SIZE];
};

struct vals {
	char name[PRO_NAME_SIZE];
	double Distance;
	char description[PRO_PATH_SIZE];
};

class IRF2C01 : private InterfaceRule
{
public:
	// CTOR
	IRF2C01() = default;

	// METHODS
	int IRF2C01_003(ruleResult& final_res);
	int IRF2C01_008(ruleResult& final_res);
	int IRF2C01_011(ruleResult& final_res);
	int IRF2C01_012(ruleResult& final_res);
	int IRF2C01_016(ruleResult& final_res);
	int IRF2C01_017(ruleResult& final_res);
	int IRF2C01_020(ruleResult& final_res);
	int IRF2C01_013(ruleResult& final_res);
	int IRF2C01_019(ruleResult& final_res);

private:
	vector<int> reqValsFromCsv;
	SubModuleInfo _reqSMinfo;
};
ProError select_action_IRF2C01_003(char* dialog, char* component, ProAppData data);
ProError NameAndIdVisitAction(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError selection_action_IRF2C01_008(char* dialog, char* component, ProAppData data);
ProError Nomcltre_sel();
ProError Nomcltre_Sel_Alloc();
ProError selection_action_IRF2C01_011(char* dialog, char* component, ProAppData data);

ProError ruleDlgCloseAction_F2C01_016(char* dialog, char* component, ProAppData data);
ProError ruleDlgOKaction_F2C01_016(char* dialog, char* component, ProAppData data);
ProError select_action_IRF2C01_016(char* dialog, char* component, ProAppData data);
ProError rg_select_action_IRF2C01_016(char* dialog, char* component, ProAppData data);
int Manual_F2C01_016();
int Automatic_F2C01_016();
ProError ProUtilDefaultFilter();
ProError ProUtilCollect3ParamOpaqueVisitAction(
	void* p_object,	/* In:	The opaque handle being visited */
	ProError	    status,	/* In:  The status returned by filter func */
	ProAppData	    app_data);	/* In:	In fact it's ProArray** */
ProError ProUtilCollect2ParamDBVisitAction(
	void* p_object,	/* In:	The pointer to the object being visited */
	ProAppData	    app_data);
ProError selection_action_IRF2C01_017(char* dialog, char* component, ProAppData data);


ProError measure_action_IR_F2C01_020(char* dialog, char* component);
ProError createDatumPointsusingCSYS_IR_F2C01_020(Pro3dPnt pnt_arr[2], char* csysName);
//ProError createDatumPointsusingCSYS_IR_F2C01_020(Pro3dPnt pnt_arr, Pro3dPnt pnt_arr2, char* csysName);
ProError ruleDlgOKaction_IR_F2C01_020(char* dialog, char* component, ProAppData data);
ProError ruleDlgCloseAction_IR_F2C01_020(char* dialog, char* component, ProAppData data);
ProError deleteDatumPointCreatedUsingCsys_IR_F2C01_020(char* dtmpoint_name);
ProError getReqComponentsId_IR_F2C01_020(ProFeature* pFeat, ProError status, ProAppData appD);
ProError compsFilter_IR_F2C01_020(ProFeature* p_feature, ProAppData app_data);
ProError selectaction_F2C01_020(char* dialog, char* component, ProAppData appD);
ProError radioGrpSelectAction_F2C01_020(char* dialog, char* component, ProAppData data);

ProError selectActionF2C01_013(char* dialog, char* component, ProAppData appD);
ProError cross_memb_fetch_F1A01(ProFeature* p_feature, ProError status, ProAppData appdata);
ProError propShaft_fasteners_fetch_F2C01(ProFeature* p_feature, ProError status, ProAppData appdata);
ProError mouting_bkt_fetch_F2C02(ProFeature* p_feature, ProError status, ProAppData app_data);

string remSpacesAtBothEnds1(const string& str);
//ProError select_action_IRF2C01013(char* dialog, char* component, ProAppData data);
//ProError visitFasteners(ProFeature* p_feature, ProError status, vector<HardwareInfo>* _hwInfo);
//ProError run_action_IRF2C01_019(char* dialog, char* component, ProAppData data);
//ProError select_action_IR_F2C01_019(char* dialog, char* component, ProAppData data);
ProError getParameterDescAndPartnameF2C01(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError selectActionF2C01_019(char* dialog, char* component, ProAppData appD);
ProError radioGrpSelectAction(char* dialog, char* component, ProAppData data);
#endif