/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 18-04-2023	|	V1_0_0		| F1B01 - FIFTH WHEEL COUPLING RULES
==================================================================================================================*/
#pragma once
#ifndef IRF1B01_H
#define IRF1B01_H

#include "InterfaceRule.h"

class IRF1B01 : private InterfaceRule
{
public:
	// CTOR
	//IRF1B01();

	// METHODS
	int IRF1B01_001(ruleResult &final_res);
};

#endif