#pragma once
/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-04-2023	|	V1_0_0		| F2B06 - STEERING SYSTEM RULES
==================================================================================================================*/
#pragma once

#ifndef IRF2B06_H
#define IRF2B06_H

#include "InterfaceRule.h"

struct PartnameDescriptionPairF2B06 {		// Prajakta
	char part_name[PRO_NAME_SIZE];
	char description[PRO_NAME_SIZE];
};

class IRF2B06 : private InterfaceRule
{
public:
	// CTOR
	IRF2B06() = default;

	// METHODS
	int IRF2B06_003(ruleResult& final_res);

};
ProError user_action_F2B06_003(ProFeature* p_feature, ProError status, ProAppData appdata);

#endif