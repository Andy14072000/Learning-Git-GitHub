/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 24-04-2023	| V1_0_0		| F2A02 - FRONT AXLE/LIFT AXLE RULES
==================================================================================================================*/
#pragma once
#ifndef IRF2A02_H
#define IRF2A02_H

#include "InterfaceRule.h"

class IRF2A02 : private InterfaceRule
{
public:
	// CTOR
	IRF2A02() = default;

	// METHODS
	int IRF2A02_003(ruleResult &final_res);
	int IRF2A02_004(ruleResult &final_res);
	int IRF2A02_007(ruleResult& final_res);
	int IRF2A02_008(ruleResult& final_res);
	int IRF2A02_009(ruleResult& final_res);
};
ProError select_action_IRF2A02_003(char* dialog, char* component, ProAppData data);

ProError select_action_IRF2A02_004(char* dialog, char* component, ProAppData data);

ProError select_action_IRF2A02_007(char* dialog, char* component, ProAppData data);

/*------------------------ Prototypes for IR-F2A02_008 ------------------------- */
ProError select_action_IRF2A02_008(char* dialog, char* component, ProAppData data);
int measureDistanceBetweenAsmAndPart_F2A02_008(ComponentData reqComp1, ProSelection* Part_sel, double& distance);

/*------------------------ Prototypes for IR-F2A02_009 ------------------------- */
ProError select_action_IRF2A02_009_01(char* dialog, char* component, ProAppData data);
ProError select_action_IRF2A02_009_02(char* dialog, char* component, ProAppData data);

#endif