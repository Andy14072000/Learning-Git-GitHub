/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 30-06-2022	| V1_0_0		| SQL INTEGRATION
===================================================================================================================
BHUVAN BHARATH	| 07-04-2023	| V2_0_0		| SQLite INTEGRATION
==================================================================================================================*/#pragma once
#ifndef SQL_DB_H
#define SQL_DB_H

#include "sqlite/sqlite3.h"
#include <io.h>

typedef struct SQLruleData
{
	int sno;
	char id[PRO_PATH_SIZE];
	char status[PRO_NAME_SIZE];
	char *remark;
} SQLruleData;

struct ruleResult
{
	string result = "";
	string remark = "";
	bool performedSts;
};

//int sqlConnect();
int createSQLtbl(vector<string> ruleNames, char* mdlName);
int SQLupdateRuleStatus(char* mdlName, int testNo, ruleResult *_testResult);
int retrieveSQLData(char* mdlName, vector<SQLruleData> &testData);
int SQLcheckIfRulePerformed(char* mdlName, int testId, bool &isTestPerformed);
int custom_busy_handler(void *data, int count);
//int setSQLiteJournalMode();
//string getPasswordFromConfig();
//void freeSQL();
#endif