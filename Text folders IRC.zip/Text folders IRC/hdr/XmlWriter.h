/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 08-02-2023	| V1_0_0		| XML FILE OPERATIONS
==================================================================================================================*/
#ifndef XML_WRITER_H
#define XML_WRITER_H
#include "DPDSCreoIRCapplication.h"
#include "AppFrontEnd.h"
#include "AppBackEnd.h"

class XMLWriter
{
public:
	string doc_name;
	string doc_path;
	string status_value;
	string candidate_name;
	int	  stat_total, stat_failed, stat_passed, stat_non_applicable, sum_total;
	string timestamp_date;
	string timestamp_time;
	string username;

	void writeSummary(Summary sumry);
	void writeRequirements(vector <RuleRequirements> req);
	void writeResults(rule_results res, vector <RuleRequirements> req);
	void userComments(/*usercomments *usrcom*/);
	void xmlWrite(string xmlFileName, Summary sumry, vector <RuleRequirements> req, rule_results res, char *cResPath);
	void writeHTML(string xmlFileName, string htmlFileName);
};


#endif