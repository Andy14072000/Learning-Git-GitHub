/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 07-DEC-2021	| V1_0_0		| LOG FILE OPERATIONS
==================================================================================================================*/
#pragma once
#ifndef LOGFILE_H
#define LOGFILE_H

#include <fstream>
#include <vector>
#include <string>
#include <ctime>
#include <iostream>
#include <Windows.h>
#include <direct.h>
#include <iomanip>

using namespace std;

class LogFile
{
public:
	// MEMBER
	char file_path[260];

	// METHODS
	void Start(string filePath);
	void Append(string filePath);
	string getTime();
	void Write(const std::string& text);
	void WriteDouble(double value, int precision);
};
#endif

