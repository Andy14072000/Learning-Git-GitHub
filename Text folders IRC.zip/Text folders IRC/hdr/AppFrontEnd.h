/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-12-2021	|	V1_0_0		| FRONT END UPDATED
==================================================================================================================*/
#pragma once
#ifndef APP_FRONT_END_H
#define APP_FRONT_END_H

#include "DPDSCreoIRCapplication.h"
#include "XmlWriter.h"
#include "AssemblyTool.h"
#include "curl.h"
#include<DPDSCreoAppTracker.h>

//GLOBAL DECLARATIONS
extern int sqlRes;
extern char stsCellLabel[PRO_NAME_SIZE];
extern char stsCellLabelPass[PRO_NAME_SIZE];
extern char stsCellLabelFail[PRO_NAME_SIZE];
extern char stsCellLabelDeviation[PRO_NAME_SIZE];
extern char stsCellLabelManualCheck[PRO_NAME_SIZE];
extern bool submitToPlmEnable;
extern ProParameter n_fail_parameter;
extern vector<string> testResult;
//extern vector<RuleRequirements> testResult;

class AppFrontEnd /*: public AppBackEnd*/
{
public:
	int initialize();
	int createLibraryTable(SubModuleInfo subModuleInfo);
private:
	void createUIDialog();
	int createStatusTable();
};

// CALLBACK FUNCTIONS
ProError submitPLM_pb_action(char* dialog, char* component, ProAppData app_data);
ProError report_pb_action(char* dialog, char* component, ProAppData app_data);
ProError tab_action(char* dialog, char* component, ProAppData app_data);
ProError run_pb_action(char* dialog, char* component, ProAppData app_data);
ProError verify_cb_action(char* dialog, char* component, ProAppData app_data);
ProError help_pb_action(char* dialog, char* component, ProAppData app_data);
ProError main_close_pb_action(char* dialog, char* component, ProAppData data);
ProError main_UI_close(char* dialog, char* component, ProAppData data);
ProError submodule_list_select_action(char* dialog, char* component, ProAppData app_data);
ProError submodule_retrieve_callback(ProFeature* p_feature, ProError status, ProAppData app_data);
ProError deviation_cb_action(char* dialog, char* component, ProAppData app_data);
ProError copy_pb_action(char* dialog, char* component, ProAppData app_data);
ProError revision_extraction_from_txr(const string& mdl_name, char* Con_mdl_Name);
ProError DRStatus_creation(ProModelitem cSubmdlItem);

// FUNTION PROTOTYPES FOR FrontEndActions.cpp
int extractRuleNames(string subModlName, vector<string> &tableData);
void extractRulesData(char* descFilePath, vector<string> ruleNames, vector<string> &rulesData, bool truncate);
void ruleStatusUIupdate(RuleInfo &rule_info);
string generateReport(string subModuleName, vector<RuleInfo> &rules_list);
void updateGUI(string subModlName, vector<RuleInfo> &rules_list);
void fetchRuleInfo(SubModuleInfo subModlInfo, vector<RuleInfo> &rulesList);
bool sortDigitisable(const RuleInfo& info);
void writeRemarkTxtFile(string remarkFp, RuleInfo subModuleInfo);
size_t WriteCallback1(void* contents, size_t size, size_t nmemb, std::string* output);

// VERIFY ACTIONS (SPECIAL CASES)
void IR_F1E02_006_verifyaction(vector<string> &reqInterfModules);
void IR_F1E01_007_verifyaction(vector<string>& reqInterfModules);
void IR_F2B06_003_verifyaction(vector<string>& reqInterfModules);

#endif 