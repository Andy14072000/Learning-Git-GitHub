/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 23-12-2021	|	V1_0_0		| BACKEND OPERATIONS UPDATED
==================================================================================================================*/
#pragma once
#ifndef APP_BACKEND_H
#define APP_BACKEND_H

#include "DPDSCreoIRCapplication.h"

struct RuleRequirements
{
	int testIndx = 0;
	string name;
	int performed;
	string status;
	string comments;
	string description;
};

struct rule_results
{
	int total = 0;
	int totPassed = 0;
	int totFailed = 0;
	int totNA = 0;
};

struct Summary
{
	string candidate;
	string finalResult;
	int total = 0;
	int passed = 0;
	int failed = 0;
	int notApplicable = 0;
	string asmLoc;
	string userName;
	string dateCreated;
	string timeCreated;
};

class AppBackEnd
{
public:
	// MEMBER FUNCTIONS
	int CallSelectedRule(string TestName, ruleResult &res);
}; 


#endif
