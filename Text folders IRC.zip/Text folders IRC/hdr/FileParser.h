/*=================================================================================================================
NAME			| DATE			| VERSION		| COMMENTS
===================================================================================================================
BHUVAN BHARATH	| 20-01-2023	| V1_0_0		| FILES OPERATIONS
==================================================================================================================*/
#pragma once
#include <Windows.h>
#include <string>
#include <string.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
#include <sstream>
#include <istream>

using namespace std;

class FileParser
{
	string fileName;
	char delimeter;

public:
	FileParser(string filename, char delm) :
		fileName(filename), delimeter(delm)
	{ }

	int getData2D(vector<vector<string>> &data2D);
	int getData(vector<string> &data1D);
	int getlinesCount();

};




